export * as OpenCodeWorkerd from "./workerd";
import { WorkerdProfile } from "./internal/workerd";
import type { LogOptions } from "./logging";
import { PromiseSdk } from "./promise";
export type Configuration = WorkerdProfile.Configuration;
export interface CreateOptions extends WorkerdProfile.Options {
    readonly log?: LogOptions;
    readonly plugins?: PromiseSdk.CreateOptions["plugins"];
    readonly instances?: PromiseSdk.CreateOptions["instances"];
}
/**
 * Boots the embedded opencode SDK on the workerd runtime profile: the full
 * application graph inside a Cloudflare Durable Object, with the database on
 * the injected `DurableObjectStorage` SQLite and every intentionally-local
 * service replaced or disabled (see `ServerWorkerd.replacements`).
 *
 * Suspended Sessions resume on boot (as on every runtime) because a Durable
 * Object can be evicted mid-turn with no teardown; the write-ahead execution
 * claim marks the turn and the boot-time sweep replays it.
 *
 * Returns the same typed `OpenCode.Interface` as `OpenCode.create` — typed
 * session operations plus the live `events.subscribe()` stream — served over
 * an in-process fetch transport, so no request leaves the isolate.
 */
export declare const create: ({ log, plugins, instances, ...options }: CreateOptions) => Promise<PromiseSdk.Interface>;
export type Interface = PromiseSdk.Interface;
