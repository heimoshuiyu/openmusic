import { PromiseSdk } from "./promise";
export type { LogEntry, LogLevel, LogOptions, LogWriter } from "./logging";
export type CreateOptions = PromiseSdk.CreateOptions;
export type InstanceOptions = PromiseSdk.InstanceOptions;
export type InstanceConfiguration = PromiseSdk.InstanceConfiguration;
export type Interface = PromiseSdk.Interface;
export declare const create: (options?: CreateOptions) => Promise<PromiseSdk.Interface>;
