export * as WorkerdProfile from "./workerd";
import type { Config } from "@opencode/schema/config";
import { ServerWorkerd } from "@opencode/server/workerd";
export type Configuration = Omit<typeof Config.Info.Encoded, "plugins">;
export interface Options extends Omit<ServerWorkerd.Options, "password" | "config"> {
    readonly config?: Configuration;
}
export declare function make({ config, ...options }: Options): {
    options: {
        readonly app?: {
            readonly name?: string | undefined;
            readonly version?: string | undefined;
            readonly channel?: string | undefined;
        } | undefined;
        readonly hostname?: string | undefined;
        readonly port?: number | undefined;
        readonly password?: string | undefined;
        readonly cors?: readonly string[] | undefined;
        readonly simulation?: boolean | undefined;
        readonly database?: {
            readonly path?: string | undefined;
        } | undefined;
        readonly pty?: {
            readonly handoff?: {
                readonly directory: string;
                readonly instanceID: string;
                readonly ticket: string;
                readonly expiresAt: number;
            } | undefined;
            readonly root?: string | undefined;
        } | undefined;
        readonly events?: {
            readonly persist?: boolean | undefined;
        } | undefined;
        readonly models?: {
            readonly url?: string | undefined;
            readonly file?: string | undefined;
            readonly fetch?: boolean | undefined;
            readonly snapshot?: boolean | undefined;
        } | undefined;
        readonly fetch?: import("@opencode/util/effect/app-node-platform").Fetch | undefined;
        readonly config?: {
            readonly directory?: string | undefined;
            readonly project?: boolean | undefined;
            readonly claude?: boolean | undefined;
            readonly file?: string | undefined;
            readonly content?: string | undefined;
        } | undefined;
        readonly windows?: {
            readonly gitbash?: string | undefined;
        } | undefined;
        readonly fs?: {
            readonly filewatcher?: boolean | undefined;
            readonly fff?: boolean | undefined;
        } | undefined;
    };
    replacements: import("@opencode/util/effect/layer-node").Replacements;
};
