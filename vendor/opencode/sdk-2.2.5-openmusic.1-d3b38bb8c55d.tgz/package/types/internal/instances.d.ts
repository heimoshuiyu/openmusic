export * as SdkInstances from "./instances";
import { Instance } from "@opencode/core/instance";
import { LocationServiceMap } from "@opencode/core/location-service-map";
import type { InstancePlugins } from "@opencode/core/plugin/instance";
import type { Session } from "@opencode/schema/session";
import type { LayerNode } from "@opencode/util/effect/layer-node";
import { Context, Effect, Layer, Scope } from "effect";
export interface Configuration {
    readonly plugins: InstancePlugins.List;
}
export interface Options<R = never> {
    /** Select a sharing key within the Session's current Location. Must not initialize plugins. */
    readonly key: (session: Session.Info) => string;
    /**
     * Reconstruct configuration on a cache miss. Resources belong to the instance Scope; other requirements
     * are the services the SDK entrypoint was built with.
     */
    readonly configure: (key: string) => Effect.Effect<Configuration, unknown, R | Scope.Scope>;
}
/** Closes `configure` over services captured where the SDK entrypoint was built; the host graph has none of its own. */
export declare function provide<R>(options: Options<R>, context: Context.Context<R>): Options;
/** Replaces the host's `Instance.node`; `replacements` resolves lazily so instances inherit the final host graph. */
export declare function node(options: Options, replacements: () => LayerNode.Replacements): LayerNode.Provider<Instance.Service, never, LayerNode.Tag<"global">>;
export declare function layer(options: Options, replacements: () => LayerNode.Replacements): Layer.Layer<Instance.Service, never, LocationServiceMap.Service>;
