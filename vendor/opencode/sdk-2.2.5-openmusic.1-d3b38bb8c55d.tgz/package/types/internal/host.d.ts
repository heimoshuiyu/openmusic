export * as EmbeddedHost from "./host";
import { SdkPlugins } from "@opencode/core/plugin/sdk";
import type { Plugin } from "@opencode/plugin/effect/plugin";
import { SessionRestart } from "@opencode/core/session/execution/restart";
import { Session } from "@opencode/core/session";
import { Workspace } from "@opencode/core/workspace";
import { WorkspaceDriver } from "@opencode/core/workspace/driver";
import type { ServerOptions } from "@opencode/server/options";
import type { LayerNode } from "@opencode/util/effect/layer-node";
import { Effect, ManagedRuntime } from "effect";
import { HttpRouter } from "effect/http";
import { type LogOptions } from "../logging";
import { SdkInstances } from "./instances";
export interface CreateOptions<R = never> extends Omit<ServerOptions, "hostname" | "port" | "password"> {
    readonly log?: LogOptions;
    readonly plugins?: ReadonlyArray<Plugin>;
    readonly workspaceProviders?: Readonly<Record<string, WorkspaceDriver.Interface>>;
    readonly instances?: SdkInstances.Options<R>;
}
/** Host hooks for embedding opencode on a non-default runtime profile. */
export interface EmbedOptions {
    readonly overrides?: LayerNode.Replacements;
}
export declare const create: <R = never>(options?: CreateOptions<R> | undefined, embed?: EmbedOptions | undefined) => Effect.Effect<{
    runtime: ManagedRuntime.ManagedRuntime<import("effect/http/HttpClient").HttpClient | HttpRouter.HttpRouter | import("@opencode/util/global").Service | import("@opencode/core/database/database").Service | import("@opencode/util/fs-util").FSUtil.Service | import("@opencode/core/project").Service | import("@opencode/core/app").Service | import("@opencode/core/credential").Service | import("@opencode/core/kv").Service | import("@opencode/core/wellknown").Service | Workspace.Service | import("@opencode/core/session/instruction-entry").Service | import("@opencode/core/job").Service | import("@opencode/core/permission/saved").Service | import("@opencode/core/location-service-map").Service | Session.Service | import("@opencode/core/persistent-pty/index").Service | import("@opencode/core/worktree").Service | import("@opencode/core/schedule").Service | import("@opencode/core/plugin/update").Service | import("@opencode/core/instance").Service | import("@opencode/core/bus").Service | SdkPlugins.Service | SessionRestart.Service | import("@opencode/core/pty/ticket").Service | import("@opencode/core/session/transfer").Service | import("@opencode/core/location-activity").Service | import("@opencode/core/filesystem/file-watch").Service | import("@opencode/server/pairing").Service, Error | import("@opencode/core/persistent-pty/index").UnavailableError>;
    fetch: ((input: RequestInfo | URL, init?: RequestInit) => Promise<Response>) & {
        preconnect: () => undefined;
    };
    plugins: SdkPlugins.Interface;
    sessions: Session.Interface;
    workspace: Workspace.Interface;
    close: () => Promise<void>;
}, Error, R>;
export type Interface = Effect.Success<ReturnType<typeof create>>;
