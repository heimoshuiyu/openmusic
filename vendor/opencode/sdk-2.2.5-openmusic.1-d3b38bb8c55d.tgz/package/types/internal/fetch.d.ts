export * as OwnedFetch from "./fetch";
export declare function make(handler: (request: Request) => Promise<Response>, dispose: () => Promise<void>): {
    fetch: ((input: RequestInfo | URL, init?: RequestInit) => Promise<Response>) & {
        preconnect: () => undefined;
    };
    close: () => Promise<void>;
};
