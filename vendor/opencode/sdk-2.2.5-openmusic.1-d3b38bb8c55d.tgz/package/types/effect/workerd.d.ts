export * as OpenCodeWorkerd from "./workerd";
import { Layer } from "effect";
import type { Config, Scope } from "effect";
import { WorkerdProfile } from "../internal/workerd";
import { OpenCode } from "./opencode";
export type Configuration = WorkerdProfile.Configuration;
export interface CreateOptions<R = never> extends WorkerdProfile.Options {
    readonly log?: OpenCode.CreateOptions["log"];
    readonly plugins?: OpenCode.CreateOptions["plugins"];
    readonly workspaceProviders?: OpenCode.CreateOptions["workspaceProviders"];
    readonly instances?: OpenCode.CreateOptions<R>["instances"];
}
export declare const create: <R = never>({ log, plugins, workspaceProviders, instances, ...options }: CreateOptions<R>) => import("effect/Effect").Effect<OpenCode.Interface, Config.ConfigError | Error, R | Scope.Scope>;
export declare const layer: <R = never>(options: CreateOptions<R>) => Layer.Layer<OpenCode.Service, Config.ConfigError | Error, Exclude<R, Scope.Scope>>;
export type Interface = OpenCode.Interface;
export type Requirements = Scope.Scope;
