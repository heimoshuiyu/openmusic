export * as OpenCode from "./opencode";
import { type OpenCodeClient } from "@opencode/client/effect";
import type { Session } from "@opencode/core/session";
import type { Workspace } from "@opencode/core/workspace";
import { Context, Effect, Layer } from "effect";
import type { Config, Scope } from "effect";
import { EmbeddedHost } from "../internal/host";
import type { SdkInstances } from "../internal/instances";
export type { LogEntry, LogLevel, LogOptions, LogWriter } from "../logging";
export type CreateOptions<R = never> = EmbeddedHost.CreateOptions<R>;
export type EmbedOptions = EmbeddedHost.EmbedOptions;
export type InstanceOptions<R = never> = SdkInstances.Options<R>;
export type InstanceConfiguration = SdkInstances.Configuration;
export type Interface = Omit<OpenCodeClient, "plugin" | "workspace"> & {
    readonly sessions: Omit<OpenCodeClient["session"], "create" | "get" | "move"> & {
        readonly create: Session.Interface["create"];
        readonly get: (input: {
            readonly sessionID: Session.ID;
        }) => ReturnType<Session.Interface["get"]>;
        readonly move: Session.Interface["move"];
    };
    readonly events: OpenCodeClient["event"];
    readonly workspace: {
        readonly create: Workspace.Interface["create"];
        readonly provision: (options: {
            readonly workspaceID: Workspace.ID;
        }) => ReturnType<Workspace.Interface["provision"]>;
        readonly destroy: (options: {
            readonly workspaceID: Workspace.ID;
        }) => ReturnType<Workspace.Interface["destroy"]>;
    };
    readonly plugin: EmbeddedHost.Interface["plugins"]["register"] & OpenCodeClient["plugin"];
};
export declare const create: <R = never>(options?: CreateOptions<R>, embed?: EmbedOptions) => Effect.Effect<Interface, Config.ConfigError | Error, Scope.Scope | R>;
declare const Service_base: Context.ServiceClass<Service, "@opencode/sdk/OpenCode", Interface>;
export declare class Service extends Service_base {
}
export declare const layer: <R = never>(options?: CreateOptions<R>) => Layer.Layer<Service, Config.ConfigError | Error, Exclude<R, Scope.Scope>>;
