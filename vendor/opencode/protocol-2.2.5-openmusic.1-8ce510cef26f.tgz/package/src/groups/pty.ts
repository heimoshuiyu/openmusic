import { Pty } from "@opencode/schema/pty"
import { PtyTicket } from "@opencode/schema/pty-ticket"
import { Location } from "@opencode/schema/location"
import { Context, Schema } from "effect"
import { HttpApiEndpoint, HttpApiGroup, HttpApiMiddleware, HttpApiSchema, OpenApi } from "effect/http-api"
import { ForbiddenError, LocationNotFoundError, PtyNotFoundError } from "../errors.js"
import { LocationQuery, locationQueryOpenApi } from "./location.js"

export const PTY_CONNECT_TICKET_QUERY = "ticket"
export const PTY_CONNECT_TOKEN_HEADER = "x-opencode-ticket"
export const PTY_CONNECT_TOKEN_HEADER_VALUE = "1"
export const PTY_CONNECT_PATH = "/api/pty/:ptyID/connect"

const PTY_CONNECT_URL = /^\/api\/pty\/[^/]+\/connect$/

export function hasPtyConnectTicketURL(url: URL) {
  return PTY_CONNECT_URL.test(url.pathname) && !!url.searchParams.get(PTY_CONNECT_TICKET_QUERY)
}

export const makePtyGroup = <LocationId extends HttpApiMiddleware.AnyId, LocationService>(
  locationMiddleware: Context.Key<LocationId, LocationService>,
) =>
  HttpApiGroup.make("server.pty")
    .add(
      HttpApiEndpoint.get("pty.list", "/api/pty", {
        query: LocationQuery,
        success: Location.response(Schema.Array(Pty.Info)),
      })
        .annotateMerge(locationQueryOpenApi)
        .annotateMerge(
          OpenApi.annotations({
            identifier: "pty.list",
            summary: "List PTY sessions",
            description: "List PTY sessions for a location, including exited sessions retained until removal.",
          }),
        ),
    )
    .add(
      HttpApiEndpoint.post("pty.create", "/api/pty", {
        query: LocationQuery,
        payload: Pty.CreateInput,
        success: Location.response(Pty.Info),
      })
        .annotateMerge(locationQueryOpenApi)
        .annotateMerge(
          OpenApi.annotations({
            identifier: "pty.create",
            summary: "Create PTY session",
            description: "Create a pseudo-terminal session for a location.",
          }),
        ),
    )
    .add(
      HttpApiEndpoint.get("pty.get", "/api/pty/:ptyID", {
        params: { ptyID: Pty.ID },
        query: LocationQuery,
        success: Location.response(Pty.Info),
        error: PtyNotFoundError,
      })
        .annotateMerge(locationQueryOpenApi)
        .annotateMerge(
          OpenApi.annotations({
            identifier: "pty.get",
            summary: "Get PTY session",
            description: "Get one PTY session, including its exit code once exited.",
          }),
        ),
    )
    .add(
      HttpApiEndpoint.put("pty.update", "/api/pty/:ptyID", {
        params: { ptyID: Pty.ID },
        query: LocationQuery,
        payload: Pty.UpdateInput,
        success: Location.response(Pty.Info),
        error: PtyNotFoundError,
      })
        .annotateMerge(locationQueryOpenApi)
        .annotateMerge(
          OpenApi.annotations({
            identifier: "pty.update",
            summary: "Update PTY session",
            description: "Update the title or viewport size of one PTY session.",
          }),
        ),
    )
    .add(
      HttpApiEndpoint.delete("pty.remove", "/api/pty/:ptyID", {
        params: { ptyID: Pty.ID },
        query: LocationQuery,
        success: HttpApiSchema.NoContent,
        error: PtyNotFoundError,
      })
        .annotateMerge(locationQueryOpenApi)
        .annotateMerge(
          OpenApi.annotations({
            identifier: "pty.remove",
            summary: "Remove PTY session",
            description: "Terminate and remove one PTY session.",
          }),
        ),
    )
    .add(
      HttpApiEndpoint.post("pty.connectToken", "/api/pty/:ptyID/connect-token", {
        params: { ptyID: Pty.ID },
        query: LocationQuery,
        headers: Schema.Struct({ [PTY_CONNECT_TOKEN_HEADER]: Schema.optional(Schema.String) }),
        success: Location.response(PtyTicket.ConnectToken),
        error: [ForbiddenError, PtyNotFoundError],
      })
        .annotateMerge(locationQueryOpenApi)
        .annotateMerge(
          OpenApi.annotations({
            identifier: "pty.connect.token",
            summary: "Create PTY WebSocket token",
            description: "Create a short-lived single-use ticket for opening a PTY WebSocket connection.",
          }),
        ),
    )
    .middleware(locationMiddleware)
    .add(
      // Query fields are decoded in the raw handler before upgrade work.
      HttpApiEndpoint.get("pty.connect", PTY_CONNECT_PATH, {
        params: { ptyID: Pty.ID },
        success: Schema.Boolean,
        error: [ForbiddenError, PtyNotFoundError, LocationNotFoundError],
      }).annotateMerge(
        OpenApi.annotations({
          identifier: "pty.connect",
          summary: "Connect to PTY session",
          description: "Establish a WebSocket connection streaming PTY output and accepting terminal input.",
          transform: (operation) => ({
            ...operation,
            "x-websocket": true,
            parameters: [
              ...(operation.parameters ?? []),
              ...["location[directory]", "cursor", PTY_CONNECT_TICKET_QUERY].map((name) => ({
                in: "query",
                name,
                schema: { type: "string" },
              })),
            ],
          }),
        }),
      ),
    )
    .annotateMerge(OpenApi.annotations({ title: "pty", description: "Experimental location-scoped PTY routes." }))
