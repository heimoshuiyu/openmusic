import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiSchema } from "effect/http-api";
import { FileNotFoundError, ServiceUnavailableError } from "../errors.js";
export declare const FileSystemGroup: HttpApiGroup.HttpApiGroup<"server.fs", HttpApiEndpoint.HttpApiEndpoint<"fs.find", "GET", "/api/fs/find", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
    readonly query: Schema.String;
    readonly type: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["file", "directory"]>>>, Schema.optionalKey<Schema.Literals<readonly ["file", "directory"]>>, never, never>;
    readonly limit: Schema.optional<Schema.compose<Schema.Int, Schema.NumberFromString>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly path: Schema.brand<Schema.String, "RelativePath">;
        readonly type: Schema.Literals<readonly ["file", "directory"]>;
    }>>;
}>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"fs.list", "GET", "/api/fs/list", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
    readonly path: Schema.optional<Schema.String>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly path: Schema.brand<Schema.String, "RelativePath">;
        readonly type: Schema.Literals<readonly ["file", "directory"]>;
    }>>;
}>>, Schema.toCodecJson<typeof FileNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"fs.read", "GET", "/api/fs/read/*", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Uint8Array>, Schema.toCodecJson<typeof FileNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"fs.unwatch", "DELETE", "/api/experimental/fs/watch", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly path: Schema.String;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"fs.watch", "POST", "/api/experimental/fs/watch", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly path: Schema.String;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof ServiceUnavailableError | typeof FileNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"fs.write", "POST", "/api/experimental/fs/write", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
    readonly path: Schema.String;
}>>, Schema.toCodecJson<Schema.Uint8Array>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly path: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
}>>, never, never, never>, false>;
