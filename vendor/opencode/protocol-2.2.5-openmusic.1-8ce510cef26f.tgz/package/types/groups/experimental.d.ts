/** `server.experimental`: routes under /api/experimental, without compatibility guarantees. */
export declare const ExperimentalGroup: import("effect/http-api/HttpApiGroup").HttpApiGroup<"server.experimental", import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"artifacts.create", "POST", "/api/experimental/artifacts", never, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").optional<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").optional<import("effect/Schema").String>;
    }>>;
}>>, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly title: import("effect/Schema").String;
    readonly files: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").String>;
    readonly entry: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
    readonly provider: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Trim, "Artifact.ProviderID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").Trim, "Artifact.ProviderID">>, never, never>;
    readonly sessionID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
}>>, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
    }>;
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Artifact.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
        };
        readonly provider: import("effect/Schema").brand<import("effect/Schema").Trim, "Artifact.ProviderID">;
        readonly sessionID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly title: import("effect/Schema").String;
        readonly entry: import("effect/Schema").String;
        readonly url: import("effect/Schema").String;
        readonly time: import("effect/Schema").Struct<{
            readonly created: import("effect/Schema").Finite;
            readonly updated: import("effect/Schema").Finite;
        }>;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").LocationNotFoundError | typeof import("../errors.js").InvalidRequestError | typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").ProviderNotFoundError | typeof import("../errors.js").SessionNotFoundError | typeof import("../errors.js").ForbiddenError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"artifacts.delete", "DELETE", "/api/experimental/artifacts/:artifactID", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    artifactID: import("effect/Schema").brand<import("effect/Schema").String, "Artifact.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
    };
}>>, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").optional<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").optional<import("effect/Schema").String>;
    }>>;
}>>, never, never, import("effect/Schema").toCodecJson<import("effect/http-api/HttpApiSchema").NoContent>, import("effect/Schema").toCodecJson<typeof import("../errors.js").LocationNotFoundError | typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").ForbiddenError | typeof import("../errors.js").ArtifactNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"artifacts.get", "GET", "/api/experimental/artifacts/:artifactID", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    artifactID: import("effect/Schema").brand<import("effect/Schema").String, "Artifact.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
    };
}>>, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").optional<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").optional<import("effect/Schema").String>;
    }>>;
}>>, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
    }>;
    readonly data: import("effect/Schema").Struct<{
        readonly info: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Artifact.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
            };
            readonly provider: import("effect/Schema").brand<import("effect/Schema").Trim, "Artifact.ProviderID">;
            readonly sessionID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            }>, never, never>;
            readonly title: import("effect/Schema").String;
            readonly entry: import("effect/Schema").String;
            readonly url: import("effect/Schema").String;
            readonly time: import("effect/Schema").Struct<{
                readonly created: import("effect/Schema").Finite;
                readonly updated: import("effect/Schema").Finite;
            }>;
        }>;
        readonly files: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").String>;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").LocationNotFoundError | typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").ForbiddenError | typeof import("../errors.js").ArtifactNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"artifacts.list", "GET", "/api/experimental/artifacts", never, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").optional<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").optional<import("effect/Schema").String>;
    }>>;
    readonly sessionID: import("effect/Schema").optional<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>;
    readonly provider: import("effect/Schema").optional<import("effect/Schema").brand<import("effect/Schema").Trim, "Artifact.ProviderID">>;
}>>, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
    }>;
    readonly data: import("effect/Schema").$Array<import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Artifact.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
        };
        readonly provider: import("effect/Schema").brand<import("effect/Schema").Trim, "Artifact.ProviderID">;
        readonly sessionID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly title: import("effect/Schema").String;
        readonly entry: import("effect/Schema").String;
        readonly url: import("effect/Schema").String;
        readonly time: import("effect/Schema").Struct<{
            readonly created: import("effect/Schema").Finite;
            readonly updated: import("effect/Schema").Finite;
        }>;
    }>>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").LocationNotFoundError | typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").SessionNotFoundError | typeof import("../errors.js").ForbiddenError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"artifacts.providers", "GET", "/api/experimental/artifacts/providers", never, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").optional<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").optional<import("effect/Schema").String>;
    }>>;
}>>, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
    }>;
    readonly data: import("effect/Schema").$Array<import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").Trim, "Artifact.ProviderID">;
        readonly name: import("effect/Schema").String;
        readonly capabilities: import("effect/Schema").$Array<import("effect/Schema").Literals<readonly ["static", "server-code", "sqlite", "durable-objects"]>>;
        readonly default: import("effect/Schema").Boolean;
    }>>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").LocationNotFoundError | typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").ForbiddenError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"artifacts.update", "PATCH", "/api/experimental/artifacts/:artifactID", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    artifactID: import("effect/Schema").brand<import("effect/Schema").String, "Artifact.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
    };
}>>, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").optional<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").optional<import("effect/Schema").String>;
    }>>;
}>>, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
    readonly files: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").String>;
    readonly entry: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
    readonly sessionID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
}>>, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
    }>;
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Artifact.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
        };
        readonly provider: import("effect/Schema").brand<import("effect/Schema").Trim, "Artifact.ProviderID">;
        readonly sessionID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly title: import("effect/Schema").String;
        readonly entry: import("effect/Schema").String;
        readonly url: import("effect/Schema").String;
        readonly time: import("effect/Schema").Struct<{
            readonly created: import("effect/Schema").Finite;
            readonly updated: import("effect/Schema").Finite;
        }>;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").LocationNotFoundError | typeof import("../errors.js").InvalidRequestError | typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").SessionNotFoundError | typeof import("../errors.js").ForbiddenError | typeof import("../errors.js").ArtifactNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"artifacts.view", "GET", "/api/experimental/artifacts/:artifactID/view/*", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    artifactID: import("effect/Schema").brand<import("effect/Schema").String, "Artifact.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
    };
}>>, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    readonly location: import("effect/Schema").optional<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").optional<import("effect/Schema").String>;
    }>>;
}>>, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Uint8Array>, import("effect/Schema").toCodecJson<typeof import("../errors.js").LocationNotFoundError | typeof import("../errors.js").InvalidRequestError | typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").FileNotFoundError | typeof import("../errors.js").ForbiddenError | typeof import("../errors.js").ArtifactNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"job.list", "GET", "/api/experimental/job", never, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    readonly sessionID: import("effect/Schema").optional<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>;
    readonly kind: import("effect/Schema").optional<import("effect/Schema").Literals<readonly ["shell", "subagent", "image"]>>;
    readonly status: import("effect/Schema").optional<import("effect/Schema").Literals<readonly ["running", "completed", "error", "cancelled"]>>;
    readonly descendants: import("effect/Schema").optional<import("effect/Schema").decodeTo<import("effect/Schema").Boolean, import("effect/Schema").Literals<readonly ["true", "false"]>, never, never>>;
}>>, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").$Array<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").String;
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: import("effect/Schema").Literals<readonly ["running", "completed", "error", "cancelled"]>;
        readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly time: import("effect/Schema").Struct<{
            readonly started: import("effect/Schema").Finite;
            readonly completed: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
        }>;
        readonly kind: import("effect/Schema").tag<"shell">;
        readonly shellID: import("effect/Schema").String;
        readonly command: import("effect/Schema").String;
    }>, import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").String;
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: import("effect/Schema").Literals<readonly ["running", "completed", "error", "cancelled"]>;
        readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly time: import("effect/Schema").Struct<{
            readonly started: import("effect/Schema").Finite;
            readonly completed: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
        }>;
        readonly kind: import("effect/Schema").tag<"subagent">;
        readonly childSessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly agent: import("effect/Schema").String;
        readonly description: import("effect/Schema").String;
    }>, import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").String;
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: import("effect/Schema").Literals<readonly ["running", "completed", "error", "cancelled"]>;
        readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly time: import("effect/Schema").Struct<{
            readonly started: import("effect/Schema").Finite;
            readonly completed: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
        }>;
        readonly kind: import("effect/Schema").tag<"image">;
        readonly path: import("effect/Schema").String;
        readonly model: import("effect/Schema").String;
    }>]>>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").InvalidRequestError | typeof import("../errors.js").SessionNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"media.get", "GET", "/api/experimental/media/:hash", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    hash: import("effect/Schema").String;
}>>, never, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Uint8Array>, import("effect/Schema").toCodecJson<typeof import("../errors.js").InvalidRequestError | typeof import("../errors.js").FileNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"persistentPty.connect", "GET", "/api/experimental/persistent-pty/:ptyID/connect", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    ptyID: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Boolean>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").ForbiddenError | typeof import("../errors.js").PtyNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"persistentPty.connectToken", "POST", "/api/experimental/persistent-pty/:ptyID/connect-token", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    ptyID: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, never, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    readonly "x-opencode-ticket": import("effect/Schema").optional<import("effect/Schema").String>;
}>>, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").Struct<{
        readonly ticket: import("effect/Schema").String;
        readonly expires_in: import("effect/Schema").Int;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").ForbiddenError | typeof import("../errors.js").PtyNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"persistentPty.create", "POST", "/api/experimental/session/:sessionID/terminal", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly command: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
    readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
    readonly cwd: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
    readonly title: import("effect/Schema").String;
    readonly env: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").String>;
    readonly size: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly cols: import("effect/Schema").Int;
        readonly rows: import("effect/Schema").Int;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly cols: import("effect/Schema").Int;
        readonly rows: import("effect/Schema").Int;
    }>>, never, never>;
}>>, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: import("effect/Schema").String;
        readonly command: import("effect/Schema").String;
        readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
        readonly cwd: import("effect/Schema").String;
        readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
        readonly pid: import("effect/Schema").Int;
        readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly userTitle: import("effect/Schema").NullOr<import("effect/Schema").String>;
        readonly foregroundProcess: import("effect/Schema").NullOr<import("effect/Schema").String>;
        readonly size: import("effect/Schema").Struct<{
            readonly cols: import("effect/Schema").Int;
            readonly rows: import("effect/Schema").Int;
        }>;
        readonly output: import("effect/Schema").Struct<{
            readonly head: import("effect/Schema").Int;
            readonly tail: import("effect/Schema").Int;
        }>;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").InvalidRequestError | typeof import("../errors.js").ServiceUnavailableError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"persistentPty.get", "GET", "/api/experimental/persistent-pty/:ptyID", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    ptyID: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: import("effect/Schema").String;
        readonly command: import("effect/Schema").String;
        readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
        readonly cwd: import("effect/Schema").String;
        readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
        readonly pid: import("effect/Schema").Int;
        readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly userTitle: import("effect/Schema").NullOr<import("effect/Schema").String>;
        readonly foregroundProcess: import("effect/Schema").NullOr<import("effect/Schema").String>;
        readonly size: import("effect/Schema").Struct<{
            readonly cols: import("effect/Schema").Int;
            readonly rows: import("effect/Schema").Int;
        }>;
        readonly output: import("effect/Schema").Struct<{
            readonly head: import("effect/Schema").Int;
            readonly tail: import("effect/Schema").Int;
        }>;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").PtyNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"persistentPty.handoff", "POST", "/api/experimental/persistent-pty/handoff", never, never, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly handoff: import("effect/Schema").NullOr<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").String;
        readonly instanceID: import("effect/Schema").String;
        readonly ticket: import("effect/Schema").String;
        readonly expiresAt: import("effect/Schema").Number;
    }>>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ServiceUnavailableError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"persistentPty.list", "GET", "/api/experimental/session/:sessionID/terminal", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").$Array<import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: import("effect/Schema").String;
        readonly command: import("effect/Schema").String;
        readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
        readonly cwd: import("effect/Schema").String;
        readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
        readonly pid: import("effect/Schema").Int;
        readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly userTitle: import("effect/Schema").NullOr<import("effect/Schema").String>;
        readonly foregroundProcess: import("effect/Schema").NullOr<import("effect/Schema").String>;
        readonly size: import("effect/Schema").Struct<{
            readonly cols: import("effect/Schema").Int;
            readonly rows: import("effect/Schema").Int;
        }>;
        readonly output: import("effect/Schema").Struct<{
            readonly head: import("effect/Schema").Int;
            readonly tail: import("effect/Schema").Int;
        }>;
    }>>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").InvalidRequestError | typeof import("../errors.js").ServiceUnavailableError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"persistentPty.read", "GET", "/api/experimental/session/:sessionID/terminal/read", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    lines: import("effect/Schema").optional<import("effect/Schema").compose<import("effect/Schema").Int, import("effect/Schema").NumberFromString>>;
}>>, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").NullOr<import("effect/Schema").Struct<{
        readonly ptyID: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: import("effect/Schema").String;
        readonly cwd: import("effect/Schema").String;
        readonly foregroundProcess: import("effect/Schema").NullOr<import("effect/Schema").String>;
        readonly screen: import("effect/Schema").Struct<{
            readonly text: import("effect/Schema").String;
            readonly cols: import("effect/Schema").Int;
            readonly rows: import("effect/Schema").Int;
            readonly cursor: import("effect/Schema").Struct<{
                readonly x: import("effect/Schema").Int;
                readonly y: import("effect/Schema").Int;
            }>;
        }>;
    }>>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ServiceUnavailableError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"persistentPty.remove", "DELETE", "/api/experimental/persistent-pty/:ptyID", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    ptyID: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, never, never, import("effect/Schema").toCodecJson<import("effect/http-api/HttpApiSchema").NoContent>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").PtyNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"persistentPty.shutdown", "POST", "/api/experimental/persistent-pty/shutdown", never, never, never, never, import("effect/Schema").toCodecJson<import("effect/http-api/HttpApiSchema").NoContent>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ServiceUnavailableError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"persistentPty.snapshot", "GET", "/api/experimental/persistent-pty/:ptyID/snapshot", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    ptyID: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").Struct<{
        readonly info: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: import("effect/Schema").String;
            readonly command: import("effect/Schema").String;
            readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
            readonly cwd: import("effect/Schema").String;
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
            readonly pid: import("effect/Schema").Int;
            readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: import("effect/Schema").NullOr<import("effect/Schema").String>;
            readonly foregroundProcess: import("effect/Schema").NullOr<import("effect/Schema").String>;
            readonly size: import("effect/Schema").Struct<{
                readonly cols: import("effect/Schema").Int;
                readonly rows: import("effect/Schema").Int;
            }>;
            readonly output: import("effect/Schema").Struct<{
                readonly head: import("effect/Schema").Int;
                readonly tail: import("effect/Schema").Int;
            }>;
        }>;
        readonly text: import("effect/Schema").String;
        readonly checkpoint: import("effect/Schema").Uint8Array;
        readonly cursor: import("effect/Schema").Struct<{
            readonly x: import("effect/Schema").Int;
            readonly y: import("effect/Schema").Int;
        }>;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").PtyNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"persistentPty.update", "PUT", "/api/experimental/persistent-pty/:ptyID", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    ptyID: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly attachmentID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
    readonly size: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly cols: import("effect/Schema").Int;
        readonly rows: import("effect/Schema").Int;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly cols: import("effect/Schema").Int;
        readonly rows: import("effect/Schema").Int;
    }>>, never, never>;
    readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").NullOr<import("effect/Schema").String>>>, import("effect/Schema").optionalKey<import("effect/Schema").NullOr<import("effect/Schema").String>>, never, never>;
}>>, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: import("effect/Schema").String;
        readonly command: import("effect/Schema").String;
        readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
        readonly cwd: import("effect/Schema").String;
        readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
        readonly pid: import("effect/Schema").Int;
        readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly userTitle: import("effect/Schema").NullOr<import("effect/Schema").String>;
        readonly foregroundProcess: import("effect/Schema").NullOr<import("effect/Schema").String>;
        readonly size: import("effect/Schema").Struct<{
            readonly cols: import("effect/Schema").Int;
            readonly rows: import("effect/Schema").Int;
        }>;
        readonly output: import("effect/Schema").Struct<{
            readonly head: import("effect/Schema").Int;
            readonly tail: import("effect/Schema").Int;
        }>;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ServiceUnavailableError | typeof import("../errors.js").PtyNotFoundError | typeof import("../errors.js").PtyFeatureUnsupportedError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"plugin.webList", "POST", "/api/experimental/plugin/web-list", never, never, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").$Array<import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Plugin.ID">;
    readonly revision: import("effect/Schema").String;
    readonly options: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>;
    readonly ticket: import("effect/Schema").String;
}>>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").LocationNotFoundError | typeof import("../errors.js").ForbiddenError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"plugin.webModule", "GET", "/api/experimental/plugin/web-module", never, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    id: import("effect/Schema").brand<import("effect/Schema").String, "Plugin.ID">;
    revision: import("effect/Schema").String;
    ticket: import("effect/Schema").String;
}>>, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Uint8Array>, import("effect/Schema").toCodecJson<typeof import("../errors.js").LocationNotFoundError | typeof import("../errors.js").PluginNotFoundError | typeof import("../errors.js").ForbiddenError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"schedule.create", "POST", "/api/experimental/schedule", never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
    readonly when: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
        readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly in: import("effect/Schema").String;
        readonly at: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly every: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly cron: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>, import("effect/Schema").Struct<{
        readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly at: import("effect/Schema").String;
        readonly in: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly every: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly cron: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>, import("effect/Schema").Struct<{
        readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly every: import("effect/Schema").String;
        readonly in: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly at: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly cron: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>, import("effect/Schema").Struct<{
        readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly cron: import("effect/Schema").String;
        readonly in: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly at: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly every: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
        readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly in: import("effect/Schema").String;
        readonly at: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly every: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly cron: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>, import("effect/Schema").Struct<{
        readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly at: import("effect/Schema").String;
        readonly in: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly every: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly cron: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>, import("effect/Schema").Struct<{
        readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly every: import("effect/Schema").String;
        readonly in: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly at: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly cron: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>, import("effect/Schema").Struct<{
        readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly cron: import("effect/Schema").String;
        readonly in: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly at: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly every: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>]>>, never, never>;
    readonly if: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
        readonly run: import("effect/Schema").String;
        readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        readonly code: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>, import("effect/Schema").Struct<{
        readonly code: import("effect/Schema").String;
        readonly run: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly is: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly matches: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly changes: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
        readonly run: import("effect/Schema").String;
        readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        readonly code: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>, import("effect/Schema").Struct<{
        readonly code: import("effect/Schema").String;
        readonly run: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly is: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly matches: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly changes: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>]>>, never, never>;
    readonly until: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
        readonly run: import("effect/Schema").String;
        readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        readonly code: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>, import("effect/Schema").Struct<{
        readonly code: import("effect/Schema").String;
        readonly run: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly is: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly matches: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly changes: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
        readonly run: import("effect/Schema").String;
        readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        readonly code: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>, import("effect/Schema").Struct<{
        readonly code: import("effect/Schema").String;
        readonly run: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly is: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly matches: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
        readonly changes: import("effect/Schema").optionalKey<import("effect/Schema").Never>;
    }>]>>, never, never>;
    readonly ends: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly after: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly at: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly times: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly after: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly at: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly times: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
    }>>, never, never>;
    readonly prompt: import("effect/Schema").String;
    readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Schedule.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
        };
        readonly sessionID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly when: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"in">;
            readonly in: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"at">;
            readonly at: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"every">;
            readonly every: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"cron">;
            readonly cron: import("effect/Schema").String;
        }>]>;
        readonly tz: import("effect/Schema").String;
        readonly if: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly until: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly action: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"prompt">;
            readonly prompt: import("effect/Schema").String;
        }>]>;
        readonly status: import("effect/Schema").Literals<readonly ["active", "paused", "done"]>;
        readonly nextDueAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly endsAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly remainingRuns: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        readonly runCount: import("effect/Schema").Int;
        readonly lastFiredAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly lastOutcome: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>, never, never>;
        readonly lastOutput: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly time: import("effect/Schema").Struct<{
            readonly created: import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>;
            readonly updated: import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>;
        }>;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").InvalidRequestError | typeof import("../errors.js").SessionNotFoundError | typeof import("../errors.js").ForbiddenError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"schedule.delete", "DELETE", "/api/experimental/schedule/:scheduleID", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    scheduleID: import("effect/Schema").brand<import("effect/Schema").String, "Schedule.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
    };
}>>, never, never, never, import("effect/Schema").toCodecJson<import("effect/http-api/HttpApiSchema").NoContent>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ForbiddenError | typeof import("../errors.js").ScheduleNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"schedule.get", "GET", "/api/experimental/schedule/:scheduleID", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    scheduleID: import("effect/Schema").brand<import("effect/Schema").String, "Schedule.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
    };
}>>, never, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Schedule.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
        };
        readonly sessionID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly when: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"in">;
            readonly in: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"at">;
            readonly at: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"every">;
            readonly every: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"cron">;
            readonly cron: import("effect/Schema").String;
        }>]>;
        readonly tz: import("effect/Schema").String;
        readonly if: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly until: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly action: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"prompt">;
            readonly prompt: import("effect/Schema").String;
        }>]>;
        readonly status: import("effect/Schema").Literals<readonly ["active", "paused", "done"]>;
        readonly nextDueAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly endsAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly remainingRuns: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        readonly runCount: import("effect/Schema").Int;
        readonly lastFiredAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly lastOutcome: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>, never, never>;
        readonly lastOutput: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly time: import("effect/Schema").Struct<{
            readonly created: import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>;
            readonly updated: import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>;
        }>;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ForbiddenError | typeof import("../errors.js").ScheduleNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"schedule.list", "GET", "/api/experimental/schedule", never, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").$Array<import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Schedule.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
        };
        readonly sessionID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly when: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"in">;
            readonly in: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"at">;
            readonly at: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"every">;
            readonly every: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"cron">;
            readonly cron: import("effect/Schema").String;
        }>]>;
        readonly tz: import("effect/Schema").String;
        readonly if: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly until: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly action: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"prompt">;
            readonly prompt: import("effect/Schema").String;
        }>]>;
        readonly status: import("effect/Schema").Literals<readonly ["active", "paused", "done"]>;
        readonly nextDueAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly endsAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly remainingRuns: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        readonly runCount: import("effect/Schema").Int;
        readonly lastFiredAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly lastOutcome: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>, never, never>;
        readonly lastOutput: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly time: import("effect/Schema").Struct<{
            readonly created: import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>;
            readonly updated: import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>;
        }>;
    }>>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").SessionNotFoundError | typeof import("../errors.js").ForbiddenError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"schedule.pause", "POST", "/api/experimental/schedule/:scheduleID/pause", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    scheduleID: import("effect/Schema").brand<import("effect/Schema").String, "Schedule.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
    };
}>>, never, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Schedule.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
        };
        readonly sessionID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly when: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"in">;
            readonly in: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"at">;
            readonly at: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"every">;
            readonly every: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"cron">;
            readonly cron: import("effect/Schema").String;
        }>]>;
        readonly tz: import("effect/Schema").String;
        readonly if: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly until: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly action: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"prompt">;
            readonly prompt: import("effect/Schema").String;
        }>]>;
        readonly status: import("effect/Schema").Literals<readonly ["active", "paused", "done"]>;
        readonly nextDueAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly endsAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly remainingRuns: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        readonly runCount: import("effect/Schema").Int;
        readonly lastFiredAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly lastOutcome: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>, never, never>;
        readonly lastOutput: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly time: import("effect/Schema").Struct<{
            readonly created: import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>;
            readonly updated: import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>;
        }>;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ForbiddenError | typeof import("../errors.js").ScheduleNotFoundError>, never, never> | import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"schedule.resume", "POST", "/api/experimental/schedule/:scheduleID/resume", import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    scheduleID: import("effect/Schema").brand<import("effect/Schema").String, "Schedule.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
    };
}>>, never, never, never, import("effect/Schema").toCodecJson<import("effect/Schema").Struct<{
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Schedule.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
        };
        readonly sessionID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly when: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"in">;
            readonly in: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"at">;
            readonly at: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"every">;
            readonly every: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly tz: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly type: import("effect/Schema").tag<"cron">;
            readonly cron: import("effect/Schema").String;
        }>]>;
        readonly tz: import("effect/Schema").String;
        readonly if: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly until: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"shell">;
            readonly run: import("effect/Schema").String;
            readonly is: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly matches: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly changes: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"code">;
            readonly code: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly action: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"prompt">;
            readonly prompt: import("effect/Schema").String;
        }>]>;
        readonly status: import("effect/Schema").Literals<readonly ["active", "paused", "done"]>;
        readonly nextDueAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly endsAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly remainingRuns: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        readonly runCount: import("effect/Schema").Int;
        readonly lastFiredAt: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>>, import("effect/Schema").optionalKey<import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>>, never, never>;
        readonly lastOutcome: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>, never, never>;
        readonly lastOutput: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly time: import("effect/Schema").Struct<{
            readonly created: import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>;
            readonly updated: import("effect/Schema").decodeTo<import("effect/Schema").DateTimeUtc, import("effect/Schema").Finite, never, never>;
        }>;
    }>;
}>>, import("effect/Schema").toCodecJson<typeof import("../errors.js").ForbiddenError | typeof import("../errors.js").ScheduleNotFoundError>, never, never>, false>;
