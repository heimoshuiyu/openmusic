import { Schema } from "effect";
import { HttpApiEndpoint } from "effect/http-api";
import { InvalidRequestError, SessionNotFoundError } from "../errors.js";
export declare const ListQuery: Schema.Struct<{
    readonly sessionID: Schema.optional<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>;
    readonly kind: Schema.optional<Schema.Literals<readonly ["shell", "subagent", "image"]>>;
    readonly status: Schema.optional<Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>>;
    readonly descendants: Schema.optional<Schema.decodeTo<Schema.Boolean, Schema.Literals<readonly ["true", "false"]>, never, never>>;
}>;
export type ListQuery = typeof ListQuery.Type;
/** Lives in the `server.experimental` group (see `groups/experimental.ts`). */
export declare const JobEndpoints: readonly [HttpApiEndpoint.HttpApiEndpoint<"job.list", "GET", "/api/experimental/job", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly sessionID: Schema.optional<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>;
    readonly kind: Schema.optional<Schema.Literals<readonly ["shell", "subagent", "image"]>>;
    readonly status: Schema.optional<Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>>;
    readonly descendants: Schema.optional<Schema.decodeTo<Schema.Boolean, Schema.Literals<readonly ["true", "false"]>, never, never>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly id: Schema.String;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly time: Schema.Struct<{
            readonly started: Schema.Finite;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>;
        readonly kind: Schema.tag<"shell">;
        readonly shellID: Schema.String;
        readonly command: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.String;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly time: Schema.Struct<{
            readonly started: Schema.Finite;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>;
        readonly kind: Schema.tag<"subagent">;
        readonly childSessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly agent: Schema.String;
        readonly description: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.String;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly time: Schema.Struct<{
            readonly started: Schema.Finite;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>;
        readonly kind: Schema.tag<"image">;
        readonly path: Schema.String;
        readonly model: Schema.String;
    }>]>>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof SessionNotFoundError>, never, never>];
