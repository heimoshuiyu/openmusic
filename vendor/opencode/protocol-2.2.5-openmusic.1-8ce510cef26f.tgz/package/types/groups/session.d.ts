import { Session } from "@opencode/schema/session";
import { InstructionEntry } from "@opencode/schema/instruction-entry";
import { Context, Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiMiddleware, HttpApiSchema } from "effect/http-api";
import { ConflictError, LocationNotFoundError, CommandExecutionError, CommandNotFoundError, FormAlreadySettledError, FormInvalidAnswerError, FormNotFoundError, InvalidCursorError, InvalidRequestError, MessageNotFoundError, ServiceUnavailableError, SessionBusyError, SessionNotFoundError, SkillNotFoundError, UnknownError } from "../errors.js";
/** Experimental: the `session.inbox.list` response for clients that opt into `experimental-media-uri`. */
export declare const SessionMediaInboxResponse: Schema.Struct<{
    readonly data: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"user">;
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly payload: Schema.Struct<{
            readonly text: Schema.String;
            readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly name: Schema.String;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly name: Schema.String;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>, never, never>;
            readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Skill.ID">;
                readonly name: Schema.brand<Schema.String, "Skill.Name">;
                readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Skill.ID">;
                readonly name: Schema.brand<Schema.String, "Skill.Name">;
                readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>, never, never>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                readonly data: Schema.String;
                readonly mime: Schema.String;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"inline">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"uri">;
                    readonly uri: Schema.String;
                }>]>;
                readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }> & {
                create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                    readonly data: string;
                    readonly mime: string;
                    readonly source: {
                        readonly type: "inline";
                    } | {
                        readonly type: "uri";
                        readonly uri: string;
                    };
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                };
            }, Schema.Struct<{
                readonly mime: Schema.String;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"inline">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"uri">;
                    readonly uri: Schema.String;
                }>]>;
                readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
                readonly uri: Schema.String;
                readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>]>>>>, Schema.optionalKey<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                readonly data: Schema.String;
                readonly mime: Schema.String;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"inline">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"uri">;
                    readonly uri: Schema.String;
                }>]>;
                readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }> & {
                create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                    readonly data: string;
                    readonly mime: string;
                    readonly source: {
                        readonly type: "inline";
                    } | {
                        readonly type: "uri";
                        readonly uri: string;
                    };
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                };
            }, Schema.Struct<{
                readonly mime: Schema.String;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"inline">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"uri">;
                    readonly uri: Schema.String;
                }>]>;
                readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
                readonly uri: Schema.String;
                readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>]>>>, never, never>;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"synthetic">;
        readonly payload: Schema.Struct<{
            readonly text: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>;
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"compaction">;
        readonly payload: Schema.Struct<{}>;
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"move">;
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly payload: Schema.Struct<{
            readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            };
            readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
            readonly location: Schema.Struct<{
                readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            }>;
        }>;
    }>]>>;
}>;
export declare const SessionsCursor: Schema.brand<Schema.String, "SessionsCursor"> & {
    make: (input: {
        readonly order?: "asc" | "desc" | undefined;
        readonly search?: string | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
        readonly archived?: boolean | undefined;
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly anchor: {
            readonly id: string & import("effect/Brand").Brand<"SessionID">;
            readonly time: number;
            readonly direction: "next" | "previous";
        };
    } | {
        readonly order?: "asc" | "desc" | undefined;
        readonly search?: string | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
        readonly archived?: boolean | undefined;
        readonly project: string & import("effect/Brand").Brand<"Project.ID">;
        readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
        readonly anchor: {
            readonly id: string & import("effect/Brand").Brand<"SessionID">;
            readonly time: number;
            readonly direction: "next" | "previous";
        };
    } | {
        readonly order?: "asc" | "desc" | undefined;
        readonly search?: string | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
        readonly archived?: boolean | undefined;
        readonly anchor: {
            readonly id: string & import("effect/Brand").Brand<"SessionID">;
            readonly time: number;
            readonly direction: "next" | "previous";
        };
    }) => string & import("effect/Brand").Brand<"SessionsCursor">;
    parse: (input: string) => import("effect/Effect").Effect<{
        readonly order?: "asc" | "desc" | undefined;
        readonly search?: string | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
        readonly archived?: boolean | undefined;
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly anchor: {
            readonly id: string & import("effect/Brand").Brand<"SessionID">;
            readonly time: number;
            readonly direction: "next" | "previous";
        };
    } | {
        readonly order?: "asc" | "desc" | undefined;
        readonly search?: string | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
        readonly archived?: boolean | undefined;
        readonly project: string & import("effect/Brand").Brand<"Project.ID">;
        readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
        readonly anchor: {
            readonly id: string & import("effect/Brand").Brand<"SessionID">;
            readonly time: number;
            readonly direction: "next" | "previous";
        };
    } | {
        readonly order?: "asc" | "desc" | undefined;
        readonly search?: string | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
        readonly archived?: boolean | undefined;
        readonly anchor: {
            readonly id: string & import("effect/Brand").Brand<"SessionID">;
            readonly time: number;
            readonly direction: "next" | "previous";
        };
    }, "Invalid cursor", never>;
};
export type SessionsCursor = Session.ListCursor;
export declare const SessionsQuery: Schema.Struct<{
    readonly order: Schema.optional<Schema.Literals<readonly ["asc", "desc"]>>;
    readonly search: Schema.optional<Schema.String>;
    readonly parentID: Schema.optional<Schema.Union<readonly [Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }, Schema.decodeTo<Schema.Null, Schema.Literal<"null">, never, never>]>>;
    readonly archived: Schema.optional<Schema.decodeTo<Schema.Boolean, Schema.Literals<readonly ["true", "false"]>, never, never>>;
    readonly directory: Schema.optional<Schema.brand<Schema.String, "AbsolutePath">>;
    readonly project: Schema.optional<Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    }>;
    readonly subpath: Schema.optional<Schema.brand<Schema.String, "RelativePath">>;
    readonly limit: Schema.optional<Schema.compose<Schema.Int, Schema.NumberFromString>>;
    readonly cursor: Schema.optional<Schema.brand<Schema.String, "SessionsCursor"> & {
        make: (input: {
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        } | {
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly project: string & import("effect/Brand").Brand<"Project.ID">;
            readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        } | {
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        }) => string & import("effect/Brand").Brand<"SessionsCursor">;
        parse: (input: string) => import("effect/Effect").Effect<{
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        } | {
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly project: string & import("effect/Brand").Brand<"Project.ID">;
            readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        } | {
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        }, "Invalid cursor", never>;
    }>;
}>;
export declare const makeSessionGroup: <I extends HttpApiMiddleware.AnyId, S, FormI extends HttpApiMiddleware.AnyId, FormS>(sessionLocationMiddleware: Context.Key<I, S>, formLocationMiddleware: Context.Key<FormI, FormS>) => HttpApiGroup.HttpApiGroup<"server.session", HttpApiEndpoint.HttpApiEndpoint<"session.active", "GET", "/api/session/active", never, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Record<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }, Schema.Struct<{
        readonly type: Schema.Literal<"running">;
    }>>;
}>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.background", "POST", "/api/session/:sessionID/background", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.command", "POST", "/api/session/:sessionID/command", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly text: Schema.String;
    readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly uri: Schema.String;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly uri: Schema.String;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly name: Schema.String;
    readonly delivery: Schema.optional<Schema.Literals<readonly ["steer", "queue"]>>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError | typeof CommandNotFoundError | typeof CommandExecutionError>, I, HttpApiMiddleware.Requires<I>> | HttpApiEndpoint.HttpApiEndpoint<"session.compact", "POST", "/api/session/:sessionID/compact", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly id: Schema.optional<Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    }>;
    readonly delivery: Schema.optional<Schema.Literals<readonly ["steer", "queue"]>>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly type: Schema.tag<"compaction">;
        readonly payload: Schema.Struct<{}>;
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof ConflictError | typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.context", "GET", "/api/session/:sessionID/context", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"agent-switched">;
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"model-switched">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"location-switched">;
        readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        }>;
        readonly previous: Schema.optional<Schema.Struct<{
            readonly location: Schema.Struct<{
                readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            }>;
            readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>, never, never>;
            readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        }>>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly text: Schema.String;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>, never, never>;
        readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly type: Schema.tag<"user">;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"synthetic">;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"system">;
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"skill">;
        readonly skill: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.tag<"shell">;
        readonly shellID: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly command: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
        readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.tag<"assistant">;
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly content: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
            readonly type: Schema.tag<"text">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"reasoning">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"tool">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
                readonly status: Schema.tag<"streaming">;
                readonly input: Schema.String;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"running">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"completed">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"error">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly error: Schema.Struct<{
                    readonly type: Schema.String;
                    readonly message: Schema.String;
                    readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>, never, never>;
                    readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }>;
                readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>]>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>;
        }>]>>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
        }>>, never, never>;
        readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>>, Schema.optionalKey<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>, never, never>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>, never, never>;
        readonly retry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly attempt: Schema.Int;
            readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly attempt: Schema.Int;
            readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly streamed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
    }>, Schema.Union<readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly status: Schema.tag<"running">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly summary: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly status: Schema.tag<"completed">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly summary: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly status: Schema.tag<"failed">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>]>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"idle">;
        readonly outcome: Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>;
        readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>, never, never>;
    }>]>>;
}>>, Schema.toCodecJson<typeof UnknownError | typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.create", "POST", "/api/session", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly id: Schema.optional<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>;
    readonly parentID: Schema.optional<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>;
    readonly title: Schema.optional<Schema.String>;
    readonly agent: Schema.optional<Schema.brand<Schema.String, "Agent.ID">>;
    readonly model: Schema.optional<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>;
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>;
    readonly permissions: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly action: Schema.String;
        readonly resource: Schema.String;
        readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
    }>>>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly fork: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>, never, never>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly outcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>>, Schema.optionalKey<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly busy: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly idle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly viewed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>, never, never>;
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.diff", "GET", "/api/session/:sessionID/diff", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly from: Schema.optional<Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    }>;
    readonly to: Schema.optional<Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    }>;
    readonly context: Schema.optional<Schema.compose<Schema.Int, Schema.NumberFromString>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Struct<{
        readonly file: Schema.String;
        readonly patch: Schema.String;
        readonly additions: Schema.Int;
        readonly deletions: Schema.Int;
        readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
        readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
    }>>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof InvalidRequestError | typeof UnknownError | typeof SessionNotFoundError | typeof MessageNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.environment", "PUT", "/api/session/:sessionID/environment", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly variables: Schema.$Record<Schema.String, Schema.String>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.export", "GET", "/api/experimental/session/:sessionID/export", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly sanitize: Schema.optional<Schema.decodeTo<Schema.Boolean, Schema.Literals<readonly ["true", "false"]>, never, never>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            }>, never, never>;
            readonly fork: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly boundary: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"before">;
                    readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    };
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"through">;
                    readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    };
                }>]>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly boundary: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"before">;
                    readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    };
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"through">;
                    readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    };
                }>]>;
            }>>, never, never>;
            readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            };
            readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
            }> & {
                parse: (input: string) => {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
            }>>, Schema.optionalKey<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
            }> & {
                parse: (input: string) => {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
            }>, never, never>;
            readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
                zero: number & import("effect/Brand").Brand<"Money.USD">;
            };
            readonly tokens: Schema.Struct<{
                readonly input: Schema.Finite;
                readonly output: Schema.Finite;
                readonly reasoning: Schema.Finite;
                readonly cache: Schema.Struct<{
                    readonly read: Schema.Finite;
                    readonly write: Schema.Finite;
                }>;
            }>;
            readonly outcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>>, Schema.optionalKey<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly busy: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                readonly idle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                readonly viewed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly action: Schema.String;
                readonly resource: Schema.String;
                readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly action: Schema.String;
                readonly resource: Schema.String;
                readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
            }>>>, never, never>;
            readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
                readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
                readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly file: Schema.String;
                    readonly patch: Schema.String;
                    readonly additions: Schema.Int;
                    readonly deletions: Schema.Int;
                    readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                    readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly file: Schema.String;
                    readonly patch: Schema.String;
                    readonly additions: Schema.Int;
                    readonly deletions: Schema.Int;
                    readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                    readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
                }>>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
                readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
                readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly file: Schema.String;
                    readonly patch: Schema.String;
                    readonly additions: Schema.Int;
                    readonly deletions: Schema.Int;
                    readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                    readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly file: Schema.String;
                    readonly patch: Schema.String;
                    readonly additions: Schema.Int;
                    readonly deletions: Schema.Int;
                    readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                    readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
                }>>>, never, never>;
            }>>, never, never>;
            readonly location: Schema.Struct<{
                readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            }>;
        }>;
        readonly messages: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            }>;
            readonly type: Schema.tag<"agent-switched">;
            readonly agent: Schema.brand<Schema.String, "Agent.ID">;
            readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            }>;
            readonly type: Schema.tag<"model-switched">;
            readonly model: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
            }> & {
                parse: (input: string) => {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
            };
            readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
            }> & {
                parse: (input: string) => {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
            }>>, Schema.optionalKey<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
            }> & {
                parse: (input: string) => {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
            }>, never, never>;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            }>;
            readonly type: Schema.tag<"location-switched">;
            readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>, never, never>;
            readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
            readonly location: Schema.Struct<{
                readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            }>;
            readonly previous: Schema.optional<Schema.Struct<{
                readonly location: Schema.Struct<{
                    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
                }>;
                readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                }>, never, never>;
                readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
            }>>;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            }>;
            readonly text: Schema.String;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly data: Schema.String;
                readonly mime: Schema.String;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"inline">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"uri">;
                    readonly uri: Schema.String;
                }>]>;
                readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }> & {
                create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                    readonly data: string;
                    readonly mime: string;
                    readonly source: {
                        readonly type: "inline";
                    } | {
                        readonly type: "uri";
                        readonly uri: string;
                    };
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                };
            }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly data: Schema.String;
                readonly mime: Schema.String;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"inline">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"uri">;
                    readonly uri: Schema.String;
                }>]>;
                readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }> & {
                create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                    readonly data: string;
                    readonly mime: string;
                    readonly source: {
                        readonly type: "inline";
                    } | {
                        readonly type: "uri";
                        readonly uri: string;
                    };
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                };
            }>>, never, never>;
            readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly name: Schema.String;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly name: Schema.String;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>, never, never>;
            readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Skill.ID">;
                readonly name: Schema.brand<Schema.String, "Skill.Name">;
                readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Skill.ID">;
                readonly name: Schema.brand<Schema.String, "Skill.Name">;
                readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>, never, never>;
            readonly type: Schema.tag<"user">;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            }>;
            readonly text: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"synthetic">;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            }>;
            readonly type: Schema.tag<"system">;
            readonly text: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            }>;
            readonly type: Schema.tag<"skill">;
            readonly skill: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly type: Schema.tag<"shell">;
            readonly shellID: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly command: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly output: Schema.String;
                readonly cursor: Schema.Int;
                readonly size: Schema.Int;
                readonly truncated: Schema.Boolean;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly output: Schema.String;
                readonly cursor: Schema.Int;
                readonly size: Schema.Int;
                readonly truncated: Schema.Boolean;
            }>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly type: Schema.tag<"assistant">;
            readonly agent: Schema.brand<Schema.String, "Agent.ID">;
            readonly model: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
            }> & {
                parse: (input: string) => {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
            };
            readonly content: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
                readonly type: Schema.tag<"text">;
                readonly text: Schema.String;
                readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"reasoning">;
                readonly text: Schema.String;
                readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
                readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                    readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                    readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                }>>, never, never>;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"tool">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
                readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
                    readonly status: Schema.tag<"streaming">;
                    readonly input: Schema.String;
                }>, Schema.Struct<{
                    readonly status: Schema.tag<"running">;
                    readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                    readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
                }>, Schema.Struct<{
                    readonly status: Schema.tag<"completed">;
                    readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                    readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"text">;
                        readonly text: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"file">;
                        readonly uri: Schema.String;
                        readonly mime: Schema.String;
                        readonly name: Schema.optional<Schema.String>;
                    }>]>>;
                    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
                }>, Schema.Struct<{
                    readonly status: Schema.tag<"error">;
                    readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                    readonly error: Schema.Struct<{
                        readonly type: Schema.String;
                        readonly message: Schema.String;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                            readonly body: Schema.String;
                        }>>>, Schema.optionalKey<Schema.Struct<{
                            readonly body: Schema.String;
                        }>>, never, never>;
                        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    }>;
                    readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"text">;
                        readonly text: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"file">;
                        readonly uri: Schema.String;
                        readonly mime: Schema.String;
                        readonly name: Schema.optional<Schema.String>;
                    }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"text">;
                        readonly text: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"file">;
                        readonly uri: Schema.String;
                        readonly mime: Schema.String;
                        readonly name: Schema.optional<Schema.String>;
                    }>]>>>, never, never>;
                    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
                }>]>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                    readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                    readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                }>;
            }>]>>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
                readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
                readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
                readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
                readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
            }>>, never, never>;
            readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>>, Schema.optionalKey<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>, never, never>;
            readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
                zero: number & import("effect/Brand").Brand<"Money.USD">;
            }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
                zero: number & import("effect/Brand").Brand<"Money.USD">;
            }>, never, never>;
            readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly input: Schema.Finite;
                readonly output: Schema.Finite;
                readonly reasoning: Schema.Finite;
                readonly cache: Schema.Struct<{
                    readonly read: Schema.Finite;
                    readonly write: Schema.Finite;
                }>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly input: Schema.Finite;
                readonly output: Schema.Finite;
                readonly reasoning: Schema.Finite;
                readonly cache: Schema.Struct<{
                    readonly read: Schema.Finite;
                    readonly write: Schema.Finite;
                }>;
            }>>, never, never>;
            readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>, never, never>;
            readonly retry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly attempt: Schema.Int;
                readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly error: Schema.Struct<{
                    readonly type: Schema.String;
                    readonly message: Schema.String;
                    readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>, never, never>;
                    readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly attempt: Schema.Int;
                readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly error: Schema.Struct<{
                    readonly type: Schema.String;
                    readonly message: Schema.String;
                    readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>, never, never>;
                    readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }>;
            }>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly streamed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>;
        }>, Schema.Union<readonly [Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            }>;
            readonly type: Schema.tag<"compaction">;
            readonly status: Schema.tag<"running">;
            readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
            readonly summary: Schema.String;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            }>;
            readonly type: Schema.tag<"compaction">;
            readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
                zero: number & import("effect/Brand").Brand<"Money.USD">;
            }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
                zero: number & import("effect/Brand").Brand<"Money.USD">;
            }>, never, never>;
            readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly input: Schema.Finite;
                readonly output: Schema.Finite;
                readonly reasoning: Schema.Finite;
                readonly cache: Schema.Struct<{
                    readonly read: Schema.Finite;
                    readonly write: Schema.Finite;
                }>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly input: Schema.Finite;
                readonly output: Schema.Finite;
                readonly reasoning: Schema.Finite;
                readonly cache: Schema.Struct<{
                    readonly read: Schema.Finite;
                    readonly write: Schema.Finite;
                }>;
            }>>, never, never>;
            readonly status: Schema.tag<"completed">;
            readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
            }> & {
                parse: (input: string) => {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
            }>>, Schema.optionalKey<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
            }> & {
                parse: (input: string) => {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
            }>, never, never>;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly summary: Schema.String;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            }>;
            readonly type: Schema.tag<"compaction">;
            readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
                zero: number & import("effect/Brand").Brand<"Money.USD">;
            }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
                zero: number & import("effect/Brand").Brand<"Money.USD">;
            }>, never, never>;
            readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly input: Schema.Finite;
                readonly output: Schema.Finite;
                readonly reasoning: Schema.Finite;
                readonly cache: Schema.Struct<{
                    readonly read: Schema.Finite;
                    readonly write: Schema.Finite;
                }>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly input: Schema.Finite;
                readonly output: Schema.Finite;
                readonly reasoning: Schema.Finite;
                readonly cache: Schema.Struct<{
                    readonly read: Schema.Finite;
                    readonly write: Schema.Finite;
                }>;
            }>>, never, never>;
            readonly status: Schema.tag<"failed">;
            readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
        }>]>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            }>;
            readonly type: Schema.tag<"idle">;
            readonly outcome: Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>;
            readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>, never, never>;
        }>]>>;
    }>;
}>>, Schema.toCodecJson<typeof UnknownError | typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.fork", "POST", "/api/session/:sessionID/fork", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly before: Schema.optional<Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    }>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly fork: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>, never, never>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly outcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>>, Schema.optionalKey<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly busy: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly idle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly viewed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>, never, never>;
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof SessionNotFoundError | typeof MessageNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.form.cancel", "DELETE", "/api/session/:sessionID/form/:formID", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.String;
    formID: Schema.brand<Schema.String, "Form.ID"> & {
        create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly message: Schema.optional<Schema.String>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError | typeof FormNotFoundError | typeof FormAlreadySettledError>, FormI, HttpApiMiddleware.Requires<FormI>> | HttpApiEndpoint.HttpApiEndpoint<"session.form.create", "POST", "/api/session/:sessionID/form", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.String;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly id: Schema.optional<Schema.brand<Schema.String, "Form.ID"> & {
        create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
    }>;
    readonly title: Schema.String;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: Schema.String;
        readonly title: Schema.String;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"string">;
            readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
            readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"number">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"integer">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"boolean">;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"multiselect">;
            readonly options: Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>;
            readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly type: Schema.Literal<"external">;
            readonly url: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof ConflictError | typeof SessionNotFoundError>, FormI, HttpApiMiddleware.Requires<FormI>> | HttpApiEndpoint.HttpApiEndpoint<"session.form.get", "GET", "/api/session/:sessionID/form/:formID", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.String;
    formID: Schema.brand<Schema.String, "Form.ID"> & {
        create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: Schema.String;
        readonly title: Schema.String;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"string">;
            readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
            readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"number">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"integer">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"boolean">;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"multiselect">;
            readonly options: Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>;
            readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly type: Schema.Literal<"external">;
            readonly url: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>;
        readonly state: Schema.Union<readonly [Schema.Struct<{
            readonly status: Schema.Literal<"pending">;
        }>, Schema.Struct<{
            readonly status: Schema.Literal<"answered">;
            readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
        }>, Schema.Struct<{
            readonly status: Schema.Literal<"cancelled">;
            readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>;
    }>;
}>>, Schema.toCodecJson<typeof SessionNotFoundError | typeof FormNotFoundError>, FormI, HttpApiMiddleware.Requires<FormI>> | HttpApiEndpoint.HttpApiEndpoint<"session.form.list", "GET", "/api/session/:sessionID/form", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: Schema.String;
        readonly title: Schema.String;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"string">;
            readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
            readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"number">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"integer">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"boolean">;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"multiselect">;
            readonly options: Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>;
            readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly type: Schema.Literal<"external">;
            readonly url: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>;
    }>>;
}>>, Schema.toCodecJson<typeof SessionNotFoundError>, FormI, HttpApiMiddleware.Requires<FormI>> | HttpApiEndpoint.HttpApiEndpoint<"session.form.reply", "POST", "/api/session/:sessionID/form/:formID/reply", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.String;
    formID: Schema.brand<Schema.String, "Form.ID"> & {
        create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError | typeof FormNotFoundError | typeof FormAlreadySettledError | typeof FormInvalidAnswerError>, FormI, HttpApiMiddleware.Requires<FormI>> | HttpApiEndpoint.HttpApiEndpoint<"session.generate", "POST", "/api/session/:sessionID/generate", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly prompt: Schema.String;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly text: Schema.String;
    }>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError | typeof SessionNotFoundError>, I, HttpApiMiddleware.Requires<I>> | HttpApiEndpoint.HttpApiEndpoint<"session.get", "GET", "/api/session/:sessionID", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly fork: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>, never, never>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly outcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>>, Schema.optionalKey<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly busy: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly idle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly viewed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>, never, never>;
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.import", "POST", "/api/experimental/session/import", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly info: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly fork: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>, never, never>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly outcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>>, Schema.optionalKey<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly busy: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly idle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly viewed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>, never, never>;
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        }>;
    }>;
    readonly messages: Schema.decodeTo<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"agent-switched">;
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"model-switched">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"location-switched">;
        readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        }>;
        readonly previous: Schema.optional<Schema.Struct<{
            readonly location: Schema.Struct<{
                readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            }>;
            readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>, never, never>;
            readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        }>>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly text: Schema.String;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>, never, never>;
        readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly type: Schema.tag<"user">;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"synthetic">;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"system">;
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"skill">;
        readonly skill: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.tag<"shell">;
        readonly shellID: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly command: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
        readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.tag<"assistant">;
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly content: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
            readonly type: Schema.tag<"text">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"reasoning">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"tool">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
                readonly status: Schema.tag<"streaming">;
                readonly input: Schema.String;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"running">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"completed">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"error">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly error: Schema.Struct<{
                    readonly type: Schema.String;
                    readonly message: Schema.String;
                    readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>, never, never>;
                    readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }>;
                readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>]>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>;
        }>]>>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
        }>>, never, never>;
        readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>>, Schema.optionalKey<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>, never, never>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>, never, never>;
        readonly retry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly attempt: Schema.Int;
            readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly attempt: Schema.Int;
            readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly streamed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
    }>, Schema.Union<readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly status: Schema.tag<"running">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly summary: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly status: Schema.tag<"completed">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly summary: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly status: Schema.tag<"failed">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>]>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"idle">;
        readonly outcome: Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>;
        readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>, never, never>;
    }>]>>, Schema.decodeTo<Schema.$Array<Schema.Unknown>, Schema.$Array<Schema.Codec<Schema.Json, Schema.Json, never, never>>, never, never>, never, never>;
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly fork: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>, never, never>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly outcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>>, Schema.optionalKey<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly busy: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly idle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly viewed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>, never, never>;
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof ConflictError | typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.inbox.cancel", "DELETE", "/api/session/:sessionID/inbox/:inboxID", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.inbox.list", "GET", "/api/session/:sessionID/inbox", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"user">;
        readonly payload: Schema.Struct<{
            readonly text: Schema.String;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly data: Schema.String;
                readonly mime: Schema.String;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"inline">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"uri">;
                    readonly uri: Schema.String;
                }>]>;
                readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }> & {
                create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                    readonly data: string;
                    readonly mime: string;
                    readonly source: {
                        readonly type: "inline";
                    } | {
                        readonly type: "uri";
                        readonly uri: string;
                    };
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                };
            }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly data: Schema.String;
                readonly mime: Schema.String;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"inline">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"uri">;
                    readonly uri: Schema.String;
                }>]>;
                readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }> & {
                create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                    readonly data: string;
                    readonly mime: string;
                    readonly source: {
                        readonly type: "inline";
                    } | {
                        readonly type: "uri";
                        readonly uri: string;
                    };
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                };
            }>>, never, never>;
            readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly name: Schema.String;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly name: Schema.String;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>, never, never>;
            readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Skill.ID">;
                readonly name: Schema.brand<Schema.String, "Skill.Name">;
                readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Skill.ID">;
                readonly name: Schema.brand<Schema.String, "Skill.Name">;
                readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>, never, never>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>;
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"synthetic">;
        readonly payload: Schema.Struct<{
            readonly text: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>;
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"compaction">;
        readonly payload: Schema.Struct<{}>;
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"move">;
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly payload: Schema.Struct<{
            readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            };
            readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
            readonly location: Schema.Struct<{
                readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            }>;
        }>;
    }>]>>;
}>>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.inbox.update", "PATCH", "/api/session/:sessionID/inbox/:inboxID", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof ConflictError | typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.instructions.entry.list", "GET", "/api/experimental/session/:sessionID/instructions/entries", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    }>>;
}>>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.instructions.entry.put", "PUT", "/api/experimental/session/:sessionID/instructions/entries/:key", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    key: Schema.String;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError | typeof InstructionEntry.ValueTooLargeError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.instructions.entry.remove", "DELETE", "/api/experimental/session/:sessionID/instructions/entries/:key", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    key: Schema.String;
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.interrupt", "POST", "/api/session/:sessionID/interrupt", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    resume: Schema.optional<Schema.decodeTo<Schema.Boolean, Schema.Literals<readonly ["true", "false"]>, never, never>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly interrupted: Schema.Boolean;
}>>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.list", "GET", "/api/session", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly order: Schema.optional<Schema.Literals<readonly ["asc", "desc"]>>;
    readonly search: Schema.optional<Schema.String>;
    readonly parentID: Schema.optional<Schema.Union<readonly [Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }, Schema.decodeTo<Schema.Null, Schema.Literal<"null">, never, never>]>>;
    readonly archived: Schema.optional<Schema.decodeTo<Schema.Boolean, Schema.Literals<readonly ["true", "false"]>, never, never>>;
    readonly directory: Schema.optional<Schema.brand<Schema.String, "AbsolutePath">>;
    readonly project: Schema.optional<Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    }>;
    readonly subpath: Schema.optional<Schema.brand<Schema.String, "RelativePath">>;
    readonly limit: Schema.optional<Schema.compose<Schema.Int, Schema.NumberFromString>>;
    readonly cursor: Schema.optional<Schema.brand<Schema.String, "SessionsCursor"> & {
        make: (input: {
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        } | {
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly project: string & import("effect/Brand").Brand<"Project.ID">;
            readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        } | {
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        }) => string & import("effect/Brand").Brand<"SessionsCursor">;
        parse: (input: string) => import("effect/Effect").Effect<{
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        } | {
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly project: string & import("effect/Brand").Brand<"Project.ID">;
            readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        } | {
            readonly order?: "asc" | "desc" | undefined;
            readonly search?: string | undefined;
            readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
            readonly archived?: boolean | undefined;
            readonly anchor: {
                readonly id: string & import("effect/Brand").Brand<"SessionID">;
                readonly time: number;
                readonly direction: "next" | "previous";
            };
        }, "Invalid cursor", never>;
    }>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly fork: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>, never, never>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly outcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>>, Schema.optionalKey<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly busy: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly idle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly viewed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>, never, never>;
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        }>;
    }>>;
    readonly cursor: Schema.Struct<{
        readonly previous: Schema.optional<Schema.brand<Schema.String, "SessionsCursor"> & {
            make: (input: {
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            } | {
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly project: string & import("effect/Brand").Brand<"Project.ID">;
                readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            } | {
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            }) => string & import("effect/Brand").Brand<"SessionsCursor">;
            parse: (input: string) => import("effect/Effect").Effect<{
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            } | {
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly project: string & import("effect/Brand").Brand<"Project.ID">;
                readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            } | {
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            }, "Invalid cursor", never>;
        }>;
        readonly next: Schema.optional<Schema.brand<Schema.String, "SessionsCursor"> & {
            make: (input: {
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            } | {
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly project: string & import("effect/Brand").Brand<"Project.ID">;
                readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            } | {
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            }) => string & import("effect/Brand").Brand<"SessionsCursor">;
            parse: (input: string) => import("effect/Effect").Effect<{
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            } | {
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly project: string & import("effect/Brand").Brand<"Project.ID">;
                readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            } | {
                readonly order?: "asc" | "desc" | undefined;
                readonly search?: string | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
                readonly archived?: boolean | undefined;
                readonly anchor: {
                    readonly id: string & import("effect/Brand").Brand<"SessionID">;
                    readonly time: number;
                    readonly direction: "next" | "previous";
                };
            }, "Invalid cursor", never>;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof InvalidCursorError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.log", "GET", "/api/experimental/session/:sessionID/log", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    after: Schema.optional<Schema.compose<Schema.brand<Schema.Int, "Event.Seq">, Schema.NumberFromString>>;
    follow: Schema.optional<Schema.decodeTo<Schema.Boolean, Schema.Literals<readonly ["true", "false"]>, never, never>>;
}>>, never, never, HttpApiSchema.StreamSse<HttpApiSchema.SseEventFromData<Schema.Union<readonly [Schema.toTaggedUnion<"type", readonly [...((Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.agent.selected">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
    }>;
}> & {
    type: "session.agent.selected";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.archived">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.archived";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.compaction.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly text: Schema.String;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}> & {
    type: "session.compaction.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly text: Schema.String;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.compaction.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}> & {
    type: "session.compaction.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.compaction.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
    }>;
}> & {
    type: "session.compaction.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.created">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly slug: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly version: Schema.String;
    }>;
}> & {
    type: "session.created";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly slug: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly version: Schema.String;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.deleted">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.deleted";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}> & {
    type: "session.execution.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.interrupted">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["user", "shutdown", "superseded", "inactivity"]>;
    }>;
}> & {
    type: "session.execution.interrupted";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["user", "shutdown", "superseded", "inactivity"]>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.execution.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.succeeded">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.execution.succeeded";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.forked">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly boundary: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"before">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"through">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>]>;
        readonly instructions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>>, Schema.optionalKey<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>, never, never>;
        readonly instructionEntries: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>, never, never>;
    }>;
}> & {
    type: "session.forked";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly boundary: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"before">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"through">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>]>;
        readonly instructions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>>, Schema.optionalKey<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>, never, never>;
        readonly instructionEntries: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.cancelled">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.inbox.cancelled";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.delivered">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.inbox.delivered";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.delivery.changed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    }>;
}> & {
    type: "session.inbox.delivery.changed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.enqueued">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly item: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"user">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>, never, never>;
                readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"synthetic">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"compaction">;
            readonly payload: Schema.Struct<{}>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"move">;
            readonly payload: Schema.Struct<{
                readonly location: Schema.Struct<{
                    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
                    readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>, never, never>;
                }>;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>]>;
    }>;
}> & {
    type: "session.inbox.enqueued";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly item: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"user">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>, never, never>;
                readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"synthetic">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"compaction">;
            readonly payload: Schema.Struct<{}>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"move">;
            readonly payload: Schema.Struct<{
                readonly location: Schema.Struct<{
                    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
                    readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>, never, never>;
                }>;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>]>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.instructions.updated">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly delta: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.brand<Schema.String, "Instruction.Hash">, Schema.Literal<"removed">]>>;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
}> & {
    type: "session.instructions.updated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly delta: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.brand<Schema.String, "Instruction.Hash">, Schema.Literal<"removed">]>>;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.metadata.updated">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>;
}> & {
    type: "session.metadata.updated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.model.selected">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>;
}> & {
    type: "session.model.selected";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.moved">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.moved";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.permissions">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly permissions: Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>;
    }>;
}> & {
    type: "session.permissions";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly permissions: Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.reasoning.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.reasoning.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.reasoning.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.reasoning.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.renamed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly title: Schema.String;
    }>;
}> & {
    type: "session.renamed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly title: Schema.String;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.retry.scheduled">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly attempt: Schema.Int;
        readonly at: Schema.Int;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}> & {
    type: "session.retry.scheduled";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly attempt: Schema.Int;
        readonly at: Schema.Int;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.revert.cleared">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.revert.cleared";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.revert.committed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly to: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.revert.committed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly to: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.revert.staged">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly revert: Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>;
    }>;
}> & {
    type: "session.revert.staged";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly revert: Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.shell.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
        readonly output: Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>;
    }>;
}> & {
    type: "session.shell.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
        readonly output: Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.shell.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
    }>;
}> & {
    type: "session.shell.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.skill.activated">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.String;
    }>;
}> & {
    type: "session.skill.activated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.String;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly finish: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}> & {
    type: "session.step.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly finish: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["content-filter"]>>>, Schema.optionalKey<Schema.Literals<readonly ["content-filter"]>>, never, never>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}> & {
    type: "session.step.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["content-filter"]>>>, Schema.optionalKey<Schema.Literals<readonly ["content-filter"]>>, never, never>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly started: Schema.Int;
    }>;
}> & {
    type: "session.step.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly started: Schema.Int;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.streamed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.step.streamed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.synthetic">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.synthetic";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.text.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.text.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.text.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
    }>;
}> & {
    type: "session.text.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.called">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.called";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.input.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly text: Schema.String;
    }>;
}> & {
    type: "session.tool.input.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly text: Schema.String;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.input.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly name: Schema.String;
    }>;
}> & {
    type: "session.tool.input.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly name: Schema.String;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.success">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.success";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.unarchived">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.unarchived";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}) | (Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.viewed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly idle: Schema.Finite;
    }>;
}> & {
    type: "session.viewed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly idle: Schema.Finite;
    }>;
}))[], Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.usage.recorded">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly source: Schema.Literals<readonly ["title", "compaction"]>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
    }>;
}> & {
    type: "session.usage.recorded";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly source: Schema.Literals<readonly ["title", "compaction"]>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.message.content.updated">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly content: Schema.$Array<Schema.toEncoded<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
            readonly type: Schema.tag<"text">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"reasoning">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"tool">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
                readonly status: Schema.tag<"streaming">;
                readonly input: Schema.String;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"running">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"completed">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"error">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly error: Schema.Struct<{
                    readonly type: Schema.String;
                    readonly message: Schema.String;
                    readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>, never, never>;
                    readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }>;
                readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>]>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>;
        }>]>>>;
    }>;
}> & {
    type: "session.message.content.updated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly content: Schema.$Array<Schema.toEncoded<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
            readonly type: Schema.tag<"text">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"reasoning">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"tool">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
                readonly status: Schema.tag<"streaming">;
                readonly input: Schema.String;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"running">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"completed">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"error">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly error: Schema.Struct<{
                    readonly type: Schema.String;
                    readonly message: Schema.String;
                    readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>, never, never>;
                    readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }>;
                readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>]>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>;
        }>]>>>;
    }>;
}]>, Schema.Struct<{
    readonly type: Schema.Literal<"log.synced">;
    readonly aggregateID: Schema.String;
    readonly seq: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Int, "Event.Seq">>>, Schema.optionalKey<Schema.brand<Schema.Int, "Event.Seq">>, never, never>;
}>]>>, Schema.Never, {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.agent.selected";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly agent: string & import("effect/Brand").Brand<"Agent.ID">;
        readonly previous?: (string & import("effect/Brand").Brand<"Agent.ID">) | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.archived";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "auto" | "manual";
        readonly model?: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        } | undefined;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
        readonly text: string;
        readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "auto" | "manual";
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly inputID?: (string & import("effect/Brand").Brand<"Session.Message.ID">) | undefined;
        readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "auto" | "manual";
        readonly inputID?: (string & import("effect/Brand").Brand<"Session.Message.ID">) | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.created";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
        readonly location: {
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
        };
        readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
        readonly slug: string;
        readonly title?: string | undefined;
        readonly agent?: (string & import("effect/Brand").Brand<"Agent.ID">) | undefined;
        readonly model?: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        } | undefined;
        readonly metadata?: {
            readonly [x: string]: Schema.Json;
        } | undefined;
        readonly permissions?: readonly {
            readonly action: string;
            readonly resource: string;
            readonly effect: "allow" | "ask" | "deny";
        }[] | undefined;
        readonly version: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.deleted";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.interrupted";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "inactivity" | "shutdown" | "superseded" | "user";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.succeeded";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.forked";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly parentID: string & import("effect/Brand").Brand<"SessionID">;
        readonly boundary: {
            readonly type: "before";
            readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        } | {
            readonly type: "through";
            readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly instructions?: {
            readonly [x: string & import("effect/Brand").Brand<"Instruction.Key">]: string & import("effect/Brand").Brand<"Instruction.Hash">;
        } | undefined;
        readonly instructionEntries?: readonly {
            readonly key: string;
            readonly value: Schema.Json;
            readonly removed: boolean;
        }[] | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.cancelled";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.delivered";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.delivery.changed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly delivery: "queue" | "steer";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.enqueued";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly item: {
            readonly type: "user";
            readonly payload: {
                readonly text: string;
                readonly files?: readonly {
                    readonly data: string;
                    readonly mime: string;
                    readonly source: {
                        readonly type: "inline";
                    } | {
                        readonly type: "uri";
                        readonly uri: string;
                    };
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                }[] | undefined;
                readonly agents?: readonly {
                    readonly name: string;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                }[] | undefined;
                readonly skills?: readonly {
                    readonly id: string & import("effect/Brand").Brand<"Skill.ID">;
                    readonly name: string & import("effect/Brand").Brand<"Skill.Name">;
                    readonly text?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                }[] | undefined;
                readonly metadata?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
            readonly delivery: "queue" | "steer";
        } | {
            readonly type: "synthetic";
            readonly payload: {
                readonly text: string;
                readonly description?: string | undefined;
                readonly metadata?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
            readonly delivery: "queue" | "steer";
        } | {
            readonly type: "compaction";
            readonly payload: {};
            readonly delivery: "queue" | "steer";
        } | {
            readonly type: "move";
            readonly payload: {
                readonly location: {
                    readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                    readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
                };
                readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
                readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
            };
            readonly delivery: "queue" | "steer";
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.instructions.updated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly delta: {
            readonly [x: string]: "removed" | (string & import("effect/Brand").Brand<"Instruction.Hash">);
        };
        readonly text?: string | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.message.content.updated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly content: readonly ({
            readonly type: "tool";
            readonly id: string;
            readonly name: string;
            readonly executed?: boolean | undefined;
            readonly native?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly state: {
                readonly status: "streaming";
                readonly input: string;
            } | {
                readonly status: "running";
                readonly input: {
                    readonly [x: string]: unknown;
                };
                readonly metadata: {
                    readonly [x: string]: Schema.Json;
                };
            } | {
                readonly status: "completed";
                readonly input: {
                    readonly [x: string]: unknown;
                };
                readonly content: readonly [{
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                }, ...({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[]];
                readonly metadata?: {
                    readonly [x: string]: Schema.Json;
                } | undefined;
            } | {
                readonly status: "error";
                readonly input: {
                    readonly [x: string]: unknown;
                };
                readonly error: {
                    readonly type: string;
                    readonly message: string;
                    readonly status?: number | undefined;
                    readonly response?: {
                        readonly body: string;
                    } | undefined;
                    readonly retryAfterMs?: number | undefined;
                };
                readonly content?: readonly [{
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                }, ...({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[]] | undefined;
                readonly metadata?: {
                    readonly [x: string]: Schema.Json;
                } | undefined;
            };
            readonly time: {
                readonly created: number;
                readonly ran?: number | undefined;
                readonly completed?: number | undefined;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly native?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | {
            readonly type: "reasoning";
            readonly text: string;
            readonly native?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly time?: {
                readonly created: number;
                readonly completed?: number | undefined;
            } | undefined;
        })[];
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.metadata.updated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly metadata: {
            readonly [x: string]: Schema.Json;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.model.selected";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly model: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
        readonly previous?: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.moved";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly location: {
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
        };
        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
        readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.permissions";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly permissions: readonly {
            readonly action: string;
            readonly resource: string;
            readonly effect: "allow" | "ask" | "deny";
        }[];
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.reasoning.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly text: string;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.reasoning.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.renamed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly title: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.retry.scheduled";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly attempt: number;
        readonly at: number;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.cleared";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.committed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly to: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.staged";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly revert: {
            readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
            readonly partID?: string | undefined;
            readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
            readonly files?: readonly {
                readonly file: string;
                readonly patch: string;
                readonly additions: number;
                readonly deletions: number;
                readonly status: "added" | "deleted" | "modified";
                readonly more?: true | undefined;
            }[] | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.shell.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly shell: {
            readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
            readonly status: "exited" | "killed" | "running" | "timeout";
            readonly command: string;
            readonly cwd: string;
            readonly shell: string;
            readonly file: string;
            readonly pid?: number | undefined;
            readonly exit?: number | undefined;
            readonly signal?: string | undefined;
            readonly metadata: {
                readonly [x: string]: unknown;
            };
            readonly time: {
                readonly started: number;
                readonly completed?: number | undefined;
            };
        };
        readonly output: {
            readonly output: string;
            readonly cursor: number;
            readonly size: number;
            readonly truncated: boolean;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.shell.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly shell: {
            readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
            readonly status: "exited" | "killed" | "running" | "timeout";
            readonly command: string;
            readonly cwd: string;
            readonly shell: string;
            readonly file: string;
            readonly pid?: number | undefined;
            readonly exit?: number | undefined;
            readonly signal?: string | undefined;
            readonly metadata: {
                readonly [x: string]: unknown;
            };
            readonly time: {
                readonly started: number;
                readonly completed?: number | undefined;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.skill.activated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly id: string & import("effect/Brand").Brand<"Skill.ID">;
        readonly name: string & import("effect/Brand").Brand<"Skill.Name">;
        readonly text: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly finish: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly rawFinish?: string | undefined;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
        readonly cost: number & import("effect/Brand").Brand<"Money.USD">;
        readonly tokens: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        };
        readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
        readonly files?: readonly (string & import("effect/Brand").Brand<"RelativePath">)[] | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly finish?: "content-filter" | undefined;
        readonly rawFinish?: string | undefined;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
        readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
        readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
        readonly files?: readonly (string & import("effect/Brand").Brand<"RelativePath">)[] | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly agent: string & import("effect/Brand").Brand<"Agent.ID">;
        readonly model: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
        readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
        readonly started: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.streamed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.synthetic";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly text: string;
        readonly description?: string | undefined;
        readonly metadata?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.text.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly text: string;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.text.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.called";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly input: {
            readonly [x: string]: unknown;
        };
        readonly executed: boolean;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly content?: readonly [{
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        }, ...({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[]] | undefined;
        readonly metadata?: {
            readonly [x: string]: Schema.Json;
        } | undefined;
        readonly executed: boolean;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.input.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly text: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.input.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly name: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.success";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly content: readonly [{
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        }, ...({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[]];
        readonly metadata?: {
            readonly [x: string]: Schema.Json;
        } | undefined;
        readonly executed: boolean;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.unarchived";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.usage.recorded";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly source: "compaction" | "title";
        readonly cost: number & import("effect/Brand").Brand<"Money.USD">;
        readonly tokens: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.viewed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly idle: number;
    };
} | {
    readonly type: "log.synced";
    readonly aggregateID: string;
    readonly seq?: (number & import("effect/Brand").Brand<"Event.Seq">) | undefined;
}>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.message", "GET", "/api/session/:sessionID/message/:messageID", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Union<readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"agent-switched">;
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"model-switched">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"location-switched">;
        readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        }>;
        readonly previous: Schema.optional<Schema.Struct<{
            readonly location: Schema.Struct<{
                readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            }>;
            readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>, never, never>;
            readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        }>>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly text: Schema.String;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>, never, never>;
        readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly type: Schema.tag<"user">;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"synthetic">;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"system">;
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"skill">;
        readonly skill: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.tag<"shell">;
        readonly shellID: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly command: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
        readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.tag<"assistant">;
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly content: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
            readonly type: Schema.tag<"text">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"reasoning">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"tool">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
                readonly status: Schema.tag<"streaming">;
                readonly input: Schema.String;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"running">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"completed">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"error">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly error: Schema.Struct<{
                    readonly type: Schema.String;
                    readonly message: Schema.String;
                    readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>, never, never>;
                    readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }>;
                readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>]>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>;
        }>]>>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
        }>>, never, never>;
        readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>>, Schema.optionalKey<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>, never, never>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>, never, never>;
        readonly retry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly attempt: Schema.Int;
            readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly attempt: Schema.Int;
            readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly streamed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
    }>, Schema.Union<readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly status: Schema.tag<"running">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly summary: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly status: Schema.tag<"completed">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly summary: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly status: Schema.tag<"failed">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>]>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"idle">;
        readonly outcome: Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>;
        readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>, never, never>;
    }>]>;
}>>, Schema.toCodecJson<typeof SessionNotFoundError | typeof MessageNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.move", "POST", "/api/session/:sessionID/move", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    readonly delivery: Schema.optional<Schema.Literals<readonly ["steer", "queue"]>>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof InvalidRequestError | typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.prompt", "POST", "/api/session/:sessionID/prompt", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly text: Schema.String;
    readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly uri: Schema.String;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly uri: Schema.String;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly id: Schema.optional<Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    }>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly delivery: Schema.optional<Schema.Literals<readonly ["steer", "queue"]>>;
    readonly resume: Schema.optional<Schema.Boolean>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly type: Schema.tag<"user">;
        readonly payload: Schema.Struct<{
            readonly text: Schema.String;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly data: Schema.String;
                readonly mime: Schema.String;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"inline">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"uri">;
                    readonly uri: Schema.String;
                }>]>;
                readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }> & {
                create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                    readonly data: string;
                    readonly mime: string;
                    readonly source: {
                        readonly type: "inline";
                    } | {
                        readonly type: "uri";
                        readonly uri: string;
                    };
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                };
            }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly data: Schema.String;
                readonly mime: Schema.String;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"inline">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"uri">;
                    readonly uri: Schema.String;
                }>]>;
                readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }> & {
                create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                    readonly data: string;
                    readonly mime: string;
                    readonly source: {
                        readonly type: "inline";
                    } | {
                        readonly type: "uri";
                        readonly uri: string;
                    };
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                };
            }>>, never, never>;
            readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly name: Schema.String;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly name: Schema.String;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>, never, never>;
            readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Skill.ID">;
                readonly name: Schema.brand<Schema.String, "Skill.Name">;
                readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Skill.ID">;
                readonly name: Schema.brand<Schema.String, "Skill.Name">;
                readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                    readonly text: Schema.String;
                }>>, never, never>;
            }>>>, never, never>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>;
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof ConflictError | typeof SessionNotFoundError>, I, HttpApiMiddleware.Requires<I>> | HttpApiEndpoint.HttpApiEndpoint<"session.remove", "DELETE", "/api/session/:sessionID", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.revert.clear", "DELETE", "/api/session/:sessionID/revert", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionBusyError | typeof UnknownError | typeof SessionNotFoundError>, I, HttpApiMiddleware.Requires<I>> | HttpApiEndpoint.HttpApiEndpoint<"session.revert.commit", "POST", "/api/session/:sessionID/revert/commit", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionBusyError | typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.revert.stage", "POST", "/api/session/:sessionID/revert/stage", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly files: Schema.optional<Schema.Boolean>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly file: Schema.String;
            readonly patch: Schema.String;
            readonly additions: Schema.Int;
            readonly deletions: Schema.Int;
            readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
            readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly file: Schema.String;
            readonly patch: Schema.String;
            readonly additions: Schema.Int;
            readonly deletions: Schema.Int;
            readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
            readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
        }>>>, never, never>;
    }>;
}>>, Schema.toCodecJson<typeof SessionBusyError | typeof UnknownError | typeof SessionNotFoundError | typeof MessageNotFoundError>, I, HttpApiMiddleware.Requires<I>> | HttpApiEndpoint.HttpApiEndpoint<"session.shell", "POST", "/api/session/:sessionID/shell", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly id: Schema.optional<Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    }>;
    readonly command: Schema.String;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError>, I, HttpApiMiddleware.Requires<I>> | HttpApiEndpoint.HttpApiEndpoint<"session.skill", "POST", "/api/experimental/session/:sessionID/skill", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Skill.ID">;
    readonly resume: Schema.optional<Schema.Boolean>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError | typeof SkillNotFoundError>, I, HttpApiMiddleware.Requires<I>> | HttpApiEndpoint.HttpApiEndpoint<"session.stats", "GET", "/api/experimental/session/stats", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly from: Schema.optional<Schema.NumberFromString>;
    readonly to: Schema.optional<Schema.NumberFromString>;
    readonly project: Schema.optional<Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    }>;
    readonly timezone: Schema.optional<Schema.String>;
    readonly tools: Schema.optional<Schema.Literals<readonly ["none", "summary", "detail"]>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly range: Schema.Struct<{
            readonly from: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly to: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly sessions: Schema.Int;
        readonly subagents: Schema.Int;
        readonly prompts: Schema.Int;
        readonly steps: Schema.Int;
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tools: Schema.Union<readonly [Schema.Struct<{
            readonly mode: Schema.Literal<"none">;
        }>, Schema.Struct<{
            readonly mode: Schema.Literal<"summary">;
            readonly totals: Schema.Struct<{
                readonly calls: Schema.Int;
                readonly succeeded: Schema.Int;
                readonly failed: Schema.Int;
                readonly unfinished: Schema.Int;
            }>;
        }>, Schema.Struct<{
            readonly mode: Schema.Literal<"detail">;
            readonly totals: Schema.Struct<{
                readonly calls: Schema.Int;
                readonly succeeded: Schema.Int;
                readonly failed: Schema.Int;
                readonly unfinished: Schema.Int;
            }>;
            readonly usage: Schema.$Array<Schema.Struct<{
                readonly name: Schema.String;
                readonly calls: Schema.Int;
                readonly succeeded: Schema.Int;
                readonly failed: Schema.Int;
                readonly unfinished: Schema.Int;
                readonly durationP50: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>>;
        }>]>;
        readonly activeDays: Schema.Int;
        readonly streak: Schema.Int;
        readonly activity: Schema.$Array<Schema.Struct<{
            readonly date: Schema.String;
            readonly steps: Schema.Int;
        }>>;
        readonly models: Schema.$Array<Schema.Struct<{
            readonly model: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
            }> & {
                parse: (input: string) => {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
            };
            readonly steps: Schema.Int;
            readonly tokens: Schema.Struct<{
                readonly input: Schema.Finite;
                readonly output: Schema.Finite;
                readonly reasoning: Schema.Finite;
                readonly cache: Schema.Struct<{
                    readonly read: Schema.Finite;
                    readonly write: Schema.Finite;
                }>;
            }>;
            readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
                zero: number & import("effect/Brand").Brand<"Money.USD">;
            };
        }>>;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.switchAgent", "POST", "/api/session/:sessionID/agent", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly agent: Schema.brand<Schema.String, "Agent.ID">;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.switchModel", "POST", "/api/session/:sessionID/model", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly model: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    };
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.synthetic", "POST", "/api/session/:sessionID/synthetic", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly id: Schema.optional<Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    }>;
    readonly text: Schema.String;
    readonly description: Schema.optional<Schema.String>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly delivery: Schema.optional<Schema.Literals<readonly ["steer", "queue"]>>;
    readonly resume: Schema.optional<Schema.Boolean>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly type: Schema.tag<"synthetic">;
        readonly payload: Schema.Struct<{
            readonly text: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>;
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof ConflictError | typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.update", "PATCH", "/api/session/:sessionID", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly title: Schema.optional<Schema.String>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>;
    readonly permissions: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly action: Schema.String;
        readonly resource: Schema.String;
        readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
    }>>>;
    readonly archived: Schema.optional<Schema.Boolean>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof LocationNotFoundError | typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.view", "POST", "/api/session/:sessionID/view", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly idle: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.wait", "POST", "/api/experimental/session/:sessionID/wait", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof ServiceUnavailableError | typeof SessionNotFoundError>, never, never>, false>;
