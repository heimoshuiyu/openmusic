import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiSchema } from "effect/http-api";
import { ProjectNotFoundError } from "../errors.js";
declare const WorktreeError_base: Schema.Class<WorktreeError, Schema.TaggedStruct<"WorktreeError", {
    readonly name: Schema.Literal<"WorktreeError">;
    readonly data: Schema.Struct<{
        readonly message: Schema.String;
        readonly forceRequired: Schema.optional<Schema.Boolean>;
    }>;
}>, import("effect/Cause").YieldableError>;
export declare class WorktreeError extends WorktreeError_base {
}
export declare const WorktreeGroup: HttpApiGroup.HttpApiGroup<"server.worktree", HttpApiEndpoint.HttpApiEndpoint<"worktree.create", "POST", "/api/worktree", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    };
    readonly from: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "AbsolutePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "AbsolutePath">>, never, never>;
    readonly branch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Trim>>, Schema.optionalKey<Schema.Trim>, never, never>;
    readonly directory: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "AbsolutePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "AbsolutePath">>, never, never>;
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
}>>, Schema.toCodecJson<typeof ProjectNotFoundError | typeof WorktreeError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"worktree.list", "GET", "/api/worktree", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    };
}>>, never, never, Schema.toCodecJson<Schema.$Array<Schema.Struct<{
    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    readonly strategy: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>>>, Schema.toCodecJson<typeof ProjectNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"worktree.refresh", "POST", "/api/worktree/refresh", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    };
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof ProjectNotFoundError | typeof WorktreeError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"worktree.remove", "DELETE", "/api/worktree", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    };
    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    readonly force: Schema.Boolean;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof ProjectNotFoundError | typeof WorktreeError>, never, never>, false>;
export {};
