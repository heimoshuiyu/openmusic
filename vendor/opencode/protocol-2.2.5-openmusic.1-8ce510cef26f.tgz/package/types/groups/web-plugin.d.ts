import { Schema } from "effect";
import { HttpApiEndpoint } from "effect/http-api";
import { ForbiddenError, LocationNotFoundError, PluginNotFoundError } from "../errors.js";
export declare const WEB_PLUGIN_MODULE_PATH = "/api/experimental/plugin/web-module";
export declare const WebPluginEndpoints: readonly [HttpApiEndpoint.HttpApiEndpoint<"plugin.webList", "POST", "/api/experimental/plugin/web-list", never, never, never, never, Schema.toCodecJson<Schema.$Array<Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Plugin.ID">;
    readonly revision: Schema.String;
    readonly options: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    readonly ticket: Schema.String;
}>>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof ForbiddenError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"plugin.webModule", "GET", "/api/experimental/plugin/web-module", never, Schema.toCodecStringTree<Schema.Struct<{
    id: Schema.brand<Schema.String, "Plugin.ID">;
    revision: Schema.String;
    ticket: Schema.String;
}>>, never, never, Schema.toCodecJson<Schema.Uint8Array>, Schema.toCodecJson<typeof LocationNotFoundError | typeof PluginNotFoundError | typeof ForbiddenError>, never, never>];
