import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiSchema } from "effect/http-api";
import { ArtifactNotFoundError, FileNotFoundError, ForbiddenError, InvalidRequestError, LocationNotFoundError, ProviderNotFoundError, ServiceUnavailableError, SessionNotFoundError } from "../errors.js";
/** Lives in the `server.experimental` group (see `groups/experimental.ts`). */
export declare const ArtifactEndpoints: readonly [HttpApiEndpoint.HttpApiEndpoint<"artifacts.providers", "GET", "/api/experimental/artifacts/providers", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.Trim, "Artifact.ProviderID">;
        readonly name: Schema.String;
        readonly capabilities: Schema.$Array<Schema.Literals<readonly ["static", "server-code", "sqlite", "durable-objects"]>>;
        readonly default: Schema.Boolean;
    }>>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof ServiceUnavailableError | typeof ForbiddenError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"artifacts.list", "GET", "/api/experimental/artifacts", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
    readonly sessionID: Schema.optional<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>;
    readonly provider: Schema.optional<Schema.brand<Schema.Trim, "Artifact.ProviderID">>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Artifact.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
        };
        readonly provider: Schema.brand<Schema.Trim, "Artifact.ProviderID">;
        readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly title: Schema.String;
        readonly entry: Schema.String;
        readonly url: Schema.String;
        readonly time: Schema.Struct<{
            readonly created: Schema.Finite;
            readonly updated: Schema.Finite;
        }>;
    }>>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof ServiceUnavailableError | typeof SessionNotFoundError | typeof ForbiddenError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"artifacts.create", "POST", "/api/experimental/artifacts", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly title: Schema.String;
    readonly files: Schema.$Record<Schema.String, Schema.String>;
    readonly entry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly provider: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Trim, "Artifact.ProviderID">>>, Schema.optionalKey<Schema.brand<Schema.Trim, "Artifact.ProviderID">>, never, never>;
    readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Artifact.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
        };
        readonly provider: Schema.brand<Schema.Trim, "Artifact.ProviderID">;
        readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly title: Schema.String;
        readonly entry: Schema.String;
        readonly url: Schema.String;
        readonly time: Schema.Struct<{
            readonly created: Schema.Finite;
            readonly updated: Schema.Finite;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof InvalidRequestError | typeof ServiceUnavailableError | typeof ProviderNotFoundError | typeof SessionNotFoundError | typeof ForbiddenError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"artifacts.get", "GET", "/api/experimental/artifacts/:artifactID", Schema.toCodecStringTree<Schema.Struct<{
    artifactID: Schema.brand<Schema.String, "Artifact.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Artifact.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
            };
            readonly provider: Schema.brand<Schema.Trim, "Artifact.ProviderID">;
            readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            }>, never, never>;
            readonly title: Schema.String;
            readonly entry: Schema.String;
            readonly url: Schema.String;
            readonly time: Schema.Struct<{
                readonly created: Schema.Finite;
                readonly updated: Schema.Finite;
            }>;
        }>;
        readonly files: Schema.$Record<Schema.String, Schema.String>;
    }>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof ServiceUnavailableError | typeof ForbiddenError | typeof ArtifactNotFoundError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"artifacts.update", "PATCH", "/api/experimental/artifacts/:artifactID", Schema.toCodecStringTree<Schema.Struct<{
    artifactID: Schema.brand<Schema.String, "Artifact.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly files: Schema.$Record<Schema.String, Schema.String>;
    readonly entry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Artifact.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
        };
        readonly provider: Schema.brand<Schema.Trim, "Artifact.ProviderID">;
        readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly title: Schema.String;
        readonly entry: Schema.String;
        readonly url: Schema.String;
        readonly time: Schema.Struct<{
            readonly created: Schema.Finite;
            readonly updated: Schema.Finite;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof InvalidRequestError | typeof ServiceUnavailableError | typeof SessionNotFoundError | typeof ForbiddenError | typeof ArtifactNotFoundError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"artifacts.delete", "DELETE", "/api/experimental/artifacts/:artifactID", Schema.toCodecStringTree<Schema.Struct<{
    artifactID: Schema.brand<Schema.String, "Artifact.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof LocationNotFoundError | typeof ServiceUnavailableError | typeof ForbiddenError | typeof ArtifactNotFoundError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"artifacts.view", "GET", "/api/experimental/artifacts/:artifactID/view/*", Schema.toCodecStringTree<Schema.Struct<{
    artifactID: Schema.brand<Schema.String, "Artifact.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Uint8Array>, Schema.toCodecJson<typeof LocationNotFoundError | typeof InvalidRequestError | typeof ServiceUnavailableError | typeof FileNotFoundError | typeof ForbiddenError | typeof ArtifactNotFoundError>, never, never>];
