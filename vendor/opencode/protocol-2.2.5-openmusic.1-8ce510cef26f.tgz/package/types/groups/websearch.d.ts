import { WebSearch } from "@opencode/schema/websearch";
import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup } from "effect/http-api";
import { InvalidRequestError, ServiceUnavailableError } from "../errors.js";
export declare const WebSearchGroup: HttpApiGroup.HttpApiGroup<"server.websearch", HttpApiEndpoint.HttpApiEndpoint<"websearch.providers", "GET", "/api/websearch/provider", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "WebSearch.ID">;
        readonly name: Schema.String;
    }>>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"websearch.query", "POST", "/api/websearch", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly query: Schema.String;
    readonly providerID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "WebSearch.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "WebSearch.ID">>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: typeof WebSearch.Response;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof ServiceUnavailableError>, never, never>, false>;
