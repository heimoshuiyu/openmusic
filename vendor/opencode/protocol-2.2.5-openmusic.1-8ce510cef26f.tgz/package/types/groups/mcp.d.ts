import { Mcp } from "@opencode/schema/mcp";
import { Context, Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiMiddleware, HttpApiSchema } from "effect/http-api";
import { ForbiddenError, LocationNotFoundError, McpServerNotFoundError } from "../errors.js";
export declare const MCP_CLIENT_PATH = "/api/experimental/client-mcp";
export declare function hasMcpClientTicketURL(url: URL): boolean;
export declare const makeMcpGroup: <LocationId extends HttpApiMiddleware.AnyId, LocationService>(locationMiddleware: Context.Key<LocationId, LocationService>) => HttpApiGroup.HttpApiGroup<"server.mcp", HttpApiEndpoint.HttpApiEndpoint<"mcp.add", "PUT", "/api/experimental/mcp/:server", Schema.toCodecStringTree<Schema.Struct<{
    server: Schema.String;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly config: Schema.toTaggedUnion<"type", readonly [typeof Mcp.LocalConfig, typeof Mcp.RemoteConfig]>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, never, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"mcp.list", "GET", "/api/mcp", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly status: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
            readonly status: Schema.Literal<"connected">;
        }>, Schema.Struct<{
            readonly status: Schema.Literal<"pending">;
        }>, Schema.Struct<{
            readonly status: Schema.Literal<"disabled">;
        }>, Schema.Struct<{
            readonly status: Schema.Literal<"failed">;
            readonly error: Schema.String;
        }>, Schema.Struct<{
            readonly status: Schema.Literal<"needs_auth">;
            readonly error: Schema.String;
        }>]>;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly integrationID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Integration.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Integration.ID">>, never, never>;
    }>>;
}>>, never, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"mcp.resource.catalog", "GET", "/api/mcp/resource", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly resources: Schema.$Array<Schema.Struct<{
            readonly server: Schema.String;
            readonly name: Schema.String;
            readonly uri: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mimeType: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly templates: Schema.$Array<Schema.Struct<{
            readonly server: Schema.String;
            readonly name: Schema.String;
            readonly uriTemplate: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mimeType: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
    }>;
}>>, never, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"mcp.connect", "POST", "/api/experimental/mcp/:server/connect", Schema.toCodecStringTree<Schema.Struct<{
    server: Schema.String;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof McpServerNotFoundError>, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"mcp.disconnect", "POST", "/api/experimental/mcp/:server/disconnect", Schema.toCodecStringTree<Schema.Struct<{
    server: Schema.String;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof McpServerNotFoundError>, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"mcp.remove", "DELETE", "/api/experimental/mcp/:server", Schema.toCodecStringTree<Schema.Struct<{
    server: Schema.String;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof McpServerNotFoundError>, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"mcp.clientToken", "POST", "/api/experimental/client-mcp/token", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
    readonly name: Schema.String;
}>>, never, Schema.toCodecStringTree<Schema.Struct<{
    readonly "x-opencode-ticket": Schema.optional<Schema.String>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly ticket: Schema.String;
        readonly expires_in: Schema.Int;
    }>;
}>>, Schema.toCodecJson<typeof ForbiddenError>, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"mcp.client", "GET", "/api/experimental/client-mcp", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
    readonly name: Schema.String;
    readonly ticket: Schema.optional<Schema.String>;
}>>, never, never, Schema.toCodecJson<Schema.Boolean>, Schema.toCodecJson<typeof LocationNotFoundError | typeof ForbiddenError>, never, never>, false>;
