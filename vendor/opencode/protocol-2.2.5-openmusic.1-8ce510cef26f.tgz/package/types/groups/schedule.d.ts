import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiSchema } from "effect/http-api";
import { ForbiddenError, InvalidRequestError, ScheduleNotFoundError, SessionNotFoundError } from "../errors.js";
export declare const CreatePayload: Schema.Struct<{
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly in: Schema.String;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly every: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly cron: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly in: Schema.String;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly every: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly cron: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
    }>]>>, never, never>;
    readonly if: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>, never, never>;
    readonly until: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>, never, never>;
    readonly ends: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly after: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly times: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly after: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly times: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>, never, never>;
    readonly prompt: Schema.String;
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>;
export type CreatePayload = typeof CreatePayload.Type;
/** Lives in the `server.experimental` group (see `groups/experimental.ts`). */
export declare const ScheduleEndpoints: readonly [HttpApiEndpoint.HttpApiEndpoint<"schedule.create", "POST", "/api/experimental/schedule", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly in: Schema.String;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly every: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly cron: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly in: Schema.String;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly every: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly cron: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
    }>]>>, never, never>;
    readonly if: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>, never, never>;
    readonly until: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>, never, never>;
    readonly ends: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly after: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly times: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly after: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly times: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>, never, never>;
    readonly prompt: Schema.String;
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Schedule.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
        };
        readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly when: Schema.Union<readonly [Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"in">;
            readonly in: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"at">;
            readonly at: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"every">;
            readonly every: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"cron">;
            readonly cron: Schema.String;
        }>]>;
        readonly tz: Schema.String;
        readonly if: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>, never, never>;
        readonly until: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>, never, never>;
        readonly action: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"prompt">;
            readonly prompt: Schema.String;
        }>]>;
        readonly status: Schema.Literals<readonly ["active", "paused", "done"]>;
        readonly nextDueAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly endsAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly remainingRuns: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly runCount: Schema.Int;
        readonly lastFiredAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly lastOutcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>>, Schema.optionalKey<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>, never, never>;
        readonly lastOutput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof SessionNotFoundError | typeof ForbiddenError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"schedule.list", "GET", "/api/experimental/schedule", never, Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Schedule.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
        };
        readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly when: Schema.Union<readonly [Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"in">;
            readonly in: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"at">;
            readonly at: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"every">;
            readonly every: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"cron">;
            readonly cron: Schema.String;
        }>]>;
        readonly tz: Schema.String;
        readonly if: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>, never, never>;
        readonly until: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>, never, never>;
        readonly action: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"prompt">;
            readonly prompt: Schema.String;
        }>]>;
        readonly status: Schema.Literals<readonly ["active", "paused", "done"]>;
        readonly nextDueAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly endsAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly remainingRuns: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly runCount: Schema.Int;
        readonly lastFiredAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly lastOutcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>>, Schema.optionalKey<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>, never, never>;
        readonly lastOutput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>>;
}>>, Schema.toCodecJson<typeof SessionNotFoundError | typeof ForbiddenError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"schedule.get", "GET", "/api/experimental/schedule/:scheduleID", Schema.toCodecStringTree<Schema.Struct<{
    scheduleID: Schema.brand<Schema.String, "Schedule.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Schedule.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
        };
        readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly when: Schema.Union<readonly [Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"in">;
            readonly in: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"at">;
            readonly at: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"every">;
            readonly every: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"cron">;
            readonly cron: Schema.String;
        }>]>;
        readonly tz: Schema.String;
        readonly if: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>, never, never>;
        readonly until: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>, never, never>;
        readonly action: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"prompt">;
            readonly prompt: Schema.String;
        }>]>;
        readonly status: Schema.Literals<readonly ["active", "paused", "done"]>;
        readonly nextDueAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly endsAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly remainingRuns: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly runCount: Schema.Int;
        readonly lastFiredAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly lastOutcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>>, Schema.optionalKey<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>, never, never>;
        readonly lastOutput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof ForbiddenError | typeof ScheduleNotFoundError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"schedule.pause", "POST", "/api/experimental/schedule/:scheduleID/pause", Schema.toCodecStringTree<Schema.Struct<{
    scheduleID: Schema.brand<Schema.String, "Schedule.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Schedule.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
        };
        readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly when: Schema.Union<readonly [Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"in">;
            readonly in: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"at">;
            readonly at: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"every">;
            readonly every: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"cron">;
            readonly cron: Schema.String;
        }>]>;
        readonly tz: Schema.String;
        readonly if: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>, never, never>;
        readonly until: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>, never, never>;
        readonly action: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"prompt">;
            readonly prompt: Schema.String;
        }>]>;
        readonly status: Schema.Literals<readonly ["active", "paused", "done"]>;
        readonly nextDueAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly endsAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly remainingRuns: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly runCount: Schema.Int;
        readonly lastFiredAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly lastOutcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>>, Schema.optionalKey<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>, never, never>;
        readonly lastOutput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof ForbiddenError | typeof ScheduleNotFoundError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"schedule.resume", "POST", "/api/experimental/schedule/:scheduleID/resume", Schema.toCodecStringTree<Schema.Struct<{
    scheduleID: Schema.brand<Schema.String, "Schedule.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Schedule.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
        };
        readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly when: Schema.Union<readonly [Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"in">;
            readonly in: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"at">;
            readonly at: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"every">;
            readonly every: Schema.String;
        }>, Schema.Struct<{
            readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.tag<"cron">;
            readonly cron: Schema.String;
        }>]>;
        readonly tz: Schema.String;
        readonly if: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>, never, never>;
        readonly until: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"shell">;
            readonly run: Schema.String;
            readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"code">;
            readonly code: Schema.String;
        }>]>>, never, never>;
        readonly action: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"prompt">;
            readonly prompt: Schema.String;
        }>]>;
        readonly status: Schema.Literals<readonly ["active", "paused", "done"]>;
        readonly nextDueAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly endsAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly remainingRuns: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly runCount: Schema.Int;
        readonly lastFiredAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly lastOutcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>>, Schema.optionalKey<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>, never, never>;
        readonly lastOutput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof ForbiddenError | typeof ScheduleNotFoundError>, never, never>, HttpApiEndpoint.HttpApiEndpoint<"schedule.delete", "DELETE", "/api/experimental/schedule/:scheduleID", Schema.toCodecStringTree<Schema.Struct<{
    scheduleID: Schema.brand<Schema.String, "Schedule.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
    };
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof ForbiddenError | typeof ScheduleNotFoundError>, never, never>];
