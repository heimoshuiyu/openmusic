import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup } from "effect/http-api";
import { UnauthorizedError } from "../errors.js";
export declare const ServerInfo: Schema.Struct<{
    readonly version: Schema.String;
    readonly pid: Schema.Int;
    readonly hostname: Schema.optional<Schema.String>;
    readonly urls: Schema.$Array<Schema.String>;
    readonly paths: Schema.Struct<{
        readonly tmp: Schema.String;
    }>;
    readonly capabilities: Schema.optional<Schema.Struct<{
        readonly persistentPty: Schema.optional<Schema.Boolean>;
    }>>;
}>;
export type ServerInfo = typeof ServerInfo.Type;
export declare const PairingCode: Schema.Struct<{
    readonly code: Schema.String;
    readonly expires_in: Schema.Int;
}>;
export type PairingCode = typeof PairingCode.Type;
export declare const PairingSession: Schema.Struct<{
    readonly token: Schema.String;
}>;
export type PairingSession = typeof PairingSession.Type;
export declare const PAIRING_CONNECT_PATH = "/auth/connect/:code";
export declare function isPairingConnectURL(url: URL): boolean;
export declare const ServerGroup: HttpApiGroup.HttpApiGroup<"server.server", HttpApiEndpoint.HttpApiEndpoint<"server.connect", "GET", "/auth/connect/:code", Schema.toCodecStringTree<Schema.Struct<{
    code: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly token: Schema.String;
}>>, Schema.toCodecJson<typeof UnauthorizedError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"server.info", "GET", "/api/info", never, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly version: Schema.String;
    readonly pid: Schema.Int;
    readonly hostname: Schema.optional<Schema.String>;
    readonly urls: Schema.$Array<Schema.String>;
    readonly paths: Schema.Struct<{
        readonly tmp: Schema.String;
    }>;
    readonly capabilities: Schema.optional<Schema.Struct<{
        readonly persistentPty: Schema.optional<Schema.Boolean>;
    }>>;
}>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"server.pair", "POST", "/api/pair", never, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly code: Schema.String;
    readonly expires_in: Schema.Int;
}>>, never, never, never>, false>;
