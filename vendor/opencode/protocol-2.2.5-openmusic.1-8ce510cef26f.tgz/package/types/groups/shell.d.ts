import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiSchema } from "effect/http-api";
import { ShellNotFoundError } from "../errors.js";
export declare const ShellGroup: HttpApiGroup.HttpApiGroup<"server.shell", HttpApiEndpoint.HttpApiEndpoint<"shell.create", "POST", "/api/shell", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly command: Schema.String;
    readonly cwd: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
        readonly command: Schema.String;
        readonly cwd: Schema.String;
        readonly shell: Schema.String;
        readonly file: Schema.String;
        readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly time: Schema.Struct<{
            readonly started: Schema.Finite;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>;
    }>;
}>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"shell.get", "GET", "/api/shell/:id", Schema.toCodecStringTree<Schema.Struct<{
    id: Schema.brand<Schema.String, "Shell.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Shell.ID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
        readonly command: Schema.String;
        readonly cwd: Schema.String;
        readonly shell: Schema.String;
        readonly file: Schema.String;
        readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly time: Schema.Struct<{
            readonly started: Schema.Finite;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof ShellNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"shell.list", "GET", "/api/shell", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
        readonly command: Schema.String;
        readonly cwd: Schema.String;
        readonly shell: Schema.String;
        readonly file: Schema.String;
        readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly time: Schema.Struct<{
            readonly started: Schema.Finite;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>;
    }>>;
}>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"shell.output", "GET", "/api/shell/:id/output", Schema.toCodecStringTree<Schema.Struct<{
    id: Schema.brand<Schema.String, "Shell.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Shell.ID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly cursor: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly output: Schema.String;
        readonly cursor: Schema.Int;
        readonly size: Schema.Int;
        readonly truncated: Schema.Boolean;
    }>;
}>>, Schema.toCodecJson<typeof ShellNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"shell.remove", "DELETE", "/api/shell/:id", Schema.toCodecStringTree<Schema.Struct<{
    id: Schema.brand<Schema.String, "Shell.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Shell.ID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, never, never, never>, false>;
