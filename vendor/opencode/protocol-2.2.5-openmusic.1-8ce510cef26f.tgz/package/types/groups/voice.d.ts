import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup } from "effect/http-api";
import { InvalidRequestError, LocationNotFoundError, ServiceUnavailableError } from "../errors.js";
export declare const VoiceTransportType: Schema.Literals<readonly ["webrtc", "websocket"]>;
export declare const VoiceModel: Schema.Struct<{
    readonly model: Schema.String;
    readonly provider: Schema.String;
    readonly transports: Schema.$Array<Schema.Literals<readonly ["webrtc", "websocket"]>>;
    readonly available: Schema.Boolean;
}>;
export declare const VoiceWebRTCTransportInput: Schema.Struct<{
    readonly type: Schema.Literal<"webrtc">;
    readonly sdp: Schema.String;
    readonly dcid: Schema.optional<Schema.Number>;
}>;
export declare const VoiceWebSocketTransportInput: Schema.Struct<{
    readonly type: Schema.Literal<"websocket">;
}>;
export declare const VoiceTransportInput: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"webrtc">;
    readonly sdp: Schema.String;
    readonly dcid: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"websocket">;
}>]>;
export declare const VoiceWebRTCTransport: Schema.Struct<{
    readonly type: Schema.Literal<"webrtc">;
    readonly sdp: Schema.String;
}>;
export declare const VoiceWebSocketTransport: Schema.Struct<{
    readonly type: Schema.Literal<"websocket">;
    readonly url: Schema.String;
    readonly token: Schema.String;
    readonly expiresAt: Schema.Number;
}>;
export declare const VoiceTransport: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"webrtc">;
    readonly sdp: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"websocket">;
    readonly url: Schema.String;
    readonly token: Schema.String;
    readonly expiresAt: Schema.Number;
}>]>;
export declare const VoiceGroup: HttpApiGroup.HttpApiGroup<"server.voice", HttpApiEndpoint.HttpApiEndpoint<"voice.models", "GET", "/api/experimental/voice/models", never, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly models: Schema.$Array<Schema.Struct<{
            readonly model: Schema.String;
            readonly provider: Schema.String;
            readonly transports: Schema.$Array<Schema.Literals<readonly ["webrtc", "websocket"]>>;
            readonly available: Schema.Boolean;
        }>>;
        readonly default: Schema.optional<Schema.String>;
    }>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof ServiceUnavailableError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"voice.session", "POST", "/api/experimental/voice/session", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly model: Schema.String;
    readonly session: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly transport: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"webrtc">;
        readonly sdp: Schema.String;
        readonly dcid: Schema.optional<Schema.Number>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"websocket">;
    }>]>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly transport: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"webrtc">;
            readonly sdp: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"websocket">;
            readonly url: Schema.String;
            readonly token: Schema.String;
            readonly expiresAt: Schema.Number;
        }>]>;
    }>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof InvalidRequestError | typeof ServiceUnavailableError>, never, never>, false>;
