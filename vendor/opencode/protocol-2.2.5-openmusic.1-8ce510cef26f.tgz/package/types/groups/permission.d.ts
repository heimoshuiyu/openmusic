import { Context, Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiMiddleware, HttpApiSchema } from "effect/http-api";
import { ConflictError, LocationNotFoundError, PermissionNotFoundError, PermissionSavedNotFoundError, SessionNotFoundError } from "../errors.js";
export declare const makePermissionGroup: <LocationId extends HttpApiMiddleware.AnyId, LocationService, SessionLocationId extends HttpApiMiddleware.AnyId, SessionLocationService>(locationMiddleware: Context.Key<LocationId, LocationService>, sessionLocationMiddleware: Context.Key<SessionLocationId, SessionLocationService>) => HttpApiGroup.HttpApiGroup<"server.permission", HttpApiEndpoint.HttpApiEndpoint<"permission.request.list", "GET", "/api/permission/request", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly action: Schema.String;
        readonly resources: Schema.$Array<Schema.String>;
        readonly save: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>, never, never>;
        readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly id: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
    }>>;
}>>, never, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"permission.saved.list", "GET", "/api/permission/saved", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly projectID: Schema.optional<Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    }>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PermissionSaved.ID"> & {
            create: () => string & import("effect/Brand").Brand<"PermissionSaved.ID">;
        };
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly action: Schema.String;
        readonly resource: Schema.String;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>>;
}>>, never, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"permission.saved.remove", "DELETE", "/api/permission/saved/:id", Schema.toCodecStringTree<Schema.Struct<{
    id: Schema.brand<Schema.String, "PermissionSaved.ID"> & {
        create: () => string & import("effect/Brand").Brand<"PermissionSaved.ID">;
    };
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"permission.saved.update", "PATCH", "/api/permission/saved/:id", Schema.toCodecStringTree<Schema.Struct<{
    id: Schema.brand<Schema.String, "PermissionSaved.ID"> & {
        create: () => string & import("effect/Brand").Brand<"PermissionSaved.ID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly action: Schema.optional<Schema.String>;
    readonly resource: Schema.optional<Schema.String>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PermissionSaved.ID"> & {
            create: () => string & import("effect/Brand").Brand<"PermissionSaved.ID">;
        };
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly action: Schema.String;
        readonly resource: Schema.String;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof ConflictError | typeof PermissionSavedNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.permission.create", "POST", "/api/session/:sessionID/permission", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly id: Schema.optional<Schema.brand<Schema.String, "Permission.ID"> & {
        create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
    }>;
    readonly action: Schema.String;
    readonly resources: Schema.$Array<Schema.String>;
    readonly save: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tool">;
        readonly messageID: Schema.String;
        readonly id: Schema.String;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tool">;
        readonly messageID: Schema.String;
        readonly id: Schema.String;
    }>]>>, never, never>;
    readonly agent: Schema.optional<Schema.brand<Schema.String, "Agent.ID">>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
        readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
    }>;
}>>, Schema.toCodecJson<typeof SessionNotFoundError>, SessionLocationId, HttpApiMiddleware.Requires<SessionLocationId>> | HttpApiEndpoint.HttpApiEndpoint<"session.permission.get", "GET", "/api/session/:sessionID/permission/:requestID", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    requestID: Schema.brand<Schema.String, "Permission.ID"> & {
        create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly action: Schema.String;
        readonly resources: Schema.$Array<Schema.String>;
        readonly save: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>, never, never>;
        readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly id: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
    }>;
}>>, Schema.toCodecJson<typeof SessionNotFoundError | typeof PermissionNotFoundError>, SessionLocationId, HttpApiMiddleware.Requires<SessionLocationId>> | HttpApiEndpoint.HttpApiEndpoint<"session.permission.list", "GET", "/api/session/:sessionID/permission", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly action: Schema.String;
        readonly resources: Schema.$Array<Schema.String>;
        readonly save: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>, never, never>;
        readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly id: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
    }>>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof SessionNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"session.permission.reply", "POST", "/api/session/:sessionID/permission/:requestID/reply", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    requestID: Schema.brand<Schema.String, "Permission.ID"> & {
        create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly decision: Schema.Literals<readonly ["once", "always", "reject"]>;
    readonly message: Schema.optional<Schema.String>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof SessionNotFoundError | typeof PermissionNotFoundError>, SessionLocationId, HttpApiMiddleware.Requires<SessionLocationId>>, false>;
