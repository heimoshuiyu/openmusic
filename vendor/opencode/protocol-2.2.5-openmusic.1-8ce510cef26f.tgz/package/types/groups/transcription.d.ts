import { Context, Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiMiddleware } from "effect/http-api";
import { InvalidRequestError, ServiceUnavailableError, SessionNotFoundError, UnknownError } from "../errors.js";
export declare const TranscribeRequest: Schema.Struct<{
    readonly audio: Schema.String;
    readonly mime: Schema.String;
    readonly prompt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly contextSessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
    readonly images: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly type: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["whisper", "lalm"]>>>, Schema.optionalKey<Schema.Literals<readonly ["whisper", "lalm"]>>, never, never>;
        readonly whisper: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly lalm: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>, never, never>;
        readonly hot_words: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly type: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["whisper", "lalm"]>>>, Schema.optionalKey<Schema.Literals<readonly ["whisper", "lalm"]>>, never, never>;
        readonly whisper: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly lalm: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>, never, never>;
        readonly hot_words: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>>, never, never>;
}>;
export declare const TranscribeResponse: Schema.Struct<{
    readonly text: Schema.String;
    readonly usage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly output_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly output_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>>, never, never>;
}>;
export declare const makeTranscriptionGroup: <LocationId extends HttpApiMiddleware.AnyId, LocationService>(locationMiddleware: Context.Key<LocationId, LocationService>) => HttpApiGroup.HttpApiGroup<"server.transcription", HttpApiEndpoint.HttpApiEndpoint<"transcribe", "POST", "/api/transcription", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly audio: Schema.String;
    readonly mime: Schema.String;
    readonly prompt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly contextSessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
    readonly images: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly type: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["whisper", "lalm"]>>>, Schema.optionalKey<Schema.Literals<readonly ["whisper", "lalm"]>>, never, never>;
        readonly whisper: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly lalm: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>, never, never>;
        readonly hot_words: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly type: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["whisper", "lalm"]>>>, Schema.optionalKey<Schema.Literals<readonly ["whisper", "lalm"]>>, never, never>;
        readonly whisper: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly lalm: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>, never, never>;
        readonly hot_words: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly text: Schema.String;
        readonly usage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly output_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly output_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>>, never, never>;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof ServiceUnavailableError | typeof UnknownError | typeof SessionNotFoundError>, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"transcribeWithOverrides", "POST", "/api/experimental/transcription", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly audio: Schema.String;
    readonly mime: Schema.String;
    readonly prompt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly contextSessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
    readonly images: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly type: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["whisper", "lalm"]>>>, Schema.optionalKey<Schema.Literals<readonly ["whisper", "lalm"]>>, never, never>;
        readonly whisper: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly lalm: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>, never, never>;
        readonly hot_words: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly type: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["whisper", "lalm"]>>>, Schema.optionalKey<Schema.Literals<readonly ["whisper", "lalm"]>>, never, never>;
        readonly whisper: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly lalm: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
        }>>, never, never>;
        readonly hot_words: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>>, never, never>;
    readonly overrides: Schema.Struct<{
        readonly context_pairs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<0>, Schema.Int]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<0>, Schema.Int]>>, never, never>;
        readonly hot_words: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly whisper: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly url: Schema.String;
            readonly apiKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly url: Schema.String;
            readonly apiKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
    }>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly text: Schema.String;
        readonly usage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly output_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly output_tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>>, never, never>;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof ServiceUnavailableError | typeof UnknownError | typeof SessionNotFoundError>, LocationId, HttpApiMiddleware.Requires<LocationId>>, false>;
