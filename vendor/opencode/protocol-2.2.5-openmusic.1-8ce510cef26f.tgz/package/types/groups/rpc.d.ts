import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup } from "effect/http-api";
import { RpcError, RpcInternalError } from "../errors.js";
export declare const RpcInput: Schema.Struct<{
    readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Unknown>>, Schema.optionalKey<Schema.Unknown>, never, never>;
}>;
export declare const RpcOutput: Schema.Struct<{
    readonly output: Schema.optionalKey<Schema.Unknown>;
}>;
export declare const RpcGroup: HttpApiGroup.HttpApiGroup<"server.rpc", HttpApiEndpoint.HttpApiEndpoint<"rpc.call", "POST", "/api/rpc/:rpcID/:method", Schema.toCodecStringTree<Schema.Struct<{
    rpcID: Schema.String;
    method: Schema.String;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Unknown>>, Schema.optionalKey<Schema.Unknown>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly output: Schema.optionalKey<Schema.Unknown>;
}>>, Schema.toCodecJson<typeof RpcError | typeof RpcInternalError>, never, never>, false>;
