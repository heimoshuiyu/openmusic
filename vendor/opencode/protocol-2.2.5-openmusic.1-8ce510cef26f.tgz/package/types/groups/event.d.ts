import type { Definition } from "@opencode/schema/event";
import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiSchema } from "effect/http-api";
export declare const makeEventGroup: <const Definitions extends ReadonlyArray<Definition>>(definitions: Definitions) => HttpApiGroup.HttpApiGroup<"server.event", HttpApiEndpoint.HttpApiEndpoint<"event.subscribe", "GET", "/api/event", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly types: Schema.optional<Schema.ArrayEnsure<Schema.Union<readonly [Schema.Literals<readonly Definitions[number]["type"][]>, Schema.TemplateLiteral<readonly ["rpc.", Schema.String]>]>>>;
}>>, never, never, HttpApiSchema.StreamSse<HttpApiSchema.SseEventFromData<Schema.Union<readonly [...Definitions, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly type: Schema.TemplateLiteral<readonly ["rpc.", Schema.String]>;
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Record<Schema.String, Schema.Unknown>;
}>, ...Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>>;
    readonly type: Schema.Literal<"server.connected">;
    readonly data: Schema.Struct<{}>;
}>[]]>>, Schema.Never, (readonly [...{ [K in keyof Definitions]: Definitions[K]["Type"]; }, {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: `rpc.${string}`;
    readonly location: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
    };
    readonly data: {
        readonly [x: string]: unknown;
    };
}, ...{
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
    } | undefined;
    readonly type: "server.connected";
    readonly data: {};
}[]])[number]>, never, never, never>, false>;
export declare const EventGroup: HttpApiGroup.HttpApiGroup<"server.event", HttpApiEndpoint.HttpApiEndpoint<"event.subscribe", "GET", "/api/event", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly types: Schema.optional<Schema.ArrayEnsure<Schema.Union<readonly [Schema.Literals<readonly ("agent.updated" | "artifact.updated" | "command.updated" | "config.updated" | "credential.switched" | "credential.updated" | "filesystem.changed" | "form.cancelled" | "form.created" | "form.replied" | "installation.update-available" | "installation.updated" | "integration.updated" | "location.shutdown" | "mcp.resources.changed" | "mcp.status.changed" | "model.updated" | "models-dev.refreshed" | "permission.asked" | "permission.replied" | "persistent-pty.added" | "persistent-pty.removed" | "persistent-pty.updated" | "plugin.updated" | "project.updated" | "provider.updated" | "pty.created" | "pty.deleted" | "pty.exited" | "pty.updated" | "reference.updated" | "session.agent.selected" | "session.archived" | "session.compaction.delta" | "session.compaction.ended" | "session.compaction.failed" | "session.compaction.started" | "session.created" | "session.deleted" | "session.execution.failed" | "session.execution.interrupted" | "session.execution.started" | "session.execution.succeeded" | "session.forked" | "session.idle" | "session.inbox.cancelled" | "session.inbox.delivered" | "session.inbox.delivery.changed" | "session.inbox.enqueued" | "session.instructions.updated" | "session.metadata.updated" | "session.model.selected" | "session.moved" | "session.permissions" | "session.reasoning.delta" | "session.reasoning.ended" | "session.reasoning.started" | "session.renamed" | "session.retry.scheduled" | "session.revert.cleared" | "session.revert.committed" | "session.revert.staged" | "session.shell.ended" | "session.shell.started" | "session.skill.activated" | "session.status" | "session.step.ended" | "session.step.failed" | "session.step.started" | "session.step.streamed" | "session.synthetic" | "session.text.delta" | "session.text.ended" | "session.text.started" | "session.tool.called" | "session.tool.failed" | "session.tool.input.delta" | "session.tool.input.ended" | "session.tool.input.started" | "session.tool.progress" | "session.tool.success" | "session.unarchived" | "session.usage.updated" | "session.viewed" | "shell.created" | "shell.deleted" | "shell.exited" | "skill.updated" | "tui.command.execute" | "tui.prompt.append" | "tui.session.select" | "tui.toast.show" | "vcs.branch.updated" | "websearch.updated" | "worktree.resolved" | "worktree.updated")[]>, Schema.TemplateLiteral<readonly ["rpc.", Schema.String]>]>>>;
}>>, never, never, HttpApiSchema.StreamSse<HttpApiSchema.SseEventFromData<Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"location.shutdown">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "location.shutdown";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"models-dev.refreshed">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "models-dev.refreshed";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"credential.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
        readonly credentialID: Schema.brand<Schema.String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        };
    }>;
}> & {
    type: "credential.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
        readonly credentialID: Schema.brand<Schema.String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"credential.switched">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
        readonly credentialID: Schema.NullOr<Schema.brand<Schema.String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        }>;
    }>;
}> & {
    type: "credential.switched";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
        readonly credentialID: Schema.NullOr<Schema.brand<Schema.String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"integration.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "integration.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"provider.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "provider.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"model.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "model.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"agent.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "agent.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.created">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly slug: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly version: Schema.String;
    }>;
}> & {
    type: "session.created";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly slug: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly version: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.agent.selected">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
    }>;
}> & {
    type: "session.agent.selected";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.model.selected">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>;
}> & {
    type: "session.model.selected";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.moved">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.moved";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.renamed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly title: Schema.String;
    }>;
}> & {
    type: "session.renamed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly title: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.metadata.updated">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>;
}> & {
    type: "session.metadata.updated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.permissions">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly permissions: Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>;
    }>;
}> & {
    type: "session.permissions";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly permissions: Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.viewed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly idle: Schema.Finite;
    }>;
}> & {
    type: "session.viewed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly idle: Schema.Finite;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.archived">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.archived";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.unarchived">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.unarchived";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.usage.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
    }>;
}> & {
    type: "session.usage.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.deleted">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.deleted";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.forked">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly boundary: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"before">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"through">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>]>;
        readonly instructions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>>, Schema.optionalKey<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>, never, never>;
        readonly instructionEntries: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>, never, never>;
    }>;
}> & {
    type: "session.forked";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly boundary: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"before">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"through">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>]>;
        readonly instructions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>>, Schema.optionalKey<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>, never, never>;
        readonly instructionEntries: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.delivered">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.inbox.delivered";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.enqueued">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly item: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"user">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>, never, never>;
                readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"synthetic">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"compaction">;
            readonly payload: Schema.Struct<{}>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"move">;
            readonly payload: Schema.Struct<{
                readonly location: Schema.Struct<{
                    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
                    readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>, never, never>;
                }>;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>]>;
    }>;
}> & {
    type: "session.inbox.enqueued";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly item: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"user">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>, never, never>;
                readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"synthetic">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"compaction">;
            readonly payload: Schema.Struct<{}>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"move">;
            readonly payload: Schema.Struct<{
                readonly location: Schema.Struct<{
                    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
                    readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>, never, never>;
                }>;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.cancelled">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.inbox.cancelled";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.delivery.changed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    }>;
}> & {
    type: "session.inbox.delivery.changed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.execution.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.succeeded">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.execution.succeeded";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}> & {
    type: "session.execution.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.interrupted">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["user", "shutdown", "superseded", "inactivity"]>;
    }>;
}> & {
    type: "session.execution.interrupted";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["user", "shutdown", "superseded", "inactivity"]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.instructions.updated">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly delta: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.brand<Schema.String, "Instruction.Hash">, Schema.Literal<"removed">]>>;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
}> & {
    type: "session.instructions.updated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly delta: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.brand<Schema.String, "Instruction.Hash">, Schema.Literal<"removed">]>>;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.synthetic">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.synthetic";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.skill.activated">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.String;
    }>;
}> & {
    type: "session.skill.activated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.shell.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
    }>;
}> & {
    type: "session.shell.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.shell.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
        readonly output: Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>;
    }>;
}> & {
    type: "session.shell.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
        readonly output: Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly started: Schema.Int;
    }>;
}> & {
    type: "session.step.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly started: Schema.Int;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.streamed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.step.streamed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly finish: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}> & {
    type: "session.step.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly finish: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["content-filter"]>>>, Schema.optionalKey<Schema.Literals<readonly ["content-filter"]>>, never, never>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}> & {
    type: "session.step.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["content-filter"]>>>, Schema.optionalKey<Schema.Literals<readonly ["content-filter"]>>, never, never>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.text.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
    }>;
}> & {
    type: "session.text.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.text.delta">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly delta: Schema.String;
    }>;
}> & {
    type: "session.text.delta";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly delta: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.text.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.text.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.reasoning.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.reasoning.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.reasoning.delta">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly delta: Schema.String;
    }>;
}> & {
    type: "session.reasoning.delta";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly delta: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.reasoning.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.reasoning.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.input.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly name: Schema.String;
    }>;
}> & {
    type: "session.tool.input.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly name: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.input.delta">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly delta: Schema.String;
    }>;
}> & {
    type: "session.tool.input.delta";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly delta: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.input.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly text: Schema.String;
    }>;
}> & {
    type: "session.tool.input.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly text: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.called">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.called";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.progress">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>;
}> & {
    type: "session.tool.progress";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.success">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.success";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.retry.scheduled">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly attempt: Schema.Int;
        readonly at: Schema.Int;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}> & {
    type: "session.retry.scheduled";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly attempt: Schema.Int;
        readonly at: Schema.Int;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.compaction.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
    }>;
}> & {
    type: "session.compaction.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.compaction.delta">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: Schema.String;
    }>;
}> & {
    type: "session.compaction.delta";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.compaction.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly text: Schema.String;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}> & {
    type: "session.compaction.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly text: Schema.String;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.compaction.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}> & {
    type: "session.compaction.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.revert.staged">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly revert: Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>;
    }>;
}> & {
    type: "session.revert.staged";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly revert: Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.revert.cleared">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.revert.cleared";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.revert.committed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly to: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.revert.committed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly to: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"filesystem.changed">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly file: Schema.String;
        readonly event: Schema.Literals<readonly ["add", "change", "unlink"]>;
    }>;
}> & {
    type: "filesystem.changed";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly file: Schema.String;
        readonly event: Schema.Literals<readonly ["add", "change", "unlink"]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"reference.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "reference.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"permission.asked">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly action: Schema.String;
        readonly resources: Schema.$Array<Schema.String>;
        readonly save: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>, never, never>;
        readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly id: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
    }>;
}> & {
    type: "permission.asked";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly action: Schema.String;
        readonly resources: Schema.$Array<Schema.String>;
        readonly save: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>, never, never>;
        readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly id: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"permission.replied">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly requestID: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
        readonly reply: Schema.Literals<readonly ["once", "always", "reject"]>;
    }>;
}> & {
    type: "permission.replied";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly requestID: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
        readonly reply: Schema.Literals<readonly ["once", "always", "reject"]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"plugin.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "plugin.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"project.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly canonical: Schema.brand<Schema.String, "AbsolutePath">;
        readonly vcs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly icon: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly override: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly color: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly override: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly color: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly commands: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.Int;
            readonly updated: Schema.Int;
            readonly active: Schema.Int;
            readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly sandboxes: Schema.$Array<Schema.String>;
    }>;
}> & {
    type: "project.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly canonical: Schema.brand<Schema.String, "AbsolutePath">;
        readonly vcs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly icon: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly override: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly color: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly override: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly color: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly commands: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.Int;
            readonly updated: Schema.Int;
            readonly active: Schema.Int;
            readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly sandboxes: Schema.$Array<Schema.String>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"worktree.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
    }>;
}> & {
    type: "worktree.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"worktree.resolved">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly previous: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly adopted: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, never, never>;
    }>;
}> & {
    type: "worktree.resolved";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly previous: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly adopted: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"command.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "command.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"config.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "config.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"skill.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "skill.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"pty.created">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}> & {
    type: "pty.created";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"pty.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}> & {
    type: "pty.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"pty.exited">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly exitCode: Schema.Int;
    }>;
}> & {
    type: "pty.exited";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly exitCode: Schema.Int;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"pty.deleted">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}> & {
    type: "pty.deleted";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"persistent-pty.added">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
}> & {
    type: "persistent-pty.added";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"persistent-pty.removed">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}> & {
    type: "persistent-pty.removed";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"persistent-pty.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
}> & {
    type: "persistent-pty.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"shell.created">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
    }>;
}> & {
    type: "shell.created";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"shell.exited">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
    }>;
}> & {
    type: "shell.exited";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"shell.deleted">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
    }>;
}> & {
    type: "shell.deleted";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"form.created">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly form: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
            readonly title: Schema.String;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>;
        }>;
    }>;
}> & {
    type: "form.created";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly form: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
            readonly title: Schema.String;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"form.replied">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: Schema.String;
        readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
    }>;
}> & {
    type: "form.replied";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: Schema.String;
        readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"form.cancelled">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: Schema.String;
    }>;
}> & {
    type: "form.cancelled";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"websearch.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "websearch.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"artifact.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "artifact.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.status">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"idle">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"retry">;
            readonly attempt: Schema.Int;
            readonly message: Schema.String;
            readonly action: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly reason: Schema.String;
                readonly provider: Schema.String;
                readonly title: Schema.String;
                readonly message: Schema.String;
                readonly label: Schema.String;
                readonly link: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly reason: Schema.String;
                readonly provider: Schema.String;
                readonly title: Schema.String;
                readonly message: Schema.String;
                readonly label: Schema.String;
                readonly link: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>, never, never>;
            readonly next: Schema.Int;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"busy">;
        }>]>;
    }>;
}> & {
    type: "session.status";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"idle">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"retry">;
            readonly attempt: Schema.Int;
            readonly message: Schema.String;
            readonly action: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly reason: Schema.String;
                readonly provider: Schema.String;
                readonly title: Schema.String;
                readonly message: Schema.String;
                readonly label: Schema.String;
                readonly link: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly reason: Schema.String;
                readonly provider: Schema.String;
                readonly title: Schema.String;
                readonly message: Schema.String;
                readonly label: Schema.String;
                readonly link: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>, never, never>;
            readonly next: Schema.Int;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"busy">;
        }>]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.idle">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.idle";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"tui.prompt.append">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly text: Schema.String;
    }>;
}> & {
    type: "tui.prompt.append";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly text: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"tui.command.execute">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly command: Schema.Union<readonly [Schema.Literals<readonly ["session.list", "session.new", "session.interrupt", "session.background", "session.compact", "session.page.up", "session.page.down", "session.line.up", "session.line.down", "session.half.page.up", "session.half.page.down", "session.first", "session.last", "prompt.clear", "prompt.submit", "agent.cycle"]>, Schema.String]>;
    }>;
}> & {
    type: "tui.command.execute";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly command: Schema.Union<readonly [Schema.Literals<readonly ["session.list", "session.new", "session.interrupt", "session.background", "session.compact", "session.page.up", "session.page.down", "session.line.up", "session.line.down", "session.half.page.up", "session.half.page.down", "session.first", "session.last", "prompt.clear", "prompt.submit", "agent.cycle"]>, Schema.String]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"tui.toast.show">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly message: Schema.String;
        readonly variant: Schema.Literals<readonly ["info", "success", "warning", "error"]>;
        readonly duration: Schema.withDecodingDefault<Schema.Int, never>;
    }>;
}> & {
    type: "tui.toast.show";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly message: Schema.String;
        readonly variant: Schema.Literals<readonly ["info", "success", "warning", "error"]>;
        readonly duration: Schema.withDecodingDefault<Schema.Int, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"tui.session.select">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID">;
    }>;
}> & {
    type: "tui.session.select";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID">;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"installation.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly version: Schema.String;
    }>;
}> & {
    type: "installation.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly version: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"installation.update-available">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly version: Schema.String;
    }>;
}> & {
    type: "installation.update-available";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly version: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"vcs.branch.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly branch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
}> & {
    type: "vcs.branch.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly branch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"mcp.status.changed">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly server: Schema.String;
    }>;
}> & {
    type: "mcp.status.changed";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly server: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"mcp.resources.changed">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly server: Schema.String;
    }>;
}> & {
    type: "mcp.resources.changed";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly server: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly type: Schema.TemplateLiteral<readonly ["rpc.", Schema.String]>;
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Record<Schema.String, Schema.Unknown>;
}>, ...Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>>;
    readonly type: Schema.Literal<"server.connected">;
    readonly data: Schema.Struct<{}>;
}>[]]>>, Schema.Never, {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.agent.selected";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly agent: string & import("effect/Brand").Brand<"Agent.ID">;
        readonly previous?: (string & import("effect/Brand").Brand<"Agent.ID">) | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.archived";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "auto" | "manual";
        readonly model?: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        } | undefined;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
        readonly text: string;
        readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "auto" | "manual";
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly inputID?: (string & import("effect/Brand").Brand<"Session.Message.ID">) | undefined;
        readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "auto" | "manual";
        readonly inputID?: (string & import("effect/Brand").Brand<"Session.Message.ID">) | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.created";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
        readonly location: {
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
        };
        readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
        readonly slug: string;
        readonly title?: string | undefined;
        readonly agent?: (string & import("effect/Brand").Brand<"Agent.ID">) | undefined;
        readonly model?: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        } | undefined;
        readonly metadata?: {
            readonly [x: string]: Schema.Json;
        } | undefined;
        readonly permissions?: readonly {
            readonly action: string;
            readonly resource: string;
            readonly effect: "allow" | "ask" | "deny";
        }[] | undefined;
        readonly version: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.deleted";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.interrupted";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "inactivity" | "shutdown" | "superseded" | "user";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.succeeded";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.forked";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly parentID: string & import("effect/Brand").Brand<"SessionID">;
        readonly boundary: {
            readonly type: "before";
            readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        } | {
            readonly type: "through";
            readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly instructions?: {
            readonly [x: string & import("effect/Brand").Brand<"Instruction.Key">]: string & import("effect/Brand").Brand<"Instruction.Hash">;
        } | undefined;
        readonly instructionEntries?: readonly {
            readonly key: string;
            readonly value: Schema.Json;
            readonly removed: boolean;
        }[] | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.cancelled";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.delivered";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.delivery.changed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly delivery: "queue" | "steer";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.enqueued";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly item: {
            readonly type: "user";
            readonly payload: {
                readonly text: string;
                readonly files?: readonly {
                    readonly data: string;
                    readonly mime: string;
                    readonly source: {
                        readonly type: "inline";
                    } | {
                        readonly type: "uri";
                        readonly uri: string;
                    };
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                }[] | undefined;
                readonly agents?: readonly {
                    readonly name: string;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                }[] | undefined;
                readonly skills?: readonly {
                    readonly id: string & import("effect/Brand").Brand<"Skill.ID">;
                    readonly name: string & import("effect/Brand").Brand<"Skill.Name">;
                    readonly text?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                }[] | undefined;
                readonly metadata?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
            readonly delivery: "queue" | "steer";
        } | {
            readonly type: "synthetic";
            readonly payload: {
                readonly text: string;
                readonly description?: string | undefined;
                readonly metadata?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
            readonly delivery: "queue" | "steer";
        } | {
            readonly type: "compaction";
            readonly payload: {};
            readonly delivery: "queue" | "steer";
        } | {
            readonly type: "move";
            readonly payload: {
                readonly location: {
                    readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                    readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
                };
                readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
                readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
            };
            readonly delivery: "queue" | "steer";
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.instructions.updated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly delta: {
            readonly [x: string]: "removed" | (string & import("effect/Brand").Brand<"Instruction.Hash">);
        };
        readonly text?: string | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.metadata.updated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly metadata: {
            readonly [x: string]: Schema.Json;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.model.selected";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly model: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
        readonly previous?: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.moved";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly location: {
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
        };
        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
        readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.permissions";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly permissions: readonly {
            readonly action: string;
            readonly resource: string;
            readonly effect: "allow" | "ask" | "deny";
        }[];
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.reasoning.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly text: string;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.reasoning.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.renamed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly title: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.retry.scheduled";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly attempt: number;
        readonly at: number;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.cleared";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.committed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly to: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.staged";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly revert: {
            readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
            readonly partID?: string | undefined;
            readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
            readonly files?: readonly {
                readonly file: string;
                readonly patch: string;
                readonly additions: number;
                readonly deletions: number;
                readonly status: "added" | "deleted" | "modified";
                readonly more?: true | undefined;
            }[] | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.shell.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly shell: {
            readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
            readonly status: "exited" | "killed" | "running" | "timeout";
            readonly command: string;
            readonly cwd: string;
            readonly shell: string;
            readonly file: string;
            readonly pid?: number | undefined;
            readonly exit?: number | undefined;
            readonly signal?: string | undefined;
            readonly metadata: {
                readonly [x: string]: unknown;
            };
            readonly time: {
                readonly started: number;
                readonly completed?: number | undefined;
            };
        };
        readonly output: {
            readonly output: string;
            readonly cursor: number;
            readonly size: number;
            readonly truncated: boolean;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.shell.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly shell: {
            readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
            readonly status: "exited" | "killed" | "running" | "timeout";
            readonly command: string;
            readonly cwd: string;
            readonly shell: string;
            readonly file: string;
            readonly pid?: number | undefined;
            readonly exit?: number | undefined;
            readonly signal?: string | undefined;
            readonly metadata: {
                readonly [x: string]: unknown;
            };
            readonly time: {
                readonly started: number;
                readonly completed?: number | undefined;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.skill.activated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly id: string & import("effect/Brand").Brand<"Skill.ID">;
        readonly name: string & import("effect/Brand").Brand<"Skill.Name">;
        readonly text: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly finish: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly rawFinish?: string | undefined;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
        readonly cost: number & import("effect/Brand").Brand<"Money.USD">;
        readonly tokens: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        };
        readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
        readonly files?: readonly (string & import("effect/Brand").Brand<"RelativePath">)[] | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly finish?: "content-filter" | undefined;
        readonly rawFinish?: string | undefined;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
        readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
        readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
        readonly files?: readonly (string & import("effect/Brand").Brand<"RelativePath">)[] | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly agent: string & import("effect/Brand").Brand<"Agent.ID">;
        readonly model: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
        readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
        readonly started: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.streamed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.synthetic";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly text: string;
        readonly description?: string | undefined;
        readonly metadata?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.text.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly text: string;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.text.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.called";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly input: {
            readonly [x: string]: unknown;
        };
        readonly executed: boolean;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly content?: readonly [{
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        }, ...({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[]] | undefined;
        readonly metadata?: {
            readonly [x: string]: Schema.Json;
        } | undefined;
        readonly executed: boolean;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.input.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly text: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.input.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly name: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.success";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly content: readonly [{
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        }, ...({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[]];
        readonly metadata?: {
            readonly [x: string]: Schema.Json;
        } | undefined;
        readonly executed: boolean;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.unarchived";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.viewed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly idle: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "worktree.resolved";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly previous: string & import("effect/Brand").Brand<"Project.ID">;
        readonly adopted?: readonly (string & import("effect/Brand").Brand<"Project.ID">)[] | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "agent.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "artifact.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "command.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "config.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "credential.switched";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly integrationID: string & import("effect/Brand").Brand<"Integration.ID">;
        readonly credentialID: (string & import("effect/Brand").Brand<"Credential.ID">) | null;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "credential.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly integrationID: string & import("effect/Brand").Brand<"Integration.ID">;
        readonly credentialID: string & import("effect/Brand").Brand<"Credential.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "filesystem.changed";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly file: string;
        readonly event: "add" | "change" | "unlink";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "form.cancelled";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"Form.ID">;
        readonly sessionID: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "form.created";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly form: {
            readonly id: string & import("effect/Brand").Brand<"Form.ID">;
            readonly sessionID: string;
            readonly title: string;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly fields: readonly [{
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "string";
                readonly format?: "date" | "date-time" | "email" | "uri" | undefined;
                readonly minLength?: number | undefined;
                readonly maxLength?: number | undefined;
                readonly pattern?: string | undefined;
                readonly placeholder?: string | undefined;
                readonly default?: string | undefined;
                readonly options?: readonly {
                    readonly value: string;
                    readonly label: string;
                    readonly description?: string | undefined;
                }[] | undefined;
                readonly custom?: boolean | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "number";
                readonly minimum?: number | undefined;
                readonly maximum?: number | undefined;
                readonly default?: number | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "integer";
                readonly minimum?: number | undefined;
                readonly maximum?: number | undefined;
                readonly default?: number | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "boolean";
                readonly default?: boolean | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "multiselect";
                readonly options: readonly {
                    readonly value: string;
                    readonly label: string;
                    readonly description?: string | undefined;
                }[];
                readonly minItems?: number | undefined;
                readonly maxItems?: number | undefined;
                readonly custom?: boolean | undefined;
                readonly default?: readonly string[] | undefined;
            } | {
                readonly key: string;
                readonly type: "external";
                readonly url: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
            }, ...({
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "string";
                readonly format?: "date" | "date-time" | "email" | "uri" | undefined;
                readonly minLength?: number | undefined;
                readonly maxLength?: number | undefined;
                readonly pattern?: string | undefined;
                readonly placeholder?: string | undefined;
                readonly default?: string | undefined;
                readonly options?: readonly {
                    readonly value: string;
                    readonly label: string;
                    readonly description?: string | undefined;
                }[] | undefined;
                readonly custom?: boolean | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "number";
                readonly minimum?: number | undefined;
                readonly maximum?: number | undefined;
                readonly default?: number | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "integer";
                readonly minimum?: number | undefined;
                readonly maximum?: number | undefined;
                readonly default?: number | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "boolean";
                readonly default?: boolean | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "multiselect";
                readonly options: readonly {
                    readonly value: string;
                    readonly label: string;
                    readonly description?: string | undefined;
                }[];
                readonly minItems?: number | undefined;
                readonly maxItems?: number | undefined;
                readonly custom?: boolean | undefined;
                readonly default?: readonly string[] | undefined;
            } | {
                readonly key: string;
                readonly type: "external";
                readonly url: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
            })[]];
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "form.replied";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"Form.ID">;
        readonly sessionID: string;
        readonly answer: {
            readonly [x: string]: string | number | boolean | readonly string[];
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "installation.update-available";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly version: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "installation.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly version: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "integration.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "location.shutdown";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "mcp.resources.changed";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly server: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "mcp.status.changed";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly server: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "model.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "models-dev.refreshed";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "permission.asked";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly action: string;
        readonly resources: readonly string[];
        readonly save?: readonly string[] | undefined;
        readonly metadata?: {
            readonly [x: string]: unknown;
        } | undefined;
        readonly source?: {
            readonly type: "tool";
            readonly messageID: string;
            readonly id: string;
        } | undefined;
        readonly message?: string | undefined;
        readonly id: string & import("effect/Brand").Brand<"Permission.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "permission.replied";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly requestID: string & import("effect/Brand").Brand<"Permission.ID">;
        readonly reply: "always" | "once" | "reject";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "persistent-pty.added";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly terminal: {
            readonly id: string & import("effect/Brand").Brand<"PtyID">;
            readonly title: string;
            readonly command: string;
            readonly args: readonly string[];
            readonly cwd: string;
            readonly status: "exited" | "running";
            readonly pid: number;
            readonly exitCode?: number | undefined;
            readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            readonly userTitle: string | null;
            readonly foregroundProcess: string | null;
            readonly size: {
                readonly cols: number;
                readonly rows: number;
            };
            readonly output: {
                readonly head: number;
                readonly tail: number;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "persistent-pty.removed";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly ptyID: string & import("effect/Brand").Brand<"PtyID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "persistent-pty.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly terminal: {
            readonly id: string & import("effect/Brand").Brand<"PtyID">;
            readonly title: string;
            readonly command: string;
            readonly args: readonly string[];
            readonly cwd: string;
            readonly status: "exited" | "running";
            readonly pid: number;
            readonly exitCode?: number | undefined;
            readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            readonly userTitle: string | null;
            readonly foregroundProcess: string | null;
            readonly size: {
                readonly cols: number;
                readonly rows: number;
            };
            readonly output: {
                readonly head: number;
                readonly tail: number;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "plugin.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "project.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"Project.ID">;
        readonly canonical: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly vcs?: string | undefined;
        readonly name?: string | undefined;
        readonly icon?: {
            readonly url?: string | undefined;
            readonly override?: string | undefined;
            readonly color?: string | undefined;
        } | undefined;
        readonly commands?: {
            readonly start?: string | undefined;
        } | undefined;
        readonly time: {
            readonly created: number;
            readonly updated: number;
            readonly active: number;
            readonly archived?: number | undefined;
        };
        readonly sandboxes: readonly string[];
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "provider.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "pty.created";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly info: {
            readonly id: string & import("effect/Brand").Brand<"PtyID">;
            readonly title: string;
            readonly command: string;
            readonly args: readonly string[];
            readonly cwd: string;
            readonly status: "exited" | "running";
            readonly pid: number;
            readonly exitCode?: number | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "pty.deleted";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"PtyID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "pty.exited";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"PtyID">;
        readonly exitCode: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "pty.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly info: {
            readonly id: string & import("effect/Brand").Brand<"PtyID">;
            readonly title: string;
            readonly command: string;
            readonly args: readonly string[];
            readonly cwd: string;
            readonly status: "exited" | "running";
            readonly pid: number;
            readonly exitCode?: number | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "reference.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.delta";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly text: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.idle";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.reasoning.delta";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly delta: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.status";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly status: {
            readonly type: "idle";
        } | {
            readonly type: "busy";
        } | {
            readonly type: "retry";
            readonly attempt: number;
            readonly message: string;
            readonly action?: {
                readonly reason: string;
                readonly provider: string;
                readonly title: string;
                readonly message: string;
                readonly label: string;
                readonly link?: string | undefined;
            } | undefined;
            readonly next: number;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.text.delta";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly delta: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.input.delta";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly delta: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.progress";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly metadata: {
            readonly [x: string]: Schema.Json;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.usage.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly cost: number & import("effect/Brand").Brand<"Money.USD">;
        readonly tokens: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "shell.created";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly info: {
            readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
            readonly status: "exited" | "killed" | "running" | "timeout";
            readonly command: string;
            readonly cwd: string;
            readonly shell: string;
            readonly file: string;
            readonly pid?: number | undefined;
            readonly exit?: number | undefined;
            readonly signal?: string | undefined;
            readonly metadata: {
                readonly [x: string]: unknown;
            };
            readonly time: {
                readonly started: number;
                readonly completed?: number | undefined;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "shell.deleted";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "shell.exited";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
        readonly exit?: number | undefined;
        readonly status: "exited" | "killed" | "running" | "timeout";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "skill.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "tui.command.execute";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly command: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "tui.prompt.append";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly text: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "tui.session.select";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "tui.toast.show";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly title?: string | undefined;
        readonly message: string;
        readonly variant: "error" | "info" | "success" | "warning";
        readonly duration: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "vcs.branch.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly branch?: string | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "websearch.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "worktree.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: `rpc.${string}`;
    readonly location: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
    };
    readonly data: {
        readonly [x: string]: unknown;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
    } | undefined;
    readonly type: "server.connected";
    readonly data: {};
}>, never, never, never>, false>;
export declare const OpenCodeEvent: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"location.shutdown">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "location.shutdown";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"models-dev.refreshed">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "models-dev.refreshed";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"credential.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
        readonly credentialID: Schema.brand<Schema.String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        };
    }>;
}> & {
    type: "credential.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
        readonly credentialID: Schema.brand<Schema.String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"credential.switched">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
        readonly credentialID: Schema.NullOr<Schema.brand<Schema.String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        }>;
    }>;
}> & {
    type: "credential.switched";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
        readonly credentialID: Schema.NullOr<Schema.brand<Schema.String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"integration.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "integration.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"provider.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "provider.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"model.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "model.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"agent.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "agent.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.created">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly slug: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly version: Schema.String;
    }>;
}> & {
    type: "session.created";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly slug: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly version: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.agent.selected">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
    }>;
}> & {
    type: "session.agent.selected";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.model.selected">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>;
}> & {
    type: "session.model.selected";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.moved">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.moved";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.renamed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly title: Schema.String;
    }>;
}> & {
    type: "session.renamed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly title: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.metadata.updated">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>;
}> & {
    type: "session.metadata.updated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.permissions">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly permissions: Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>;
    }>;
}> & {
    type: "session.permissions";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly permissions: Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.viewed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly idle: Schema.Finite;
    }>;
}> & {
    type: "session.viewed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly idle: Schema.Finite;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.archived">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.archived";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.unarchived">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.unarchived";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.usage.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
    }>;
}> & {
    type: "session.usage.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.deleted">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.deleted";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.forked">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly boundary: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"before">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"through">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>]>;
        readonly instructions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>>, Schema.optionalKey<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>, never, never>;
        readonly instructionEntries: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>, never, never>;
    }>;
}> & {
    type: "session.forked";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly boundary: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"before">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"through">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>]>;
        readonly instructions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>>, Schema.optionalKey<Schema.$Record<Schema.brand<Schema.String, "Instruction.Key">, Schema.brand<Schema.String, "Instruction.Hash">>>, never, never>;
        readonly instructionEntries: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
            readonly removed: Schema.Boolean;
        }>>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.delivered">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.inbox.delivered";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.enqueued">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly item: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"user">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>, never, never>;
                readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"synthetic">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"compaction">;
            readonly payload: Schema.Struct<{}>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"move">;
            readonly payload: Schema.Struct<{
                readonly location: Schema.Struct<{
                    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
                    readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>, never, never>;
                }>;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>]>;
    }>;
}> & {
    type: "session.inbox.enqueued";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly item: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"user">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly data: Schema.String;
                    readonly mime: Schema.String;
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"inline">;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"uri">;
                        readonly uri: Schema.String;
                    }>]>;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema/prompt").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>, never, never>;
                readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly name: Schema.String;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Skill.ID">;
                    readonly name: Schema.brand<Schema.String, "Skill.Name">;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                        readonly text: Schema.String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"synthetic">;
            readonly payload: Schema.Struct<{
                readonly text: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"compaction">;
            readonly payload: Schema.Struct<{}>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"move">;
            readonly payload: Schema.Struct<{
                readonly location: Schema.Struct<{
                    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
                    readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>, never, never>;
                }>;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
            }>;
            readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
        }>]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.cancelled">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.inbox.cancelled";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.inbox.delivery.changed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    }>;
}> & {
    type: "session.inbox.delivery.changed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.execution.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.succeeded">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.execution.succeeded";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}> & {
    type: "session.execution.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.execution.interrupted">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["user", "shutdown", "superseded", "inactivity"]>;
    }>;
}> & {
    type: "session.execution.interrupted";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["user", "shutdown", "superseded", "inactivity"]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.instructions.updated">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly delta: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.brand<Schema.String, "Instruction.Hash">, Schema.Literal<"removed">]>>;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
}> & {
    type: "session.instructions.updated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly delta: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.brand<Schema.String, "Instruction.Hash">, Schema.Literal<"removed">]>>;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.synthetic">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.synthetic";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.skill.activated">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.String;
    }>;
}> & {
    type: "session.skill.activated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.shell.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
    }>;
}> & {
    type: "session.shell.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.shell.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
        readonly output: Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>;
    }>;
}> & {
    type: "session.shell.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
        readonly output: Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly started: Schema.Int;
    }>;
}> & {
    type: "session.step.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly started: Schema.Int;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.streamed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.step.streamed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly finish: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}> & {
    type: "session.step.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly finish: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.step.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["content-filter"]>>>, Schema.optionalKey<Schema.Literals<readonly ["content-filter"]>>, never, never>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}> & {
    type: "session.step.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["content-filter"]>>>, Schema.optionalKey<Schema.Literals<readonly ["content-filter"]>>, never, never>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.text.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
    }>;
}> & {
    type: "session.text.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.text.delta">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly delta: Schema.String;
    }>;
}> & {
    type: "session.text.delta";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly delta: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.text.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.text.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.reasoning.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.reasoning.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.reasoning.delta">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly delta: Schema.String;
    }>;
}> & {
    type: "session.reasoning.delta";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly delta: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.reasoning.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.reasoning.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: Schema.Int;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.input.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly name: Schema.String;
    }>;
}> & {
    type: "session.tool.input.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly name: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.input.delta">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly delta: Schema.String;
    }>;
}> & {
    type: "session.tool.input.delta";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly delta: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.input.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly text: Schema.String;
    }>;
}> & {
    type: "session.tool.input.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly text: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.called">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.called";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.progress">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>;
}> & {
    type: "session.tool.progress";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.success">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.success";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.tool.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: Schema.String;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly executed: Schema.Boolean;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.retry.scheduled">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly attempt: Schema.Int;
        readonly at: Schema.Int;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}> & {
    type: "session.retry.scheduled";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly attempt: Schema.Int;
        readonly at: Schema.Int;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.compaction.started">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
    }>;
}> & {
    type: "session.compaction.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.compaction.delta">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: Schema.String;
    }>;
}> & {
    type: "session.compaction.delta";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.compaction.ended">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly text: Schema.String;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}> & {
    type: "session.compaction.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly text: Schema.String;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.compaction.failed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}> & {
    type: "session.compaction.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly inputID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.revert.staged">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly revert: Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>;
    }>;
}> & {
    type: "session.revert.staged";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly revert: Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.revert.cleared">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.revert.cleared";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.revert.committed">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly to: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.revert.committed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly to: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"filesystem.changed">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly file: Schema.String;
        readonly event: Schema.Literals<readonly ["add", "change", "unlink"]>;
    }>;
}> & {
    type: "filesystem.changed";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly file: Schema.String;
        readonly event: Schema.Literals<readonly ["add", "change", "unlink"]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"reference.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "reference.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"permission.asked">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly action: Schema.String;
        readonly resources: Schema.$Array<Schema.String>;
        readonly save: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>, never, never>;
        readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly id: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
    }>;
}> & {
    type: "permission.asked";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly action: Schema.String;
        readonly resources: Schema.$Array<Schema.String>;
        readonly save: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"tool">;
            readonly messageID: Schema.String;
            readonly id: Schema.String;
        }>]>>, never, never>;
        readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly id: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"permission.replied">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly requestID: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
        readonly reply: Schema.Literals<readonly ["once", "always", "reject"]>;
    }>;
}> & {
    type: "permission.replied";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly requestID: Schema.brand<Schema.String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
        readonly reply: Schema.Literals<readonly ["once", "always", "reject"]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"plugin.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "plugin.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"project.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly canonical: Schema.brand<Schema.String, "AbsolutePath">;
        readonly vcs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly icon: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly override: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly color: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly override: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly color: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly commands: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.Int;
            readonly updated: Schema.Int;
            readonly active: Schema.Int;
            readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly sandboxes: Schema.$Array<Schema.String>;
    }>;
}> & {
    type: "project.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly canonical: Schema.brand<Schema.String, "AbsolutePath">;
        readonly vcs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly icon: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly override: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly color: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly override: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly color: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly commands: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.Int;
            readonly updated: Schema.Int;
            readonly active: Schema.Int;
            readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly sandboxes: Schema.$Array<Schema.String>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"worktree.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
    }>;
}> & {
    type: "worktree.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"worktree.resolved">;
    readonly durable: Schema.Struct<{
        readonly aggregateID: Schema.String;
        readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
        readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
    }>;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly previous: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly adopted: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, never, never>;
    }>;
}> & {
    type: "worktree.resolved";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: Schema.Struct<{
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly previous: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly adopted: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"command.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "command.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"config.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "config.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"skill.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "skill.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"pty.created">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}> & {
    type: "pty.created";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"pty.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}> & {
    type: "pty.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"pty.exited">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly exitCode: Schema.Int;
    }>;
}> & {
    type: "pty.exited";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly exitCode: Schema.Int;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"pty.deleted">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}> & {
    type: "pty.deleted";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"persistent-pty.added">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
}> & {
    type: "persistent-pty.added";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"persistent-pty.removed">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}> & {
    type: "persistent-pty.removed";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"persistent-pty.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
}> & {
    type: "persistent-pty.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"shell.created">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
    }>;
}> & {
    type: "shell.created";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: Schema.String;
            readonly cwd: Schema.String;
            readonly shell: Schema.String;
            readonly file: Schema.String;
            readonly pid: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly signal: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly time: Schema.Struct<{
                readonly started: Schema.Finite;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            }>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"shell.exited">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
    }>;
}> & {
    type: "shell.exited";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"shell.deleted">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
    }>;
}> & {
    type: "shell.deleted";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"form.created">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly form: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
            readonly title: Schema.String;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>;
        }>;
    }>;
}> & {
    type: "form.created";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly form: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
            readonly title: Schema.String;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>;
        }>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"form.replied">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: Schema.String;
        readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
    }>;
}> & {
    type: "form.replied";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: Schema.String;
        readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"form.cancelled">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: Schema.String;
    }>;
}> & {
    type: "form.cancelled";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"websearch.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "websearch.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"artifact.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{}>;
}> & {
    type: "artifact.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{}>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.status">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"idle">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"retry">;
            readonly attempt: Schema.Int;
            readonly message: Schema.String;
            readonly action: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly reason: Schema.String;
                readonly provider: Schema.String;
                readonly title: Schema.String;
                readonly message: Schema.String;
                readonly label: Schema.String;
                readonly link: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly reason: Schema.String;
                readonly provider: Schema.String;
                readonly title: Schema.String;
                readonly message: Schema.String;
                readonly label: Schema.String;
                readonly link: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>, never, never>;
            readonly next: Schema.Int;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"busy">;
        }>]>;
    }>;
}> & {
    type: "session.status";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"idle">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"retry">;
            readonly attempt: Schema.Int;
            readonly message: Schema.String;
            readonly action: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly reason: Schema.String;
                readonly provider: Schema.String;
                readonly title: Schema.String;
                readonly message: Schema.String;
                readonly label: Schema.String;
                readonly link: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly reason: Schema.String;
                readonly provider: Schema.String;
                readonly title: Schema.String;
                readonly message: Schema.String;
                readonly label: Schema.String;
                readonly link: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>, never, never>;
            readonly next: Schema.Int;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"busy">;
        }>]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.idle">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.idle";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"tui.prompt.append">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly text: Schema.String;
    }>;
}> & {
    type: "tui.prompt.append";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly text: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"tui.command.execute">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly command: Schema.Union<readonly [Schema.Literals<readonly ["session.list", "session.new", "session.interrupt", "session.background", "session.compact", "session.page.up", "session.page.down", "session.line.up", "session.line.down", "session.half.page.up", "session.half.page.down", "session.first", "session.last", "prompt.clear", "prompt.submit", "agent.cycle"]>, Schema.String]>;
    }>;
}> & {
    type: "tui.command.execute";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly command: Schema.Union<readonly [Schema.Literals<readonly ["session.list", "session.new", "session.interrupt", "session.background", "session.compact", "session.page.up", "session.page.down", "session.line.up", "session.line.down", "session.half.page.up", "session.half.page.down", "session.first", "session.last", "prompt.clear", "prompt.submit", "agent.cycle"]>, Schema.String]>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"tui.toast.show">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly message: Schema.String;
        readonly variant: Schema.Literals<readonly ["info", "success", "warning", "error"]>;
        readonly duration: Schema.withDecodingDefault<Schema.Int, never>;
    }>;
}> & {
    type: "tui.toast.show";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly message: Schema.String;
        readonly variant: Schema.Literals<readonly ["info", "success", "warning", "error"]>;
        readonly duration: Schema.withDecodingDefault<Schema.Int, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"tui.session.select">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID">;
    }>;
}> & {
    type: "tui.session.select";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID">;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"installation.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly version: Schema.String;
    }>;
}> & {
    type: "installation.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly version: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"installation.update-available">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly version: Schema.String;
    }>;
}> & {
    type: "installation.update-available";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly version: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"vcs.branch.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly branch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
}> & {
    type: "vcs.branch.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly branch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"mcp.status.changed">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly server: Schema.String;
    }>;
}> & {
    type: "mcp.status.changed";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly server: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"mcp.resources.changed">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly server: Schema.String;
    }>;
}> & {
    type: "mcp.resources.changed";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly server: Schema.String;
    }>;
}, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly type: Schema.TemplateLiteral<readonly ["rpc.", Schema.String]>;
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Record<Schema.String, Schema.Unknown>;
}>, ...Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>>;
    readonly type: Schema.Literal<"server.connected">;
    readonly data: Schema.Struct<{}>;
}>[]]>;
export type OpenCodeEvent = typeof OpenCodeEvent.Type;
export type OpenCodeEventEncoded = typeof OpenCodeEvent.Encoded;
export declare const isOpenCodeEvent: (event: {
    readonly type: string;
}) => event is OpenCodeEvent;
