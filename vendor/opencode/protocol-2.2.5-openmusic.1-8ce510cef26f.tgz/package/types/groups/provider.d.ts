import { Provider } from "@opencode/schema/provider";
import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup } from "effect/http-api";
import { ProviderNotFoundError, ServiceUnavailableError } from "../errors.js";
export declare const ProviderGroup: HttpApiGroup.HttpApiGroup<"server.provider", HttpApiEndpoint.HttpApiEndpoint<"provider.get", "GET", "/api/provider/:providerID", Schema.toCodecStringTree<Schema.Struct<{
    providerID: Schema.brand<Schema.String, "Provider.ID"> & {
        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
        openai: string & import("effect/Brand").Brand<"Provider.ID">;
        google: string & import("effect/Brand").Brand<"Provider.ID">;
        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
        azure: string & import("effect/Brand").Brand<"Provider.ID">;
        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
            readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>, never, never>;
            readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
            readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>, never, never>;
            readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>, never, never>;
        readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
        readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
        readonly id: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly canonical: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        }>, never, never>;
        readonly integrationID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Integration.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Integration.ID">>, never, never>;
        readonly name: Schema.String;
        readonly activation: Schema.Literals<readonly ["auto", "enabled", "disabled"]>;
        readonly package: Schema.String;
        readonly compatibility: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<import("@opencode/schema/model-compatibility").ReasoningField, import("@opencode/schema/model-compatibility").ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<import("@opencode/schema/model-compatibility").ReasoningField, import("@opencode/schema/model-compatibility").ReasoningField, never, never>>, never, never>;
            readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
            readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
            readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<import("@opencode/schema/model-compatibility").ReasoningField, import("@opencode/schema/model-compatibility").ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<import("@opencode/schema/model-compatibility").ReasoningField, import("@opencode/schema/model-compatibility").ReasoningField, never, never>>, never, never>;
            readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
            readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
            readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
        }>>, never, never>;
    }> & {
        empty: (id: Provider.ID) => Provider.Info;
    };
}>>, Schema.toCodecJson<typeof ServiceUnavailableError | typeof ProviderNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"provider.list", "GET", "/api/provider", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
            readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>, never, never>;
            readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
            readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>, never, never>;
            readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>, never, never>;
        readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
        readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
        readonly id: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly canonical: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        }>, never, never>;
        readonly integrationID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Integration.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Integration.ID">>, never, never>;
        readonly name: Schema.String;
        readonly activation: Schema.Literals<readonly ["auto", "enabled", "disabled"]>;
        readonly package: Schema.String;
        readonly compatibility: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<import("@opencode/schema/model-compatibility").ReasoningField, import("@opencode/schema/model-compatibility").ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<import("@opencode/schema/model-compatibility").ReasoningField, import("@opencode/schema/model-compatibility").ReasoningField, never, never>>, never, never>;
            readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
            readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
            readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<import("@opencode/schema/model-compatibility").ReasoningField, import("@opencode/schema/model-compatibility").ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<import("@opencode/schema/model-compatibility").ReasoningField, import("@opencode/schema/model-compatibility").ReasoningField, never, never>>, never, never>;
            readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
            readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
            readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
        }>>, never, never>;
    }> & {
        empty: (id: Provider.ID) => Provider.Info;
    }>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError>, never, never>, false>;
