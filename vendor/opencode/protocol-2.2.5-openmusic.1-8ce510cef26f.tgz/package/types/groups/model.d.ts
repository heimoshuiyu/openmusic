import { Model } from "@opencode/schema/model";
import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup } from "effect/http-api";
import { ServiceUnavailableError } from "../errors.js";
export declare const ModelGroup: HttpApiGroup.HttpApiGroup<"server.model", HttpApiEndpoint.HttpApiEndpoint<"model.default", "GET", "/api/model/default", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.UndefinedOr<Schema.Struct<{
        readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>, never, never>;
        readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
        readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly modelID: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly canonical: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        }>, never, never>;
        readonly type: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Model.Type, Model.Type, never, never>>>, Schema.optionalKey<Schema.Codec<Model.Type, Model.Type, never, never>>, never, never>;
        readonly family: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.Family">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.Family">>, never, never>;
        readonly name: Schema.String;
        readonly compatibility: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>, never, never>;
            readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
            readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
            readonly supportsThinkingBlockBinding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsEffortUpdates: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>, never, never>;
            readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
            readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
            readonly supportsThinkingBlockBinding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsEffortUpdates: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
        }>>, never, never>;
        readonly package: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly capabilities: Schema.Struct<{
            readonly tools: Schema.Boolean;
            readonly input: Schema.$Array<Schema.String>;
            readonly output: Schema.$Array<Schema.String>;
            readonly temperature: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }> & {
            default: () => {
                tools: true;
                input: string[];
                output: string[];
            };
        };
        readonly variants: Schema.$Array<Schema.Struct<{
            readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
            readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
            readonly id: Schema.brand<Schema.String, "Model.VariantID">;
            readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
                readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"summary">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"native">;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"summary">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"native">;
                }>]>>, never, never>;
                readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
                readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"summary">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"native">;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"summary">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"native">;
                }>]>>, never, never>;
                readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>, never, never>;
        }>>;
        readonly time: Schema.Struct<{
            readonly released: Schema.Finite;
        }>;
        readonly cost: Schema.$Array<Schema.Struct<{
            readonly tier: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly type: Schema.tag<"context">;
                readonly size: Schema.Int;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly type: Schema.tag<"context">;
                readonly size: Schema.Int;
            }>>, never, never>;
            readonly input: Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
                zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
            };
            readonly output: Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
                zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
            };
            readonly cache: Schema.Struct<{
                readonly read: Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
                    zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
                };
                readonly write: Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
                    zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
                };
            }>;
        }>>;
        readonly status: Schema.Literals<readonly ["alpha", "beta", "deprecated", "active"]>;
        readonly enabled: Schema.Boolean;
        readonly limit: Schema.Struct<{
            readonly context: Schema.Int;
            readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly output: Schema.Int;
        }>;
    }> & {
        default: (providerID: import("@opencode/schema/provider").ID, id: Model.ID) => {
            id: string & import("effect/Brand").Brand<"Model.ID">;
            modelID: string & import("effect/Brand").Brand<"Model.ID">;
            providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            name: string & import("effect/Brand").Brand<"Model.ID">;
            capabilities: {
                tools: true;
                input: string[];
                output: string[];
            };
            variants: never[];
            time: {
                released: number;
            };
            cost: never[];
            status: "active";
            enabled: true;
            limit: {
                context: number;
                output: number;
            };
        };
    }>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"model.list", "GET", "/api/model", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
    readonly types: Schema.optional<Schema.ArrayEnsure<Schema.Codec<Model.Type, Model.Type, never, never>>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
                readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>, never, never>;
            }>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>, never, never>;
        readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
        readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly modelID: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly canonical: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        }>, never, never>;
        readonly type: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Model.Type, Model.Type, never, never>>>, Schema.optionalKey<Schema.Codec<Model.Type, Model.Type, never, never>>, never, never>;
        readonly family: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.Family">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.Family">>, never, never>;
        readonly name: Schema.String;
        readonly compatibility: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>, never, never>;
            readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
            readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
            readonly supportsThinkingBlockBinding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsEffortUpdates: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>, never, never>;
            readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
            readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
            readonly supportsThinkingBlockBinding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly supportsEffortUpdates: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
        }>>, never, never>;
        readonly package: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly capabilities: Schema.Struct<{
            readonly tools: Schema.Boolean;
            readonly input: Schema.$Array<Schema.String>;
            readonly output: Schema.$Array<Schema.String>;
            readonly temperature: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }> & {
            default: () => {
                tools: true;
                input: string[];
                output: string[];
            };
        };
        readonly variants: Schema.$Array<Schema.Struct<{
            readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
            readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
            readonly id: Schema.brand<Schema.String, "Model.VariantID">;
            readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
                readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"summary">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"native">;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"summary">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"native">;
                }>]>>, never, never>;
                readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
                readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"summary">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"native">;
                }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"summary">;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"native">;
                }>]>>, never, never>;
                readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>, never, never>;
        }>>;
        readonly time: Schema.Struct<{
            readonly released: Schema.Finite;
        }>;
        readonly cost: Schema.$Array<Schema.Struct<{
            readonly tier: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly type: Schema.tag<"context">;
                readonly size: Schema.Int;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly type: Schema.tag<"context">;
                readonly size: Schema.Int;
            }>>, never, never>;
            readonly input: Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
                zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
            };
            readonly output: Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
                zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
            };
            readonly cache: Schema.Struct<{
                readonly read: Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
                    zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
                };
                readonly write: Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
                    zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
                };
            }>;
        }>>;
        readonly status: Schema.Literals<readonly ["alpha", "beta", "deprecated", "active"]>;
        readonly enabled: Schema.Boolean;
        readonly limit: Schema.Struct<{
            readonly context: Schema.Int;
            readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly output: Schema.Int;
        }>;
    }> & {
        default: (providerID: import("@opencode/schema/provider").ID, id: Model.ID) => {
            id: string & import("effect/Brand").Brand<"Model.ID">;
            modelID: string & import("effect/Brand").Brand<"Model.ID">;
            providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            name: string & import("effect/Brand").Brand<"Model.ID">;
            capabilities: {
                tools: true;
                input: string[];
                output: string[];
            };
            variants: never[];
            time: {
                released: number;
            };
            cost: never[];
            status: "active";
            enabled: true;
            limit: {
                context: number;
                output: number;
            };
        };
    }>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError>, never, never>, false>;
