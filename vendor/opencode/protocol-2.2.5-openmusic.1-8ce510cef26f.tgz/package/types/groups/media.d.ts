import { Schema } from "effect";
import { HttpApiEndpoint } from "effect/http-api";
import { FileNotFoundError, InvalidRequestError } from "../errors.js";
export declare const MediaHash: Schema.String;
/** Lives in the `server.experimental` group (see `groups/experimental.ts`). */
export declare const MediaGetEndpoint: HttpApiEndpoint.HttpApiEndpoint<"media.get", "GET", "/api/experimental/media/:hash", Schema.toCodecStringTree<Schema.Struct<{
    hash: Schema.String;
}>>, never, never, never, Schema.toCodecJson<Schema.Uint8Array>, Schema.toCodecJson<typeof InvalidRequestError | typeof FileNotFoundError>, never, never>;
