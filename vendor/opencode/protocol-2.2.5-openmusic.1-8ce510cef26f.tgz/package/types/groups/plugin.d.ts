import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiSchema } from "effect/http-api";
import { InvalidRequestError, PluginNotFoundError, ServiceUnavailableError } from "../errors.js";
export declare const PluginGroup: HttpApiGroup.HttpApiGroup<"server.plugin", HttpApiEndpoint.HttpApiEndpoint<"plugin.check", "POST", "/api/plugin/check", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly target: Schema.optional<Schema.String>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Plugin.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Plugin.ID">>, never, never>;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"builtin">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"package">;
            readonly target: Schema.String;
            readonly version: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly outdated: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            readonly updating: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"local">;
            readonly path: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"sdk">;
        }>]>;
        readonly features: Schema.Struct<{
            readonly server: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            readonly tui: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            readonly rpc: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            readonly gui: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
        }>;
        readonly state: Schema.Union<readonly [Schema.Struct<{
            readonly status: Schema.Literal<"active">;
        }>, Schema.Struct<{
            readonly status: Schema.Literal<"failed">;
            readonly error: Schema.String;
            readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>;
    }>>;
}>>, Schema.toCodecJson<typeof InvalidRequestError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"plugin.gui", "GET", "/api/plugin/gui", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
    readonly id: Schema.brand<Schema.String, "Plugin.ID">;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly code: Schema.String;
        readonly revision: Schema.String;
        readonly options: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>;
}>>, Schema.toCodecJson<typeof PluginNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"plugin.list", "GET", "/api/plugin", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Plugin.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Plugin.ID">>, never, never>;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"builtin">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"package">;
            readonly target: Schema.String;
            readonly version: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly outdated: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            readonly updating: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"local">;
            readonly path: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"sdk">;
        }>]>;
        readonly features: Schema.Struct<{
            readonly server: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            readonly tui: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            readonly rpc: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            readonly gui: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
        }>;
        readonly state: Schema.Union<readonly [Schema.Struct<{
            readonly status: Schema.Literal<"active">;
        }>, Schema.Struct<{
            readonly status: Schema.Literal<"failed">;
            readonly error: Schema.String;
            readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>;
    }>>;
}>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"plugin.update", "POST", "/api/plugin/update", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly targets: Schema.$Array<Schema.String>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof InvalidRequestError | typeof ServiceUnavailableError>, never, never>, false>;
