import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiSchema } from "effect/http-api";
import { ConflictError, InvalidRequestError } from "../errors.js";
export declare const CredentialGroup: HttpApiGroup.HttpApiGroup<"server.credential", HttpApiEndpoint.HttpApiEndpoint<"credential.activate", "POST", "/api/credential/:credentialID/activate", Schema.toCodecStringTree<Schema.Struct<{
    credentialID: Schema.brand<Schema.String, "Credential.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Credential.ID">;
    };
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"credential.create", "POST", "/api/credential", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Credential.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Credential.ID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Credential.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Credential.ID">;
    }>, never, never>;
    readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
    readonly label: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly value: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"oauth">;
        readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
        readonly refresh: Schema.String;
        readonly access: Schema.String;
        readonly expires: Schema.Int;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"key">;
        readonly key: Schema.String;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"external">;
        readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>]>;
    readonly activate: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        };
        readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
        readonly label: Schema.String;
        readonly active: Schema.Boolean;
        readonly value: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"oauth">;
            readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
            readonly refresh: Schema.String;
            readonly access: Schema.String;
            readonly expires: Schema.Int;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"key">;
            readonly key: Schema.String;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"external">;
            readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>]>;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof ConflictError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"credential.list", "GET", "/api/credential", never, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        };
        readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
        readonly label: Schema.String;
        readonly active: Schema.Boolean;
        readonly value: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"oauth">;
            readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
            readonly refresh: Schema.String;
            readonly access: Schema.String;
            readonly expires: Schema.Int;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"key">;
            readonly key: Schema.String;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"external">;
            readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>]>;
    }>>;
}>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"credential.remove", "DELETE", "/api/credential/:credentialID", Schema.toCodecStringTree<Schema.Struct<{
    credentialID: Schema.brand<Schema.String, "Credential.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Credential.ID">;
    };
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"credential.update", "PATCH", "/api/credential/:credentialID", Schema.toCodecStringTree<Schema.Struct<{
    credentialID: Schema.brand<Schema.String, "Credential.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Credential.ID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly label: Schema.String;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, never, never, never>, false>;
