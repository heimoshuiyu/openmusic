import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiSchema } from "effect/http-api";
import { ForbiddenError, InvalidRequestError, PtyFeatureUnsupportedError, PtyNotFoundError, ServiceUnavailableError } from "../errors.js";
import { PTY_CONNECT_TICKET_QUERY, PTY_CONNECT_TOKEN_HEADER, PTY_CONNECT_TOKEN_HEADER_VALUE } from "./pty.js";
export { PTY_CONNECT_TICKET_QUERY, PTY_CONNECT_TOKEN_HEADER, PTY_CONNECT_TOKEN_HEADER_VALUE };
export declare const PERSISTENT_PTY_CONNECT_PATH = "/api/experimental/persistent-pty/:ptyID/connect";
export declare function hasPersistentPtyConnectTicketURL(url: URL): boolean;
export declare const PersistentPtyGroup: HttpApiGroup.HttpApiGroup<"server.experimental", HttpApiEndpoint.HttpApiEndpoint<"persistentPty.connect", "GET", "/api/experimental/persistent-pty/:ptyID/connect", Schema.toCodecStringTree<Schema.Struct<{
    ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Boolean>, Schema.toCodecJson<typeof ServiceUnavailableError | typeof ForbiddenError | typeof PtyNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"persistentPty.connectToken", "POST", "/api/experimental/persistent-pty/:ptyID/connect-token", Schema.toCodecStringTree<Schema.Struct<{
    ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, never, Schema.toCodecStringTree<Schema.Struct<{
    readonly "x-opencode-ticket": Schema.optional<Schema.String>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly ticket: Schema.String;
        readonly expires_in: Schema.Int;
    }>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError | typeof ForbiddenError | typeof PtyNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"persistentPty.create", "POST", "/api/experimental/session/:sessionID/terminal", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly command: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly args: Schema.$Array<Schema.String>;
    readonly cwd: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly title: Schema.String;
    readonly env: Schema.$Record<Schema.String, Schema.String>;
    readonly size: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly cols: Schema.Int;
        readonly rows: Schema.Int;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly cols: Schema.Int;
        readonly rows: Schema.Int;
    }>>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: Schema.String;
        readonly command: Schema.String;
        readonly args: Schema.$Array<Schema.String>;
        readonly cwd: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited"]>;
        readonly pid: Schema.Int;
        readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly userTitle: Schema.NullOr<Schema.String>;
        readonly foregroundProcess: Schema.NullOr<Schema.String>;
        readonly size: Schema.Struct<{
            readonly cols: Schema.Int;
            readonly rows: Schema.Int;
        }>;
        readonly output: Schema.Struct<{
            readonly head: Schema.Int;
            readonly tail: Schema.Int;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof ServiceUnavailableError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"persistentPty.get", "GET", "/api/experimental/persistent-pty/:ptyID", Schema.toCodecStringTree<Schema.Struct<{
    ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: Schema.String;
        readonly command: Schema.String;
        readonly args: Schema.$Array<Schema.String>;
        readonly cwd: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited"]>;
        readonly pid: Schema.Int;
        readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly userTitle: Schema.NullOr<Schema.String>;
        readonly foregroundProcess: Schema.NullOr<Schema.String>;
        readonly size: Schema.Struct<{
            readonly cols: Schema.Int;
            readonly rows: Schema.Int;
        }>;
        readonly output: Schema.Struct<{
            readonly head: Schema.Int;
            readonly tail: Schema.Int;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError | typeof PtyNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"persistentPty.handoff", "POST", "/api/experimental/persistent-pty/handoff", never, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly handoff: Schema.NullOr<Schema.Struct<{
        readonly directory: Schema.String;
        readonly instanceID: Schema.String;
        readonly ticket: Schema.String;
        readonly expiresAt: Schema.Number;
    }>>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"persistentPty.list", "GET", "/api/experimental/session/:sessionID/terminal", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: Schema.String;
        readonly command: Schema.String;
        readonly args: Schema.$Array<Schema.String>;
        readonly cwd: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited"]>;
        readonly pid: Schema.Int;
        readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly userTitle: Schema.NullOr<Schema.String>;
        readonly foregroundProcess: Schema.NullOr<Schema.String>;
        readonly size: Schema.Struct<{
            readonly cols: Schema.Int;
            readonly rows: Schema.Int;
        }>;
        readonly output: Schema.Struct<{
            readonly head: Schema.Int;
            readonly tail: Schema.Int;
        }>;
    }>>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof ServiceUnavailableError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"persistentPty.read", "GET", "/api/experimental/session/:sessionID/terminal/read", Schema.toCodecStringTree<Schema.Struct<{
    sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    lines: Schema.optional<Schema.compose<Schema.Int, Schema.NumberFromString>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.NullOr<Schema.Struct<{
        readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: Schema.String;
        readonly cwd: Schema.String;
        readonly foregroundProcess: Schema.NullOr<Schema.String>;
        readonly screen: Schema.Struct<{
            readonly text: Schema.String;
            readonly cols: Schema.Int;
            readonly rows: Schema.Int;
            readonly cursor: Schema.Struct<{
                readonly x: Schema.Int;
                readonly y: Schema.Int;
            }>;
        }>;
    }>>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"persistentPty.remove", "DELETE", "/api/experimental/persistent-pty/:ptyID", Schema.toCodecStringTree<Schema.Struct<{
    ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof ServiceUnavailableError | typeof PtyNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"persistentPty.shutdown", "POST", "/api/experimental/persistent-pty/shutdown", never, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof ServiceUnavailableError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"persistentPty.snapshot", "GET", "/api/experimental/persistent-pty/:ptyID/snapshot", Schema.toCodecStringTree<Schema.Struct<{
    ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly info: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
        readonly text: Schema.String;
        readonly checkpoint: Schema.Uint8Array;
        readonly cursor: Schema.Struct<{
            readonly x: Schema.Int;
            readonly y: Schema.Int;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError | typeof PtyNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"persistentPty.update", "PUT", "/api/experimental/persistent-pty/:ptyID", Schema.toCodecStringTree<Schema.Struct<{
    ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly attachmentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly size: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly cols: Schema.Int;
        readonly rows: Schema.Int;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly cols: Schema.Int;
        readonly rows: Schema.Int;
    }>>, never, never>;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NullOr<Schema.String>>>, Schema.optionalKey<Schema.NullOr<Schema.String>>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: Schema.String;
        readonly command: Schema.String;
        readonly args: Schema.$Array<Schema.String>;
        readonly cwd: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited"]>;
        readonly pid: Schema.Int;
        readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly userTitle: Schema.NullOr<Schema.String>;
        readonly foregroundProcess: Schema.NullOr<Schema.String>;
        readonly size: Schema.Struct<{
            readonly cols: Schema.Int;
            readonly rows: Schema.Int;
        }>;
        readonly output: Schema.Struct<{
            readonly head: Schema.Int;
            readonly tail: Schema.Int;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError | typeof PtyNotFoundError | typeof PtyFeatureUnsupportedError>, never, never>, false>;
