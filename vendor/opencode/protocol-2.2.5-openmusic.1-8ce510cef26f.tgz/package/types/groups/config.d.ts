import { Config } from "@opencode/schema/config";
import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiSchema } from "effect/http-api";
export declare const ConfigGroup: HttpApiGroup.HttpApiGroup<"server.config", HttpApiEndpoint.HttpApiEndpoint<"config.get", "GET", "/api/config", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.$Array<Schema.Union<readonly [typeof Config.Document, typeof Config.Directory]>>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"config.shells", "GET", "/api/config/shell", never, never, never, never, Schema.toCodecJson<Schema.$Array<Schema.Struct<{
    readonly path: Schema.String;
    readonly name: Schema.String;
    readonly acceptable: Schema.Boolean;
}>>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"config.update", "PATCH", "/api/experimental/config", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly shell: Schema.NullOr<Schema.String>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, never, never, never>, false>;
