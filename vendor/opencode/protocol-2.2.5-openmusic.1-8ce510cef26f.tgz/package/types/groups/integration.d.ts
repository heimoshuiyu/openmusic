import { Integration } from "@opencode/schema/integration";
import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiSchema } from "effect/http-api";
import { IntegrationAttemptNotFoundError, IntegrationMethodNotFoundError, IntegrationNotFoundError, InvalidRequestError } from "../errors.js";
export declare const IntegrationGroup: HttpApiGroup.HttpApiGroup<"server.integration", HttpApiEndpoint.HttpApiEndpoint<"integration.command.cancel", "DELETE", "/api/integration/:integrationID/connect/command/:attemptID", Schema.toCodecStringTree<Schema.Struct<{
    integrationID: Schema.brand<Schema.String, "Integration.ID">;
    attemptID: Schema.brand<Schema.String, "Integration.AttemptID"> & {
        create: () => string & import("effect/Brand").Brand<"Integration.AttemptID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"integration.command.connect", "POST", "/api/integration/:integrationID/connect/command", Schema.toCodecStringTree<Schema.Struct<{
    integrationID: Schema.brand<Schema.String, "Integration.ID">;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly label: Schema.optional<Schema.String>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly attemptID: Schema.brand<Schema.String, "Integration.AttemptID"> & {
            create: () => string & import("effect/Brand").Brand<"Integration.AttemptID">;
        };
        readonly time: Schema.Struct<{
            readonly created: Schema.Number;
            readonly expires: Schema.Number;
        }>;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof IntegrationNotFoundError | typeof IntegrationMethodNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"integration.command.status", "GET", "/api/integration/:integrationID/connect/command/:attemptID", Schema.toCodecStringTree<Schema.Struct<{
    integrationID: Schema.brand<Schema.String, "Integration.ID">;
    attemptID: Schema.brand<Schema.String, "Integration.AttemptID"> & {
        create: () => string & import("effect/Brand").Brand<"Integration.AttemptID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Union<readonly [Schema.Struct<{
        readonly status: Schema.Literal<"pending">;
        readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.Number;
            readonly expires: Schema.Number;
        }>;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"complete">;
        readonly time: Schema.Struct<{
            readonly created: Schema.Number;
            readonly expires: Schema.Number;
        }>;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"failed">;
        readonly message: Schema.String;
        readonly time: Schema.Struct<{
            readonly created: Schema.Number;
            readonly expires: Schema.Number;
        }>;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"expired">;
        readonly time: Schema.Struct<{
            readonly created: Schema.Number;
            readonly expires: Schema.Number;
        }>;
    }>]>;
}>>, Schema.toCodecJson<typeof IntegrationNotFoundError | typeof IntegrationAttemptNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"integration.connect.external", "POST", "/api/integration/:integrationID/connect/external", Schema.toCodecStringTree<Schema.Struct<{
    integrationID: Schema.brand<Schema.String, "Integration.ID">;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly answer: Schema.optional<Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>>;
    readonly label: Schema.optional<Schema.String>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof InvalidRequestError | typeof IntegrationNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"integration.connect.key", "POST", "/api/integration/:integrationID/connect/key", Schema.toCodecStringTree<Schema.Struct<{
    integrationID: Schema.brand<Schema.String, "Integration.ID">;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly key: Schema.String;
    readonly answer: Schema.optional<Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>>;
    readonly label: Schema.optional<Schema.String>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof InvalidRequestError | typeof IntegrationNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"integration.get", "GET", "/api/integration/:integrationID", Schema.toCodecStringTree<Schema.Struct<{
    integrationID: Schema.brand<Schema.String, "Integration.ID">;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Integration.ID">;
        readonly name: Schema.String;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
        readonly methods: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
            readonly type: Schema.Literal<"oauth">;
            readonly label: Schema.String;
            readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, never, never>;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
            readonly type: Schema.Literal<"command">;
            readonly label: Schema.String;
            readonly command: Schema.$Array<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"key">;
            readonly label: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, never, never>;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
            readonly type: Schema.Literal<"external">;
            readonly label: Schema.String;
            readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"env">;
            readonly names: Schema.$Array<Schema.String>;
        }>]>>;
        readonly connections: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"credential">;
            readonly id: Schema.brand<Schema.String, "Credential.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Credential.ID">;
            };
            readonly label: Schema.String;
            readonly method: Schema.Literals<readonly ["key", "oauth", "external"]>;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly status: Schema.Literals<readonly ["needs_auth"]>;
                readonly message: Schema.String;
                readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly status: Schema.Literals<readonly ["needs_auth"]>;
                readonly message: Schema.String;
                readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"env">;
            readonly name: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly status: Schema.Literals<readonly ["needs_auth"]>;
                readonly message: Schema.String;
                readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly status: Schema.Literals<readonly ["needs_auth"]>;
                readonly message: Schema.String;
                readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>, never, never>;
        }>]>>;
    }>;
}>>, Schema.toCodecJson<typeof IntegrationNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"integration.list", "GET", "/api/integration", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Integration.ID">;
        readonly name: Schema.String;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
        readonly methods: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
            readonly type: Schema.Literal<"oauth">;
            readonly label: Schema.String;
            readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, never, never>;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
            readonly type: Schema.Literal<"command">;
            readonly label: Schema.String;
            readonly command: Schema.$Array<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"key">;
            readonly label: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, never, never>;
        }>, Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
            readonly type: Schema.Literal<"external">;
            readonly label: Schema.String;
            readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"string">;
                readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"number">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"integer">;
                readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"boolean">;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly key: Schema.String;
                    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                }>>>, never, never>;
                readonly type: Schema.Literal<"multiselect">;
                readonly options: Schema.$Array<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly label: Schema.String;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>;
                readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            }>, Schema.Struct<{
                readonly key: Schema.String;
                readonly type: Schema.Literal<"external">;
                readonly url: Schema.String;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"env">;
            readonly names: Schema.$Array<Schema.String>;
        }>]>>;
        readonly connections: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"credential">;
            readonly id: Schema.brand<Schema.String, "Credential.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Credential.ID">;
            };
            readonly label: Schema.String;
            readonly method: Schema.Literals<readonly ["key", "oauth", "external"]>;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly status: Schema.Literals<readonly ["needs_auth"]>;
                readonly message: Schema.String;
                readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly status: Schema.Literals<readonly ["needs_auth"]>;
                readonly message: Schema.String;
                readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"env">;
            readonly name: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly status: Schema.Literals<readonly ["needs_auth"]>;
                readonly message: Schema.String;
                readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly status: Schema.Literals<readonly ["needs_auth"]>;
                readonly message: Schema.String;
                readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>, never, never>;
        }>]>>;
    }>>;
}>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"integration.oauth.cancel", "DELETE", "/api/integration/:integrationID/connect/oauth/:attemptID", Schema.toCodecStringTree<Schema.Struct<{
    integrationID: Schema.brand<Schema.String, "Integration.ID">;
    attemptID: Schema.brand<Schema.String, "Integration.AttemptID"> & {
        create: () => string & import("effect/Brand").Brand<"Integration.AttemptID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"integration.oauth.complete", "POST", "/api/integration/:integrationID/connect/oauth/:attemptID/complete", Schema.toCodecStringTree<Schema.Struct<{
    integrationID: Schema.brand<Schema.String, "Integration.ID">;
    attemptID: Schema.brand<Schema.String, "Integration.AttemptID"> & {
        create: () => string & import("effect/Brand").Brand<"Integration.AttemptID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly code: Schema.optional<Schema.String>;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof InvalidRequestError | typeof IntegrationNotFoundError | typeof IntegrationAttemptNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"integration.oauth.connect", "POST", "/api/integration/:integrationID/connect/oauth", Schema.toCodecStringTree<Schema.Struct<{
    integrationID: Schema.brand<Schema.String, "Integration.ID">;
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly answer: Schema.optional<Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>>;
    readonly label: Schema.optional<Schema.String>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: typeof Integration.Attempt;
}>>, Schema.toCodecJson<typeof InvalidRequestError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"integration.oauth.status", "GET", "/api/integration/:integrationID/connect/oauth/:attemptID", Schema.toCodecStringTree<Schema.Struct<{
    integrationID: Schema.brand<Schema.String, "Integration.ID">;
    attemptID: Schema.brand<Schema.String, "Integration.AttemptID"> & {
        create: () => string & import("effect/Brand").Brand<"Integration.AttemptID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Union<readonly [Schema.Struct<{
        readonly status: Schema.Literal<"pending">;
        readonly time: Schema.Struct<{
            readonly created: Schema.Number;
            readonly expires: Schema.Number;
        }>;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"complete">;
        readonly time: Schema.Struct<{
            readonly created: Schema.Number;
            readonly expires: Schema.Number;
        }>;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"failed">;
        readonly message: Schema.String;
        readonly time: Schema.Struct<{
            readonly created: Schema.Number;
            readonly expires: Schema.Number;
        }>;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"expired">;
        readonly time: Schema.Struct<{
            readonly created: Schema.Number;
            readonly expires: Schema.Number;
        }>;
    }>]>;
}>>, Schema.toCodecJson<typeof IntegrationNotFoundError | typeof IntegrationAttemptNotFoundError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"integration.wellknown.add", "POST", "/api/experimental/integration/wellknown", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly url: Schema.String;
}>>, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof InvalidRequestError>, never, never>, false>;
