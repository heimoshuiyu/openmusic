import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiSchema } from "effect/http-api";
import { ConflictError, InvalidRequestError, ServiceUnavailableError } from "../errors.js";
declare const VcsInitNotSupportedError_base: Schema.Class<VcsInitNotSupportedError, Schema.TaggedStruct<"VcsInitNotSupportedError", {
    readonly providerID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class VcsInitNotSupportedError extends VcsInitNotSupportedError_base {
}
export declare const VcsGroup: HttpApiGroup.HttpApiGroup<"server.vcs", HttpApiEndpoint.HttpApiEndpoint<"vcs.base", "GET", "/api/vcs/base", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.NullOr<Schema.Struct<{
        readonly name: Schema.String;
        readonly ref: Schema.String;
        readonly source: Schema.Literals<readonly ["reflog", "default"]>;
    }>>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"vcs.branch.list", "GET", "/api/vcs/branch", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
    readonly search: Schema.optional<Schema.String>;
    readonly limit: Schema.optional<Schema.compose<Schema.Int, Schema.NumberFromString>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.String>;
}>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"vcs.diff", "GET", "/api/vcs/diff", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
    readonly mode: Schema.Literals<readonly ["working", "branch", "committed"]>;
    readonly base: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly context: Schema.optional<Schema.compose<Schema.Int, Schema.NumberFromString>>;
    readonly untracked: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["files", "folders"]>>>, Schema.optionalKey<Schema.Literals<readonly ["files", "folders"]>>, never, never>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly file: Schema.String;
        readonly patch: Schema.String;
        readonly additions: Schema.Int;
        readonly deletions: Schema.Int;
        readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
        readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
    }>>;
}>>, Schema.toCodecJson<typeof ServiceUnavailableError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"vcs.get", "GET", "/api/vcs", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly provider: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly branch: Schema.Struct<{
            readonly current: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>;
    }>;
}>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"vcs.init", "POST", "/api/vcs/init", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
    readonly provider: Schema.optional<Schema.String>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof InvalidRequestError | typeof ConflictError | typeof ServiceUnavailableError | typeof VcsInitNotSupportedError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"vcs.status", "GET", "/api/vcs/status", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly file: Schema.String;
        readonly additions: Schema.Int;
        readonly deletions: Schema.Int;
        readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
    }>>;
}>>, never, never, never>, false>;
export {};
