import { Context, Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiMiddleware, HttpApiSchema } from "effect/http-api";
import { ForbiddenError, LocationNotFoundError, PtyNotFoundError } from "../errors.js";
export declare const PTY_CONNECT_TICKET_QUERY = "ticket";
export declare const PTY_CONNECT_TOKEN_HEADER = "x-opencode-ticket";
export declare const PTY_CONNECT_TOKEN_HEADER_VALUE = "1";
export declare const PTY_CONNECT_PATH = "/api/pty/:ptyID/connect";
export declare function hasPtyConnectTicketURL(url: URL): boolean;
export declare const makePtyGroup: <LocationId extends HttpApiMiddleware.AnyId, LocationService>(locationMiddleware: Context.Key<LocationId, LocationService>) => HttpApiGroup.HttpApiGroup<"server.pty", HttpApiEndpoint.HttpApiEndpoint<"pty.create", "POST", "/api/pty", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly command: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly args: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    readonly cwd: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly env: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: Schema.String;
        readonly command: Schema.String;
        readonly args: Schema.$Array<Schema.String>;
        readonly cwd: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited"]>;
        readonly pid: Schema.Int;
        readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}>>, never, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"pty.list", "GET", "/api/pty", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: Schema.String;
        readonly command: Schema.String;
        readonly args: Schema.$Array<Schema.String>;
        readonly cwd: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited"]>;
        readonly pid: Schema.Int;
        readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>;
}>>, never, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"pty.get", "GET", "/api/pty/:ptyID", Schema.toCodecStringTree<Schema.Struct<{
    ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: Schema.String;
        readonly command: Schema.String;
        readonly args: Schema.$Array<Schema.String>;
        readonly cwd: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited"]>;
        readonly pid: Schema.Int;
        readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}>>, Schema.toCodecJson<typeof PtyNotFoundError>, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"pty.remove", "DELETE", "/api/pty/:ptyID", Schema.toCodecStringTree<Schema.Struct<{
    ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof PtyNotFoundError>, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"pty.update", "PUT", "/api/pty/:ptyID", Schema.toCodecStringTree<Schema.Struct<{
    ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly size: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly rows: Schema.Int;
        readonly cols: Schema.Int;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly rows: Schema.Int;
        readonly cols: Schema.Int;
    }>>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: Schema.String;
        readonly command: Schema.String;
        readonly args: Schema.$Array<Schema.String>;
        readonly cwd: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited"]>;
        readonly pid: Schema.Int;
        readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}>>, Schema.toCodecJson<typeof PtyNotFoundError>, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"pty.connectToken", "POST", "/api/pty/:ptyID/connect-token", Schema.toCodecStringTree<Schema.Struct<{
    ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, Schema.toCodecStringTree<Schema.Struct<{
    readonly "x-opencode-ticket": Schema.optional<Schema.String>;
}>>, Schema.toCodecJson<Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly data: Schema.Struct<{
        readonly ticket: Schema.String;
        readonly expires_in: Schema.Int;
    }>;
}>>, Schema.toCodecJson<typeof ForbiddenError | typeof PtyNotFoundError>, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"pty.connect", "GET", "/api/pty/:ptyID/connect", Schema.toCodecStringTree<Schema.Struct<{
    ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
}>>, never, never, never, Schema.toCodecJson<Schema.Boolean>, Schema.toCodecJson<typeof LocationNotFoundError | typeof ForbiddenError | typeof PtyNotFoundError>, never, never>, false>;
