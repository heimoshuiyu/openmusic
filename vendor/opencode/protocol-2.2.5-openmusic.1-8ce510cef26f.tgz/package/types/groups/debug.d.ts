import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiSchema } from "effect/http-api";
import { InvalidRequestError, UnknownError } from "../errors.js";
export declare const DebugGroup: HttpApiGroup.HttpApiGroup<"server.debug", HttpApiEndpoint.HttpApiEndpoint<"debug.heapDump", "POST", "/api/debug/heap-dump", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly directory: Schema.optional<Schema.String>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly path: Schema.String;
    readonly pid: Schema.Int;
    readonly memory: Schema.Struct<{
        readonly rss: Schema.Number;
        readonly heapTotal: Schema.Number;
        readonly heapUsed: Schema.Number;
        readonly external: Schema.Number;
        readonly arrayBuffers: Schema.Number;
    }>;
}>>, Schema.toCodecJson<typeof InvalidRequestError | typeof UnknownError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"debug.location", "GET", "/api/debug/location", never, never, never, never, Schema.toCodecJson<Schema.$Array<Schema.Struct<{
    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
}>>>, never, never, never> | HttpApiEndpoint.HttpApiEndpoint<"debug.location.evict", "DELETE", "/api/debug/location", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, never, never, never>, false>;
