import { Generate } from "@opencode/schema/generate";
import { Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup } from "effect/http-api";
import { InvalidRequestError, LocationNotFoundError, ModelNotFoundError, ProviderNotFoundError, ProviderRequestError, ServiceUnavailableError, UnsupportedModelError } from "../errors.js";
export declare const GenerateGroup: HttpApiGroup.HttpApiGroup<"server.generate", HttpApiEndpoint.HttpApiEndpoint<"generate.decisions", "POST", "/api/experimental/generate/decisions", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly model: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    };
    readonly input: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"json">;
        readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    }>, Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.Literal<"file">;
    }>]>>;
    readonly questions: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"predicate">;
        readonly name: Schema.String;
        readonly instructions: Schema.String;
        readonly criteria: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly true: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly false: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly true: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly false: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"choice">;
        readonly name: Schema.String;
        readonly instructions: Schema.String;
        readonly choices: Schema.$Array<Schema.Struct<{
            readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"score">;
        readonly name: Schema.String;
        readonly instructions: Schema.String;
        readonly levels: Schema.$Array<Schema.Struct<{
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
    }>]>>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly answers: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"predicate">;
            readonly name: Schema.String;
            readonly probability: Schema.Finite;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"choice">;
            readonly name: Schema.String;
            readonly choice: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
            readonly probabilities: Schema.$Array<Schema.Struct<{
                readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
                readonly probability: Schema.Finite;
            }>>;
            readonly confidence: Schema.Finite;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"score">;
            readonly name: Schema.String;
            readonly score: Schema.Finite;
            readonly probabilities: Schema.$Array<Schema.Struct<{
                readonly value: Schema.Int;
                readonly label: Schema.String;
                readonly probability: Schema.Finite;
            }>>;
            readonly confidence: Schema.Finite;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"error">;
            readonly name: Schema.String;
            readonly reason: Schema.String;
            readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof InvalidRequestError | typeof ServiceUnavailableError | typeof ProviderNotFoundError | typeof ModelNotFoundError | typeof UnsupportedModelError | typeof ProviderRequestError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"generate.image", "POST", "/api/experimental/generate/image", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly model: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    };
    readonly prompt: Schema.String;
    readonly images: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>, never, never>;
    readonly n: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly aspect: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<`${number}:${number}`, `${number}:${number}`, never, never>>>, Schema.optionalKey<Schema.Codec<`${number}:${number}`, `${number}:${number}`, never, never>>, never, never>;
    readonly resolution: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Generate.ImageResolution, Generate.ImageResolution, never, never>>>, Schema.optionalKey<Schema.Codec<Generate.ImageResolution, Generate.ImageResolution, never, never>>, never, never>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly images: Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly type: Schema.Literal<"image">;
        }>>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
            readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        }>>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof InvalidRequestError | typeof ServiceUnavailableError | typeof ProviderNotFoundError | typeof ModelNotFoundError | typeof UnsupportedModelError | typeof ProviderRequestError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"generate.text", "POST", "/api/experimental/generate/text", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly prompt: Schema.String;
    readonly model: Schema.optional<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly text: Schema.String;
    }>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof InvalidRequestError | typeof ServiceUnavailableError | typeof ProviderNotFoundError | typeof ModelNotFoundError | typeof UnsupportedModelError | typeof ProviderRequestError>, never, never> | HttpApiEndpoint.HttpApiEndpoint<"generate.textLegacy", "POST", "/api/experimental/generate", never, never, Schema.toCodecJson<Schema.Struct<{
    readonly prompt: Schema.String;
    readonly model: Schema.optional<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>;
}>>, never, Schema.toCodecJson<Schema.Struct<{
    readonly data: Schema.Struct<{
        readonly text: Schema.String;
    }>;
}>>, Schema.toCodecJson<typeof LocationNotFoundError | typeof InvalidRequestError | typeof ServiceUnavailableError | typeof ProviderNotFoundError | typeof ModelNotFoundError | typeof UnsupportedModelError | typeof ProviderRequestError>, never, never>, false>;
