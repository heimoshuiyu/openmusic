import { Context, Schema } from "effect";
import { HttpApiEndpoint, HttpApiGroup, HttpApiMiddleware, HttpApiSchema } from "effect/http-api";
import { ServiceUnavailableError } from "../errors.js";
export declare const LocationQuery: Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>;
export declare const locationQueryOpenApi: Context.Context<never>;
export declare const makeLocationGroup: <LocationId extends HttpApiMiddleware.AnyId, LocationService>(locationMiddleware: Context.Key<LocationId, LocationService>) => HttpApiGroup.HttpApiGroup<"server.location", HttpApiEndpoint.HttpApiEndpoint<"location.get", "GET", "/api/location", never, Schema.toCodecStringTree<Schema.Struct<{
    readonly location: Schema.optional<Schema.Struct<{
        readonly directory: Schema.optional<Schema.String>;
    }>>;
}>>, never, never, Schema.toCodecJson<Schema.Struct<{
    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    readonly project: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly canonical: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
}>>, never, LocationId, HttpApiMiddleware.Requires<LocationId>> | HttpApiEndpoint.HttpApiEndpoint<"location.reload", "POST", "/api/location/reload", never, never, never, never, Schema.toCodecJson<HttpApiSchema.NoContent>, Schema.toCodecJson<typeof ServiceUnavailableError>, never, never>, false>;
