import { Schema } from "effect";
declare const LocationNotFoundError_base: Schema.Class<LocationNotFoundError, Schema.TaggedStruct<"LocationNotFoundError", {
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    }>;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class LocationNotFoundError extends LocationNotFoundError_base {
}
declare const InvalidRequestError_base: Schema.Class<InvalidRequestError, Schema.TaggedStruct<"InvalidRequestError", {
    readonly message: Schema.String;
    readonly kind: Schema.optional<Schema.String>;
    readonly field: Schema.optional<Schema.String>;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRequestError extends InvalidRequestError_base {
}
declare const RpcError_base: Schema.Class<RpcError, Schema.TaggedStruct<"RpcError", {
    readonly type: Schema.String;
    readonly message: Schema.String;
    readonly data: Schema.optional<Schema.Unknown>;
}>, import("effect/Cause").YieldableError>;
export declare class RpcError extends RpcError_base {
}
declare const RpcInternalError_base: Schema.Class<RpcInternalError, Schema.TaggedStruct<"RpcInternalError", {
    readonly type: Schema.Literals<readonly ["rpc.internal", "rpc.invalid_output"]>;
    readonly message: Schema.String;
    readonly data: Schema.optional<Schema.Unknown>;
}>, import("effect/Cause").YieldableError>;
export declare class RpcInternalError extends RpcInternalError_base {
}
declare const UnauthorizedError_base: Schema.Class<UnauthorizedError, Schema.TaggedStruct<"UnauthorizedError", {
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class UnauthorizedError extends UnauthorizedError_base {
}
declare const ConflictError_base: Schema.Class<ConflictError, Schema.TaggedStruct<"ConflictError", {
    readonly message: Schema.String;
    readonly resource: Schema.optional<Schema.String>;
}>, import("effect/Cause").YieldableError>;
export declare class ConflictError extends ConflictError_base {
}
declare const SessionBusyError_base: Schema.Class<SessionBusyError, Schema.TaggedStruct<"SessionBusyError", {
    readonly sessionID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class SessionBusyError extends SessionBusyError_base {
}
declare const ServiceUnavailableError_base: Schema.Class<ServiceUnavailableError, Schema.TaggedStruct<"ServiceUnavailableError", {
    readonly message: Schema.String;
    readonly service: Schema.optional<Schema.String>;
}>, import("effect/Cause").YieldableError>;
export declare class ServiceUnavailableError extends ServiceUnavailableError_base {
}
declare const UnknownError_base: Schema.Class<UnknownError, Schema.TaggedStruct<"UnknownError", {
    readonly message: Schema.String;
    readonly ref: Schema.optional<Schema.String>;
}>, import("effect/Cause").YieldableError>;
export declare class UnknownError extends UnknownError_base {
}
declare const ProviderNotFoundError_base: Schema.Class<ProviderNotFoundError, Schema.TaggedStruct<"ProviderNotFoundError", {
    readonly providerID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class ProviderNotFoundError extends ProviderNotFoundError_base {
}
declare const IntegrationNotFoundError_base: Schema.Class<IntegrationNotFoundError, Schema.TaggedStruct<"IntegrationNotFoundError", {
    readonly integrationID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class IntegrationNotFoundError extends IntegrationNotFoundError_base {
}
declare const IntegrationAttemptNotFoundError_base: Schema.Class<IntegrationAttemptNotFoundError, Schema.TaggedStruct<"IntegrationAttemptNotFoundError", {
    readonly integrationID: Schema.String;
    readonly attemptID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class IntegrationAttemptNotFoundError extends IntegrationAttemptNotFoundError_base {
}
declare const IntegrationMethodNotFoundError_base: Schema.Class<IntegrationMethodNotFoundError, Schema.TaggedStruct<"IntegrationMethodNotFoundError", {
    readonly integrationID: Schema.String;
    readonly methodID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class IntegrationMethodNotFoundError extends IntegrationMethodNotFoundError_base {
}
declare const ProjectNotFoundError_base: Schema.Class<ProjectNotFoundError, Schema.TaggedStruct<"ProjectNotFoundError", {
    readonly projectID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class ProjectNotFoundError extends ProjectNotFoundError_base {
}
declare const FileNotFoundError_base: Schema.Class<FileNotFoundError, Schema.TaggedStruct<"FileNotFoundError", {
    readonly path: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class FileNotFoundError extends FileNotFoundError_base {
}
declare const PluginNotFoundError_base: Schema.Class<PluginNotFoundError, Schema.TaggedStruct<"PluginNotFoundError", {
    readonly pluginID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class PluginNotFoundError extends PluginNotFoundError_base {
}
declare const AgentNotFoundError_base: Schema.Class<AgentNotFoundError, Schema.TaggedStruct<"AgentNotFoundError", {
    readonly agentID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class AgentNotFoundError extends AgentNotFoundError_base {
}
declare const SessionNotFoundError_base: Schema.Class<SessionNotFoundError, Schema.TaggedStruct<"SessionNotFoundError", {
    readonly sessionID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class SessionNotFoundError extends SessionNotFoundError_base {
}
declare const MessageNotFoundError_base: Schema.Class<MessageNotFoundError, Schema.TaggedStruct<"MessageNotFoundError", {
    readonly sessionID: Schema.String;
    readonly messageID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class MessageNotFoundError extends MessageNotFoundError_base {
}
declare const SkillNotFoundError_base: Schema.Class<SkillNotFoundError, Schema.TaggedStruct<"SkillNotFoundError", {
    readonly skill: Schema.brand<Schema.String, "Skill.ID">;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class SkillNotFoundError extends SkillNotFoundError_base {
}
declare const McpServerNotFoundError_base: Schema.Class<McpServerNotFoundError, Schema.TaggedStruct<"McpServerNotFoundError", {
    readonly server: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class McpServerNotFoundError extends McpServerNotFoundError_base {
}
declare const CommandNotFoundError_base: Schema.Class<CommandNotFoundError, Schema.TaggedStruct<"CommandNotFoundError", {
    readonly command: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class CommandNotFoundError extends CommandNotFoundError_base {
}
declare const CommandExecutionError_base: Schema.Class<CommandExecutionError, Schema.TaggedStruct<"CommandExecutionError", {
    readonly command: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class CommandExecutionError extends CommandExecutionError_base {
}
declare const InvalidCursorError_base: Schema.Class<InvalidCursorError, Schema.TaggedStruct<"InvalidCursorError", {
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidCursorError extends InvalidCursorError_base {
}
declare const PermissionNotFoundError_base: Schema.Class<PermissionNotFoundError, Schema.TaggedStruct<"PermissionNotFoundError", {
    readonly requestID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class PermissionNotFoundError extends PermissionNotFoundError_base {
}
declare const PermissionSavedNotFoundError_base: Schema.Class<PermissionSavedNotFoundError, Schema.TaggedStruct<"PermissionSavedNotFoundError", {
    readonly id: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class PermissionSavedNotFoundError extends PermissionSavedNotFoundError_base {
}
declare const FormNotFoundError_base: Schema.Class<FormNotFoundError, Schema.TaggedStruct<"FormNotFoundError", {
    readonly id: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class FormNotFoundError extends FormNotFoundError_base {
}
declare const FormAlreadySettledError_base: Schema.Class<FormAlreadySettledError, Schema.TaggedStruct<"FormAlreadySettledError", {
    readonly id: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class FormAlreadySettledError extends FormAlreadySettledError_base {
}
declare const FormInvalidAnswerError_base: Schema.Class<FormInvalidAnswerError, Schema.TaggedStruct<"FormInvalidAnswerError", {
    readonly id: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class FormInvalidAnswerError extends FormInvalidAnswerError_base {
}
declare const ForbiddenError_base: Schema.Class<ForbiddenError, Schema.TaggedStruct<"ForbiddenError", {
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class ForbiddenError extends ForbiddenError_base {
}
declare const PtyNotFoundError_base: Schema.Class<PtyNotFoundError, Schema.TaggedStruct<"PtyNotFoundError", {
    readonly ptyID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class PtyNotFoundError extends PtyNotFoundError_base {
}
declare const PtyFeatureUnsupportedError_base: Schema.Class<PtyFeatureUnsupportedError, Schema.TaggedStruct<"PtyFeatureUnsupportedError", {
    readonly feature: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class PtyFeatureUnsupportedError extends PtyFeatureUnsupportedError_base {
}
declare const ShellNotFoundError_base: Schema.Class<ShellNotFoundError, Schema.TaggedStruct<"ShellNotFoundError", {
    readonly id: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class ShellNotFoundError extends ShellNotFoundError_base {
}
declare const ModelNotFoundError_base: Schema.Class<ModelNotFoundError, Schema.TaggedStruct<"ModelNotFoundError", {
    readonly providerID: Schema.String;
    readonly modelID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class ModelNotFoundError extends ModelNotFoundError_base {
}
declare const UnsupportedModelError_base: Schema.Class<UnsupportedModelError, Schema.TaggedStruct<"UnsupportedModelError", {
    readonly providerID: Schema.String;
    readonly modelID: Schema.String;
    readonly capability: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
/** The model exists but cannot serve this request, such as a chat model asked for images. */
export declare class UnsupportedModelError extends UnsupportedModelError_base {
}
declare const ProviderRequestError_base: Schema.Class<ProviderRequestError, Schema.TaggedStruct<"ProviderRequestError", {
    readonly providerID: Schema.String;
    readonly reason: Schema.Literals<readonly ["authentication", "rate_limit", "content_filter", "invalid_request", "overloaded", "provider"]>;
    readonly message: Schema.String;
    readonly status: Schema.optional<Schema.Int>;
    readonly retryAfterMs: Schema.optional<Schema.Int>;
}>, import("effect/Cause").YieldableError>;
/** The provider rejected or failed the request after the server sent it. */
export declare class ProviderRequestError extends ProviderRequestError_base {
}
declare const ScheduleNotFoundError_base: Schema.Class<ScheduleNotFoundError, Schema.TaggedStruct<"ScheduleNotFoundError", {
    readonly scheduleID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class ScheduleNotFoundError extends ScheduleNotFoundError_base {
}
declare const ArtifactNotFoundError_base: Schema.Class<ArtifactNotFoundError, Schema.TaggedStruct<"ArtifactNotFoundError", {
    readonly artifactID: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class ArtifactNotFoundError extends ArtifactNotFoundError_base {
}
export {};
