import { HttpApiMiddleware } from "effect/http-api";
import { UnauthorizedError } from "../errors.js";
declare const Authorization_base: HttpApiMiddleware.ServiceClass<Authorization, "@opencode/HttpApiAuthorization", {
    requires: never;
    provides: never;
    error: typeof UnauthorizedError;
    clientError: never;
    requiredForClient: false;
    security: never;
}, HttpApiMiddleware.HttpApiMiddleware<never, typeof UnauthorizedError, never>>;
export declare class Authorization extends Authorization_base {
}
export {};
