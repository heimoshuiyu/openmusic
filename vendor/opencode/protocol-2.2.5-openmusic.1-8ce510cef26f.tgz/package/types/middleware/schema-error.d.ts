import { HttpApiMiddleware } from "effect/http-api";
import { InvalidRequestError } from "../errors.js";
declare const SchemaErrorMiddleware_base: HttpApiMiddleware.ServiceClass<SchemaErrorMiddleware, "@opencode/HttpApiSchemaError", {
    requires: never;
    provides: never;
    error: typeof InvalidRequestError;
    clientError: never;
    requiredForClient: false;
    security: never;
}, HttpApiMiddleware.HttpApiMiddleware<never, typeof InvalidRequestError, never>>;
export declare class SchemaErrorMiddleware extends SchemaErrorMiddleware_base {
}
export {};
