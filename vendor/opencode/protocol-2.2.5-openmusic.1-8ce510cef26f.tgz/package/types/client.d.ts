import { LocationNotFoundError, InvalidRequestError, SessionNotFoundError } from "./errors.js";
import type { Api } from "./api.js";
import type { Context } from "effect";
import { HttpApiMiddleware } from "effect/http-api";
import type { EventGroup } from "./groups/event.js";
declare const LocationMiddleware_base: HttpApiMiddleware.ServiceClass<LocationMiddleware, "@opencode/client/LocationMiddleware", {
    requires: never;
    provides: never;
    error: readonly [typeof LocationNotFoundError];
    clientError: never;
    requiredForClient: false;
    security: never;
}, HttpApiMiddleware.HttpApiMiddleware<never, readonly [typeof LocationNotFoundError], never>>;
declare class LocationMiddleware extends LocationMiddleware_base {
}
declare const SessionLocationMiddleware_base: HttpApiMiddleware.ServiceClass<SessionLocationMiddleware, "@opencode/client/SessionLocationMiddleware", {
    requires: never;
    provides: never;
    error: readonly [typeof InvalidRequestError, typeof SessionNotFoundError, typeof LocationNotFoundError];
    clientError: never;
    requiredForClient: false;
    security: never;
}, HttpApiMiddleware.HttpApiMiddleware<never, readonly [typeof InvalidRequestError, typeof SessionNotFoundError, typeof LocationNotFoundError], never>>;
declare class SessionLocationMiddleware extends SessionLocationMiddleware_base {
}
type ClientApiShape = Api<Context.Service.Identifier<typeof LocationMiddleware>, Context.Service.Shape<typeof LocationMiddleware>, Context.Service.Identifier<typeof SessionLocationMiddleware>, Context.Service.Shape<typeof SessionLocationMiddleware>, Context.Service.Identifier<typeof SessionLocationMiddleware>, Context.Service.Shape<typeof SessionLocationMiddleware>, typeof EventGroup>;
export declare const ClientApi: ClientApiShape;
export declare const groupNames: {
    readonly "server.server": "server";
    readonly "server.debug": "debug";
    readonly "server.migration": "migration";
    readonly "server.location": "location";
    readonly "server.agent": "agent";
    readonly "server.plugin": "plugin";
    readonly "server.session": "session";
    readonly "server.message": "message";
    readonly "server.model": "model";
    readonly "server.generate": "generate";
    readonly "server.voice": "voice";
    readonly "server.transcription": "transcription";
    readonly "server.provider": "provider";
    readonly "server.integration": "integration";
    readonly "server.websearch": "websearch";
    readonly "server.usage": "usage";
    readonly "server.credential": "credential";
    readonly "server.form": "form";
    readonly "server.permission": "permission";
    readonly "server.fs": "file";
    readonly "server.command": "command";
    readonly "server.skill": "skill";
    readonly "server.rpc": "rpc";
    readonly "server.event": "event";
    readonly "server.pty": "pty";
    readonly "server.experimental": "experimental";
    readonly "server.shell": "shell";
    readonly "server.mcp": "mcp";
    readonly "server.reference": "reference";
    readonly "server.project": "project";
    readonly "server.worktree": "worktree";
    readonly "server.vcs": "vcs";
    readonly "server.config": "config";
};
export declare const clientNamespace: (endpoint: {
    readonly path: string;
}) => "experimental" | undefined;
export declare const promiseOmitEndpoints: Set<string>;
export declare const effectOmitEndpoints: Set<string>;
export {};
