export * as Transcription from "./transcription.js";
import { Schema } from "effect";
export declare const Backend: Schema.Literals<readonly ["whisper", "lalm"]>;
export type Backend = typeof Backend.Type;
export declare const ContextPairs: Schema.Int;
export declare const RequestContextPairs: Schema.Union<readonly [Schema.Literal<0>, Schema.Int]>;
export declare const whisperEndpoints: {
    readonly openai: "https://api.openai.com/v1/audio/transcriptions";
    readonly groq: "https://api.groq.com/openai/v1/audio/transcriptions";
};
/** Request-only overrides for the experimental transcription endpoint. */
export interface Overrides extends Schema.Schema.Type<typeof Overrides> {
}
export declare const Overrides: Schema.Struct<{
    readonly context_pairs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<0>, Schema.Int]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<0>, Schema.Int]>>, never, never>;
    readonly hot_words: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    readonly whisper: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly url: Schema.String;
        readonly apiKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly url: Schema.String;
        readonly apiKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>, never, never>;
}>;
export interface Whisper extends Schema.Schema.Type<typeof Whisper> {
}
export declare const Whisper: Schema.Struct<{
    readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>;
export interface Lalm extends Schema.Schema.Type<typeof Lalm> {
}
export declare const Lalm: Schema.Struct<{
    readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
}>;
export interface Settings extends Schema.Schema.Type<typeof Settings> {
}
export declare const Settings: Schema.Struct<{
    readonly type: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["whisper", "lalm"]>>>, Schema.optionalKey<Schema.Literals<readonly ["whisper", "lalm"]>>, never, never>;
    readonly whisper: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly language: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>, never, never>;
    readonly lalm: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly system: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly instruction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly audio_input_format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["input_audio", "audio_url"]>>>, Schema.optionalKey<Schema.Literals<readonly ["input_audio", "audio_url"]>>, never, never>;
    }>>, never, never>;
    readonly hot_words: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
}>;
