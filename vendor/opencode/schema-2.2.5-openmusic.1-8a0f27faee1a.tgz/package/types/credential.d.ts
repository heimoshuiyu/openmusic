export * as Credential from "./credential.js";
import { Schema } from "effect";
export declare const ID: Schema.brand<Schema.String, "Credential.ID"> & {
    create: () => string & import("effect/Brand").Brand<"Credential.ID">;
};
export type ID = typeof ID.Type;
export declare const Event: {
    Updated: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"credential.updated">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
            readonly credentialID: Schema.brand<Schema.String, "Credential.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Credential.ID">;
            };
        }>;
    }> & {
        type: "credential.updated";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
            readonly credentialID: Schema.brand<Schema.String, "Credential.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Credential.ID">;
            };
        }>;
    };
    Switched: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"credential.switched">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
            readonly credentialID: Schema.NullOr<Schema.brand<Schema.String, "Credential.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Credential.ID">;
            }>;
        }>;
    }> & {
        type: "credential.switched";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
            readonly credentialID: Schema.NullOr<Schema.brand<Schema.String, "Credential.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Credential.ID">;
            }>;
        }>;
    };
    Definitions: readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"credential.updated">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
            readonly credentialID: Schema.brand<Schema.String, "Credential.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Credential.ID">;
            };
        }>;
    }> & {
        type: "credential.updated";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
            readonly credentialID: Schema.brand<Schema.String, "Credential.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Credential.ID">;
            };
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"credential.switched">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
            readonly credentialID: Schema.NullOr<Schema.brand<Schema.String, "Credential.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Credential.ID">;
            }>;
        }>;
    }> & {
        type: "credential.switched";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
            readonly credentialID: Schema.NullOr<Schema.brand<Schema.String, "Credential.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Credential.ID">;
            }>;
        }>;
    }];
};
export interface OAuth extends Schema.Schema.Type<typeof OAuth> {
}
export declare const OAuth: Schema.Struct<{
    readonly type: Schema.Literal<"oauth">;
    readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly refresh: Schema.String;
    readonly access: Schema.String;
    readonly expires: Schema.Int;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>;
export interface Key extends Schema.Schema.Type<typeof Key> {
}
export declare const Key: Schema.Struct<{
    readonly type: Schema.Literal<"key">;
    readonly key: Schema.String;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>;
/** References a credential source whose secrets and renewal are managed outside the credential store. */
export interface External extends Schema.Schema.Type<typeof External> {
}
export declare const External: Schema.Struct<{
    readonly type: Schema.Literal<"external">;
    readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>;
export declare const Value: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"oauth">;
    readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly refresh: Schema.String;
    readonly access: Schema.String;
    readonly expires: Schema.Int;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"key">;
    readonly key: Schema.String;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"external">;
    readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>]>;
export type Value = Schema.Schema.Type<typeof Value>;
export interface Entry extends Schema.Schema.Type<typeof Entry> {
}
export declare const Entry: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Credential.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Credential.ID">;
    };
    readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
    readonly label: Schema.String;
    readonly active: Schema.Boolean;
    readonly value: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"oauth">;
        readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
        readonly refresh: Schema.String;
        readonly access: Schema.String;
        readonly expires: Schema.Int;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"key">;
        readonly key: Schema.String;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"external">;
        readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>]>;
}>;
export interface CreateInput extends Schema.Schema.Type<typeof CreateInput> {
}
export declare const CreateInput: Schema.Struct<{
    readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Credential.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Credential.ID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Credential.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Credential.ID">;
    }>, never, never>;
    readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
    readonly label: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly value: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"oauth">;
        readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
        readonly refresh: Schema.String;
        readonly access: Schema.String;
        readonly expires: Schema.Int;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"key">;
        readonly key: Schema.String;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"external">;
        readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>]>;
    readonly activate: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>;
