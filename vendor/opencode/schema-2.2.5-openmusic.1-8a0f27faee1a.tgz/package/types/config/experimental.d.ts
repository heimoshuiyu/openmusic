export * as ConfigExperimental from "./experimental.js";
import { Schema } from "effect";
declare const Info_base: Schema.Class<Info, Schema.Struct<{
    readonly portable_shell_scanner: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly all_flags: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly part_rows: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly image_generate: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.Struct<{
            readonly providerID: Schema.brand<Schema.String, "Provider.ID">;
            readonly model: Schema.brand<Schema.String, "Model.ID">;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }>, Schema.Union<readonly [Schema.String, Schema.Struct<{
            readonly providerID: Schema.brand<Schema.String, "Provider.ID">;
            readonly model: Schema.brand<Schema.String, "Model.ID">;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }>]>, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.Struct<{
            readonly providerID: Schema.brand<Schema.String, "Provider.ID">;
            readonly model: Schema.brand<Schema.String, "Model.ID">;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }>, Schema.Union<readonly [Schema.String, Schema.Struct<{
            readonly providerID: Schema.brand<Schema.String, "Provider.ID">;
            readonly model: Schema.brand<Schema.String, "Model.ID">;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }>]>, never, never>>, never, never>;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.Struct<{
            readonly providerID: Schema.brand<Schema.String, "Provider.ID">;
            readonly model: Schema.brand<Schema.String, "Model.ID">;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }>, Schema.Union<readonly [Schema.String, Schema.Struct<{
            readonly providerID: Schema.brand<Schema.String, "Provider.ID">;
            readonly model: Schema.brand<Schema.String, "Model.ID">;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }>]>, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.Struct<{
            readonly providerID: Schema.brand<Schema.String, "Provider.ID">;
            readonly model: Schema.brand<Schema.String, "Model.ID">;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }>, Schema.Union<readonly [Schema.String, Schema.Struct<{
            readonly providerID: Schema.brand<Schema.String, "Provider.ID">;
            readonly model: Schema.brand<Schema.String, "Model.ID">;
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }>]>, never, never>>, never, never>;
    }>]>>, never, never>;
    readonly subagent_depth: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly location_idle_timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.DurationFromString, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.DurationFromString, Schema.Literal<false>]>>, never, never>;
    readonly policies: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.decodeTo<Schema.toType<Schema.Struct<{
        readonly action: Schema.Literals<readonly ["provider.use", "tool.use", "integration.connect", "integration.use", "mcp.use", "skill.use", "plugin.use", "websearch.use"]>;
        readonly resource: Schema.String;
        readonly effect: Schema.Literals<readonly ["allow", "deny"]>;
    }>>, Schema.Struct<{
        readonly action: Schema.Literals<readonly ["provider.use", "tool.use", "integration.connect", "integration.use", "mcp.use", "skill.use", "plugin.use", "websearch.use"]>;
        readonly resource: Schema.String;
        readonly effect: Schema.Literals<readonly ["allow", "deny"]>;
    }>, never, never>>>>, Schema.optionalKey<Schema.$Array<Schema.decodeTo<Schema.toType<Schema.Struct<{
        readonly action: Schema.Literals<readonly ["provider.use", "tool.use", "integration.connect", "integration.use", "mcp.use", "skill.use", "plugin.use", "websearch.use"]>;
        readonly resource: Schema.String;
        readonly effect: Schema.Literals<readonly ["allow", "deny"]>;
    }>>, Schema.Struct<{
        readonly action: Schema.Literals<readonly ["provider.use", "tool.use", "integration.connect", "integration.use", "mcp.use", "skill.use", "plugin.use", "websearch.use"]>;
        readonly resource: Schema.String;
        readonly effect: Schema.Literals<readonly ["allow", "deny"]>;
    }>, never, never>>>, never, never>;
    readonly artifacts: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly background_compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly codemode_vm: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly media_blob: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly schedules: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly todo: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>, {}>;
export declare class Info extends Info_base {
}
