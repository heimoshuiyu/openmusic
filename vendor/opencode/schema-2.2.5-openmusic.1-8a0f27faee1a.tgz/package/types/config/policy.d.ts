export * as ConfigPolicy from "./policy.js";
import { Schema } from "effect";
export declare const Effect: Schema.Literals<readonly ["allow", "deny"]>;
export type Effect = typeof Effect.Type;
/**
 * - `provider.use`: resource is a provider ID.
 * - `tool.use`: resource is `<tool>:<input>`, such as `shell:git *`.
 * - `integration.connect`: resource is an integration ID; controls which integrations can be listed and connected.
 * - `integration.use`: resource is `<integration>#<account>`, or the bare integration ID when the providers, models,
 *   web search, MCP servers, or config an integration supplies come from no account (env keys, local config, the
 *   signed-out free tier).
 * - `mcp.use`, `skill.use`, `plugin.use`: resource is an MCP server name, skill ID, or plugin target.
 * - `websearch.use`: resource is a web search provider ID, such as `opencode` or `exa`.
 */
export declare const Action: Schema.Literals<readonly ["provider.use", "tool.use", "integration.connect", "integration.use", "mcp.use", "skill.use", "plugin.use", "websearch.use"]>;
export type Action = typeof Action.Type;
export declare const Info: Schema.decodeTo<Schema.toType<Schema.Struct<{
    readonly action: Schema.Literals<readonly ["provider.use", "tool.use", "integration.connect", "integration.use", "mcp.use", "skill.use", "plugin.use", "websearch.use"]>;
    readonly resource: Schema.String;
    readonly effect: Schema.Literals<readonly ["allow", "deny"]>;
}>>, Schema.Struct<{
    readonly action: Schema.Literals<readonly ["provider.use", "tool.use", "integration.connect", "integration.use", "mcp.use", "skill.use", "plugin.use", "websearch.use"]>;
    readonly resource: Schema.String;
    readonly effect: Schema.Literals<readonly ["allow", "deny"]>;
}>, never, never>;
export type Info = typeof Info.Type;
