export * as ConfigCompaction from "./compaction.js";
import { Schema } from "effect";
declare const Keep_base: Schema.Class<Keep, Schema.Struct<{
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}>, {}>;
export declare class Keep extends Keep_base {
}
/** A share of the model's window such as "20%" or "12.5%", from 1% up to but not including 100%. */
export declare const Percent: Schema.String;
export type Percent = typeof Percent.Type;
declare const Info_base: Schema.Class<Info, Schema.Struct<{
    readonly auto: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly keep: Schema.decodeTo<Schema.optional<Schema.toType<typeof Keep>>, Schema.optionalKey<typeof Keep>, never, never>;
    readonly buffer: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.String, Schema.Int]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.String, Schema.Int]>>, never, never>;
}>, {}>;
export declare class Info extends Info_base {
}
