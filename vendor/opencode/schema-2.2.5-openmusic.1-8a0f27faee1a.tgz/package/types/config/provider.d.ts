export * as ConfigProvider from "./provider.js";
import { Schema } from "effect";
import { Model, Type } from "../model.js";
export declare const Settings: Schema.StructWithRest<Schema.Struct<{
    readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
    readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
    readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
    readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"summary">;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"native">;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"summary">;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"native">;
    }>]>>, never, never>;
    readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
        readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
        readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>, never, never>;
    }>>, never, never>;
    readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
    readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
}>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>;
export type Settings = typeof Settings.Type;
export declare const ModelSettings: Schema.StructWithRest<Schema.Struct<{
    readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"summary">;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"native">;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"summary">;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"native">;
    }>]>>, never, never>;
    readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
        readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
        readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>, never, never>;
    }>>, never, never>;
    readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
}>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>;
export type ModelSettings = typeof ModelSettings.Type;
export declare const Overlays: {
    settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
        readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>, never, never>;
        readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>, never, never>;
        readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
        readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
    }>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
        readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>, never, never>;
        readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>, never, never>;
        readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
        readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
    }>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>>, never, never>;
    headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
    body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
};
declare const Request_base: Schema.Class<Request, Schema.Struct<{
    readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
    readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
}>, {}>;
export declare class Request extends Request_base {
}
declare const Cache_base: Schema.Class<Cache, Schema.Struct<{
    readonly read: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
        zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
        zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
    }>, never, never>;
    readonly write: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
        zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
        zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
    }>, never, never>;
}>, {}>;
declare class Cache extends Cache_base {
}
declare const Cost_base: Schema.Class<Cost, Schema.Struct<{
    readonly tier: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly type: Schema.Literal<"context">;
        readonly size: Schema.Int;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly type: Schema.Literal<"context">;
        readonly size: Schema.Int;
    }>>, never, never>;
    readonly input: Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
        zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
    };
    readonly output: Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
        zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
    };
    readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<typeof Cache>>, Schema.optionalKey<typeof Cache>, never, never>;
}>, {}>;
declare class Cost extends Cost_base {
}
declare const Limit_base: Schema.Class<Limit, Schema.Struct<{
    readonly context: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}>, {}>;
declare class Limit extends Limit_base {
}
export declare const Reasoning: Schema.Union<readonly [Schema.Struct<{
    readonly supported: Schema.Literal<false>;
}>, Schema.Struct<{
    readonly supported: Schema.Literal<true>;
    readonly toggle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly effort: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    readonly budget: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly min: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly max: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly min: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly max: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>, never, never>;
}>]>;
export type Reasoning = typeof Reasoning.Type;
declare const ModelConfig_base: Schema.Class<ModelConfig, Schema.Struct<{
    readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
        readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>, never, never>;
        readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>, never, never>;
        readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
    }>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
        readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>, never, never>;
        readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>, never, never>;
        readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
    }>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>>, never, never>;
    readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
    readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
    readonly modelID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.ID">>, never, never>;
    readonly type: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Type, Type, never, never>>>, Schema.optionalKey<Schema.Codec<Type, Type, never, never>>, never, never>;
    readonly family: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.Family">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.Family">>, never, never>;
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly releaseDate: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly compatibility: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>, never, never>;
        readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
        readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
        readonly supportsThinkingBlockBinding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly supportsEffortUpdates: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>, never, never>;
        readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
        readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
        readonly supportsThinkingBlockBinding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly supportsEffortUpdates: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
    }>>, never, never>;
    readonly package: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly capabilities: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly tools: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly temperature: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly reasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly supported: Schema.Literal<false>;
        }>, Schema.Struct<{
            readonly supported: Schema.Literal<true>;
            readonly toggle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly effort: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            readonly budget: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly min: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly max: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly min: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly max: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>, never, never>;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly supported: Schema.Literal<false>;
        }>, Schema.Struct<{
            readonly supported: Schema.Literal<true>;
            readonly toggle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly effort: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            readonly budget: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly min: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly max: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly min: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly max: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>, never, never>;
        }>]>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly tools: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        readonly temperature: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly reasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly supported: Schema.Literal<false>;
        }>, Schema.Struct<{
            readonly supported: Schema.Literal<true>;
            readonly toggle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly effort: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            readonly budget: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly min: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly max: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly min: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly max: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>, never, never>;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly supported: Schema.Literal<false>;
        }>, Schema.Struct<{
            readonly supported: Schema.Literal<true>;
            readonly toggle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly effort: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
            readonly budget: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly min: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly max: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly min: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly max: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>>, never, never>;
        }>]>>, never, never>;
    }>>, never, never>;
    readonly variants: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
        readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly id: Schema.brand<Schema.String, "Model.VariantID">;
        readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
        readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly id: Schema.brand<Schema.String, "Model.VariantID">;
        readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
            readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"summary">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"native">;
            }>]>>, never, never>;
            readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
        }>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>>, never, never>;
    }>>>, never, never>;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [typeof Cost, Schema.$Array<typeof Cost>]>>>, Schema.optionalKey<Schema.Union<readonly [typeof Cost, Schema.$Array<typeof Cost>]>>, never, never>;
    readonly disabled: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<typeof Limit>>, Schema.optionalKey<typeof Limit>, never, never>;
}>, {}>;
declare class ModelConfig extends ModelConfig_base {
}
declare const Info_base: Schema.Class<Info, Schema.Struct<{
    readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
        readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>, never, never>;
        readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>, never, never>;
        readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
        readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
    }>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
        readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>, never, never>;
        readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>, never, never>;
        readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
        readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
    }>, readonly [Schema.$Record<Schema.String, Schema.UndefinedOr<Schema.Codec<Schema.Json, Schema.Json, never, never>>>]>>, never, never>;
    readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
    readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
    readonly canonical: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Provider.ID"> & {
        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
        openai: string & import("effect/Brand").Brand<"Provider.ID">;
        google: string & import("effect/Brand").Brand<"Provider.ID">;
        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
        azure: string & import("effect/Brand").Brand<"Provider.ID">;
        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Provider.ID"> & {
        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
        openai: string & import("effect/Brand").Brand<"Provider.ID">;
        google: string & import("effect/Brand").Brand<"Provider.ID">;
        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
        azure: string & import("effect/Brand").Brand<"Provider.ID">;
        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
    }>, never, never>;
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly env: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    readonly package: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly compatibility: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>, never, never>;
        readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
        readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
        readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<Model.ReasoningField, Model.ReasoningField, never, never>>, never, never>;
        readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
        readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
        readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
    }>>, never, never>;
    readonly models: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, typeof ModelConfig>>>, Schema.optionalKey<Schema.$Record<Schema.String, typeof ModelConfig>>, never, never>;
}>, {}>;
export declare class Info extends Info_base {
}
