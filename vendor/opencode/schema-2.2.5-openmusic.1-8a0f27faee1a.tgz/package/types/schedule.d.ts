export * as Schedule from "./schedule.js";
import { Option, Schema } from "effect";
import { SessionID } from "./session-id.js";
export declare const ID: Schema.brand<Schema.String, "Schedule.ID"> & {
    create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
};
export type ID = typeof ID.Type;
/** Milliseconds in a duration string, or `None` when it is not one. */
export declare const durationMillis: (value: string) => Option.Option<number>;
/** A duration such as "90 seconds", "5 minutes" or "2 hours". The service validates it, since clients cannot run a custom check. */
export declare const DurationString: Schema.String;
export declare const In: Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.tag<"in">;
    readonly in: Schema.String;
}>;
/** An instant with an offset, or a wall-clock time in `tz`, e.g. "2026-10-27T09:00". */
export declare const At: Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.tag<"at">;
    readonly at: Schema.String;
}>;
export declare const Every: Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.tag<"every">;
    readonly every: Schema.String;
}>;
export declare const Cron: Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.tag<"cron">;
    readonly cron: Schema.String;
}>;
export declare const When: Schema.Union<readonly [Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.tag<"in">;
    readonly in: Schema.String;
}>, Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.tag<"at">;
    readonly at: Schema.String;
}>, Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.tag<"every">;
    readonly every: Schema.String;
}>, Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.tag<"cron">;
    readonly cron: Schema.String;
}>]>;
export type When = typeof When.Type;
/** Stops a repeating schedule at whichever limit comes first. */
export declare const Ends: Schema.Struct<{
    readonly after: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly at: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly times: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}>;
export type Ends = typeof Ends.Type;
export declare const PromptAction: Schema.Struct<{
    readonly type: Schema.tag<"prompt">;
    readonly prompt: Schema.String;
}>;
export declare const Action: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.tag<"prompt">;
    readonly prompt: Schema.String;
}>]>;
export type Action = typeof Action.Type;
/**
 * Runs `run` in the Session's directory before firing, with no model call. With none of `is`, `matches` or `changes`
 * set, exit 0 wakes and any non-zero exit is "not yet". With `is`, `matches` or `changes`, non-zero exit is a check
 * error, and exit 0 wakes when trimmed stdout equals `is`, stdout matches `matches`, or stdout differs from the
 * previous run (`changes`).
 */
export declare const ShellCondition: Schema.Struct<{
    readonly type: Schema.tag<"shell">;
    readonly run: Schema.String;
    readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>;
export type ShellCondition = typeof ShellCondition.Type;
/**
 * Runs `code` in a confined Code Mode runtime before firing, with no model call and no `fetch`. Tools called statically
 * as `tools.<path>(...)` are extracted from the AST and authorized at creation; the program receives `state` (initially
 * `null`), `now` (epoch ms) and `runs` (completed checks), and returns a boolean or `{ wake, state?, message? }`.
 */
export declare const CodeCondition: Schema.Struct<{
    readonly type: Schema.tag<"code">;
    readonly code: Schema.String;
}>;
export type CodeCondition = typeof CodeCondition.Type;
/** Checked before firing; the schedule wakes the Session only when the condition passes. */
export declare const Condition: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.tag<"shell">;
    readonly run: Schema.String;
    readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"code">;
    readonly code: Schema.String;
}>]>;
export type Condition = typeof Condition.Type;
export declare const CheckMode: Schema.Literals<readonly ["if", "until"]>;
export type CheckMode = typeof CheckMode.Type;
export declare const StoredCheck: Schema.Struct<{
    readonly mode: Schema.Literals<readonly ["if", "until"]>;
    readonly condition: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"shell">;
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"code">;
        readonly code: Schema.String;
    }>]>;
}>;
export type StoredCheck = typeof StoredCheck.Type;
export declare const Status: Schema.Literals<readonly ["active", "paused", "done"]>;
export type Status = typeof Status.Type;
export declare const Outcome: Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>;
export type Outcome = typeof Outcome.Type;
export declare const Info: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Schedule.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Schedule.ID">;
    };
    readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly when: Schema.Union<readonly [Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"in">;
        readonly in: Schema.String;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"at">;
        readonly at: Schema.String;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"every">;
        readonly every: Schema.String;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"cron">;
        readonly cron: Schema.String;
    }>]>;
    readonly tz: Schema.String;
    readonly if: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"shell">;
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"code">;
        readonly code: Schema.String;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"shell">;
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"code">;
        readonly code: Schema.String;
    }>]>>, never, never>;
    readonly until: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"shell">;
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"code">;
        readonly code: Schema.String;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"shell">;
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"code">;
        readonly code: Schema.String;
    }>]>>, never, never>;
    readonly action: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"prompt">;
        readonly prompt: Schema.String;
    }>]>;
    readonly status: Schema.Literals<readonly ["active", "paused", "done"]>;
    readonly nextDueAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    readonly endsAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    readonly remainingRuns: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly runCount: Schema.Int;
    readonly lastFiredAt: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    readonly lastOutcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>>, Schema.optionalKey<Schema.Literals<readonly ["fired", "late", "checked", "expired", "skipped", "disabled", "failed"]>>, never, never>;
    readonly lastOutput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>;
export type Info = typeof Info.Type;
export declare const CreateInput: Schema.Struct<{
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"in">;
        readonly in: Schema.String;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"at">;
        readonly at: Schema.String;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"every">;
        readonly every: Schema.String;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"cron">;
        readonly cron: Schema.String;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"in">;
        readonly in: Schema.String;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"at">;
        readonly at: Schema.String;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"every">;
        readonly every: Schema.String;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"cron">;
        readonly cron: Schema.String;
    }>]>>, never, never>;
    readonly if: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"shell">;
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"code">;
        readonly code: Schema.String;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"shell">;
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"code">;
        readonly code: Schema.String;
    }>]>>, never, never>;
    readonly until: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"shell">;
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"code">;
        readonly code: Schema.String;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"shell">;
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"code">;
        readonly code: Schema.String;
    }>]>>, never, never>;
    readonly ends: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly after: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly times: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly after: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly times: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>, never, never>;
    readonly action: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"prompt">;
        readonly prompt: Schema.String;
    }>]>;
}>;
export type CreateInput = typeof CreateInput.Type;
/** The `when` callers write: exactly one of `in`, `at`, `every` or `cron`, with an optional `tz`. */
export declare const WhenInput: Schema.Union<readonly [Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly in: Schema.String;
    readonly at: Schema.optionalKey<Schema.Never>;
    readonly every: Schema.optionalKey<Schema.Never>;
    readonly cron: Schema.optionalKey<Schema.Never>;
}>, Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly at: Schema.String;
    readonly in: Schema.optionalKey<Schema.Never>;
    readonly every: Schema.optionalKey<Schema.Never>;
    readonly cron: Schema.optionalKey<Schema.Never>;
}>, Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly every: Schema.String;
    readonly in: Schema.optionalKey<Schema.Never>;
    readonly at: Schema.optionalKey<Schema.Never>;
    readonly cron: Schema.optionalKey<Schema.Never>;
}>, Schema.Struct<{
    readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly cron: Schema.String;
    readonly in: Schema.optionalKey<Schema.Never>;
    readonly at: Schema.optionalKey<Schema.Never>;
    readonly every: Schema.optionalKey<Schema.Never>;
}>]>;
export type WhenInput = typeof WhenInput.Type;
export declare const ShellConditionInput: Schema.Struct<{
    readonly run: Schema.String;
    readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>;
export declare const CodeConditionInput: Schema.Struct<{
    readonly code: Schema.String;
}>;
export declare const ConditionInput: Schema.Union<readonly [Schema.Struct<{
    readonly run: Schema.String;
    readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly code: Schema.optionalKey<Schema.Never>;
}>, Schema.Struct<{
    readonly code: Schema.String;
    readonly run: Schema.optionalKey<Schema.Never>;
    readonly is: Schema.optionalKey<Schema.Never>;
    readonly matches: Schema.optionalKey<Schema.Never>;
    readonly changes: Schema.optionalKey<Schema.Never>;
}>]>;
export type ConditionInput = typeof ConditionInput.Type;
/** A schedule as callers describe it: when it fires, optional condition, when it stops, and the prompt it sends. */
export declare const Request: Schema.Struct<{
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly in: Schema.String;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly every: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly cron: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly in: Schema.String;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly every: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly cron: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly tz: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly cron: Schema.String;
        readonly in: Schema.optionalKey<Schema.Never>;
        readonly at: Schema.optionalKey<Schema.Never>;
        readonly every: Schema.optionalKey<Schema.Never>;
    }>]>>, never, never>;
    readonly if: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>, never, never>;
    readonly until: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly run: Schema.String;
        readonly is: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly matches: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly changes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly code: Schema.optionalKey<Schema.Never>;
    }>, Schema.Struct<{
        readonly code: Schema.String;
        readonly run: Schema.optionalKey<Schema.Never>;
        readonly is: Schema.optionalKey<Schema.Never>;
        readonly matches: Schema.optionalKey<Schema.Never>;
        readonly changes: Schema.optionalKey<Schema.Never>;
    }>]>>, never, never>;
    readonly ends: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly after: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly times: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly after: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly at: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly times: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>, never, never>;
    readonly prompt: Schema.String;
}>;
export type Request = typeof Request.Type;
export declare const toCreateInput: (sessionID: SessionID, request: Request) => CreateInput;
