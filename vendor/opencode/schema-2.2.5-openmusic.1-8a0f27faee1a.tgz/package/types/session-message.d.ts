export * as SessionMessage from "./session-message.js";
import { Schema } from "effect";
export declare const ID: Schema.brand<Schema.String, "Session.Message.ID"> & {
    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
};
export type ID = typeof ID.Type;
/**
 * Provider-owned replay data, keyed by the producing provider's metadata fields and echoed back verbatim. A tool's
 * result data is merged into its call data, so adapters must not reuse a key with a different value across the two.
 */
export declare const Native: Schema.$Record<Schema.String, Schema.Unknown>;
export type Native = typeof Native.Type;
export interface AgentSelected extends Schema.Schema.Type<typeof AgentSelected> {
}
export declare const AgentSelected: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"agent-switched">;
    readonly agent: Schema.brand<Schema.String, "Agent.ID">;
    readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
}>;
export interface ModelSelected extends Schema.Schema.Type<typeof ModelSelected> {
}
export declare const ModelSelected: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"model-switched">;
    readonly model: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    };
    readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>>, Schema.optionalKey<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>, never, never>;
}>;
export interface LocationSwitched extends Schema.Schema.Type<typeof LocationSwitched> {
}
export declare const LocationSwitched: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"location-switched">;
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>;
    readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    }>, never, never>;
    readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    }>>, never, never>;
}>;
export interface User extends Schema.Schema.Type<typeof User> {
}
export declare const User: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly text: Schema.String;
    readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }>>, never, never>;
    readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly type: Schema.tag<"user">;
}>;
/** A {@link User} whose files may stay on the server, for clients that opt into `experimental-media-uri`. */
export interface MediaUser extends Schema.Schema.Type<typeof MediaUser> {
}
export declare const MediaUser: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly text: Schema.String;
    readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly type: Schema.tag<"user">;
    readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }, Schema.Struct<{
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
        readonly uri: Schema.String;
        readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>]>>>>, Schema.optionalKey<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }, Schema.Struct<{
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
        readonly uri: Schema.String;
        readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>]>>>, never, never>;
}>;
export interface Synthetic extends Schema.Schema.Type<typeof Synthetic> {
}
export declare const Synthetic: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly text: Schema.String;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.tag<"synthetic">;
}>;
export interface System extends Schema.Schema.Type<typeof System> {
}
export declare const System: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"system">;
    /** The model-facing update text, frozen at emit time. */
    readonly text: Schema.String;
    /** A short human-readable summary for transcript display. */
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>;
export interface Skill extends Schema.Schema.Type<typeof Skill> {
}
export declare const Skill: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"skill">;
    readonly skill: Schema.brand<Schema.String, "Skill.ID">;
    readonly name: Schema.brand<Schema.String, "Skill.Name">;
    readonly text: Schema.String;
}>;
export interface Shell extends Schema.Schema.Type<typeof Shell> {
}
export declare const Shell: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.tag<"shell">;
    readonly shellID: Schema.brand<Schema.String, "Shell.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Shell.ID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
    };
    readonly command: Schema.String;
    readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
    readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly output: Schema.String;
        readonly cursor: Schema.Int;
        readonly size: Schema.Int;
        readonly truncated: Schema.Boolean;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly output: Schema.String;
        readonly cursor: Schema.Int;
        readonly size: Schema.Int;
        readonly truncated: Schema.Boolean;
    }>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>;
}>;
export interface ToolStateStreaming extends Schema.Schema.Type<typeof ToolStateStreaming> {
}
export declare const ToolStateStreaming: Schema.Struct<{
    readonly status: Schema.tag<"streaming">;
    readonly input: Schema.String;
}>;
export interface ToolStateRunning extends Schema.Schema.Type<typeof ToolStateRunning> {
}
export declare const ToolStateRunning: Schema.Struct<{
    readonly status: Schema.tag<"running">;
    readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
}>;
export interface ToolStateCompleted extends Schema.Schema.Type<typeof ToolStateCompleted> {
}
export declare const ToolStateCompleted: Schema.Struct<{
    readonly status: Schema.tag<"completed">;
    readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"file">;
        readonly uri: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.optional<Schema.String>;
    }>]>>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
}>;
export interface ToolStateError extends Schema.Schema.Type<typeof ToolStateError> {
}
export declare const ToolStateError: Schema.Struct<{
    readonly status: Schema.tag<"error">;
    readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly error: Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"file">;
        readonly uri: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.optional<Schema.String>;
    }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"file">;
        readonly uri: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.optional<Schema.String>;
    }>]>>>, never, never>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
}>;
export declare const ToolState: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
    readonly status: Schema.tag<"streaming">;
    readonly input: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.tag<"running">;
    readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
}>, Schema.Struct<{
    readonly status: Schema.tag<"completed">;
    readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"file">;
        readonly uri: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.optional<Schema.String>;
    }>]>>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
}>, Schema.Struct<{
    readonly status: Schema.tag<"error">;
    readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly error: Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"file">;
        readonly uri: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.optional<Schema.String>;
    }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"file">;
        readonly uri: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.optional<Schema.String>;
    }>]>>>, never, never>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
}>]>;
export type ToolState = ToolStateStreaming | ToolStateRunning | ToolStateCompleted | ToolStateError;
export interface AssistantTool extends Schema.Schema.Type<typeof AssistantTool> {
}
export declare const AssistantTool: Schema.Struct<{
    readonly type: Schema.tag<"tool">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
        readonly status: Schema.tag<"streaming">;
        readonly input: Schema.String;
    }>, Schema.Struct<{
        readonly status: Schema.tag<"running">;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>, Schema.Struct<{
        readonly status: Schema.tag<"completed">;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
    }>, Schema.Struct<{
        readonly status: Schema.tag<"error">;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
    }>]>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>;
}>;
export interface AssistantText extends Schema.Schema.Type<typeof AssistantText> {
}
export declare const AssistantText: Schema.Struct<{
    readonly type: Schema.tag<"text">;
    readonly text: Schema.String;
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>;
export interface AssistantReasoning extends Schema.Schema.Type<typeof AssistantReasoning> {
}
export declare const AssistantReasoning: Schema.Struct<{
    readonly type: Schema.tag<"reasoning">;
    readonly text: Schema.String;
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>>, never, never>;
}>;
export declare const AssistantContent: Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
    readonly type: Schema.tag<"text">;
    readonly text: Schema.String;
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"reasoning">;
    readonly text: Schema.String;
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
        readonly status: Schema.tag<"streaming">;
        readonly input: Schema.String;
    }>, Schema.Struct<{
        readonly status: Schema.tag<"running">;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>, Schema.Struct<{
        readonly status: Schema.tag<"completed">;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
    }>, Schema.Struct<{
        readonly status: Schema.tag<"error">;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
    }>]>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>;
}>]>;
export type AssistantContent = AssistantText | AssistantReasoning | AssistantTool;
export declare const AssistantContentEncoded: Schema.toEncoded<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
    readonly type: Schema.tag<"text">;
    readonly text: Schema.String;
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"reasoning">;
    readonly text: Schema.String;
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
        readonly status: Schema.tag<"streaming">;
        readonly input: Schema.String;
    }>, Schema.Struct<{
        readonly status: Schema.tag<"running">;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
    }>, Schema.Struct<{
        readonly status: Schema.tag<"completed">;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
    }>, Schema.Struct<{
        readonly status: Schema.tag<"error">;
        readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
        readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
    }>]>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>;
}>]>>;
export type AssistantContentEncoded = typeof AssistantContentEncoded.Type;
export interface AssistantRetry extends Schema.Schema.Type<typeof AssistantRetry> {
}
export declare const AssistantRetry: Schema.Struct<{
    readonly attempt: Schema.Int;
    readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    readonly error: Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}>;
export interface Assistant extends Schema.Schema.Type<typeof Assistant> {
}
export declare const Assistant: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.tag<"assistant">;
    readonly agent: Schema.brand<Schema.String, "Agent.ID">;
    readonly model: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    };
    readonly content: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
        readonly type: Schema.tag<"text">;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"reasoning">;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"tool">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
            readonly status: Schema.tag<"streaming">;
            readonly input: Schema.String;
        }>, Schema.Struct<{
            readonly status: Schema.tag<"running">;
            readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
        }>, Schema.Struct<{
            readonly status: Schema.tag<"completed">;
            readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        }>, Schema.Struct<{
            readonly status: Schema.tag<"error">;
            readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
            readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>>, never, never>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        }>]>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
    }>]>>;
    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>>, never, never>;
    readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>>, Schema.optionalKey<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>, never, never>;
    readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    /** Step-level native data, such as a provider's reason for blocking a response. */
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>, never, never>;
    readonly retry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly attempt: Schema.Int;
        readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly attempt: Schema.Int;
        readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        /** When the provider response body ended, before tool settlement. */
        readonly streamed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>;
}>;
export interface CompactionRunning extends Schema.Schema.Type<typeof CompactionRunning> {
}
export declare const CompactionRunning: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly status: Schema.tag<"running">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly summary: Schema.String;
}>;
export interface CompactionCompleted extends Schema.Schema.Type<typeof CompactionCompleted> {
}
export declare const CompactionCompleted: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly status: Schema.tag<"completed">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>>, Schema.optionalKey<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>, never, never>;
    /** A provider compaction stores its replacement window in `native.messages`, replayed instead of `summary`. */
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly summary: Schema.String;
}>;
export interface CompactionFailed extends Schema.Schema.Type<typeof CompactionFailed> {
}
export declare const CompactionFailed: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly status: Schema.tag<"failed">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly error: Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}>;
export declare const Compaction: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly status: Schema.tag<"running">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly summary: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly status: Schema.tag<"completed">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>>, Schema.optionalKey<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>, never, never>;
    /** A provider compaction stores its replacement window in `native.messages`, replayed instead of `summary`. */
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly summary: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly status: Schema.tag<"failed">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly error: Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}>]>;
export type Compaction = CompactionRunning | CompactionCompleted | CompactionFailed;
/**
 * Marks the Session going idle: every step since the previous marker belongs to
 * one turn, including prompts steered in while it was busy. A shutdown does not
 * record one, since the resumed execution continues the same turn.
 */
export interface Idle extends Schema.Schema.Type<typeof Idle> {
}
export declare const Idle: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"idle">;
    readonly outcome: Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>;
    readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>, never, never>;
}>;
export declare const Info: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"agent-switched">;
    readonly agent: Schema.brand<Schema.String, "Agent.ID">;
    readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"model-switched">;
    readonly model: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    };
    readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>>, Schema.optionalKey<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>, never, never>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"location-switched">;
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>;
    readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    }>, never, never>;
    readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    }>>, never, never>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly text: Schema.String;
    readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }>>, never, never>;
    readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly type: Schema.tag<"user">;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly text: Schema.String;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.tag<"synthetic">;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"system">;
    /** The model-facing update text, frozen at emit time. */
    readonly text: Schema.String;
    /** A short human-readable summary for transcript display. */
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"skill">;
    readonly skill: Schema.brand<Schema.String, "Skill.ID">;
    readonly name: Schema.brand<Schema.String, "Skill.Name">;
    readonly text: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.tag<"shell">;
    readonly shellID: Schema.brand<Schema.String, "Shell.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Shell.ID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
    };
    readonly command: Schema.String;
    readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
    readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly output: Schema.String;
        readonly cursor: Schema.Int;
        readonly size: Schema.Int;
        readonly truncated: Schema.Boolean;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly output: Schema.String;
        readonly cursor: Schema.Int;
        readonly size: Schema.Int;
        readonly truncated: Schema.Boolean;
    }>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.tag<"assistant">;
    readonly agent: Schema.brand<Schema.String, "Agent.ID">;
    readonly model: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    };
    readonly content: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
        readonly type: Schema.tag<"text">;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"reasoning">;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"tool">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
            readonly status: Schema.tag<"streaming">;
            readonly input: Schema.String;
        }>, Schema.Struct<{
            readonly status: Schema.tag<"running">;
            readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
        }>, Schema.Struct<{
            readonly status: Schema.tag<"completed">;
            readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        }>, Schema.Struct<{
            readonly status: Schema.tag<"error">;
            readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
            readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>>, never, never>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        }>]>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
    }>]>>;
    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>>, never, never>;
    readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>>, Schema.optionalKey<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>, never, never>;
    readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    /** Step-level native data, such as a provider's reason for blocking a response. */
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>, never, never>;
    readonly retry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly attempt: Schema.Int;
        readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly attempt: Schema.Int;
        readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        /** When the provider response body ended, before tool settlement. */
        readonly streamed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>;
}>, Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly status: Schema.tag<"running">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly summary: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly status: Schema.tag<"completed">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>>, Schema.optionalKey<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>, never, never>;
    /** A provider compaction stores its replacement window in `native.messages`, replayed instead of `summary`. */
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly summary: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly status: Schema.tag<"failed">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly error: Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}>]>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"idle">;
    readonly outcome: Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>;
    readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>, never, never>;
}>]>;
export type Info = AgentSelected | ModelSelected | LocationSwitched | User | Synthetic | System | Skill | Shell | Assistant | Compaction | Idle;
export type Type = Info["type"];
/** {@link Info} with {@link MediaUser} for clients that opt into `experimental-media-uri`. */
export declare const MediaInfo: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"agent-switched">;
    readonly agent: Schema.brand<Schema.String, "Agent.ID">;
    readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"model-switched">;
    readonly model: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    };
    readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>>, Schema.optionalKey<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>, never, never>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"location-switched">;
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>;
    readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    }>, never, never>;
    readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    }>>, never, never>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly text: Schema.String;
    readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly type: Schema.tag<"user">;
    readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }, Schema.Struct<{
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
        readonly uri: Schema.String;
        readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>]>>>>, Schema.optionalKey<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }, Schema.Struct<{
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
        readonly uri: Schema.String;
        readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>]>>>, never, never>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly text: Schema.String;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.tag<"synthetic">;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"system">;
    /** The model-facing update text, frozen at emit time. */
    readonly text: Schema.String;
    /** A short human-readable summary for transcript display. */
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"skill">;
    readonly skill: Schema.brand<Schema.String, "Skill.ID">;
    readonly name: Schema.brand<Schema.String, "Skill.Name">;
    readonly text: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.tag<"shell">;
    readonly shellID: Schema.brand<Schema.String, "Shell.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Shell.ID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
    };
    readonly command: Schema.String;
    readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
    readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly output: Schema.String;
        readonly cursor: Schema.Int;
        readonly size: Schema.Int;
        readonly truncated: Schema.Boolean;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly output: Schema.String;
        readonly cursor: Schema.Int;
        readonly size: Schema.Int;
        readonly truncated: Schema.Boolean;
    }>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.tag<"assistant">;
    readonly agent: Schema.brand<Schema.String, "Agent.ID">;
    readonly model: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    };
    readonly content: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
        readonly type: Schema.tag<"text">;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"reasoning">;
        readonly text: Schema.String;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"tool">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
            readonly status: Schema.tag<"streaming">;
            readonly input: Schema.String;
        }>, Schema.Struct<{
            readonly status: Schema.tag<"running">;
            readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
        }>, Schema.Struct<{
            readonly status: Schema.tag<"completed">;
            readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        }>, Schema.Struct<{
            readonly status: Schema.tag<"error">;
            readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
            readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>>, never, never>;
            readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        }>]>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
    }>]>>;
    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
    }>>, never, never>;
    readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>>, Schema.optionalKey<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>, never, never>;
    readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    /** Step-level native data, such as a provider's reason for blocking a response. */
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>, never, never>;
    readonly retry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly attempt: Schema.Int;
        readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly attempt: Schema.Int;
        readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        /** When the provider response body ended, before tool settlement. */
        readonly streamed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>;
}>, Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly status: Schema.tag<"running">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly summary: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly status: Schema.tag<"completed">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>>, Schema.optionalKey<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>, never, never>;
    /** A provider compaction stores its replacement window in `native.messages`, replayed instead of `summary`. */
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly summary: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"compaction">;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly status: Schema.tag<"failed">;
    readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
    readonly error: Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}>]>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly type: Schema.tag<"idle">;
    readonly outcome: Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>;
    readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly type: Schema.String;
        readonly message: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly body: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly body: Schema.String;
        }>>, never, never>;
        readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>>, never, never>;
}>]>;
export type MediaInfo = Exclude<Info, User> | MediaUser;
