export * as CredentialLegacy from "./credential-legacy.js";
import { Schema } from "effect";
/** Decodes a stored or exported credential value of either shape into the current `Credential.Value`. */
export declare const Value: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"oauth">;
    readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly refresh: Schema.String;
    readonly access: Schema.String;
    readonly expires: Schema.Int;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>, Schema.decodeTo<Schema.Struct<{
    readonly type: Schema.Literal<"key">;
    readonly key: Schema.String;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"key">;
    readonly key: Schema.String;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly configuration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>>, never, never>;
}>, never, never>, Schema.Struct<{
    readonly type: Schema.Literal<"external">;
    readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>]>;
/** Decodes an `auth export` entry of either shape into the current `Credential.Entry`. */
export declare const Entry: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Credential.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Credential.ID">;
    };
    readonly integrationID: Schema.brand<Schema.String, "Integration.ID">;
    readonly label: Schema.String;
    readonly active: Schema.Boolean;
    readonly value: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"oauth">;
        readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
        readonly refresh: Schema.String;
        readonly access: Schema.String;
        readonly expires: Schema.Int;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>, Schema.decodeTo<Schema.Struct<{
        readonly type: Schema.Literal<"key">;
        readonly key: Schema.String;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"key">;
        readonly key: Schema.String;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly configuration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>>, never, never>;
    }>, never, never>, Schema.Struct<{
        readonly type: Schema.Literal<"external">;
        readonly methodID: Schema.brand<Schema.String, "Integration.MethodID">;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>]>;
}>;
