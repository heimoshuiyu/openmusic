export * as Job from "./job.js";
import { Schema } from "effect";
export declare const Kind: Schema.Literals<readonly ["shell", "subagent", "image"]>;
export type Kind = typeof Kind.Type;
export declare const Status: Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>;
export type Status = typeof Status.Type;
export interface Time extends Schema.Schema.Type<typeof Time> {
}
export declare const Time: Schema.Struct<{
    readonly started: Schema.Finite;
    readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
}>;
export interface Shell extends Schema.Schema.Type<typeof Shell> {
}
export declare const Shell: Schema.Struct<{
    readonly id: Schema.String;
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly status: Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly time: Schema.Struct<{
        readonly started: Schema.Finite;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>;
    readonly kind: Schema.tag<"shell">;
    readonly shellID: Schema.String;
    readonly command: Schema.String;
}>;
export interface Subagent extends Schema.Schema.Type<typeof Subagent> {
}
export declare const Subagent: Schema.Struct<{
    readonly id: Schema.String;
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly status: Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly time: Schema.Struct<{
        readonly started: Schema.Finite;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>;
    readonly kind: Schema.tag<"subagent">;
    readonly childSessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly agent: Schema.String;
    readonly description: Schema.String;
}>;
export interface Image extends Schema.Schema.Type<typeof Image> {
}
export declare const Image: Schema.Struct<{
    readonly id: Schema.String;
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly status: Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly time: Schema.Struct<{
        readonly started: Schema.Finite;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>;
    readonly kind: Schema.tag<"image">;
    readonly path: Schema.String;
    readonly model: Schema.String;
}>;
export declare const Info: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.String;
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly status: Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly time: Schema.Struct<{
        readonly started: Schema.Finite;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>;
    readonly kind: Schema.tag<"shell">;
    readonly shellID: Schema.String;
    readonly command: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.String;
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly status: Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly time: Schema.Struct<{
        readonly started: Schema.Finite;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>;
    readonly kind: Schema.tag<"subagent">;
    readonly childSessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly agent: Schema.String;
    readonly description: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.String;
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly status: Schema.Literals<readonly ["running", "completed", "error", "cancelled"]>;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly time: Schema.Struct<{
        readonly started: Schema.Finite;
        readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>;
    readonly kind: Schema.tag<"image">;
    readonly path: Schema.String;
    readonly model: Schema.String;
}>]>;
export type Info = typeof Info.Type;
