export * as Artifact from "./artifact.js";
import { Schema } from "effect";
export declare const ID: Schema.brand<Schema.String, "Artifact.ID"> & {
    create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
};
export type ID = typeof ID.Type;
export declare const ProviderID: Schema.brand<Schema.Trim, "Artifact.ProviderID">;
export type ProviderID = typeof ProviderID.Type;
export declare const Capability: Schema.Literals<readonly ["static", "server-code", "sqlite", "durable-objects"]>;
export type Capability = typeof Capability.Type;
export interface Provider extends Schema.Schema.Type<typeof Provider> {
}
export declare const Provider: Schema.Struct<{
    readonly id: Schema.brand<Schema.Trim, "Artifact.ProviderID">;
    readonly name: Schema.String;
    readonly capabilities: Schema.$Array<Schema.Literals<readonly ["static", "server-code", "sqlite", "durable-objects"]>>;
    readonly default: Schema.Boolean;
}>;
export interface Time extends Schema.Schema.Type<typeof Time> {
}
export declare const Time: Schema.Struct<{
    readonly created: Schema.Finite;
    readonly updated: Schema.Finite;
}>;
export interface Info extends Schema.Schema.Type<typeof Info> {
}
export declare const Info: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Artifact.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
    };
    readonly provider: Schema.brand<Schema.Trim, "Artifact.ProviderID">;
    readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
    readonly title: Schema.String;
    readonly entry: Schema.String;
    readonly url: Schema.String;
    readonly time: Schema.Struct<{
        readonly created: Schema.Finite;
        readonly updated: Schema.Finite;
    }>;
}>;
export interface Content extends Schema.Schema.Type<typeof Content> {
}
export declare const Content: Schema.Struct<{
    readonly info: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Artifact.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Artifact.ID">;
        };
        readonly provider: Schema.brand<Schema.Trim, "Artifact.ProviderID">;
        readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly title: Schema.String;
        readonly entry: Schema.String;
        readonly url: Schema.String;
        readonly time: Schema.Struct<{
            readonly created: Schema.Finite;
            readonly updated: Schema.Finite;
        }>;
    }>;
    readonly files: Schema.$Record<Schema.String, Schema.String>;
}>;
export interface CreateInput extends Schema.Schema.Type<typeof CreateInput> {
}
export declare const CreateInput: Schema.Struct<{
    readonly title: Schema.String;
    readonly files: Schema.$Record<Schema.String, Schema.String>;
    readonly entry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly provider: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Trim, "Artifact.ProviderID">>>, Schema.optionalKey<Schema.brand<Schema.Trim, "Artifact.ProviderID">>, never, never>;
    readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
}>;
export interface UpdateInput extends Schema.Schema.Type<typeof UpdateInput> {
}
export declare const UpdateInput: Schema.Struct<{
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly files: Schema.$Record<Schema.String, Schema.String>;
    readonly entry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly sessionID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
}>;
export declare const Event: {
    Updated: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"artifact.updated">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{}>;
    }> & {
        type: "artifact.updated";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{}>;
    };
    Definitions: readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"artifact.updated">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{}>;
    }> & {
        type: "artifact.updated";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{}>;
    }];
};
