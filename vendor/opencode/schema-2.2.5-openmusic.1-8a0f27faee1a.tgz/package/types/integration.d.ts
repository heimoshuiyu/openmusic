export * as Integration from "./integration.js";
import { Schema } from "effect";
export declare const ID: Schema.brand<Schema.String, "Integration.ID">;
export type ID = typeof ID.Type;
export declare const MethodID: Schema.brand<Schema.String, "Integration.MethodID">;
export type MethodID = typeof MethodID.Type;
export interface OAuthMethod extends Schema.Schema.Type<typeof OAuthMethod> {
}
export declare const OAuthMethod: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly type: Schema.Literal<"oauth">;
    readonly label: Schema.String;
    readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>, never, never>;
}>;
export interface CommandMethod extends Schema.Schema.Type<typeof CommandMethod> {
}
export declare const CommandMethod: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly type: Schema.Literal<"command">;
    readonly label: Schema.String;
    readonly command: Schema.$Array<Schema.String>;
}>;
export interface KeyMethod extends Schema.Schema.Type<typeof KeyMethod> {
}
export declare const KeyMethod: Schema.Struct<{
    readonly type: Schema.Literal<"key">;
    readonly label: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>, never, never>;
}>;
/** Saves a reference to credentials managed outside opencode, configured by the form answers. */
export interface ExternalMethod extends Schema.Schema.Type<typeof ExternalMethod> {
}
export declare const ExternalMethod: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly type: Schema.Literal<"external">;
    readonly label: Schema.String;
    readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>, never, never>;
}>;
export interface EnvMethod extends Schema.Schema.Type<typeof EnvMethod> {
}
export declare const EnvMethod: Schema.Struct<{
    readonly type: Schema.Literal<"env">;
    readonly names: Schema.$Array<Schema.String>;
}>;
export declare const Method: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly type: Schema.Literal<"oauth">;
    readonly label: Schema.String;
    readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>, never, never>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly type: Schema.Literal<"command">;
    readonly label: Schema.String;
    readonly command: Schema.$Array<Schema.String>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"key">;
    readonly label: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>, never, never>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
    readonly type: Schema.Literal<"external">;
    readonly label: Schema.String;
    readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"env">;
    readonly names: Schema.$Array<Schema.String>;
}>]>;
export type Method = typeof Method.Type;
export declare const Event: {
    Updated: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"integration.updated">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{}>;
    }> & {
        type: "integration.updated";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{}>;
    };
    Definitions: readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"integration.updated">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{}>;
    }> & {
        type: "integration.updated";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{}>;
    }];
};
export interface Ref extends Schema.Schema.Type<typeof Ref> {
}
export declare const Ref: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Integration.ID">;
    readonly name: Schema.String;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
}>;
export declare const Info: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Integration.ID">;
    readonly name: Schema.String;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
    readonly methods: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
        readonly type: Schema.Literal<"oauth">;
        readonly label: Schema.String;
        readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"string">;
            readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
            readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"number">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"integer">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"boolean">;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"multiselect">;
            readonly options: Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>;
            readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly type: Schema.Literal<"external">;
            readonly url: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"string">;
            readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
            readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"number">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"integer">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"boolean">;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"multiselect">;
            readonly options: Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>;
            readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly type: Schema.Literal<"external">;
            readonly url: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
        readonly type: Schema.Literal<"command">;
        readonly label: Schema.String;
        readonly command: Schema.$Array<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"key">;
        readonly label: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"string">;
            readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
            readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"number">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"integer">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"boolean">;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"multiselect">;
            readonly options: Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>;
            readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly type: Schema.Literal<"external">;
            readonly url: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"string">;
            readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
            readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"number">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"integer">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"boolean">;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"multiselect">;
            readonly options: Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>;
            readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly type: Schema.Literal<"external">;
            readonly url: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Integration.MethodID">;
        readonly type: Schema.Literal<"external">;
        readonly label: Schema.String;
        readonly form: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"string">;
            readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
            readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"number">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"integer">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"boolean">;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"multiselect">;
            readonly options: Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>;
            readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly type: Schema.Literal<"external">;
            readonly url: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"string">;
            readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
            readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"number">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"integer">;
            readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"boolean">;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly key: Schema.String;
                readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
            }>>>, never, never>;
            readonly type: Schema.Literal<"multiselect">;
            readonly options: Schema.$Array<Schema.Struct<{
                readonly value: Schema.String;
                readonly label: Schema.String;
                readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>>;
            readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
        }>, Schema.Struct<{
            readonly key: Schema.String;
            readonly type: Schema.Literal<"external">;
            readonly url: Schema.String;
            readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"env">;
        readonly names: Schema.$Array<Schema.String>;
    }>]>>;
    readonly connections: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"credential">;
        readonly id: Schema.brand<Schema.String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        };
        readonly label: Schema.String;
        readonly method: Schema.Literals<readonly ["key", "oauth", "external"]>;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly status: Schema.Literals<readonly ["needs_auth"]>;
            readonly message: Schema.String;
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly status: Schema.Literals<readonly ["needs_auth"]>;
            readonly message: Schema.String;
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"env">;
        readonly name: Schema.String;
        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly status: Schema.Literals<readonly ["needs_auth"]>;
            readonly message: Schema.String;
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly status: Schema.Literals<readonly ["needs_auth"]>;
            readonly message: Schema.String;
            readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
    }>]>>;
}>;
export interface Info extends Schema.Schema.Type<typeof Info> {
}
export declare const AttemptID: Schema.brand<Schema.String, "Integration.AttemptID"> & {
    create: () => string & import("effect/Brand").Brand<"Integration.AttemptID">;
};
export type AttemptID = typeof AttemptID.Type;
declare const Attempt_base: Schema.Class<Attempt, Schema.Struct<{
    readonly attemptID: Schema.brand<Schema.String, "Integration.AttemptID"> & {
        create: () => string & import("effect/Brand").Brand<"Integration.AttemptID">;
    };
    readonly url: Schema.String;
    readonly instructions: Schema.String;
    readonly mode: Schema.Literals<readonly ["auto", "code"]>;
    /** An `auto` attempt also accepts the redirect URL pasted from the browser as its `code`. */
    readonly paste: Schema.optionalKey<Schema.Literal<true>>;
    readonly time: Schema.Struct<{
        readonly created: Schema.Number;
        readonly expires: Schema.Number;
    }>;
}>, {}>;
export declare class Attempt extends Attempt_base {
}
export declare const AttemptStatus: Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"pending">;
    readonly time: Schema.Struct<{
        readonly created: Schema.Number;
        readonly expires: Schema.Number;
    }>;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"complete">;
    readonly time: Schema.Struct<{
        readonly created: Schema.Number;
        readonly expires: Schema.Number;
    }>;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly message: Schema.String;
    readonly time: Schema.Struct<{
        readonly created: Schema.Number;
        readonly expires: Schema.Number;
    }>;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"expired">;
    readonly time: Schema.Struct<{
        readonly created: Schema.Number;
        readonly expires: Schema.Number;
    }>;
}>]>;
export type AttemptStatus = typeof AttemptStatus.Type;
export interface CommandAttempt extends Schema.Schema.Type<typeof CommandAttempt> {
}
export declare const CommandAttempt: Schema.Struct<{
    readonly attemptID: Schema.brand<Schema.String, "Integration.AttemptID"> & {
        create: () => string & import("effect/Brand").Brand<"Integration.AttemptID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.Number;
        readonly expires: Schema.Number;
    }>;
}>;
export declare const CommandAttemptStatus: Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"pending">;
    readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.Number;
        readonly expires: Schema.Number;
    }>;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"complete">;
    readonly time: Schema.Struct<{
        readonly created: Schema.Number;
        readonly expires: Schema.Number;
    }>;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"failed">;
    readonly message: Schema.String;
    readonly time: Schema.Struct<{
        readonly created: Schema.Number;
        readonly expires: Schema.Number;
    }>;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"expired">;
    readonly time: Schema.Struct<{
        readonly created: Schema.Number;
        readonly expires: Schema.Number;
    }>;
}>]>;
export type CommandAttemptStatus = typeof CommandAttemptStatus.Type;
