export * as SessionTransfer from "./session-transfer.js";
import { Schema } from "effect";
export interface Data extends Schema.Schema.Type<typeof Data> {
}
export declare const Data: Schema.Struct<{
    readonly info: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly fork: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly boundary: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"before">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"through">;
                readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                    create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                    fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
            }>]>;
        }>>, never, never>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>;
        readonly outcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>>, Schema.optionalKey<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly busy: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly idle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly viewed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
        readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly action: Schema.String;
            readonly resource: Schema.String;
            readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                readonly file: Schema.String;
                readonly patch: Schema.String;
                readonly additions: Schema.Int;
                readonly deletions: Schema.Int;
                readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
            }>>>, never, never>;
        }>>, never, never>;
    }>;
    readonly messages: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"agent-switched">;
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"model-switched">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"location-switched">;
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>, never, never>;
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        readonly previous: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly location: Schema.Struct<{
                readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
            }>;
            readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>, never, never>;
            readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly location: Schema.Struct<{
                readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
            }>;
            readonly projectID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Project.ID"> & {
                global: string & import("effect/Brand").Brand<"Project.ID">;
            }>, never, never>;
            readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
        }>>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly text: Schema.String;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>, never, never>;
        readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly type: Schema.tag<"user">;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.tag<"synthetic">;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"system">;
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"skill">;
        readonly skill: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.tag<"shell">;
        readonly shellID: Schema.brand<Schema.String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly command: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited", "timeout", "killed"]>;
        readonly exit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly output: Schema.String;
            readonly cursor: Schema.Int;
            readonly size: Schema.Int;
            readonly truncated: Schema.Boolean;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.tag<"assistant">;
        readonly agent: Schema.brand<Schema.String, "Agent.ID">;
        readonly model: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly content: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
            readonly type: Schema.tag<"text">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"reasoning">;
            readonly text: Schema.String;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly time: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>>, never, never>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"tool">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly executed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
            readonly state: Schema.toTaggedUnion<"status", readonly [Schema.Struct<{
                readonly status: Schema.tag<"streaming">;
                readonly input: Schema.String;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"running">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"completed">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly content: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>, Schema.Struct<{
                readonly status: Schema.tag<"error">;
                readonly input: Schema.$Record<Schema.String, Schema.Unknown>;
                readonly error: Schema.Struct<{
                    readonly type: Schema.String;
                    readonly message: Schema.String;
                    readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>>, Schema.optionalKey<Schema.Struct<{
                        readonly body: Schema.String;
                    }>>, never, never>;
                    readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }>;
                readonly content: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>>, Schema.optionalKey<Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>>, never, never>;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
            }>]>;
            readonly time: Schema.Struct<{
                readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
                readonly ran: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
                readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            }>;
        }>]>>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
            readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>>, Schema.optionalKey<Schema.$Array<Schema.brand<Schema.String, "RelativePath">>>, never, never>;
        }>>, never, never>;
        readonly finish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>>, Schema.optionalKey<Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>>, never, never>;
        readonly rawFinish: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>, never, never>;
        readonly retry: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly attempt: Schema.Int;
            readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly attempt: Schema.Int;
            readonly at: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly error: Schema.Struct<{
                readonly type: Schema.String;
                readonly message: Schema.String;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly body: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly body: Schema.String;
                }>>, never, never>;
                readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            }>;
        }>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
            readonly streamed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
            readonly completed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        }>;
    }>, Schema.Union<readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly status: Schema.tag<"running">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly summary: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly status: Schema.tag<"completed">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, Schema.optionalKey<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Model.ID">;
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly summary: Schema.String;
    }>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"compaction">;
        readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly input: Schema.Finite;
            readonly output: Schema.Finite;
            readonly reasoning: Schema.Finite;
            readonly cache: Schema.Struct<{
                readonly read: Schema.Finite;
                readonly write: Schema.Finite;
            }>;
        }>>, never, never>;
        readonly status: Schema.tag<"failed">;
        readonly reason: Schema.Literals<readonly ["auto", "manual"]>;
        readonly error: Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>;
    }>]>, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly time: Schema.Struct<{
            readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        }>;
        readonly type: Schema.tag<"idle">;
        readonly outcome: Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>;
        readonly error: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly body: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly body: Schema.String;
            }>>, never, never>;
            readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>>, never, never>;
    }>]>>;
}>;
