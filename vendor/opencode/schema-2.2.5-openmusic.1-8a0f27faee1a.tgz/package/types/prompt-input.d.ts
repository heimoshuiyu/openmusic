export * as PromptInput from "./prompt-input.js";
import { Schema } from "effect";
export interface FileAttachment extends Schema.Schema.Type<typeof FileAttachment> {
}
export declare const FileAttachment: Schema.Struct<{
    readonly uri: Schema.String;
    readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"inline">;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"uri">;
        readonly uri: Schema.String;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"inline">;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"uri">;
        readonly uri: Schema.String;
    }>]>>, never, never>;
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly start: Schema.Finite;
        readonly end: Schema.Finite;
        readonly text: Schema.String;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly start: Schema.Finite;
        readonly end: Schema.Finite;
        readonly text: Schema.String;
    }>>, never, never>;
}>;
export interface Prompt extends Schema.Schema.Type<typeof Prompt> {
}
export interface SkillAttachment extends Schema.Schema.Type<typeof SkillAttachment> {
}
export declare const SkillAttachment: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Skill.ID">;
    readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly start: Schema.Finite;
        readonly end: Schema.Finite;
        readonly text: Schema.String;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly start: Schema.Finite;
        readonly end: Schema.Finite;
        readonly text: Schema.String;
    }>>, never, never>;
}>;
export declare const Prompt: Schema.Struct<{
    readonly text: Schema.String;
    readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly uri: Schema.String;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly uri: Schema.String;
        readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
}>;
