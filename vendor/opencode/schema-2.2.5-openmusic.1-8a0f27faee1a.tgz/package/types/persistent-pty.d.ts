export * as PersistentPty from "./persistent-pty.js";
import { Schema } from "effect";
export declare const Info: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
    readonly title: Schema.String;
    readonly command: Schema.String;
    readonly args: Schema.$Array<Schema.String>;
    readonly cwd: Schema.String;
    readonly status: Schema.Literals<readonly ["running", "exited"]>;
    readonly pid: Schema.Int;
    readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly userTitle: Schema.NullOr<Schema.String>;
    readonly foregroundProcess: Schema.NullOr<Schema.String>;
    readonly size: Schema.Struct<{
        readonly cols: Schema.Int;
        readonly rows: Schema.Int;
    }>;
    readonly output: Schema.Struct<{
        readonly head: Schema.Int;
        readonly tail: Schema.Int;
    }>;
}>;
export interface Info extends Schema.Schema.Type<typeof Info> {
}
export declare const Handoff: Schema.Struct<{
    readonly directory: Schema.String;
    readonly instanceID: Schema.String;
    readonly ticket: Schema.String;
    readonly expiresAt: Schema.Number;
}>;
export interface Handoff extends Schema.Schema.Type<typeof Handoff> {
}
export declare const CreateInput: Schema.Struct<{
    readonly command: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly args: Schema.$Array<Schema.String>;
    readonly cwd: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly title: Schema.String;
    readonly env: Schema.$Record<Schema.String, Schema.String>;
    readonly size: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly cols: Schema.Int;
        readonly rows: Schema.Int;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly cols: Schema.Int;
        readonly rows: Schema.Int;
    }>>, never, never>;
}>;
export interface CreateInput extends Schema.Schema.Type<typeof CreateInput> {
}
export declare const UpdateInput: Schema.Struct<{
    readonly attachmentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly size: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly cols: Schema.Int;
        readonly rows: Schema.Int;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly cols: Schema.Int;
        readonly rows: Schema.Int;
    }>>, never, never>;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.NullOr<Schema.String>>>, Schema.optionalKey<Schema.NullOr<Schema.String>>, never, never>;
}>;
export interface UpdateInput extends Schema.Schema.Type<typeof UpdateInput> {
}
export declare const Snapshot: Schema.Struct<{
    readonly info: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly title: Schema.String;
        readonly command: Schema.String;
        readonly args: Schema.$Array<Schema.String>;
        readonly cwd: Schema.String;
        readonly status: Schema.Literals<readonly ["running", "exited"]>;
        readonly pid: Schema.Int;
        readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly userTitle: Schema.NullOr<Schema.String>;
        readonly foregroundProcess: Schema.NullOr<Schema.String>;
        readonly size: Schema.Struct<{
            readonly cols: Schema.Int;
            readonly rows: Schema.Int;
        }>;
        readonly output: Schema.Struct<{
            readonly head: Schema.Int;
            readonly tail: Schema.Int;
        }>;
    }>;
    readonly text: Schema.String;
    readonly checkpoint: Schema.Uint8Array;
    readonly cursor: Schema.Struct<{
        readonly x: Schema.Int;
        readonly y: Schema.Int;
    }>;
}>;
export interface Snapshot extends Schema.Schema.Type<typeof Snapshot> {
}
export declare const ReadLines: Schema.Int;
export declare const ReadResult: Schema.Struct<{
    readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
        create: () => string & import("effect/Brand").Brand<"PtyID">;
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
    };
    readonly title: Schema.String;
    readonly cwd: Schema.String;
    readonly foregroundProcess: Schema.NullOr<Schema.String>;
    readonly screen: Schema.Struct<{
        readonly text: Schema.String;
        readonly cols: Schema.Int;
        readonly rows: Schema.Int;
        readonly cursor: Schema.Struct<{
            readonly x: Schema.Int;
            readonly y: Schema.Int;
        }>;
    }>;
}>;
export interface ReadResult extends Schema.Schema.Type<typeof ReadResult> {
}
export declare const Added: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"persistent-pty.added">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
}> & {
    type: "persistent-pty.added";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
};
export declare const Removed: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"persistent-pty.removed">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}> & {
    type: "persistent-pty.removed";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
};
export declare const Updated: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"persistent-pty.updated">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
}> & {
    type: "persistent-pty.updated";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: Schema.String;
            readonly command: Schema.String;
            readonly args: Schema.$Array<Schema.String>;
            readonly cwd: Schema.String;
            readonly status: Schema.Literals<readonly ["running", "exited"]>;
            readonly pid: Schema.Int;
            readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: Schema.NullOr<Schema.String>;
            readonly foregroundProcess: Schema.NullOr<Schema.String>;
            readonly size: Schema.Struct<{
                readonly cols: Schema.Int;
                readonly rows: Schema.Int;
            }>;
            readonly output: Schema.Struct<{
                readonly head: Schema.Int;
                readonly tail: Schema.Int;
            }>;
        }>;
    }>;
};
export declare const Event: {
    Added: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"persistent-pty.added">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly terminal: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "PtyID"> & {
                    create: () => string & import("effect/Brand").Brand<"PtyID">;
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
                };
                readonly title: Schema.String;
                readonly command: Schema.String;
                readonly args: Schema.$Array<Schema.String>;
                readonly cwd: Schema.String;
                readonly status: Schema.Literals<readonly ["running", "exited"]>;
                readonly pid: Schema.Int;
                readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly userTitle: Schema.NullOr<Schema.String>;
                readonly foregroundProcess: Schema.NullOr<Schema.String>;
                readonly size: Schema.Struct<{
                    readonly cols: Schema.Int;
                    readonly rows: Schema.Int;
                }>;
                readonly output: Schema.Struct<{
                    readonly head: Schema.Int;
                    readonly tail: Schema.Int;
                }>;
            }>;
        }>;
    }> & {
        type: "persistent-pty.added";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly terminal: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "PtyID"> & {
                    create: () => string & import("effect/Brand").Brand<"PtyID">;
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
                };
                readonly title: Schema.String;
                readonly command: Schema.String;
                readonly args: Schema.$Array<Schema.String>;
                readonly cwd: Schema.String;
                readonly status: Schema.Literals<readonly ["running", "exited"]>;
                readonly pid: Schema.Int;
                readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly userTitle: Schema.NullOr<Schema.String>;
                readonly foregroundProcess: Schema.NullOr<Schema.String>;
                readonly size: Schema.Struct<{
                    readonly cols: Schema.Int;
                    readonly rows: Schema.Int;
                }>;
                readonly output: Schema.Struct<{
                    readonly head: Schema.Int;
                    readonly tail: Schema.Int;
                }>;
            }>;
        }>;
    };
    Removed: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"persistent-pty.removed">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
        }>;
    }> & {
        type: "persistent-pty.removed";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
        }>;
    };
    Updated: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"persistent-pty.updated">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly terminal: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "PtyID"> & {
                    create: () => string & import("effect/Brand").Brand<"PtyID">;
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
                };
                readonly title: Schema.String;
                readonly command: Schema.String;
                readonly args: Schema.$Array<Schema.String>;
                readonly cwd: Schema.String;
                readonly status: Schema.Literals<readonly ["running", "exited"]>;
                readonly pid: Schema.Int;
                readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly userTitle: Schema.NullOr<Schema.String>;
                readonly foregroundProcess: Schema.NullOr<Schema.String>;
                readonly size: Schema.Struct<{
                    readonly cols: Schema.Int;
                    readonly rows: Schema.Int;
                }>;
                readonly output: Schema.Struct<{
                    readonly head: Schema.Int;
                    readonly tail: Schema.Int;
                }>;
            }>;
        }>;
    }> & {
        type: "persistent-pty.updated";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly terminal: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "PtyID"> & {
                    create: () => string & import("effect/Brand").Brand<"PtyID">;
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
                };
                readonly title: Schema.String;
                readonly command: Schema.String;
                readonly args: Schema.$Array<Schema.String>;
                readonly cwd: Schema.String;
                readonly status: Schema.Literals<readonly ["running", "exited"]>;
                readonly pid: Schema.Int;
                readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly userTitle: Schema.NullOr<Schema.String>;
                readonly foregroundProcess: Schema.NullOr<Schema.String>;
                readonly size: Schema.Struct<{
                    readonly cols: Schema.Int;
                    readonly rows: Schema.Int;
                }>;
                readonly output: Schema.Struct<{
                    readonly head: Schema.Int;
                    readonly tail: Schema.Int;
                }>;
            }>;
        }>;
    };
    Definitions: readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"persistent-pty.added">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly terminal: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "PtyID"> & {
                    create: () => string & import("effect/Brand").Brand<"PtyID">;
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
                };
                readonly title: Schema.String;
                readonly command: Schema.String;
                readonly args: Schema.$Array<Schema.String>;
                readonly cwd: Schema.String;
                readonly status: Schema.Literals<readonly ["running", "exited"]>;
                readonly pid: Schema.Int;
                readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly userTitle: Schema.NullOr<Schema.String>;
                readonly foregroundProcess: Schema.NullOr<Schema.String>;
                readonly size: Schema.Struct<{
                    readonly cols: Schema.Int;
                    readonly rows: Schema.Int;
                }>;
                readonly output: Schema.Struct<{
                    readonly head: Schema.Int;
                    readonly tail: Schema.Int;
                }>;
            }>;
        }>;
    }> & {
        type: "persistent-pty.added";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly terminal: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "PtyID"> & {
                    create: () => string & import("effect/Brand").Brand<"PtyID">;
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
                };
                readonly title: Schema.String;
                readonly command: Schema.String;
                readonly args: Schema.$Array<Schema.String>;
                readonly cwd: Schema.String;
                readonly status: Schema.Literals<readonly ["running", "exited"]>;
                readonly pid: Schema.Int;
                readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly userTitle: Schema.NullOr<Schema.String>;
                readonly foregroundProcess: Schema.NullOr<Schema.String>;
                readonly size: Schema.Struct<{
                    readonly cols: Schema.Int;
                    readonly rows: Schema.Int;
                }>;
                readonly output: Schema.Struct<{
                    readonly head: Schema.Int;
                    readonly tail: Schema.Int;
                }>;
            }>;
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"persistent-pty.removed">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
        }>;
    }> & {
        type: "persistent-pty.removed";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly ptyID: Schema.brand<Schema.String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"persistent-pty.updated">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly terminal: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "PtyID"> & {
                    create: () => string & import("effect/Brand").Brand<"PtyID">;
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
                };
                readonly title: Schema.String;
                readonly command: Schema.String;
                readonly args: Schema.$Array<Schema.String>;
                readonly cwd: Schema.String;
                readonly status: Schema.Literals<readonly ["running", "exited"]>;
                readonly pid: Schema.Int;
                readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly userTitle: Schema.NullOr<Schema.String>;
                readonly foregroundProcess: Schema.NullOr<Schema.String>;
                readonly size: Schema.Struct<{
                    readonly cols: Schema.Int;
                    readonly rows: Schema.Int;
                }>;
                readonly output: Schema.Struct<{
                    readonly head: Schema.Int;
                    readonly tail: Schema.Int;
                }>;
            }>;
        }>;
    }> & {
        type: "persistent-pty.updated";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly terminal: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "PtyID"> & {
                    create: () => string & import("effect/Brand").Brand<"PtyID">;
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
                };
                readonly title: Schema.String;
                readonly command: Schema.String;
                readonly args: Schema.$Array<Schema.String>;
                readonly cwd: Schema.String;
                readonly status: Schema.Literals<readonly ["running", "exited"]>;
                readonly pid: Schema.Int;
                readonly exitCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly userTitle: Schema.NullOr<Schema.String>;
                readonly foregroundProcess: Schema.NullOr<Schema.String>;
                readonly size: Schema.Struct<{
                    readonly cols: Schema.Int;
                    readonly rows: Schema.Int;
                }>;
                readonly output: Schema.Struct<{
                    readonly head: Schema.Int;
                    readonly tail: Schema.Int;
                }>;
            }>;
        }>;
    }];
};
