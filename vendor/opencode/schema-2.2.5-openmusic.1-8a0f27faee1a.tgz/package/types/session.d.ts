export * as Session from "./session.js";
import { Effect, Schema } from "effect";
import { SessionEvent } from "./session-event.js";
import { SessionID } from "./session-id.js";
import { SessionMetadata } from "./session-metadata.js";
import { Revert } from "./session-revert.js";
import { SessionFork } from "./session-fork.js";
export declare const ID: Schema.brand<Schema.String, "SessionID"> & {
    create: () => string & import("effect/Brand").Brand<"SessionID">;
};
export type ID = SessionID;
export declare const Metadata: Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>;
export type Metadata = SessionMetadata;
export declare const Event: typeof SessionEvent;
export { Revert };
export declare const ForkBoundary: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"before">;
    readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
}>, Schema.Struct<{
    readonly type: Schema.Literal<"through">;
    readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
}>]>;
export type ForkBoundary = SessionFork.Boundary;
export interface Info extends Schema.Schema.Type<typeof Info> {
}
export declare const Info: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
    readonly fork: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly boundary: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"before">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"through">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>]>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly boundary: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"before">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"through">;
            readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>]>;
    }>>, never, never>;
    readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    };
    readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Agent.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Agent.ID">>, never, never>;
    readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>>, Schema.optionalKey<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    }>, never, never>;
    readonly cost: Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    };
    readonly tokens: Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>;
    /** Outcome of the last completed execution, recorded at `time.idle`. Absent until a run reaches a terminal transition. */
    readonly outcome: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>>, Schema.optionalKey<Schema.Literals<readonly ["succeeded", "failed", "interrupted"]>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        readonly updated: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
        /** Start of the most recent execution. While it runs, `idle` still holds the previous execution's end. Resuming after a restart starts a new execution. */
        readonly busy: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        /** End of the most recent completed execution. */
        readonly idle: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly viewed: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
        readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>>, Schema.optionalKey<Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>>, never, never>;
    }>;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>;
    readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Codec<Schema.Json, Schema.Json, never, never>>>, never, never>;
    /** Evaluated after the agent's rules; the last matching rule wins. */
    readonly permissions: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly action: Schema.String;
        readonly resource: Schema.String;
        readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly action: Schema.String;
        readonly resource: Schema.String;
        readonly effect: Schema.Literals<readonly ["allow", "deny", "ask"]>;
    }>>>, never, never>;
    readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly file: Schema.String;
            readonly patch: Schema.String;
            readonly additions: Schema.Int;
            readonly deletions: Schema.Int;
            readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
            readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly file: Schema.String;
            readonly patch: Schema.String;
            readonly additions: Schema.Int;
            readonly deletions: Schema.Int;
            readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
            readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
        }>>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly messageID: Schema.brand<Schema.String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Snapshot.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Snapshot.ID">>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly file: Schema.String;
            readonly patch: Schema.String;
            readonly additions: Schema.Int;
            readonly deletions: Schema.Int;
            readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
            readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly file: Schema.String;
            readonly patch: Schema.String;
            readonly additions: Schema.Int;
            readonly deletions: Schema.Int;
            readonly status: Schema.Literals<readonly ["added", "deleted", "modified"]>;
            readonly more: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literal<true>>>, Schema.optionalKey<Schema.Literal<true>>, never, never>;
        }>>>, never, never>;
    }>>, never, never>;
}>;
export declare const ListAnchor: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Finite;
    readonly direction: Schema.Literals<readonly ["previous", "next"]>;
}>;
export interface ListAnchor extends Schema.Schema.Type<typeof ListAnchor> {
}
export declare const ListFilter: Schema.Struct<{
    readonly order: Schema.optional<Schema.Literals<readonly ["asc", "desc"]>>;
    readonly search: Schema.optional<Schema.String>;
    readonly parentID: Schema.optional<Schema.Union<readonly [Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }, Schema.decodeTo<Schema.Null, Schema.Literal<"null">, never, never>]>>;
    readonly archived: Schema.optional<Schema.decodeTo<Schema.Boolean, Schema.Literals<readonly ["true", "false"]>, never, never>>;
    readonly directory: Schema.optional<Schema.brand<Schema.String, "AbsolutePath">>;
    readonly project: Schema.optional<Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    }>;
    readonly subpath: Schema.optional<Schema.brand<Schema.String, "RelativePath">>;
}>;
export interface ListFilter extends Schema.Schema.Type<typeof ListFilter> {
}
declare const ListCursorInput: Schema.Union<readonly [Schema.Struct<{
    readonly order: Schema.optional<Schema.Literals<readonly ["asc", "desc"]>>;
    readonly search: Schema.optional<Schema.String>;
    readonly parentID: Schema.optional<Schema.Union<readonly [Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }, Schema.decodeTo<Schema.Null, Schema.Literal<"null">, never, never>]>>;
    readonly archived: Schema.optional<Schema.decodeTo<Schema.Boolean, Schema.Literals<readonly ["true", "false"]>, never, never>>;
    readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
    readonly anchor: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Finite;
        readonly direction: Schema.Literals<readonly ["previous", "next"]>;
    }>;
}>, Schema.Struct<{
    readonly order: Schema.optional<Schema.Literals<readonly ["asc", "desc"]>>;
    readonly search: Schema.optional<Schema.String>;
    readonly parentID: Schema.optional<Schema.Union<readonly [Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }, Schema.decodeTo<Schema.Null, Schema.Literal<"null">, never, never>]>>;
    readonly archived: Schema.optional<Schema.decodeTo<Schema.Boolean, Schema.Literals<readonly ["true", "false"]>, never, never>>;
    readonly project: Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    };
    readonly subpath: Schema.optional<Schema.brand<Schema.String, "RelativePath">>;
    readonly anchor: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Finite;
        readonly direction: Schema.Literals<readonly ["previous", "next"]>;
    }>;
}>, Schema.Struct<{
    readonly order: Schema.optional<Schema.Literals<readonly ["asc", "desc"]>>;
    readonly search: Schema.optional<Schema.String>;
    readonly parentID: Schema.optional<Schema.Union<readonly [Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }, Schema.decodeTo<Schema.Null, Schema.Literal<"null">, never, never>]>>;
    readonly archived: Schema.optional<Schema.decodeTo<Schema.Boolean, Schema.Literals<readonly ["true", "false"]>, never, never>>;
    readonly anchor: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly time: Schema.Finite;
        readonly direction: Schema.Literals<readonly ["previous", "next"]>;
    }>;
}>]>;
export declare const ListCursor: Schema.brand<Schema.String, "SessionsCursor"> & {
    make: (input: typeof ListCursorInput.Type) => string & import("effect/Brand").Brand<"SessionsCursor">;
    parse: (input: string) => Effect.Effect<{
        readonly order?: "asc" | "desc" | undefined;
        readonly search?: string | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
        readonly archived?: boolean | undefined;
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly anchor: {
            readonly id: string & import("effect/Brand").Brand<"SessionID">;
            readonly time: number;
            readonly direction: "next" | "previous";
        };
    } | {
        readonly order?: "asc" | "desc" | undefined;
        readonly search?: string | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
        readonly archived?: boolean | undefined;
        readonly project: string & import("effect/Brand").Brand<"Project.ID">;
        readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
        readonly anchor: {
            readonly id: string & import("effect/Brand").Brand<"SessionID">;
            readonly time: number;
            readonly direction: "next" | "previous";
        };
    } | {
        readonly order?: "asc" | "desc" | undefined;
        readonly search?: string | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | null | undefined;
        readonly archived?: boolean | undefined;
        readonly anchor: {
            readonly id: string & import("effect/Brand").Brand<"SessionID">;
            readonly time: number;
            readonly direction: "next" | "previous";
        };
    }, "Invalid cursor", never>;
};
export type ListCursor = typeof ListCursor.Type;
