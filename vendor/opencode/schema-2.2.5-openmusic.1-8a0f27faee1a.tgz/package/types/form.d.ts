export * as Form from "./form.js";
import { Schema } from "effect";
export declare const ID: Schema.brand<Schema.String, "Form.ID"> & {
    create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
};
export type ID = typeof ID.Type;
export declare const Metadata: Schema.$Record<Schema.String, Schema.Unknown>;
export type Metadata = typeof Metadata.Type;
export declare const Option: Schema.Struct<{
    readonly value: Schema.String;
    readonly label: Schema.String;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>;
export interface Option extends Schema.Schema.Type<typeof Option> {
}
export declare const When: Schema.Struct<{
    readonly key: Schema.String;
    readonly op: Schema.Literals<readonly ["eq", "neq"]>;
    readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
}>;
export interface When extends Schema.Schema.Type<typeof When> {
}
export declare const StringField: Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"string">;
    readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
    readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly value: Schema.String;
        readonly label: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly value: Schema.String;
        readonly label: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>, never, never>;
    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>;
export interface StringField extends Schema.Schema.Type<typeof StringField> {
}
export declare const NumberField: Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"number">;
    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
}>;
export interface NumberField extends Schema.Schema.Type<typeof NumberField> {
}
export declare const IntegerField: Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"integer">;
    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
}>;
export interface IntegerField extends Schema.Schema.Type<typeof IntegerField> {
}
export declare const BooleanField: Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"boolean">;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>;
export interface BooleanField extends Schema.Schema.Type<typeof BooleanField> {
}
export declare const MultiselectField: Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"multiselect">;
    readonly options: Schema.$Array<Schema.Struct<{
        readonly value: Schema.String;
        readonly label: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>;
    readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
}>;
export interface MultiselectField extends Schema.Schema.Type<typeof MultiselectField> {
}
export declare const ExternalField: Schema.Struct<{
    readonly key: Schema.String;
    readonly type: Schema.Literal<"external">;
    readonly url: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>;
export interface ExternalField extends Schema.Schema.Type<typeof ExternalField> {
}
export declare const Field: Schema.Union<readonly [Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"string">;
    readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
    readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly value: Schema.String;
        readonly label: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly value: Schema.String;
        readonly label: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>, never, never>;
    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>, Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"number">;
    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
}>, Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"integer">;
    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
}>, Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"boolean">;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>, Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"multiselect">;
    readonly options: Schema.$Array<Schema.Struct<{
        readonly value: Schema.String;
        readonly label: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>;
    readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
}>, Schema.Struct<{
    readonly key: Schema.String;
    readonly type: Schema.Literal<"external">;
    readonly url: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>]>;
export type Field = StringField | NumberField | IntegerField | BooleanField | MultiselectField | ExternalField;
export declare const Fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"string">;
    readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
    readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly value: Schema.String;
        readonly label: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly value: Schema.String;
        readonly label: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>, never, never>;
    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>, Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"number">;
    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
}>, Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"integer">;
    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
}>, Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"boolean">;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}>, Schema.Struct<{
    readonly key: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
    }>>>, never, never>;
    readonly type: Schema.Literal<"multiselect">;
    readonly options: Schema.$Array<Schema.Struct<{
        readonly value: Schema.String;
        readonly label: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>;
    readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
}>, Schema.Struct<{
    readonly key: Schema.String;
    readonly type: Schema.Literal<"external">;
    readonly url: Schema.String;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>]>>;
export type Fields = typeof Fields.Type;
export declare const Info: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Form.ID"> & {
        create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
    };
    readonly sessionID: Schema.String;
    readonly title: Schema.String;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>;
}>;
export interface Info extends Schema.Schema.Type<typeof Info> {
}
export declare const Value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>;
export type Value = typeof Value.Type;
export declare const Answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
export type Answer = typeof Answer.Type;
export declare const State: Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"pending">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"answered">;
    readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"cancelled">;
    readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>]>;
export type State = typeof State.Type;
export declare const Detail: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Form.ID"> & {
        create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
    };
    readonly sessionID: Schema.String;
    readonly title: Schema.String;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"string">;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
        readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"number">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"integer">;
        readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"boolean">;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly key: Schema.String;
            readonly op: Schema.Literals<readonly ["eq", "neq"]>;
            readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
        }>>>, never, never>;
        readonly type: Schema.Literal<"multiselect">;
        readonly options: Schema.$Array<Schema.Struct<{
            readonly value: Schema.String;
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
        readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
    }>, Schema.Struct<{
        readonly key: Schema.String;
        readonly type: Schema.Literal<"external">;
        readonly url: Schema.String;
        readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>;
    readonly state: Schema.Union<readonly [Schema.Struct<{
        readonly status: Schema.Literal<"pending">;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"answered">;
        readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"cancelled">;
        readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>;
}>;
export interface Detail extends Schema.Schema.Type<typeof Detail> {
}
export declare const Reply: Schema.Struct<{
    readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
}>;
export interface Reply extends Schema.Schema.Type<typeof Reply> {
}
export declare const Event: {
    Created: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"form.created">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly form: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                    create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
                };
                readonly sessionID: Schema.String;
                readonly title: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
                readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"string">;
                    readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                    readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>>, never, never>;
                    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"number">;
                    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"integer">;
                    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"boolean">;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"multiselect">;
                    readonly options: Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>;
                    readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly type: Schema.Literal<"external">;
                    readonly url: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>;
            }>;
        }>;
    }> & {
        type: "form.created";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly form: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                    create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
                };
                readonly sessionID: Schema.String;
                readonly title: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
                readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"string">;
                    readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                    readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>>, never, never>;
                    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"number">;
                    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"integer">;
                    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"boolean">;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"multiselect">;
                    readonly options: Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>;
                    readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly type: Schema.Literal<"external">;
                    readonly url: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>;
            }>;
        }>;
    };
    Replied: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"form.replied">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
            readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
        }>;
    }> & {
        type: "form.replied";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
            readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
        }>;
    };
    Cancelled: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"form.cancelled">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
        }>;
    }> & {
        type: "form.cancelled";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
        }>;
    };
    Definitions: readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"form.created">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly form: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                    create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
                };
                readonly sessionID: Schema.String;
                readonly title: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
                readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"string">;
                    readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                    readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>>, never, never>;
                    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"number">;
                    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"integer">;
                    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"boolean">;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"multiselect">;
                    readonly options: Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>;
                    readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly type: Schema.Literal<"external">;
                    readonly url: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>;
            }>;
        }>;
    }> & {
        type: "form.created";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly form: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                    create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
                };
                readonly sessionID: Schema.String;
                readonly title: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
                readonly fields: Schema.NonEmptyArray<Schema.Union<readonly [Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"string">;
                    readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>>, Schema.optionalKey<Schema.Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                    readonly minLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly maxLength: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly pattern: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly placeholder: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly options: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>>, never, never>;
                    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"number">;
                    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"integer">;
                    readonly minimum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly maximum: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"boolean">;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly required: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly hidden: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly when: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly key: Schema.String;
                        readonly op: Schema.Literals<readonly ["eq", "neq"]>;
                        readonly value: Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean]>;
                    }>>>, never, never>;
                    readonly type: Schema.Literal<"multiselect">;
                    readonly options: Schema.$Array<Schema.Struct<{
                        readonly value: Schema.String;
                        readonly label: Schema.String;
                        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    }>>;
                    readonly minItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly maxItems: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly custom: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly default: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.String>>>, Schema.optionalKey<Schema.$Array<Schema.String>>, never, never>;
                }>, Schema.Struct<{
                    readonly key: Schema.String;
                    readonly type: Schema.Literal<"external">;
                    readonly url: Schema.String;
                    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>]>>;
            }>;
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"form.replied">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
            readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
        }>;
    }> & {
        type: "form.replied";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
            readonly answer: Schema.$Record<Schema.String, Schema.Union<readonly [Schema.String, Schema.Number, Schema.Boolean, Schema.$Array<Schema.String>]>>;
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"form.cancelled">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
        }>;
    }> & {
        type: "form.cancelled";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: Schema.String;
        }>;
    }];
};
