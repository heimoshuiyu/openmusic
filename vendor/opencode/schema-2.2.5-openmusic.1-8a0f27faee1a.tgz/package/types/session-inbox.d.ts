export * as SessionInbox from "./session-inbox.js";
import { Schema } from "effect";
export declare const Delivery: Schema.Literals<readonly ["steer", "queue"]>;
export type Delivery = typeof Delivery.Type;
export interface UserPayload extends Schema.Schema.Type<typeof UserPayload> {
}
export declare const UserPayload: Schema.Struct<{
    readonly text: Schema.String;
    readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }>>, never, never>;
    readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>;
/** A {@link UserPayload} whose files may stay on the server, for clients that opt into `experimental-media-uri`. */
export interface MediaUserPayload extends Schema.Schema.Type<typeof MediaUserPayload> {
}
export declare const MediaUserPayload: Schema.Struct<{
    readonly text: Schema.String;
    readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Skill.ID">;
        readonly name: Schema.brand<Schema.String, "Skill.Name">;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }>>>, never, never>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }, Schema.Struct<{
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
        readonly uri: Schema.String;
        readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>]>>>>, Schema.optionalKey<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
    }> & {
        create: (input: import("./prompt.js").FileAttachment) => {
            readonly data: string;
            readonly mime: string;
            readonly source: {
                readonly type: "inline";
            } | {
                readonly type: "uri";
                readonly uri: string;
            };
            readonly name?: string | undefined;
            readonly description?: string | undefined;
            readonly mention?: {
                readonly start: number;
                readonly end: number;
                readonly text: string;
            } | undefined;
        };
    }, Schema.Struct<{
        readonly mime: Schema.String;
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"inline">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"uri">;
            readonly uri: Schema.String;
        }>]>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
            readonly text: Schema.String;
        }>>, never, never>;
        readonly uri: Schema.String;
        readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>]>>>, never, never>;
}>;
export interface SyntheticPayload extends Schema.Schema.Type<typeof SyntheticPayload> {
}
export declare const SyntheticPayload: Schema.Struct<{
    readonly text: Schema.String;
    readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>;
export interface CompactionPayload extends Schema.Schema.Type<typeof CompactionPayload> {
}
export declare const CompactionPayload: Schema.Struct<{}>;
export interface MovePayload extends Schema.Schema.Type<typeof MovePayload> {
}
export declare const MovePayload: Schema.Struct<{
    readonly location: Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>;
    readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    };
    readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
}>;
export declare const Item: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.tag<"user">;
    readonly payload: Schema.Struct<{
        readonly text: Schema.String;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>, never, never>;
        readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"synthetic">;
    readonly payload: Schema.Struct<{
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"compaction">;
    readonly payload: Schema.Struct<{}>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"move">;
    readonly payload: Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    }>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
}>]>;
export type Item = typeof Item.Type;
export interface User extends Schema.Schema.Type<typeof User> {
}
export declare const User: Schema.Struct<{
    readonly type: Schema.tag<"user">;
    readonly payload: Schema.Struct<{
        readonly text: Schema.String;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>, never, never>;
        readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>;
/** A {@link User} whose files may stay on the server, for clients that opt into `experimental-media-uri`. */
export interface MediaUser extends Schema.Schema.Type<typeof MediaUser> {
}
export declare const MediaUser: Schema.Struct<{
    readonly type: Schema.tag<"user">;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly payload: Schema.Struct<{
        readonly text: Schema.String;
        readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }, Schema.Struct<{
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
            readonly uri: Schema.String;
            readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>]>>>>, Schema.optionalKey<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }, Schema.Struct<{
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
            readonly uri: Schema.String;
            readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>]>>>, never, never>;
    }>;
}>;
export interface Synthetic extends Schema.Schema.Type<typeof Synthetic> {
}
export declare const Synthetic: Schema.Struct<{
    readonly type: Schema.tag<"synthetic">;
    readonly payload: Schema.Struct<{
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>;
export interface Compaction extends Schema.Schema.Type<typeof Compaction> {
}
export declare const Compaction: Schema.Struct<{
    readonly type: Schema.tag<"compaction">;
    readonly payload: Schema.Struct<{}>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>;
export interface Move extends Schema.Schema.Type<typeof Move> {
}
export declare const Move: Schema.Struct<{
    readonly type: Schema.tag<"move">;
    readonly payload: Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    }>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>;
export declare const Info: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.tag<"user">;
    readonly payload: Schema.Struct<{
        readonly text: Schema.String;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }>>, never, never>;
        readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"synthetic">;
    readonly payload: Schema.Struct<{
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"compaction">;
    readonly payload: Schema.Struct<{}>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"move">;
    readonly payload: Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    }>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>]>;
export type Info = typeof Info.Type;
/** {@link Info} with {@link MediaUser} for clients that opt into `experimental-media-uri`. */
export declare const MediaInfo: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.tag<"user">;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
    readonly payload: Schema.Struct<{
        readonly text: Schema.String;
        readonly agents: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly skills: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Skill.ID">;
            readonly name: Schema.brand<Schema.String, "Skill.Name">;
            readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }>>>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly files: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }, Schema.Struct<{
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
            readonly uri: Schema.String;
            readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>]>>>>, Schema.optionalKey<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly data: Schema.String;
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
        }> & {
            create: (input: import("./prompt.js").FileAttachment) => {
                readonly data: string;
                readonly mime: string;
                readonly source: {
                    readonly type: "inline";
                } | {
                    readonly type: "uri";
                    readonly uri: string;
                };
                readonly name?: string | undefined;
                readonly description?: string | undefined;
                readonly mention?: {
                    readonly start: number;
                    readonly end: number;
                    readonly text: string;
                } | undefined;
            };
        }, Schema.Struct<{
            readonly mime: Schema.String;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"inline">;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"uri">;
                readonly uri: Schema.String;
            }>]>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly mention: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
                readonly text: Schema.String;
            }>>, never, never>;
            readonly uri: Schema.String;
            readonly bytes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly width: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly height: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        }>]>>>, never, never>;
    }>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"synthetic">;
    readonly payload: Schema.Struct<{
        readonly text: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    }>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"compaction">;
    readonly payload: Schema.Struct<{}>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"move">;
    readonly payload: Schema.Struct<{
        readonly location: Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "RelativePath">>>, Schema.optionalKey<Schema.brand<Schema.String, "RelativePath">>, never, never>;
    }>;
    readonly delivery: Schema.Literals<readonly ["steer", "queue"]>;
    readonly id: Schema.brand<Schema.String, "Session.Message.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
        fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly time: Schema.Struct<{
        readonly created: Schema.decodeTo<Schema.DateTimeUtc, Schema.Finite, never, never>;
    }>;
}>]>;
export type MediaInfo = typeof MediaInfo.Type;
