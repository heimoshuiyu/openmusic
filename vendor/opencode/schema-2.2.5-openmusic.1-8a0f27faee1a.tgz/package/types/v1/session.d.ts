export * as SessionV1 from "./session.js";
import { Schema, Types } from "effect";
export declare const MessageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
};
export type MessageID = typeof MessageID.Type;
export declare const PartID: Schema.brand<Schema.String, "SessionV1.PartID"> & {
    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
};
export type PartID = typeof PartID.Type;
export declare const OutputLengthError: {
    Schema: Schema.Struct<{
        readonly name: Schema.Literal<"MessageOutputLengthError">;
        readonly data: Schema.Struct<{}>;
    }>;
    EffectSchema: Schema.Struct<{
        readonly name: Schema.Literal<"MessageOutputLengthError">;
        readonly data: Schema.Struct<{}>;
    }>;
};
export declare const AuthError: {
    Schema: Schema.Struct<{
        readonly name: Schema.Literal<"ProviderAuthError">;
        readonly data: Schema.Struct<{
            providerID: Schema.String;
            message: Schema.String;
        }>;
    }>;
    EffectSchema: Schema.Struct<{
        readonly name: Schema.Literal<"ProviderAuthError">;
        readonly data: Schema.Struct<{
            providerID: Schema.String;
            message: Schema.String;
        }>;
    }>;
};
export declare const AbortedError: {
    Schema: Schema.Struct<{
        readonly name: Schema.Literal<"MessageAbortedError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
        }>;
    }>;
    EffectSchema: Schema.Struct<{
        readonly name: Schema.Literal<"MessageAbortedError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
        }>;
    }>;
};
export declare const StructuredOutputError: {
    Schema: Schema.Struct<{
        readonly name: Schema.Literal<"StructuredOutputError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            retries: Schema.Int;
        }>;
    }>;
    EffectSchema: Schema.Struct<{
        readonly name: Schema.Literal<"StructuredOutputError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            retries: Schema.Int;
        }>;
    }>;
};
export declare const APIError: {
    Schema: Schema.Struct<{
        readonly name: Schema.Literal<"APIError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            statusCode: Schema.optional<Schema.Int>;
            isRetryable: Schema.Boolean;
            responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
            responseBody: Schema.optional<Schema.String>;
            metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
        }>;
    }>;
    EffectSchema: Schema.Struct<{
        readonly name: Schema.Literal<"APIError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            statusCode: Schema.optional<Schema.Int>;
            isRetryable: Schema.Boolean;
            responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
            responseBody: Schema.optional<Schema.String>;
            metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
        }>;
    }>;
};
export type APIError = Schema.Schema.Type<typeof APIError.Schema>;
export declare const ContextOverflowError: {
    Schema: Schema.Struct<{
        readonly name: Schema.Literal<"ContextOverflowError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            responseBody: Schema.optional<Schema.String>;
        }>;
    }>;
    EffectSchema: Schema.Struct<{
        readonly name: Schema.Literal<"ContextOverflowError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            responseBody: Schema.optional<Schema.String>;
        }>;
    }>;
};
export declare const ContentFilterError: {
    Schema: Schema.Struct<{
        readonly name: Schema.Literal<"ContentFilterError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
        }>;
    }>;
    EffectSchema: Schema.Struct<{
        readonly name: Schema.Literal<"ContentFilterError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
        }>;
    }>;
};
declare const OutputFormatText_base: Schema.Class<OutputFormatText, Schema.Struct<{
    readonly type: Schema.Literal<"text">;
}>, {}>;
export declare class OutputFormatText extends OutputFormatText_base {
}
declare const OutputFormatJsonSchema_base: Schema.Class<OutputFormatJsonSchema, Schema.Struct<{
    readonly type: Schema.Literal<"json_schema">;
    readonly schema: Schema.$Record<Schema.String, Schema.Any>;
    readonly retryCount: Schema.withDecodingDefault<Schema.optional<Schema.Int>, never>;
}>, {}>;
export declare class OutputFormatJsonSchema extends OutputFormatJsonSchema_base {
}
export declare const Format: Schema.Union<readonly [typeof OutputFormatText, typeof OutputFormatJsonSchema]>;
export type OutputFormat = Schema.Schema.Type<typeof Format>;
export declare const SnapshotPart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"snapshot">;
    readonly snapshot: Schema.String;
}>;
export type SnapshotPart = Types.DeepMutable<Schema.Schema.Type<typeof SnapshotPart>>;
export declare const PatchPart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"patch">;
    readonly hash: Schema.String;
    readonly files: Schema.$Array<Schema.String>;
}>;
export type PatchPart = Types.DeepMutable<Schema.Schema.Type<typeof PatchPart>>;
export declare const TextPart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"text">;
    readonly text: Schema.String;
    readonly synthetic: Schema.optional<Schema.Boolean>;
    readonly ignored: Schema.optional<Schema.Boolean>;
    readonly time: Schema.optional<Schema.Struct<{
        readonly start: Schema.Int;
        readonly end: Schema.optional<Schema.Int>;
    }>>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
}>;
export type TextPart = Types.DeepMutable<Schema.Schema.Type<typeof TextPart>>;
export declare const ReasoningPart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"reasoning">;
    readonly text: Schema.String;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
    readonly time: Schema.Struct<{
        readonly start: Schema.Int;
        readonly end: Schema.optional<Schema.Int>;
    }>;
}>;
export type ReasoningPart = Types.DeepMutable<Schema.Schema.Type<typeof ReasoningPart>>;
export declare const Range: Schema.Struct<{
    readonly start: Schema.Struct<{
        readonly line: Schema.Int;
        readonly character: Schema.Int;
    }>;
    readonly end: Schema.Struct<{
        readonly line: Schema.Int;
        readonly character: Schema.Int;
    }>;
}>;
export type Range = typeof Range.Type;
export declare const FileSource: Schema.Struct<{
    readonly text: Schema.Struct<{
        readonly value: Schema.String;
        readonly start: Schema.Finite;
        readonly end: Schema.Finite;
    }>;
    readonly type: Schema.Literal<"file">;
    readonly path: Schema.String;
}>;
export declare const SymbolSource: Schema.Struct<{
    readonly text: Schema.Struct<{
        readonly value: Schema.String;
        readonly start: Schema.Finite;
        readonly end: Schema.Finite;
    }>;
    readonly type: Schema.Literal<"symbol">;
    readonly path: Schema.String;
    readonly range: Schema.Struct<{
        readonly start: Schema.Struct<{
            readonly line: Schema.Int;
            readonly character: Schema.Int;
        }>;
        readonly end: Schema.Struct<{
            readonly line: Schema.Int;
            readonly character: Schema.Int;
        }>;
    }>;
    readonly name: Schema.String;
    readonly kind: Schema.Int;
}>;
export declare const ResourceSource: Schema.Struct<{
    readonly text: Schema.Struct<{
        readonly value: Schema.String;
        readonly start: Schema.Finite;
        readonly end: Schema.Finite;
    }>;
    readonly type: Schema.Literal<"resource">;
    readonly clientName: Schema.String;
    readonly uri: Schema.String;
}>;
export declare const FilePartSource: Schema.Union<readonly [Schema.Struct<{
    readonly text: Schema.Struct<{
        readonly value: Schema.String;
        readonly start: Schema.Finite;
        readonly end: Schema.Finite;
    }>;
    readonly type: Schema.Literal<"file">;
    readonly path: Schema.String;
}>, Schema.Struct<{
    readonly text: Schema.Struct<{
        readonly value: Schema.String;
        readonly start: Schema.Finite;
        readonly end: Schema.Finite;
    }>;
    readonly type: Schema.Literal<"symbol">;
    readonly path: Schema.String;
    readonly range: Schema.Struct<{
        readonly start: Schema.Struct<{
            readonly line: Schema.Int;
            readonly character: Schema.Int;
        }>;
        readonly end: Schema.Struct<{
            readonly line: Schema.Int;
            readonly character: Schema.Int;
        }>;
    }>;
    readonly name: Schema.String;
    readonly kind: Schema.Int;
}>, Schema.Struct<{
    readonly text: Schema.Struct<{
        readonly value: Schema.String;
        readonly start: Schema.Finite;
        readonly end: Schema.Finite;
    }>;
    readonly type: Schema.Literal<"resource">;
    readonly clientName: Schema.String;
    readonly uri: Schema.String;
}>]>;
export declare const FilePart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"file">;
    readonly mime: Schema.String;
    readonly filename: Schema.optional<Schema.String>;
    readonly url: Schema.String;
    readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly text: Schema.Struct<{
            readonly value: Schema.String;
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
        }>;
        readonly type: Schema.Literal<"file">;
        readonly path: Schema.String;
    }>, Schema.Struct<{
        readonly text: Schema.Struct<{
            readonly value: Schema.String;
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
        }>;
        readonly type: Schema.Literal<"symbol">;
        readonly path: Schema.String;
        readonly range: Schema.Struct<{
            readonly start: Schema.Struct<{
                readonly line: Schema.Int;
                readonly character: Schema.Int;
            }>;
            readonly end: Schema.Struct<{
                readonly line: Schema.Int;
                readonly character: Schema.Int;
            }>;
        }>;
        readonly name: Schema.String;
        readonly kind: Schema.Int;
    }>, Schema.Struct<{
        readonly text: Schema.Struct<{
            readonly value: Schema.String;
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
        }>;
        readonly type: Schema.Literal<"resource">;
        readonly clientName: Schema.String;
        readonly uri: Schema.String;
    }>]>>;
}>;
export type FilePart = Types.DeepMutable<Schema.Schema.Type<typeof FilePart>>;
export declare const AgentPart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"agent">;
    readonly name: Schema.String;
    readonly source: Schema.optional<Schema.Struct<{
        readonly value: Schema.String;
        readonly start: Schema.Int;
        readonly end: Schema.Int;
    }>>;
}>;
export type AgentPart = Types.DeepMutable<Schema.Schema.Type<typeof AgentPart>>;
export declare const CompactionPart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"compaction">;
    readonly auto: Schema.Boolean;
    readonly overflow: Schema.optional<Schema.Boolean>;
    readonly tail_start_id: Schema.optional<Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    }>;
}>;
export type CompactionPart = Types.DeepMutable<Schema.Schema.Type<typeof CompactionPart>>;
export declare const SubtaskPart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"subtask">;
    readonly prompt: Schema.String;
    readonly description: Schema.String;
    readonly agent: Schema.String;
    readonly model: Schema.optional<Schema.Struct<{
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly modelID: Schema.brand<Schema.String, "Model.ID">;
    }>>;
    readonly command: Schema.optional<Schema.String>;
}>;
export type SubtaskPart = Types.DeepMutable<Schema.Schema.Type<typeof SubtaskPart>>;
export declare const RetryPart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"retry">;
    readonly attempt: Schema.Int;
    readonly error: Schema.Struct<{
        readonly name: Schema.Literal<"APIError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            statusCode: Schema.optional<Schema.Int>;
            isRetryable: Schema.Boolean;
            responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
            responseBody: Schema.optional<Schema.String>;
            metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
        }>;
    }>;
    readonly time: Schema.Struct<{
        readonly created: Schema.Int;
    }>;
}>;
export type RetryPart = Omit<Types.DeepMutable<Schema.Schema.Type<typeof RetryPart>>, "error"> & {
    error: APIError;
};
export declare const StepStartPart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"step-start">;
    readonly snapshot: Schema.optional<Schema.String>;
}>;
export type StepStartPart = Types.DeepMutable<Schema.Schema.Type<typeof StepStartPart>>;
export declare const StepFinishPart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"step-finish">;
    readonly reason: Schema.String;
    readonly snapshot: Schema.optional<Schema.String>;
    readonly cost: Schema.Finite;
    readonly tokens: Schema.Struct<{
        readonly total: Schema.optional<Schema.Finite>;
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>;
}>;
export type StepFinishPart = Types.DeepMutable<Schema.Schema.Type<typeof StepFinishPart>>;
export declare const ToolStatePending: Schema.Struct<{
    readonly status: Schema.Literal<"pending">;
    readonly input: Schema.$Record<Schema.String, Schema.Any>;
    readonly raw: Schema.String;
}>;
export type ToolStatePending = Types.DeepMutable<Schema.Schema.Type<typeof ToolStatePending>>;
export declare const ToolStateRunning: Schema.Struct<{
    readonly status: Schema.Literal<"running">;
    readonly input: Schema.$Record<Schema.String, Schema.Any>;
    readonly title: Schema.optional<Schema.String>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
    readonly time: Schema.Struct<{
        readonly start: Schema.Int;
    }>;
}>;
export type ToolStateRunning = Types.DeepMutable<Schema.Schema.Type<typeof ToolStateRunning>>;
export declare const ToolStateCompleted: Schema.Struct<{
    readonly status: Schema.Literal<"completed">;
    readonly input: Schema.$Record<Schema.String, Schema.Any>;
    readonly output: Schema.String;
    readonly title: Schema.String;
    readonly metadata: Schema.$Record<Schema.String, Schema.Any>;
    readonly time: Schema.Struct<{
        readonly start: Schema.Int;
        readonly end: Schema.Int;
        readonly compacted: Schema.optional<Schema.Int>;
    }>;
    readonly attachments: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
        };
        readonly type: Schema.Literal<"file">;
        readonly mime: Schema.String;
        readonly filename: Schema.optional<Schema.String>;
        readonly url: Schema.String;
        readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
            readonly text: Schema.Struct<{
                readonly value: Schema.String;
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
            }>;
            readonly type: Schema.Literal<"file">;
            readonly path: Schema.String;
        }>, Schema.Struct<{
            readonly text: Schema.Struct<{
                readonly value: Schema.String;
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
            }>;
            readonly type: Schema.Literal<"symbol">;
            readonly path: Schema.String;
            readonly range: Schema.Struct<{
                readonly start: Schema.Struct<{
                    readonly line: Schema.Int;
                    readonly character: Schema.Int;
                }>;
                readonly end: Schema.Struct<{
                    readonly line: Schema.Int;
                    readonly character: Schema.Int;
                }>;
            }>;
            readonly name: Schema.String;
            readonly kind: Schema.Int;
        }>, Schema.Struct<{
            readonly text: Schema.Struct<{
                readonly value: Schema.String;
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
            }>;
            readonly type: Schema.Literal<"resource">;
            readonly clientName: Schema.String;
            readonly uri: Schema.String;
        }>]>>;
    }>>>;
}>;
export type ToolStateCompleted = Types.DeepMutable<Schema.Schema.Type<typeof ToolStateCompleted>>;
export declare const ToolStateError: Schema.Struct<{
    readonly status: Schema.Literal<"error">;
    readonly input: Schema.$Record<Schema.String, Schema.Any>;
    readonly error: Schema.String;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
    readonly time: Schema.Struct<{
        readonly start: Schema.Int;
        readonly end: Schema.Int;
    }>;
}>;
export type ToolStateError = Types.DeepMutable<Schema.Schema.Type<typeof ToolStateError>>;
export declare const ToolState: Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"pending">;
    readonly input: Schema.$Record<Schema.String, Schema.Any>;
    readonly raw: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"running">;
    readonly input: Schema.$Record<Schema.String, Schema.Any>;
    readonly title: Schema.optional<Schema.String>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
    readonly time: Schema.Struct<{
        readonly start: Schema.Int;
    }>;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"completed">;
    readonly input: Schema.$Record<Schema.String, Schema.Any>;
    readonly output: Schema.String;
    readonly title: Schema.String;
    readonly metadata: Schema.$Record<Schema.String, Schema.Any>;
    readonly time: Schema.Struct<{
        readonly start: Schema.Int;
        readonly end: Schema.Int;
        readonly compacted: Schema.optional<Schema.Int>;
    }>;
    readonly attachments: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
        };
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
        };
        readonly type: Schema.Literal<"file">;
        readonly mime: Schema.String;
        readonly filename: Schema.optional<Schema.String>;
        readonly url: Schema.String;
        readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
            readonly text: Schema.Struct<{
                readonly value: Schema.String;
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
            }>;
            readonly type: Schema.Literal<"file">;
            readonly path: Schema.String;
        }>, Schema.Struct<{
            readonly text: Schema.Struct<{
                readonly value: Schema.String;
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
            }>;
            readonly type: Schema.Literal<"symbol">;
            readonly path: Schema.String;
            readonly range: Schema.Struct<{
                readonly start: Schema.Struct<{
                    readonly line: Schema.Int;
                    readonly character: Schema.Int;
                }>;
                readonly end: Schema.Struct<{
                    readonly line: Schema.Int;
                    readonly character: Schema.Int;
                }>;
            }>;
            readonly name: Schema.String;
            readonly kind: Schema.Int;
        }>, Schema.Struct<{
            readonly text: Schema.Struct<{
                readonly value: Schema.String;
                readonly start: Schema.Finite;
                readonly end: Schema.Finite;
            }>;
            readonly type: Schema.Literal<"resource">;
            readonly clientName: Schema.String;
            readonly uri: Schema.String;
        }>]>>;
    }>>>;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"error">;
    readonly input: Schema.$Record<Schema.String, Schema.Any>;
    readonly error: Schema.String;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
    readonly time: Schema.Struct<{
        readonly start: Schema.Int;
        readonly end: Schema.Int;
    }>;
}>]>;
export type ToolState = ToolStatePending | ToolStateRunning | ToolStateCompleted | ToolStateError;
export declare const ToolPart: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"tool">;
    readonly callID: Schema.String;
    readonly tool: Schema.String;
    readonly state: Schema.Union<readonly [Schema.Struct<{
        readonly status: Schema.Literal<"pending">;
        readonly input: Schema.$Record<Schema.String, Schema.Any>;
        readonly raw: Schema.String;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"running">;
        readonly input: Schema.$Record<Schema.String, Schema.Any>;
        readonly title: Schema.optional<Schema.String>;
        readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
        readonly time: Schema.Struct<{
            readonly start: Schema.Int;
        }>;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"completed">;
        readonly input: Schema.$Record<Schema.String, Schema.Any>;
        readonly output: Schema.String;
        readonly title: Schema.String;
        readonly metadata: Schema.$Record<Schema.String, Schema.Any>;
        readonly time: Schema.Struct<{
            readonly start: Schema.Int;
            readonly end: Schema.Int;
            readonly compacted: Schema.optional<Schema.Int>;
        }>;
        readonly attachments: Schema.optional<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
            };
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
            readonly type: Schema.Literal<"file">;
            readonly mime: Schema.String;
            readonly filename: Schema.optional<Schema.String>;
            readonly url: Schema.String;
            readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                readonly text: Schema.Struct<{
                    readonly value: Schema.String;
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                }>;
                readonly type: Schema.Literal<"file">;
                readonly path: Schema.String;
            }>, Schema.Struct<{
                readonly text: Schema.Struct<{
                    readonly value: Schema.String;
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                }>;
                readonly type: Schema.Literal<"symbol">;
                readonly path: Schema.String;
                readonly range: Schema.Struct<{
                    readonly start: Schema.Struct<{
                        readonly line: Schema.Int;
                        readonly character: Schema.Int;
                    }>;
                    readonly end: Schema.Struct<{
                        readonly line: Schema.Int;
                        readonly character: Schema.Int;
                    }>;
                }>;
                readonly name: Schema.String;
                readonly kind: Schema.Int;
            }>, Schema.Struct<{
                readonly text: Schema.Struct<{
                    readonly value: Schema.String;
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                }>;
                readonly type: Schema.Literal<"resource">;
                readonly clientName: Schema.String;
                readonly uri: Schema.String;
            }>]>>;
        }>>>;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"error">;
        readonly input: Schema.$Record<Schema.String, Schema.Any>;
        readonly error: Schema.String;
        readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
        readonly time: Schema.Struct<{
            readonly start: Schema.Int;
            readonly end: Schema.Int;
        }>;
    }>]>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
}>;
export type ToolPart = Omit<Types.DeepMutable<Schema.Schema.Type<typeof ToolPart>>, "state"> & {
    state: ToolState;
};
export declare const User: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly role: Schema.Literal<"user">;
    readonly time: Schema.Struct<{
        readonly created: Schema.Finite;
    }>;
    readonly format: Schema.optional<Schema.Union<readonly [typeof OutputFormatText, typeof OutputFormatJsonSchema]>>;
    readonly summary: Schema.optional<Schema.Struct<{
        readonly title: Schema.optional<Schema.String>;
        readonly body: Schema.optional<Schema.String>;
        readonly diffs: Schema.$Array<Schema.Struct<{
            readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly additions: Schema.Finite;
            readonly deletions: Schema.Finite;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
        }>>;
    }>>;
    readonly agent: Schema.String;
    readonly model: Schema.Struct<{
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly modelID: Schema.brand<Schema.String, "Model.ID">;
        readonly variant: Schema.optional<Schema.String>;
    }>;
    readonly system: Schema.optional<Schema.String>;
    readonly tools: Schema.optional<Schema.$Record<Schema.String, Schema.Boolean>>;
}>;
export type User = Types.DeepMutable<Schema.Schema.Type<typeof User>>;
export declare const Part: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"text">;
    readonly text: Schema.String;
    readonly synthetic: Schema.optional<Schema.Boolean>;
    readonly ignored: Schema.optional<Schema.Boolean>;
    readonly time: Schema.optional<Schema.Struct<{
        readonly start: Schema.Int;
        readonly end: Schema.optional<Schema.Int>;
    }>>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"subtask">;
    readonly prompt: Schema.String;
    readonly description: Schema.String;
    readonly agent: Schema.String;
    readonly model: Schema.optional<Schema.Struct<{
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly modelID: Schema.brand<Schema.String, "Model.ID">;
    }>>;
    readonly command: Schema.optional<Schema.String>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"reasoning">;
    readonly text: Schema.String;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
    readonly time: Schema.Struct<{
        readonly start: Schema.Int;
        readonly end: Schema.optional<Schema.Int>;
    }>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"file">;
    readonly mime: Schema.String;
    readonly filename: Schema.optional<Schema.String>;
    readonly url: Schema.String;
    readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly text: Schema.Struct<{
            readonly value: Schema.String;
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
        }>;
        readonly type: Schema.Literal<"file">;
        readonly path: Schema.String;
    }>, Schema.Struct<{
        readonly text: Schema.Struct<{
            readonly value: Schema.String;
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
        }>;
        readonly type: Schema.Literal<"symbol">;
        readonly path: Schema.String;
        readonly range: Schema.Struct<{
            readonly start: Schema.Struct<{
                readonly line: Schema.Int;
                readonly character: Schema.Int;
            }>;
            readonly end: Schema.Struct<{
                readonly line: Schema.Int;
                readonly character: Schema.Int;
            }>;
        }>;
        readonly name: Schema.String;
        readonly kind: Schema.Int;
    }>, Schema.Struct<{
        readonly text: Schema.Struct<{
            readonly value: Schema.String;
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
        }>;
        readonly type: Schema.Literal<"resource">;
        readonly clientName: Schema.String;
        readonly uri: Schema.String;
    }>]>>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"tool">;
    readonly callID: Schema.String;
    readonly tool: Schema.String;
    readonly state: Schema.Union<readonly [Schema.Struct<{
        readonly status: Schema.Literal<"pending">;
        readonly input: Schema.$Record<Schema.String, Schema.Any>;
        readonly raw: Schema.String;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"running">;
        readonly input: Schema.$Record<Schema.String, Schema.Any>;
        readonly title: Schema.optional<Schema.String>;
        readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
        readonly time: Schema.Struct<{
            readonly start: Schema.Int;
        }>;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"completed">;
        readonly input: Schema.$Record<Schema.String, Schema.Any>;
        readonly output: Schema.String;
        readonly title: Schema.String;
        readonly metadata: Schema.$Record<Schema.String, Schema.Any>;
        readonly time: Schema.Struct<{
            readonly start: Schema.Int;
            readonly end: Schema.Int;
            readonly compacted: Schema.optional<Schema.Int>;
        }>;
        readonly attachments: Schema.optional<Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
            };
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
            readonly type: Schema.Literal<"file">;
            readonly mime: Schema.String;
            readonly filename: Schema.optional<Schema.String>;
            readonly url: Schema.String;
            readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                readonly text: Schema.Struct<{
                    readonly value: Schema.String;
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                }>;
                readonly type: Schema.Literal<"file">;
                readonly path: Schema.String;
            }>, Schema.Struct<{
                readonly text: Schema.Struct<{
                    readonly value: Schema.String;
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                }>;
                readonly type: Schema.Literal<"symbol">;
                readonly path: Schema.String;
                readonly range: Schema.Struct<{
                    readonly start: Schema.Struct<{
                        readonly line: Schema.Int;
                        readonly character: Schema.Int;
                    }>;
                    readonly end: Schema.Struct<{
                        readonly line: Schema.Int;
                        readonly character: Schema.Int;
                    }>;
                }>;
                readonly name: Schema.String;
                readonly kind: Schema.Int;
            }>, Schema.Struct<{
                readonly text: Schema.Struct<{
                    readonly value: Schema.String;
                    readonly start: Schema.Finite;
                    readonly end: Schema.Finite;
                }>;
                readonly type: Schema.Literal<"resource">;
                readonly clientName: Schema.String;
                readonly uri: Schema.String;
            }>]>>;
        }>>>;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"error">;
        readonly input: Schema.$Record<Schema.String, Schema.Any>;
        readonly error: Schema.String;
        readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
        readonly time: Schema.Struct<{
            readonly start: Schema.Int;
            readonly end: Schema.Int;
        }>;
    }>]>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"step-start">;
    readonly snapshot: Schema.optional<Schema.String>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"step-finish">;
    readonly reason: Schema.String;
    readonly snapshot: Schema.optional<Schema.String>;
    readonly cost: Schema.Finite;
    readonly tokens: Schema.Struct<{
        readonly total: Schema.optional<Schema.Finite>;
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"snapshot">;
    readonly snapshot: Schema.String;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"patch">;
    readonly hash: Schema.String;
    readonly files: Schema.$Array<Schema.String>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"agent">;
    readonly name: Schema.String;
    readonly source: Schema.optional<Schema.Struct<{
        readonly value: Schema.String;
        readonly start: Schema.Int;
        readonly end: Schema.Int;
    }>>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"retry">;
    readonly attempt: Schema.Int;
    readonly error: Schema.Struct<{
        readonly name: Schema.Literal<"APIError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            statusCode: Schema.optional<Schema.Int>;
            isRetryable: Schema.Boolean;
            responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
            responseBody: Schema.optional<Schema.String>;
            metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
        }>;
    }>;
    readonly time: Schema.Struct<{
        readonly created: Schema.Int;
    }>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly type: Schema.Literal<"compaction">;
    readonly auto: Schema.Boolean;
    readonly overflow: Schema.optional<Schema.Boolean>;
    readonly tail_start_id: Schema.optional<Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    }>;
}>]>;
export type Part = TextPart | SubtaskPart | ReasoningPart | FilePart | ToolPart | StepStartPart | StepFinishPart | SnapshotPart | PatchPart | AgentPart | RetryPart | CompactionPart;
declare const AssistantErrorSchema: Schema.Union<readonly [Schema.Struct<{
    readonly name: Schema.Literal<"ProviderAuthError">;
    readonly data: Schema.Struct<{
        providerID: Schema.String;
        message: Schema.String;
    }>;
}>, Schema.Struct<{
    readonly name: Schema.Literal<"UnknownError">;
    readonly data: Schema.Struct<{
        message: Schema.String;
        ref: Schema.optional<Schema.String>;
    }>;
}>, Schema.Struct<{
    readonly name: Schema.Literal<"MessageOutputLengthError">;
    readonly data: Schema.Struct<{}>;
}>, Schema.Struct<{
    readonly name: Schema.Literal<"MessageAbortedError">;
    readonly data: Schema.Struct<{
        message: Schema.String;
    }>;
}>, Schema.Struct<{
    readonly name: Schema.Literal<"StructuredOutputError">;
    readonly data: Schema.Struct<{
        message: Schema.String;
        retries: Schema.Int;
    }>;
}>, Schema.Struct<{
    readonly name: Schema.Literal<"ContextOverflowError">;
    readonly data: Schema.Struct<{
        message: Schema.String;
        responseBody: Schema.optional<Schema.String>;
    }>;
}>, Schema.Struct<{
    readonly name: Schema.Literal<"ContentFilterError">;
    readonly data: Schema.Struct<{
        message: Schema.String;
    }>;
}>, Schema.Struct<{
    readonly name: Schema.Literal<"APIError">;
    readonly data: Schema.Struct<{
        message: Schema.String;
        statusCode: Schema.optional<Schema.Int>;
        isRetryable: Schema.Boolean;
        responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
        responseBody: Schema.optional<Schema.String>;
        metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
    }>;
}>]>;
type AssistantError = Schema.Schema.Type<typeof AssistantErrorSchema>;
export declare const TextPartInput: Schema.Struct<{
    readonly id: Schema.optional<Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    }>;
    readonly type: Schema.Literal<"text">;
    readonly text: Schema.String;
    readonly synthetic: Schema.optional<Schema.Boolean>;
    readonly ignored: Schema.optional<Schema.Boolean>;
    readonly time: Schema.optional<Schema.Struct<{
        readonly start: Schema.Int;
        readonly end: Schema.optional<Schema.Int>;
    }>>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
}>;
export type TextPartInput = Types.DeepMutable<Schema.Schema.Type<typeof TextPartInput>>;
export declare const FilePartInput: Schema.Struct<{
    readonly id: Schema.optional<Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    }>;
    readonly type: Schema.Literal<"file">;
    readonly mime: Schema.String;
    readonly filename: Schema.optional<Schema.String>;
    readonly url: Schema.String;
    readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly text: Schema.Struct<{
            readonly value: Schema.String;
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
        }>;
        readonly type: Schema.Literal<"file">;
        readonly path: Schema.String;
    }>, Schema.Struct<{
        readonly text: Schema.Struct<{
            readonly value: Schema.String;
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
        }>;
        readonly type: Schema.Literal<"symbol">;
        readonly path: Schema.String;
        readonly range: Schema.Struct<{
            readonly start: Schema.Struct<{
                readonly line: Schema.Int;
                readonly character: Schema.Int;
            }>;
            readonly end: Schema.Struct<{
                readonly line: Schema.Int;
                readonly character: Schema.Int;
            }>;
        }>;
        readonly name: Schema.String;
        readonly kind: Schema.Int;
    }>, Schema.Struct<{
        readonly text: Schema.Struct<{
            readonly value: Schema.String;
            readonly start: Schema.Finite;
            readonly end: Schema.Finite;
        }>;
        readonly type: Schema.Literal<"resource">;
        readonly clientName: Schema.String;
        readonly uri: Schema.String;
    }>]>>;
}>;
export type FilePartInput = Types.DeepMutable<Schema.Schema.Type<typeof FilePartInput>>;
export declare const AgentPartInput: Schema.Struct<{
    readonly id: Schema.optional<Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    }>;
    readonly type: Schema.Literal<"agent">;
    readonly name: Schema.String;
    readonly source: Schema.optional<Schema.Struct<{
        readonly value: Schema.String;
        readonly start: Schema.Int;
        readonly end: Schema.Int;
    }>>;
}>;
export type AgentPartInput = Types.DeepMutable<Schema.Schema.Type<typeof AgentPartInput>>;
export declare const SubtaskPartInput: Schema.Struct<{
    readonly id: Schema.optional<Schema.brand<Schema.String, "SessionV1.PartID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
    }>;
    readonly type: Schema.Literal<"subtask">;
    readonly prompt: Schema.String;
    readonly description: Schema.String;
    readonly agent: Schema.String;
    readonly model: Schema.optional<Schema.Struct<{
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly modelID: Schema.brand<Schema.String, "Model.ID">;
    }>>;
    readonly command: Schema.optional<Schema.String>;
}>;
export type SubtaskPartInput = Types.DeepMutable<Schema.Schema.Type<typeof SubtaskPartInput>>;
export declare const Assistant: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly role: Schema.Literal<"assistant">;
    readonly time: Schema.Struct<{
        readonly created: Schema.Int;
        readonly completed: Schema.optional<Schema.Int>;
    }>;
    readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly name: Schema.Literal<"ProviderAuthError">;
        readonly data: Schema.Struct<{
            providerID: Schema.String;
            message: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"UnknownError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            ref: Schema.optional<Schema.String>;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"MessageOutputLengthError">;
        readonly data: Schema.Struct<{}>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"MessageAbortedError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"StructuredOutputError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            retries: Schema.Int;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"ContextOverflowError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            responseBody: Schema.optional<Schema.String>;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"ContentFilterError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"APIError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            statusCode: Schema.optional<Schema.Int>;
            isRetryable: Schema.Boolean;
            responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
            responseBody: Schema.optional<Schema.String>;
            metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
        }>;
    }>]>>;
    readonly parentID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly modelID: Schema.brand<Schema.String, "Model.ID">;
    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
        openai: string & import("effect/Brand").Brand<"Provider.ID">;
        google: string & import("effect/Brand").Brand<"Provider.ID">;
        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
        azure: string & import("effect/Brand").Brand<"Provider.ID">;
        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
    };
    readonly mode: Schema.String;
    readonly agent: Schema.String;
    readonly path: Schema.Struct<{
        readonly cwd: Schema.String;
        readonly root: Schema.String;
    }>;
    readonly summary: Schema.optional<Schema.Boolean>;
    readonly cost: Schema.Finite;
    readonly tokens: Schema.Struct<{
        readonly total: Schema.optional<Schema.Finite>;
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>;
    readonly structured: Schema.optional<Schema.Any>;
    readonly variant: Schema.optional<Schema.String>;
    readonly finish: Schema.optional<Schema.String>;
}>;
export type Assistant = Omit<Types.DeepMutable<Schema.Schema.Type<typeof Assistant>>, "error"> & {
    error?: AssistantError;
};
export declare const Info: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly role: Schema.Literal<"user">;
    readonly time: Schema.Struct<{
        readonly created: Schema.Finite;
    }>;
    readonly format: Schema.optional<Schema.Union<readonly [typeof OutputFormatText, typeof OutputFormatJsonSchema]>>;
    readonly summary: Schema.optional<Schema.Struct<{
        readonly title: Schema.optional<Schema.String>;
        readonly body: Schema.optional<Schema.String>;
        readonly diffs: Schema.$Array<Schema.Struct<{
            readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly additions: Schema.Finite;
            readonly deletions: Schema.Finite;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
        }>>;
    }>>;
    readonly agent: Schema.String;
    readonly model: Schema.Struct<{
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly modelID: Schema.brand<Schema.String, "Model.ID">;
        readonly variant: Schema.optional<Schema.String>;
    }>;
    readonly system: Schema.optional<Schema.String>;
    readonly tools: Schema.optional<Schema.$Record<Schema.String, Schema.Boolean>>;
}>, Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly role: Schema.Literal<"assistant">;
    readonly time: Schema.Struct<{
        readonly created: Schema.Int;
        readonly completed: Schema.optional<Schema.Int>;
    }>;
    readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly name: Schema.Literal<"ProviderAuthError">;
        readonly data: Schema.Struct<{
            providerID: Schema.String;
            message: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"UnknownError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            ref: Schema.optional<Schema.String>;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"MessageOutputLengthError">;
        readonly data: Schema.Struct<{}>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"MessageAbortedError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"StructuredOutputError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            retries: Schema.Int;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"ContextOverflowError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            responseBody: Schema.optional<Schema.String>;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"ContentFilterError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly name: Schema.Literal<"APIError">;
        readonly data: Schema.Struct<{
            message: Schema.String;
            statusCode: Schema.optional<Schema.Int>;
            isRetryable: Schema.Boolean;
            responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
            responseBody: Schema.optional<Schema.String>;
            metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
        }>;
    }>]>>;
    readonly parentID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
    };
    readonly modelID: Schema.brand<Schema.String, "Model.ID">;
    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
        openai: string & import("effect/Brand").Brand<"Provider.ID">;
        google: string & import("effect/Brand").Brand<"Provider.ID">;
        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
        azure: string & import("effect/Brand").Brand<"Provider.ID">;
        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
    };
    readonly mode: Schema.String;
    readonly agent: Schema.String;
    readonly path: Schema.Struct<{
        readonly cwd: Schema.String;
        readonly root: Schema.String;
    }>;
    readonly summary: Schema.optional<Schema.Boolean>;
    readonly cost: Schema.Finite;
    readonly tokens: Schema.Struct<{
        readonly total: Schema.optional<Schema.Finite>;
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>;
    readonly structured: Schema.optional<Schema.Any>;
    readonly variant: Schema.optional<Schema.String>;
    readonly finish: Schema.optional<Schema.String>;
}>]>;
export type Info = User | Assistant;
export declare const SessionInfo: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly slug: Schema.String;
    readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    };
    readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
    }>, never, never>;
    readonly directory: Schema.String;
    readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    }>, never, never>;
    readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly additions: Schema.Finite;
        readonly deletions: Schema.Finite;
        readonly files: Schema.Finite;
        readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly additions: Schema.Finite;
            readonly deletions: Schema.Finite;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly additions: Schema.Finite;
            readonly deletions: Schema.Finite;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
        }>>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly additions: Schema.Finite;
        readonly deletions: Schema.Finite;
        readonly files: Schema.Finite;
        readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
            readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly additions: Schema.Finite;
            readonly deletions: Schema.Finite;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
        }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly additions: Schema.Finite;
            readonly deletions: Schema.Finite;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
        }>>>, never, never>;
    }>>, never, never>;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.Finite;
        readonly output: Schema.Finite;
        readonly reasoning: Schema.Finite;
        readonly cache: Schema.Struct<{
            readonly read: Schema.Finite;
            readonly write: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly url: Schema.String;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly url: Schema.String;
    }>>, never, never>;
    readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>, never, never>;
    readonly version: Schema.String;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
    readonly time: Schema.Struct<{
        readonly created: Schema.Int;
        readonly updated: Schema.Int;
        readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>;
    readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly permission: Schema.String;
        readonly pattern: Schema.String;
        readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly permission: Schema.String;
        readonly pattern: Schema.String;
        readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
    }>>>, never, never>;
    readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
        };
        readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
        }>, never, never>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
        };
        readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
        }>, never, never>;
        readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>, never, never>;
}>;
export type SessionInfo = typeof SessionInfo.Type;
export declare const PartDelta: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"message.part.delta">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
        };
        readonly partID: Schema.brand<Schema.String, "SessionV1.PartID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
        };
        readonly field: Schema.String;
        readonly delta: Schema.String;
    }>;
}> & {
    type: "message.part.delta";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
        };
        readonly partID: Schema.brand<Schema.String, "SessionV1.PartID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
        };
        readonly field: Schema.String;
        readonly delta: Schema.String;
    }>;
};
export declare const Diff: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.diff">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly diff: Schema.$Array<Schema.Struct<{
            readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly additions: Schema.Finite;
            readonly deletions: Schema.Finite;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
        }>>;
    }>;
}> & {
    type: "session.diff";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly diff: Schema.$Array<Schema.Struct<{
            readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly additions: Schema.Finite;
            readonly deletions: Schema.Finite;
            readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
        }>>;
    }>;
};
export declare const Error: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: Schema.Finite;
    readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
    readonly type: Schema.Literal<"session.error">;
    readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
        readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: Schema.Struct<{
        readonly sessionID: Schema.optional<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>;
        readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
            readonly name: Schema.Literal<"ProviderAuthError">;
            readonly data: Schema.Struct<{
                providerID: Schema.String;
                message: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"UnknownError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
                ref: Schema.optional<Schema.String>;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"MessageOutputLengthError">;
            readonly data: Schema.Struct<{}>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"MessageAbortedError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"StructuredOutputError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
                retries: Schema.Int;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"ContextOverflowError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
                responseBody: Schema.optional<Schema.String>;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"ContentFilterError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"APIError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
                statusCode: Schema.optional<Schema.Int>;
                isRetryable: Schema.Boolean;
                responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                responseBody: Schema.optional<Schema.String>;
                metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
            }>;
        }>]>>;
    }>;
}> & {
    type: "session.error";
    durability: "ephemeral";
    durable: undefined;
    data: Schema.Struct<{
        readonly sessionID: Schema.optional<Schema.brand<Schema.String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>;
        readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
            readonly name: Schema.Literal<"ProviderAuthError">;
            readonly data: Schema.Struct<{
                providerID: Schema.String;
                message: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"UnknownError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
                ref: Schema.optional<Schema.String>;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"MessageOutputLengthError">;
            readonly data: Schema.Struct<{}>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"MessageAbortedError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"StructuredOutputError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
                retries: Schema.Int;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"ContextOverflowError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
                responseBody: Schema.optional<Schema.String>;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"ContentFilterError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly name: Schema.Literal<"APIError">;
            readonly data: Schema.Struct<{
                message: Schema.String;
                statusCode: Schema.optional<Schema.Int>;
                isRetryable: Schema.Boolean;
                responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                responseBody: Schema.optional<Schema.String>;
                metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
            }>;
        }>]>>;
    }>;
};
export declare const Event: {
    Created: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"session.created">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    }> & {
        type: "session.created";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    };
    Updated: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"session.updated">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    }> & {
        type: "session.updated";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    };
    Deleted: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"session.deleted">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    }> & {
        type: "session.deleted";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    };
    MessageUpdated: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"message.updated">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Union<readonly [Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly role: Schema.Literal<"user">;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Finite;
                }>;
                readonly format: Schema.optional<Schema.Union<readonly [typeof OutputFormatText, typeof OutputFormatJsonSchema]>>;
                readonly summary: Schema.optional<Schema.Struct<{
                    readonly title: Schema.optional<Schema.String>;
                    readonly body: Schema.optional<Schema.String>;
                    readonly diffs: Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>;
                }>>;
                readonly agent: Schema.String;
                readonly model: Schema.Struct<{
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                    readonly variant: Schema.optional<Schema.String>;
                }>;
                readonly system: Schema.optional<Schema.String>;
                readonly tools: Schema.optional<Schema.$Record<Schema.String, Schema.Boolean>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly role: Schema.Literal<"assistant">;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly completed: Schema.optional<Schema.Int>;
                }>;
                readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly name: Schema.Literal<"ProviderAuthError">;
                    readonly data: Schema.Struct<{
                        providerID: Schema.String;
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"UnknownError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        ref: Schema.optional<Schema.String>;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"MessageOutputLengthError">;
                    readonly data: Schema.Struct<{}>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"MessageAbortedError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"StructuredOutputError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        retries: Schema.Int;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"ContextOverflowError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        responseBody: Schema.optional<Schema.String>;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"ContentFilterError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"APIError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        statusCode: Schema.optional<Schema.Int>;
                        isRetryable: Schema.Boolean;
                        responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                        responseBody: Schema.optional<Schema.String>;
                        metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    }>;
                }>]>>;
                readonly parentID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly mode: Schema.String;
                readonly agent: Schema.String;
                readonly path: Schema.Struct<{
                    readonly cwd: Schema.String;
                    readonly root: Schema.String;
                }>;
                readonly summary: Schema.optional<Schema.Boolean>;
                readonly cost: Schema.Finite;
                readonly tokens: Schema.Struct<{
                    readonly total: Schema.optional<Schema.Finite>;
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>;
                readonly structured: Schema.optional<Schema.Any>;
                readonly variant: Schema.optional<Schema.String>;
                readonly finish: Schema.optional<Schema.String>;
            }>]>;
        }>;
    }> & {
        type: "message.updated";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Union<readonly [Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly role: Schema.Literal<"user">;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Finite;
                }>;
                readonly format: Schema.optional<Schema.Union<readonly [typeof OutputFormatText, typeof OutputFormatJsonSchema]>>;
                readonly summary: Schema.optional<Schema.Struct<{
                    readonly title: Schema.optional<Schema.String>;
                    readonly body: Schema.optional<Schema.String>;
                    readonly diffs: Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>;
                }>>;
                readonly agent: Schema.String;
                readonly model: Schema.Struct<{
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                    readonly variant: Schema.optional<Schema.String>;
                }>;
                readonly system: Schema.optional<Schema.String>;
                readonly tools: Schema.optional<Schema.$Record<Schema.String, Schema.Boolean>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly role: Schema.Literal<"assistant">;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly completed: Schema.optional<Schema.Int>;
                }>;
                readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly name: Schema.Literal<"ProviderAuthError">;
                    readonly data: Schema.Struct<{
                        providerID: Schema.String;
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"UnknownError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        ref: Schema.optional<Schema.String>;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"MessageOutputLengthError">;
                    readonly data: Schema.Struct<{}>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"MessageAbortedError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"StructuredOutputError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        retries: Schema.Int;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"ContextOverflowError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        responseBody: Schema.optional<Schema.String>;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"ContentFilterError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"APIError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        statusCode: Schema.optional<Schema.Int>;
                        isRetryable: Schema.Boolean;
                        responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                        responseBody: Schema.optional<Schema.String>;
                        metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    }>;
                }>]>>;
                readonly parentID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly mode: Schema.String;
                readonly agent: Schema.String;
                readonly path: Schema.Struct<{
                    readonly cwd: Schema.String;
                    readonly root: Schema.String;
                }>;
                readonly summary: Schema.optional<Schema.Boolean>;
                readonly cost: Schema.Finite;
                readonly tokens: Schema.Struct<{
                    readonly total: Schema.optional<Schema.Finite>;
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>;
                readonly structured: Schema.optional<Schema.Any>;
                readonly variant: Schema.optional<Schema.String>;
                readonly finish: Schema.optional<Schema.String>;
            }>]>;
        }>;
    };
    MessageRemoved: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"message.removed">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
        }>;
    }> & {
        type: "message.removed";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
        }>;
    };
    PartUpdated: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"message.part.updated">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly part: Schema.Union<readonly [Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
                readonly synthetic: Schema.optional<Schema.Boolean>;
                readonly ignored: Schema.optional<Schema.Boolean>;
                readonly time: Schema.optional<Schema.Struct<{
                    readonly start: Schema.Int;
                    readonly end: Schema.optional<Schema.Int>;
                }>>;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"subtask">;
                readonly prompt: Schema.String;
                readonly description: Schema.String;
                readonly agent: Schema.String;
                readonly model: Schema.optional<Schema.Struct<{
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                }>>;
                readonly command: Schema.optional<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"reasoning">;
                readonly text: Schema.String;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                readonly time: Schema.Struct<{
                    readonly start: Schema.Int;
                    readonly end: Schema.optional<Schema.Int>;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"file">;
                readonly mime: Schema.String;
                readonly filename: Schema.optional<Schema.String>;
                readonly url: Schema.String;
                readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"file">;
                    readonly path: Schema.String;
                }>, Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"symbol">;
                    readonly path: Schema.String;
                    readonly range: Schema.Struct<{
                        readonly start: Schema.Struct<{
                            readonly line: Schema.Int;
                            readonly character: Schema.Int;
                        }>;
                        readonly end: Schema.Struct<{
                            readonly line: Schema.Int;
                            readonly character: Schema.Int;
                        }>;
                    }>;
                    readonly name: Schema.String;
                    readonly kind: Schema.Int;
                }>, Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"resource">;
                    readonly clientName: Schema.String;
                    readonly uri: Schema.String;
                }>]>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"tool">;
                readonly callID: Schema.String;
                readonly tool: Schema.String;
                readonly state: Schema.Union<readonly [Schema.Struct<{
                    readonly status: Schema.Literal<"pending">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly raw: Schema.String;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"running">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly title: Schema.optional<Schema.String>;
                    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                    }>;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"completed">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly output: Schema.String;
                    readonly title: Schema.String;
                    readonly metadata: Schema.$Record<Schema.String, Schema.Any>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                        readonly end: Schema.Int;
                        readonly compacted: Schema.optional<Schema.Int>;
                    }>;
                    readonly attachments: Schema.optional<Schema.$Array<Schema.Struct<{
                        readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                        };
                        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                            create: () => string & import("effect/Brand").Brand<"SessionID">;
                        };
                        readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                        };
                        readonly type: Schema.Literal<"file">;
                        readonly mime: Schema.String;
                        readonly filename: Schema.optional<Schema.String>;
                        readonly url: Schema.String;
                        readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"file">;
                            readonly path: Schema.String;
                        }>, Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"symbol">;
                            readonly path: Schema.String;
                            readonly range: Schema.Struct<{
                                readonly start: Schema.Struct<{
                                    readonly line: Schema.Int;
                                    readonly character: Schema.Int;
                                }>;
                                readonly end: Schema.Struct<{
                                    readonly line: Schema.Int;
                                    readonly character: Schema.Int;
                                }>;
                            }>;
                            readonly name: Schema.String;
                            readonly kind: Schema.Int;
                        }>, Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"resource">;
                            readonly clientName: Schema.String;
                            readonly uri: Schema.String;
                        }>]>>;
                    }>>>;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"error">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly error: Schema.String;
                    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                        readonly end: Schema.Int;
                    }>;
                }>]>;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"step-start">;
                readonly snapshot: Schema.optional<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"step-finish">;
                readonly reason: Schema.String;
                readonly snapshot: Schema.optional<Schema.String>;
                readonly cost: Schema.Finite;
                readonly tokens: Schema.Struct<{
                    readonly total: Schema.optional<Schema.Finite>;
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"snapshot">;
                readonly snapshot: Schema.String;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"patch">;
                readonly hash: Schema.String;
                readonly files: Schema.$Array<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"agent">;
                readonly name: Schema.String;
                readonly source: Schema.optional<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly start: Schema.Int;
                    readonly end: Schema.Int;
                }>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"retry">;
                readonly attempt: Schema.Int;
                readonly error: Schema.Struct<{
                    readonly name: Schema.Literal<"APIError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        statusCode: Schema.optional<Schema.Int>;
                        isRetryable: Schema.Boolean;
                        responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                        responseBody: Schema.optional<Schema.String>;
                        metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    }>;
                }>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"compaction">;
                readonly auto: Schema.Boolean;
                readonly overflow: Schema.optional<Schema.Boolean>;
                readonly tail_start_id: Schema.optional<Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                }>;
            }>]>;
            readonly time: Schema.Finite;
        }>;
    }> & {
        type: "message.part.updated";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly part: Schema.Union<readonly [Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
                readonly synthetic: Schema.optional<Schema.Boolean>;
                readonly ignored: Schema.optional<Schema.Boolean>;
                readonly time: Schema.optional<Schema.Struct<{
                    readonly start: Schema.Int;
                    readonly end: Schema.optional<Schema.Int>;
                }>>;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"subtask">;
                readonly prompt: Schema.String;
                readonly description: Schema.String;
                readonly agent: Schema.String;
                readonly model: Schema.optional<Schema.Struct<{
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                }>>;
                readonly command: Schema.optional<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"reasoning">;
                readonly text: Schema.String;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                readonly time: Schema.Struct<{
                    readonly start: Schema.Int;
                    readonly end: Schema.optional<Schema.Int>;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"file">;
                readonly mime: Schema.String;
                readonly filename: Schema.optional<Schema.String>;
                readonly url: Schema.String;
                readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"file">;
                    readonly path: Schema.String;
                }>, Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"symbol">;
                    readonly path: Schema.String;
                    readonly range: Schema.Struct<{
                        readonly start: Schema.Struct<{
                            readonly line: Schema.Int;
                            readonly character: Schema.Int;
                        }>;
                        readonly end: Schema.Struct<{
                            readonly line: Schema.Int;
                            readonly character: Schema.Int;
                        }>;
                    }>;
                    readonly name: Schema.String;
                    readonly kind: Schema.Int;
                }>, Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"resource">;
                    readonly clientName: Schema.String;
                    readonly uri: Schema.String;
                }>]>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"tool">;
                readonly callID: Schema.String;
                readonly tool: Schema.String;
                readonly state: Schema.Union<readonly [Schema.Struct<{
                    readonly status: Schema.Literal<"pending">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly raw: Schema.String;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"running">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly title: Schema.optional<Schema.String>;
                    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                    }>;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"completed">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly output: Schema.String;
                    readonly title: Schema.String;
                    readonly metadata: Schema.$Record<Schema.String, Schema.Any>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                        readonly end: Schema.Int;
                        readonly compacted: Schema.optional<Schema.Int>;
                    }>;
                    readonly attachments: Schema.optional<Schema.$Array<Schema.Struct<{
                        readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                        };
                        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                            create: () => string & import("effect/Brand").Brand<"SessionID">;
                        };
                        readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                        };
                        readonly type: Schema.Literal<"file">;
                        readonly mime: Schema.String;
                        readonly filename: Schema.optional<Schema.String>;
                        readonly url: Schema.String;
                        readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"file">;
                            readonly path: Schema.String;
                        }>, Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"symbol">;
                            readonly path: Schema.String;
                            readonly range: Schema.Struct<{
                                readonly start: Schema.Struct<{
                                    readonly line: Schema.Int;
                                    readonly character: Schema.Int;
                                }>;
                                readonly end: Schema.Struct<{
                                    readonly line: Schema.Int;
                                    readonly character: Schema.Int;
                                }>;
                            }>;
                            readonly name: Schema.String;
                            readonly kind: Schema.Int;
                        }>, Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"resource">;
                            readonly clientName: Schema.String;
                            readonly uri: Schema.String;
                        }>]>>;
                    }>>>;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"error">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly error: Schema.String;
                    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                        readonly end: Schema.Int;
                    }>;
                }>]>;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"step-start">;
                readonly snapshot: Schema.optional<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"step-finish">;
                readonly reason: Schema.String;
                readonly snapshot: Schema.optional<Schema.String>;
                readonly cost: Schema.Finite;
                readonly tokens: Schema.Struct<{
                    readonly total: Schema.optional<Schema.Finite>;
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"snapshot">;
                readonly snapshot: Schema.String;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"patch">;
                readonly hash: Schema.String;
                readonly files: Schema.$Array<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"agent">;
                readonly name: Schema.String;
                readonly source: Schema.optional<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly start: Schema.Int;
                    readonly end: Schema.Int;
                }>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"retry">;
                readonly attempt: Schema.Int;
                readonly error: Schema.Struct<{
                    readonly name: Schema.Literal<"APIError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        statusCode: Schema.optional<Schema.Int>;
                        isRetryable: Schema.Boolean;
                        responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                        responseBody: Schema.optional<Schema.String>;
                        metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    }>;
                }>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"compaction">;
                readonly auto: Schema.Boolean;
                readonly overflow: Schema.optional<Schema.Boolean>;
                readonly tail_start_id: Schema.optional<Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                }>;
            }>]>;
            readonly time: Schema.Finite;
        }>;
    };
    PartRemoved: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"message.part.removed">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
            readonly partID: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
            };
        }>;
    }> & {
        type: "message.part.removed";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
            readonly partID: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
            };
        }>;
    };
    PartDelta: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"message.part.delta">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
            readonly partID: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
            };
            readonly field: Schema.String;
            readonly delta: Schema.String;
        }>;
    }> & {
        type: "message.part.delta";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
            readonly partID: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
            };
            readonly field: Schema.String;
            readonly delta: Schema.String;
        }>;
    };
    Diff: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"session.diff">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly diff: Schema.$Array<Schema.Struct<{
                readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly additions: Schema.Finite;
                readonly deletions: Schema.Finite;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
            }>>;
        }>;
    }> & {
        type: "session.diff";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly diff: Schema.$Array<Schema.Struct<{
                readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly additions: Schema.Finite;
                readonly deletions: Schema.Finite;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
            }>>;
        }>;
    };
    Error: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"session.error">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.optional<Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            }>;
            readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                readonly name: Schema.Literal<"ProviderAuthError">;
                readonly data: Schema.Struct<{
                    providerID: Schema.String;
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"UnknownError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    ref: Schema.optional<Schema.String>;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"MessageOutputLengthError">;
                readonly data: Schema.Struct<{}>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"MessageAbortedError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"StructuredOutputError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    retries: Schema.Int;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"ContextOverflowError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    responseBody: Schema.optional<Schema.String>;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"ContentFilterError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"APIError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    statusCode: Schema.optional<Schema.Int>;
                    isRetryable: Schema.Boolean;
                    responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    responseBody: Schema.optional<Schema.String>;
                    metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                }>;
            }>]>>;
        }>;
    }> & {
        type: "session.error";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.optional<Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            }>;
            readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                readonly name: Schema.Literal<"ProviderAuthError">;
                readonly data: Schema.Struct<{
                    providerID: Schema.String;
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"UnknownError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    ref: Schema.optional<Schema.String>;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"MessageOutputLengthError">;
                readonly data: Schema.Struct<{}>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"MessageAbortedError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"StructuredOutputError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    retries: Schema.Int;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"ContextOverflowError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    responseBody: Schema.optional<Schema.String>;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"ContentFilterError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"APIError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    statusCode: Schema.optional<Schema.Int>;
                    isRetryable: Schema.Boolean;
                    responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    responseBody: Schema.optional<Schema.String>;
                    metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                }>;
            }>]>>;
        }>;
    };
    Definitions: readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"session.created">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    }> & {
        type: "session.created";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"session.updated">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    }> & {
        type: "session.updated";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"session.deleted">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    }> & {
        type: "session.deleted";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly slug: Schema.String;
                readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                    create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                }>, never, never>;
                readonly directory: Schema.String;
                readonly path: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                }>, never, never>;
                readonly summary: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly additions: Schema.Finite;
                    readonly deletions: Schema.Finite;
                    readonly files: Schema.Finite;
                    readonly diffs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>>, never, never>;
                }>>, never, never>;
                readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>>, never, never>;
                readonly share: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly url: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly url: Schema.String;
                }>>, never, never>;
                readonly title: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly agent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly model: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Model.ID">;
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
                readonly version: Schema.String;
                readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly updated: Schema.Int;
                    readonly compacting: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly archived: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
                }>;
                readonly permission: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
                    readonly permission: Schema.String;
                    readonly pattern: Schema.String;
                    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
                }>>>, never, never>;
                readonly revert: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                    };
                    readonly partID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>>, Schema.optionalKey<Schema.brand<Schema.String, "SessionV1.PartID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                    }>, never, never>;
                    readonly snapshot: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly diff: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }>>, never, never>;
            }>;
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"message.updated">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Union<readonly [Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly role: Schema.Literal<"user">;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Finite;
                }>;
                readonly format: Schema.optional<Schema.Union<readonly [typeof OutputFormatText, typeof OutputFormatJsonSchema]>>;
                readonly summary: Schema.optional<Schema.Struct<{
                    readonly title: Schema.optional<Schema.String>;
                    readonly body: Schema.optional<Schema.String>;
                    readonly diffs: Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>;
                }>>;
                readonly agent: Schema.String;
                readonly model: Schema.Struct<{
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                    readonly variant: Schema.optional<Schema.String>;
                }>;
                readonly system: Schema.optional<Schema.String>;
                readonly tools: Schema.optional<Schema.$Record<Schema.String, Schema.Boolean>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly role: Schema.Literal<"assistant">;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly completed: Schema.optional<Schema.Int>;
                }>;
                readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly name: Schema.Literal<"ProviderAuthError">;
                    readonly data: Schema.Struct<{
                        providerID: Schema.String;
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"UnknownError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        ref: Schema.optional<Schema.String>;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"MessageOutputLengthError">;
                    readonly data: Schema.Struct<{}>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"MessageAbortedError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"StructuredOutputError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        retries: Schema.Int;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"ContextOverflowError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        responseBody: Schema.optional<Schema.String>;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"ContentFilterError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"APIError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        statusCode: Schema.optional<Schema.Int>;
                        isRetryable: Schema.Boolean;
                        responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                        responseBody: Schema.optional<Schema.String>;
                        metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    }>;
                }>]>>;
                readonly parentID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly mode: Schema.String;
                readonly agent: Schema.String;
                readonly path: Schema.Struct<{
                    readonly cwd: Schema.String;
                    readonly root: Schema.String;
                }>;
                readonly summary: Schema.optional<Schema.Boolean>;
                readonly cost: Schema.Finite;
                readonly tokens: Schema.Struct<{
                    readonly total: Schema.optional<Schema.Finite>;
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>;
                readonly structured: Schema.optional<Schema.Any>;
                readonly variant: Schema.optional<Schema.String>;
                readonly finish: Schema.optional<Schema.String>;
            }>]>;
        }>;
    }> & {
        type: "message.updated";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly info: Schema.Union<readonly [Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly role: Schema.Literal<"user">;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Finite;
                }>;
                readonly format: Schema.optional<Schema.Union<readonly [typeof OutputFormatText, typeof OutputFormatJsonSchema]>>;
                readonly summary: Schema.optional<Schema.Struct<{
                    readonly title: Schema.optional<Schema.String>;
                    readonly body: Schema.optional<Schema.String>;
                    readonly diffs: Schema.$Array<Schema.Struct<{
                        readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly additions: Schema.Finite;
                        readonly deletions: Schema.Finite;
                        readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
                    }>>;
                }>>;
                readonly agent: Schema.String;
                readonly model: Schema.Struct<{
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                    readonly variant: Schema.optional<Schema.String>;
                }>;
                readonly system: Schema.optional<Schema.String>;
                readonly tools: Schema.optional<Schema.$Record<Schema.String, Schema.Boolean>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly role: Schema.Literal<"assistant">;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                    readonly completed: Schema.optional<Schema.Int>;
                }>;
                readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly name: Schema.Literal<"ProviderAuthError">;
                    readonly data: Schema.Struct<{
                        providerID: Schema.String;
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"UnknownError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        ref: Schema.optional<Schema.String>;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"MessageOutputLengthError">;
                    readonly data: Schema.Struct<{}>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"MessageAbortedError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"StructuredOutputError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        retries: Schema.Int;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"ContextOverflowError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        responseBody: Schema.optional<Schema.String>;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"ContentFilterError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                    }>;
                }>, Schema.Struct<{
                    readonly name: Schema.Literal<"APIError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        statusCode: Schema.optional<Schema.Int>;
                        isRetryable: Schema.Boolean;
                        responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                        responseBody: Schema.optional<Schema.String>;
                        metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    }>;
                }>]>>;
                readonly parentID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                    openai: string & import("effect/Brand").Brand<"Provider.ID">;
                    google: string & import("effect/Brand").Brand<"Provider.ID">;
                    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                    azure: string & import("effect/Brand").Brand<"Provider.ID">;
                    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                };
                readonly mode: Schema.String;
                readonly agent: Schema.String;
                readonly path: Schema.Struct<{
                    readonly cwd: Schema.String;
                    readonly root: Schema.String;
                }>;
                readonly summary: Schema.optional<Schema.Boolean>;
                readonly cost: Schema.Finite;
                readonly tokens: Schema.Struct<{
                    readonly total: Schema.optional<Schema.Finite>;
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>;
                readonly structured: Schema.optional<Schema.Any>;
                readonly variant: Schema.optional<Schema.String>;
                readonly finish: Schema.optional<Schema.String>;
            }>]>;
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"message.removed">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
        }>;
    }> & {
        type: "message.removed";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"message.part.updated">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly part: Schema.Union<readonly [Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
                readonly synthetic: Schema.optional<Schema.Boolean>;
                readonly ignored: Schema.optional<Schema.Boolean>;
                readonly time: Schema.optional<Schema.Struct<{
                    readonly start: Schema.Int;
                    readonly end: Schema.optional<Schema.Int>;
                }>>;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"subtask">;
                readonly prompt: Schema.String;
                readonly description: Schema.String;
                readonly agent: Schema.String;
                readonly model: Schema.optional<Schema.Struct<{
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                }>>;
                readonly command: Schema.optional<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"reasoning">;
                readonly text: Schema.String;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                readonly time: Schema.Struct<{
                    readonly start: Schema.Int;
                    readonly end: Schema.optional<Schema.Int>;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"file">;
                readonly mime: Schema.String;
                readonly filename: Schema.optional<Schema.String>;
                readonly url: Schema.String;
                readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"file">;
                    readonly path: Schema.String;
                }>, Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"symbol">;
                    readonly path: Schema.String;
                    readonly range: Schema.Struct<{
                        readonly start: Schema.Struct<{
                            readonly line: Schema.Int;
                            readonly character: Schema.Int;
                        }>;
                        readonly end: Schema.Struct<{
                            readonly line: Schema.Int;
                            readonly character: Schema.Int;
                        }>;
                    }>;
                    readonly name: Schema.String;
                    readonly kind: Schema.Int;
                }>, Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"resource">;
                    readonly clientName: Schema.String;
                    readonly uri: Schema.String;
                }>]>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"tool">;
                readonly callID: Schema.String;
                readonly tool: Schema.String;
                readonly state: Schema.Union<readonly [Schema.Struct<{
                    readonly status: Schema.Literal<"pending">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly raw: Schema.String;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"running">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly title: Schema.optional<Schema.String>;
                    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                    }>;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"completed">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly output: Schema.String;
                    readonly title: Schema.String;
                    readonly metadata: Schema.$Record<Schema.String, Schema.Any>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                        readonly end: Schema.Int;
                        readonly compacted: Schema.optional<Schema.Int>;
                    }>;
                    readonly attachments: Schema.optional<Schema.$Array<Schema.Struct<{
                        readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                        };
                        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                            create: () => string & import("effect/Brand").Brand<"SessionID">;
                        };
                        readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                        };
                        readonly type: Schema.Literal<"file">;
                        readonly mime: Schema.String;
                        readonly filename: Schema.optional<Schema.String>;
                        readonly url: Schema.String;
                        readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"file">;
                            readonly path: Schema.String;
                        }>, Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"symbol">;
                            readonly path: Schema.String;
                            readonly range: Schema.Struct<{
                                readonly start: Schema.Struct<{
                                    readonly line: Schema.Int;
                                    readonly character: Schema.Int;
                                }>;
                                readonly end: Schema.Struct<{
                                    readonly line: Schema.Int;
                                    readonly character: Schema.Int;
                                }>;
                            }>;
                            readonly name: Schema.String;
                            readonly kind: Schema.Int;
                        }>, Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"resource">;
                            readonly clientName: Schema.String;
                            readonly uri: Schema.String;
                        }>]>>;
                    }>>>;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"error">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly error: Schema.String;
                    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                        readonly end: Schema.Int;
                    }>;
                }>]>;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"step-start">;
                readonly snapshot: Schema.optional<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"step-finish">;
                readonly reason: Schema.String;
                readonly snapshot: Schema.optional<Schema.String>;
                readonly cost: Schema.Finite;
                readonly tokens: Schema.Struct<{
                    readonly total: Schema.optional<Schema.Finite>;
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"snapshot">;
                readonly snapshot: Schema.String;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"patch">;
                readonly hash: Schema.String;
                readonly files: Schema.$Array<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"agent">;
                readonly name: Schema.String;
                readonly source: Schema.optional<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly start: Schema.Int;
                    readonly end: Schema.Int;
                }>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"retry">;
                readonly attempt: Schema.Int;
                readonly error: Schema.Struct<{
                    readonly name: Schema.Literal<"APIError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        statusCode: Schema.optional<Schema.Int>;
                        isRetryable: Schema.Boolean;
                        responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                        responseBody: Schema.optional<Schema.String>;
                        metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    }>;
                }>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"compaction">;
                readonly auto: Schema.Boolean;
                readonly overflow: Schema.optional<Schema.Boolean>;
                readonly tail_start_id: Schema.optional<Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                }>;
            }>]>;
            readonly time: Schema.Finite;
        }>;
    }> & {
        type: "message.part.updated";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly part: Schema.Union<readonly [Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
                readonly synthetic: Schema.optional<Schema.Boolean>;
                readonly ignored: Schema.optional<Schema.Boolean>;
                readonly time: Schema.optional<Schema.Struct<{
                    readonly start: Schema.Int;
                    readonly end: Schema.optional<Schema.Int>;
                }>>;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"subtask">;
                readonly prompt: Schema.String;
                readonly description: Schema.String;
                readonly agent: Schema.String;
                readonly model: Schema.optional<Schema.Struct<{
                    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                        openai: string & import("effect/Brand").Brand<"Provider.ID">;
                        google: string & import("effect/Brand").Brand<"Provider.ID">;
                        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                        azure: string & import("effect/Brand").Brand<"Provider.ID">;
                        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
                    };
                    readonly modelID: Schema.brand<Schema.String, "Model.ID">;
                }>>;
                readonly command: Schema.optional<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"reasoning">;
                readonly text: Schema.String;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                readonly time: Schema.Struct<{
                    readonly start: Schema.Int;
                    readonly end: Schema.optional<Schema.Int>;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"file">;
                readonly mime: Schema.String;
                readonly filename: Schema.optional<Schema.String>;
                readonly url: Schema.String;
                readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"file">;
                    readonly path: Schema.String;
                }>, Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"symbol">;
                    readonly path: Schema.String;
                    readonly range: Schema.Struct<{
                        readonly start: Schema.Struct<{
                            readonly line: Schema.Int;
                            readonly character: Schema.Int;
                        }>;
                        readonly end: Schema.Struct<{
                            readonly line: Schema.Int;
                            readonly character: Schema.Int;
                        }>;
                    }>;
                    readonly name: Schema.String;
                    readonly kind: Schema.Int;
                }>, Schema.Struct<{
                    readonly text: Schema.Struct<{
                        readonly value: Schema.String;
                        readonly start: Schema.Finite;
                        readonly end: Schema.Finite;
                    }>;
                    readonly type: Schema.Literal<"resource">;
                    readonly clientName: Schema.String;
                    readonly uri: Schema.String;
                }>]>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"tool">;
                readonly callID: Schema.String;
                readonly tool: Schema.String;
                readonly state: Schema.Union<readonly [Schema.Struct<{
                    readonly status: Schema.Literal<"pending">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly raw: Schema.String;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"running">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly title: Schema.optional<Schema.String>;
                    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                    }>;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"completed">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly output: Schema.String;
                    readonly title: Schema.String;
                    readonly metadata: Schema.$Record<Schema.String, Schema.Any>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                        readonly end: Schema.Int;
                        readonly compacted: Schema.optional<Schema.Int>;
                    }>;
                    readonly attachments: Schema.optional<Schema.$Array<Schema.Struct<{
                        readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                        };
                        readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                            create: () => string & import("effect/Brand").Brand<"SessionID">;
                        };
                        readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                            ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                        };
                        readonly type: Schema.Literal<"file">;
                        readonly mime: Schema.String;
                        readonly filename: Schema.optional<Schema.String>;
                        readonly url: Schema.String;
                        readonly source: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"file">;
                            readonly path: Schema.String;
                        }>, Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"symbol">;
                            readonly path: Schema.String;
                            readonly range: Schema.Struct<{
                                readonly start: Schema.Struct<{
                                    readonly line: Schema.Int;
                                    readonly character: Schema.Int;
                                }>;
                                readonly end: Schema.Struct<{
                                    readonly line: Schema.Int;
                                    readonly character: Schema.Int;
                                }>;
                            }>;
                            readonly name: Schema.String;
                            readonly kind: Schema.Int;
                        }>, Schema.Struct<{
                            readonly text: Schema.Struct<{
                                readonly value: Schema.String;
                                readonly start: Schema.Finite;
                                readonly end: Schema.Finite;
                            }>;
                            readonly type: Schema.Literal<"resource">;
                            readonly clientName: Schema.String;
                            readonly uri: Schema.String;
                        }>]>>;
                    }>>>;
                }>, Schema.Struct<{
                    readonly status: Schema.Literal<"error">;
                    readonly input: Schema.$Record<Schema.String, Schema.Any>;
                    readonly error: Schema.String;
                    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
                    readonly time: Schema.Struct<{
                        readonly start: Schema.Int;
                        readonly end: Schema.Int;
                    }>;
                }>]>;
                readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Any>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"step-start">;
                readonly snapshot: Schema.optional<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"step-finish">;
                readonly reason: Schema.String;
                readonly snapshot: Schema.optional<Schema.String>;
                readonly cost: Schema.Finite;
                readonly tokens: Schema.Struct<{
                    readonly total: Schema.optional<Schema.Finite>;
                    readonly input: Schema.Finite;
                    readonly output: Schema.Finite;
                    readonly reasoning: Schema.Finite;
                    readonly cache: Schema.Struct<{
                        readonly read: Schema.Finite;
                        readonly write: Schema.Finite;
                    }>;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"snapshot">;
                readonly snapshot: Schema.String;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"patch">;
                readonly hash: Schema.String;
                readonly files: Schema.$Array<Schema.String>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"agent">;
                readonly name: Schema.String;
                readonly source: Schema.optional<Schema.Struct<{
                    readonly value: Schema.String;
                    readonly start: Schema.Int;
                    readonly end: Schema.Int;
                }>>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"retry">;
                readonly attempt: Schema.Int;
                readonly error: Schema.Struct<{
                    readonly name: Schema.Literal<"APIError">;
                    readonly data: Schema.Struct<{
                        message: Schema.String;
                        statusCode: Schema.optional<Schema.Int>;
                        isRetryable: Schema.Boolean;
                        responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                        responseBody: Schema.optional<Schema.String>;
                        metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    }>;
                }>;
                readonly time: Schema.Struct<{
                    readonly created: Schema.Int;
                }>;
            }>, Schema.Struct<{
                readonly id: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
                };
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                };
                readonly type: Schema.Literal<"compaction">;
                readonly auto: Schema.Boolean;
                readonly overflow: Schema.optional<Schema.Boolean>;
                readonly tail_start_id: Schema.optional<Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                    ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
                }>;
            }>]>;
            readonly time: Schema.Finite;
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"message.part.removed">;
        readonly durable: Schema.Struct<{
            readonly aggregateID: Schema.String;
            readonly seq: Schema.brand<Schema.Int, "Event.Seq">;
            readonly version: Schema.decodeTo<Schema.toType<Schema.brand<Schema.Int, "Event.Version">>, Schema.Literal<number>, never, never>;
        }>;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
            readonly partID: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
            };
        }>;
    }> & {
        type: "message.part.removed";
        durability: "durable";
        durable: {
            readonly version: number;
            readonly aggregate: string;
        };
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
            readonly partID: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
            };
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"message.part.delta">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
            readonly partID: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
            };
            readonly field: Schema.String;
            readonly delta: Schema.String;
        }>;
    }> & {
        type: "message.part.delta";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly messageID: Schema.brand<Schema.String, "SessionV1.MessageID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.MessageID">;
            };
            readonly partID: Schema.brand<Schema.String, "SessionV1.PartID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"SessionV1.PartID">;
            };
            readonly field: Schema.String;
            readonly delta: Schema.String;
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"session.diff">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly diff: Schema.$Array<Schema.Struct<{
                readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly additions: Schema.Finite;
                readonly deletions: Schema.Finite;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
            }>>;
        }>;
    }> & {
        type: "session.diff";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly diff: Schema.$Array<Schema.Struct<{
                readonly file: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly patch: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                readonly additions: Schema.Finite;
                readonly deletions: Schema.Finite;
                readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["added", "deleted", "modified"]>>>, Schema.optionalKey<Schema.Literals<readonly ["added", "deleted", "modified"]>>, never, never>;
            }>>;
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"session.error">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.optional<Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            }>;
            readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                readonly name: Schema.Literal<"ProviderAuthError">;
                readonly data: Schema.Struct<{
                    providerID: Schema.String;
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"UnknownError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    ref: Schema.optional<Schema.String>;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"MessageOutputLengthError">;
                readonly data: Schema.Struct<{}>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"MessageAbortedError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"StructuredOutputError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    retries: Schema.Int;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"ContextOverflowError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    responseBody: Schema.optional<Schema.String>;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"ContentFilterError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"APIError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    statusCode: Schema.optional<Schema.Int>;
                    isRetryable: Schema.Boolean;
                    responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    responseBody: Schema.optional<Schema.String>;
                    metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                }>;
            }>]>>;
        }>;
    }> & {
        type: "session.error";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.optional<Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            }>;
            readonly error: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                readonly name: Schema.Literal<"ProviderAuthError">;
                readonly data: Schema.Struct<{
                    providerID: Schema.String;
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"UnknownError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    ref: Schema.optional<Schema.String>;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"MessageOutputLengthError">;
                readonly data: Schema.Struct<{}>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"MessageAbortedError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"StructuredOutputError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    retries: Schema.Int;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"ContextOverflowError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    responseBody: Schema.optional<Schema.String>;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"ContentFilterError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                }>;
            }>, Schema.Struct<{
                readonly name: Schema.Literal<"APIError">;
                readonly data: Schema.Struct<{
                    message: Schema.String;
                    statusCode: Schema.optional<Schema.Int>;
                    isRetryable: Schema.Boolean;
                    responseHeaders: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                    responseBody: Schema.optional<Schema.String>;
                    metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
                }>;
            }>]>>;
        }>;
    }];
};
