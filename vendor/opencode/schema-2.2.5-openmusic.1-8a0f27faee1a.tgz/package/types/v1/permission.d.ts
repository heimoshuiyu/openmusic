export * as PermissionV1 from "./permission.js";
import { Schema } from "effect";
export declare const ID: Schema.brand<Schema.String, "PermissionV1.ID"> & {
    ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
};
export type ID = typeof ID.Type;
export declare const Action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
export type Action = typeof Action.Type;
export declare const Rule: Schema.Struct<{
    readonly permission: Schema.String;
    readonly pattern: Schema.String;
    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
}>;
export type Rule = typeof Rule.Type;
export declare const Ruleset: Schema.$Array<Schema.Struct<{
    readonly permission: Schema.String;
    readonly pattern: Schema.String;
    readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
}>>;
export type Ruleset = typeof Ruleset.Type;
export declare const Request: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "PermissionV1.ID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
    };
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly permission: Schema.String;
    readonly patterns: Schema.$Array<Schema.String>;
    readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly always: Schema.$Array<Schema.String>;
    readonly tool: Schema.optional<Schema.Struct<{
        readonly messageID: Schema.String;
        readonly callID: Schema.String;
    }>>;
}>;
export type Request = typeof Request.Type;
export declare const Reply: Schema.Literals<readonly ["once", "always", "reject"]>;
export type Reply = typeof Reply.Type;
export declare const ReplyBody: Schema.Struct<{
    readonly reply: Schema.Literals<readonly ["once", "always", "reject"]>;
    readonly message: Schema.optional<Schema.String>;
}>;
export type ReplyBody = typeof ReplyBody.Type;
export declare const Approval: Schema.Struct<{
    readonly projectID: Schema.brand<Schema.String, "Project.ID"> & {
        global: string & import("effect/Brand").Brand<"Project.ID">;
    };
    readonly patterns: Schema.$Array<Schema.String>;
}>;
export type Approval = typeof Approval.Type;
export declare const AskInput: Schema.Struct<{
    readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
        create: () => string & import("effect/Brand").Brand<"SessionID">;
    };
    readonly permission: Schema.String;
    readonly patterns: Schema.$Array<Schema.String>;
    readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly always: Schema.$Array<Schema.String>;
    readonly tool: Schema.optional<Schema.Struct<{
        readonly messageID: Schema.String;
        readonly callID: Schema.String;
    }>>;
    readonly id: Schema.optional<Schema.brand<Schema.String, "PermissionV1.ID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
    }>;
    readonly ruleset: Schema.$Array<Schema.Struct<{
        readonly permission: Schema.String;
        readonly pattern: Schema.String;
        readonly action: Schema.Literals<readonly ["allow", "deny", "ask"]>;
    }>>;
}>;
export type AskInput = typeof AskInput.Type;
export declare const ReplyInput: Schema.Struct<{
    readonly reply: Schema.Literals<readonly ["once", "always", "reject"]>;
    readonly message: Schema.optional<Schema.String>;
    readonly requestID: Schema.brand<Schema.String, "PermissionV1.ID"> & {
        ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
    };
}>;
export type ReplyInput = typeof ReplyInput.Type;
export declare const Event: {
    Asked: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"permission.asked">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PermissionV1.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
            };
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly permission: Schema.String;
            readonly patterns: Schema.$Array<Schema.String>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly always: Schema.$Array<Schema.String>;
            readonly tool: Schema.optional<Schema.Struct<{
                readonly messageID: Schema.String;
                readonly callID: Schema.String;
            }>>;
        }>;
    }> & {
        type: "permission.asked";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PermissionV1.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
            };
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly permission: Schema.String;
            readonly patterns: Schema.$Array<Schema.String>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly always: Schema.$Array<Schema.String>;
            readonly tool: Schema.optional<Schema.Struct<{
                readonly messageID: Schema.String;
                readonly callID: Schema.String;
            }>>;
        }>;
    };
    Replied: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"permission.replied">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly requestID: Schema.brand<Schema.String, "PermissionV1.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
            };
            readonly reply: Schema.Literals<readonly ["once", "always", "reject"]>;
        }>;
    }> & {
        type: "permission.replied";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly requestID: Schema.brand<Schema.String, "PermissionV1.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
            };
            readonly reply: Schema.Literals<readonly ["once", "always", "reject"]>;
        }>;
    };
    Definitions: readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"permission.asked">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PermissionV1.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
            };
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly permission: Schema.String;
            readonly patterns: Schema.$Array<Schema.String>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly always: Schema.$Array<Schema.String>;
            readonly tool: Schema.optional<Schema.Struct<{
                readonly messageID: Schema.String;
                readonly callID: Schema.String;
            }>>;
        }>;
    }> & {
        type: "permission.asked";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "PermissionV1.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
            };
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly permission: Schema.String;
            readonly patterns: Schema.$Array<Schema.String>;
            readonly metadata: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly always: Schema.$Array<Schema.String>;
            readonly tool: Schema.optional<Schema.Struct<{
                readonly messageID: Schema.String;
                readonly callID: Schema.String;
            }>>;
        }>;
    }, Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"permission.replied">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly requestID: Schema.brand<Schema.String, "PermissionV1.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
            };
            readonly reply: Schema.Literals<readonly ["once", "always", "reject"]>;
        }>;
    }> & {
        type: "permission.replied";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{
            readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly requestID: Schema.brand<Schema.String, "PermissionV1.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PermissionV1.ID">;
            };
            readonly reply: Schema.Literals<readonly ["once", "always", "reject"]>;
        }>;
    }];
};
