export * as SessionLegacy from "./session-legacy.js";
/** Upgrades a durable event payload by event type. */
export declare function event(type: string, data: unknown): unknown;
/** Upgrades a projected message's data by message type. */
export declare function message(type: unknown, data: Record<string, unknown>): Record<string, unknown>;
/** Upgrades complete messages, such as those in an exported session, before decoding. */
export declare function messages(values: ReadonlyArray<unknown>): unknown[];
/** Upgrades an assistant content part written before v2.1. */
export declare function part(value: unknown): unknown;
