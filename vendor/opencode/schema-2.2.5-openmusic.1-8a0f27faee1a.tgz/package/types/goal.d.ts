export * as Goal from "./goal.js";
import { Schema } from "effect";
export declare const Status: Schema.Literals<readonly ["active", "paused", "complete"]>;
export type Status = typeof Status.Type;
export interface State extends Schema.Schema.Type<typeof State> {
}
export declare const State: Schema.Struct<{
    readonly id: Schema.String;
    readonly objective: Schema.String;
    readonly status: Schema.Literals<readonly ["active", "paused", "complete"]>;
    /** Why the goal last changed: the reviewer's reason, or what paused it. */
    readonly reason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    /** Continuations sent since the goal was set or last resumed. */
    readonly rounds: Schema.Number;
    /** A backstop for loops that stall detection misses. */
    readonly maxRounds: Schema.Number;
    /** Rounds in a row without progress: no tool calls, or the same reason as the round before. */
    readonly stalls: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
    /** The server process that armed the goal. */
    readonly boot: Schema.String;
    readonly updatedAt: Schema.Number;
}>;
/**
 * The `/goal` plugin's RPC. Clients read a Session's goal with `get` and keep it current from `changed`, which the
 * plugin publishes in the Session's Location on every write. A Session's goal is its own: children and forks start
 * without one. The schemas are Standard Schemas too, so Promise clients can call it.
 */
export declare const Definition: {
    readonly id: "opencode.goal";
    readonly methods: {
        get: {
            input: import("effect/StandardSchema").StandardSchemaV1<{
                readonly sessionID: string;
            }, {
                readonly sessionID: string;
            }> & Schema.Struct<{
                readonly sessionID: Schema.String;
            }>;
            output: import("effect/StandardSchema").StandardSchemaV1<{
                readonly id: string;
                readonly objective: string;
                readonly status: "active" | "complete" | "paused";
                readonly reason?: string | undefined;
                readonly rounds: number;
                readonly maxRounds: number;
                readonly stalls?: number | undefined;
                readonly boot: string;
                readonly updatedAt: number;
            } | null, {
                readonly id: string;
                readonly objective: string;
                readonly status: "active" | "complete" | "paused";
                readonly reason?: string | undefined;
                readonly rounds: number;
                readonly maxRounds: number;
                readonly stalls?: number | undefined;
                readonly boot: string;
                readonly updatedAt: number;
            } | null> & Schema.NullOr<Schema.Struct<{
                readonly id: Schema.String;
                readonly objective: Schema.String;
                readonly status: Schema.Literals<readonly ["active", "paused", "complete"]>;
                /** Why the goal last changed: the reviewer's reason, or what paused it. */
                readonly reason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                /** Continuations sent since the goal was set or last resumed. */
                readonly rounds: Schema.Number;
                /** A backstop for loops that stall detection misses. */
                readonly maxRounds: Schema.Number;
                /** Rounds in a row without progress: no tool calls, or the same reason as the round before. */
                readonly stalls: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                /** The server process that armed the goal. */
                readonly boot: Schema.String;
                readonly updatedAt: Schema.Number;
            }>>;
        };
    };
    readonly events: {
        changed: {
            schema: import("effect/StandardSchema").StandardSchemaV1<{
                readonly sessionID: string;
                readonly goal: {
                    readonly id: string;
                    readonly objective: string;
                    readonly status: "active" | "complete" | "paused";
                    readonly reason?: string | undefined;
                    readonly rounds: number;
                    readonly maxRounds: number;
                    readonly stalls?: number | undefined;
                    readonly boot: string;
                    readonly updatedAt: number;
                } | null;
            }, {
                readonly sessionID: string;
                readonly goal: {
                    readonly id: string;
                    readonly objective: string;
                    readonly status: "active" | "complete" | "paused";
                    readonly reason?: string | undefined;
                    readonly rounds: number;
                    readonly maxRounds: number;
                    readonly stalls?: number | undefined;
                    readonly boot: string;
                    readonly updatedAt: number;
                } | null;
            }> & Schema.Struct<{
                readonly sessionID: Schema.String;
                readonly goal: Schema.NullOr<Schema.Struct<{
                    readonly id: Schema.String;
                    readonly objective: Schema.String;
                    readonly status: Schema.Literals<readonly ["active", "paused", "complete"]>;
                    /** Why the goal last changed: the reviewer's reason, or what paused it. */
                    readonly reason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    /** Continuations sent since the goal was set or last resumed. */
                    readonly rounds: Schema.Number;
                    /** A backstop for loops that stall detection misses. */
                    readonly maxRounds: Schema.Number;
                    /** Rounds in a row without progress: no tool calls, or the same reason as the round before. */
                    readonly stalls: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optionalKey<Schema.Number>, never, never>;
                    /** The server process that armed the goal. */
                    readonly boot: Schema.String;
                    readonly updatedAt: Schema.Number;
                }>>;
            }>;
        };
    };
};
