export * as Provider from "./provider.js";
import { Schema } from "effect";
export declare const ID: Schema.brand<Schema.String, "Provider.ID"> & {
    opencode: string & import("effect/Brand").Brand<"Provider.ID">;
    anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
    openai: string & import("effect/Brand").Brand<"Provider.ID">;
    google: string & import("effect/Brand").Brand<"Provider.ID">;
    googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
    githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
    claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
    amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
    azure: string & import("effect/Brand").Brand<"Provider.ID">;
    openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
    mistral: string & import("effect/Brand").Brand<"Provider.ID">;
    gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
};
export type ID = typeof ID.Type;
export declare const Event: {
    Updated: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"provider.updated">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{}>;
    }> & {
        type: "provider.updated";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{}>;
    };
    Definitions: readonly [Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Event.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Event.ID">;
        };
        readonly created: Schema.Finite;
        readonly metadata: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
        readonly type: Schema.Literal<"provider.updated">;
        readonly location: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.brand<Schema.String, "AbsolutePath">;
            readonly workspaceID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, Schema.optionalKey<Schema.brand<Schema.String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>>, never, never>;
        readonly data: Schema.Struct<{}>;
    }> & {
        type: "provider.updated";
        durability: "ephemeral";
        durable: undefined;
        data: Schema.Struct<{}>;
    }];
};
export declare const Package: Schema.String;
export type Package = typeof Package.Type;
export declare const Activation: Schema.Literals<readonly ["auto", "enabled", "disabled"]>;
export type Activation = typeof Activation.Type;
export declare const Compaction: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"summary">;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"native">;
}>]>;
export type Compaction = typeof Compaction.Type;
/** "websocket" on a route without a WebSocket channel warns and falls back to HTTP. */
export declare const Transport: Schema.Literals<readonly ["http", "websocket"]>;
export type Transport = typeof Transport.Type;
/** Prompt-cache lifetime such as "5m", "30m", "1h" or "24h", in models.dev's duration format. */
export declare const CacheTTL: Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>;
export type CacheTTL = typeof CacheTTL.Type;
/** Keep-alive requests for this provider's or model's sessions; overrides the top-level `warming`. */
export declare const CacheWarming: Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
    readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
    readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>]>;
export type CacheWarming = typeof CacheWarming.Type;
/** Prompt-cache settings. `ttl` is sent to the provider as given; each provider accepts its own set. */
export declare const Cache: Schema.Struct<{
    readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
    readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
        readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
        readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
        readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
        readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>, never, never>;
}>;
export type Cache = typeof Cache.Type;
/** HTTP request body compression; only endpoints known to decode it should enable it. */
export declare const Encoding: Schema.Literals<readonly ["zstd", "gzip", "none"]>;
export type Encoding = typeof Encoding.Type;
export declare const Settings: Schema.StructWithRest<Schema.Struct<{
    readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
    readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
    readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
    readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"summary">;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"native">;
    }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"summary">;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"native">;
    }>]>>, never, never>;
    readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
        readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
        readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
            readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
            readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>]>>, never, never>;
    }>>, never, never>;
    readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
    readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
}>, readonly [Schema.$Record<Schema.String, Schema.Any>]>;
export type Settings = typeof Settings.Type;
export declare const Overlays: {
    settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
        readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>, never, never>;
        readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>, never, never>;
        readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
        readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
        readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>, never, never>;
        readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>, never, never>;
        readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
        readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>, never, never>;
    headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
    body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
};
export interface Request extends Schema.Schema.Type<typeof Request> {
}
export declare const Request: Schema.Struct<{
    readonly settings: Schema.withConstructorDefault<Schema.StructWithRest<Schema.Struct<{
        readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>, never, never>;
        readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>, never, never>;
        readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
        readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>;
    readonly headers: Schema.$Record<Schema.String, Schema.String>;
    readonly body: Schema.$Record<Schema.String, Schema.Any>;
}>;
export interface Info extends Schema.Schema.Type<typeof Info> {
}
export declare const Info: Schema.Struct<{
    readonly settings: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
        readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>, never, never>;
        readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>, never, never>;
        readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
        readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>>, Schema.optionalKey<Schema.StructWithRest<Schema.Struct<{
        readonly timeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly headerTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly chunkTimeout: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Finite, Schema.Literal<false>]>>, never, never>;
        readonly compaction: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"summary">;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"native">;
        }>]>>, never, never>;
        readonly cache: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly ttl: Schema.decodeTo<Schema.optional<Schema.toType<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>>, Schema.optionalKey<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>, never, never>;
            readonly warming: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Boolean, Schema.Struct<{
                readonly interval: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>>, Schema.optionalKey<Schema.Union<readonly [Schema.Literal<"auto">, Schema.String]>>, never, never>;
                readonly duration: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            }>]>>, never, never>;
        }>>, never, never>;
        readonly transport: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["http", "websocket"]>>>, Schema.optionalKey<Schema.Literals<readonly ["http", "websocket"]>>, never, never>;
        readonly encoding: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["zstd", "gzip", "none"]>>>, Schema.optionalKey<Schema.Literals<readonly ["zstd", "gzip", "none"]>>, never, never>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Any>]>>, never, never>;
    readonly headers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.String>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.String>>, never, never>;
    readonly body: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Any>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Any>>, never, never>;
    readonly id: Schema.brand<Schema.String, "Provider.ID"> & {
        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
        openai: string & import("effect/Brand").Brand<"Provider.ID">;
        google: string & import("effect/Brand").Brand<"Provider.ID">;
        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
        azure: string & import("effect/Brand").Brand<"Provider.ID">;
        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
    };
    readonly canonical: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Provider.ID"> & {
        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
        openai: string & import("effect/Brand").Brand<"Provider.ID">;
        google: string & import("effect/Brand").Brand<"Provider.ID">;
        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
        azure: string & import("effect/Brand").Brand<"Provider.ID">;
        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
    }>>, Schema.optionalKey<Schema.brand<Schema.String, "Provider.ID"> & {
        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
        openai: string & import("effect/Brand").Brand<"Provider.ID">;
        google: string & import("effect/Brand").Brand<"Provider.ID">;
        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
        azure: string & import("effect/Brand").Brand<"Provider.ID">;
        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
    }>, never, never>;
    readonly integrationID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Integration.ID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Integration.ID">>, never, never>;
    readonly name: Schema.String;
    readonly activation: Schema.Literals<readonly ["auto", "enabled", "disabled"]>;
    readonly package: Schema.String;
    /** Inherited by every model of this provider; model compatibility overrides individual fields. */
    readonly compatibility: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<import("./model-compatibility.js").ReasoningField, import("./model-compatibility.js").ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<import("./model-compatibility.js").ReasoningField, import("./model-compatibility.js").ReasoningField, never, never>>, never, never>;
        readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
        readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
        readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly reasoningField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<import("./model-compatibility.js").ReasoningField, import("./model-compatibility.js").ReasoningField, never, never>>>, Schema.optionalKey<Schema.Codec<import("./model-compatibility.js").ReasoningField, import("./model-compatibility.js").ReasoningField, never, never>>, never, never>;
        readonly requireReasoning: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly maxTokensField: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>>, Schema.optionalKey<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>, never, never>;
        readonly requireFinishReason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly requireAssistantAfterTool: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly supportsPromptCacheKey: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly streamUsage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly cacheFormat: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["anthropic", "alibaba"]>>>, Schema.optionalKey<Schema.Literals<readonly ["anthropic", "alibaba"]>>, never, never>;
        readonly mediaInput: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["assets", "state", "root"]>>>, Schema.optionalKey<Schema.Literals<readonly ["assets", "state", "root"]>>, never, never>;
    }>>, never, never>;
}> & {
    empty: (id: ID) => Info;
};
