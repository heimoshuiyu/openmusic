export * as Generate from "./generate.js";
import { Schema } from "effect";
export interface File extends Schema.Schema.Type<typeof File> {
}
export declare const File: Schema.Struct<{
    readonly data: Schema.String;
    readonly mime: Schema.String;
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>;
export interface Usage extends Schema.Schema.Type<typeof Usage> {
}
export declare const Usage: Schema.Struct<{
    readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
}>;
export declare const Native: Schema.$Record<Schema.String, Schema.Unknown>;
export type Native = typeof Native.Type;
export type ImageAspect = `${number}:${number}`;
export declare const ImageAspect: Schema.Codec<ImageAspect>;
/** Open-ended: providers add size tiers beyond these. */
export type ImageResolution = "1K" | "2K" | "4K" | (string & {});
export declare const ImageResolution: Schema.Codec<ImageResolution>;
export interface ImageRequest extends Schema.Schema.Type<typeof ImageRequest> {
}
export declare const ImageRequest: Schema.Struct<{
    readonly model: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    };
    readonly prompt: Schema.String;
    readonly images: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>>, Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>, never, never>;
    readonly n: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly aspect: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<`${number}:${number}`, `${number}:${number}`, never, never>>>, Schema.optionalKey<Schema.Codec<`${number}:${number}`, `${number}:${number}`, never, never>>, never, never>;
    readonly resolution: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Codec<ImageResolution, ImageResolution, never, never>>>, Schema.optionalKey<Schema.Codec<ImageResolution, ImageResolution, never, never>>, never, never>;
}>;
export interface ImageOutput extends Schema.Schema.Type<typeof ImageOutput> {
}
export declare const ImageOutput: Schema.Struct<{
    readonly data: Schema.String;
    readonly mime: Schema.String;
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.Literal<"image">;
}>;
export interface ImageResult extends Schema.Schema.Type<typeof ImageResult> {
}
export declare const ImageResult: Schema.Struct<{
    readonly images: Schema.$Array<Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.Literal<"image">;
    }>>;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>>, never, never>;
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>;
export interface DecisionTextPart extends Schema.Schema.Type<typeof DecisionTextPart> {
}
export declare const DecisionTextPart: Schema.Struct<{
    readonly type: Schema.Literal<"text">;
    readonly text: Schema.String;
}>;
export interface DecisionJsonPart extends Schema.Schema.Type<typeof DecisionJsonPart> {
}
export declare const DecisionJsonPart: Schema.Struct<{
    readonly type: Schema.Literal<"json">;
    readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
}>;
export interface DecisionFilePart extends Schema.Schema.Type<typeof DecisionFilePart> {
}
export declare const DecisionFilePart: Schema.Struct<{
    readonly data: Schema.String;
    readonly mime: Schema.String;
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.Literal<"file">;
}>;
export type DecisionPart = DecisionTextPart | DecisionJsonPart | DecisionFilePart;
export declare const DecisionPart: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"text">;
    readonly text: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"json">;
    readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
}>, Schema.Struct<{
    readonly data: Schema.String;
    readonly mime: Schema.String;
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly type: Schema.Literal<"file">;
}>]>;
export declare const ChoiceValue: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
export type ChoiceValue = typeof ChoiceValue.Type;
export interface PredicateQuestion extends Schema.Schema.Type<typeof PredicateQuestion> {
}
export declare const PredicateQuestion: Schema.Struct<{
    readonly type: Schema.Literal<"predicate">;
    readonly name: Schema.String;
    readonly instructions: Schema.String;
    readonly criteria: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly true: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly false: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly true: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly false: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>, never, never>;
}>;
export interface ChoiceQuestion extends Schema.Schema.Type<typeof ChoiceQuestion> {
}
export declare const ChoiceQuestion: Schema.Struct<{
    readonly type: Schema.Literal<"choice">;
    readonly name: Schema.String;
    readonly instructions: Schema.String;
    readonly choices: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>;
}>;
export interface ScoreQuestion extends Schema.Schema.Type<typeof ScoreQuestion> {
}
export declare const ScoreQuestion: Schema.Struct<{
    readonly type: Schema.Literal<"score">;
    readonly name: Schema.String;
    readonly instructions: Schema.String;
    readonly levels: Schema.$Array<Schema.Struct<{
        readonly label: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>;
}>;
export type DecisionQuestion = PredicateQuestion | ChoiceQuestion | ScoreQuestion;
export declare const DecisionQuestion: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"predicate">;
    readonly name: Schema.String;
    readonly instructions: Schema.String;
    readonly criteria: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly true: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly false: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly true: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly false: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"choice">;
    readonly name: Schema.String;
    readonly instructions: Schema.String;
    readonly choices: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"score">;
    readonly name: Schema.String;
    readonly instructions: Schema.String;
    readonly levels: Schema.$Array<Schema.Struct<{
        readonly label: Schema.String;
        readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>>;
}>]>;
export interface DecisionRequest extends Schema.Schema.Type<typeof DecisionRequest> {
}
export declare const DecisionRequest: Schema.Struct<{
    readonly model: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Model.ID">;
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly variant: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Model.VariantID">>>, Schema.optionalKey<Schema.brand<Schema.String, "Model.VariantID">>, never, never>;
    }> & {
        parse: (input: string) => {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
    };
    readonly input: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"json">;
        readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    }>, Schema.Struct<{
        readonly data: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly type: Schema.Literal<"file">;
    }>]>>;
    readonly questions: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"predicate">;
        readonly name: Schema.String;
        readonly instructions: Schema.String;
        readonly criteria: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
            readonly true: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly false: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>>, Schema.optionalKey<Schema.Struct<{
            readonly true: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly false: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>, never, never>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"choice">;
        readonly name: Schema.String;
        readonly instructions: Schema.String;
        readonly choices: Schema.$Array<Schema.Struct<{
            readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"score">;
        readonly name: Schema.String;
        readonly instructions: Schema.String;
        readonly levels: Schema.$Array<Schema.Struct<{
            readonly label: Schema.String;
            readonly description: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        }>>;
    }>]>>;
}>;
export interface PredicateAnswer extends Schema.Schema.Type<typeof PredicateAnswer> {
}
export declare const PredicateAnswer: Schema.Struct<{
    readonly type: Schema.Literal<"predicate">;
    readonly name: Schema.String;
    readonly probability: Schema.Finite;
}>;
export interface ChoiceAnswer extends Schema.Schema.Type<typeof ChoiceAnswer> {
}
export declare const ChoiceAnswer: Schema.Struct<{
    readonly type: Schema.Literal<"choice">;
    readonly name: Schema.String;
    readonly choice: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
    readonly probabilities: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
        readonly probability: Schema.Finite;
    }>>;
    readonly confidence: Schema.Finite;
}>;
export interface ScoreAnswer extends Schema.Schema.Type<typeof ScoreAnswer> {
}
export declare const ScoreAnswer: Schema.Struct<{
    readonly type: Schema.Literal<"score">;
    readonly name: Schema.String;
    readonly score: Schema.Finite;
    readonly probabilities: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Int;
        readonly label: Schema.String;
        readonly probability: Schema.Finite;
    }>>;
    readonly confidence: Schema.Finite;
}>;
export interface ErrorAnswer extends Schema.Schema.Type<typeof ErrorAnswer> {
}
export declare const ErrorAnswer: Schema.Struct<{
    readonly type: Schema.Literal<"error">;
    readonly name: Schema.String;
    readonly reason: Schema.String;
    readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>;
export type DecisionAnswer = PredicateAnswer | ChoiceAnswer | ScoreAnswer | ErrorAnswer;
export declare const DecisionAnswer: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"predicate">;
    readonly name: Schema.String;
    readonly probability: Schema.Finite;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"choice">;
    readonly name: Schema.String;
    readonly choice: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
    readonly probabilities: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
        readonly probability: Schema.Finite;
    }>>;
    readonly confidence: Schema.Finite;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"score">;
    readonly name: Schema.String;
    readonly score: Schema.Finite;
    readonly probabilities: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Int;
        readonly label: Schema.String;
        readonly probability: Schema.Finite;
    }>>;
    readonly confidence: Schema.Finite;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"error">;
    readonly name: Schema.String;
    readonly reason: Schema.String;
    readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}>]>;
export interface DecisionResult extends Schema.Schema.Type<typeof DecisionResult> {
}
export declare const DecisionResult: Schema.Struct<{
    readonly answers: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"predicate">;
        readonly name: Schema.String;
        readonly probability: Schema.Finite;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"choice">;
        readonly name: Schema.String;
        readonly choice: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
        readonly probabilities: Schema.$Array<Schema.Struct<{
            readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
            readonly probability: Schema.Finite;
        }>>;
        readonly confidence: Schema.Finite;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"score">;
        readonly name: Schema.String;
        readonly score: Schema.Finite;
        readonly probabilities: Schema.$Array<Schema.Struct<{
            readonly value: Schema.Int;
            readonly label: Schema.String;
            readonly probability: Schema.Finite;
        }>>;
        readonly confidence: Schema.Finite;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"error">;
        readonly name: Schema.String;
        readonly reason: Schema.String;
        readonly message: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>]>>;
    readonly cost: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
    readonly tokens: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly input: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Finite>>, Schema.optionalKey<Schema.Finite>, never, never>;
    }>>, never, never>;
    readonly native: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Record<Schema.String, Schema.Unknown>>>, Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>, never, never>;
}>;
