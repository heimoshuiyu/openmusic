export * as InstructionEntry from "./instruction-entry.js";
import { Schema } from "effect";
/**
 * Slash-free client-facing key for one API-managed instruction entry. The server
 * derives the namespaced Instructions key as `api/<key>`, keeping the
 * `api/*` namespace enforced by construction.
 */
export declare const Key: Schema.String;
export type Key = typeof Key.Type;
export declare const Info: Schema.Struct<{
    readonly key: Schema.String;
    readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
}>;
export interface Info extends Schema.Schema.Type<typeof Info> {
}
export declare const Snapshot: Schema.$Array<Schema.Struct<{
    readonly key: Schema.String;
    readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    readonly removed: Schema.Boolean;
}>>;
export type Snapshot = typeof Snapshot.Type;
export declare const MaxValueBytes: number;
declare const ValueTooLargeError_base: Schema.Class<ValueTooLargeError, Schema.TaggedStruct<"InstructionEntryValueTooLargeError", {
    readonly actualBytes: Schema.Int;
    readonly maxBytes: Schema.Int;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
export declare class ValueTooLargeError extends ValueTooLargeError_base {
}
