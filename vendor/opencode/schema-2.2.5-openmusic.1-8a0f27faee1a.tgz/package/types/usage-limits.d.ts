export * as UsageLimits from "./usage-limits.js";
import { Schema } from "effect";
/** One window of the OpenCode Go allowance. */
export interface Meter extends Schema.Schema.Type<typeof Meter> {
}
export declare const Meter: Schema.Struct<{
    /** How much of the window's allowance is used. */
    readonly percent: Schema.Finite;
    /** Go refuses requests until the window resets. */
    readonly limited: Schema.Boolean;
    readonly resetsAt: Schema.Finite;
}>;
/** The OpenCode Go allowance of a workspace the member subscribes to Go in. */
export interface Go extends Schema.Schema.Type<typeof Go> {
}
export declare const Go: Schema.Struct<{
    readonly rolling: Schema.Struct<{
        /** How much of the window's allowance is used. */
        readonly percent: Schema.Finite;
        /** Go refuses requests until the window resets. */
        readonly limited: Schema.Boolean;
        readonly resetsAt: Schema.Finite;
    }>;
    readonly weekly: Schema.Struct<{
        /** How much of the window's allowance is used. */
        readonly percent: Schema.Finite;
        /** Go refuses requests until the window resets. */
        readonly limited: Schema.Boolean;
        readonly resetsAt: Schema.Finite;
    }>;
    readonly monthly: Schema.Struct<{
        /** How much of the window's allowance is used. */
        readonly percent: Schema.Finite;
        /** Go refuses requests until the window resets. */
        readonly limited: Schema.Boolean;
        readonly resetsAt: Schema.Finite;
    }>;
}>;
/** A model a budget covers, by the IDs OpenCode knows it by. */
export interface BudgetModel extends Schema.Schema.Type<typeof BudgetModel> {
}
export declare const BudgetModel: Schema.Struct<{
    readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
        opencode: string & import("effect/Brand").Brand<"Provider.ID">;
        anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
        openai: string & import("effect/Brand").Brand<"Provider.ID">;
        google: string & import("effect/Brand").Brand<"Provider.ID">;
        googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
        githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
        claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
        amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
        azure: string & import("effect/Brand").Brand<"Provider.ID">;
        openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
        mistral: string & import("effect/Brand").Brand<"Provider.ID">;
        gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
    };
    readonly modelID: Schema.brand<Schema.String, "Model.ID">;
    readonly name: Schema.String;
    /** What a per-model budget's member has spent on this model this month. */
    readonly spent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    }>, never, never>;
}>;
/** A monthly spend limit the OpenCode Console workspace sets on the member. */
export interface Budget extends Schema.Schema.Type<typeof Budget> {
}
export declare const Budget: Schema.Struct<{
    readonly id: Schema.String;
    readonly limit: Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    };
    /** The member's spend this month, or the pooled spend of a combined budget; per model, the most on one model. */
    readonly spent: Schema.brand<Schema.Finite, "Money.USD"> & {
        zero: number & import("effect/Brand").Brand<"Money.USD">;
    };
    /** `each` limits every member separately; `combined` pools everyone's spend against one limit. */
    readonly scope: Schema.Literals<readonly ["each", "combined"]>;
    /** `set` counts spend across the budget's models; `model` limits each model separately. */
    readonly per: Schema.Literals<readonly ["set", "model"]>;
    /** `all` covers every model and billable service; `models` covers only `models`. */
    readonly coverage: Schema.Literals<readonly ["all", "models"]>;
    readonly models: Schema.$Array<Schema.Struct<{
        readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
            opencode: string & import("effect/Brand").Brand<"Provider.ID">;
            anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
            openai: string & import("effect/Brand").Brand<"Provider.ID">;
            google: string & import("effect/Brand").Brand<"Provider.ID">;
            googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
            githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
            claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
            amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
            azure: string & import("effect/Brand").Brand<"Provider.ID">;
            openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
            mistral: string & import("effect/Brand").Brand<"Provider.ID">;
            gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
        };
        readonly modelID: Schema.brand<Schema.String, "Model.ID">;
        readonly name: Schema.String;
        /** What a per-model budget's member has spent on this model this month. */
        readonly spent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
    }>>;
    /** The vendors whose models the budget counts, by name; empty when it doesn't count by vendor. */
    readonly vendors: Schema.$Array<Schema.String>;
    /** The input price per 1M tokens from which the budget counts a model, when it sets one. */
    readonly inputPriceAtLeast: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
        zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
    }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
        zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
    }>, never, never>;
    /** The budget counts models picked one by one, rather than by vendor or price. */
    readonly picked: Schema.Boolean;
    /** Everyone in the workspace pools spend against it, so reaching it pauses model use for all of them. */
    readonly shared: Schema.Boolean;
    readonly resetsAt: Schema.Finite;
}>;
/** The usage limits of the OpenCode Console workspace a location is signed in to. */
export interface Info extends Schema.Schema.Type<typeof Info> {
}
export declare const Info: Schema.Struct<{
    readonly workspace: Schema.Struct<{
        readonly id: Schema.String;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        /** The member's usage page in OpenCode Console. */
        readonly usageURL: Schema.String;
    }>;
    readonly go: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly rolling: Schema.Struct<{
            /** How much of the window's allowance is used. */
            readonly percent: Schema.Finite;
            /** Go refuses requests until the window resets. */
            readonly limited: Schema.Boolean;
            readonly resetsAt: Schema.Finite;
        }>;
        readonly weekly: Schema.Struct<{
            /** How much of the window's allowance is used. */
            readonly percent: Schema.Finite;
            /** Go refuses requests until the window resets. */
            readonly limited: Schema.Boolean;
            readonly resetsAt: Schema.Finite;
        }>;
        readonly monthly: Schema.Struct<{
            /** How much of the window's allowance is used. */
            readonly percent: Schema.Finite;
            /** Go refuses requests until the window resets. */
            readonly limited: Schema.Boolean;
            readonly resetsAt: Schema.Finite;
        }>;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly rolling: Schema.Struct<{
            /** How much of the window's allowance is used. */
            readonly percent: Schema.Finite;
            /** Go refuses requests until the window resets. */
            readonly limited: Schema.Boolean;
            readonly resetsAt: Schema.Finite;
        }>;
        readonly weekly: Schema.Struct<{
            /** How much of the window's allowance is used. */
            readonly percent: Schema.Finite;
            /** Go refuses requests until the window resets. */
            readonly limited: Schema.Boolean;
            readonly resetsAt: Schema.Finite;
        }>;
        readonly monthly: Schema.Struct<{
            /** How much of the window's allowance is used. */
            readonly percent: Schema.Finite;
            /** Go refuses requests until the window resets. */
            readonly limited: Schema.Boolean;
            readonly resetsAt: Schema.Finite;
        }>;
    }>>, never, never>;
    readonly budgets: Schema.$Array<Schema.Struct<{
        readonly id: Schema.String;
        readonly limit: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        /** The member's spend this month, or the pooled spend of a combined budget; per model, the most on one model. */
        readonly spent: Schema.brand<Schema.Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        /** `each` limits every member separately; `combined` pools everyone's spend against one limit. */
        readonly scope: Schema.Literals<readonly ["each", "combined"]>;
        /** `set` counts spend across the budget's models; `model` limits each model separately. */
        readonly per: Schema.Literals<readonly ["set", "model"]>;
        /** `all` covers every model and billable service; `models` covers only `models`. */
        readonly coverage: Schema.Literals<readonly ["all", "models"]>;
        readonly models: Schema.$Array<Schema.Struct<{
            readonly providerID: Schema.brand<Schema.String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly modelID: Schema.brand<Schema.String, "Model.ID">;
            readonly name: Schema.String;
            /** What a per-model budget's member has spent on this model this month. */
            readonly spent: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USD"> & {
                zero: number & import("effect/Brand").Brand<"Money.USD">;
            }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USD"> & {
                zero: number & import("effect/Brand").Brand<"Money.USD">;
            }>, never, never>;
        }>>;
        /** The vendors whose models the budget counts, by name; empty when it doesn't count by vendor. */
        readonly vendors: Schema.$Array<Schema.String>;
        /** The input price per 1M tokens from which the budget counts a model, when it sets one. */
        readonly inputPriceAtLeast: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
            zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
        }>>, Schema.optionalKey<Schema.brand<Schema.Finite, "Money.USDPerMillionTokens"> & {
            zero: number & import("effect/Brand").Brand<"Money.USDPerMillionTokens">;
        }>, never, never>;
        /** The budget counts models picked one by one, rather than by vendor or price. */
        readonly picked: Schema.Boolean;
        /** Everyone in the workspace pools spend against it, so reaching it pauses model use for all of them. */
        readonly shared: Schema.Boolean;
        readonly resetsAt: Schema.Finite;
    }>>;
}>;
