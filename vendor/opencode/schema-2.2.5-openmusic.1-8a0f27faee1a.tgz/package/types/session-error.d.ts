export * as SessionError from "./session-error.js";
import { Schema } from "effect";
export interface Error extends Schema.Schema.Type<typeof Error> {
}
export declare const Error: Schema.Struct<{
    readonly type: Schema.String;
    readonly message: Schema.String;
    readonly status: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly body: Schema.String;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly body: Schema.String;
    }>>, never, never>;
    /** How long the provider asked to wait before trying again, counted from when the failure was recorded. */
    readonly retryAfterMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}>;
