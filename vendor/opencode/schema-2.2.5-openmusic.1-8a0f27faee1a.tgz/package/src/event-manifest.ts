export * as EventManifest from "./event-manifest.js"

import { Schema } from "effect"
import { Agent } from "./agent.js"
import { Artifact } from "./artifact.js"
import { Command } from "./command.js"
import { Config } from "./config.js"
import { Credential } from "./credential.js"
import { Durable } from "./durable-event-manifest.js"
import { Event } from "./event.js"
import { FileSystem } from "./filesystem.js"
import { FileSystemV1 } from "./filesystem-v1.js"
import { Form } from "./form.js"
import { InstallationEvent } from "./installation-event.js"
import { Integration } from "./integration.js"
import { LegacyEventV1 } from "./legacy-event.js"
import { LspEvent } from "./lsp-event.js"
import { LocationEvent } from "./location-event.js"
import { McpEvent } from "./mcp-event.js"
import { Model } from "./model.js"
import { ModelsDev } from "./models-dev.js"
import { Permission } from "./permission.js"
import { PersistentPty } from "./persistent-pty.js"
import { Plugin } from "./plugin.js"
import { Project } from "./project.js"
import { Provider } from "./provider.js"
import { Worktree } from "./worktree.js"
import { Pty } from "./pty.js"
import { Reference } from "./reference.js"
import { ServerEvent } from "./server-event.js"
import { Shell } from "./shell.js"
import { Skill } from "./skill.js"
import { SessionEvent } from "./session-event.js"
import { SessionStatusEvent } from "./session-status-event.js"
import { TuiEvent } from "./tui-event.js"
import { VcsEvent } from "./vcs-event.js"
import { WorkspaceEvent } from "./workspace-event.js"
import { WorktreeEvent } from "./worktree-event.js"
import { WebSearch } from "./websearch.js"

const coreDefinitions = Event.inventory(...SessionEvent.Definitions)

const foundationDefinitions = Event.inventory(
  ...LocationEvent.Definitions,
  ...ModelsDev.Event.Definitions,
  ...Credential.Event.Definitions,
  ...Integration.Event.Definitions,
  ...Provider.Event.Definitions,
  ...Model.Event.Definitions,
  ...Agent.Event.Definitions,
  ...coreDefinitions,
)

const featureDefinitions = Event.inventory(
  ...FileSystem.Event.Definitions,
  ...Reference.Event.Definitions,
  ...Permission.Event.Definitions,
  ...Plugin.Event.Definitions,
  ...Project.Event.Definitions,
  ...Worktree.Event.Definitions,
  ...Command.Event.Definitions,
  ...Config.Event.Definitions,
  ...Skill.Event.Definitions,
  ...Pty.Event.Definitions,
  ...PersistentPty.Event.Definitions,
  ...Shell.Event.Definitions,
  ...Form.Event.Definitions,
  ...WebSearch.Event.Definitions,
  ...Artifact.Event.Definitions,
)

export const ServerDefinitions = Event.inventory(
  ...foundationDefinitions,
  ...featureDefinitions,
  // Current events the TUI consumes from the public stream.
  ...SessionStatusEvent.Definitions,
  ...TuiEvent.Definitions,
  ...InstallationEvent.Definitions,
  ...VcsEvent.Definitions,
  McpEvent.StatusChanged,
  McpEvent.ResourcesChanged,
)
export const Server = Event.latest(ServerDefinitions)
export type ServerEvent = Schema.Schema.Type<(typeof ServerDefinitions)[number]>
export const isServer = (event: { readonly type: string }): event is ServerEvent => Server.has(event.type)

export const Definitions = Event.inventory(
  ...foundationDefinitions,
  ...InstallationEvent.Definitions,
  ...featureDefinitions,
  ...LspEvent.Definitions,
  ...TuiEvent.Definitions,
  ...McpEvent.Definitions,
  ...LegacyEventV1.Definitions,
  ...FileSystemV1.Event.Definitions,
  ...SessionStatusEvent.Definitions,
  ...VcsEvent.Definitions,
  ...WorkspaceEvent.Definitions,
  ...WorktreeEvent.Definitions,
  ...ServerEvent.Definitions,
)
export const Latest = Event.latest(Definitions)
export { Durable }
