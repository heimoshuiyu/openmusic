export * as Transcription from "./transcription.js"

import { Schema } from "effect"
import { optional } from "./schema.js"

export const Backend = Schema.Literals(["whisper", "lalm"]).annotate({ identifier: "Transcription.Backend" })
export type Backend = typeof Backend.Type

export const ContextPairs = Schema.Int.check(Schema.isBetween({ minimum: 1, maximum: 20 }))
export const RequestContextPairs = Schema.Union([Schema.Literal(0), ContextPairs]).annotate({
  description: "0 sends audio and hot words without directory, conversation, images or draft; 1–20 includes context.",
})

export const whisperEndpoints = {
  openai: "https://api.openai.com/v1/audio/transcriptions",
  groq: "https://api.groq.com/openai/v1/audio/transcriptions",
} as const

/** Request-only overrides for the experimental transcription endpoint. */
export interface Overrides extends Schema.Schema.Type<typeof Overrides> {}
export const Overrides = Schema.Struct({
  context_pairs: RequestContextPairs.pipe(optional),
  hot_words: Schema.Array(Schema.String)
    .pipe(optional)
    .annotate({ description: "Replace all configured hot words, including with an empty list" }),
  whisper: Schema.Struct({
    url: Schema.String.annotate({ description: "Full, server-approved transcription endpoint URL" }),
    apiKey: Schema.String.pipe(optional).annotate({ description: "Request-only key for this exact URL" }),
  }).pipe(optional),
}).annotate({ identifier: "Transcription.Overrides" })

export interface Whisper extends Schema.Schema.Type<typeof Whisper> {}
export const Whisper = Schema.Struct({
  model: Schema.String.pipe(optional).annotate({ description: "Whisper model name (default: whisper-1)" }),
  language: Schema.String.pipe(optional).annotate({ description: "Language code hint for Whisper" }),
}).annotate({ identifier: "Transcription.Whisper" })

export interface Lalm extends Schema.Schema.Type<typeof Lalm> {}
export const Lalm = Schema.Struct({
  model: Schema.String.pipe(optional).annotate({
    description: "Model to use for audio transcription in the format of provider/model",
  }),
  variant: Schema.String.pipe(optional).annotate({
    description: "Named variant of the transcription model. Omit to use the model defaults.",
  }),
  system: Schema.String.pipe(optional).annotate({ description: "Large Audio Language Model system prompt" }),
  instruction: Schema.String.pipe(optional).annotate({
    description: "Instruction text appended after the audio content to guide transcription behavior",
  }),
  audio_input_format: Schema.Literals(["input_audio", "audio_url"]).pipe(optional).annotate({
    description: 'Audio input format for OpenAI-compatible LLM APIs: "input_audio" or "audio_url"',
  }),
}).annotate({ identifier: "Transcription.Lalm" })

export interface Settings extends Schema.Schema.Type<typeof Settings> {}
export const Settings = Schema.Struct({
  type: Backend.pipe(optional).annotate({ description: "Transcription backend (default: lalm)" }),
  whisper: Whisper.pipe(optional).annotate({ description: "Whisper transcription settings" }),
  lalm: Lalm.pipe(optional).annotate({ description: "Large Audio Language Model transcription settings" }),
  hot_words: Schema.Array(Schema.String).pipe(optional).annotate({
    description: "Hot words to improve transcription accuracy",
  }),
}).annotate({ identifier: "Transcription.Settings" })
