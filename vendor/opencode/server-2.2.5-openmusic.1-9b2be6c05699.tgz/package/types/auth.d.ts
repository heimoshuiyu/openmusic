export * as ServerAuth from "./auth";
import { Context, Layer, Option, Redacted } from "effect";
export type DecodedCredentials = {
    readonly username: string;
    readonly password: Redacted.Redacted;
};
export type Info = {
    readonly password: Option.Option<string>;
    readonly username: string;
};
export declare const SESSION_TTL_SECONDS: number;
declare const Config_base: Context.ServiceClass<Config, "@opencode/ServerAuthConfig", Info>;
export declare class Config extends Config_base {
    static configLayer(input: Pick<Info, "password">): Layer.Layer<Config, never, never>;
    static get layer(): Layer.Layer<Config, never, never>;
}
export declare function required(config: Info): boolean;
export declare function authorized(credentials: DecodedCredentials, config: Info): boolean;
export declare function issueSession(config: Info, now?: number): string | undefined;
export declare function verifySession(token: string, config: Info, now?: number): boolean;
export declare function sessionCookieName(host: string | undefined): string;
