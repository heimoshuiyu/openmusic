export * as ServerWorkerd from "./workerd";
import { Effect } from "effect";
import type { DurableObjectStorage } from "@opencode/core/database/sqlite.workerd";
import type { LayerNode } from "@opencode/util/effect/layer-node";
import type { ServerOptions } from "./options";
/**
 * The workerd runtime profile: boots opencode core and server inside a
 * Cloudflare Durable Object, with every intentionally-local service replaced
 * or disabled.
 *
 * - Database runs on the injected `DurableObjectStorage` SQLite.
 * - Watcher and fff are disabled through their existing option flags; pty, fff,
 *   and photon native modules resolve to inert stubs under the `workerd` bundle
 *   condition.
 * - Bare locations use a typed no-execution-plane process spawner; FileSystem,
 *   FileSystemSearch, and Pty fail with a clear defect until a remote sandbox
 *   backs them; Npm fails package installs with a typed workerd error; Snapshot
 *   and Vcs degrade to no-op results.
 * - Config is injected as a string (no filesystem); plugin discovery is
 *   precompiled-only, and stdio MCP reports the same no-plane failure as Shell.
 *
 * Bundle with the `workerd` condition, e.g.
 * `bun build src/workerd.ts --conditions=workerd --target=node`
 * (see `script/workerd-probe.ts`).
 */
export interface Options {
    /** Durable Object storage whose SQLite database backs the opencode database. */
    readonly storage: DurableObjectStorage;
    readonly app?: ServerOptions["app"];
    readonly password?: string;
    /** Inline opencode config content (JSON), same as `ServerOptions.config.content`. */
    readonly config?: {
        readonly content?: string;
    };
    /** models.dev catalog options; the bundled snapshot is the boot-time floor either way. */
    readonly models?: ServerOptions["models"];
    /** Replaces `globalThis.fetch` for OpenCode's own HTTP requests, e.g. to route them through a Service Binding. */
    readonly fetch?: ServerOptions["fetch"];
}
/**
 * Builds the web-standard fetch handler for a Durable Object's `fetch()`. The
 * application layer builds eagerly in the caller's scope, so hold it in the
 * Durable Object instance rather than per request.
 */
export declare function create(options: Options): Effect.Effect<(request: Request, context?: import("effect/Context").Context<never> | undefined) => Promise<globalThis.Response>, Error, import("effect/Scope").Scope>;
export declare function serverOptions(options: Options): ServerOptions;
/** The workerd replacement graph, applied after the standard server replacements. */
export declare function replacements(options: Options): LayerNode.Replacements;
