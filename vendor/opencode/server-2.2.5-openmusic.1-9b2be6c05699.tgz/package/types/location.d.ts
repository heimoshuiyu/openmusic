import { FileSystem } from "@opencode/core/filesystem";
import { Location } from "@opencode/core/location";
import { LocationServiceMap } from "@opencode/core/location-services";
import { Session } from "@opencode/core/session";
import { LocationNotFoundError, InvalidRequestError } from "@opencode/protocol/errors";
import { Effect, Layer } from "effect";
import { HttpServerRequest } from "effect/http";
import { HttpApiMiddleware } from "effect/http-api";
export type LocationServices = Layer.Success<ReturnType<(typeof LocationServiceMap.Service)["get"]>>;
declare const LocationMiddleware_base: HttpApiMiddleware.ServiceClass<LocationMiddleware, "@opencode/HttpApiLocation", {
    requires: never;
    provides: import("@opencode/core/instance").Services;
    error: readonly [typeof LocationNotFoundError];
    clientError: never;
    requiredForClient: false;
    security: never;
}, HttpApiMiddleware.HttpApiMiddleware<import("@opencode/core/instance").Services, readonly [typeof LocationNotFoundError], never>>;
export declare class LocationMiddleware extends LocationMiddleware_base {
}
export declare function locationErrors<A, E, R>(effect: Effect.Effect<A, E, R>): Effect.Effect<A, LocationNotFoundError | Exclude<E, Extract<E, FileSystem.DirectoryNotFoundError>>, R>;
export declare function response<A, E, R>(data: Effect.Effect<A, E, R>): Effect.Effect<{
    location: Location.Info;
    data: A;
}, E, R | Location.Service>;
export declare const sessionInfo: (sessions: Session.Interface, sessionID: unknown) => Effect.Effect<Session.SessionSchema.Info, InvalidRequestError | import("@opencode/protocol/errors").SessionNotFoundError, never>;
export declare function requestRef(request: HttpServerRequest.HttpServerRequest): Location.Ref;
export declare const layer: Layer.Layer<LocationMiddleware, never, LocationServiceMap.Service>;
export {};
