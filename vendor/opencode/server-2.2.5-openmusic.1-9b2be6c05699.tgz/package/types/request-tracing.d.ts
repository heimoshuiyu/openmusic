import { Effect } from "effect";
export declare const withoutParentSpan: <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E, R>;
