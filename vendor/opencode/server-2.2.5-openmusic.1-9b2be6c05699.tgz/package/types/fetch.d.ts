export * as ServerFetch from "./fetch";
import { Context, Effect } from "effect";
import type { LayerNode } from "@opencode/util/effect/layer-node";
export interface BootOptions {
    /**
     * Runtime-profile service replacements, applied after the standard set so later entries
     * win — swaps services the standard graph assumes are local. See `ServerWorkerd.replacements`.
     */
    readonly overrides?: LayerNode.Replacements;
}
/**
 * Builds a web-standard fetch handler — `(request: Request) => Promise<Response>` — serving the
 * same HttpApi routes as the Node server process without binding a port, owning a listener, or
 * installing signal handlers. This is the entry for runtimes that hand requests to the embedder
 * instead of letting it listen: workerd (Workers and Durable Objects), Deno.serve, Bun.serve, or
 * a test harness.
 *
 * The application layer builds EAGERLY, inside the caller's `Scope`, before the handler is
 * returned. Do not convert this to a lazy first-request build: on workerd, a first request that
 * aborts mid-build interrupts the layer construction and wedges every subsequent request
 * (Effect-TS/effect#6319 class). The embedder owns the lifecycle — closing the scope releases
 * the application layer.
 *
 * Auth follows `createRoutes` semantics: `options.password` enforces Basic auth; omitting it
 * serves unauthenticated, so an embedder without a password must front the handler with its own
 * access control.
 *
 * Sessions whose execution claim was never released resume once the layer is built, exactly as
 * the Node server process does: a runtime that dies without teardown — an evicted Durable
 * Object leaves the same durable signature as a killed process — replays orphaned turns on the
 * next boot, and the sweep is a no-op when nothing is suspended.
 */
export declare const make: (options?: {
    readonly app?: {
        readonly name?: string | undefined;
        readonly version?: string | undefined;
        readonly channel?: string | undefined;
    } | undefined;
    readonly hostname?: string | undefined;
    readonly port?: number | undefined;
    readonly password?: string | undefined;
    readonly cors?: readonly string[] | undefined;
    readonly simulation?: boolean | undefined;
    readonly database?: {
        readonly path?: string | undefined;
    } | undefined;
    readonly pty?: {
        readonly handoff?: {
            readonly directory: string;
            readonly instanceID: string;
            readonly ticket: string;
            readonly expiresAt: number;
        } | undefined;
        readonly root?: string | undefined;
    } | undefined;
    readonly events?: {
        readonly persist?: boolean | undefined;
    } | undefined;
    readonly models?: {
        readonly url?: string | undefined;
        readonly file?: string | undefined;
        readonly fetch?: boolean | undefined;
        readonly snapshot?: boolean | undefined;
    } | undefined;
    readonly fetch?: import("@opencode/util/effect/app-node-platform").Fetch | undefined;
    readonly config?: {
        readonly directory?: string | undefined;
        readonly project?: boolean | undefined;
        readonly claude?: boolean | undefined;
        readonly file?: string | undefined;
        readonly content?: string | undefined;
    } | undefined;
    readonly windows?: {
        readonly gitbash?: string | undefined;
    } | undefined;
    readonly fs?: {
        readonly filewatcher?: boolean | undefined;
        readonly fff?: boolean | undefined;
    } | undefined;
} | undefined, boot?: BootOptions | undefined) => Effect.Effect<(request: Request, context?: Context.Context<never> | undefined) => Promise<globalThis.Response>, Error, import("effect/Scope").Scope>;
