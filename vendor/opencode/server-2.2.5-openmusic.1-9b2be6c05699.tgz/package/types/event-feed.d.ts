export * as EventFeed from "./event-feed";
import { Bus } from "@opencode/core/bus";
import { type OpenCodeEvent } from "@opencode/protocol/groups/event";
import { Cause, Context, Effect, Layer, Schema, Scope, Stream } from "effect";
export declare const SubscriberCapacity = 4096;
declare const SubscriberOverflowError_base: Schema.Class<SubscriberOverflowError, Schema.TaggedStruct<"EventFeed.SubscriberOverflow", {
    readonly capacity: Schema.Int;
}>, Cause.YieldableError>;
export declare class SubscriberOverflowError extends SubscriberOverflowError_base {
}
declare const EncodingError_base: Schema.Class<EncodingError, Schema.TaggedStruct<"EventFeed.EncodingError", {
    readonly eventID: Schema.brand<Schema.String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly eventType: Schema.String;
    readonly cause: Schema.Defect;
}>, Cause.YieldableError>;
export declare class EncodingError extends EncodingError_base {
}
export type Error = SubscriberOverflowError | EncodingError;
export interface Interface {
    readonly subscribe: (types?: ReadonlyArray<string>) => Effect.Effect<Stream.Stream<string, Error>, never, Scope.Scope>;
}
declare const Service_base: Context.ServiceClass<Service, "@opencode/server/EventFeed", Interface>;
export declare class Service extends Service_base {
}
export declare function frame(event: OpenCodeEvent): string;
export declare const make: (observe: (subscriber: Bus.Subscriber) => Effect.Effect<Bus.Unsubscribe>, options?: {
    readonly capacity?: number;
    readonly encode?: (event: OpenCodeEvent) => string;
} | undefined) => Effect.Effect<Interface, never, Scope.Scope>;
export declare const layer: Layer.Layer<Service, never, Bus.Service>;
