export * as RequestSite from "./request-site";
import { Effect } from "effect";
import { HttpServerRequest, HttpServerResponse } from "effect/http";
import { type CorsOptions } from "./cors";
/**
 * API routes are called by scripts and native clients, not opened as pages from other sites. Browsers label requests
 * with Sec-Fetch-Site and Sec-Fetch-Mode; another site may navigate to the API or call it only from an allowed CORS
 * origin. Clients that send no Sec-Fetch headers (CLI, TUI, SDK, mobile) and same-origin or typed-in requests pass.
 */
export declare function rejected(request: HttpServerRequest.HttpServerRequest, options?: CorsOptions): boolean;
export declare const middleware: (options?: CorsOptions) => <E, R>(app: Effect.Effect<HttpServerResponse.HttpServerResponse, E, R | HttpServerRequest.HttpServerRequest>) => Effect.Effect<HttpServerResponse.HttpServerResponse, E, R | HttpServerRequest.HttpServerRequest>;
