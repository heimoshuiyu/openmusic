export * as ContentHeaders from "./content-headers";
export declare const CONTENT_SECURITY_POLICY = "default-src 'none'; img-src 'self'; media-src 'self'; sandbox";
/** Headers for raw file bytes: always a download, never rendered as a page on the server's origin. */
export declare function download(input: {
    readonly path?: string;
    readonly mime: string;
}): {
    "content-type": string;
    "content-disposition": string;
    "content-security-policy": string;
    "x-content-type-options": string;
};
export declare function disposition(name: string): string;
