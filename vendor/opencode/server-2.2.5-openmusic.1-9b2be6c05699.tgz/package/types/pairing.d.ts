export * as ServerPairing from "./pairing";
import { Context, Effect } from "effect";
export interface Interface {
    readonly issue: () => Effect.Effect<{
        readonly code: string;
        readonly expires_in: number;
    }>;
    readonly consume: (code: string) => Effect.Effect<boolean>;
}
declare const Service_base: Context.ServiceClass<Service, "@opencode/ServerPairing", Interface>;
export declare class Service extends Service_base {
}
export declare const node: import("@opencode/util/effect/layer-node").Provider<Service, never, import("@opencode/util/effect/layer-node").Tag<"global">>;
