import { Context, Layer } from "effect";
import type { ServerOptions } from "./options";
declare const Service_base: Context.ServiceClass<Service, "@opencode/server/ServerInfo", {
    readonly urls: () => ReadonlyArray<string>;
    readonly app: NonNullable<ServerOptions["app"]>;
    readonly paths: {
        readonly tmp: string;
    };
}>;
export declare class Service extends Service_base {
}
export declare function layer(urls: () => ReadonlyArray<string>, tmp: string, app?: ServerOptions["app"]): Layer.Layer<Service, never, never>;
export declare function connectionURLs(value: string, requestedHostname?: string): string[];
export * as ServerInfo from "./server-info";
