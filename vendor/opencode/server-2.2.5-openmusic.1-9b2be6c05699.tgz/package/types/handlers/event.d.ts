import { EventFeed } from "../event-feed";
export declare const EventHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.event">, never, EventFeed.Service | (import("@opencode/protocol/middleware/authorization").Authorization | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware)>;
