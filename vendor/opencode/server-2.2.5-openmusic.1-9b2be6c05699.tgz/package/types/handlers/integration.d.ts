import { Integration } from "@opencode/core/integration";
import { Effect } from "effect";
import { InvalidRequestError } from "@opencode/protocol/errors";
import { WellKnown } from "@opencode/core/wellknown";
import { Config } from "@opencode/core/config";
export declare const requireConnectable: (integrationID: string & import("effect/Brand").Brand<"Integration.ID">) => Effect.Effect<undefined, InvalidRequestError, Integration.Service | Config.Service>;
export declare const IntegrationHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.integration">, never, import("@opencode/protocol/middleware/authorization").Authorization | import("../location").LocationMiddleware | import("effect/http/HttpRouter").Request<"Requires", WellKnown.Service> | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware>;
