import { Credential } from "@opencode/core/credential";
import { LocationServiceMap } from "@opencode/core/location-services";
import { Global } from "@opencode/util/global";
export declare const CredentialHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.credential">, never, Global.Service | LocationServiceMap.Service | (import("@opencode/protocol/middleware/authorization").Authorization | import("effect/http/HttpRouter").Request<"Requires", Credential.Service> | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware)>;
