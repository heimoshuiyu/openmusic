import { Job } from "@opencode/core/job";
import { Session } from "@opencode/core/session";
import { Effect } from "effect";
/** `job.*` in the `server.experimental` group. */
export declare const makeJob: Effect.Effect<{
    list: (query: {
        readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
        readonly kind?: "image" | "shell" | "subagent" | undefined;
        readonly status?: "cancelled" | "completed" | "error" | "running" | undefined;
        readonly descendants?: boolean | undefined;
    }) => Effect.Effect<{
        data: ({
            readonly id: string;
            readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            readonly status: "cancelled" | "completed" | "error" | "running";
            readonly title?: string | undefined;
            readonly time: {
                readonly started: number;
                readonly completed?: number | undefined;
            };
            readonly kind: "shell";
            readonly shellID: string;
            readonly command: string;
        } | {
            readonly id: string;
            readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            readonly status: "cancelled" | "completed" | "error" | "running";
            readonly title?: string | undefined;
            readonly time: {
                readonly started: number;
                readonly completed?: number | undefined;
            };
            readonly kind: "subagent";
            readonly childSessionID: string & import("effect/Brand").Brand<"SessionID">;
            readonly agent: string;
            readonly description: string;
        } | {
            readonly id: string;
            readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            readonly status: "cancelled" | "completed" | "error" | "running";
            readonly title?: string | undefined;
            readonly time: {
                readonly started: number;
                readonly completed?: number | undefined;
            };
            readonly kind: "image";
            readonly path: string;
            readonly model: string;
        })[];
    }, import("@opencode/protocol/errors").SessionNotFoundError, never>;
}, never, Job.Service | Session.Service>;
