import { Instance } from "@opencode/core/instance/service";
import { Session } from "@opencode/core/session";
import { SessionTransfer } from "@opencode/core/session/transfer";
import { InstructionEntry } from "@opencode/core/session/instruction-entry";
export declare const SessionHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.session">, never, import("effect/http/HttpRouter").Request<"Requires", import("@opencode/core/database/database").Service> | InstructionEntry.Service | Session.Service | Instance.Service | SessionTransfer.Service | import("../middleware/session-location").SessionLocationMiddleware | (import("@opencode/protocol/middleware/authorization").Authorization | import("../middleware/form-location").FormLocationMiddleware | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware)>;
