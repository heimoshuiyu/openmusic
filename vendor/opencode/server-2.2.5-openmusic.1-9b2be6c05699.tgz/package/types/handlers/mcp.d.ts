import { LocationServiceMap } from "@opencode/core/location-service-map";
import { PtyTicket } from "@opencode/core/pty/ticket";
export declare const McpHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.mcp">, never, import("@opencode/protocol/middleware/authorization").Authorization | import("../location").LocationMiddleware | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware | LocationServiceMap.Service | PtyTicket.Service>;
