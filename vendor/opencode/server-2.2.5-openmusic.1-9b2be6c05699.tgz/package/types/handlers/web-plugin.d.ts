import { LocationServiceMap } from "@opencode/core/location-services";
import { Plugin } from "@opencode/core/plugin";
import { PtyTicket } from "@opencode/core/pty/ticket";
import { ForbiddenError, PluginNotFoundError } from "@opencode/protocol/errors";
import { Effect } from "effect";
import { type HttpServerRequest, HttpServerResponse } from "effect/http";
export declare const makeWebPlugin: Effect.Effect<{
    list: (request: HttpServerRequest.HttpServerRequest) => Effect.Effect<{
        id: Plugin.ID;
        revision: string;
        options: Plugin.GuiBundle["options"];
        ticket: string;
    }[], ForbiddenError | import("@opencode/protocol/errors").LocationNotFoundError, never>;
    module: (query: {
        id: Plugin.ID;
        revision: string;
        ticket: string;
    }, request: HttpServerRequest.HttpServerRequest) => Effect.Effect<HttpServerResponse.HttpServerResponse, ForbiddenError | import("@opencode/protocol/errors").LocationNotFoundError | PluginNotFoundError, never>;
}, never, LocationServiceMap.Service | PtyTicket.Service>;
