import { Project } from "@opencode/core/project";
import { Bus } from "@opencode/core/bus";
import { LocationServiceMap } from "@opencode/core/location-services";
export declare const VcsHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.vcs">, never, import("@opencode/protocol/middleware/authorization").Authorization | import("../location").LocationMiddleware | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware | LocationServiceMap.Service | Bus.Service | Project.Service>;
