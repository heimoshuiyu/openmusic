import { Global } from "@opencode/util/global";
export declare const DebugHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.debug">, never, Global.Service | (import("@opencode/protocol/middleware/authorization").Authorization | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware)>;
