import { Session } from "@opencode/core/session";
import type { Snapshot } from "@opencode/core/snapshot";
import { MessageNotFoundError, SessionNotFoundError, UnknownError } from "@opencode/protocol/errors";
import { Effect } from "effect";
export declare function missingSession(error: Session.NotFoundError): SessionNotFoundError;
export declare function missingMessage(error: Session.MessageNotFoundError): MessageNotFoundError;
export declare function failedMessageDecode(error: Session.MessageDecodeError): Effect.Effect<never, UnknownError, never>;
/** Snapshot repositories are host state clients cannot repair, so surface only a log reference. */
export declare function failedSnapshot(operation: string, sessionID: Session.ID): (error: Snapshot.Error) => Effect.Effect<never, UnknownError, never>;
