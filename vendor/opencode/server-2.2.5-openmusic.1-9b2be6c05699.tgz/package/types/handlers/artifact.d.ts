import { Artifact } from "@opencode/core/artifact";
import { KV } from "@opencode/core/kv";
import { Location } from "@opencode/core/location";
import { LocationServiceMap } from "@opencode/core/location-service-map";
import { Session } from "@opencode/core/session";
import { Effect } from "effect";
import { type HttpServerRequest, HttpServerResponse } from "effect/http";
/** `artifacts.*` in the `server.experimental` group. Every route needs experimental.artifacts in the resolved Location. */
export declare const makeArtifact: Effect.Effect<{
    providers: (query: {
        readonly location?: {
            readonly directory?: string;
        };
    }, request: HttpServerRequest.HttpServerRequest) => Effect.Effect<{
        location: Location.Info;
        data: readonly Artifact.Provider[];
    }, never, never>;
    list: (query: {
        readonly location?: {
            readonly directory?: string;
        };
        readonly sessionID?: Session.ID;
        readonly provider?: Artifact.ProviderID;
    }, request: HttpServerRequest.HttpServerRequest) => Effect.Effect<{
        location: Location.Info;
        data: readonly Artifact.Info[];
    }, never, never>;
    create: (query: {
        readonly location?: {
            readonly directory?: string;
        };
    }, payload: Artifact.CreateInput, request: HttpServerRequest.HttpServerRequest) => Effect.Effect<{
        location: Location.Info;
        data: Artifact.Info;
    }, never, never>;
    get: (artifactID: Artifact.ID, query: {
        readonly location?: {
            readonly directory?: string;
        };
    }, request: HttpServerRequest.HttpServerRequest) => Effect.Effect<{
        location: Location.Info;
        data: Artifact.Content;
    }, never, never>;
    update: (artifactID: Artifact.ID, query: {
        readonly location?: {
            readonly directory?: string;
        };
    }, payload: Artifact.UpdateInput, request: HttpServerRequest.HttpServerRequest) => Effect.Effect<{
        location: Location.Info;
        data: Artifact.Info;
    }, never, never>;
    remove: (artifactID: Artifact.ID, query: {
        readonly location?: {
            readonly directory?: string;
        };
    }, request: HttpServerRequest.HttpServerRequest) => Effect.Effect<void, never, never>;
    view: (artifactID: Artifact.ID, query: {
        readonly location?: {
            readonly directory?: string;
        };
    }, request: HttpServerRequest.HttpServerRequest) => Effect.Effect<HttpServerResponse.HttpServerResponse, never, never>;
}, never, KV.Service | LocationServiceMap.Service | Session.Service>;
