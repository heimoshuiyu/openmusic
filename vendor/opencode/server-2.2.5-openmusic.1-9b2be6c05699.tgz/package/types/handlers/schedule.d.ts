import { Schedule } from "@opencode/core/schedule";
import type { Session } from "@opencode/core/session";
import { ForbiddenError, InvalidRequestError, ScheduleNotFoundError } from "@opencode/protocol/errors";
import type { CreatePayload } from "@opencode/protocol/groups/schedule";
import { Effect } from "effect";
/** `schedule.*` in the `server.experimental` group. Every route needs experimental.schedules where the Session lives. */
export declare const makeSchedule: Effect.Effect<{
    create: (payload: CreatePayload) => Effect.Effect<{
        data: {
            readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
            readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
            readonly name?: string | undefined;
            readonly when: {
                readonly tz?: string | undefined;
                readonly type: "in";
                readonly in: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "at";
                readonly at: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "every";
                readonly every: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "cron";
                readonly cron: string;
            };
            readonly tz: string;
            readonly if?: {
                readonly type: "code";
                readonly code: string;
            } | {
                readonly type: "shell";
                readonly run: string;
                readonly is?: string | undefined;
                readonly matches?: string | undefined;
                readonly changes?: boolean | undefined;
            } | undefined;
            readonly until?: {
                readonly type: "code";
                readonly code: string;
            } | {
                readonly type: "shell";
                readonly run: string;
                readonly is?: string | undefined;
                readonly matches?: string | undefined;
                readonly changes?: boolean | undefined;
            } | undefined;
            readonly action: {
                readonly type: "prompt";
                readonly prompt: string;
            };
            readonly status: "active" | "done" | "paused";
            readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
            readonly endsAt?: import("effect/DateTime").Utc | undefined;
            readonly remainingRuns?: number | undefined;
            readonly runCount: number;
            readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
            readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
            readonly lastOutput?: string | undefined;
            readonly time: {
                readonly created: import("effect/DateTime").Utc;
                readonly updated: import("effect/DateTime").Utc;
            };
        };
    }, ForbiddenError | InvalidRequestError | import("@opencode/protocol/errors").SessionNotFoundError, never>;
    list: (sessionID: Session.ID) => Effect.Effect<{
        data: {
            readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
            readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
            readonly name?: string | undefined;
            readonly when: {
                readonly tz?: string | undefined;
                readonly type: "in";
                readonly in: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "at";
                readonly at: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "every";
                readonly every: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "cron";
                readonly cron: string;
            };
            readonly tz: string;
            readonly if?: {
                readonly type: "code";
                readonly code: string;
            } | {
                readonly type: "shell";
                readonly run: string;
                readonly is?: string | undefined;
                readonly matches?: string | undefined;
                readonly changes?: boolean | undefined;
            } | undefined;
            readonly until?: {
                readonly type: "code";
                readonly code: string;
            } | {
                readonly type: "shell";
                readonly run: string;
                readonly is?: string | undefined;
                readonly matches?: string | undefined;
                readonly changes?: boolean | undefined;
            } | undefined;
            readonly action: {
                readonly type: "prompt";
                readonly prompt: string;
            };
            readonly status: "active" | "done" | "paused";
            readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
            readonly endsAt?: import("effect/DateTime").Utc | undefined;
            readonly remainingRuns?: number | undefined;
            readonly runCount: number;
            readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
            readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
            readonly lastOutput?: string | undefined;
            readonly time: {
                readonly created: import("effect/DateTime").Utc;
                readonly updated: import("effect/DateTime").Utc;
            };
        }[];
    }, ForbiddenError | import("@opencode/protocol/errors").SessionNotFoundError, never>;
    get: (id: Schedule.ID) => Effect.Effect<{
        data: {
            readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
            readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
            readonly name?: string | undefined;
            readonly when: {
                readonly tz?: string | undefined;
                readonly type: "in";
                readonly in: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "at";
                readonly at: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "every";
                readonly every: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "cron";
                readonly cron: string;
            };
            readonly tz: string;
            readonly if?: {
                readonly type: "code";
                readonly code: string;
            } | {
                readonly type: "shell";
                readonly run: string;
                readonly is?: string | undefined;
                readonly matches?: string | undefined;
                readonly changes?: boolean | undefined;
            } | undefined;
            readonly until?: {
                readonly type: "code";
                readonly code: string;
            } | {
                readonly type: "shell";
                readonly run: string;
                readonly is?: string | undefined;
                readonly matches?: string | undefined;
                readonly changes?: boolean | undefined;
            } | undefined;
            readonly action: {
                readonly type: "prompt";
                readonly prompt: string;
            };
            readonly status: "active" | "done" | "paused";
            readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
            readonly endsAt?: import("effect/DateTime").Utc | undefined;
            readonly remainingRuns?: number | undefined;
            readonly runCount: number;
            readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
            readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
            readonly lastOutput?: string | undefined;
            readonly time: {
                readonly created: import("effect/DateTime").Utc;
                readonly updated: import("effect/DateTime").Utc;
            };
        };
    }, ForbiddenError | ScheduleNotFoundError, never>;
    pause: (id: Schedule.ID) => Effect.Effect<{
        data: {
            readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
            readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
            readonly name?: string | undefined;
            readonly when: {
                readonly tz?: string | undefined;
                readonly type: "in";
                readonly in: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "at";
                readonly at: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "every";
                readonly every: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "cron";
                readonly cron: string;
            };
            readonly tz: string;
            readonly if?: {
                readonly type: "code";
                readonly code: string;
            } | {
                readonly type: "shell";
                readonly run: string;
                readonly is?: string | undefined;
                readonly matches?: string | undefined;
                readonly changes?: boolean | undefined;
            } | undefined;
            readonly until?: {
                readonly type: "code";
                readonly code: string;
            } | {
                readonly type: "shell";
                readonly run: string;
                readonly is?: string | undefined;
                readonly matches?: string | undefined;
                readonly changes?: boolean | undefined;
            } | undefined;
            readonly action: {
                readonly type: "prompt";
                readonly prompt: string;
            };
            readonly status: "active" | "done" | "paused";
            readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
            readonly endsAt?: import("effect/DateTime").Utc | undefined;
            readonly remainingRuns?: number | undefined;
            readonly runCount: number;
            readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
            readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
            readonly lastOutput?: string | undefined;
            readonly time: {
                readonly created: import("effect/DateTime").Utc;
                readonly updated: import("effect/DateTime").Utc;
            };
        };
    }, ForbiddenError | ScheduleNotFoundError, never>;
    resume: (id: Schedule.ID) => Effect.Effect<{
        data: {
            readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
            readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
            readonly name?: string | undefined;
            readonly when: {
                readonly tz?: string | undefined;
                readonly type: "in";
                readonly in: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "at";
                readonly at: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "every";
                readonly every: string;
            } | {
                readonly tz?: string | undefined;
                readonly type: "cron";
                readonly cron: string;
            };
            readonly tz: string;
            readonly if?: {
                readonly type: "code";
                readonly code: string;
            } | {
                readonly type: "shell";
                readonly run: string;
                readonly is?: string | undefined;
                readonly matches?: string | undefined;
                readonly changes?: boolean | undefined;
            } | undefined;
            readonly until?: {
                readonly type: "code";
                readonly code: string;
            } | {
                readonly type: "shell";
                readonly run: string;
                readonly is?: string | undefined;
                readonly matches?: string | undefined;
                readonly changes?: boolean | undefined;
            } | undefined;
            readonly action: {
                readonly type: "prompt";
                readonly prompt: string;
            };
            readonly status: "active" | "done" | "paused";
            readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
            readonly endsAt?: import("effect/DateTime").Utc | undefined;
            readonly remainingRuns?: number | undefined;
            readonly runCount: number;
            readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
            readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
            readonly lastOutput?: string | undefined;
            readonly time: {
                readonly created: import("effect/DateTime").Utc;
                readonly updated: import("effect/DateTime").Utc;
            };
        };
    }, ForbiddenError | ScheduleNotFoundError, never>;
    remove: (id: Schedule.ID) => Effect.Effect<void, ForbiddenError | ScheduleNotFoundError, never>;
}, never, Schedule.Service>;
