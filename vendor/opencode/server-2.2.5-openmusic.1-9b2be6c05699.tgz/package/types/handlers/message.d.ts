import { Session } from "@opencode/core/session";
export declare const MessageHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.message">, never, Session.Service | (import("@opencode/protocol/middleware/authorization").Authorization | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware)>;
