import { Database } from "@opencode/core/database/database";
import { FileNotFoundError } from "@opencode/protocol/errors";
import { Effect } from "effect";
import { type HttpServerRequest, HttpServerResponse } from "effect/http";
/** `media.get` in the `server.experimental` group; serves only blobs a message or inbox item still references. */
export declare const makeMediaGet: Effect.Effect<(hash: string, request: HttpServerRequest.HttpServerRequest) => Effect.Effect<HttpServerResponse.HttpServerResponse, FileNotFoundError, never>, never, Database.Service>;
