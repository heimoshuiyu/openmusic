import { PtyTicket } from "@opencode/core/pty/ticket";
import { LocationServiceMap } from "@opencode/core/location-service-map";
export declare const PtyHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.pty">, never, import("../location").LocationMiddleware | LocationServiceMap.Service | PtyTicket.Service | (import("@opencode/protocol/middleware/authorization").Authorization | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware)>;
