import { ServerAuth } from "../auth";
import { ServerInfo } from "../server-info";
import { ServerPairing } from "../pairing";
export declare const ServerHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.server">, never, ServerAuth.Config | import("effect/http/HttpRouter").Request<"Requires", ServerInfo.Service> | ServerPairing.Service | (import("@opencode/protocol/middleware/authorization").Authorization | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware)>;
