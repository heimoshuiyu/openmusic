import { Instance } from "@opencode/core/instance/service";
import { PermissionSaved } from "@opencode/core/permission/saved";
import { Session } from "@opencode/core/session";
export declare const PermissionHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.permission">, never, import("@opencode/protocol/middleware/authorization").Authorization | import("../location").LocationMiddleware | import("effect/http/HttpRouter").Request<"Requires", PermissionSaved.Service> | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware | Session.Service | Instance.Service | import("../middleware/session-location").SessionLocationMiddleware>;
