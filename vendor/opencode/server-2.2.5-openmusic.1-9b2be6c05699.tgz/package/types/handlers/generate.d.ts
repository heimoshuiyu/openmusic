import { LocationServiceMap } from "@opencode/core/location-services";
import { Global } from "@opencode/util/global";
export declare const GenerateHandler: import("effect/Layer").Layer<import("effect/http-api/HttpApiGroup").Service<"server", "server.generate">, never, import("@opencode/protocol/middleware/authorization").Authorization | import("@opencode/protocol/middleware/schema-error").SchemaErrorMiddleware | Global.Service | LocationServiceMap.Service>;
