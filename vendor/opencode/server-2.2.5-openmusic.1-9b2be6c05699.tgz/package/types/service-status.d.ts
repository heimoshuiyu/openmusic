export * as Status from "./service-status";
import { Effect } from "effect";
export type State = {
    readonly type: "starting";
} | {
    readonly type: "ready";
} | {
    readonly type: "stopping";
} | {
    readonly type: "failed";
};
export interface Interface {
    readonly current: Effect.Effect<State>;
    readonly ready: Effect.Effect<void>;
    readonly fail: Effect.Effect<void>;
    readonly beginStopping: Effect.Effect<void>;
}
export declare const make: (options?: {
    readonly initial?: State;
} | undefined) => Effect.Effect<{
    current: Effect.Effect<State, never, never>;
    ready: Effect.Effect<void, never, never>;
    fail: Effect.Effect<void, never, never>;
    beginStopping: Effect.Effect<void, never, never>;
}, never, never>;
