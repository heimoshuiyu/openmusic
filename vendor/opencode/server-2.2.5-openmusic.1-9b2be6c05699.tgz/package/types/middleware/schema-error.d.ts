import { SchemaErrorMiddleware } from "@opencode/protocol/middleware/schema-error";
export { SchemaErrorMiddleware } from "@opencode/protocol/middleware/schema-error";
export declare const schemaErrorLayer: import("effect/Layer").Layer<SchemaErrorMiddleware, never, never>;
