import { Instance } from "@opencode/core/instance/service";
import { Session } from "@opencode/core/session";
import { Layer } from "effect";
import { HttpApiMiddleware } from "effect/http-api";
import { LocationNotFoundError, InvalidRequestError, SessionNotFoundError } from "@opencode/protocol/errors";
declare const SessionLocationMiddleware_base: HttpApiMiddleware.ServiceClass<SessionLocationMiddleware, "@opencode/HttpApiSessionLocation", {
    requires: never;
    provides: Instance.Services;
    error: readonly [typeof InvalidRequestError, typeof SessionNotFoundError, typeof LocationNotFoundError];
    clientError: never;
    requiredForClient: false;
    security: never;
}, HttpApiMiddleware.HttpApiMiddleware<Instance.Services, readonly [typeof InvalidRequestError, typeof SessionNotFoundError, typeof LocationNotFoundError], never>>;
export declare class SessionLocationMiddleware extends SessionLocationMiddleware_base {
}
export declare const sessionLocationLayer: Layer.Layer<SessionLocationMiddleware, never, Session.Service | Instance.Service>;
export {};
