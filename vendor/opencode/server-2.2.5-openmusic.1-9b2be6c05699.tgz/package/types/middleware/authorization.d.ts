import { ServerAuth } from "../auth";
import { Authorization } from "@opencode/protocol/middleware/authorization";
export { Authorization } from "@opencode/protocol/middleware/authorization";
import { Effect, Layer } from "effect";
import { HttpServerRequest, HttpServerResponse } from "effect/http";
export declare function unauthorizedResponse(request: HttpServerRequest.HttpServerRequest): HttpServerResponse.HttpServerResponse;
export declare function authorizedRequest(request: HttpServerRequest.HttpServerRequest, config: ServerAuth.Info): Effect.Effect<boolean, never, never>;
export declare const authorizationLayer: Layer.Layer<Authorization, never, ServerAuth.Config>;
