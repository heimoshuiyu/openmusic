import { Instance } from "@opencode/core/instance/service";
import { LocationServiceMap } from "@opencode/core/location-services";
import { Session } from "@opencode/core/session";
import { LocationNotFoundError, InvalidRequestError, SessionNotFoundError } from "@opencode/protocol/errors";
import { Layer } from "effect";
import { HttpApiMiddleware } from "effect/http-api";
declare const FormLocationMiddleware_base: HttpApiMiddleware.ServiceClass<FormLocationMiddleware, "@opencode/HttpApiFormLocation", {
    requires: never;
    provides: Instance.Services;
    error: readonly [typeof InvalidRequestError, typeof SessionNotFoundError, typeof LocationNotFoundError];
    clientError: never;
    requiredForClient: false;
    security: never;
}, HttpApiMiddleware.HttpApiMiddleware<Instance.Services, readonly [typeof InvalidRequestError, typeof SessionNotFoundError, typeof LocationNotFoundError], never>>;
export declare class FormLocationMiddleware extends FormLocationMiddleware_base {
}
export declare const formLocationLayer: Layer.Layer<FormLocationMiddleware, never, LocationServiceMap.Service | Session.Service | Instance.Service>;
export {};
