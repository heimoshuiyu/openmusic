import { LocationMiddleware } from "./location";
import { FormLocationMiddleware } from "./middleware/form-location";
import { SessionLocationMiddleware } from "./middleware/session-location";
export declare const Api: import("@opencode/protocol/api").Api<LocationMiddleware, import("effect/http-api/HttpApiMiddleware").HttpApiMiddleware<import("@opencode/core/instance").Services, readonly [typeof import("@opencode/protocol/errors").LocationNotFoundError], never>, FormLocationMiddleware, import("effect/http-api/HttpApiMiddleware").HttpApiMiddleware<import("@opencode/core/instance").Services, readonly [typeof import("@opencode/protocol/errors").InvalidRequestError, typeof import("@opencode/protocol/errors").SessionNotFoundError, typeof import("@opencode/protocol/errors").LocationNotFoundError], never>, SessionLocationMiddleware, import("effect/http-api/HttpApiMiddleware").HttpApiMiddleware<import("@opencode/core/instance").Services, readonly [typeof import("@opencode/protocol/errors").InvalidRequestError, typeof import("@opencode/protocol/errors").SessionNotFoundError, typeof import("@opencode/protocol/errors").LocationNotFoundError], never>, import("effect/http-api/HttpApiGroup").HttpApiGroup<"server.event", import("effect/http-api/HttpApiEndpoint").HttpApiEndpoint<"event.subscribe", "GET", "/api/event", never, import("effect/Schema").toCodecStringTree<import("effect/Schema").Struct<{
    readonly types: import("effect/Schema").optional<import("effect/Schema").ArrayEnsure<import("effect/Schema").Union<readonly [import("effect/Schema").Literals<readonly ("agent.updated" | "artifact.updated" | "command.updated" | "config.updated" | "credential.switched" | "credential.updated" | "filesystem.changed" | "form.cancelled" | "form.created" | "form.replied" | "installation.update-available" | "installation.updated" | "integration.updated" | "location.shutdown" | "mcp.resources.changed" | "mcp.status.changed" | "model.updated" | "models-dev.refreshed" | "permission.asked" | "permission.replied" | "persistent-pty.added" | "persistent-pty.removed" | "persistent-pty.updated" | "plugin.updated" | "project.updated" | "provider.updated" | "pty.created" | "pty.deleted" | "pty.exited" | "pty.updated" | "reference.updated" | "session.agent.selected" | "session.archived" | "session.compaction.delta" | "session.compaction.ended" | "session.compaction.failed" | "session.compaction.started" | "session.created" | "session.deleted" | "session.execution.failed" | "session.execution.interrupted" | "session.execution.started" | "session.execution.succeeded" | "session.forked" | "session.idle" | "session.inbox.cancelled" | "session.inbox.delivered" | "session.inbox.delivery.changed" | "session.inbox.enqueued" | "session.instructions.updated" | "session.metadata.updated" | "session.model.selected" | "session.moved" | "session.permissions" | "session.reasoning.delta" | "session.reasoning.ended" | "session.reasoning.started" | "session.renamed" | "session.retry.scheduled" | "session.revert.cleared" | "session.revert.committed" | "session.revert.staged" | "session.shell.ended" | "session.shell.started" | "session.skill.activated" | "session.status" | "session.step.ended" | "session.step.failed" | "session.step.started" | "session.step.streamed" | "session.synthetic" | "session.text.delta" | "session.text.ended" | "session.text.started" | "session.tool.called" | "session.tool.failed" | "session.tool.input.delta" | "session.tool.input.ended" | "session.tool.input.started" | "session.tool.progress" | "session.tool.success" | "session.unarchived" | "session.usage.updated" | "session.viewed" | "shell.created" | "shell.deleted" | "shell.exited" | "skill.updated" | "tui.command.execute" | "tui.prompt.append" | "tui.session.select" | "tui.toast.show" | "vcs.branch.updated" | "websearch.updated" | "worktree.resolved" | "worktree.updated")[]>, import("effect/Schema").TemplateLiteral<readonly ["rpc.", import("effect/Schema").String]>]>>>;
}>>, never, never, import("effect/http-api/HttpApiSchema").StreamSse<import("effect/http-api/HttpApiSchema").SseEventFromData<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"location.shutdown">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "location.shutdown";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"models-dev.refreshed">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "models-dev.refreshed";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"credential.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly integrationID: import("effect/Schema").brand<import("effect/Schema").String, "Integration.ID">;
        readonly credentialID: import("effect/Schema").brand<import("effect/Schema").String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        };
    }>;
}> & {
    type: "credential.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly integrationID: import("effect/Schema").brand<import("effect/Schema").String, "Integration.ID">;
        readonly credentialID: import("effect/Schema").brand<import("effect/Schema").String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"credential.switched">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly integrationID: import("effect/Schema").brand<import("effect/Schema").String, "Integration.ID">;
        readonly credentialID: import("effect/Schema").NullOr<import("effect/Schema").brand<import("effect/Schema").String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        }>;
    }>;
}> & {
    type: "credential.switched";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly integrationID: import("effect/Schema").brand<import("effect/Schema").String, "Integration.ID">;
        readonly credentialID: import("effect/Schema").NullOr<import("effect/Schema").brand<import("effect/Schema").String, "Credential.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Credential.ID">;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"integration.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "integration.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"provider.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "provider.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"model.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "model.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"agent.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "agent.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.created">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly projectID: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly location: import("effect/Schema").Struct<{
            readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
            readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly subpath: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>, never, never>;
        readonly parentID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly slug: import("effect/Schema").String;
        readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly agent: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">>, never, never>;
        readonly model: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>, never, never>;
        readonly permissions: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
            readonly action: import("effect/Schema").String;
            readonly resource: import("effect/Schema").String;
            readonly effect: import("effect/Schema").Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
            readonly action: import("effect/Schema").String;
            readonly resource: import("effect/Schema").String;
            readonly effect: import("effect/Schema").Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly version: import("effect/Schema").String;
    }>;
}> & {
    type: "session.created";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly projectID: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly location: import("effect/Schema").Struct<{
            readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
            readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly subpath: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>, never, never>;
        readonly parentID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        }>, never, never>;
        readonly slug: import("effect/Schema").String;
        readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly agent: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">>, never, never>;
        readonly model: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>, never, never>;
        readonly permissions: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
            readonly action: import("effect/Schema").String;
            readonly resource: import("effect/Schema").String;
            readonly effect: import("effect/Schema").Literals<readonly ["allow", "deny", "ask"]>;
        }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
            readonly action: import("effect/Schema").String;
            readonly resource: import("effect/Schema").String;
            readonly effect: import("effect/Schema").Literals<readonly ["allow", "deny", "ask"]>;
        }>>>, never, never>;
        readonly version: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.agent.selected">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly agent: import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">;
        readonly previous: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">>, never, never>;
    }>;
}> & {
    type: "session.agent.selected";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly agent: import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">;
        readonly previous: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.model.selected">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly model: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>;
}> & {
    type: "session.model.selected";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly model: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly previous: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.moved">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly location: import("effect/Schema").Struct<{
            readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
            readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>, never, never>;
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.moved";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly location: import("effect/Schema").Struct<{
            readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
            readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
            }>, never, never>;
        }>;
        readonly projectID: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly subpath: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>, never, never>;
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.renamed">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly title: import("effect/Schema").String;
    }>;
}> & {
    type: "session.renamed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly title: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.metadata.updated">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly metadata: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>;
    }>;
}> & {
    type: "session.metadata.updated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly metadata: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.permissions">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly permissions: import("effect/Schema").$Array<import("effect/Schema").Struct<{
            readonly action: import("effect/Schema").String;
            readonly resource: import("effect/Schema").String;
            readonly effect: import("effect/Schema").Literals<readonly ["allow", "deny", "ask"]>;
        }>>;
    }>;
}> & {
    type: "session.permissions";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly permissions: import("effect/Schema").$Array<import("effect/Schema").Struct<{
            readonly action: import("effect/Schema").String;
            readonly resource: import("effect/Schema").String;
            readonly effect: import("effect/Schema").Literals<readonly ["allow", "deny", "ask"]>;
        }>>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.viewed">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly idle: import("effect/Schema").Finite;
    }>;
}> & {
    type: "session.viewed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly idle: import("effect/Schema").Finite;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.archived">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.archived";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.unarchived">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.unarchived";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.usage.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly cost: import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>;
    }>;
}> & {
    type: "session.usage.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly cost: import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.deleted">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.deleted";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.forked">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly boundary: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"before">;
            readonly messageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"through">;
            readonly messageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>]>;
        readonly instructions: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").brand<import("effect/Schema").String, "Instruction.Key">, import("effect/Schema").brand<import("effect/Schema").String, "Instruction.Hash">>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").brand<import("effect/Schema").String, "Instruction.Key">, import("effect/Schema").brand<import("effect/Schema").String, "Instruction.Hash">>>, never, never>;
        readonly instructionEntries: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
            readonly key: import("effect/Schema").String;
            readonly value: import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>;
            readonly removed: import("effect/Schema").Boolean;
        }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
            readonly key: import("effect/Schema").String;
            readonly value: import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>;
            readonly removed: import("effect/Schema").Boolean;
        }>>>, never, never>;
    }>;
}> & {
    type: "session.forked";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly parentID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly boundary: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"before">;
            readonly messageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"through">;
            readonly messageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }>]>;
        readonly instructions: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").brand<import("effect/Schema").String, "Instruction.Key">, import("effect/Schema").brand<import("effect/Schema").String, "Instruction.Hash">>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").brand<import("effect/Schema").String, "Instruction.Key">, import("effect/Schema").brand<import("effect/Schema").String, "Instruction.Hash">>>, never, never>;
        readonly instructionEntries: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
            readonly key: import("effect/Schema").String;
            readonly value: import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>;
            readonly removed: import("effect/Schema").Boolean;
        }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
            readonly key: import("effect/Schema").String;
            readonly value: import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>;
            readonly removed: import("effect/Schema").Boolean;
        }>>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.inbox.delivered">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.inbox.delivered";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.inbox.enqueued">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly item: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"user">;
            readonly payload: import("effect/Schema").Struct<{
                readonly text: import("effect/Schema").String;
                readonly files: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly data: import("effect/Schema").String;
                    readonly mime: import("effect/Schema").String;
                    readonly source: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
                        readonly type: import("effect/Schema").Literal<"inline">;
                    }>, import("effect/Schema").Struct<{
                        readonly type: import("effect/Schema").Literal<"uri">;
                        readonly uri: import("effect/Schema").String;
                    }>]>;
                    readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly data: import("effect/Schema").String;
                    readonly mime: import("effect/Schema").String;
                    readonly source: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
                        readonly type: import("effect/Schema").Literal<"inline">;
                    }>, import("effect/Schema").Struct<{
                        readonly type: import("effect/Schema").Literal<"uri">;
                        readonly uri: import("effect/Schema").String;
                    }>]>;
                    readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>, never, never>;
                readonly agents: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly name: import("effect/Schema").String;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly name: import("effect/Schema").String;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly skills: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Skill.ID">;
                    readonly name: import("effect/Schema").brand<import("effect/Schema").String, "Skill.Name">;
                    readonly text: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Skill.ID">;
                    readonly name: import("effect/Schema").brand<import("effect/Schema").String, "Skill.Name">;
                    readonly text: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
            }>;
            readonly delivery: import("effect/Schema").Literals<readonly ["steer", "queue"]>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"synthetic">;
            readonly payload: import("effect/Schema").Struct<{
                readonly text: import("effect/Schema").String;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
            }>;
            readonly delivery: import("effect/Schema").Literals<readonly ["steer", "queue"]>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"compaction">;
            readonly payload: import("effect/Schema").Struct<{}>;
            readonly delivery: import("effect/Schema").Literals<readonly ["steer", "queue"]>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"move">;
            readonly payload: import("effect/Schema").Struct<{
                readonly location: import("effect/Schema").Struct<{
                    readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
                    readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>, never, never>;
                }>;
                readonly projectID: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly subpath: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>, never, never>;
            }>;
            readonly delivery: import("effect/Schema").Literals<readonly ["steer", "queue"]>;
        }>]>;
    }>;
}> & {
    type: "session.inbox.enqueued";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly item: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"user">;
            readonly payload: import("effect/Schema").Struct<{
                readonly text: import("effect/Schema").String;
                readonly files: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly data: import("effect/Schema").String;
                    readonly mime: import("effect/Schema").String;
                    readonly source: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
                        readonly type: import("effect/Schema").Literal<"inline">;
                    }>, import("effect/Schema").Struct<{
                        readonly type: import("effect/Schema").Literal<"uri">;
                        readonly uri: import("effect/Schema").String;
                    }>]>;
                    readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly data: import("effect/Schema").String;
                    readonly mime: import("effect/Schema").String;
                    readonly source: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
                        readonly type: import("effect/Schema").Literal<"inline">;
                    }>, import("effect/Schema").Struct<{
                        readonly type: import("effect/Schema").Literal<"uri">;
                        readonly uri: import("effect/Schema").String;
                    }>]>;
                    readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }> & {
                    create: (input: import("@opencode/schema").FileAttachment) => {
                        readonly data: string;
                        readonly mime: string;
                        readonly source: {
                            readonly type: "inline";
                        } | {
                            readonly type: "uri";
                            readonly uri: string;
                        };
                        readonly name?: string | undefined;
                        readonly description?: string | undefined;
                        readonly mention?: {
                            readonly start: number;
                            readonly end: number;
                            readonly text: string;
                        } | undefined;
                    };
                }>>, never, never>;
                readonly agents: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly name: import("effect/Schema").String;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly name: import("effect/Schema").String;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly skills: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Skill.ID">;
                    readonly name: import("effect/Schema").brand<import("effect/Schema").String, "Skill.Name">;
                    readonly text: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Skill.ID">;
                    readonly name: import("effect/Schema").brand<import("effect/Schema").String, "Skill.Name">;
                    readonly text: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                    readonly mention: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                        readonly start: import("effect/Schema").Finite;
                        readonly end: import("effect/Schema").Finite;
                        readonly text: import("effect/Schema").String;
                    }>>, never, never>;
                }>>>, never, never>;
                readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
            }>;
            readonly delivery: import("effect/Schema").Literals<readonly ["steer", "queue"]>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"synthetic">;
            readonly payload: import("effect/Schema").Struct<{
                readonly text: import("effect/Schema").String;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
            }>;
            readonly delivery: import("effect/Schema").Literals<readonly ["steer", "queue"]>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"compaction">;
            readonly payload: import("effect/Schema").Struct<{}>;
            readonly delivery: import("effect/Schema").Literals<readonly ["steer", "queue"]>;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").tag<"move">;
            readonly payload: import("effect/Schema").Struct<{
                readonly location: import("effect/Schema").Struct<{
                    readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
                    readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
                        ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
                        create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
                    }>, never, never>;
                }>;
                readonly projectID: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
                    global: string & import("effect/Brand").Brand<"Project.ID">;
                };
                readonly subpath: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>, never, never>;
            }>;
            readonly delivery: import("effect/Schema").Literals<readonly ["steer", "queue"]>;
        }>]>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.inbox.cancelled">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.inbox.cancelled";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        inboxID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.inbox.delivery.changed">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly delivery: import("effect/Schema").Literals<readonly ["steer", "queue"]>;
    }>;
}> & {
    type: "session.inbox.delivery.changed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly inboxID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly delivery: import("effect/Schema").Literals<readonly ["steer", "queue"]>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.execution.started">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.execution.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.execution.succeeded">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.execution.succeeded";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.execution.failed">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly error: import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").String;
            readonly message: import("effect/Schema").String;
            readonly status: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly response: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>, never, never>;
            readonly retryAfterMs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
    }>;
}> & {
    type: "session.execution.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly error: import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").String;
            readonly message: import("effect/Schema").String;
            readonly status: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly response: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>, never, never>;
            readonly retryAfterMs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.execution.interrupted">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: import("effect/Schema").Literals<readonly ["user", "shutdown", "superseded", "inactivity"]>;
    }>;
}> & {
    type: "session.execution.interrupted";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: import("effect/Schema").Literals<readonly ["user", "shutdown", "superseded", "inactivity"]>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.instructions.updated">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly delta: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Union<readonly [import("effect/Schema").brand<import("effect/Schema").String, "Instruction.Hash">, import("effect/Schema").Literal<"removed">]>>;
        readonly text: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
    }>;
}> & {
    type: "session.instructions.updated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly delta: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Union<readonly [import("effect/Schema").brand<import("effect/Schema").String, "Instruction.Hash">, import("effect/Schema").Literal<"removed">]>>;
        readonly text: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.synthetic">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: import("effect/Schema").String;
        readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}> & {
    type: "session.synthetic";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: import("effect/Schema").String;
        readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.skill.activated">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Skill.ID">;
        readonly name: import("effect/Schema").brand<import("effect/Schema").String, "Skill.Name">;
        readonly text: import("effect/Schema").String;
    }>;
}> & {
    type: "session.skill.activated";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Skill.ID">;
        readonly name: import("effect/Schema").brand<import("effect/Schema").String, "Skill.Name">;
        readonly text: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.shell.started">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: import("effect/Schema").String;
            readonly cwd: import("effect/Schema").String;
            readonly shell: import("effect/Schema").String;
            readonly file: import("effect/Schema").String;
            readonly pid: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly exit: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            readonly signal: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly metadata: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>;
            readonly time: import("effect/Schema").Struct<{
                readonly started: import("effect/Schema").Finite;
                readonly completed: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            }>;
        }>;
    }>;
}> & {
    type: "session.shell.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: import("effect/Schema").String;
            readonly cwd: import("effect/Schema").String;
            readonly shell: import("effect/Schema").String;
            readonly file: import("effect/Schema").String;
            readonly pid: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly exit: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            readonly signal: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly metadata: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>;
            readonly time: import("effect/Schema").Struct<{
                readonly started: import("effect/Schema").Finite;
                readonly completed: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            }>;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.shell.ended">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: import("effect/Schema").String;
            readonly cwd: import("effect/Schema").String;
            readonly shell: import("effect/Schema").String;
            readonly file: import("effect/Schema").String;
            readonly pid: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly exit: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            readonly signal: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly metadata: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>;
            readonly time: import("effect/Schema").Struct<{
                readonly started: import("effect/Schema").Finite;
                readonly completed: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            }>;
        }>;
        readonly output: import("effect/Schema").Struct<{
            readonly output: import("effect/Schema").String;
            readonly cursor: import("effect/Schema").Int;
            readonly size: import("effect/Schema").Int;
            readonly truncated: import("effect/Schema").Boolean;
        }>;
    }>;
}> & {
    type: "session.shell.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly shell: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: import("effect/Schema").String;
            readonly cwd: import("effect/Schema").String;
            readonly shell: import("effect/Schema").String;
            readonly file: import("effect/Schema").String;
            readonly pid: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly exit: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            readonly signal: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly metadata: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>;
            readonly time: import("effect/Schema").Struct<{
                readonly started: import("effect/Schema").Finite;
                readonly completed: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            }>;
        }>;
        readonly output: import("effect/Schema").Struct<{
            readonly output: import("effect/Schema").String;
            readonly cursor: import("effect/Schema").Int;
            readonly size: import("effect/Schema").Int;
            readonly truncated: import("effect/Schema").Boolean;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.step.started">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly agent: import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">;
        readonly model: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly snapshot: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>, never, never>;
        readonly started: import("effect/Schema").Int;
    }>;
}> & {
    type: "session.step.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly agent: import("effect/Schema").brand<import("effect/Schema").String, "Agent.ID">;
        readonly model: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        };
        readonly snapshot: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>, never, never>;
        readonly started: import("effect/Schema").Int;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.step.streamed">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.step.streamed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.step.ended">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly finish: import("effect/Schema").Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly rawFinish: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
        readonly cost: import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>;
        readonly snapshot: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>, never, never>;
        readonly files: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>, never, never>;
    }>;
}> & {
    type: "session.step.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly finish: import("effect/Schema").Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly rawFinish: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
        readonly cost: import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        };
        readonly tokens: import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>;
        readonly snapshot: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>, never, never>;
        readonly files: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.step.failed">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly error: import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").String;
            readonly message: import("effect/Schema").String;
            readonly status: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly response: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>, never, never>;
            readonly retryAfterMs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
        readonly finish: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literals<readonly ["content-filter"]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literals<readonly ["content-filter"]>>, never, never>;
        readonly rawFinish: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
        readonly cost: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>, never, never>;
        readonly snapshot: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>, never, never>;
        readonly files: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>, never, never>;
    }>;
}> & {
    type: "session.step.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly error: import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").String;
            readonly message: import("effect/Schema").String;
            readonly status: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly response: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>, never, never>;
            readonly retryAfterMs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
        readonly finish: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literals<readonly ["content-filter"]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literals<readonly ["content-filter"]>>, never, never>;
        readonly rawFinish: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
        readonly cost: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>, never, never>;
        readonly snapshot: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>, never, never>;
        readonly files: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "RelativePath">>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.text.started">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
    }>;
}> & {
    type: "session.text.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.text.delta">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
        readonly delta: import("effect/Schema").String;
    }>;
}> & {
    type: "session.text.delta";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
        readonly delta: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.text.ended">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
        readonly text: import("effect/Schema").String;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}> & {
    type: "session.text.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
        readonly text: import("effect/Schema").String;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.reasoning.started">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}> & {
    type: "session.reasoning.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.reasoning.delta">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
        readonly delta: import("effect/Schema").String;
    }>;
}> & {
    type: "session.reasoning.delta";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
        readonly delta: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.reasoning.ended">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
        readonly text: import("effect/Schema").String;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}> & {
    type: "session.reasoning.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly ordinal: import("effect/Schema").Int;
        readonly text: import("effect/Schema").String;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.tool.input.started">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly name: import("effect/Schema").String;
    }>;
}> & {
    type: "session.tool.input.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly name: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.tool.input.delta">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly delta: import("effect/Schema").String;
    }>;
}> & {
    type: "session.tool.input.delta";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly delta: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.tool.input.ended">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly text: import("effect/Schema").String;
    }>;
}> & {
    type: "session.tool.input.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly text: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.tool.called">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly input: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>;
        readonly executed: import("effect/Schema").Boolean;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.called";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly input: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>;
        readonly executed: import("effect/Schema").Boolean;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.tool.progress">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly metadata: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>;
    }>;
}> & {
    type: "session.tool.progress";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly metadata: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.tool.success">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly content: import("effect/Schema").NonEmptyArray<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"text">;
            readonly text: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"file">;
            readonly uri: import("effect/Schema").String;
            readonly mime: import("effect/Schema").String;
            readonly name: import("effect/Schema").optional<import("effect/Schema").String>;
        }>]>>;
        readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>, never, never>;
        readonly executed: import("effect/Schema").Boolean;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.success";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly content: import("effect/Schema").NonEmptyArray<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"text">;
            readonly text: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"file">;
            readonly uri: import("effect/Schema").String;
            readonly mime: import("effect/Schema").String;
            readonly name: import("effect/Schema").optional<import("effect/Schema").String>;
        }>]>>;
        readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>, never, never>;
        readonly executed: import("effect/Schema").Boolean;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.tool.failed">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly error: import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").String;
            readonly message: import("effect/Schema").String;
            readonly status: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly response: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>, never, never>;
            readonly retryAfterMs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
        readonly content: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").NonEmptyArray<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"text">;
            readonly text: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"file">;
            readonly uri: import("effect/Schema").String;
            readonly mime: import("effect/Schema").String;
            readonly name: import("effect/Schema").optional<import("effect/Schema").String>;
        }>]>>>>, import("effect/Schema").optionalKey<import("effect/Schema").NonEmptyArray<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"text">;
            readonly text: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"file">;
            readonly uri: import("effect/Schema").String;
            readonly mime: import("effect/Schema").String;
            readonly name: import("effect/Schema").optional<import("effect/Schema").String>;
        }>]>>>, never, never>;
        readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>, never, never>;
        readonly executed: import("effect/Schema").Boolean;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}> & {
    type: "session.tool.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly id: import("effect/Schema").String;
        readonly error: import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").String;
            readonly message: import("effect/Schema").String;
            readonly status: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly response: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>, never, never>;
            readonly retryAfterMs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
        readonly content: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").NonEmptyArray<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"text">;
            readonly text: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"file">;
            readonly uri: import("effect/Schema").String;
            readonly mime: import("effect/Schema").String;
            readonly name: import("effect/Schema").optional<import("effect/Schema").String>;
        }>]>>>>, import("effect/Schema").optionalKey<import("effect/Schema").NonEmptyArray<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"text">;
            readonly text: import("effect/Schema").String;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"file">;
            readonly uri: import("effect/Schema").String;
            readonly mime: import("effect/Schema").String;
            readonly name: import("effect/Schema").optional<import("effect/Schema").String>;
        }>]>>>, never, never>;
        readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Codec<import("effect/Schema").Json, import("effect/Schema").Json, never, never>>>, never, never>;
        readonly executed: import("effect/Schema").Boolean;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.retry.scheduled">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly attempt: import("effect/Schema").Int;
        readonly at: import("effect/Schema").Int;
        readonly error: import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").String;
            readonly message: import("effect/Schema").String;
            readonly status: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly response: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>, never, never>;
            readonly retryAfterMs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
    }>;
}> & {
    type: "session.retry.scheduled";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly assistantMessageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly attempt: import("effect/Schema").Int;
        readonly at: import("effect/Schema").Int;
        readonly error: import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").String;
            readonly message: import("effect/Schema").String;
            readonly status: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly response: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>, never, never>;
            readonly retryAfterMs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.compaction.started">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: import("effect/Schema").Literals<readonly ["auto", "manual"]>;
        readonly inputID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
    }>;
}> & {
    type: "session.compaction.started";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: import("effect/Schema").Literals<readonly ["auto", "manual"]>;
        readonly inputID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.compaction.delta">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: import("effect/Schema").String;
    }>;
}> & {
    type: "session.compaction.delta";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly text: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.compaction.ended">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: import("effect/Schema").Literals<readonly ["auto", "manual"]>;
        readonly model: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
        readonly text: import("effect/Schema").String;
        readonly cost: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>, never, never>;
    }>;
}> & {
    type: "session.compaction.ended";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: import("effect/Schema").Literals<readonly ["auto", "manual"]>;
        readonly model: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Model.ID">;
            readonly providerID: import("effect/Schema").brand<import("effect/Schema").String, "Provider.ID"> & {
                opencode: string & import("effect/Brand").Brand<"Provider.ID">;
                anthropic: string & import("effect/Brand").Brand<"Provider.ID">;
                openai: string & import("effect/Brand").Brand<"Provider.ID">;
                google: string & import("effect/Brand").Brand<"Provider.ID">;
                googleVertex: string & import("effect/Brand").Brand<"Provider.ID">;
                githubCopilot: string & import("effect/Brand").Brand<"Provider.ID">;
                claudeAgent: string & import("effect/Brand").Brand<"Provider.ID">;
                amazonBedrock: string & import("effect/Brand").Brand<"Provider.ID">;
                azure: string & import("effect/Brand").Brand<"Provider.ID">;
                openrouter: string & import("effect/Brand").Brand<"Provider.ID">;
                mistral: string & import("effect/Brand").Brand<"Provider.ID">;
                gitlab: string & import("effect/Brand").Brand<"Provider.ID">;
            };
            readonly variant: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Model.VariantID">>, never, never>;
        }> & {
            parse: (input: string) => {
                readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
            };
        }>, never, never>;
        readonly native: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
        readonly text: import("effect/Schema").String;
        readonly cost: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.compaction.failed">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: import("effect/Schema").Literals<readonly ["auto", "manual"]>;
        readonly error: import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").String;
            readonly message: import("effect/Schema").String;
            readonly status: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly response: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>, never, never>;
            readonly retryAfterMs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
        readonly inputID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
        readonly cost: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>, never, never>;
    }>;
}> & {
    type: "session.compaction.failed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly reason: import("effect/Schema").Literals<readonly ["auto", "manual"]>;
        readonly error: import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").String;
            readonly message: import("effect/Schema").String;
            readonly status: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly response: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly body: import("effect/Schema").String;
            }>>, never, never>;
            readonly retryAfterMs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
        readonly inputID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        }>, never, never>;
        readonly cost: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").Finite, "Money.USD"> & {
            zero: number & import("effect/Brand").Brand<"Money.USD">;
        }>, never, never>;
        readonly tokens: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly input: import("effect/Schema").Finite;
            readonly output: import("effect/Schema").Finite;
            readonly reasoning: import("effect/Schema").Finite;
            readonly cache: import("effect/Schema").Struct<{
                readonly read: import("effect/Schema").Finite;
                readonly write: import("effect/Schema").Finite;
            }>;
        }>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.revert.staged">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly revert: import("effect/Schema").Struct<{
            readonly messageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly snapshot: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>, never, never>;
            readonly files: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                readonly file: import("effect/Schema").String;
                readonly patch: import("effect/Schema").String;
                readonly additions: import("effect/Schema").Int;
                readonly deletions: import("effect/Schema").Int;
                readonly status: import("effect/Schema").Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literal<true>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literal<true>>, never, never>;
            }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                readonly file: import("effect/Schema").String;
                readonly patch: import("effect/Schema").String;
                readonly additions: import("effect/Schema").Int;
                readonly deletions: import("effect/Schema").Int;
                readonly status: import("effect/Schema").Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literal<true>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literal<true>>, never, never>;
            }>>>, never, never>;
        }>;
    }>;
}> & {
    type: "session.revert.staged";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly revert: import("effect/Schema").Struct<{
            readonly messageID: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
                fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
            readonly partID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly snapshot: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Snapshot.ID">>, never, never>;
            readonly files: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                readonly file: import("effect/Schema").String;
                readonly patch: import("effect/Schema").String;
                readonly additions: import("effect/Schema").Int;
                readonly deletions: import("effect/Schema").Int;
                readonly status: import("effect/Schema").Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literal<true>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literal<true>>, never, never>;
            }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                readonly file: import("effect/Schema").String;
                readonly patch: import("effect/Schema").String;
                readonly additions: import("effect/Schema").Int;
                readonly deletions: import("effect/Schema").Int;
                readonly status: import("effect/Schema").Literals<readonly ["added", "deleted", "modified"]>;
                readonly more: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literal<true>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literal<true>>, never, never>;
            }>>>, never, never>;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.revert.cleared">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.revert.cleared";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.revert.committed">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly to: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}> & {
    type: "session.revert.committed";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly to: import("effect/Schema").brand<import("effect/Schema").String, "Session.Message.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Session.Message.ID">;
            fromEvent: (eventID: string) => string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"filesystem.changed">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly file: import("effect/Schema").String;
        readonly event: import("effect/Schema").Literals<readonly ["add", "change", "unlink"]>;
    }>;
}> & {
    type: "filesystem.changed";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly file: import("effect/Schema").String;
        readonly event: import("effect/Schema").Literals<readonly ["add", "change", "unlink"]>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"reference.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "reference.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"permission.asked">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly action: import("effect/Schema").String;
        readonly resources: import("effect/Schema").$Array<import("effect/Schema").String>;
        readonly save: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").String>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").String>>, never, never>;
        readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
        readonly source: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"tool">;
            readonly messageID: import("effect/Schema").String;
            readonly id: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"tool">;
            readonly messageID: import("effect/Schema").String;
            readonly id: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly message: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
    }>;
}> & {
    type: "permission.asked";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly action: import("effect/Schema").String;
        readonly resources: import("effect/Schema").$Array<import("effect/Schema").String>;
        readonly save: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").String>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").String>>, never, never>;
        readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
        readonly source: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"tool">;
            readonly messageID: import("effect/Schema").String;
            readonly id: import("effect/Schema").String;
        }>]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"tool">;
            readonly messageID: import("effect/Schema").String;
            readonly id: import("effect/Schema").String;
        }>]>>, never, never>;
        readonly message: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"permission.replied">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly requestID: import("effect/Schema").brand<import("effect/Schema").String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
        readonly reply: import("effect/Schema").Literals<readonly ["once", "always", "reject"]>;
    }>;
}> & {
    type: "permission.replied";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly requestID: import("effect/Schema").brand<import("effect/Schema").String, "Permission.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Permission.ID">;
        };
        readonly reply: import("effect/Schema").Literals<readonly ["once", "always", "reject"]>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"plugin.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "plugin.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"project.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly canonical: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly vcs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly icon: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly url: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly override: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly color: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly url: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly override: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly color: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        }>>, never, never>;
        readonly commands: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly start: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly start: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        }>>, never, never>;
        readonly time: import("effect/Schema").Struct<{
            readonly created: import("effect/Schema").Int;
            readonly updated: import("effect/Schema").Int;
            readonly active: import("effect/Schema").Int;
            readonly archived: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
        readonly sandboxes: import("effect/Schema").$Array<import("effect/Schema").String>;
    }>;
}> & {
    type: "project.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly canonical: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly vcs: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly name: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly icon: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly url: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly override: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly color: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly url: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly override: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly color: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        }>>, never, never>;
        readonly commands: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
            readonly start: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
            readonly start: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        }>>, never, never>;
        readonly time: import("effect/Schema").Struct<{
            readonly created: import("effect/Schema").Int;
            readonly updated: import("effect/Schema").Int;
            readonly active: import("effect/Schema").Int;
            readonly archived: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
        readonly sandboxes: import("effect/Schema").$Array<import("effect/Schema").String>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"worktree.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly projectID: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
    }>;
}> & {
    type: "worktree.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly projectID: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"worktree.resolved">;
    readonly durable: import("effect/Schema").Struct<{
        readonly aggregateID: import("effect/Schema").String;
        readonly seq: import("effect/Schema").brand<import("effect/Schema").Int, "Event.Seq">;
        readonly version: import("effect/Schema").decodeTo<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").Int, "Event.Version">>, import("effect/Schema").Literal<number>, never, never>;
    }>;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly projectID: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly previous: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly adopted: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, never, never>;
    }>;
}> & {
    type: "worktree.resolved";
    durability: "durable";
    durable: {
        readonly version: number;
        readonly aggregate: string;
    };
    data: import("effect/Schema").Struct<{
        readonly projectID: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly previous: import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        };
        readonly adopted: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").brand<import("effect/Schema").String, "Project.ID"> & {
            global: string & import("effect/Brand").Brand<"Project.ID">;
        }>>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"command.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "command.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"config.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "config.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"skill.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "skill.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"pty.created">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly info: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: import("effect/Schema").String;
            readonly command: import("effect/Schema").String;
            readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
            readonly cwd: import("effect/Schema").String;
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
            readonly pid: import("effect/Schema").Int;
            readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
    }>;
}> & {
    type: "pty.created";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly info: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: import("effect/Schema").String;
            readonly command: import("effect/Schema").String;
            readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
            readonly cwd: import("effect/Schema").String;
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
            readonly pid: import("effect/Schema").Int;
            readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"pty.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly info: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: import("effect/Schema").String;
            readonly command: import("effect/Schema").String;
            readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
            readonly cwd: import("effect/Schema").String;
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
            readonly pid: import("effect/Schema").Int;
            readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
    }>;
}> & {
    type: "pty.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly info: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: import("effect/Schema").String;
            readonly command: import("effect/Schema").String;
            readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
            readonly cwd: import("effect/Schema").String;
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
            readonly pid: import("effect/Schema").Int;
            readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"pty.exited">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly exitCode: import("effect/Schema").Int;
    }>;
}> & {
    type: "pty.exited";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
        readonly exitCode: import("effect/Schema").Int;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"pty.deleted">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}> & {
    type: "pty.deleted";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"persistent-pty.added">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: import("effect/Schema").String;
            readonly command: import("effect/Schema").String;
            readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
            readonly cwd: import("effect/Schema").String;
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
            readonly pid: import("effect/Schema").Int;
            readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: import("effect/Schema").NullOr<import("effect/Schema").String>;
            readonly foregroundProcess: import("effect/Schema").NullOr<import("effect/Schema").String>;
            readonly size: import("effect/Schema").Struct<{
                readonly cols: import("effect/Schema").Int;
                readonly rows: import("effect/Schema").Int;
            }>;
            readonly output: import("effect/Schema").Struct<{
                readonly head: import("effect/Schema").Int;
                readonly tail: import("effect/Schema").Int;
            }>;
        }>;
    }>;
}> & {
    type: "persistent-pty.added";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: import("effect/Schema").String;
            readonly command: import("effect/Schema").String;
            readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
            readonly cwd: import("effect/Schema").String;
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
            readonly pid: import("effect/Schema").Int;
            readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: import("effect/Schema").NullOr<import("effect/Schema").String>;
            readonly foregroundProcess: import("effect/Schema").NullOr<import("effect/Schema").String>;
            readonly size: import("effect/Schema").Struct<{
                readonly cols: import("effect/Schema").Int;
                readonly rows: import("effect/Schema").Int;
            }>;
            readonly output: import("effect/Schema").Struct<{
                readonly head: import("effect/Schema").Int;
                readonly tail: import("effect/Schema").Int;
            }>;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"persistent-pty.removed">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly ptyID: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}> & {
    type: "persistent-pty.removed";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly ptyID: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
            create: () => string & import("effect/Brand").Brand<"PtyID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"persistent-pty.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: import("effect/Schema").String;
            readonly command: import("effect/Schema").String;
            readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
            readonly cwd: import("effect/Schema").String;
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
            readonly pid: import("effect/Schema").Int;
            readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: import("effect/Schema").NullOr<import("effect/Schema").String>;
            readonly foregroundProcess: import("effect/Schema").NullOr<import("effect/Schema").String>;
            readonly size: import("effect/Schema").Struct<{
                readonly cols: import("effect/Schema").Int;
                readonly rows: import("effect/Schema").Int;
            }>;
            readonly output: import("effect/Schema").Struct<{
                readonly head: import("effect/Schema").Int;
                readonly tail: import("effect/Schema").Int;
            }>;
        }>;
    }>;
}> & {
    type: "persistent-pty.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly terminal: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "PtyID"> & {
                create: () => string & import("effect/Brand").Brand<"PtyID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"PtyID">;
            };
            readonly title: import("effect/Schema").String;
            readonly command: import("effect/Schema").String;
            readonly args: import("effect/Schema").$Array<import("effect/Schema").String>;
            readonly cwd: import("effect/Schema").String;
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited"]>;
            readonly pid: import("effect/Schema").Int;
            readonly exitCode: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
                create: () => string & import("effect/Brand").Brand<"SessionID">;
            };
            readonly userTitle: import("effect/Schema").NullOr<import("effect/Schema").String>;
            readonly foregroundProcess: import("effect/Schema").NullOr<import("effect/Schema").String>;
            readonly size: import("effect/Schema").Struct<{
                readonly cols: import("effect/Schema").Int;
                readonly rows: import("effect/Schema").Int;
            }>;
            readonly output: import("effect/Schema").Struct<{
                readonly head: import("effect/Schema").Int;
                readonly tail: import("effect/Schema").Int;
            }>;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"shell.created">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly info: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: import("effect/Schema").String;
            readonly cwd: import("effect/Schema").String;
            readonly shell: import("effect/Schema").String;
            readonly file: import("effect/Schema").String;
            readonly pid: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly exit: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            readonly signal: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly metadata: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>;
            readonly time: import("effect/Schema").Struct<{
                readonly started: import("effect/Schema").Finite;
                readonly completed: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            }>;
        }>;
    }>;
}> & {
    type: "shell.created";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly info: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Shell.ID"> & {
                create: () => string & import("effect/Brand").Brand<"Shell.ID">;
                ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
            };
            readonly status: import("effect/Schema").Literals<readonly ["running", "exited", "timeout", "killed"]>;
            readonly command: import("effect/Schema").String;
            readonly cwd: import("effect/Schema").String;
            readonly shell: import("effect/Schema").String;
            readonly file: import("effect/Schema").String;
            readonly pid: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
            readonly exit: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            readonly signal: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            readonly metadata: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>;
            readonly time: import("effect/Schema").Struct<{
                readonly started: import("effect/Schema").Finite;
                readonly completed: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
            }>;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"shell.exited">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly exit: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
        readonly status: import("effect/Schema").Literals<readonly ["running", "exited", "timeout", "killed"]>;
    }>;
}> & {
    type: "shell.exited";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
        readonly exit: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Finite>>, import("effect/Schema").optionalKey<import("effect/Schema").Finite>, never, never>;
        readonly status: import("effect/Schema").Literals<readonly ["running", "exited", "timeout", "killed"]>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"shell.deleted">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
    }>;
}> & {
    type: "shell.deleted";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Shell.ID"> & {
            create: () => string & import("effect/Brand").Brand<"Shell.ID">;
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Shell.ID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"form.created">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly form: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: import("effect/Schema").String;
            readonly title: import("effect/Schema").String;
            readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
            readonly fields: import("effect/Schema").NonEmptyArray<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly required: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly hidden: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly when: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>, never, never>;
                readonly type: import("effect/Schema").Literal<"string">;
                readonly format: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literals<readonly ["email", "uri", "date", "date-time"]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
                readonly maxLength: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
                readonly pattern: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly placeholder: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly default: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly options: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly value: import("effect/Schema").String;
                    readonly label: import("effect/Schema").String;
                    readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly value: import("effect/Schema").String;
                    readonly label: import("effect/Schema").String;
                    readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                }>>>, never, never>;
                readonly custom: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
            }>, import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly required: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly hidden: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly when: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>, never, never>;
                readonly type: import("effect/Schema").Literal<"number">;
                readonly minimum: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
                readonly maximum: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
                readonly default: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
            }>, import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly required: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly hidden: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly when: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>, never, never>;
                readonly type: import("effect/Schema").Literal<"integer">;
                readonly minimum: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
                readonly maximum: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
                readonly default: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
            }>, import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly required: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly hidden: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly when: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>, never, never>;
                readonly type: import("effect/Schema").Literal<"boolean">;
                readonly default: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
            }>, import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly required: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly hidden: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly when: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>, never, never>;
                readonly type: import("effect/Schema").Literal<"multiselect">;
                readonly options: import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly value: import("effect/Schema").String;
                    readonly label: import("effect/Schema").String;
                    readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                }>>;
                readonly minItems: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
                readonly maxItems: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
                readonly custom: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly default: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").String>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").String>>, never, never>;
            }>, import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly type: import("effect/Schema").Literal<"external">;
                readonly url: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            }>]>>;
        }>;
    }>;
}> & {
    type: "form.created";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly form: import("effect/Schema").Struct<{
            readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Form.ID"> & {
                create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
            };
            readonly sessionID: import("effect/Schema").String;
            readonly title: import("effect/Schema").String;
            readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
            readonly fields: import("effect/Schema").NonEmptyArray<import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly required: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly hidden: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly when: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>, never, never>;
                readonly type: import("effect/Schema").Literal<"string">;
                readonly format: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Literals<readonly ["email", "uri", "date", "date-time"]>>>, import("effect/Schema").optionalKey<import("effect/Schema").Literals<readonly ["email", "uri", "date", "date-time"]>>, never, never>;
                readonly minLength: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
                readonly maxLength: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
                readonly pattern: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly placeholder: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly default: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly options: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly value: import("effect/Schema").String;
                    readonly label: import("effect/Schema").String;
                    readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly value: import("effect/Schema").String;
                    readonly label: import("effect/Schema").String;
                    readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                }>>>, never, never>;
                readonly custom: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
            }>, import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly required: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly hidden: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly when: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>, never, never>;
                readonly type: import("effect/Schema").Literal<"number">;
                readonly minimum: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
                readonly maximum: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
                readonly default: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
            }>, import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly required: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly hidden: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly when: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>, never, never>;
                readonly type: import("effect/Schema").Literal<"integer">;
                readonly minimum: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
                readonly maximum: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
                readonly default: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Number>>, import("effect/Schema").optionalKey<import("effect/Schema").Number>, never, never>;
            }>, import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly required: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly hidden: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly when: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>, never, never>;
                readonly type: import("effect/Schema").Literal<"boolean">;
                readonly default: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
            }>, import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly required: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly hidden: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly when: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly key: import("effect/Schema").String;
                    readonly op: import("effect/Schema").Literals<readonly ["eq", "neq"]>;
                    readonly value: import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean]>;
                }>>>, never, never>;
                readonly type: import("effect/Schema").Literal<"multiselect">;
                readonly options: import("effect/Schema").$Array<import("effect/Schema").Struct<{
                    readonly value: import("effect/Schema").String;
                    readonly label: import("effect/Schema").String;
                    readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                }>>;
                readonly minItems: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
                readonly maxItems: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Int>>, import("effect/Schema").optionalKey<import("effect/Schema").Int>, never, never>;
                readonly custom: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Boolean>>, import("effect/Schema").optionalKey<import("effect/Schema").Boolean>, never, never>;
                readonly default: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Array<import("effect/Schema").String>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Array<import("effect/Schema").String>>, never, never>;
            }>, import("effect/Schema").Struct<{
                readonly key: import("effect/Schema").String;
                readonly type: import("effect/Schema").Literal<"external">;
                readonly url: import("effect/Schema").String;
                readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
                readonly description: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            }>]>>;
        }>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"form.replied">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: import("effect/Schema").String;
        readonly answer: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean, import("effect/Schema").$Array<import("effect/Schema").String>]>>;
    }>;
}> & {
    type: "form.replied";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: import("effect/Schema").String;
        readonly answer: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Union<readonly [import("effect/Schema").String, import("effect/Schema").Number, import("effect/Schema").Boolean, import("effect/Schema").$Array<import("effect/Schema").String>]>>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"form.cancelled">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: import("effect/Schema").String;
    }>;
}> & {
    type: "form.cancelled";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Form.ID"> & {
            create: (id?: string) => string & import("effect/Brand").Brand<"Form.ID">;
        };
        readonly sessionID: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"websearch.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "websearch.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"artifact.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{}>;
}> & {
    type: "artifact.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{}>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.status">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"idle">;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"retry">;
            readonly attempt: import("effect/Schema").Int;
            readonly message: import("effect/Schema").String;
            readonly action: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly reason: import("effect/Schema").String;
                readonly provider: import("effect/Schema").String;
                readonly title: import("effect/Schema").String;
                readonly message: import("effect/Schema").String;
                readonly label: import("effect/Schema").String;
                readonly link: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly reason: import("effect/Schema").String;
                readonly provider: import("effect/Schema").String;
                readonly title: import("effect/Schema").String;
                readonly message: import("effect/Schema").String;
                readonly label: import("effect/Schema").String;
                readonly link: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            }>>, never, never>;
            readonly next: import("effect/Schema").Int;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"busy">;
        }>]>;
    }>;
}> & {
    type: "session.status";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
        readonly status: import("effect/Schema").Union<readonly [import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"idle">;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"retry">;
            readonly attempt: import("effect/Schema").Int;
            readonly message: import("effect/Schema").String;
            readonly action: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
                readonly reason: import("effect/Schema").String;
                readonly provider: import("effect/Schema").String;
                readonly title: import("effect/Schema").String;
                readonly message: import("effect/Schema").String;
                readonly label: import("effect/Schema").String;
                readonly link: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
                readonly reason: import("effect/Schema").String;
                readonly provider: import("effect/Schema").String;
                readonly title: import("effect/Schema").String;
                readonly message: import("effect/Schema").String;
                readonly label: import("effect/Schema").String;
                readonly link: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
            }>>, never, never>;
            readonly next: import("effect/Schema").Int;
        }>, import("effect/Schema").Struct<{
            readonly type: import("effect/Schema").Literal<"busy">;
        }>]>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"session.idle">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}> & {
    type: "session.idle";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID"> & {
            create: () => string & import("effect/Brand").Brand<"SessionID">;
        };
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"tui.prompt.append">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly text: import("effect/Schema").String;
    }>;
}> & {
    type: "tui.prompt.append";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly text: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"tui.command.execute">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly command: import("effect/Schema").Union<readonly [import("effect/Schema").Literals<readonly ["session.list", "session.new", "session.interrupt", "session.background", "session.compact", "session.page.up", "session.page.down", "session.line.up", "session.line.down", "session.half.page.up", "session.half.page.down", "session.first", "session.last", "prompt.clear", "prompt.submit", "agent.cycle"]>, import("effect/Schema").String]>;
    }>;
}> & {
    type: "tui.command.execute";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly command: import("effect/Schema").Union<readonly [import("effect/Schema").Literals<readonly ["session.list", "session.new", "session.interrupt", "session.background", "session.compact", "session.page.up", "session.page.down", "session.line.up", "session.line.down", "session.half.page.up", "session.half.page.down", "session.first", "session.last", "prompt.clear", "prompt.submit", "agent.cycle"]>, import("effect/Schema").String]>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"tui.toast.show">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly message: import("effect/Schema").String;
        readonly variant: import("effect/Schema").Literals<readonly ["info", "success", "warning", "error"]>;
        readonly duration: import("effect/Schema").withDecodingDefault<import("effect/Schema").Int, never>;
    }>;
}> & {
    type: "tui.toast.show";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly title: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
        readonly message: import("effect/Schema").String;
        readonly variant: import("effect/Schema").Literals<readonly ["info", "success", "warning", "error"]>;
        readonly duration: import("effect/Schema").withDecodingDefault<import("effect/Schema").Int, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"tui.session.select">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID">;
    }>;
}> & {
    type: "tui.session.select";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly sessionID: import("effect/Schema").brand<import("effect/Schema").String, "SessionID">;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"installation.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly version: import("effect/Schema").String;
    }>;
}> & {
    type: "installation.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly version: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"installation.update-available">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly version: import("effect/Schema").String;
    }>;
}> & {
    type: "installation.update-available";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly version: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"vcs.branch.updated">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly branch: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
    }>;
}> & {
    type: "vcs.branch.updated";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly branch: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").String>>, import("effect/Schema").optionalKey<import("effect/Schema").String>, never, never>;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"mcp.status.changed">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly server: import("effect/Schema").String;
    }>;
}> & {
    type: "mcp.status.changed";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly server: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>>, import("effect/Schema").optionalKey<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>, never, never>;
    readonly type: import("effect/Schema").Literal<"mcp.resources.changed">;
    readonly location: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>>, import("effect/Schema").optionalKey<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
        readonly workspaceID: import("effect/Schema").decodeTo<import("effect/Schema").optional<import("effect/Schema").toType<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>>, import("effect/Schema").optionalKey<import("effect/Schema").brand<import("effect/Schema").String, "Workspace.ID"> & {
            ascending: (id?: string) => string & import("effect/Brand").Brand<"Workspace.ID">;
            create: () => string & import("effect/Brand").Brand<"Workspace.ID">;
        }>, never, never>;
    }>>, never, never>;
    readonly data: import("effect/Schema").Struct<{
        readonly server: import("effect/Schema").String;
    }>;
}> & {
    type: "mcp.resources.changed";
    durability: "ephemeral";
    durable: undefined;
    data: import("effect/Schema").Struct<{
        readonly server: import("effect/Schema").String;
    }>;
}, import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly created: import("effect/Schema").Finite;
    readonly metadata: import("effect/Schema").optional<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>;
    readonly type: import("effect/Schema").TemplateLiteral<readonly ["rpc.", import("effect/Schema").String]>;
    readonly location: import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
    }>;
    readonly data: import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>;
}>, ...import("effect/Schema").Struct<{
    readonly id: import("effect/Schema").brand<import("effect/Schema").String, "Event.ID"> & {
        create: () => string & import("effect/Brand").Brand<"Event.ID">;
    };
    readonly metadata: import("effect/Schema").optional<import("effect/Schema").$Record<import("effect/Schema").String, import("effect/Schema").Unknown>>;
    readonly location: import("effect/Schema").optional<import("effect/Schema").Struct<{
        readonly directory: import("effect/Schema").brand<import("effect/Schema").String, "AbsolutePath">;
    }>>;
    readonly type: import("effect/Schema").Literal<"server.connected">;
    readonly data: import("effect/Schema").Struct<{}>;
}>[]]>>, import("effect/Schema").Never, {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.agent.selected";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly agent: string & import("effect/Brand").Brand<"Agent.ID">;
        readonly previous?: (string & import("effect/Brand").Brand<"Agent.ID">) | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.archived";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "auto" | "manual";
        readonly model?: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        } | undefined;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
        readonly text: string;
        readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "auto" | "manual";
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly inputID?: (string & import("effect/Brand").Brand<"Session.Message.ID">) | undefined;
        readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "auto" | "manual";
        readonly inputID?: (string & import("effect/Brand").Brand<"Session.Message.ID">) | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.created";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
        readonly location: {
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
        };
        readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
        readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
        readonly slug: string;
        readonly title?: string | undefined;
        readonly agent?: (string & import("effect/Brand").Brand<"Agent.ID">) | undefined;
        readonly model?: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        } | undefined;
        readonly metadata?: {
            readonly [x: string]: import("effect/Schema").Json;
        } | undefined;
        readonly permissions?: readonly {
            readonly action: string;
            readonly resource: string;
            readonly effect: "allow" | "ask" | "deny";
        }[] | undefined;
        readonly version: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.deleted";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.interrupted";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly reason: "inactivity" | "shutdown" | "superseded" | "user";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.succeeded";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.forked";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly parentID: string & import("effect/Brand").Brand<"SessionID">;
        readonly boundary: {
            readonly type: "before";
            readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        } | {
            readonly type: "through";
            readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        };
        readonly instructions?: {
            readonly [x: string & import("effect/Brand").Brand<"Instruction.Key">]: string & import("effect/Brand").Brand<"Instruction.Hash">;
        } | undefined;
        readonly instructionEntries?: readonly {
            readonly key: string;
            readonly value: import("effect/Schema").Json;
            readonly removed: boolean;
        }[] | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.cancelled";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.delivered";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.delivery.changed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly delivery: "queue" | "steer";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.enqueued";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly item: {
            readonly type: "user";
            readonly payload: {
                readonly text: string;
                readonly files?: readonly {
                    readonly data: string;
                    readonly mime: string;
                    readonly source: {
                        readonly type: "inline";
                    } | {
                        readonly type: "uri";
                        readonly uri: string;
                    };
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                }[] | undefined;
                readonly agents?: readonly {
                    readonly name: string;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                }[] | undefined;
                readonly skills?: readonly {
                    readonly id: string & import("effect/Brand").Brand<"Skill.ID">;
                    readonly name: string & import("effect/Brand").Brand<"Skill.Name">;
                    readonly text?: string | undefined;
                    readonly mention?: {
                        readonly start: number;
                        readonly end: number;
                        readonly text: string;
                    } | undefined;
                }[] | undefined;
                readonly metadata?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
            readonly delivery: "queue" | "steer";
        } | {
            readonly type: "synthetic";
            readonly payload: {
                readonly text: string;
                readonly description?: string | undefined;
                readonly metadata?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
            readonly delivery: "queue" | "steer";
        } | {
            readonly type: "compaction";
            readonly payload: {};
            readonly delivery: "queue" | "steer";
        } | {
            readonly type: "move";
            readonly payload: {
                readonly location: {
                    readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                    readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
                };
                readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
                readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
            };
            readonly delivery: "queue" | "steer";
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.instructions.updated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly delta: {
            readonly [x: string]: "removed" | (string & import("effect/Brand").Brand<"Instruction.Hash">);
        };
        readonly text?: string | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.metadata.updated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly metadata: {
            readonly [x: string]: import("effect/Schema").Json;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.model.selected";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly model: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
        readonly previous?: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.moved";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly location: {
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
        };
        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
        readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.permissions";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly permissions: readonly {
            readonly action: string;
            readonly resource: string;
            readonly effect: "allow" | "ask" | "deny";
        }[];
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.reasoning.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly text: string;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.reasoning.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.renamed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly title: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.retry.scheduled";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly attempt: number;
        readonly at: number;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.cleared";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.committed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly to: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.staged";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly revert: {
            readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
            readonly partID?: string | undefined;
            readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
            readonly files?: readonly {
                readonly file: string;
                readonly patch: string;
                readonly additions: number;
                readonly deletions: number;
                readonly status: "added" | "deleted" | "modified";
                readonly more?: true | undefined;
            }[] | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.shell.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly shell: {
            readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
            readonly status: "exited" | "killed" | "running" | "timeout";
            readonly command: string;
            readonly cwd: string;
            readonly shell: string;
            readonly file: string;
            readonly pid?: number | undefined;
            readonly exit?: number | undefined;
            readonly signal?: string | undefined;
            readonly metadata: {
                readonly [x: string]: unknown;
            };
            readonly time: {
                readonly started: number;
                readonly completed?: number | undefined;
            };
        };
        readonly output: {
            readonly output: string;
            readonly cursor: number;
            readonly size: number;
            readonly truncated: boolean;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.shell.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly shell: {
            readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
            readonly status: "exited" | "killed" | "running" | "timeout";
            readonly command: string;
            readonly cwd: string;
            readonly shell: string;
            readonly file: string;
            readonly pid?: number | undefined;
            readonly exit?: number | undefined;
            readonly signal?: string | undefined;
            readonly metadata: {
                readonly [x: string]: unknown;
            };
            readonly time: {
                readonly started: number;
                readonly completed?: number | undefined;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.skill.activated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly id: string & import("effect/Brand").Brand<"Skill.ID">;
        readonly name: string & import("effect/Brand").Brand<"Skill.Name">;
        readonly text: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly finish: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly rawFinish?: string | undefined;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
        readonly cost: number & import("effect/Brand").Brand<"Money.USD">;
        readonly tokens: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        };
        readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
        readonly files?: readonly (string & import("effect/Brand").Brand<"RelativePath">)[] | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly finish?: "content-filter" | undefined;
        readonly rawFinish?: string | undefined;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
        readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
        readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
        readonly files?: readonly (string & import("effect/Brand").Brand<"RelativePath">)[] | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly agent: string & import("effect/Brand").Brand<"Agent.ID">;
        readonly model: {
            readonly id: string & import("effect/Brand").Brand<"Model.ID">;
            readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
            readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
        };
        readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
        readonly started: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.streamed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.synthetic";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly text: string;
        readonly description?: string | undefined;
        readonly metadata?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.text.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly text: string;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.text.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.called";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly input: {
            readonly [x: string]: unknown;
        };
        readonly executed: boolean;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly content?: readonly [{
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        }, ...({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[]] | undefined;
        readonly metadata?: {
            readonly [x: string]: import("effect/Schema").Json;
        } | undefined;
        readonly executed: boolean;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.input.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly text: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.input.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly name: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.success";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly content: readonly [{
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        }, ...({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[]];
        readonly metadata?: {
            readonly [x: string]: import("effect/Schema").Json;
        } | undefined;
        readonly executed: boolean;
        readonly native?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.unarchived";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.viewed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly idle: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "worktree.resolved";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
        readonly version: number & import("effect/Brand").Brand<"Event.Version">;
    };
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly previous: string & import("effect/Brand").Brand<"Project.ID">;
        readonly adopted?: readonly (string & import("effect/Brand").Brand<"Project.ID">)[] | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "agent.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "artifact.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "command.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "config.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "credential.switched";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly integrationID: string & import("effect/Brand").Brand<"Integration.ID">;
        readonly credentialID: (string & import("effect/Brand").Brand<"Credential.ID">) | null;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "credential.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly integrationID: string & import("effect/Brand").Brand<"Integration.ID">;
        readonly credentialID: string & import("effect/Brand").Brand<"Credential.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "filesystem.changed";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly file: string;
        readonly event: "add" | "change" | "unlink";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "form.cancelled";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"Form.ID">;
        readonly sessionID: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "form.created";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly form: {
            readonly id: string & import("effect/Brand").Brand<"Form.ID">;
            readonly sessionID: string;
            readonly title: string;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly fields: readonly [{
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "string";
                readonly format?: "date" | "date-time" | "email" | "uri" | undefined;
                readonly minLength?: number | undefined;
                readonly maxLength?: number | undefined;
                readonly pattern?: string | undefined;
                readonly placeholder?: string | undefined;
                readonly default?: string | undefined;
                readonly options?: readonly {
                    readonly value: string;
                    readonly label: string;
                    readonly description?: string | undefined;
                }[] | undefined;
                readonly custom?: boolean | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "number";
                readonly minimum?: number | undefined;
                readonly maximum?: number | undefined;
                readonly default?: number | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "integer";
                readonly minimum?: number | undefined;
                readonly maximum?: number | undefined;
                readonly default?: number | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "boolean";
                readonly default?: boolean | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "multiselect";
                readonly options: readonly {
                    readonly value: string;
                    readonly label: string;
                    readonly description?: string | undefined;
                }[];
                readonly minItems?: number | undefined;
                readonly maxItems?: number | undefined;
                readonly custom?: boolean | undefined;
                readonly default?: readonly string[] | undefined;
            } | {
                readonly key: string;
                readonly type: "external";
                readonly url: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
            }, ...({
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "string";
                readonly format?: "date" | "date-time" | "email" | "uri" | undefined;
                readonly minLength?: number | undefined;
                readonly maxLength?: number | undefined;
                readonly pattern?: string | undefined;
                readonly placeholder?: string | undefined;
                readonly default?: string | undefined;
                readonly options?: readonly {
                    readonly value: string;
                    readonly label: string;
                    readonly description?: string | undefined;
                }[] | undefined;
                readonly custom?: boolean | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "number";
                readonly minimum?: number | undefined;
                readonly maximum?: number | undefined;
                readonly default?: number | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "integer";
                readonly minimum?: number | undefined;
                readonly maximum?: number | undefined;
                readonly default?: number | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "boolean";
                readonly default?: boolean | undefined;
            } | {
                readonly key: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
                readonly required?: boolean | undefined;
                readonly hidden?: boolean | undefined;
                readonly when?: readonly {
                    readonly key: string;
                    readonly op: "eq" | "neq";
                    readonly value: string | number | boolean;
                }[] | undefined;
                readonly type: "multiselect";
                readonly options: readonly {
                    readonly value: string;
                    readonly label: string;
                    readonly description?: string | undefined;
                }[];
                readonly minItems?: number | undefined;
                readonly maxItems?: number | undefined;
                readonly custom?: boolean | undefined;
                readonly default?: readonly string[] | undefined;
            } | {
                readonly key: string;
                readonly type: "external";
                readonly url: string;
                readonly title?: string | undefined;
                readonly description?: string | undefined;
            })[]];
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "form.replied";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"Form.ID">;
        readonly sessionID: string;
        readonly answer: {
            readonly [x: string]: string | number | boolean | readonly string[];
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "installation.update-available";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly version: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "installation.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly version: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "integration.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "location.shutdown";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "mcp.resources.changed";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly server: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "mcp.status.changed";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly server: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "model.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "models-dev.refreshed";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "permission.asked";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly action: string;
        readonly resources: readonly string[];
        readonly save?: readonly string[] | undefined;
        readonly metadata?: {
            readonly [x: string]: unknown;
        } | undefined;
        readonly source?: {
            readonly type: "tool";
            readonly messageID: string;
            readonly id: string;
        } | undefined;
        readonly message?: string | undefined;
        readonly id: string & import("effect/Brand").Brand<"Permission.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "permission.replied";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly requestID: string & import("effect/Brand").Brand<"Permission.ID">;
        readonly reply: "always" | "once" | "reject";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "persistent-pty.added";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly terminal: {
            readonly id: string & import("effect/Brand").Brand<"PtyID">;
            readonly title: string;
            readonly command: string;
            readonly args: readonly string[];
            readonly cwd: string;
            readonly status: "exited" | "running";
            readonly pid: number;
            readonly exitCode?: number | undefined;
            readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            readonly userTitle: string | null;
            readonly foregroundProcess: string | null;
            readonly size: {
                readonly cols: number;
                readonly rows: number;
            };
            readonly output: {
                readonly head: number;
                readonly tail: number;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "persistent-pty.removed";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly ptyID: string & import("effect/Brand").Brand<"PtyID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "persistent-pty.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly terminal: {
            readonly id: string & import("effect/Brand").Brand<"PtyID">;
            readonly title: string;
            readonly command: string;
            readonly args: readonly string[];
            readonly cwd: string;
            readonly status: "exited" | "running";
            readonly pid: number;
            readonly exitCode?: number | undefined;
            readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            readonly userTitle: string | null;
            readonly foregroundProcess: string | null;
            readonly size: {
                readonly cols: number;
                readonly rows: number;
            };
            readonly output: {
                readonly head: number;
                readonly tail: number;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "plugin.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "project.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"Project.ID">;
        readonly canonical: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly vcs?: string | undefined;
        readonly name?: string | undefined;
        readonly icon?: {
            readonly url?: string | undefined;
            readonly override?: string | undefined;
            readonly color?: string | undefined;
        } | undefined;
        readonly commands?: {
            readonly start?: string | undefined;
        } | undefined;
        readonly time: {
            readonly created: number;
            readonly updated: number;
            readonly active: number;
            readonly archived?: number | undefined;
        };
        readonly sandboxes: readonly string[];
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "provider.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "pty.created";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly info: {
            readonly id: string & import("effect/Brand").Brand<"PtyID">;
            readonly title: string;
            readonly command: string;
            readonly args: readonly string[];
            readonly cwd: string;
            readonly status: "exited" | "running";
            readonly pid: number;
            readonly exitCode?: number | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "pty.deleted";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"PtyID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "pty.exited";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"PtyID">;
        readonly exitCode: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "pty.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly info: {
            readonly id: string & import("effect/Brand").Brand<"PtyID">;
            readonly title: string;
            readonly command: string;
            readonly args: readonly string[];
            readonly cwd: string;
            readonly status: "exited" | "running";
            readonly pid: number;
            readonly exitCode?: number | undefined;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "reference.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.delta";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly text: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.idle";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.reasoning.delta";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly delta: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.status";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly status: {
            readonly type: "idle";
        } | {
            readonly type: "busy";
        } | {
            readonly type: "retry";
            readonly attempt: number;
            readonly message: string;
            readonly action?: {
                readonly reason: string;
                readonly provider: string;
                readonly title: string;
                readonly message: string;
                readonly label: string;
                readonly link?: string | undefined;
            } | undefined;
            readonly next: number;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.text.delta";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly ordinal: number;
        readonly delta: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.input.delta";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly delta: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.progress";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
        readonly id: string;
        readonly metadata: {
            readonly [x: string]: import("effect/Schema").Json;
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.usage.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
        readonly cost: number & import("effect/Brand").Brand<"Money.USD">;
        readonly tokens: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "shell.created";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly info: {
            readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
            readonly status: "exited" | "killed" | "running" | "timeout";
            readonly command: string;
            readonly cwd: string;
            readonly shell: string;
            readonly file: string;
            readonly pid?: number | undefined;
            readonly exit?: number | undefined;
            readonly signal?: string | undefined;
            readonly metadata: {
                readonly [x: string]: unknown;
            };
            readonly time: {
                readonly started: number;
                readonly completed?: number | undefined;
            };
        };
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "shell.deleted";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "shell.exited";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
        readonly exit?: number | undefined;
        readonly status: "exited" | "killed" | "running" | "timeout";
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "skill.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "tui.command.execute";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly command: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "tui.prompt.append";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly text: string;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "tui.session.select";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "tui.toast.show";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly title?: string | undefined;
        readonly message: string;
        readonly variant: "error" | "info" | "success" | "warning";
        readonly duration: number;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "vcs.branch.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly branch?: string | undefined;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "websearch.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {};
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "worktree.updated";
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
        readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
    } | undefined;
    readonly data: {
        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: `rpc.${string}`;
    readonly location: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
    };
    readonly data: {
        readonly [x: string]: unknown;
    };
} | {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly location?: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
    } | undefined;
    readonly type: "server.connected";
    readonly data: {};
}>, never, never, never>, false>>;
