export * as ServerProcess from "./process";
import { Effect, Scope } from "effect";
import { HttpServerRequest, HttpServerResponse } from "effect/http";
import { NetAddress } from "effect/net";
export interface Lifecycle<E = never, R = never> {
    readonly onListen: (address: NetAddress.SocketAddress, shutdown: Effect.Effect<void>) => Effect.Effect<Effect.Effect<void>, E, R>;
}
type App = Effect.Effect<HttpServerResponse.HttpServerResponse, unknown, HttpServerRequest.HttpServerRequest | Scope.Scope>;
export type Transform = (app: App) => App;
export declare const start: <E, R>(options: {
    readonly app?: {
        readonly name?: string | undefined;
        readonly version?: string | undefined;
        readonly channel?: string | undefined;
    } | undefined;
    readonly hostname?: string | undefined;
    readonly port?: number | undefined;
    readonly password?: string | undefined;
    readonly cors?: readonly string[] | undefined;
    readonly simulation?: boolean | undefined;
    readonly database?: {
        readonly path?: string | undefined;
    } | undefined;
    readonly pty?: {
        readonly handoff?: {
            readonly directory: string;
            readonly instanceID: string;
            readonly ticket: string;
            readonly expiresAt: number;
        } | undefined;
        readonly root?: string | undefined;
    } | undefined;
    readonly events?: {
        readonly persist?: boolean | undefined;
    } | undefined;
    readonly models?: {
        readonly url?: string | undefined;
        readonly file?: string | undefined;
        readonly fetch?: boolean | undefined;
        readonly snapshot?: boolean | undefined;
    } | undefined;
    readonly fetch?: import("@opencode/util/effect/app-node-platform").Fetch | undefined;
    readonly config?: {
        readonly directory?: string | undefined;
        readonly project?: boolean | undefined;
        readonly claude?: boolean | undefined;
        readonly file?: string | undefined;
        readonly content?: string | undefined;
    } | undefined;
    readonly windows?: {
        readonly gitbash?: string | undefined;
    } | undefined;
    readonly fs?: {
        readonly filewatcher?: boolean | undefined;
        readonly fff?: boolean | undefined;
    } | undefined;
}, lifecycle?: Lifecycle<E, R> | undefined, transform?: Transform | undefined, remoteURLs?: (() => ReadonlyArray<string>) | undefined) => Effect.Effect<{
    address: NetAddress.SocketAddress;
    shutdown: Effect.Effect<void, never, never>;
    updateAvailable: (version: string) => Effect.Effect<void, never, never>;
    updated: (version: string) => Effect.Effect<void, never, never>;
}, E | Error, R | Scope.Scope>;
