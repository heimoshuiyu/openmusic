import type { OpenCode } from "./client.js"

type Client = ReturnType<typeof OpenCode.make>

export type { RpcApi, RpcCallOptions, RpcClient, RpcEventPayload } from "./rpc.js"
export type { SelectedEvent, SubscribeOptions } from "../shared-events.js"

export type AgentApi = Client["agent"]
export type CommandApi = Client["command"]
export type ConfigApi = Client["config"]
export type CredentialApi = Client["credential"]
export type EventApi = Client["event"]
/** @deprecated Use `ExperimentalGenerateApi`. Removed in the next minor. */
export type GenerateApi = Client["generate"]
export type ExperimentalGenerateApi = Client["experimental"]["generate"]
export type ExperimentalSessionApi = Client["experimental"]["session"]
export type IntegrationApi = Client["integration"]
export type McpApi = Client["mcp"]
export type ModelApi = Client["model"]
export type PluginApi = Client["plugin"]
export type PermissionApi = Client["permission"]
export type ProviderApi = Client["provider"]
export type ReferenceApi = Client["reference"]
export type WebSearchApi = Client["websearch"]
export type SessionApi = Client["session"]
export type SkillApi = Client["skill"]
export type VcsApi = Client["vcs"]
export type WorktreeApi = Client["worktree"]
