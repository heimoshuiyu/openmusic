import type {
  ServerInfoOutput,
  ServerPairOutput,
  ServerConnectInput,
  ServerConnectOutput,
  LocationGetInput,
  LocationGetOutput,
  LocationReloadOutput,
  AgentListInput,
  AgentListOutput,
  AgentGetInput,
  AgentGetOutput,
  PluginListInput,
  PluginListOutput,
  PluginGuiInput,
  PluginGuiOutput,
  PluginCheckInput,
  PluginCheckOutput,
  PluginUpdateInput,
  PluginUpdateOutput,
  SessionListInput,
  SessionListOutput,
  SessionCreateInput,
  SessionCreateOutput,
  SessionActiveOutput,
  SessionGetInput,
  SessionGetOutput,
  SessionRemoveInput,
  SessionRemoveOutput,
  SessionForkInput,
  SessionForkOutput,
  SessionSwitchAgentInput,
  SessionSwitchAgentOutput,
  SessionSwitchModelInput,
  SessionSwitchModelOutput,
  SessionUpdateInput,
  SessionUpdateOutput,
  SessionMoveInput,
  SessionMoveOutput,
  SessionPromptInput,
  SessionPromptOutput,
  SessionCommandInput,
  SessionCommandOutput,
  SessionSyntheticInput,
  SessionSyntheticOutput,
  SessionShellInput,
  SessionShellOutput,
  SessionCompactInput,
  SessionCompactOutput,
  SessionRevertStageInput,
  SessionRevertStageOutput,
  SessionRevertClearInput,
  SessionRevertClearOutput,
  SessionRevertCommitInput,
  SessionRevertCommitOutput,
  SessionContextInput,
  SessionContextOutput,
  SessionDiffInput,
  SessionDiffOutput,
  SessionInboxListInput,
  SessionInboxListOutput,
  SessionInboxCancelInput,
  SessionInboxCancelOutput,
  SessionInboxUpdateInput,
  SessionInboxUpdateOutput,
  SessionGenerateInput,
  SessionGenerateOutput,
  SessionInterruptInput,
  SessionInterruptOutput,
  SessionBackgroundInput,
  SessionBackgroundOutput,
  SessionMessageGetInput,
  SessionMessageGetOutput,
  SessionFormListInput,
  SessionFormListOutput,
  SessionFormCreateInput,
  SessionFormCreateOutput,
  SessionFormGetInput,
  SessionFormGetOutput,
  SessionFormReplyInput,
  SessionFormReplyOutput,
  SessionFormCancelInput,
  SessionFormCancelOutput,
  SessionEnvironmentInput,
  SessionEnvironmentOutput,
  SessionViewInput,
  SessionViewOutput,
  ExperimentalSessionStatsInput,
  ExperimentalSessionStatsOutput,
  ExperimentalSessionImportInput,
  ExperimentalSessionImportOutput,
  ExperimentalSessionExportInput,
  ExperimentalSessionExportOutput,
  ExperimentalSessionSkillInput,
  ExperimentalSessionSkillOutput,
  ExperimentalSessionWaitInput,
  ExperimentalSessionWaitOutput,
  ExperimentalSessionInstructionsEntryListInput,
  ExperimentalSessionInstructionsEntryListOutput,
  ExperimentalSessionInstructionsEntryPutInput,
  ExperimentalSessionInstructionsEntryPutOutput,
  ExperimentalSessionInstructionsEntryRemoveInput,
  ExperimentalSessionInstructionsEntryRemoveOutput,
  ExperimentalSessionLogInput,
  ExperimentalSessionLogOutput,
  MessageListInput,
  MessageListOutput,
  ModelListInput,
  ModelListOutput,
  ModelDefaultInput,
  ModelDefaultOutput,
  ExperimentalGenerateTextInput,
  ExperimentalGenerateTextOutput,
  ExperimentalGenerateImageInput,
  ExperimentalGenerateImageOutput,
  ExperimentalGenerateDecisionsInput,
  ExperimentalGenerateDecisionsOutput,
  ExperimentalVoiceModelsOutput,
  ExperimentalVoiceSessionInput,
  ExperimentalVoiceSessionOutput,
  TranscriptionTranscribeInput,
  TranscriptionTranscribeOutput,
  ExperimentalTranscriptionTranscribeWithOverridesInput,
  ExperimentalTranscriptionTranscribeWithOverridesOutput,
  ProviderListInput,
  ProviderListOutput,
  ProviderGetInput,
  ProviderGetOutput,
  IntegrationListInput,
  IntegrationListOutput,
  IntegrationGetInput,
  IntegrationGetOutput,
  IntegrationConnectKeyInput,
  IntegrationConnectKeyOutput,
  IntegrationConnectExternalInput,
  IntegrationConnectExternalOutput,
  IntegrationOauthConnectInput,
  IntegrationOauthConnectOutput,
  IntegrationOauthStatusInput,
  IntegrationOauthStatusOutput,
  IntegrationOauthCompleteInput,
  IntegrationOauthCompleteOutput,
  IntegrationOauthCancelInput,
  IntegrationOauthCancelOutput,
  IntegrationCommandConnectInput,
  IntegrationCommandConnectOutput,
  IntegrationCommandStatusInput,
  IntegrationCommandStatusOutput,
  IntegrationCommandCancelInput,
  IntegrationCommandCancelOutput,
  ExperimentalIntegrationWellknownAddInput,
  ExperimentalIntegrationWellknownAddOutput,
  McpListInput,
  McpListOutput,
  McpResourceCatalogInput,
  McpResourceCatalogOutput,
  ExperimentalMcpAddInput,
  ExperimentalMcpAddOutput,
  ExperimentalMcpRemoveInput,
  ExperimentalMcpRemoveOutput,
  ExperimentalMcpConnectInput,
  ExperimentalMcpConnectOutput,
  ExperimentalMcpDisconnectInput,
  ExperimentalMcpDisconnectOutput,
  ExperimentalMcpClientTokenInput,
  ExperimentalMcpClientTokenOutput,
  CredentialListOutput,
  CredentialCreateInput,
  CredentialCreateOutput,
  CredentialUpdateInput,
  CredentialUpdateOutput,
  CredentialActivateInput,
  CredentialActivateOutput,
  CredentialRemoveInput,
  CredentialRemoveOutput,
  ProjectListInput,
  ProjectListOutput,
  ProjectUpdateInput,
  ProjectUpdateOutput,
  FormListInput,
  FormListOutput,
  PermissionRequestListInput,
  PermissionRequestListOutput,
  PermissionSavedListInput,
  PermissionSavedListOutput,
  PermissionSavedUpdateInput,
  PermissionSavedUpdateOutput,
  PermissionSavedRemoveInput,
  PermissionSavedRemoveOutput,
  PermissionCreateInput,
  PermissionCreateOutput,
  PermissionListInput,
  PermissionListOutput,
  PermissionGetInput,
  PermissionGetOutput,
  PermissionReplyInput,
  PermissionReplyOutput,
  FileReadInput,
  FileReadOutput,
  FileListInput,
  FileListOutput,
  FileFindInput,
  FileFindOutput,
  ExperimentalFileWriteInput,
  ExperimentalFileWriteOutput,
  ExperimentalFileWatchInput,
  ExperimentalFileWatchOutput,
  ExperimentalFileUnwatchInput,
  ExperimentalFileUnwatchOutput,
  CommandListInput,
  CommandListOutput,
  SkillListInput,
  SkillListOutput,
  RpcCallInput,
  RpcCallOutput,
  EventSubscribeInput,
  EventSubscribeOutput,
  PtyListInput,
  PtyListOutput,
  PtyCreateInput,
  PtyCreateOutput,
  PtyGetInput,
  PtyGetOutput,
  PtyUpdateInput,
  PtyUpdateOutput,
  PtyRemoveInput,
  PtyRemoveOutput,
  PtyConnectTokenInput,
  PtyConnectTokenOutput,
  ExperimentalPersistentPtyReadInput,
  ExperimentalPersistentPtyReadOutput,
  ExperimentalPersistentPtyListInput,
  ExperimentalPersistentPtyListOutput,
  ExperimentalPersistentPtyCreateInput,
  ExperimentalPersistentPtyCreateOutput,
  ExperimentalPersistentPtyShutdownOutput,
  ExperimentalPersistentPtyHandoffOutput,
  ExperimentalPersistentPtyGetInput,
  ExperimentalPersistentPtyGetOutput,
  ExperimentalPersistentPtyUpdateInput,
  ExperimentalPersistentPtyUpdateOutput,
  ExperimentalPersistentPtySnapshotInput,
  ExperimentalPersistentPtySnapshotOutput,
  ExperimentalPersistentPtyRemoveInput,
  ExperimentalPersistentPtyRemoveOutput,
  ExperimentalPersistentPtyConnectTokenInput,
  ExperimentalPersistentPtyConnectTokenOutput,
  ExperimentalMediaGetInput,
  ExperimentalMediaGetOutput,
  ExperimentalScheduleCreateInput,
  ExperimentalScheduleCreateOutput,
  ExperimentalScheduleListInput,
  ExperimentalScheduleListOutput,
  ExperimentalScheduleGetInput,
  ExperimentalScheduleGetOutput,
  ExperimentalSchedulePauseInput,
  ExperimentalSchedulePauseOutput,
  ExperimentalScheduleResumeInput,
  ExperimentalScheduleResumeOutput,
  ExperimentalScheduleDeleteInput,
  ExperimentalScheduleDeleteOutput,
  ExperimentalArtifactsProvidersInput,
  ExperimentalArtifactsProvidersOutput,
  ExperimentalArtifactsListInput,
  ExperimentalArtifactsListOutput,
  ExperimentalArtifactsCreateInput,
  ExperimentalArtifactsCreateOutput,
  ExperimentalArtifactsGetInput,
  ExperimentalArtifactsGetOutput,
  ExperimentalArtifactsUpdateInput,
  ExperimentalArtifactsUpdateOutput,
  ExperimentalArtifactsDeleteInput,
  ExperimentalArtifactsDeleteOutput,
  ExperimentalArtifactsViewInput,
  ExperimentalArtifactsViewOutput,
  ExperimentalJobListInput,
  ExperimentalJobListOutput,
  ExperimentalPluginWebListOutput,
  ExperimentalPluginWebModuleInput,
  ExperimentalPluginWebModuleOutput,
  ShellListInput,
  ShellListOutput,
  ShellCreateInput,
  ShellCreateOutput,
  ShellGetInput,
  ShellGetOutput,
  ShellOutputInput,
  ShellOutputOutput,
  ShellRemoveInput,
  ShellRemoveOutput,
  ReferenceListInput,
  ReferenceListOutput,
  WorktreeListInput,
  WorktreeListOutput,
  WorktreeCreateInput,
  WorktreeCreateOutput,
  WorktreeRemoveInput,
  WorktreeRemoveOutput,
  WorktreeRefreshInput,
  WorktreeRefreshOutput,
  VcsInitInput,
  VcsInitOutput,
  VcsGetInput,
  VcsGetOutput,
  VcsBaseInput,
  VcsBaseOutput,
  VcsStatusInput,
  VcsStatusOutput,
  VcsBranchListInput,
  VcsBranchListOutput,
  VcsDiffInput,
  VcsDiffOutput,
  DebugHeapDumpInput,
  DebugHeapDumpOutput,
  DebugLocationListOutput,
  DebugLocationEvictInput,
  DebugLocationEvictOutput,
  ExperimentalMigrationV1StatusOutput,
  WebsearchProvidersInput,
  WebsearchProvidersOutput,
  WebsearchQueryInput,
  WebsearchQueryOutput,
  ExperimentalUsageLimitsInput,
  ExperimentalUsageLimitsOutput,
  ConfigGetInput,
  ConfigGetOutput,
  ConfigShellsOutput,
  ExperimentalConfigUpdateInput,
  ExperimentalConfigUpdateOutput,
} from "./types.js"
import { ClientError } from "./client-error.js"

export interface ClientOptions {
  readonly baseUrl: string
  readonly fetch?: typeof globalThis.fetch
  readonly headers?: RequestInit["headers"]
}

export interface RequestOptions {
  readonly signal?: AbortSignal
  readonly headers?: RequestInit["headers"]
  /** Reports every chunk a streaming response receives, including keepalive comments that yield no event. */
  readonly onActivity?: () => void
}

interface RequestDescriptor {
  readonly method: string
  readonly path: string
  readonly query?: Record<string, unknown>
  readonly headers?: Record<string, unknown>
  readonly body?: unknown
  readonly binaryBody?: true
  readonly successStatus: number
  readonly declaredStatuses: ReadonlyArray<number>
  readonly empty: boolean
  readonly binary?: true
}

const maxSseEventBytes = 16 * 1024 * 1024

export function make(options: ClientOptions) {
  const fetch = options.fetch ?? globalThis.fetch

  const prepare = (descriptor: RequestDescriptor, requestOptions?: RequestOptions) => {
    // A leading slash would replace any path prefix on baseUrl, so join relative to it.
    const baseUrl = new URL(options.baseUrl)
    if (!baseUrl.pathname.endsWith("/")) baseUrl.pathname += "/"
    const url = new URL(descriptor.path.slice(1), baseUrl)
    for (const [key, value] of Object.entries(descriptor.query ?? {})) appendQuery(url.searchParams, key, value)
    const headers = new Headers(options.headers)
    for (const [key, value] of Object.entries(descriptor.headers ?? {})) {
      if (value !== undefined && value !== null) headers.set(key, String(value))
    }
    for (const [key, value] of new Headers(requestOptions?.headers)) headers.set(key, value)
    if (descriptor.body !== undefined && !headers.has("content-type"))
      headers.set("content-type", descriptor.binaryBody ? "application/octet-stream" : "application/json")
    return {
      url,
      init: {
        method: descriptor.method,
        signal: requestOptions?.signal,
        headers,
        body:
          descriptor.body === undefined
            ? undefined
            : descriptor.binaryBody
              ? (descriptor.body as RequestInit["body"])
              : JSON.stringify(descriptor.body),
      } satisfies RequestInit,
    }
  }

  const execute = async (descriptor: RequestDescriptor, requestOptions?: RequestOptions) => {
    try {
      const prepared = prepare(descriptor, requestOptions)
      return await fetch(prepared.url, prepared.init)
    } catch (cause) {
      throw new ClientError("Transport", { cause })
    }
  }

  const responseError = async (response: Response, descriptor: RequestDescriptor): Promise<never> => {
    if (descriptor.declaredStatuses.includes(response.status))
      throw declared((await json(response)) as DeclaredErrorBody)
    try {
      await response.body?.cancel()
    } catch {}
    throw new ClientError("UnexpectedStatus", { cause: { status: response.status }, detail: String(response.status) })
  }

  const request = async <A>(descriptor: RequestDescriptor, requestOptions?: RequestOptions): Promise<A> => {
    const response = await execute(descriptor, requestOptions)
    if (response.status !== descriptor.successStatus) return responseError(response, descriptor)
    if (descriptor.binary) return new Uint8Array(await response.arrayBuffer()) as A
    if (descriptor.empty) {
      try {
        await response.body?.cancel()
      } catch {}
      return undefined as A
    }
    return (await json(response)) as A
  }

  const sse = <A>(descriptor: RequestDescriptor, requestOptions?: RequestOptions): AsyncIterable<A> => ({
    async *[Symbol.asyncIterator]() {
      const response = await execute(descriptor, requestOptions)
      if (response.status !== descriptor.successStatus) await responseError(response, descriptor)
      if (!isContentType(response, "text/event-stream")) {
        try {
          await response.body?.cancel()
        } catch {}
        throw new ClientError("UnsupportedContentType", { detail: response.headers.get("content-type") })
      }
      if (response.body === null) throw new ClientError("MalformedResponse")
      const reader = response.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ""
      try {
        while (true) {
          let next
          try {
            next = await reader.read()
          } catch (cause) {
            throw new ClientError("Transport", { cause })
          }
          if (!next.done) requestOptions?.onActivity?.()
          buffer += decoder.decode(next.value, { stream: !next.done })
          if (buffer.length > maxSseEventBytes) throw new ClientError("SseEventTooLarge")
          const trailingCarriageReturn = !next.done && buffer.endsWith("\r")
          if (trailingCarriageReturn) buffer = buffer.slice(0, -1)
          buffer = buffer.replaceAll("\r\n", "\n").replaceAll("\r", "\n")
          if (trailingCarriageReturn) buffer += "\r"
          if (next.done && buffer !== "") buffer += "\n\n"
          let boundary = buffer.indexOf("\n\n")
          while (boundary >= 0) {
            const block = buffer.slice(0, boundary)
            buffer = buffer.slice(boundary + 2)
            const data = block
              .split("\n")
              .flatMap((line) => (line.startsWith("data:") ? [line.slice(5).trimStart()] : []))
              .join("\n")
            if (data !== "") {
              try {
                yield JSON.parse(data) as A
              } catch (cause) {
                throw new ClientError("MalformedResponse", { cause })
              }
            }
            boundary = buffer.indexOf("\n\n")
          }
          if (next.done) return
        }
      } finally {
        try {
          await reader.cancel()
        } catch {}
        reader.releaseLock()
      }
    },
  })

  const client = {
    server: {
      info: (requestOptions?: RequestOptions) =>
        request<ServerInfoOutput>(
          { method: "GET", path: `/api/info`, successStatus: 200, declaredStatuses: [400, 401], empty: false },
          requestOptions,
        ),
      pair: (requestOptions?: RequestOptions) =>
        request<ServerPairOutput>(
          { method: "POST", path: `/api/pair`, successStatus: 200, declaredStatuses: [400, 401], empty: false },
          requestOptions,
        ),
      connect: (input: ServerConnectInput, requestOptions?: RequestOptions) =>
        request<ServerConnectOutput>(
          {
            method: "GET",
            path: `/auth/connect/${encodeURIComponent(input.code)}`,
            successStatus: 200,
            declaredStatuses: [400, 401],
            empty: false,
          },
          requestOptions,
        ),
    },
    location: {
      get: (input?: LocationGetInput, requestOptions?: RequestOptions) =>
        request<LocationGetOutput>(
          {
            method: "GET",
            path: `/api/location`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      reload: (requestOptions?: RequestOptions) =>
        request<LocationReloadOutput>(
          {
            method: "POST",
            path: `/api/location/reload`,
            successStatus: 204,
            declaredStatuses: [400, 401, 503],
            empty: true,
          },
          requestOptions,
        ),
    },
    agent: {
      list: (input?: AgentListInput, requestOptions?: RequestOptions) =>
        request<AgentListOutput>(
          {
            method: "GET",
            path: `/api/agent`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      get: (input: AgentGetInput, requestOptions?: RequestOptions) =>
        request<AgentGetOutput>(
          {
            method: "GET",
            path: `/api/agent/${encodeURIComponent(input.agentID)}`,
            query: { location: input["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
    },
    plugin: {
      list: (input?: PluginListInput, requestOptions?: RequestOptions) =>
        request<PluginListOutput>(
          {
            method: "GET",
            path: `/api/plugin`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      gui: (input: PluginGuiInput, requestOptions?: RequestOptions) =>
        request<PluginGuiOutput>(
          {
            method: "GET",
            path: `/api/plugin/gui`,
            query: { location: input["location"], id: input["id"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      check: (input?: PluginCheckInput, requestOptions?: RequestOptions) =>
        request<PluginCheckOutput>(
          {
            method: "POST",
            path: `/api/plugin/check`,
            query: { location: input?.["location"] },
            body: { target: input?.["target"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      update: (input: PluginUpdateInput, requestOptions?: RequestOptions) =>
        request<PluginUpdateOutput>(
          {
            method: "POST",
            path: `/api/plugin/update`,
            query: { location: input["location"] },
            body: { targets: input["targets"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404, 503],
            empty: true,
          },
          requestOptions,
        ),
    },
    session: {
      list: (input?: SessionListInput, requestOptions?: RequestOptions) =>
        request<SessionListOutput>(
          {
            method: "GET",
            path: `/api/session`,
            query: {
              limit: input?.["limit"],
              order: input?.["order"],
              search: input?.["search"],
              parentID: input?.["parentID"],
              archived: input?.["archived"],
              directory: input?.["directory"],
              project: input?.["project"],
              subpath: input?.["subpath"],
              cursor: input?.["cursor"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401],
            empty: false,
          },
          requestOptions,
        ),
      create: (input?: SessionCreateInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: SessionCreateOutput }>(
          {
            method: "POST",
            path: `/api/session`,
            body: {
              id: input?.["id"],
              parentID: input?.["parentID"],
              title: input?.["title"],
              agent: input?.["agent"],
              model: input?.["model"],
              location: input?.["location"],
              metadata: input?.["metadata"],
              permissions: input?.["permissions"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      active: (requestOptions?: RequestOptions) =>
        request<{ readonly data: SessionActiveOutput }>(
          {
            method: "GET",
            path: `/api/session/active`,
            successStatus: 200,
            declaredStatuses: [400, 401],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      get: (input: SessionGetInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: SessionGetOutput }>(
          {
            method: "GET",
            path: `/api/session/${encodeURIComponent(input.sessionID)}`,
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      remove: (input: SessionRemoveInput, requestOptions?: RequestOptions) =>
        request<SessionRemoveOutput>(
          {
            method: "DELETE",
            path: `/api/session/${encodeURIComponent(input.sessionID)}`,
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
      fork: (input: SessionForkInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: SessionForkOutput }>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/fork`,
            body: { before: input["before"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      switchAgent: (input: SessionSwitchAgentInput, requestOptions?: RequestOptions) =>
        request<SessionSwitchAgentOutput>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/agent`,
            body: { agent: input["agent"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
      switchModel: (input: SessionSwitchModelInput, requestOptions?: RequestOptions) =>
        request<SessionSwitchModelOutput>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/model`,
            body: { model: input["model"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
      update: (input: SessionUpdateInput, requestOptions?: RequestOptions) =>
        request<SessionUpdateOutput>(
          {
            method: "PATCH",
            path: `/api/session/${encodeURIComponent(input.sessionID)}`,
            body: {
              title: input["title"],
              metadata: input["metadata"],
              permissions: input["permissions"],
              archived: input["archived"],
            },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
      move: (input: SessionMoveInput, requestOptions?: RequestOptions) =>
        request<SessionMoveOutput>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/move`,
            body: { directory: input["directory"], delivery: input["delivery"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
      prompt: (input: SessionPromptInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: SessionPromptOutput }>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/prompt`,
            body: {
              id: input["id"],
              text: input["text"],
              files: input["files"],
              agents: input["agents"],
              skills: input["skills"],
              metadata: input["metadata"],
              delivery: input["delivery"],
              resume: input["resume"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 409],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      command: (input: SessionCommandInput, requestOptions?: RequestOptions) =>
        request<SessionCommandOutput>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/command`,
            body: {
              name: input["name"],
              text: input["text"],
              files: input["files"],
              agents: input["agents"],
              skills: input["skills"],
              delivery: input["delivery"],
            },
            successStatus: 204,
            declaredStatuses: [400, 401, 404, 500],
            empty: true,
          },
          requestOptions,
        ),
      synthetic: (input: SessionSyntheticInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: SessionSyntheticOutput }>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/synthetic`,
            body: {
              id: input["id"],
              text: input["text"],
              description: input["description"],
              metadata: input["metadata"],
              delivery: input["delivery"],
              resume: input["resume"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 409],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      shell: (input: SessionShellInput, requestOptions?: RequestOptions) =>
        request<SessionShellOutput>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/shell`,
            body: { id: input["id"], command: input["command"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
      compact: (input: SessionCompactInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: SessionCompactOutput }>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/compact`,
            body: { id: input["id"], delivery: input["delivery"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 409],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      revert: {
        stage: (input: SessionRevertStageInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: SessionRevertStageOutput }>(
            {
              method: "POST",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/revert/stage`,
              body: { messageID: input["messageID"], files: input["files"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 409, 500],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        clear: (input: SessionRevertClearInput, requestOptions?: RequestOptions) =>
          request<SessionRevertClearOutput>(
            {
              method: "DELETE",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/revert`,
              successStatus: 204,
              declaredStatuses: [400, 401, 404, 409, 500],
              empty: true,
            },
            requestOptions,
          ),
        commit: (input: SessionRevertCommitInput, requestOptions?: RequestOptions) =>
          request<SessionRevertCommitOutput>(
            {
              method: "POST",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/revert/commit`,
              successStatus: 204,
              declaredStatuses: [400, 401, 404, 409],
              empty: true,
            },
            requestOptions,
          ),
      },
      context: (input: SessionContextInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: SessionContextOutput }>(
          {
            method: "GET",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/context`,
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 500],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      diff: (input: SessionDiffInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: SessionDiffOutput }>(
          {
            method: "GET",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/diff`,
            query: { from: input["from"], to: input["to"], context: input["context"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 500],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      inbox: {
        list: (input: SessionInboxListInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: SessionInboxListOutput }>(
            {
              method: "GET",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/inbox`,
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        cancel: (input: SessionInboxCancelInput, requestOptions?: RequestOptions) =>
          request<SessionInboxCancelOutput>(
            {
              method: "DELETE",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/inbox/${encodeURIComponent(input.inboxID)}`,
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
        update: (input: SessionInboxUpdateInput, requestOptions?: RequestOptions) =>
          request<SessionInboxUpdateOutput>(
            {
              method: "PATCH",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/inbox/${encodeURIComponent(input.inboxID)}`,
              body: { delivery: input["delivery"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404, 409],
              empty: true,
            },
            requestOptions,
          ),
      },
      generate: (input: SessionGenerateInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: SessionGenerateOutput }>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/generate`,
            body: { prompt: input["prompt"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 503],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      interrupt: (input: SessionInterruptInput, requestOptions?: RequestOptions) =>
        request<SessionInterruptOutput>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/interrupt`,
            query: { resume: input["resume"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      background: (input: SessionBackgroundInput, requestOptions?: RequestOptions) =>
        request<SessionBackgroundOutput>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/background`,
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
      message: {
        get: (input: SessionMessageGetInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: SessionMessageGetOutput }>(
            {
              method: "GET",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/message/${encodeURIComponent(input.messageID)}`,
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
      },
      form: {
        list: (input: SessionFormListInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: SessionFormListOutput }>(
            {
              method: "GET",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/form`,
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        create: (input: SessionFormCreateInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: SessionFormCreateOutput }>(
            {
              method: "POST",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/form`,
              body: { id: input["id"], title: input["title"], metadata: input["metadata"], fields: input["fields"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 409],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        get: (input: SessionFormGetInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: SessionFormGetOutput }>(
            {
              method: "GET",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/form/${encodeURIComponent(input.formID)}`,
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        reply: (input: SessionFormReplyInput, requestOptions?: RequestOptions) =>
          request<SessionFormReplyOutput>(
            {
              method: "POST",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/form/${encodeURIComponent(input.formID)}/reply`,
              body: { answer: input["answer"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404, 409],
              empty: true,
            },
            requestOptions,
          ),
        cancel: (input: SessionFormCancelInput, requestOptions?: RequestOptions) =>
          request<SessionFormCancelOutput>(
            {
              method: "DELETE",
              path: `/api/session/${encodeURIComponent(input.sessionID)}/form/${encodeURIComponent(input.formID)}`,
              query: { message: input["message"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404, 409],
              empty: true,
            },
            requestOptions,
          ),
      },
      environment: (input: SessionEnvironmentInput, requestOptions?: RequestOptions) =>
        request<SessionEnvironmentOutput>(
          {
            method: "PUT",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/environment`,
            body: { variables: input["variables"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
      view: (input: SessionViewInput, requestOptions?: RequestOptions) =>
        request<SessionViewOutput>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/view`,
            body: { idle: input["idle"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
    },
    experimental: {
      session: {
        stats: (input?: ExperimentalSessionStatsInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalSessionStatsOutput }>(
            {
              method: "GET",
              path: `/api/experimental/session/stats`,
              query: {
                from: input?.["from"],
                to: input?.["to"],
                project: input?.["project"],
                timezone: input?.["timezone"],
                tools: input?.["tools"],
              },
              successStatus: 200,
              declaredStatuses: [400, 401],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        import: (input: ExperimentalSessionImportInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalSessionImportOutput }>(
            {
              method: "POST",
              path: `/api/experimental/session/import`,
              body: { info: input["info"], messages: input["messages"], location: input["location"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 409],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        export: (input: ExperimentalSessionExportInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalSessionExportOutput }>(
            {
              method: "GET",
              path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/export`,
              query: { sanitize: input["sanitize"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 500],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        skill: (input: ExperimentalSessionSkillInput, requestOptions?: RequestOptions) =>
          request<ExperimentalSessionSkillOutput>(
            {
              method: "POST",
              path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/skill`,
              body: { id: input["id"], resume: input["resume"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
        wait: (input: ExperimentalSessionWaitInput, requestOptions?: RequestOptions) =>
          request<ExperimentalSessionWaitOutput>(
            {
              method: "POST",
              path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/wait`,
              successStatus: 204,
              declaredStatuses: [400, 401, 404, 503],
              empty: true,
            },
            requestOptions,
          ),
        instructions: {
          entry: {
            list: (input: ExperimentalSessionInstructionsEntryListInput, requestOptions?: RequestOptions) =>
              request<{ readonly data: ExperimentalSessionInstructionsEntryListOutput }>(
                {
                  method: "GET",
                  path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/instructions/entries`,
                  successStatus: 200,
                  declaredStatuses: [400, 401, 404],
                  empty: false,
                },
                requestOptions,
              ).then((value) => value.data),
            put: (input: ExperimentalSessionInstructionsEntryPutInput, requestOptions?: RequestOptions) =>
              request<ExperimentalSessionInstructionsEntryPutOutput>(
                {
                  method: "PUT",
                  path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/instructions/entries/${encodeURIComponent(input.key)}`,
                  body: { value: input["value"] },
                  successStatus: 204,
                  declaredStatuses: [400, 401, 404, 413],
                  empty: true,
                },
                requestOptions,
              ),
            remove: (input: ExperimentalSessionInstructionsEntryRemoveInput, requestOptions?: RequestOptions) =>
              request<ExperimentalSessionInstructionsEntryRemoveOutput>(
                {
                  method: "DELETE",
                  path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/instructions/entries/${encodeURIComponent(input.key)}`,
                  successStatus: 204,
                  declaredStatuses: [400, 401, 404],
                  empty: true,
                },
                requestOptions,
              ),
          },
        },
        log: (
          input: ExperimentalSessionLogInput,
          requestOptions?: RequestOptions,
        ): AsyncIterable<ExperimentalSessionLogOutput> =>
          sse<ExperimentalSessionLogOutput>(
            {
              method: "GET",
              path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/log`,
              query: { after: input["after"], follow: input["follow"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ),
      },
      generate: {
        text: (input: ExperimentalGenerateTextInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalGenerateTextOutput }>(
            {
              method: "POST",
              path: `/api/experimental/generate/text`,
              body: { prompt: input["prompt"], model: input["model"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 422, 502, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        image: (input: ExperimentalGenerateImageInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalGenerateImageOutput }>(
            {
              method: "POST",
              path: `/api/experimental/generate/image`,
              body: {
                model: input["model"],
                prompt: input["prompt"],
                images: input["images"],
                n: input["n"],
                aspect: input["aspect"],
                resolution: input["resolution"],
              },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 422, 502, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        decisions: (input: ExperimentalGenerateDecisionsInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalGenerateDecisionsOutput }>(
            {
              method: "POST",
              path: `/api/experimental/generate/decisions`,
              body: { model: input["model"], input: input["input"], questions: input["questions"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 422, 502, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
      },
      voice: {
        models: (requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalVoiceModelsOutput }>(
            {
              method: "GET",
              path: `/api/experimental/voice/models`,
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        session: (input: ExperimentalVoiceSessionInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalVoiceSessionOutput }>(
            {
              method: "POST",
              path: `/api/experimental/voice/session`,
              body: { model: input["model"], session: input["session"], transport: input["transport"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
      },
      transcription: {
        transcribeWithOverrides: (
          input: ExperimentalTranscriptionTranscribeWithOverridesInput,
          requestOptions?: RequestOptions,
        ) =>
          request<ExperimentalTranscriptionTranscribeWithOverridesOutput>(
            {
              method: "POST",
              path: `/api/experimental/transcription`,
              query: { location: input["location"] },
              body: {
                audio: input["audio"],
                mime: input["mime"],
                prompt: input["prompt"],
                contextSessionID: input["contextSessionID"],
                images: input["images"],
                settings: input["settings"],
                overrides: input["overrides"],
              },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 500, 503],
              empty: false,
            },
            requestOptions,
          ),
      },
      integration: {
        wellknown: {
          add: (input: ExperimentalIntegrationWellknownAddInput, requestOptions?: RequestOptions) =>
            request<ExperimentalIntegrationWellknownAddOutput>(
              {
                method: "POST",
                path: `/api/experimental/integration/wellknown`,
                query: { location: input["location"] },
                body: { url: input["url"] },
                successStatus: 204,
                declaredStatuses: [400, 401, 404],
                empty: true,
              },
              requestOptions,
            ),
        },
      },
      mcp: {
        add: (input: ExperimentalMcpAddInput, requestOptions?: RequestOptions) =>
          request<ExperimentalMcpAddOutput>(
            {
              method: "PUT",
              path: `/api/experimental/mcp/${encodeURIComponent(input.server)}`,
              query: { location: input["location"] },
              body: { config: input["config"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
        remove: (input: ExperimentalMcpRemoveInput, requestOptions?: RequestOptions) =>
          request<ExperimentalMcpRemoveOutput>(
            {
              method: "DELETE",
              path: `/api/experimental/mcp/${encodeURIComponent(input.server)}`,
              query: { location: input["location"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
        connect: (input: ExperimentalMcpConnectInput, requestOptions?: RequestOptions) =>
          request<ExperimentalMcpConnectOutput>(
            {
              method: "POST",
              path: `/api/experimental/mcp/${encodeURIComponent(input.server)}/connect`,
              query: { location: input["location"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
        disconnect: (input: ExperimentalMcpDisconnectInput, requestOptions?: RequestOptions) =>
          request<ExperimentalMcpDisconnectOutput>(
            {
              method: "POST",
              path: `/api/experimental/mcp/${encodeURIComponent(input.server)}/disconnect`,
              query: { location: input["location"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
        client: {
          token: (input: ExperimentalMcpClientTokenInput, requestOptions?: RequestOptions) =>
            request<ExperimentalMcpClientTokenOutput>(
              {
                method: "POST",
                path: `/api/experimental/client-mcp/token`,
                query: { location: input["location"], name: input["name"] },
                headers: { "x-opencode-ticket": input["x-opencode-ticket"] },
                successStatus: 200,
                declaredStatuses: [400, 401, 403, 404],
                empty: false,
              },
              requestOptions,
            ),
        },
      },
      file: {
        write: (input: ExperimentalFileWriteInput, requestOptions?: RequestOptions) =>
          request<ExperimentalFileWriteOutput>(
            {
              method: "POST",
              path: `/api/experimental/fs/write`,
              query: { location: input["location"], path: input["path"] },
              body: input["payload"],
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
              binaryBody: true,
            },
            requestOptions,
          ),
        watch: (input: ExperimentalFileWatchInput, requestOptions?: RequestOptions) =>
          request<ExperimentalFileWatchOutput>(
            {
              method: "POST",
              path: `/api/experimental/fs/watch`,
              query: { location: input["location"] },
              body: { path: input["path"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404, 503],
              empty: true,
            },
            requestOptions,
          ),
        unwatch: (input: ExperimentalFileUnwatchInput, requestOptions?: RequestOptions) =>
          request<ExperimentalFileUnwatchOutput>(
            {
              method: "DELETE",
              path: `/api/experimental/fs/watch`,
              query: { location: input["location"] },
              body: { path: input["path"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
      },
      persistentPty: {
        read: (input: ExperimentalPersistentPtyReadInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalPersistentPtyReadOutput }>(
            {
              method: "GET",
              path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/terminal/read`,
              query: { lines: input["lines"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        list: (input: ExperimentalPersistentPtyListInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalPersistentPtyListOutput }>(
            {
              method: "GET",
              path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/terminal`,
              successStatus: 200,
              declaredStatuses: [400, 401, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        create: (input: ExperimentalPersistentPtyCreateInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalPersistentPtyCreateOutput }>(
            {
              method: "POST",
              path: `/api/experimental/session/${encodeURIComponent(input.sessionID)}/terminal`,
              body: {
                command: input["command"],
                args: input["args"],
                cwd: input["cwd"],
                title: input["title"],
                env: input["env"],
                size: input["size"],
              },
              successStatus: 200,
              declaredStatuses: [400, 401, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        shutdown: (requestOptions?: RequestOptions) =>
          request<ExperimentalPersistentPtyShutdownOutput>(
            {
              method: "POST",
              path: `/api/experimental/persistent-pty/shutdown`,
              successStatus: 204,
              declaredStatuses: [400, 401, 503],
              empty: true,
            },
            requestOptions,
          ),
        handoff: (requestOptions?: RequestOptions) =>
          request<ExperimentalPersistentPtyHandoffOutput>(
            {
              method: "POST",
              path: `/api/experimental/persistent-pty/handoff`,
              successStatus: 200,
              declaredStatuses: [400, 401, 503],
              empty: false,
            },
            requestOptions,
          ),
        get: (input: ExperimentalPersistentPtyGetInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalPersistentPtyGetOutput }>(
            {
              method: "GET",
              path: `/api/experimental/persistent-pty/${encodeURIComponent(input.ptyID)}`,
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        update: (input: ExperimentalPersistentPtyUpdateInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalPersistentPtyUpdateOutput }>(
            {
              method: "PUT",
              path: `/api/experimental/persistent-pty/${encodeURIComponent(input.ptyID)}`,
              body: { attachmentID: input["attachmentID"], size: input["size"], title: input["title"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 501, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        snapshot: (input: ExperimentalPersistentPtySnapshotInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalPersistentPtySnapshotOutput }>(
            {
              method: "GET",
              path: `/api/experimental/persistent-pty/${encodeURIComponent(input.ptyID)}/snapshot`,
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        remove: (input: ExperimentalPersistentPtyRemoveInput, requestOptions?: RequestOptions) =>
          request<ExperimentalPersistentPtyRemoveOutput>(
            {
              method: "DELETE",
              path: `/api/experimental/persistent-pty/${encodeURIComponent(input.ptyID)}`,
              successStatus: 204,
              declaredStatuses: [400, 401, 404, 503],
              empty: true,
            },
            requestOptions,
          ),
        connectToken: (input: ExperimentalPersistentPtyConnectTokenInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalPersistentPtyConnectTokenOutput }>(
            {
              method: "POST",
              path: `/api/experimental/persistent-pty/${encodeURIComponent(input.ptyID)}/connect-token`,
              headers: { "x-opencode-ticket": input["x-opencode-ticket"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404, 503],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
      },
      media: {
        get: (input: ExperimentalMediaGetInput, requestOptions?: RequestOptions) =>
          request<ExperimentalMediaGetOutput>(
            {
              method: "GET",
              path: `/api/experimental/media/${encodeURIComponent(input.hash)}`,
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
              binary: true,
            },
            requestOptions,
          ),
      },
      schedule: {
        create: (input: ExperimentalScheduleCreateInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalScheduleCreateOutput }>(
            {
              method: "POST",
              path: `/api/experimental/schedule`,
              body: {
                sessionID: input["sessionID"],
                name: input["name"],
                when: input["when"],
                if: input["if"],
                until: input["until"],
                ends: input["ends"],
                prompt: input["prompt"],
              },
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        list: (input: ExperimentalScheduleListInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalScheduleListOutput }>(
            {
              method: "GET",
              path: `/api/experimental/schedule`,
              query: { sessionID: input["sessionID"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        get: (input: ExperimentalScheduleGetInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalScheduleGetOutput }>(
            {
              method: "GET",
              path: `/api/experimental/schedule/${encodeURIComponent(input.scheduleID)}`,
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        pause: (input: ExperimentalSchedulePauseInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalSchedulePauseOutput }>(
            {
              method: "POST",
              path: `/api/experimental/schedule/${encodeURIComponent(input.scheduleID)}/pause`,
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        resume: (input: ExperimentalScheduleResumeInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalScheduleResumeOutput }>(
            {
              method: "POST",
              path: `/api/experimental/schedule/${encodeURIComponent(input.scheduleID)}/resume`,
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        delete: (input: ExperimentalScheduleDeleteInput, requestOptions?: RequestOptions) =>
          request<ExperimentalScheduleDeleteOutput>(
            {
              method: "DELETE",
              path: `/api/experimental/schedule/${encodeURIComponent(input.scheduleID)}`,
              successStatus: 204,
              declaredStatuses: [400, 401, 403, 404],
              empty: true,
            },
            requestOptions,
          ),
      },
      artifacts: {
        providers: (input?: ExperimentalArtifactsProvidersInput, requestOptions?: RequestOptions) =>
          request<ExperimentalArtifactsProvidersOutput>(
            {
              method: "GET",
              path: `/api/experimental/artifacts/providers`,
              query: { location: input?.["location"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404, 503],
              empty: false,
            },
            requestOptions,
          ),
        list: (input?: ExperimentalArtifactsListInput, requestOptions?: RequestOptions) =>
          request<ExperimentalArtifactsListOutput>(
            {
              method: "GET",
              path: `/api/experimental/artifacts`,
              query: { location: input?.["location"], sessionID: input?.["sessionID"], provider: input?.["provider"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404, 503],
              empty: false,
            },
            requestOptions,
          ),
        create: (input: ExperimentalArtifactsCreateInput, requestOptions?: RequestOptions) =>
          request<ExperimentalArtifactsCreateOutput>(
            {
              method: "POST",
              path: `/api/experimental/artifacts`,
              query: { location: input["location"] },
              body: {
                title: input["title"],
                files: input["files"],
                entry: input["entry"],
                provider: input["provider"],
                sessionID: input["sessionID"],
              },
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404, 503],
              empty: false,
            },
            requestOptions,
          ),
        get: (input: ExperimentalArtifactsGetInput, requestOptions?: RequestOptions) =>
          request<ExperimentalArtifactsGetOutput>(
            {
              method: "GET",
              path: `/api/experimental/artifacts/${encodeURIComponent(input.artifactID)}`,
              query: { location: input["location"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404, 503],
              empty: false,
            },
            requestOptions,
          ),
        update: (input: ExperimentalArtifactsUpdateInput, requestOptions?: RequestOptions) =>
          request<ExperimentalArtifactsUpdateOutput>(
            {
              method: "PATCH",
              path: `/api/experimental/artifacts/${encodeURIComponent(input.artifactID)}`,
              query: { location: input["location"] },
              body: {
                title: input["title"],
                files: input["files"],
                entry: input["entry"],
                sessionID: input["sessionID"],
              },
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404, 503],
              empty: false,
            },
            requestOptions,
          ),
        delete: (input: ExperimentalArtifactsDeleteInput, requestOptions?: RequestOptions) =>
          request<ExperimentalArtifactsDeleteOutput>(
            {
              method: "DELETE",
              path: `/api/experimental/artifacts/${encodeURIComponent(input.artifactID)}`,
              query: { location: input["location"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 403, 404, 503],
              empty: true,
            },
            requestOptions,
          ),
        view: (input: ExperimentalArtifactsViewInput, requestOptions?: RequestOptions) =>
          request<ExperimentalArtifactsViewOutput>(
            {
              method: "GET",
              path: `/api/experimental/artifacts/${encodeURIComponent(input.artifactID)}/view/${encodePath(input.path)}`,
              query: { location: input["location"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404, 503],
              empty: false,
              binary: true,
            },
            requestOptions,
          ),
      },
      job: {
        list: (input?: ExperimentalJobListInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: ExperimentalJobListOutput }>(
            {
              method: "GET",
              path: `/api/experimental/job`,
              query: {
                sessionID: input?.["sessionID"],
                kind: input?.["kind"],
                status: input?.["status"],
                descendants: input?.["descendants"],
              },
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
      },
      plugin: {
        webList: (requestOptions?: RequestOptions) =>
          request<ExperimentalPluginWebListOutput>(
            {
              method: "POST",
              path: `/api/experimental/plugin/web-list`,
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404],
              empty: false,
            },
            requestOptions,
          ),
        webModule: (input: ExperimentalPluginWebModuleInput, requestOptions?: RequestOptions) =>
          request<ExperimentalPluginWebModuleOutput>(
            {
              method: "GET",
              path: `/api/experimental/plugin/web-module`,
              query: { id: input["id"], revision: input["revision"], ticket: input["ticket"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404],
              empty: false,
              binary: true,
            },
            requestOptions,
          ),
      },
      migration: {
        v1: {
          status: (requestOptions?: RequestOptions) =>
            request<ExperimentalMigrationV1StatusOutput>(
              {
                method: "GET",
                path: `/api/experimental/migration/v1`,
                successStatus: 200,
                declaredStatuses: [400, 401],
                empty: false,
              },
              requestOptions,
            ),
        },
      },
      usage: {
        limits: (input?: ExperimentalUsageLimitsInput, requestOptions?: RequestOptions) =>
          request<ExperimentalUsageLimitsOutput>(
            {
              method: "GET",
              path: `/api/experimental/usage/limits`,
              query: { location: input?.["location"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 503],
              empty: false,
            },
            requestOptions,
          ),
      },
      config: {
        update: (input: ExperimentalConfigUpdateInput, requestOptions?: RequestOptions) =>
          request<ExperimentalConfigUpdateOutput>(
            {
              method: "PATCH",
              path: `/api/experimental/config`,
              body: { shell: input["shell"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
      },
    },
    message: {
      list: (input: MessageListInput, requestOptions?: RequestOptions) =>
        request<MessageListOutput>(
          {
            method: "GET",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/message`,
            query: { limit: input["limit"], order: input["order"], cursor: input["cursor"], type: input["type"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 500],
            empty: false,
          },
          requestOptions,
        ),
    },
    model: {
      list: (input?: ModelListInput, requestOptions?: RequestOptions) =>
        request<ModelListOutput>(
          {
            method: "GET",
            path: `/api/model`,
            query: { location: input?.["location"], types: input?.["types"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 503],
            empty: false,
          },
          requestOptions,
        ),
      default: (input?: ModelDefaultInput, requestOptions?: RequestOptions) =>
        request<ModelDefaultOutput>(
          {
            method: "GET",
            path: `/api/model/default`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 503],
            empty: false,
          },
          requestOptions,
        ),
    },
    transcription: {
      transcribe: (input: TranscriptionTranscribeInput, requestOptions?: RequestOptions) =>
        request<TranscriptionTranscribeOutput>(
          {
            method: "POST",
            path: `/api/transcription`,
            query: { location: input["location"] },
            body: {
              audio: input["audio"],
              mime: input["mime"],
              prompt: input["prompt"],
              contextSessionID: input["contextSessionID"],
              images: input["images"],
              settings: input["settings"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 500, 503],
            empty: false,
          },
          requestOptions,
        ),
    },
    provider: {
      list: (input?: ProviderListInput, requestOptions?: RequestOptions) =>
        request<ProviderListOutput>(
          {
            method: "GET",
            path: `/api/provider`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 503],
            empty: false,
          },
          requestOptions,
        ),
      get: (input: ProviderGetInput, requestOptions?: RequestOptions) =>
        request<ProviderGetOutput>(
          {
            method: "GET",
            path: `/api/provider/${encodeURIComponent(input.providerID)}`,
            query: { location: input["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 503],
            empty: false,
          },
          requestOptions,
        ),
    },
    integration: {
      list: (input?: IntegrationListInput, requestOptions?: RequestOptions) =>
        request<IntegrationListOutput>(
          {
            method: "GET",
            path: `/api/integration`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      get: (input: IntegrationGetInput, requestOptions?: RequestOptions) =>
        request<IntegrationGetOutput>(
          {
            method: "GET",
            path: `/api/integration/${encodeURIComponent(input.integrationID)}`,
            query: { location: input["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      connect: {
        key: (input: IntegrationConnectKeyInput, requestOptions?: RequestOptions) =>
          request<IntegrationConnectKeyOutput>(
            {
              method: "POST",
              path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/key`,
              query: { location: input["location"] },
              body: { key: input["key"], answer: input["answer"], label: input["label"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
        external: (input: IntegrationConnectExternalInput, requestOptions?: RequestOptions) =>
          request<IntegrationConnectExternalOutput>(
            {
              method: "POST",
              path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/external`,
              query: { location: input["location"] },
              body: { methodID: input["methodID"], answer: input["answer"], label: input["label"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
      },
      oauth: {
        connect: (input: IntegrationOauthConnectInput, requestOptions?: RequestOptions) =>
          request<IntegrationOauthConnectOutput>(
            {
              method: "POST",
              path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/oauth`,
              query: { location: input["location"] },
              body: { methodID: input["methodID"], answer: input["answer"], label: input["label"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ),
        status: (input: IntegrationOauthStatusInput, requestOptions?: RequestOptions) =>
          request<IntegrationOauthStatusOutput>(
            {
              method: "GET",
              path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/oauth/${encodeURIComponent(input.attemptID)}`,
              query: { location: input["location"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ),
        complete: (input: IntegrationOauthCompleteInput, requestOptions?: RequestOptions) =>
          request<IntegrationOauthCompleteOutput>(
            {
              method: "POST",
              path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/oauth/${encodeURIComponent(input.attemptID)}/complete`,
              query: { location: input["location"] },
              body: { code: input["code"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
        cancel: (input: IntegrationOauthCancelInput, requestOptions?: RequestOptions) =>
          request<IntegrationOauthCancelOutput>(
            {
              method: "DELETE",
              path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/oauth/${encodeURIComponent(input.attemptID)}`,
              query: { location: input["location"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
      },
      command: {
        connect: (input: IntegrationCommandConnectInput, requestOptions?: RequestOptions) =>
          request<IntegrationCommandConnectOutput>(
            {
              method: "POST",
              path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/command`,
              query: { location: input["location"] },
              body: { methodID: input["methodID"], label: input["label"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ),
        status: (input: IntegrationCommandStatusInput, requestOptions?: RequestOptions) =>
          request<IntegrationCommandStatusOutput>(
            {
              method: "GET",
              path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/command/${encodeURIComponent(input.attemptID)}`,
              query: { location: input["location"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ),
        cancel: (input: IntegrationCommandCancelInput, requestOptions?: RequestOptions) =>
          request<IntegrationCommandCancelOutput>(
            {
              method: "DELETE",
              path: `/api/integration/${encodeURIComponent(input.integrationID)}/connect/command/${encodeURIComponent(input.attemptID)}`,
              query: { location: input["location"] },
              successStatus: 204,
              declaredStatuses: [400, 401, 404],
              empty: true,
            },
            requestOptions,
          ),
      },
    },
    mcp: {
      list: (input?: McpListInput, requestOptions?: RequestOptions) =>
        request<McpListOutput>(
          {
            method: "GET",
            path: `/api/mcp`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      resource: {
        catalog: (input?: McpResourceCatalogInput, requestOptions?: RequestOptions) =>
          request<McpResourceCatalogOutput>(
            {
              method: "GET",
              path: `/api/mcp/resource`,
              query: { location: input?.["location"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ),
      },
    },
    credential: {
      list: (requestOptions?: RequestOptions) =>
        request<{ readonly data: CredentialListOutput }>(
          { method: "GET", path: `/api/credential`, successStatus: 200, declaredStatuses: [400, 401], empty: false },
          requestOptions,
        ).then((value) => value.data),
      create: (input: CredentialCreateInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: CredentialCreateOutput }>(
          {
            method: "POST",
            path: `/api/credential`,
            body: {
              id: input["id"],
              integrationID: input["integrationID"],
              label: input["label"],
              value: input["value"],
              activate: input["activate"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401, 409],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      update: (input: CredentialUpdateInput, requestOptions?: RequestOptions) =>
        request<CredentialUpdateOutput>(
          {
            method: "PATCH",
            path: `/api/credential/${encodeURIComponent(input.credentialID)}`,
            body: { label: input["label"] },
            successStatus: 204,
            declaredStatuses: [400, 401],
            empty: true,
          },
          requestOptions,
        ),
      activate: (input: CredentialActivateInput, requestOptions?: RequestOptions) =>
        request<CredentialActivateOutput>(
          {
            method: "POST",
            path: `/api/credential/${encodeURIComponent(input.credentialID)}/activate`,
            successStatus: 204,
            declaredStatuses: [400, 401],
            empty: true,
          },
          requestOptions,
        ),
      remove: (input: CredentialRemoveInput, requestOptions?: RequestOptions) =>
        request<CredentialRemoveOutput>(
          {
            method: "DELETE",
            path: `/api/credential/${encodeURIComponent(input.credentialID)}`,
            successStatus: 204,
            declaredStatuses: [400, 401],
            empty: true,
          },
          requestOptions,
        ),
    },
    project: {
      list: (input?: ProjectListInput, requestOptions?: RequestOptions) =>
        request<ProjectListOutput>(
          {
            method: "GET",
            path: `/api/project`,
            query: { archived: input?.["archived"] },
            successStatus: 200,
            declaredStatuses: [400, 401],
            empty: false,
          },
          requestOptions,
        ),
      update: (input: ProjectUpdateInput, requestOptions?: RequestOptions) =>
        request<ProjectUpdateOutput>(
          {
            method: "PATCH",
            path: `/api/project/${encodeURIComponent(input.projectID)}`,
            body: {
              canonical: input["canonical"],
              name: input["name"],
              icon: input["icon"],
              commands: input["commands"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
    },
    form: {
      list: (input?: FormListInput, requestOptions?: RequestOptions) =>
        request<FormListOutput>(
          {
            method: "GET",
            path: `/api/form`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
    },
    permission: {
      request: {
        list: (input?: PermissionRequestListInput, requestOptions?: RequestOptions) =>
          request<PermissionRequestListOutput>(
            {
              method: "GET",
              path: `/api/permission/request`,
              query: { location: input?.["location"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ),
      },
      saved: {
        list: (input?: PermissionSavedListInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: PermissionSavedListOutput }>(
            {
              method: "GET",
              path: `/api/permission/saved`,
              query: { projectID: input?.["projectID"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        update: (input: PermissionSavedUpdateInput, requestOptions?: RequestOptions) =>
          request<{ readonly data: PermissionSavedUpdateOutput }>(
            {
              method: "PATCH",
              path: `/api/permission/saved/${encodeURIComponent(input.id)}`,
              body: { action: input["action"], resource: input["resource"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404, 409],
              empty: false,
            },
            requestOptions,
          ).then((value) => value.data),
        remove: (input: PermissionSavedRemoveInput, requestOptions?: RequestOptions) =>
          request<PermissionSavedRemoveOutput>(
            {
              method: "DELETE",
              path: `/api/permission/saved/${encodeURIComponent(input.id)}`,
              successStatus: 204,
              declaredStatuses: [400, 401],
              empty: true,
            },
            requestOptions,
          ),
      },
      create: (input: PermissionCreateInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: PermissionCreateOutput }>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/permission`,
            body: {
              id: input["id"],
              action: input["action"],
              resources: input["resources"],
              save: input["save"],
              metadata: input["metadata"],
              source: input["source"],
              agent: input["agent"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      list: (input: PermissionListInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: PermissionListOutput }>(
          {
            method: "GET",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/permission`,
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      get: (input: PermissionGetInput, requestOptions?: RequestOptions) =>
        request<{ readonly data: PermissionGetOutput }>(
          {
            method: "GET",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/permission/${encodeURIComponent(input.requestID)}`,
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ).then((value) => value.data),
      reply: (input: PermissionReplyInput, requestOptions?: RequestOptions) =>
        request<PermissionReplyOutput>(
          {
            method: "POST",
            path: `/api/session/${encodeURIComponent(input.sessionID)}/permission/${encodeURIComponent(input.requestID)}/reply`,
            body: { decision: input["decision"], message: input["message"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
    },
    file: {
      read: (input: FileReadInput, requestOptions?: RequestOptions) =>
        request<FileReadOutput>(
          {
            method: "GET",
            path: `/api/fs/read/${encodePath(input.path)}`,
            query: { location: input["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
            binary: true,
          },
          requestOptions,
        ),
      list: (input?: FileListInput, requestOptions?: RequestOptions) =>
        request<FileListOutput>(
          {
            method: "GET",
            path: `/api/fs/list`,
            query: { location: input?.["location"], path: input?.["path"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      find: (input: FileFindInput, requestOptions?: RequestOptions) =>
        request<FileFindOutput>(
          {
            method: "GET",
            path: `/api/fs/find`,
            query: { location: input["location"], query: input["query"], type: input["type"], limit: input["limit"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
    },
    command: {
      list: (input?: CommandListInput, requestOptions?: RequestOptions) =>
        request<CommandListOutput>(
          {
            method: "GET",
            path: `/api/command`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
    },
    skill: {
      list: (input?: SkillListInput, requestOptions?: RequestOptions) =>
        request<SkillListOutput>(
          {
            method: "GET",
            path: `/api/skill`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
    },
    rpc: {
      call: (input: RpcCallInput, requestOptions?: RequestOptions) =>
        request<RpcCallOutput>(
          {
            method: "POST",
            path: `/api/rpc/${encodeURIComponent(input.rpcID)}/${encodeURIComponent(input.method)}`,
            query: { location: input["location"] },
            body: { input: input["input"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 500],
            empty: false,
          },
          requestOptions,
        ),
    },
    event: {
      subscribe: (input?: EventSubscribeInput, requestOptions?: RequestOptions): AsyncIterable<EventSubscribeOutput> =>
        sse<EventSubscribeOutput>(
          {
            method: "GET",
            path: `/api/event`,
            query: { types: input?.["types"] },
            successStatus: 200,
            declaredStatuses: [400, 401],
            empty: false,
          },
          requestOptions,
        ),
    },
    pty: {
      list: (input?: PtyListInput, requestOptions?: RequestOptions) =>
        request<PtyListOutput>(
          {
            method: "GET",
            path: `/api/pty`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      create: (input?: PtyCreateInput, requestOptions?: RequestOptions) =>
        request<PtyCreateOutput>(
          {
            method: "POST",
            path: `/api/pty`,
            query: { location: input?.["location"] },
            body: {
              command: input?.["command"],
              args: input?.["args"],
              cwd: input?.["cwd"],
              title: input?.["title"],
              env: input?.["env"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      get: (input: PtyGetInput, requestOptions?: RequestOptions) =>
        request<PtyGetOutput>(
          {
            method: "GET",
            path: `/api/pty/${encodeURIComponent(input.ptyID)}`,
            query: { location: input["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      update: (input: PtyUpdateInput, requestOptions?: RequestOptions) =>
        request<PtyUpdateOutput>(
          {
            method: "PUT",
            path: `/api/pty/${encodeURIComponent(input.ptyID)}`,
            query: { location: input["location"] },
            body: { title: input["title"], size: input["size"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      remove: (input: PtyRemoveInput, requestOptions?: RequestOptions) =>
        request<PtyRemoveOutput>(
          {
            method: "DELETE",
            path: `/api/pty/${encodeURIComponent(input.ptyID)}`,
            query: { location: input["location"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
      connect: {
        token: (input: PtyConnectTokenInput, requestOptions?: RequestOptions) =>
          request<PtyConnectTokenOutput>(
            {
              method: "POST",
              path: `/api/pty/${encodeURIComponent(input.ptyID)}/connect-token`,
              query: { location: input["location"] },
              headers: { "x-opencode-ticket": input["x-opencode-ticket"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 403, 404],
              empty: false,
            },
            requestOptions,
          ),
      },
    },
    shell: {
      list: (input?: ShellListInput, requestOptions?: RequestOptions) =>
        request<ShellListOutput>(
          {
            method: "GET",
            path: `/api/shell`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      create: (input: ShellCreateInput, requestOptions?: RequestOptions) =>
        request<ShellCreateOutput>(
          {
            method: "POST",
            path: `/api/shell`,
            query: { location: input["location"] },
            body: {
              command: input["command"],
              cwd: input["cwd"],
              timeout: input["timeout"],
              metadata: input["metadata"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      get: (input: ShellGetInput, requestOptions?: RequestOptions) =>
        request<ShellGetOutput>(
          {
            method: "GET",
            path: `/api/shell/${encodeURIComponent(input.id)}`,
            query: { location: input["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      output: (input: ShellOutputInput, requestOptions?: RequestOptions) =>
        request<ShellOutputOutput>(
          {
            method: "GET",
            path: `/api/shell/${encodeURIComponent(input.id)}/output`,
            query: { location: input["location"], cursor: input["cursor"], limit: input["limit"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      remove: (input: ShellRemoveInput, requestOptions?: RequestOptions) =>
        request<ShellRemoveOutput>(
          {
            method: "DELETE",
            path: `/api/shell/${encodeURIComponent(input.id)}`,
            query: { location: input["location"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
    },
    reference: {
      list: (input?: ReferenceListInput, requestOptions?: RequestOptions) =>
        request<ReferenceListOutput>(
          {
            method: "GET",
            path: `/api/reference`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
    },
    worktree: {
      list: (input: WorktreeListInput, requestOptions?: RequestOptions) =>
        request<WorktreeListOutput>(
          {
            method: "GET",
            path: `/api/worktree`,
            query: { projectID: input["projectID"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      create: (input: WorktreeCreateInput, requestOptions?: RequestOptions) =>
        request<WorktreeCreateOutput>(
          {
            method: "POST",
            path: `/api/worktree`,
            body: {
              projectID: input["projectID"],
              from: input["from"],
              branch: input["branch"],
              directory: input["directory"],
              name: input["name"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      remove: (input: WorktreeRemoveInput, requestOptions?: RequestOptions) =>
        request<WorktreeRemoveOutput>(
          {
            method: "DELETE",
            path: `/api/worktree`,
            body: { projectID: input["projectID"], directory: input["directory"], force: input["force"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
      refresh: (input: WorktreeRefreshInput, requestOptions?: RequestOptions) =>
        request<WorktreeRefreshOutput>(
          {
            method: "POST",
            path: `/api/worktree/refresh`,
            body: { projectID: input["projectID"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404],
            empty: true,
          },
          requestOptions,
        ),
    },
    vcs: {
      init: (input?: VcsInitInput, requestOptions?: RequestOptions) =>
        request<VcsInitOutput>(
          {
            method: "POST",
            path: `/api/vcs/init`,
            query: { location: input?.["location"], provider: input?.["provider"] },
            successStatus: 204,
            declaredStatuses: [400, 401, 404, 409, 501, 503],
            empty: true,
          },
          requestOptions,
        ),
      get: (input?: VcsGetInput, requestOptions?: RequestOptions) =>
        request<VcsGetOutput>(
          {
            method: "GET",
            path: `/api/vcs`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      base: (input?: VcsBaseInput, requestOptions?: RequestOptions) =>
        request<VcsBaseOutput>(
          {
            method: "GET",
            path: `/api/vcs/base`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 503],
            empty: false,
          },
          requestOptions,
        ),
      status: (input?: VcsStatusInput, requestOptions?: RequestOptions) =>
        request<VcsStatusOutput>(
          {
            method: "GET",
            path: `/api/vcs/status`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      branch: {
        list: (input?: VcsBranchListInput, requestOptions?: RequestOptions) =>
          request<VcsBranchListOutput>(
            {
              method: "GET",
              path: `/api/vcs/branch`,
              query: { location: input?.["location"], search: input?.["search"], limit: input?.["limit"] },
              successStatus: 200,
              declaredStatuses: [400, 401, 404],
              empty: false,
            },
            requestOptions,
          ),
      },
      diff: (input: VcsDiffInput, requestOptions?: RequestOptions) =>
        request<VcsDiffOutput>(
          {
            method: "GET",
            path: `/api/vcs/diff`,
            query: {
              location: input["location"],
              mode: input["mode"],
              base: input["base"],
              context: input["context"],
              untracked: input["untracked"],
            },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 503],
            empty: false,
          },
          requestOptions,
        ),
    },
    debug: {
      heapDump: (input?: DebugHeapDumpInput, requestOptions?: RequestOptions) =>
        request<DebugHeapDumpOutput>(
          {
            method: "POST",
            path: `/api/debug/heap-dump`,
            query: { directory: input?.["directory"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 500],
            empty: false,
          },
          requestOptions,
        ),
      location: {
        list: (requestOptions?: RequestOptions) =>
          request<DebugLocationListOutput>(
            {
              method: "GET",
              path: `/api/debug/location`,
              successStatus: 200,
              declaredStatuses: [400, 401],
              empty: false,
            },
            requestOptions,
          ),
        evict: (input?: DebugLocationEvictInput, requestOptions?: RequestOptions) =>
          request<DebugLocationEvictOutput>(
            {
              method: "DELETE",
              path: `/api/debug/location`,
              query: { location: input?.["location"] },
              successStatus: 204,
              declaredStatuses: [400, 401],
              empty: true,
            },
            requestOptions,
          ),
      },
    },
    websearch: {
      providers: (input?: WebsearchProvidersInput, requestOptions?: RequestOptions) =>
        request<WebsearchProvidersOutput>(
          {
            method: "GET",
            path: `/api/websearch/provider`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 503],
            empty: false,
          },
          requestOptions,
        ),
      query: (input: WebsearchQueryInput, requestOptions?: RequestOptions) =>
        request<WebsearchQueryOutput>(
          {
            method: "POST",
            path: `/api/websearch`,
            query: { location: input["location"] },
            body: { query: input["query"], providerID: input["providerID"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404, 503],
            empty: false,
          },
          requestOptions,
        ),
    },
    config: {
      get: (input?: ConfigGetInput, requestOptions?: RequestOptions) =>
        request<ConfigGetOutput>(
          {
            method: "GET",
            path: `/api/config`,
            query: { location: input?.["location"] },
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
      shells: (requestOptions?: RequestOptions) =>
        request<ConfigShellsOutput>(
          {
            method: "GET",
            path: `/api/config/shell`,
            successStatus: 200,
            declaredStatuses: [400, 401, 404],
            empty: false,
          },
          requestOptions,
        ),
    },
  }
  return {
    ...client,
    session: {
      ...client.session,
      /** @deprecated Use `client.experimental.session.stats`. Removed in the next minor. */
      stats: client.experimental.session.stats,
      /** @deprecated Use `client.experimental.session.import`. Removed in the next minor. */
      import: client.experimental.session.import,
      /** @deprecated Use `client.experimental.session.export`. Removed in the next minor. */
      export: client.experimental.session.export,
      /** @deprecated Use `client.experimental.session.skill`. Removed in the next minor. */
      skill: client.experimental.session.skill,
      /** @deprecated Use `client.experimental.session.wait`. Removed in the next minor. */
      wait: client.experimental.session.wait,
      /** @deprecated Use `client.experimental.session.instructions`. Removed in the next minor. */
      instructions: {
        /** @deprecated Use `client.experimental.session.instructions.entry`. Removed in the next minor. */
        entry: {
          /** @deprecated Use `client.experimental.session.instructions.entry.list`. Removed in the next minor. */
          list: client.experimental.session.instructions.entry.list,
          /** @deprecated Use `client.experimental.session.instructions.entry.put`. Removed in the next minor. */
          put: client.experimental.session.instructions.entry.put,
          /** @deprecated Use `client.experimental.session.instructions.entry.remove`. Removed in the next minor. */
          remove: client.experimental.session.instructions.entry.remove,
        },
      },
      /** @deprecated Use `client.experimental.session.log`. Removed in the next minor. */
      log: client.experimental.session.log,
    },
    /** @deprecated Use `client.experimental.generate`. Removed in the next minor. */
    generate: {
      /** @deprecated Use `client.experimental.generate.text`. Removed in the next minor. */
      text: client.experimental.generate.text,
      /** @deprecated Use `client.experimental.generate.image`. Removed in the next minor. */
      image: client.experimental.generate.image,
      /** @deprecated Use `client.experimental.generate.decisions`. Removed in the next minor. */
      decisions: client.experimental.generate.decisions,
    },
    /** @deprecated Use `client.experimental.voice`. Removed in the next minor. */
    voice: {
      /** @deprecated Use `client.experimental.voice.models`. Removed in the next minor. */
      models: client.experimental.voice.models,
      /** @deprecated Use `client.experimental.voice.session`. Removed in the next minor. */
      session: client.experimental.voice.session,
    },
    transcription: {
      ...client.transcription,
      /** @deprecated Use `client.experimental.transcription.transcribeWithOverrides`. Removed in the next minor. */
      transcribeWithOverrides: client.experimental.transcription.transcribeWithOverrides,
    },
    integration: {
      ...client.integration,
      /** @deprecated Use `client.experimental.integration.wellknown`. Removed in the next minor. */
      wellknown: {
        /** @deprecated Use `client.experimental.integration.wellknown.add`. Removed in the next minor. */
        add: client.experimental.integration.wellknown.add,
      },
    },
    mcp: {
      ...client.mcp,
      /** @deprecated Use `client.experimental.mcp.add`. Removed in the next minor. */
      add: client.experimental.mcp.add,
      /** @deprecated Use `client.experimental.mcp.remove`. Removed in the next minor. */
      remove: client.experimental.mcp.remove,
      /** @deprecated Use `client.experimental.mcp.connect`. Removed in the next minor. */
      connect: client.experimental.mcp.connect,
      /** @deprecated Use `client.experimental.mcp.disconnect`. Removed in the next minor. */
      disconnect: client.experimental.mcp.disconnect,
      /** @deprecated Use `client.experimental.mcp.client`. Removed in the next minor. */
      client: {
        /** @deprecated Use `client.experimental.mcp.client.token`. Removed in the next minor. */
        token: client.experimental.mcp.client.token,
      },
    },
    file: {
      ...client.file,
      /** @deprecated Use `client.experimental.file.write`. Removed in the next minor. */
      write: client.experimental.file.write,
      /** @deprecated Use `client.experimental.file.watch`. Removed in the next minor. */
      watch: client.experimental.file.watch,
      /** @deprecated Use `client.experimental.file.unwatch`. Removed in the next minor. */
      unwatch: client.experimental.file.unwatch,
    },
    /** @deprecated Use `client.experimental.migration`. Removed in the next minor. */
    migration: {
      /** @deprecated Use `client.experimental.migration.v1`. Removed in the next minor. */
      v1: {
        /** @deprecated Use `client.experimental.migration.v1.status`. Removed in the next minor. */
        status: client.experimental.migration.v1.status,
      },
    },
    /** @deprecated Use `client.experimental.usage`. Removed in the next minor. */
    usage: {
      /** @deprecated Use `client.experimental.usage.limits`. Removed in the next minor. */
      limits: client.experimental.usage.limits,
    },
    config: {
      ...client.config,
      /** @deprecated Use `client.experimental.config.update`. Removed in the next minor. */
      update: client.experimental.config.update,
    },
  }
}

function encodePath(value: string): string {
  return value.split("/").map(encodeURIComponent).join("/")
}

function appendQuery(params: URLSearchParams, key: string, value: unknown): void {
  if (value === undefined) return
  if (value === null) {
    params.append(key, "null")
    return
  }
  if (Array.isArray(value)) {
    for (const item of value) appendQuery(params, key, item)
    return
  }
  if (typeof value === "object") {
    for (const [child, item] of Object.entries(value)) appendQuery(params, `${key}[${child}]`, item)
    return
  }
  params.append(key, String(value))
}

async function json(response: Response): Promise<unknown> {
  if (!isContentType(response, "application/json") && !response.headers.get("content-type")?.includes("+json")) {
    try {
      await response.body?.cancel()
    } catch {}
    throw new ClientError("UnsupportedContentType", { detail: response.headers.get("content-type") })
  }
  let text: string
  try {
    text = await response.text()
  } catch (cause) {
    throw new ClientError("Transport", { cause })
  }
  if (text === "") throw new ClientError("MalformedResponse")
  try {
    return JSON.parse(text)
  } catch (cause) {
    throw new ClientError("MalformedResponse", { cause })
  }
}

type DeclaredErrorBody = {
  readonly _tag?: string
  readonly message?: string
  readonly data?: { readonly message?: string }
}

/** Throw declared error bodies as Errors. The body's fields stay on the error, so narrowing on `_tag` or `name` still works. */
function declared(body: DeclaredErrorBody) {
  const error = Object.assign(new Error(body.message ?? body.data?.message), body)
  if (body._tag) error.name = body._tag
  return error
}

function isContentType(response: Response, expected: string) {
  return response.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() === expected
}
