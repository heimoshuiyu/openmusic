import { type Accessor } from "solid-js";
import type { Data } from "./data";
export declare function createSessionRetention(input: {
    session: Pick<Data["session"], "list" | "root" | "evict"> & {
        message?: Pick<Data["session"]["message"], "list">;
    };
    current: Accessor<string | undefined>;
    keep: Accessor<readonly string[]>;
    limit: number;
}): void;
