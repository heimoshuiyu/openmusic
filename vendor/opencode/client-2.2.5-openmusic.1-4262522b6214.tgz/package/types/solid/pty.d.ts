import { Schema } from "effect";
import type { ExperimentalPersistentPtyConnectTokenInput, OpenCodeClient } from "../promise";
export declare const PersistentPtyMessage: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"attached">;
    readonly inputProtocol: Schema.optional<Schema.Number>;
    readonly info: Schema.Struct<{
        readonly size: Schema.Struct<{
            readonly cols: Schema.Int;
            readonly rows: Schema.Int;
        }>;
    }>;
    readonly role: Schema.optional<Schema.Literals<readonly ["controller", "observer"]>>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"replay_complete">;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"resized">;
    readonly cols: Schema.Number;
    readonly rows: Schema.Number;
    readonly checkpoint: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"controller_changed">;
    readonly attachmentID: Schema.optional<Schema.NullOr<Schema.String>>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"exited">;
    readonly exitCode: Schema.optional<Schema.NullOr<Schema.Number>>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"title_changed">;
    readonly title: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"foreground_process_changed">;
    readonly process: Schema.NullOr<Schema.String>;
}>]>;
export type PersistentPtyMessage = typeof PersistentPtyMessage.Type;
export declare function decodePersistentPtyMessage(text: string): import("effect/Option").Option<{
    readonly type: "replay_complete";
} | {
    readonly type: "resized";
    readonly cols: number;
    readonly rows: number;
    readonly checkpoint: string;
} | {
    readonly type: "title_changed";
    readonly title: string;
} | {
    readonly type: "foreground_process_changed";
    readonly process: string | null;
} | {
    readonly type: "attached";
    readonly inputProtocol?: number | undefined;
    readonly info: {
        readonly size: {
            readonly cols: number;
            readonly rows: number;
        };
    };
    readonly role?: "controller" | "observer" | undefined;
} | {
    readonly type: "controller_changed";
    readonly attachmentID?: string | null | undefined;
} | {
    readonly type: "exited";
    readonly exitCode?: number | null | undefined;
}>;
export declare function persistentPtyFrame(size: {
    cols: number;
    rows: number;
}, data?: Uint8Array): Uint8Array<ArrayBuffer>;
export type PtyClientOptions = {
    readonly url: string;
    readonly openSocket?: (url: URL) => WebSocket;
};
export type PersistentPtyConnectInput = {
    readonly ptyID: ExperimentalPersistentPtyConnectTokenInput["ptyID"];
    readonly cursor: number;
    readonly attachmentID: string;
    readonly takeover?: boolean;
};
export declare function createPersistentPtyClient(api: OpenCodeClient, options: PtyClientOptions): {
    connect(input: PersistentPtyConnectInput): Promise<WebSocket>;
};
