export * as RpcRuntime from "./rpc-runtime.js";
import type { Rpc } from "@opencode/schema/rpc";
import { Effect, Schema } from "effect";
export declare function read(schema: Rpc.Method["output"], value: unknown): Effect.Effect<unknown, Schema.SchemaError, never>;
export declare function readError(method: Rpc.Method, error: unknown): Effect.Effect<never, unknown>;
export declare const event: <D extends Rpc.Definition, Name extends keyof D["events"] & string>(definition: D, name: Name, schema: Rpc.EventDefinition, event: {
    readonly id: string & import("effect/Brand").Brand<"Event.ID">;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: `rpc.${string}`;
    readonly location: {
        readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
    };
    readonly data: {
        readonly [x: string]: unknown;
    };
}) => Effect.Effect<Rpc.EventPayload<D, Name>, unknown, never>;
export declare function eventType<const D extends Rpc.Definition, const Name extends keyof D["events"] & string>(definition: D, name: Name): `rpc.${D["id"]}.${Name}`;
