import type { make, RequestOptions } from "./client.js";
import type { MessageListInput, SessionInboxListInput, SessionMessageGetInput } from "./generated/types.js";
/** `mediaRefs: false` reads stored media as inline bytes, for callers such as export that need self-contained messages. */
export type MediaRequestOptions = RequestOptions & {
    readonly mediaRefs?: false;
};
/** The blob hash in a `media:<hash>` ref, the only form the server sends stored media in. */
export declare function mediaHashFromUri(uri: string | undefined): string | undefined;
/**
 * Opts a client into the experimental `experimental-media-uri` capability: while `experimental.media_blob` is on,
 * stored media comes back as `media:<hash>` refs, whose bytes `experimental.media.get` reads.
 *
 * Only the message and inbox reads can return refs, so only they carry the capability.
 * A custom header makes a cross-origin request preflighted, which every other request must keep avoiding.
 */
export declare function withMediaRefs(api: ReturnType<typeof make>): {
    server: {
        info: (requestOptions?: RequestOptions) => Promise<import("./index.js").ServerInfo>;
        pair: (requestOptions?: RequestOptions) => Promise<import("./index.js").PairingCode>;
        connect: (input: import("./index.js").ServerConnectInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PairingSession>;
    };
    location: {
        get: (input?: import("./index.js").LocationGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").LocationPublicInfo>;
        reload: (requestOptions?: RequestOptions) => Promise<void>;
    };
    agent: {
        list: (input?: import("./index.js").AgentListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").AgentListOutput>;
        get: (input: import("./index.js").AgentGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").AgentGetOutput>;
    };
    plugin: {
        list: (input?: import("./index.js").PluginListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PluginListOutput>;
        gui: (input: import("./index.js").PluginGuiInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PluginGuiOutput>;
        check: (input?: import("./index.js").PluginCheckInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PluginCheckOutput>;
        update: (input: import("./index.js").PluginUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    experimental: {
        session: {
            stats: (input?: import("./index.js").ExperimentalSessionStatsInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionStatsInfo>;
            import: (input: import("./index.js").ExperimentalSessionImportInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionInfo>;
            export: (input: import("./index.js").ExperimentalSessionExportInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionTransferData>;
            skill: (input: import("./index.js").ExperimentalSessionSkillInput, requestOptions?: RequestOptions) => Promise<void>;
            wait: (input: import("./index.js").ExperimentalSessionWaitInput, requestOptions?: RequestOptions) => Promise<void>;
            instructions: {
                entry: {
                    list: (input: import("./index.js").ExperimentalSessionInstructionsEntryListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").InstructionEntryInfo[]>;
                    put: (input: import("./index.js").ExperimentalSessionInstructionsEntryPutInput, requestOptions?: RequestOptions) => Promise<void>;
                    remove: (input: import("./index.js").ExperimentalSessionInstructionsEntryRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
                };
            };
            log: (input: import("./index.js").ExperimentalSessionLogInput, requestOptions?: RequestOptions) => AsyncIterable<import("./index.js").ExperimentalSessionLogOutput>;
        };
        generate: {
            text: (input: import("./index.js").ExperimentalGenerateTextInput, requestOptions?: RequestOptions) => Promise<{
                text: string;
            }>;
            image: (input: import("./index.js").ExperimentalGenerateImageInput, requestOptions?: RequestOptions) => Promise<import("./index.js").GenerateImageResult>;
            decisions: (input: import("./index.js").ExperimentalGenerateDecisionsInput, requestOptions?: RequestOptions) => Promise<import("./index.js").GenerateDecisionResult>;
        };
        voice: {
            models: (requestOptions?: RequestOptions) => Promise<{
                models: Array<import("./index.js").VoiceModel>;
                default?: string | undefined;
            }>;
            session: (input: import("./index.js").ExperimentalVoiceSessionInput, requestOptions?: RequestOptions) => Promise<{
                transport: import("./index.js").VoiceTransport;
            }>;
        };
        transcription: {
            transcribeWithOverrides: (input: import("./index.js").ExperimentalTranscriptionTranscribeWithOverridesInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalTranscriptionTranscribeWithOverridesOutput>;
        };
        integration: {
            wellknown: {
                add: (input: import("./index.js").ExperimentalIntegrationWellknownAddInput, requestOptions?: RequestOptions) => Promise<void>;
            };
        };
        mcp: {
            add: (input: import("./index.js").ExperimentalMcpAddInput, requestOptions?: RequestOptions) => Promise<void>;
            remove: (input: import("./index.js").ExperimentalMcpRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
            connect: (input: import("./index.js").ExperimentalMcpConnectInput, requestOptions?: RequestOptions) => Promise<void>;
            disconnect: (input: import("./index.js").ExperimentalMcpDisconnectInput, requestOptions?: RequestOptions) => Promise<void>;
            client: {
                token: (input: import("./index.js").ExperimentalMcpClientTokenInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalMcpClientTokenOutput>;
            };
        };
        file: {
            write: (input: import("./index.js").ExperimentalFileWriteInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalFileWriteOutput>;
            watch: (input: import("./index.js").ExperimentalFileWatchInput, requestOptions?: RequestOptions) => Promise<void>;
            unwatch: (input: import("./index.js").ExperimentalFileUnwatchInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        persistentPty: {
            read: (input: import("./index.js").ExperimentalPersistentPtyReadInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PersistentPtyReadResult | null>;
            list: (input: import("./index.js").ExperimentalPersistentPtyListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PersistentPtyInfo[]>;
            create: (input: import("./index.js").ExperimentalPersistentPtyCreateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PersistentPtyInfo>;
            shutdown: (requestOptions?: RequestOptions) => Promise<void>;
            handoff: (requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalPersistentPtyHandoffOutput>;
            get: (input: import("./index.js").ExperimentalPersistentPtyGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PersistentPtyInfo>;
            update: (input: import("./index.js").ExperimentalPersistentPtyUpdateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PersistentPtyInfo>;
            snapshot: (input: import("./index.js").ExperimentalPersistentPtySnapshotInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PersistentPtySnapshot>;
            remove: (input: import("./index.js").ExperimentalPersistentPtyRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
            connectToken: (input: import("./index.js").ExperimentalPersistentPtyConnectTokenInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PtyTicketConnectToken>;
        };
        media: {
            get: (input: import("./index.js").ExperimentalMediaGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalMediaGetOutput>;
        };
        schedule: {
            create: (input: import("./index.js").ExperimentalScheduleCreateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ScheduleInfo>;
            list: (input: import("./index.js").ExperimentalScheduleListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ScheduleInfo[]>;
            get: (input: import("./index.js").ExperimentalScheduleGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ScheduleInfo>;
            pause: (input: import("./index.js").ExperimentalSchedulePauseInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ScheduleInfo>;
            resume: (input: import("./index.js").ExperimentalScheduleResumeInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ScheduleInfo>;
            delete: (input: import("./index.js").ExperimentalScheduleDeleteInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        artifacts: {
            providers: (input?: import("./index.js").ExperimentalArtifactsProvidersInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalArtifactsProvidersOutput>;
            list: (input?: import("./index.js").ExperimentalArtifactsListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalArtifactsListOutput>;
            create: (input: import("./index.js").ExperimentalArtifactsCreateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalArtifactsCreateOutput>;
            get: (input: import("./index.js").ExperimentalArtifactsGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalArtifactsGetOutput>;
            update: (input: import("./index.js").ExperimentalArtifactsUpdateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalArtifactsUpdateOutput>;
            delete: (input: import("./index.js").ExperimentalArtifactsDeleteInput, requestOptions?: RequestOptions) => Promise<void>;
            view: (input: import("./index.js").ExperimentalArtifactsViewInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalArtifactsViewOutput>;
        };
        job: {
            list: (input?: import("./index.js").ExperimentalJobListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").JobInfo[]>;
        };
        plugin: {
            webList: (requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalPluginWebListOutput>;
            webModule: (input: import("./index.js").ExperimentalPluginWebModuleInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalPluginWebModuleOutput>;
        };
        migration: {
            v1: {
                status: (requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalMigrationV1StatusOutput>;
            };
        };
        usage: {
            limits: (input?: import("./index.js").ExperimentalUsageLimitsInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalUsageLimitsOutput>;
        };
        config: {
            update: (input: import("./index.js").ExperimentalConfigUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
        };
    };
    model: {
        list: (input?: import("./index.js").ModelListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ModelListOutput>;
        default: (input?: import("./index.js").ModelDefaultInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ModelDefaultOutput>;
    };
    provider: {
        list: (input?: import("./index.js").ProviderListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ProviderListOutput>;
        get: (input: import("./index.js").ProviderGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ProviderGetOutput>;
    };
    credential: {
        list: (requestOptions?: RequestOptions) => Promise<import("./index.js").CredentialEntry[]>;
        create: (input: import("./index.js").CredentialCreateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").CredentialEntry>;
        update: (input: import("./index.js").CredentialUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
        activate: (input: import("./index.js").CredentialActivateInput, requestOptions?: RequestOptions) => Promise<void>;
        remove: (input: import("./index.js").CredentialRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    project: {
        list: (input?: import("./index.js").ProjectListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ProjectListOutput>;
        update: (input: import("./index.js").ProjectUpdateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").Project>;
    };
    form: {
        list: (input?: import("./index.js").FormListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").FormListOutput>;
    };
    permission: {
        request: {
            list: (input?: import("./index.js").PermissionRequestListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PermissionRequestListOutput>;
        };
        saved: {
            list: (input?: import("./index.js").PermissionSavedListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PermissionSavedInfo[]>;
            update: (input: import("./index.js").PermissionSavedUpdateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PermissionSavedInfo>;
            remove: (input: import("./index.js").PermissionSavedRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        create: (input: import("./index.js").PermissionCreateInput, requestOptions?: RequestOptions) => Promise<{
            id: import("./index.js").PermissionID;
            effect: import("./index.js").PermissionEffect;
        }>;
        list: (input: import("./index.js").PermissionListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PermissionRequest[]>;
        get: (input: import("./index.js").PermissionGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PermissionRequest>;
        reply: (input: import("./index.js").PermissionReplyInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    command: {
        list: (input?: import("./index.js").CommandListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").CommandListOutput>;
    };
    skill: {
        list: (input?: import("./index.js").SkillListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SkillListOutput>;
    };
    pty: {
        list: (input?: import("./index.js").PtyListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PtyListOutput>;
        create: (input?: import("./index.js").PtyCreateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PtyCreateOutput>;
        get: (input: import("./index.js").PtyGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PtyGetOutput>;
        update: (input: import("./index.js").PtyUpdateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PtyUpdateOutput>;
        remove: (input: import("./index.js").PtyRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
        connect: {
            token: (input: import("./index.js").PtyConnectTokenInput, requestOptions?: RequestOptions) => Promise<import("./index.js").PtyConnectTokenOutput>;
        };
    };
    shell: {
        list: (input?: import("./index.js").ShellListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ShellListOutput>;
        create: (input: import("./index.js").ShellCreateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ShellCreateOutput>;
        get: (input: import("./index.js").ShellGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ShellGetOutput>;
        output: (input: import("./index.js").ShellOutputInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ShellOutputOutput>;
        remove: (input: import("./index.js").ShellRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    reference: {
        list: (input?: import("./index.js").ReferenceListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ReferenceListOutput>;
    };
    worktree: {
        list: (input: import("./index.js").WorktreeListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").WorktreeList>;
        create: (input: import("./index.js").WorktreeCreateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").WorktreeInfo>;
        remove: (input: import("./index.js").WorktreeRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
        refresh: (input: import("./index.js").WorktreeRefreshInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    vcs: {
        init: (input?: import("./index.js").VcsInitInput, requestOptions?: RequestOptions) => Promise<void>;
        get: (input?: import("./index.js").VcsGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").VcsGetOutput>;
        base: (input?: import("./index.js").VcsBaseInput, requestOptions?: RequestOptions) => Promise<import("./index.js").VcsBaseOutput>;
        status: (input?: import("./index.js").VcsStatusInput, requestOptions?: RequestOptions) => Promise<import("./index.js").VcsStatusOutput>;
        branch: {
            list: (input?: import("./index.js").VcsBranchListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").VcsBranchListOutput>;
        };
        diff: (input: import("./index.js").VcsDiffInput, requestOptions?: RequestOptions) => Promise<import("./index.js").VcsDiffOutput>;
    };
    debug: {
        heapDump: (input?: import("./index.js").DebugHeapDumpInput, requestOptions?: RequestOptions) => Promise<import("./index.js").DebugHeapDumpOutput>;
        location: {
            list: (requestOptions?: RequestOptions) => Promise<import("./index.js").DebugLocationListOutput>;
            evict: (input?: import("./index.js").DebugLocationEvictInput, requestOptions?: RequestOptions) => Promise<void>;
        };
    };
    websearch: {
        providers: (input?: import("./index.js").WebsearchProvidersInput, requestOptions?: RequestOptions) => Promise<import("./index.js").WebsearchProvidersOutput>;
        query: (input: import("./index.js").WebsearchQueryInput, requestOptions?: RequestOptions) => Promise<import("./index.js").WebsearchQueryOutput>;
    };
    generate: {
        text: (input: import("./index.js").ExperimentalGenerateTextInput, requestOptions?: RequestOptions) => Promise<{
            text: string;
        }>;
        image: (input: import("./index.js").ExperimentalGenerateImageInput, requestOptions?: RequestOptions) => Promise<import("./index.js").GenerateImageResult>;
        decisions: (input: import("./index.js").ExperimentalGenerateDecisionsInput, requestOptions?: RequestOptions) => Promise<import("./index.js").GenerateDecisionResult>;
    };
    voice: {
        models: (requestOptions?: RequestOptions) => Promise<{
            models: Array<import("./index.js").VoiceModel>;
            default?: string | undefined;
        }>;
        session: (input: import("./index.js").ExperimentalVoiceSessionInput, requestOptions?: RequestOptions) => Promise<{
            transport: import("./index.js").VoiceTransport;
        }>;
    };
    transcription: {
        transcribe: (input: import("./index.js").TranscriptionTranscribeInput, requestOptions?: RequestOptions) => Promise<import("./index.js").TranscriptionTranscribeOutput>;
        transcribeWithOverrides: (input: import("./index.js").ExperimentalTranscriptionTranscribeWithOverridesInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalTranscriptionTranscribeWithOverridesOutput>;
    };
    integration: {
        list: (input?: import("./index.js").IntegrationListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").IntegrationListOutput>;
        get: (input: import("./index.js").IntegrationGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").IntegrationGetOutput>;
        connect: {
            key: (input: import("./index.js").IntegrationConnectKeyInput, requestOptions?: RequestOptions) => Promise<void>;
            external: (input: import("./index.js").IntegrationConnectExternalInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        oauth: {
            connect: (input: import("./index.js").IntegrationOauthConnectInput, requestOptions?: RequestOptions) => Promise<import("./index.js").IntegrationOauthConnectOutput>;
            status: (input: import("./index.js").IntegrationOauthStatusInput, requestOptions?: RequestOptions) => Promise<import("./index.js").IntegrationOauthStatusOutput>;
            complete: (input: import("./index.js").IntegrationOauthCompleteInput, requestOptions?: RequestOptions) => Promise<void>;
            cancel: (input: import("./index.js").IntegrationOauthCancelInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        command: {
            connect: (input: import("./index.js").IntegrationCommandConnectInput, requestOptions?: RequestOptions) => Promise<import("./index.js").IntegrationCommandConnectOutput>;
            status: (input: import("./index.js").IntegrationCommandStatusInput, requestOptions?: RequestOptions) => Promise<import("./index.js").IntegrationCommandStatusOutput>;
            cancel: (input: import("./index.js").IntegrationCommandCancelInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        wellknown: {
            add: (input: import("./index.js").ExperimentalIntegrationWellknownAddInput, requestOptions?: RequestOptions) => Promise<void>;
        };
    };
    mcp: {
        list: (input?: import("./index.js").McpListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").McpListOutput>;
        resource: {
            catalog: (input?: import("./index.js").McpResourceCatalogInput, requestOptions?: RequestOptions) => Promise<import("./index.js").McpResourceCatalogOutput>;
        };
        add: (input: import("./index.js").ExperimentalMcpAddInput, requestOptions?: RequestOptions) => Promise<void>;
        remove: (input: import("./index.js").ExperimentalMcpRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
        connect: (input: import("./index.js").ExperimentalMcpConnectInput, requestOptions?: RequestOptions) => Promise<void>;
        disconnect: (input: import("./index.js").ExperimentalMcpDisconnectInput, requestOptions?: RequestOptions) => Promise<void>;
        client: {
            token: (input: import("./index.js").ExperimentalMcpClientTokenInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalMcpClientTokenOutput>;
        };
    };
    file: {
        read: (input: import("./index.js").FileReadInput, requestOptions?: RequestOptions) => Promise<import("./index.js").FileReadOutput>;
        list: (input?: import("./index.js").FileListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").FileListOutput>;
        find: (input: import("./index.js").FileFindInput, requestOptions?: RequestOptions) => Promise<import("./index.js").FileFindOutput>;
        write: (input: import("./index.js").ExperimentalFileWriteInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalFileWriteOutput>;
        watch: (input: import("./index.js").ExperimentalFileWatchInput, requestOptions?: RequestOptions) => Promise<void>;
        unwatch: (input: import("./index.js").ExperimentalFileUnwatchInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    migration: {
        v1: {
            status: (requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalMigrationV1StatusOutput>;
        };
    };
    usage: {
        limits: (input?: import("./index.js").ExperimentalUsageLimitsInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ExperimentalUsageLimitsOutput>;
    };
    config: {
        get: (input?: import("./index.js").ConfigGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").ConfigGetOutput>;
        shells: (requestOptions?: RequestOptions) => Promise<import("./index.js").ConfigShellsOutput>;
        update: (input: import("./index.js").ExperimentalConfigUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    rpc: import("./rpc.js").RpcApi<import("./rpc.js").RpcCallOptions> & {
        call: (input: import("./index.js").RpcCallInput, requestOptions?: RequestOptions) => Promise<import("./index.js").RpcOutput>;
    };
    event: {
        subscribe<Type extends Exclude<"agent.updated" | "artifact.updated" | "command.updated" | "config.updated" | "credential.switched" | "credential.updated" | "filesystem.changed" | "form.cancelled" | "form.created" | "form.replied" | "installation.update-available" | "installation.updated" | "integration.updated" | "location.shutdown" | "mcp.resources.changed" | "mcp.status.changed" | "model.updated" | "models-dev.refreshed" | "permission.asked" | "permission.replied" | "persistent-pty.added" | "persistent-pty.removed" | "persistent-pty.updated" | "plugin.updated" | "project.updated" | "provider.updated" | "pty.created" | "pty.deleted" | "pty.exited" | "pty.updated" | "reference.updated" | "server.connected" | "session.agent.selected" | "session.archived" | "session.compaction.delta" | "session.compaction.ended" | "session.compaction.failed" | "session.compaction.started" | "session.created" | "session.deleted" | "session.execution.failed" | "session.execution.interrupted" | "session.execution.started" | "session.execution.succeeded" | "session.forked" | "session.idle" | "session.inbox.cancelled" | "session.inbox.delivered" | "session.inbox.delivery.changed" | "session.inbox.enqueued" | "session.instructions.updated" | "session.metadata.updated" | "session.model.selected" | "session.moved" | "session.permissions" | "session.reasoning.delta" | "session.reasoning.ended" | "session.reasoning.started" | "session.renamed" | "session.retry.scheduled" | "session.revert.cleared" | "session.revert.committed" | "session.revert.staged" | "session.shell.ended" | "session.shell.started" | "session.skill.activated" | "session.status" | "session.step.ended" | "session.step.failed" | "session.step.started" | "session.step.streamed" | "session.synthetic" | "session.text.delta" | "session.text.ended" | "session.text.started" | "session.tool.called" | "session.tool.failed" | "session.tool.input.delta" | "session.tool.input.ended" | "session.tool.input.started" | "session.tool.progress" | "session.tool.success" | "session.unarchived" | "session.usage.updated" | "session.viewed" | "shell.created" | "shell.deleted" | "shell.exited" | "skill.updated" | "tui.command.execute" | "tui.prompt.append" | "tui.session.select" | "tui.toast.show" | "vcs.branch.updated" | "websearch.updated" | "worktree.resolved" | "worktree.updated" | `rpc.${string}`, "server.connected"> = "agent.updated" | "artifact.updated" | "command.updated" | "config.updated" | "credential.switched" | "credential.updated" | "filesystem.changed" | "form.cancelled" | "form.created" | "form.replied" | "installation.update-available" | "installation.updated" | "integration.updated" | "location.shutdown" | "mcp.resources.changed" | "mcp.status.changed" | "model.updated" | "models-dev.refreshed" | "permission.asked" | "permission.replied" | "persistent-pty.added" | "persistent-pty.removed" | "persistent-pty.updated" | "plugin.updated" | "project.updated" | "provider.updated" | "pty.created" | "pty.deleted" | "pty.exited" | "pty.updated" | "reference.updated" | "session.agent.selected" | "session.archived" | "session.compaction.delta" | "session.compaction.ended" | "session.compaction.failed" | "session.compaction.started" | "session.created" | "session.deleted" | "session.execution.failed" | "session.execution.interrupted" | "session.execution.started" | "session.execution.succeeded" | "session.forked" | "session.idle" | "session.inbox.cancelled" | "session.inbox.delivered" | "session.inbox.delivery.changed" | "session.inbox.enqueued" | "session.instructions.updated" | "session.metadata.updated" | "session.model.selected" | "session.moved" | "session.permissions" | "session.reasoning.delta" | "session.reasoning.ended" | "session.reasoning.started" | "session.renamed" | "session.retry.scheduled" | "session.revert.cleared" | "session.revert.committed" | "session.revert.staged" | "session.shell.ended" | "session.shell.started" | "session.skill.activated" | "session.status" | "session.step.ended" | "session.step.failed" | "session.step.started" | "session.step.streamed" | "session.synthetic" | "session.text.delta" | "session.text.ended" | "session.text.started" | "session.tool.called" | "session.tool.failed" | "session.tool.input.delta" | "session.tool.input.ended" | "session.tool.input.started" | "session.tool.progress" | "session.tool.success" | "session.unarchived" | "session.usage.updated" | "session.viewed" | "shell.created" | "shell.deleted" | "shell.exited" | "skill.updated" | "tui.command.execute" | "tui.prompt.append" | "tui.session.select" | "tui.toast.show" | "vcs.branch.updated" | "websearch.updated" | "worktree.resolved" | "worktree.updated" | `rpc.${string}`>(options?: import("./api.js").SubscribeOptions<Type> | undefined): AsyncIterable<([Extract<Type, "agent.updated">] extends [never] ? never : import("./index.js").AgentUpdated) | ([Extract<Type, "artifact.updated">] extends [never] ? never : import("./index.js").ArtifactUpdated) | ([Extract<Type, "command.updated">] extends [never] ? never : import("./index.js").CommandUpdated) | ([Extract<Type, "config.updated">] extends [never] ? never : import("./index.js").ConfigUpdated) | ([Extract<Type, "credential.switched">] extends [never] ? never : import("./index.js").CredentialSwitched) | ([Extract<Type, "credential.updated">] extends [never] ? never : import("./index.js").CredentialUpdated) | ([Extract<Type, "filesystem.changed">] extends [never] ? never : import("./index.js").FilesystemChanged) | ([Extract<Type, "form.cancelled">] extends [never] ? never : import("./index.js").FormCancelled) | ([Extract<Type, "form.created">] extends [never] ? never : import("./index.js").FormCreated) | ([Extract<Type, "form.replied">] extends [never] ? never : import("./index.js").FormReplied) | ([Extract<Type, "installation.update-available">] extends [never] ? never : import("./index.js").InstallationUpdateAvailable) | ([Extract<Type, "installation.updated">] extends [never] ? never : import("./index.js").InstallationUpdated) | ([Extract<Type, "integration.updated">] extends [never] ? never : import("./index.js").IntegrationUpdated) | ([Extract<Type, "location.shutdown">] extends [never] ? never : import("./index.js").LocationShutdown) | ([Extract<Type, "mcp.resources.changed">] extends [never] ? never : import("./index.js").McpResourcesChanged) | ([Extract<Type, "mcp.status.changed">] extends [never] ? never : import("./index.js").McpStatusChanged) | ([Extract<Type, "model.updated">] extends [never] ? never : import("./index.js").ModelUpdated) | ([Extract<Type, "models-dev.refreshed">] extends [never] ? never : import("./index.js").ModelsDevRefreshed) | ([Extract<Type, "permission.asked">] extends [never] ? never : import("./index.js").PermissionAsked) | ([Extract<Type, "permission.replied">] extends [never] ? never : import("./index.js").PermissionReplied) | ([Extract<Type, "persistent-pty.added">] extends [never] ? never : import("./index.js").PersistentPtyAdded) | ([Extract<Type, "persistent-pty.removed">] extends [never] ? never : import("./index.js").PersistentPtyRemoved) | ([Extract<Type, "persistent-pty.updated">] extends [never] ? never : import("./index.js").PersistentPtyUpdated) | ([Extract<Type, "plugin.updated">] extends [never] ? never : import("./index.js").PluginUpdated) | ([Extract<Type, "project.updated">] extends [never] ? never : import("./index.js").ProjectUpdated) | ([Extract<Type, "provider.updated">] extends [never] ? never : import("./index.js").ProviderUpdated) | ([Extract<Type, "pty.created">] extends [never] ? never : import("./index.js").PtyCreated) | ([Extract<Type, "pty.deleted">] extends [never] ? never : import("./index.js").PtyDeleted) | ([Extract<Type, "pty.exited">] extends [never] ? never : import("./index.js").PtyExited) | ([Extract<Type, "pty.updated">] extends [never] ? never : import("./index.js").PtyUpdated) | ([Extract<Type, "reference.updated">] extends [never] ? never : import("./index.js").ReferenceUpdated) | ([Extract<Type, "session.agent.selected">] extends [never] ? never : import("./index.js").SessionAgentSelected) | ([Extract<Type, "session.archived">] extends [never] ? never : import("./index.js").SessionArchived) | ([Extract<Type, "session.compaction.delta">] extends [never] ? never : import("./index.js").SessionCompactionDelta) | ([Extract<Type, "session.compaction.ended">] extends [never] ? never : import("./index.js").SessionCompactionEnded) | ([Extract<Type, "session.compaction.failed">] extends [never] ? never : import("./index.js").SessionCompactionFailed) | ([Extract<Type, "session.compaction.started">] extends [never] ? never : import("./index.js").SessionCompactionStarted) | ([Extract<Type, "session.created">] extends [never] ? never : import("./index.js").SessionCreated) | ([Extract<Type, "session.deleted">] extends [never] ? never : import("./index.js").SessionDeleted) | ([Extract<Type, "session.execution.failed">] extends [never] ? never : import("./index.js").SessionExecutionFailed) | ([Extract<Type, "session.execution.interrupted">] extends [never] ? never : import("./index.js").SessionExecutionInterrupted) | ([Extract<Type, "session.execution.started">] extends [never] ? never : import("./index.js").SessionExecutionStarted) | ([Extract<Type, "session.execution.succeeded">] extends [never] ? never : import("./index.js").SessionExecutionSucceeded) | ([Extract<Type, "session.forked">] extends [never] ? never : import("./index.js").SessionForked) | ([Extract<Type, "session.idle">] extends [never] ? never : import("./index.js").SessionIdle) | ([Extract<Type, "session.inbox.cancelled">] extends [never] ? never : import("./index.js").SessionInboxCancelled) | ([Extract<Type, "session.inbox.delivered">] extends [never] ? never : import("./index.js").SessionInboxDelivered) | ([Extract<Type, "session.inbox.delivery.changed">] extends [never] ? never : import("./index.js").SessionInboxDeliveryChanged) | ([Extract<Type, "session.inbox.enqueued">] extends [never] ? never : import("./index.js").SessionInboxEnqueued) | ([Extract<Type, "session.instructions.updated">] extends [never] ? never : import("./index.js").SessionInstructionsUpdated) | ([Extract<Type, "session.metadata.updated">] extends [never] ? never : import("./index.js").SessionMetadataUpdated) | ([Extract<Type, "session.model.selected">] extends [never] ? never : import("./index.js").SessionModelSelected) | ([Extract<Type, "session.moved">] extends [never] ? never : import("./index.js").SessionMoved) | ([Extract<Type, "session.permissions">] extends [never] ? never : import("./index.js").SessionPermissions) | ([Extract<Type, "session.reasoning.delta">] extends [never] ? never : import("./index.js").SessionReasoningDelta) | ([Extract<Type, "session.reasoning.ended">] extends [never] ? never : import("./index.js").SessionReasoningEnded) | ([Extract<Type, "session.reasoning.started">] extends [never] ? never : import("./index.js").SessionReasoningStarted) | ([Extract<Type, "session.renamed">] extends [never] ? never : import("./index.js").SessionRenamed) | ([Extract<Type, "session.retry.scheduled">] extends [never] ? never : import("./index.js").SessionRetryScheduled) | ([Extract<Type, "session.revert.cleared">] extends [never] ? never : import("./index.js").SessionRevertCleared) | ([Extract<Type, "session.revert.committed">] extends [never] ? never : import("./index.js").SessionRevertCommitted) | ([Extract<Type, "session.revert.staged">] extends [never] ? never : import("./index.js").SessionRevertStaged) | ([Extract<Type, "session.shell.ended">] extends [never] ? never : import("./index.js").SessionShellEnded) | ([Extract<Type, "session.shell.started">] extends [never] ? never : import("./index.js").SessionShellStarted) | ([Extract<Type, "session.skill.activated">] extends [never] ? never : import("./index.js").SessionSkillActivated) | ([Extract<Type, "session.status">] extends [never] ? never : import("./index.js").SessionStatusUpdated) | ([Extract<Type, "session.step.ended">] extends [never] ? never : import("./index.js").SessionStepEnded) | ([Extract<Type, "session.step.failed">] extends [never] ? never : import("./index.js").SessionStepFailed) | ([Extract<Type, "session.step.started">] extends [never] ? never : import("./index.js").SessionStepStarted) | ([Extract<Type, "session.step.streamed">] extends [never] ? never : import("./index.js").SessionStepStreamed) | ([Extract<Type, "session.synthetic">] extends [never] ? never : import("./index.js").SessionSynthetic) | ([Extract<Type, "session.text.delta">] extends [never] ? never : import("./index.js").SessionTextDelta) | ([Extract<Type, "session.text.ended">] extends [never] ? never : import("./index.js").SessionTextEnded) | ([Extract<Type, "session.text.started">] extends [never] ? never : import("./index.js").SessionTextStarted) | ([Extract<Type, "session.tool.called">] extends [never] ? never : import("./index.js").SessionToolCalled) | ([Extract<Type, "session.tool.failed">] extends [never] ? never : import("./index.js").SessionToolFailed) | ([Extract<Type, "session.tool.input.delta">] extends [never] ? never : import("./index.js").SessionToolInputDelta) | ([Extract<Type, "session.tool.input.ended">] extends [never] ? never : import("./index.js").SessionToolInputEnded) | ([Extract<Type, "session.tool.input.started">] extends [never] ? never : import("./index.js").SessionToolInputStarted) | ([Extract<Type, "session.tool.progress">] extends [never] ? never : import("./index.js").SessionToolProgress) | ([Extract<Type, "session.tool.success">] extends [never] ? never : import("./index.js").SessionToolSuccess) | ([Extract<Type, "session.unarchived">] extends [never] ? never : import("./index.js").SessionUnarchived) | ([Extract<Type, "session.usage.updated">] extends [never] ? never : import("./index.js").SessionUsageUpdated) | ([Extract<Type, "session.viewed">] extends [never] ? never : import("./index.js").SessionViewed) | ([Extract<Type, "shell.created">] extends [never] ? never : import("./index.js").ShellCreated) | ([Extract<Type, "shell.deleted">] extends [never] ? never : import("./index.js").ShellDeleted) | ([Extract<Type, "shell.exited">] extends [never] ? never : import("./index.js").ShellExited) | ([Extract<Type, "skill.updated">] extends [never] ? never : import("./index.js").SkillUpdated) | ([Extract<Type, "tui.command.execute">] extends [never] ? never : import("./index.js").TuiCommandExecute) | ([Extract<Type, "tui.prompt.append">] extends [never] ? never : import("./index.js").TuiPromptAppend) | ([Extract<Type, "tui.session.select">] extends [never] ? never : import("./index.js").TuiSessionSelect) | ([Extract<Type, "tui.toast.show">] extends [never] ? never : import("./index.js").TuiToastShow) | ([Extract<Type, `rpc.${string}`>] extends [never] ? never : import("./index.js").V2EventRpc) | (["server.connected" | Extract<Type, "server.connected">] extends [never] ? never : import("./index.js").V2EventServerConnected) | ([Extract<Type, "vcs.branch.updated">] extends [never] ? never : import("./index.js").VcsBranchUpdated) | ([Extract<Type, "websearch.updated">] extends [never] ? never : import("./index.js").WebsearchUpdated) | ([Extract<Type, "worktree.resolved">] extends [never] ? never : import("./index.js").WorktreeResolved) | ([Extract<Type, "worktree.updated">] extends [never] ? never : import("./index.js").WorktreeUpdated)>;
    };
    message: {
        list: (input: MessageListInput, options?: MediaRequestOptions) => Promise<import("./index.js").SessionMessagesResponse>;
    };
    session: {
        list: (input?: import("./index.js").SessionListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionsResponse>;
        create: (input?: import("./index.js").SessionCreateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionInfo>;
        active: (requestOptions?: RequestOptions) => Promise<{
            [x: string]: import("./index.js").SessionActive;
        }>;
        get: (input: import("./index.js").SessionGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionInfo>;
        remove: (input: import("./index.js").SessionRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
        fork: (input: import("./index.js").SessionForkInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionInfo>;
        switchAgent: (input: import("./index.js").SessionSwitchAgentInput, requestOptions?: RequestOptions) => Promise<void>;
        switchModel: (input: import("./index.js").SessionSwitchModelInput, requestOptions?: RequestOptions) => Promise<void>;
        update: (input: import("./index.js").SessionUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
        move: (input: import("./index.js").SessionMoveInput, requestOptions?: RequestOptions) => Promise<void>;
        prompt: (input: import("./index.js").SessionPromptInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionInboxUser>;
        command: (input: import("./index.js").SessionCommandInput, requestOptions?: RequestOptions) => Promise<void>;
        synthetic: (input: import("./index.js").SessionSyntheticInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionInboxSynthetic>;
        shell: (input: import("./index.js").SessionShellInput, requestOptions?: RequestOptions) => Promise<void>;
        compact: (input: import("./index.js").SessionCompactInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionInboxCompaction>;
        revert: {
            stage: (input: import("./index.js").SessionRevertStageInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionRevert>;
            clear: (input: import("./index.js").SessionRevertClearInput, requestOptions?: RequestOptions) => Promise<void>;
            commit: (input: import("./index.js").SessionRevertCommitInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        context: (input: import("./index.js").SessionContextInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionMessageInfo[]>;
        diff: (input: import("./index.js").SessionDiffInput, requestOptions?: RequestOptions) => Promise<import("./index.js").FileDiffInfo[]>;
        generate: (input: import("./index.js").SessionGenerateInput, requestOptions?: RequestOptions) => Promise<{
            text: string;
        }>;
        interrupt: (input: import("./index.js").SessionInterruptInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionInterruptResponse>;
        background: (input: import("./index.js").SessionBackgroundInput, requestOptions?: RequestOptions) => Promise<void>;
        form: {
            list: (input: import("./index.js").SessionFormListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").FormInfo[]>;
            create: (input: import("./index.js").SessionFormCreateInput, requestOptions?: RequestOptions) => Promise<import("./index.js").FormInfo>;
            get: (input: import("./index.js").SessionFormGetInput, requestOptions?: RequestOptions) => Promise<import("./index.js").FormDetail>;
            reply: (input: import("./index.js").SessionFormReplyInput, requestOptions?: RequestOptions) => Promise<void>;
            cancel: (input: import("./index.js").SessionFormCancelInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        environment: (input: import("./index.js").SessionEnvironmentInput, requestOptions?: RequestOptions) => Promise<void>;
        view: (input: import("./index.js").SessionViewInput, requestOptions?: RequestOptions) => Promise<void>;
        stats: (input?: import("./index.js").ExperimentalSessionStatsInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionStatsInfo>;
        import: (input: import("./index.js").ExperimentalSessionImportInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionInfo>;
        export: (input: import("./index.js").ExperimentalSessionExportInput, requestOptions?: RequestOptions) => Promise<import("./index.js").SessionTransferData>;
        skill: (input: import("./index.js").ExperimentalSessionSkillInput, requestOptions?: RequestOptions) => Promise<void>;
        wait: (input: import("./index.js").ExperimentalSessionWaitInput, requestOptions?: RequestOptions) => Promise<void>;
        instructions: {
            entry: {
                list: (input: import("./index.js").ExperimentalSessionInstructionsEntryListInput, requestOptions?: RequestOptions) => Promise<import("./index.js").InstructionEntryInfo[]>;
                put: (input: import("./index.js").ExperimentalSessionInstructionsEntryPutInput, requestOptions?: RequestOptions) => Promise<void>;
                remove: (input: import("./index.js").ExperimentalSessionInstructionsEntryRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
            };
        };
        log: (input: import("./index.js").ExperimentalSessionLogInput, requestOptions?: RequestOptions) => AsyncIterable<import("./index.js").ExperimentalSessionLogOutput>;
        message: {
            get: (input: SessionMessageGetInput, options?: MediaRequestOptions) => Promise<import("./index.js").SessionMessageAgentSelected | import("./index.js").SessionMessageAssistant | import("./index.js").SessionMessageCompactionCompleted | import("./index.js").SessionMessageCompactionFailed | import("./index.js").SessionMessageCompactionRunning | import("./index.js").SessionMessageIdle | import("./index.js").SessionMessageLocationSwitched | import("./index.js").SessionMessageModelSelected | import("./index.js").SessionMessageShell | import("./index.js").SessionMessageSkill | import("./index.js").SessionMessageSynthetic | import("./index.js").SessionMessageSystem | import("./index.js").SessionMessageUser>;
        };
        inbox: {
            cancel: (input: import("./index.js").SessionInboxCancelInput, requestOptions?: RequestOptions) => Promise<void>;
            update: (input: import("./index.js").SessionInboxUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
            list: (input: SessionInboxListInput, options?: MediaRequestOptions) => Promise<import("./index.js").SessionInboxInfo[]>;
        };
    };
};
