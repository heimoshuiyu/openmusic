import type { ServerConnectInput, LocationGetInput, AgentListInput, AgentListOutput, AgentGetInput, AgentGetOutput, PluginListInput, PluginListOutput, PluginGuiInput, PluginGuiOutput, PluginCheckInput, PluginCheckOutput, PluginUpdateInput, SessionListInput, SessionCreateInput, SessionGetInput, SessionRemoveInput, SessionForkInput, SessionSwitchAgentInput, SessionSwitchModelInput, SessionUpdateInput, SessionMoveInput, SessionPromptInput, SessionCommandInput, SessionSyntheticInput, SessionShellInput, SessionCompactInput, SessionRevertStageInput, SessionRevertClearInput, SessionRevertCommitInput, SessionContextInput, SessionDiffInput, SessionInboxListInput, SessionInboxCancelInput, SessionInboxUpdateInput, SessionGenerateInput, SessionInterruptInput, SessionBackgroundInput, SessionMessageGetInput, SessionFormListInput, SessionFormCreateInput, SessionFormGetInput, SessionFormReplyInput, SessionFormCancelInput, SessionEnvironmentInput, SessionViewInput, ExperimentalSessionStatsInput, ExperimentalSessionImportInput, ExperimentalSessionExportInput, ExperimentalSessionSkillInput, ExperimentalSessionWaitInput, ExperimentalSessionInstructionsEntryListInput, ExperimentalSessionInstructionsEntryPutInput, ExperimentalSessionInstructionsEntryRemoveInput, ExperimentalSessionLogInput, ExperimentalSessionLogOutput, MessageListInput, ModelListInput, ModelListOutput, ModelDefaultInput, ModelDefaultOutput, ExperimentalGenerateTextInput, ExperimentalGenerateImageInput, ExperimentalGenerateDecisionsInput, ExperimentalVoiceSessionInput, TranscriptionTranscribeInput, TranscriptionTranscribeOutput, ExperimentalTranscriptionTranscribeWithOverridesInput, ExperimentalTranscriptionTranscribeWithOverridesOutput, ProviderListInput, ProviderListOutput, ProviderGetInput, ProviderGetOutput, IntegrationListInput, IntegrationListOutput, IntegrationGetInput, IntegrationGetOutput, IntegrationConnectKeyInput, IntegrationConnectExternalInput, IntegrationOauthConnectInput, IntegrationOauthConnectOutput, IntegrationOauthStatusInput, IntegrationOauthStatusOutput, IntegrationOauthCompleteInput, IntegrationOauthCancelInput, IntegrationCommandConnectInput, IntegrationCommandConnectOutput, IntegrationCommandStatusInput, IntegrationCommandStatusOutput, IntegrationCommandCancelInput, ExperimentalIntegrationWellknownAddInput, McpListInput, McpListOutput, McpResourceCatalogInput, McpResourceCatalogOutput, ExperimentalMcpAddInput, ExperimentalMcpRemoveInput, ExperimentalMcpConnectInput, ExperimentalMcpDisconnectInput, ExperimentalMcpClientTokenInput, ExperimentalMcpClientTokenOutput, CredentialCreateInput, CredentialUpdateInput, CredentialActivateInput, CredentialRemoveInput, ProjectListInput, ProjectListOutput, ProjectUpdateInput, FormListInput, FormListOutput, PermissionRequestListInput, PermissionRequestListOutput, PermissionSavedListInput, PermissionSavedUpdateInput, PermissionSavedRemoveInput, PermissionCreateInput, PermissionListInput, PermissionGetInput, PermissionReplyInput, FileReadInput, FileReadOutput, FileListInput, FileListOutput, FileFindInput, FileFindOutput, ExperimentalFileWriteInput, ExperimentalFileWriteOutput, ExperimentalFileWatchInput, ExperimentalFileUnwatchInput, CommandListInput, CommandListOutput, SkillListInput, SkillListOutput, RpcCallInput, EventSubscribeInput, EventSubscribeOutput, PtyListInput, PtyListOutput, PtyCreateInput, PtyCreateOutput, PtyGetInput, PtyGetOutput, PtyUpdateInput, PtyUpdateOutput, PtyRemoveInput, PtyConnectTokenInput, PtyConnectTokenOutput, ExperimentalPersistentPtyReadInput, ExperimentalPersistentPtyListInput, ExperimentalPersistentPtyCreateInput, ExperimentalPersistentPtyHandoffOutput, ExperimentalPersistentPtyGetInput, ExperimentalPersistentPtyUpdateInput, ExperimentalPersistentPtySnapshotInput, ExperimentalPersistentPtyRemoveInput, ExperimentalPersistentPtyConnectTokenInput, ExperimentalMediaGetInput, ExperimentalMediaGetOutput, ExperimentalScheduleCreateInput, ExperimentalScheduleListInput, ExperimentalScheduleGetInput, ExperimentalSchedulePauseInput, ExperimentalScheduleResumeInput, ExperimentalScheduleDeleteInput, ExperimentalArtifactsProvidersInput, ExperimentalArtifactsProvidersOutput, ExperimentalArtifactsListInput, ExperimentalArtifactsListOutput, ExperimentalArtifactsCreateInput, ExperimentalArtifactsCreateOutput, ExperimentalArtifactsGetInput, ExperimentalArtifactsGetOutput, ExperimentalArtifactsUpdateInput, ExperimentalArtifactsUpdateOutput, ExperimentalArtifactsDeleteInput, ExperimentalArtifactsViewInput, ExperimentalArtifactsViewOutput, ExperimentalJobListInput, ExperimentalPluginWebListOutput, ExperimentalPluginWebModuleInput, ExperimentalPluginWebModuleOutput, ShellListInput, ShellListOutput, ShellCreateInput, ShellCreateOutput, ShellGetInput, ShellGetOutput, ShellOutputInput, ShellOutputOutput, ShellRemoveInput, ReferenceListInput, ReferenceListOutput, WorktreeListInput, WorktreeCreateInput, WorktreeRemoveInput, WorktreeRefreshInput, VcsInitInput, VcsGetInput, VcsGetOutput, VcsBaseInput, VcsBaseOutput, VcsStatusInput, VcsStatusOutput, VcsBranchListInput, VcsBranchListOutput, VcsDiffInput, VcsDiffOutput, DebugHeapDumpInput, DebugHeapDumpOutput, DebugLocationListOutput, DebugLocationEvictInput, ExperimentalMigrationV1StatusOutput, WebsearchProvidersInput, WebsearchProvidersOutput, WebsearchQueryInput, WebsearchQueryOutput, ExperimentalUsageLimitsInput, ExperimentalUsageLimitsOutput, ConfigGetInput, ConfigGetOutput, ConfigShellsOutput, ExperimentalConfigUpdateInput } from "./types.js";
export interface ClientOptions {
    readonly baseUrl: string;
    readonly fetch?: typeof globalThis.fetch;
    readonly headers?: RequestInit["headers"];
}
export interface RequestOptions {
    readonly signal?: AbortSignal;
    readonly headers?: RequestInit["headers"];
    /** Reports every chunk a streaming response receives, including keepalive comments that yield no event. */
    readonly onActivity?: () => void;
}
export declare function make(options: ClientOptions): {
    server: {
        info: (requestOptions?: RequestOptions) => Promise<import("./types.js").ServerInfo>;
        pair: (requestOptions?: RequestOptions) => Promise<import("./types.js").PairingCode>;
        connect: (input: ServerConnectInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PairingSession>;
    };
    location: {
        get: (input?: LocationGetInput, requestOptions?: RequestOptions) => Promise<import("./types.js").LocationPublicInfo>;
        reload: (requestOptions?: RequestOptions) => Promise<void>;
    };
    agent: {
        list: (input?: AgentListInput, requestOptions?: RequestOptions) => Promise<AgentListOutput>;
        get: (input: AgentGetInput, requestOptions?: RequestOptions) => Promise<AgentGetOutput>;
    };
    plugin: {
        list: (input?: PluginListInput, requestOptions?: RequestOptions) => Promise<PluginListOutput>;
        gui: (input: PluginGuiInput, requestOptions?: RequestOptions) => Promise<PluginGuiOutput>;
        check: (input?: PluginCheckInput, requestOptions?: RequestOptions) => Promise<PluginCheckOutput>;
        update: (input: PluginUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    experimental: {
        session: {
            stats: (input?: ExperimentalSessionStatsInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionStatsInfo>;
            import: (input: ExperimentalSessionImportInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionInfo>;
            export: (input: ExperimentalSessionExportInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionTransferData>;
            skill: (input: ExperimentalSessionSkillInput, requestOptions?: RequestOptions) => Promise<void>;
            wait: (input: ExperimentalSessionWaitInput, requestOptions?: RequestOptions) => Promise<void>;
            instructions: {
                entry: {
                    list: (input: ExperimentalSessionInstructionsEntryListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").InstructionEntryInfo[]>;
                    put: (input: ExperimentalSessionInstructionsEntryPutInput, requestOptions?: RequestOptions) => Promise<void>;
                    remove: (input: ExperimentalSessionInstructionsEntryRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
                };
            };
            log: (input: ExperimentalSessionLogInput, requestOptions?: RequestOptions) => AsyncIterable<ExperimentalSessionLogOutput>;
        };
        generate: {
            text: (input: ExperimentalGenerateTextInput, requestOptions?: RequestOptions) => Promise<{
                text: string;
            }>;
            image: (input: ExperimentalGenerateImageInput, requestOptions?: RequestOptions) => Promise<import("./types.js").GenerateImageResult>;
            decisions: (input: ExperimentalGenerateDecisionsInput, requestOptions?: RequestOptions) => Promise<import("./types.js").GenerateDecisionResult>;
        };
        voice: {
            models: (requestOptions?: RequestOptions) => Promise<{
                models: Array<import("./types.js").VoiceModel>;
                default?: string | undefined;
            }>;
            session: (input: ExperimentalVoiceSessionInput, requestOptions?: RequestOptions) => Promise<{
                transport: import("./types.js").VoiceTransport;
            }>;
        };
        transcription: {
            transcribeWithOverrides: (input: ExperimentalTranscriptionTranscribeWithOverridesInput, requestOptions?: RequestOptions) => Promise<ExperimentalTranscriptionTranscribeWithOverridesOutput>;
        };
        integration: {
            wellknown: {
                add: (input: ExperimentalIntegrationWellknownAddInput, requestOptions?: RequestOptions) => Promise<void>;
            };
        };
        mcp: {
            add: (input: ExperimentalMcpAddInput, requestOptions?: RequestOptions) => Promise<void>;
            remove: (input: ExperimentalMcpRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
            connect: (input: ExperimentalMcpConnectInput, requestOptions?: RequestOptions) => Promise<void>;
            disconnect: (input: ExperimentalMcpDisconnectInput, requestOptions?: RequestOptions) => Promise<void>;
            client: {
                token: (input: ExperimentalMcpClientTokenInput, requestOptions?: RequestOptions) => Promise<ExperimentalMcpClientTokenOutput>;
            };
        };
        file: {
            write: (input: ExperimentalFileWriteInput, requestOptions?: RequestOptions) => Promise<ExperimentalFileWriteOutput>;
            watch: (input: ExperimentalFileWatchInput, requestOptions?: RequestOptions) => Promise<void>;
            unwatch: (input: ExperimentalFileUnwatchInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        persistentPty: {
            read: (input: ExperimentalPersistentPtyReadInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PersistentPtyReadResult | null>;
            list: (input: ExperimentalPersistentPtyListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PersistentPtyInfo[]>;
            create: (input: ExperimentalPersistentPtyCreateInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PersistentPtyInfo>;
            shutdown: (requestOptions?: RequestOptions) => Promise<void>;
            handoff: (requestOptions?: RequestOptions) => Promise<ExperimentalPersistentPtyHandoffOutput>;
            get: (input: ExperimentalPersistentPtyGetInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PersistentPtyInfo>;
            update: (input: ExperimentalPersistentPtyUpdateInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PersistentPtyInfo>;
            snapshot: (input: ExperimentalPersistentPtySnapshotInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PersistentPtySnapshot>;
            remove: (input: ExperimentalPersistentPtyRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
            connectToken: (input: ExperimentalPersistentPtyConnectTokenInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PtyTicketConnectToken>;
        };
        media: {
            get: (input: ExperimentalMediaGetInput, requestOptions?: RequestOptions) => Promise<ExperimentalMediaGetOutput>;
        };
        schedule: {
            create: (input: ExperimentalScheduleCreateInput, requestOptions?: RequestOptions) => Promise<import("./types.js").ScheduleInfo>;
            list: (input: ExperimentalScheduleListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").ScheduleInfo[]>;
            get: (input: ExperimentalScheduleGetInput, requestOptions?: RequestOptions) => Promise<import("./types.js").ScheduleInfo>;
            pause: (input: ExperimentalSchedulePauseInput, requestOptions?: RequestOptions) => Promise<import("./types.js").ScheduleInfo>;
            resume: (input: ExperimentalScheduleResumeInput, requestOptions?: RequestOptions) => Promise<import("./types.js").ScheduleInfo>;
            delete: (input: ExperimentalScheduleDeleteInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        artifacts: {
            providers: (input?: ExperimentalArtifactsProvidersInput, requestOptions?: RequestOptions) => Promise<ExperimentalArtifactsProvidersOutput>;
            list: (input?: ExperimentalArtifactsListInput, requestOptions?: RequestOptions) => Promise<ExperimentalArtifactsListOutput>;
            create: (input: ExperimentalArtifactsCreateInput, requestOptions?: RequestOptions) => Promise<ExperimentalArtifactsCreateOutput>;
            get: (input: ExperimentalArtifactsGetInput, requestOptions?: RequestOptions) => Promise<ExperimentalArtifactsGetOutput>;
            update: (input: ExperimentalArtifactsUpdateInput, requestOptions?: RequestOptions) => Promise<ExperimentalArtifactsUpdateOutput>;
            delete: (input: ExperimentalArtifactsDeleteInput, requestOptions?: RequestOptions) => Promise<void>;
            view: (input: ExperimentalArtifactsViewInput, requestOptions?: RequestOptions) => Promise<ExperimentalArtifactsViewOutput>;
        };
        job: {
            list: (input?: ExperimentalJobListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").JobInfo[]>;
        };
        plugin: {
            webList: (requestOptions?: RequestOptions) => Promise<ExperimentalPluginWebListOutput>;
            webModule: (input: ExperimentalPluginWebModuleInput, requestOptions?: RequestOptions) => Promise<ExperimentalPluginWebModuleOutput>;
        };
        migration: {
            v1: {
                status: (requestOptions?: RequestOptions) => Promise<ExperimentalMigrationV1StatusOutput>;
            };
        };
        usage: {
            limits: (input?: ExperimentalUsageLimitsInput, requestOptions?: RequestOptions) => Promise<ExperimentalUsageLimitsOutput>;
        };
        config: {
            update: (input: ExperimentalConfigUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
        };
    };
    message: {
        list: (input: MessageListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionMessagesResponse>;
    };
    model: {
        list: (input?: ModelListInput, requestOptions?: RequestOptions) => Promise<ModelListOutput>;
        default: (input?: ModelDefaultInput, requestOptions?: RequestOptions) => Promise<ModelDefaultOutput>;
    };
    provider: {
        list: (input?: ProviderListInput, requestOptions?: RequestOptions) => Promise<ProviderListOutput>;
        get: (input: ProviderGetInput, requestOptions?: RequestOptions) => Promise<ProviderGetOutput>;
    };
    credential: {
        list: (requestOptions?: RequestOptions) => Promise<import("./types.js").CredentialEntry[]>;
        create: (input: CredentialCreateInput, requestOptions?: RequestOptions) => Promise<import("./types.js").CredentialEntry>;
        update: (input: CredentialUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
        activate: (input: CredentialActivateInput, requestOptions?: RequestOptions) => Promise<void>;
        remove: (input: CredentialRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    project: {
        list: (input?: ProjectListInput, requestOptions?: RequestOptions) => Promise<ProjectListOutput>;
        update: (input: ProjectUpdateInput, requestOptions?: RequestOptions) => Promise<import("./types.js").Project>;
    };
    form: {
        list: (input?: FormListInput, requestOptions?: RequestOptions) => Promise<FormListOutput>;
    };
    permission: {
        request: {
            list: (input?: PermissionRequestListInput, requestOptions?: RequestOptions) => Promise<PermissionRequestListOutput>;
        };
        saved: {
            list: (input?: PermissionSavedListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PermissionSavedInfo[]>;
            update: (input: PermissionSavedUpdateInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PermissionSavedInfo>;
            remove: (input: PermissionSavedRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        create: (input: PermissionCreateInput, requestOptions?: RequestOptions) => Promise<{
            id: import("./types.js").PermissionID;
            effect: import("./types.js").PermissionEffect;
        }>;
        list: (input: PermissionListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PermissionRequest[]>;
        get: (input: PermissionGetInput, requestOptions?: RequestOptions) => Promise<import("./types.js").PermissionRequest>;
        reply: (input: PermissionReplyInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    command: {
        list: (input?: CommandListInput, requestOptions?: RequestOptions) => Promise<CommandListOutput>;
    };
    skill: {
        list: (input?: SkillListInput, requestOptions?: RequestOptions) => Promise<SkillListOutput>;
    };
    rpc: {
        call: (input: RpcCallInput, requestOptions?: RequestOptions) => Promise<import("./types.js").RpcOutput>;
    };
    event: {
        subscribe: (input?: EventSubscribeInput, requestOptions?: RequestOptions) => AsyncIterable<EventSubscribeOutput>;
    };
    pty: {
        list: (input?: PtyListInput, requestOptions?: RequestOptions) => Promise<PtyListOutput>;
        create: (input?: PtyCreateInput, requestOptions?: RequestOptions) => Promise<PtyCreateOutput>;
        get: (input: PtyGetInput, requestOptions?: RequestOptions) => Promise<PtyGetOutput>;
        update: (input: PtyUpdateInput, requestOptions?: RequestOptions) => Promise<PtyUpdateOutput>;
        remove: (input: PtyRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
        connect: {
            token: (input: PtyConnectTokenInput, requestOptions?: RequestOptions) => Promise<PtyConnectTokenOutput>;
        };
    };
    shell: {
        list: (input?: ShellListInput, requestOptions?: RequestOptions) => Promise<ShellListOutput>;
        create: (input: ShellCreateInput, requestOptions?: RequestOptions) => Promise<ShellCreateOutput>;
        get: (input: ShellGetInput, requestOptions?: RequestOptions) => Promise<ShellGetOutput>;
        output: (input: ShellOutputInput, requestOptions?: RequestOptions) => Promise<ShellOutputOutput>;
        remove: (input: ShellRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    reference: {
        list: (input?: ReferenceListInput, requestOptions?: RequestOptions) => Promise<ReferenceListOutput>;
    };
    worktree: {
        list: (input: WorktreeListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").WorktreeList>;
        create: (input: WorktreeCreateInput, requestOptions?: RequestOptions) => Promise<import("./types.js").WorktreeInfo>;
        remove: (input: WorktreeRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
        refresh: (input: WorktreeRefreshInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    vcs: {
        init: (input?: VcsInitInput, requestOptions?: RequestOptions) => Promise<void>;
        get: (input?: VcsGetInput, requestOptions?: RequestOptions) => Promise<VcsGetOutput>;
        base: (input?: VcsBaseInput, requestOptions?: RequestOptions) => Promise<VcsBaseOutput>;
        status: (input?: VcsStatusInput, requestOptions?: RequestOptions) => Promise<VcsStatusOutput>;
        branch: {
            list: (input?: VcsBranchListInput, requestOptions?: RequestOptions) => Promise<VcsBranchListOutput>;
        };
        diff: (input: VcsDiffInput, requestOptions?: RequestOptions) => Promise<VcsDiffOutput>;
    };
    debug: {
        heapDump: (input?: DebugHeapDumpInput, requestOptions?: RequestOptions) => Promise<DebugHeapDumpOutput>;
        location: {
            list: (requestOptions?: RequestOptions) => Promise<DebugLocationListOutput>;
            evict: (input?: DebugLocationEvictInput, requestOptions?: RequestOptions) => Promise<void>;
        };
    };
    websearch: {
        providers: (input?: WebsearchProvidersInput, requestOptions?: RequestOptions) => Promise<WebsearchProvidersOutput>;
        query: (input: WebsearchQueryInput, requestOptions?: RequestOptions) => Promise<WebsearchQueryOutput>;
    };
    session: {
        list: (input?: SessionListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionsResponse>;
        create: (input?: SessionCreateInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionInfo>;
        active: (requestOptions?: RequestOptions) => Promise<{
            [x: string]: import("./types.js").SessionActive;
        }>;
        get: (input: SessionGetInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionInfo>;
        remove: (input: SessionRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
        fork: (input: SessionForkInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionInfo>;
        switchAgent: (input: SessionSwitchAgentInput, requestOptions?: RequestOptions) => Promise<void>;
        switchModel: (input: SessionSwitchModelInput, requestOptions?: RequestOptions) => Promise<void>;
        update: (input: SessionUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
        move: (input: SessionMoveInput, requestOptions?: RequestOptions) => Promise<void>;
        prompt: (input: SessionPromptInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionInboxUser>;
        command: (input: SessionCommandInput, requestOptions?: RequestOptions) => Promise<void>;
        synthetic: (input: SessionSyntheticInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionInboxSynthetic>;
        shell: (input: SessionShellInput, requestOptions?: RequestOptions) => Promise<void>;
        compact: (input: SessionCompactInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionInboxCompaction>;
        revert: {
            stage: (input: SessionRevertStageInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionRevert>;
            clear: (input: SessionRevertClearInput, requestOptions?: RequestOptions) => Promise<void>;
            commit: (input: SessionRevertCommitInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        context: (input: SessionContextInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionMessageInfo[]>;
        diff: (input: SessionDiffInput, requestOptions?: RequestOptions) => Promise<import("./types.js").FileDiffInfo[]>;
        inbox: {
            list: (input: SessionInboxListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionInboxInfo[]>;
            cancel: (input: SessionInboxCancelInput, requestOptions?: RequestOptions) => Promise<void>;
            update: (input: SessionInboxUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        generate: (input: SessionGenerateInput, requestOptions?: RequestOptions) => Promise<{
            text: string;
        }>;
        interrupt: (input: SessionInterruptInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionInterruptResponse>;
        background: (input: SessionBackgroundInput, requestOptions?: RequestOptions) => Promise<void>;
        message: {
            get: (input: SessionMessageGetInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionMessageAgentSelected | import("./types.js").SessionMessageAssistant | import("./types.js").SessionMessageCompactionCompleted | import("./types.js").SessionMessageCompactionFailed | import("./types.js").SessionMessageCompactionRunning | import("./types.js").SessionMessageIdle | import("./types.js").SessionMessageLocationSwitched | import("./types.js").SessionMessageModelSelected | import("./types.js").SessionMessageShell | import("./types.js").SessionMessageSkill | import("./types.js").SessionMessageSynthetic | import("./types.js").SessionMessageSystem | import("./types.js").SessionMessageUser>;
        };
        form: {
            list: (input: SessionFormListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").FormInfo[]>;
            create: (input: SessionFormCreateInput, requestOptions?: RequestOptions) => Promise<import("./types.js").FormInfo>;
            get: (input: SessionFormGetInput, requestOptions?: RequestOptions) => Promise<import("./types.js").FormDetail>;
            reply: (input: SessionFormReplyInput, requestOptions?: RequestOptions) => Promise<void>;
            cancel: (input: SessionFormCancelInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        environment: (input: SessionEnvironmentInput, requestOptions?: RequestOptions) => Promise<void>;
        view: (input: SessionViewInput, requestOptions?: RequestOptions) => Promise<void>;
        /** @deprecated Use `client.experimental.session.stats`. Removed in the next minor. */
        stats: (input?: ExperimentalSessionStatsInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionStatsInfo>;
        /** @deprecated Use `client.experimental.session.import`. Removed in the next minor. */
        import: (input: ExperimentalSessionImportInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionInfo>;
        /** @deprecated Use `client.experimental.session.export`. Removed in the next minor. */
        export: (input: ExperimentalSessionExportInput, requestOptions?: RequestOptions) => Promise<import("./types.js").SessionTransferData>;
        /** @deprecated Use `client.experimental.session.skill`. Removed in the next minor. */
        skill: (input: ExperimentalSessionSkillInput, requestOptions?: RequestOptions) => Promise<void>;
        /** @deprecated Use `client.experimental.session.wait`. Removed in the next minor. */
        wait: (input: ExperimentalSessionWaitInput, requestOptions?: RequestOptions) => Promise<void>;
        /** @deprecated Use `client.experimental.session.instructions`. Removed in the next minor. */
        instructions: {
            /** @deprecated Use `client.experimental.session.instructions.entry`. Removed in the next minor. */
            entry: {
                /** @deprecated Use `client.experimental.session.instructions.entry.list`. Removed in the next minor. */
                list: (input: ExperimentalSessionInstructionsEntryListInput, requestOptions?: RequestOptions) => Promise<import("./types.js").InstructionEntryInfo[]>;
                /** @deprecated Use `client.experimental.session.instructions.entry.put`. Removed in the next minor. */
                put: (input: ExperimentalSessionInstructionsEntryPutInput, requestOptions?: RequestOptions) => Promise<void>;
                /** @deprecated Use `client.experimental.session.instructions.entry.remove`. Removed in the next minor. */
                remove: (input: ExperimentalSessionInstructionsEntryRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
            };
        };
        /** @deprecated Use `client.experimental.session.log`. Removed in the next minor. */
        log: (input: ExperimentalSessionLogInput, requestOptions?: RequestOptions) => AsyncIterable<ExperimentalSessionLogOutput>;
    };
    /** @deprecated Use `client.experimental.generate`. Removed in the next minor. */
    generate: {
        /** @deprecated Use `client.experimental.generate.text`. Removed in the next minor. */
        text: (input: ExperimentalGenerateTextInput, requestOptions?: RequestOptions) => Promise<{
            text: string;
        }>;
        /** @deprecated Use `client.experimental.generate.image`. Removed in the next minor. */
        image: (input: ExperimentalGenerateImageInput, requestOptions?: RequestOptions) => Promise<import("./types.js").GenerateImageResult>;
        /** @deprecated Use `client.experimental.generate.decisions`. Removed in the next minor. */
        decisions: (input: ExperimentalGenerateDecisionsInput, requestOptions?: RequestOptions) => Promise<import("./types.js").GenerateDecisionResult>;
    };
    /** @deprecated Use `client.experimental.voice`. Removed in the next minor. */
    voice: {
        /** @deprecated Use `client.experimental.voice.models`. Removed in the next minor. */
        models: (requestOptions?: RequestOptions) => Promise<{
            models: Array<import("./types.js").VoiceModel>;
            default?: string | undefined;
        }>;
        /** @deprecated Use `client.experimental.voice.session`. Removed in the next minor. */
        session: (input: ExperimentalVoiceSessionInput, requestOptions?: RequestOptions) => Promise<{
            transport: import("./types.js").VoiceTransport;
        }>;
    };
    transcription: {
        transcribe: (input: TranscriptionTranscribeInput, requestOptions?: RequestOptions) => Promise<TranscriptionTranscribeOutput>;
        /** @deprecated Use `client.experimental.transcription.transcribeWithOverrides`. Removed in the next minor. */
        transcribeWithOverrides: (input: ExperimentalTranscriptionTranscribeWithOverridesInput, requestOptions?: RequestOptions) => Promise<ExperimentalTranscriptionTranscribeWithOverridesOutput>;
    };
    integration: {
        list: (input?: IntegrationListInput, requestOptions?: RequestOptions) => Promise<IntegrationListOutput>;
        get: (input: IntegrationGetInput, requestOptions?: RequestOptions) => Promise<IntegrationGetOutput>;
        connect: {
            key: (input: IntegrationConnectKeyInput, requestOptions?: RequestOptions) => Promise<void>;
            external: (input: IntegrationConnectExternalInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        oauth: {
            connect: (input: IntegrationOauthConnectInput, requestOptions?: RequestOptions) => Promise<IntegrationOauthConnectOutput>;
            status: (input: IntegrationOauthStatusInput, requestOptions?: RequestOptions) => Promise<IntegrationOauthStatusOutput>;
            complete: (input: IntegrationOauthCompleteInput, requestOptions?: RequestOptions) => Promise<void>;
            cancel: (input: IntegrationOauthCancelInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        command: {
            connect: (input: IntegrationCommandConnectInput, requestOptions?: RequestOptions) => Promise<IntegrationCommandConnectOutput>;
            status: (input: IntegrationCommandStatusInput, requestOptions?: RequestOptions) => Promise<IntegrationCommandStatusOutput>;
            cancel: (input: IntegrationCommandCancelInput, requestOptions?: RequestOptions) => Promise<void>;
        };
        /** @deprecated Use `client.experimental.integration.wellknown`. Removed in the next minor. */
        wellknown: {
            /** @deprecated Use `client.experimental.integration.wellknown.add`. Removed in the next minor. */
            add: (input: ExperimentalIntegrationWellknownAddInput, requestOptions?: RequestOptions) => Promise<void>;
        };
    };
    mcp: {
        list: (input?: McpListInput, requestOptions?: RequestOptions) => Promise<McpListOutput>;
        resource: {
            catalog: (input?: McpResourceCatalogInput, requestOptions?: RequestOptions) => Promise<McpResourceCatalogOutput>;
        };
        /** @deprecated Use `client.experimental.mcp.add`. Removed in the next minor. */
        add: (input: ExperimentalMcpAddInput, requestOptions?: RequestOptions) => Promise<void>;
        /** @deprecated Use `client.experimental.mcp.remove`. Removed in the next minor. */
        remove: (input: ExperimentalMcpRemoveInput, requestOptions?: RequestOptions) => Promise<void>;
        /** @deprecated Use `client.experimental.mcp.connect`. Removed in the next minor. */
        connect: (input: ExperimentalMcpConnectInput, requestOptions?: RequestOptions) => Promise<void>;
        /** @deprecated Use `client.experimental.mcp.disconnect`. Removed in the next minor. */
        disconnect: (input: ExperimentalMcpDisconnectInput, requestOptions?: RequestOptions) => Promise<void>;
        /** @deprecated Use `client.experimental.mcp.client`. Removed in the next minor. */
        client: {
            /** @deprecated Use `client.experimental.mcp.client.token`. Removed in the next minor. */
            token: (input: ExperimentalMcpClientTokenInput, requestOptions?: RequestOptions) => Promise<ExperimentalMcpClientTokenOutput>;
        };
    };
    file: {
        read: (input: FileReadInput, requestOptions?: RequestOptions) => Promise<FileReadOutput>;
        list: (input?: FileListInput, requestOptions?: RequestOptions) => Promise<FileListOutput>;
        find: (input: FileFindInput, requestOptions?: RequestOptions) => Promise<FileFindOutput>;
        /** @deprecated Use `client.experimental.file.write`. Removed in the next minor. */
        write: (input: ExperimentalFileWriteInput, requestOptions?: RequestOptions) => Promise<ExperimentalFileWriteOutput>;
        /** @deprecated Use `client.experimental.file.watch`. Removed in the next minor. */
        watch: (input: ExperimentalFileWatchInput, requestOptions?: RequestOptions) => Promise<void>;
        /** @deprecated Use `client.experimental.file.unwatch`. Removed in the next minor. */
        unwatch: (input: ExperimentalFileUnwatchInput, requestOptions?: RequestOptions) => Promise<void>;
    };
    /** @deprecated Use `client.experimental.migration`. Removed in the next minor. */
    migration: {
        /** @deprecated Use `client.experimental.migration.v1`. Removed in the next minor. */
        v1: {
            /** @deprecated Use `client.experimental.migration.v1.status`. Removed in the next minor. */
            status: (requestOptions?: RequestOptions) => Promise<ExperimentalMigrationV1StatusOutput>;
        };
    };
    /** @deprecated Use `client.experimental.usage`. Removed in the next minor. */
    usage: {
        /** @deprecated Use `client.experimental.usage.limits`. Removed in the next minor. */
        limits: (input?: ExperimentalUsageLimitsInput, requestOptions?: RequestOptions) => Promise<ExperimentalUsageLimitsOutput>;
    };
    config: {
        get: (input?: ConfigGetInput, requestOptions?: RequestOptions) => Promise<ConfigGetOutput>;
        shells: (requestOptions?: RequestOptions) => Promise<ConfigShellsOutput>;
        /** @deprecated Use `client.experimental.config.update`. Removed in the next minor. */
        update: (input: ExperimentalConfigUpdateInput, requestOptions?: RequestOptions) => Promise<void>;
    };
};
