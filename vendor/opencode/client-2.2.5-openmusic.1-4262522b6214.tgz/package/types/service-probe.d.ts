import type { DiscoverOptions, Endpoint, Info } from "./service.js";
export type LocalService = {
    readonly info: Info;
    readonly endpoint: Endpoint;
    readonly version?: string;
    readonly state: "ready" | "waiting" | "failed";
    readonly compatible: boolean;
};
/**
 * What `ensure()` does with a registered service that answered: return it, keep polling while
 * it starts, replace it because its version does not meet the requirement, or fail.
 */
export declare function decide(service: LocalService, options: DiscoverOptions): {
    readonly _tag: "replace";
    readonly pty: "clear" | "handoff";
} | {
    readonly pty?: undefined;
    readonly _tag: "reuse";
} | {
    readonly pty?: undefined;
    readonly _tag: "wait";
} | {
    _tag: "fail";
    error: Error;
};
/** The default registration file. */
export declare function fallback(): string;
/** Whether two registrations describe the same service instance. */
export declare function same(left: Info, right: Info): boolean;
/** Ask a registered owner for its health and classify the answer. */
export declare function probeResult(info: Info, timeout?: number): Promise<{
    service: undefined;
    timedOut: boolean;
} | {
    service: {
        info: Info;
        endpoint: {
            url: string;
            auth: {
                type: "basic";
                username: string;
                password: string;
            } | undefined;
        };
        version: string | undefined;
        state: "ready";
        compatible: false;
    };
    timedOut: boolean;
} | {
    service: {
        info: Info;
        endpoint: {
            url: string;
            auth: {
                type: "basic";
                username: string;
                password: string;
            } | undefined;
        };
        version: string;
        state: "failed" | "ready" | "waiting";
        compatible: true;
    };
    timedOut: boolean;
}>;
/** Create HTTP authentication headers for a service endpoint. */
export declare function headers(endpoint: Endpoint): {
    authorization: string;
} | undefined;
