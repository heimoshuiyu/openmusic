export type ClientMcpOptions = {
    /** Base URL of the opencode server, for example `http://127.0.0.1:4096`. Its query params are kept. */
    readonly url: string;
    /** Client name, `[a-zA-Z0-9_-]+`. Tools are exposed to the model as `<name>_<tool>`. */
    readonly name: string;
    /** Sent as `location[directory]`. */
    readonly directory?: string;
    /** Handshake headers, such as `authorization`. Browsers cannot send them; use a ticket in `url` instead. */
    readonly headers?: Record<string, string>;
    readonly tools: ReadonlyArray<ClientMcpTool>;
    readonly WebSocket?: typeof WebSocket;
};
export type ClientMcpTool = {
    /** `[a-zA-Z0-9_-]+` */
    readonly name: string;
    readonly description?: string;
    /** JSON Schema for the arguments; `type: "object"` is always set. Arguments are not validated here. */
    readonly inputSchema?: Record<string, unknown>;
    readonly handler: (args: Record<string, unknown>, ctx: ClientMcpToolContext) => ClientMcpToolResult | Promise<ClientMcpToolResult>;
};
export type ClientMcpToolContext = {
    /** The opencode session that issued the call. */
    readonly sessionID?: string;
};
export type ClientMcpToolResult = {
    readonly content: ReadonlyArray<{
        readonly type: "text";
        readonly text: string;
    } | {
        readonly type: "image";
        readonly data: string;
        readonly mimeType: string;
    }>;
    readonly isError?: boolean;
};
export type ClientMcpConnection = {
    close(): Promise<void>;
};
/**
 * Exposes tools to the opencode server: opens a WebSocket to `/api/experimental/client-mcp` and answers MCP
 * JSON-RPC over it (one message per text frame), so the opencode server is the MCP client. Reconnects with
 * backoff until `close()`.
 */
export declare function connectClientMcp(options: ClientMcpOptions): ClientMcpConnection;
