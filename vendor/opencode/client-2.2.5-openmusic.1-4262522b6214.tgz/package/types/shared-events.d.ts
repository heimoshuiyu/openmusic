export * as SharedEvents from "./shared-events.js";
/** The members of event union `A` whose type matches one of `Type`, including `rpc.*` events. */
export type SelectedEvent<A extends {
    readonly type: string;
}, Type extends string> = A extends unknown ? [Extract<Type, A["type"]>] extends [never] ? never : A : never;
export type SubscribeOptions<Type extends string = string> = {
    readonly types?: ReadonlyArray<Type>;
    readonly signal?: AbortSignal;
    /** Reports transport activity on the shared stream, including keepalive frames that carry no event. */
    readonly onActivity?: () => void;
};
export declare function make<A extends {
    readonly type: string;
}>(connect: (signal: AbortSignal, onActivity: () => void) => AsyncIterable<A>): {
    subscribe<Type extends Exclude<A["type"], "server.connected"> = Exclude<A["type"], "server.connected">>(options?: SubscribeOptions<Type>): AsyncIterable<SelectedEvent<A, Type | "server.connected">>;
};
