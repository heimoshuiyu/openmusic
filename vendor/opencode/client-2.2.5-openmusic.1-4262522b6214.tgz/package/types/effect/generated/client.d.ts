import { Effect, Stream, Schema } from "effect";
import { Sse } from "effect/encoding";
import { HttpClientError } from "effect/http";
import type { ServerInfoOutput, ServerPairOutput, ServerConnectInput, ServerConnectOutput, LocationGetInput, AgentListInput, AgentListOutput, AgentGetInput, AgentGetOutput, PluginListInput, PluginListOutput, PluginGuiInput, PluginGuiOutput, PluginCheckInput, PluginCheckOutput, PluginUpdateInput, SessionListInput, SessionListOutput, SessionCreateInput, SessionActiveOutput, SessionGetInput, SessionRemoveInput, SessionForkInput, SessionSwitchAgentInput, SessionSwitchModelInput, SessionUpdateInput, SessionMoveInput, SessionPromptInput, SessionCommandInput, SessionSyntheticInput, SessionShellInput, SessionCompactInput, SessionRevertStageInput, SessionRevertClearInput, SessionRevertCommitInput, SessionContextInput, SessionContextOutput, SessionDiffInput, SessionDiffOutput, SessionInboxListInput, SessionInboxListOutput, SessionInboxCancelInput, SessionInboxUpdateInput, SessionGenerateInput, SessionGenerateOutput, SessionInterruptInput, SessionInterruptOutput, SessionBackgroundInput, SessionMessageGetInput, SessionFormListInput, SessionFormListOutput, SessionFormCreateInput, SessionFormGetInput, SessionFormReplyInput, SessionFormCancelInput, SessionEnvironmentInput, SessionViewInput, ExperimentalSessionStatsInput, ExperimentalSessionStatsOutput, ExperimentalSessionImportInput, ExperimentalSessionExportInput, ExperimentalSessionExportOutput, ExperimentalSessionSkillInput, ExperimentalSessionWaitInput, ExperimentalSessionInstructionsEntryListInput, ExperimentalSessionInstructionsEntryListOutput, ExperimentalSessionInstructionsEntryPutInput, ExperimentalSessionInstructionsEntryRemoveInput, ExperimentalSessionLogInput, ExperimentalSessionLogOutput, MessageListInput, MessageListOutput, ModelListInput, ModelListOutput, ModelDefaultInput, ModelDefaultOutput, ExperimentalGenerateTextInput, ExperimentalGenerateTextOutput, ExperimentalGenerateImageInput, ExperimentalGenerateDecisionsInput, ExperimentalVoiceModelsOutput, ExperimentalVoiceSessionInput, ExperimentalVoiceSessionOutput, TranscriptionTranscribeInput, TranscriptionTranscribeOutput, ExperimentalTranscriptionTranscribeWithOverridesInput, ExperimentalTranscriptionTranscribeWithOverridesOutput, ProviderListInput, ProviderListOutput, ProviderGetInput, ProviderGetOutput, IntegrationListInput, IntegrationListOutput, IntegrationGetInput, IntegrationGetOutput, IntegrationConnectKeyInput, IntegrationConnectExternalInput, IntegrationOauthConnectInput, IntegrationOauthConnectOutput, IntegrationOauthStatusInput, IntegrationOauthStatusOutput, IntegrationOauthCompleteInput, IntegrationOauthCancelInput, IntegrationCommandConnectInput, IntegrationCommandConnectOutput, IntegrationCommandStatusInput, IntegrationCommandStatusOutput, IntegrationCommandCancelInput, ExperimentalIntegrationWellknownAddInput, McpListInput, McpListOutput, McpResourceCatalogInput, McpResourceCatalogOutput, ExperimentalMcpAddInput, ExperimentalMcpRemoveInput, ExperimentalMcpConnectInput, ExperimentalMcpDisconnectInput, ExperimentalMcpClientTokenInput, ExperimentalMcpClientTokenOutput, CredentialListOutput, CredentialCreateInput, CredentialUpdateInput, CredentialActivateInput, CredentialRemoveInput, ProjectListInput, ProjectListOutput, ProjectUpdateInput, FormListInput, FormListOutput, PermissionRequestListInput, PermissionRequestListOutput, PermissionSavedListInput, PermissionSavedListOutput, PermissionSavedUpdateInput, PermissionSavedRemoveInput, PermissionCreateInput, PermissionCreateOutput, PermissionListInput, PermissionListOutput, PermissionGetInput, PermissionReplyInput, FileListInput, FileListOutput, FileFindInput, FileFindOutput, ExperimentalFileWatchInput, ExperimentalFileUnwatchInput, CommandListInput, CommandListOutput, SkillListInput, SkillListOutput, RpcCallInput, RpcCallOutput, EventSubscribeInput, PtyListInput, PtyListOutput, PtyCreateInput, PtyCreateOutput, PtyGetInput, PtyGetOutput, PtyUpdateInput, PtyUpdateOutput, PtyRemoveInput, PtyConnectTokenInput, PtyConnectTokenOutput, ExperimentalPersistentPtyReadInput, ExperimentalPersistentPtyReadOutput, ExperimentalPersistentPtyListInput, ExperimentalPersistentPtyListOutput, ExperimentalPersistentPtyCreateInput, ExperimentalPersistentPtyCreateOutput, ExperimentalPersistentPtyHandoffOutput, ExperimentalPersistentPtyGetInput, ExperimentalPersistentPtyGetOutput, ExperimentalPersistentPtyUpdateInput, ExperimentalPersistentPtyUpdateOutput, ExperimentalPersistentPtySnapshotInput, ExperimentalPersistentPtySnapshotOutput, ExperimentalPersistentPtyRemoveInput, ExperimentalPersistentPtyConnectTokenInput, ExperimentalScheduleCreateInput, ExperimentalScheduleListInput, ExperimentalScheduleListOutput, ExperimentalScheduleGetInput, ExperimentalSchedulePauseInput, ExperimentalScheduleResumeInput, ExperimentalScheduleDeleteInput, ExperimentalArtifactsProvidersInput, ExperimentalArtifactsProvidersOutput, ExperimentalArtifactsListInput, ExperimentalArtifactsListOutput, ExperimentalArtifactsCreateInput, ExperimentalArtifactsCreateOutput, ExperimentalArtifactsGetInput, ExperimentalArtifactsGetOutput, ExperimentalArtifactsUpdateInput, ExperimentalArtifactsUpdateOutput, ExperimentalArtifactsDeleteInput, ExperimentalJobListInput, ExperimentalJobListOutput, ExperimentalPluginWebListOutput, ExperimentalPluginWebModuleInput, ExperimentalPluginWebModuleOutput, ShellListInput, ShellListOutput, ShellCreateInput, ShellCreateOutput, ShellGetInput, ShellGetOutput, ShellOutputInput, ShellOutputOutput, ShellRemoveInput, ReferenceListInput, ReferenceListOutput, WorktreeListInput, WorktreeCreateInput, WorktreeRemoveInput, WorktreeRefreshInput, VcsInitInput, VcsGetInput, VcsGetOutput, VcsBaseInput, VcsBaseOutput, VcsStatusInput, VcsStatusOutput, VcsBranchListInput, VcsBranchListOutput, VcsDiffInput, VcsDiffOutput, DebugHeapDumpInput, DebugHeapDumpOutput, DebugLocationListOutput, DebugLocationEvictInput, ExperimentalMigrationV1StatusOutput, WebsearchProvidersInput, WebsearchProvidersOutput, WebsearchQueryInput, WebsearchQueryOutput, ExperimentalUsageLimitsInput, ExperimentalUsageLimitsOutput, ConfigGetInput, ConfigGetOutput, ConfigShellsOutput, ExperimentalConfigUpdateInput } from "../api/api.js";
import { ClientError } from "./client-error.js";
export declare const make: (options?: {
    readonly baseUrl?: URL | string;
}) => Effect.Effect<{
    server: {
        info: () => Effect.Effect<ServerInfoOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        pair: () => Effect.Effect<ServerPairOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        connect: (input: ServerConnectInput) => Effect.Effect<ServerConnectOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    location: {
        get: (input?: LocationGetInput) => Effect.Effect<import("@opencode/schema/location").PublicInfo, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        reload: () => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    agent: {
        list: (input?: AgentListInput) => Effect.Effect<AgentListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: AgentGetInput) => Effect.Effect<AgentGetOutput, import("@opencode/protocol/errors").AgentNotFoundError | ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    plugin: {
        list: (input?: PluginListInput) => Effect.Effect<PluginListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        gui: (input: PluginGuiInput) => Effect.Effect<PluginGuiOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PluginNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        check: (input?: PluginCheckInput) => Effect.Effect<PluginCheckOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        update: (input: PluginUpdateInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    experimental: {
        persistentPty: {
            read: (input: ExperimentalPersistentPtyReadInput) => Effect.Effect<ExperimentalPersistentPtyReadOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            list: (input: ExperimentalPersistentPtyListInput) => Effect.Effect<ExperimentalPersistentPtyListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            create: (input: ExperimentalPersistentPtyCreateInput) => Effect.Effect<ExperimentalPersistentPtyCreateOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            shutdown: () => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            handoff: () => Effect.Effect<ExperimentalPersistentPtyHandoffOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            get: (input: ExperimentalPersistentPtyGetInput) => Effect.Effect<ExperimentalPersistentPtyGetOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PtyNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            update: (input: ExperimentalPersistentPtyUpdateInput) => Effect.Effect<ExperimentalPersistentPtyUpdateOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PtyFeatureUnsupportedError | import("@opencode/protocol/errors").PtyNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            snapshot: (input: ExperimentalPersistentPtySnapshotInput) => Effect.Effect<ExperimentalPersistentPtySnapshotOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PtyNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            remove: (input: ExperimentalPersistentPtyRemoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PtyNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            connectToken: (input: ExperimentalPersistentPtyConnectTokenInput) => Effect.Effect<import("@opencode/schema/pty-ticket").ConnectToken, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PtyNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        schedule: {
            create: (input: ExperimentalScheduleCreateInput) => Effect.Effect<{
                readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
                readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
                readonly name?: string | undefined;
                readonly when: {
                    readonly tz?: string | undefined;
                    readonly type: "in";
                    readonly in: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "at";
                    readonly at: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "every";
                    readonly every: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "cron";
                    readonly cron: string;
                };
                readonly tz: string;
                readonly if?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly until?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly action: {
                    readonly type: "prompt";
                    readonly prompt: string;
                };
                readonly status: "active" | "done" | "paused";
                readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
                readonly endsAt?: import("effect/DateTime").Utc | undefined;
                readonly remainingRuns?: number | undefined;
                readonly runCount: number;
                readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
                readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
                readonly lastOutput?: string | undefined;
                readonly time: {
                    readonly created: import("effect/DateTime").Utc;
                    readonly updated: import("effect/DateTime").Utc;
                };
            }, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            list: (input: ExperimentalScheduleListInput) => Effect.Effect<ExperimentalScheduleListOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            get: (input: ExperimentalScheduleGetInput) => Effect.Effect<{
                readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
                readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
                readonly name?: string | undefined;
                readonly when: {
                    readonly tz?: string | undefined;
                    readonly type: "in";
                    readonly in: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "at";
                    readonly at: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "every";
                    readonly every: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "cron";
                    readonly cron: string;
                };
                readonly tz: string;
                readonly if?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly until?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly action: {
                    readonly type: "prompt";
                    readonly prompt: string;
                };
                readonly status: "active" | "done" | "paused";
                readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
                readonly endsAt?: import("effect/DateTime").Utc | undefined;
                readonly remainingRuns?: number | undefined;
                readonly runCount: number;
                readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
                readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
                readonly lastOutput?: string | undefined;
                readonly time: {
                    readonly created: import("effect/DateTime").Utc;
                    readonly updated: import("effect/DateTime").Utc;
                };
            }, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ScheduleNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            pause: (input: ExperimentalSchedulePauseInput) => Effect.Effect<{
                readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
                readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
                readonly name?: string | undefined;
                readonly when: {
                    readonly tz?: string | undefined;
                    readonly type: "in";
                    readonly in: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "at";
                    readonly at: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "every";
                    readonly every: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "cron";
                    readonly cron: string;
                };
                readonly tz: string;
                readonly if?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly until?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly action: {
                    readonly type: "prompt";
                    readonly prompt: string;
                };
                readonly status: "active" | "done" | "paused";
                readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
                readonly endsAt?: import("effect/DateTime").Utc | undefined;
                readonly remainingRuns?: number | undefined;
                readonly runCount: number;
                readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
                readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
                readonly lastOutput?: string | undefined;
                readonly time: {
                    readonly created: import("effect/DateTime").Utc;
                    readonly updated: import("effect/DateTime").Utc;
                };
            }, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ScheduleNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            resume: (input: ExperimentalScheduleResumeInput) => Effect.Effect<{
                readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
                readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
                readonly name?: string | undefined;
                readonly when: {
                    readonly tz?: string | undefined;
                    readonly type: "in";
                    readonly in: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "at";
                    readonly at: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "every";
                    readonly every: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "cron";
                    readonly cron: string;
                };
                readonly tz: string;
                readonly if?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly until?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly action: {
                    readonly type: "prompt";
                    readonly prompt: string;
                };
                readonly status: "active" | "done" | "paused";
                readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
                readonly endsAt?: import("effect/DateTime").Utc | undefined;
                readonly remainingRuns?: number | undefined;
                readonly runCount: number;
                readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
                readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
                readonly lastOutput?: string | undefined;
                readonly time: {
                    readonly created: import("effect/DateTime").Utc;
                    readonly updated: import("effect/DateTime").Utc;
                };
            }, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ScheduleNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            delete: (input: ExperimentalScheduleDeleteInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ScheduleNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        artifacts: {
            providers: (input?: ExperimentalArtifactsProvidersInput) => Effect.Effect<ExperimentalArtifactsProvidersOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            list: (input?: ExperimentalArtifactsListInput) => Effect.Effect<ExperimentalArtifactsListOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            create: (input: ExperimentalArtifactsCreateInput) => Effect.Effect<ExperimentalArtifactsCreateOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            get: (input: ExperimentalArtifactsGetInput) => Effect.Effect<ExperimentalArtifactsGetOutput, import("@opencode/protocol/errors").ArtifactNotFoundError | ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            update: (input: ExperimentalArtifactsUpdateInput) => Effect.Effect<ExperimentalArtifactsUpdateOutput, import("@opencode/protocol/errors").ArtifactNotFoundError | ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            delete: (input: ExperimentalArtifactsDeleteInput) => Effect.Effect<void, import("@opencode/protocol/errors").ArtifactNotFoundError | ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        job: {
            list: (input?: ExperimentalJobListInput) => Effect.Effect<ExperimentalJobListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        plugin: {
            webList: () => Effect.Effect<ExperimentalPluginWebListOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            webModule: (input: ExperimentalPluginWebModuleInput) => Effect.Effect<ExperimentalPluginWebModuleOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PluginNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        session: {
            stats: (input?: ExperimentalSessionStatsInput) => Effect.Effect<ExperimentalSessionStatsOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            import: (input: ExperimentalSessionImportInput) => Effect.Effect<import("@opencode/schema/session").Info, ClientError | import("@opencode/protocol/errors").ConflictError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            export: (input: ExperimentalSessionExportInput) => Effect.Effect<ExperimentalSessionExportOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
            skill: (input: ExperimentalSessionSkillInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").SkillNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            wait: (input: ExperimentalSessionWaitInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            instructions: {
                entry: {
                    list: (input: ExperimentalSessionInstructionsEntryListInput) => Effect.Effect<ExperimentalSessionInstructionsEntryListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
                    put: (input: ExperimentalSessionInstructionsEntryPutInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/schema/instruction-entry").ValueTooLargeError, never>;
                    remove: (input: ExperimentalSessionInstructionsEntryRemoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
                };
            };
            log: (input: ExperimentalSessionLogInput) => Stream.Stream<ExperimentalSessionLogOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Sse.Retry | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | Sse.SseError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        generate: {
            text: (input: ExperimentalGenerateTextInput) => Effect.Effect<ExperimentalGenerateTextOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
            image: (input: ExperimentalGenerateImageInput) => Effect.Effect<import("@opencode/schema/generate").ImageResult, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
            decisions: (input: ExperimentalGenerateDecisionsInput) => Effect.Effect<import("@opencode/schema/generate").DecisionResult, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
        };
        voice: {
            models: () => Effect.Effect<ExperimentalVoiceModelsOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            session: (input: ExperimentalVoiceSessionInput) => Effect.Effect<ExperimentalVoiceSessionOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        transcription: {
            transcribeWithOverrides: (input: ExperimentalTranscriptionTranscribeWithOverridesInput) => Effect.Effect<ExperimentalTranscriptionTranscribeWithOverridesOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        };
        integration: {
            wellknown: {
                add: (input: ExperimentalIntegrationWellknownAddInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            };
        };
        mcp: {
            add: (input: ExperimentalMcpAddInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            remove: (input: ExperimentalMcpRemoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            connect: (input: ExperimentalMcpConnectInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            disconnect: (input: ExperimentalMcpDisconnectInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            client: {
                token: (input: ExperimentalMcpClientTokenInput) => Effect.Effect<ExperimentalMcpClientTokenOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            };
        };
        file: {
            watch: (input: ExperimentalFileWatchInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").FileNotFoundError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            unwatch: (input: ExperimentalFileUnwatchInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        migration: {
            v1: {
                status: () => Effect.Effect<ExperimentalMigrationV1StatusOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            };
        };
        usage: {
            limits: (input?: ExperimentalUsageLimitsInput) => Effect.Effect<ExperimentalUsageLimitsOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        config: {
            update: (input: ExperimentalConfigUpdateInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    message: {
        list: (input: MessageListInput) => Effect.Effect<MessageListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidCursorError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
    };
    model: {
        list: (input?: ModelListInput) => Effect.Effect<ModelListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        default: (input?: ModelDefaultInput) => Effect.Effect<ModelDefaultOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    provider: {
        list: (input?: ProviderListInput) => Effect.Effect<ProviderListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: ProviderGetInput) => Effect.Effect<ProviderGetOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    credential: {
        list: () => Effect.Effect<CredentialListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        create: (input: CredentialCreateInput) => Effect.Effect<import("@opencode/schema/credential").Entry, ClientError | import("@opencode/protocol/errors").ConflictError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        update: (input: CredentialUpdateInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        activate: (input: CredentialActivateInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        remove: (input: CredentialRemoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    project: {
        list: (input?: ProjectListInput) => Effect.Effect<ProjectListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        update: (input: ProjectUpdateInput) => Effect.Effect<import("@opencode/schema/project").Info, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ProjectNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    form: {
        list: (input?: FormListInput) => Effect.Effect<FormListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    permission: {
        request: {
            list: (input?: PermissionRequestListInput) => Effect.Effect<PermissionRequestListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        saved: {
            list: (input?: PermissionSavedListInput) => Effect.Effect<PermissionSavedListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            update: (input: PermissionSavedUpdateInput) => Effect.Effect<import("@opencode/schema/permission-saved").Info, ClientError | import("@opencode/protocol/errors").ConflictError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PermissionSavedNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            remove: (input: PermissionSavedRemoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        create: (input: PermissionCreateInput) => Effect.Effect<PermissionCreateOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        list: (input: PermissionListInput) => Effect.Effect<PermissionListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: PermissionGetInput) => Effect.Effect<import("@opencode/schema/permission").Request, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PermissionNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        reply: (input: PermissionReplyInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PermissionNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    command: {
        list: (input?: CommandListInput) => Effect.Effect<CommandListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    skill: {
        list: (input?: SkillListInput) => Effect.Effect<SkillListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    rpc: {
        call: (input: RpcCallInput) => Effect.Effect<RpcCallOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").RpcError | import("@opencode/protocol/errors").RpcInternalError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    event: {
        subscribe: (input?: EventSubscribeInput) => Stream.Stream<{
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.agent.selected";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly agent: string & import("effect/Brand").Brand<"Agent.ID">;
                readonly previous?: (string & import("effect/Brand").Brand<"Agent.ID">) | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.archived";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.compaction.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly reason: "auto" | "manual";
                readonly model?: {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                } | undefined;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
                readonly text: string;
                readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
                readonly tokens?: {
                    readonly input: number;
                    readonly output: number;
                    readonly reasoning: number;
                    readonly cache: {
                        readonly read: number;
                        readonly write: number;
                    };
                } | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.compaction.failed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly reason: "auto" | "manual";
                readonly error: {
                    readonly type: string;
                    readonly message: string;
                    readonly status?: number | undefined;
                    readonly response?: {
                        readonly body: string;
                    } | undefined;
                    readonly retryAfterMs?: number | undefined;
                };
                readonly inputID?: (string & import("effect/Brand").Brand<"Session.Message.ID">) | undefined;
                readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
                readonly tokens?: {
                    readonly input: number;
                    readonly output: number;
                    readonly reasoning: number;
                    readonly cache: {
                        readonly read: number;
                        readonly write: number;
                    };
                } | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.compaction.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly reason: "auto" | "manual";
                readonly inputID?: (string & import("effect/Brand").Brand<"Session.Message.ID">) | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.created";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
                readonly location: {
                    readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                    readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
                };
                readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
                readonly slug: string;
                readonly title?: string | undefined;
                readonly agent?: (string & import("effect/Brand").Brand<"Agent.ID">) | undefined;
                readonly model?: {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                } | undefined;
                readonly metadata?: {
                    readonly [x: string]: Schema.Json;
                } | undefined;
                readonly permissions?: readonly {
                    readonly action: string;
                    readonly resource: string;
                    readonly effect: "allow" | "ask" | "deny";
                }[] | undefined;
                readonly version: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.deleted";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.execution.failed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly error: {
                    readonly type: string;
                    readonly message: string;
                    readonly status?: number | undefined;
                    readonly response?: {
                        readonly body: string;
                    } | undefined;
                    readonly retryAfterMs?: number | undefined;
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.execution.interrupted";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly reason: "inactivity" | "shutdown" | "superseded" | "user";
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.execution.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.execution.succeeded";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.forked";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly parentID: string & import("effect/Brand").Brand<"SessionID">;
                readonly boundary: {
                    readonly type: "before";
                    readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                } | {
                    readonly type: "through";
                    readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
                readonly instructions?: {
                    readonly [x: string & import("effect/Brand").Brand<"Instruction.Key">]: string & import("effect/Brand").Brand<"Instruction.Hash">;
                } | undefined;
                readonly instructionEntries?: readonly {
                    readonly key: string;
                    readonly value: Schema.Json;
                    readonly removed: boolean;
                }[] | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.inbox.cancelled";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.inbox.delivered";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.inbox.delivery.changed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly delivery: "queue" | "steer";
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.inbox.enqueued";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly item: {
                    readonly type: "user";
                    readonly payload: {
                        readonly text: string;
                        readonly files?: readonly {
                            readonly data: string;
                            readonly mime: string;
                            readonly source: {
                                readonly type: "inline";
                            } | {
                                readonly type: "uri";
                                readonly uri: string;
                            };
                            readonly name?: string | undefined;
                            readonly description?: string | undefined;
                            readonly mention?: {
                                readonly start: number;
                                readonly end: number;
                                readonly text: string;
                            } | undefined;
                        }[] | undefined;
                        readonly agents?: readonly {
                            readonly name: string;
                            readonly mention?: {
                                readonly start: number;
                                readonly end: number;
                                readonly text: string;
                            } | undefined;
                        }[] | undefined;
                        readonly skills?: readonly {
                            readonly id: string & import("effect/Brand").Brand<"Skill.ID">;
                            readonly name: string & import("effect/Brand").Brand<"Skill.Name">;
                            readonly text?: string | undefined;
                            readonly mention?: {
                                readonly start: number;
                                readonly end: number;
                                readonly text: string;
                            } | undefined;
                        }[] | undefined;
                        readonly metadata?: {
                            readonly [x: string]: unknown;
                        } | undefined;
                    };
                    readonly delivery: "queue" | "steer";
                } | {
                    readonly type: "synthetic";
                    readonly payload: {
                        readonly text: string;
                        readonly description?: string | undefined;
                        readonly metadata?: {
                            readonly [x: string]: unknown;
                        } | undefined;
                    };
                    readonly delivery: "queue" | "steer";
                } | {
                    readonly type: "compaction";
                    readonly payload: {};
                    readonly delivery: "queue" | "steer";
                } | {
                    readonly type: "move";
                    readonly payload: {
                        readonly location: {
                            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                            readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
                        };
                        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
                        readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
                    };
                    readonly delivery: "queue" | "steer";
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.instructions.updated";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly delta: {
                    readonly [x: string]: "removed" | (string & import("effect/Brand").Brand<"Instruction.Hash">);
                };
                readonly text?: string | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.metadata.updated";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly metadata: {
                    readonly [x: string]: Schema.Json;
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.model.selected";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly model: {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
                readonly previous?: {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                } | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.moved";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly location: {
                    readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                    readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
                };
                readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
                readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.permissions";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly permissions: readonly {
                    readonly action: string;
                    readonly resource: string;
                    readonly effect: "allow" | "ask" | "deny";
                }[];
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.reasoning.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
                readonly text: string;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.reasoning.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.renamed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly title: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.retry.scheduled";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly attempt: number;
                readonly at: number;
                readonly error: {
                    readonly type: string;
                    readonly message: string;
                    readonly status?: number | undefined;
                    readonly response?: {
                        readonly body: string;
                    } | undefined;
                    readonly retryAfterMs?: number | undefined;
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.revert.cleared";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.revert.committed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly to: string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.revert.staged";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly revert: {
                    readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                    readonly partID?: string | undefined;
                    readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
                    readonly files?: readonly {
                        readonly file: string;
                        readonly patch: string;
                        readonly additions: number;
                        readonly deletions: number;
                        readonly status: "added" | "deleted" | "modified";
                        readonly more?: true | undefined;
                    }[] | undefined;
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.shell.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly shell: {
                    readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
                    readonly status: "exited" | "killed" | "running" | "timeout";
                    readonly command: string;
                    readonly cwd: string;
                    readonly shell: string;
                    readonly file: string;
                    readonly pid?: number | undefined;
                    readonly exit?: number | undefined;
                    readonly signal?: string | undefined;
                    readonly metadata: {
                        readonly [x: string]: unknown;
                    };
                    readonly time: {
                        readonly started: number;
                        readonly completed?: number | undefined;
                    };
                };
                readonly output: {
                    readonly output: string;
                    readonly cursor: number;
                    readonly size: number;
                    readonly truncated: boolean;
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.shell.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly shell: {
                    readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
                    readonly status: "exited" | "killed" | "running" | "timeout";
                    readonly command: string;
                    readonly cwd: string;
                    readonly shell: string;
                    readonly file: string;
                    readonly pid?: number | undefined;
                    readonly exit?: number | undefined;
                    readonly signal?: string | undefined;
                    readonly metadata: {
                        readonly [x: string]: unknown;
                    };
                    readonly time: {
                        readonly started: number;
                        readonly completed?: number | undefined;
                    };
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.skill.activated";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly id: string & import("effect/Brand").Brand<"Skill.ID">;
                readonly name: string & import("effect/Brand").Brand<"Skill.Name">;
                readonly text: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.step.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly finish: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly rawFinish?: string | undefined;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
                readonly cost: number & import("effect/Brand").Brand<"Money.USD">;
                readonly tokens: {
                    readonly input: number;
                    readonly output: number;
                    readonly reasoning: number;
                    readonly cache: {
                        readonly read: number;
                        readonly write: number;
                    };
                };
                readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
                readonly files?: readonly (string & import("effect/Brand").Brand<"RelativePath">)[] | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.step.failed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly error: {
                    readonly type: string;
                    readonly message: string;
                    readonly status?: number | undefined;
                    readonly response?: {
                        readonly body: string;
                    } | undefined;
                    readonly retryAfterMs?: number | undefined;
                };
                readonly finish?: "content-filter" | undefined;
                readonly rawFinish?: string | undefined;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
                readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
                readonly tokens?: {
                    readonly input: number;
                    readonly output: number;
                    readonly reasoning: number;
                    readonly cache: {
                        readonly read: number;
                        readonly write: number;
                    };
                } | undefined;
                readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
                readonly files?: readonly (string & import("effect/Brand").Brand<"RelativePath">)[] | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.step.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly agent: string & import("effect/Brand").Brand<"Agent.ID">;
                readonly model: {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
                readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
                readonly started: number;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.step.streamed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.synthetic";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly text: string;
                readonly description?: string | undefined;
                readonly metadata?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.text.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
                readonly text: string;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.text.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.called";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly input: {
                    readonly [x: string]: unknown;
                };
                readonly executed: boolean;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.failed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly error: {
                    readonly type: string;
                    readonly message: string;
                    readonly status?: number | undefined;
                    readonly response?: {
                        readonly body: string;
                    } | undefined;
                    readonly retryAfterMs?: number | undefined;
                };
                readonly content?: readonly [{
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                }, ...({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[]] | undefined;
                readonly metadata?: {
                    readonly [x: string]: Schema.Json;
                } | undefined;
                readonly executed: boolean;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.input.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly text: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.input.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly name: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.success";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly content: readonly [{
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                }, ...({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[]];
                readonly metadata?: {
                    readonly [x: string]: Schema.Json;
                } | undefined;
                readonly executed: boolean;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.unarchived";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.viewed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly idle: number;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "worktree.resolved";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly previous: string & import("effect/Brand").Brand<"Project.ID">;
                readonly adopted?: readonly (string & import("effect/Brand").Brand<"Project.ID">)[] | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "agent.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "artifact.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "command.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "config.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "credential.switched";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly integrationID: string & import("effect/Brand").Brand<"Integration.ID">;
                readonly credentialID: (string & import("effect/Brand").Brand<"Credential.ID">) | null;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "credential.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly integrationID: string & import("effect/Brand").Brand<"Integration.ID">;
                readonly credentialID: string & import("effect/Brand").Brand<"Credential.ID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "filesystem.changed";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly file: string;
                readonly event: "add" | "change" | "unlink";
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "form.cancelled";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"Form.ID">;
                readonly sessionID: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "form.created";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly form: {
                    readonly id: string & import("effect/Brand").Brand<"Form.ID">;
                    readonly sessionID: string;
                    readonly title: string;
                    readonly metadata?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                    readonly fields: readonly [{
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "string";
                        readonly format?: "date" | "date-time" | "email" | "uri" | undefined;
                        readonly minLength?: number | undefined;
                        readonly maxLength?: number | undefined;
                        readonly pattern?: string | undefined;
                        readonly placeholder?: string | undefined;
                        readonly default?: string | undefined;
                        readonly options?: readonly {
                            readonly value: string;
                            readonly label: string;
                            readonly description?: string | undefined;
                        }[] | undefined;
                        readonly custom?: boolean | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "number";
                        readonly minimum?: number | undefined;
                        readonly maximum?: number | undefined;
                        readonly default?: number | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "integer";
                        readonly minimum?: number | undefined;
                        readonly maximum?: number | undefined;
                        readonly default?: number | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "boolean";
                        readonly default?: boolean | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "multiselect";
                        readonly options: readonly {
                            readonly value: string;
                            readonly label: string;
                            readonly description?: string | undefined;
                        }[];
                        readonly minItems?: number | undefined;
                        readonly maxItems?: number | undefined;
                        readonly custom?: boolean | undefined;
                        readonly default?: readonly string[] | undefined;
                    } | {
                        readonly key: string;
                        readonly type: "external";
                        readonly url: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                    }, ...({
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "string";
                        readonly format?: "date" | "date-time" | "email" | "uri" | undefined;
                        readonly minLength?: number | undefined;
                        readonly maxLength?: number | undefined;
                        readonly pattern?: string | undefined;
                        readonly placeholder?: string | undefined;
                        readonly default?: string | undefined;
                        readonly options?: readonly {
                            readonly value: string;
                            readonly label: string;
                            readonly description?: string | undefined;
                        }[] | undefined;
                        readonly custom?: boolean | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "number";
                        readonly minimum?: number | undefined;
                        readonly maximum?: number | undefined;
                        readonly default?: number | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "integer";
                        readonly minimum?: number | undefined;
                        readonly maximum?: number | undefined;
                        readonly default?: number | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "boolean";
                        readonly default?: boolean | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "multiselect";
                        readonly options: readonly {
                            readonly value: string;
                            readonly label: string;
                            readonly description?: string | undefined;
                        }[];
                        readonly minItems?: number | undefined;
                        readonly maxItems?: number | undefined;
                        readonly custom?: boolean | undefined;
                        readonly default?: readonly string[] | undefined;
                    } | {
                        readonly key: string;
                        readonly type: "external";
                        readonly url: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                    })[]];
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "form.replied";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"Form.ID">;
                readonly sessionID: string;
                readonly answer: {
                    readonly [x: string]: string | number | boolean | readonly string[];
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "installation.update-available";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly version: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "installation.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly version: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "integration.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "location.shutdown";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "mcp.resources.changed";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly server: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "mcp.status.changed";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly server: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "model.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "models-dev.refreshed";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "permission.asked";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly action: string;
                readonly resources: readonly string[];
                readonly save?: readonly string[] | undefined;
                readonly metadata?: {
                    readonly [x: string]: unknown;
                } | undefined;
                readonly source?: {
                    readonly type: "tool";
                    readonly messageID: string;
                    readonly id: string;
                } | undefined;
                readonly message?: string | undefined;
                readonly id: string & import("effect/Brand").Brand<"Permission.ID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "permission.replied";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly requestID: string & import("effect/Brand").Brand<"Permission.ID">;
                readonly reply: "always" | "once" | "reject";
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "persistent-pty.added";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly terminal: {
                    readonly id: string & import("effect/Brand").Brand<"PtyID">;
                    readonly title: string;
                    readonly command: string;
                    readonly args: readonly string[];
                    readonly cwd: string;
                    readonly status: "exited" | "running";
                    readonly pid: number;
                    readonly exitCode?: number | undefined;
                    readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                    readonly userTitle: string | null;
                    readonly foregroundProcess: string | null;
                    readonly size: {
                        readonly cols: number;
                        readonly rows: number;
                    };
                    readonly output: {
                        readonly head: number;
                        readonly tail: number;
                    };
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "persistent-pty.removed";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly ptyID: string & import("effect/Brand").Brand<"PtyID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "persistent-pty.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly terminal: {
                    readonly id: string & import("effect/Brand").Brand<"PtyID">;
                    readonly title: string;
                    readonly command: string;
                    readonly args: readonly string[];
                    readonly cwd: string;
                    readonly status: "exited" | "running";
                    readonly pid: number;
                    readonly exitCode?: number | undefined;
                    readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                    readonly userTitle: string | null;
                    readonly foregroundProcess: string | null;
                    readonly size: {
                        readonly cols: number;
                        readonly rows: number;
                    };
                    readonly output: {
                        readonly head: number;
                        readonly tail: number;
                    };
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "plugin.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "project.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"Project.ID">;
                readonly canonical: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly vcs?: string | undefined;
                readonly name?: string | undefined;
                readonly icon?: {
                    readonly url?: string | undefined;
                    readonly override?: string | undefined;
                    readonly color?: string | undefined;
                } | undefined;
                readonly commands?: {
                    readonly start?: string | undefined;
                } | undefined;
                readonly time: {
                    readonly created: number;
                    readonly updated: number;
                    readonly active: number;
                    readonly archived?: number | undefined;
                };
                readonly sandboxes: readonly string[];
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "provider.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "pty.created";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly info: {
                    readonly id: string & import("effect/Brand").Brand<"PtyID">;
                    readonly title: string;
                    readonly command: string;
                    readonly args: readonly string[];
                    readonly cwd: string;
                    readonly status: "exited" | "running";
                    readonly pid: number;
                    readonly exitCode?: number | undefined;
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "pty.deleted";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"PtyID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "pty.exited";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"PtyID">;
                readonly exitCode: number;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "pty.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly info: {
                    readonly id: string & import("effect/Brand").Brand<"PtyID">;
                    readonly title: string;
                    readonly command: string;
                    readonly args: readonly string[];
                    readonly cwd: string;
                    readonly status: "exited" | "running";
                    readonly pid: number;
                    readonly exitCode?: number | undefined;
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "reference.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.compaction.delta";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly text: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.idle";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.reasoning.delta";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
                readonly delta: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.status";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly status: {
                    readonly type: "idle";
                } | {
                    readonly type: "busy";
                } | {
                    readonly type: "retry";
                    readonly attempt: number;
                    readonly message: string;
                    readonly action?: {
                        readonly reason: string;
                        readonly provider: string;
                        readonly title: string;
                        readonly message: string;
                        readonly label: string;
                        readonly link?: string | undefined;
                    } | undefined;
                    readonly next: number;
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.text.delta";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
                readonly delta: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.input.delta";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly delta: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.progress";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly metadata: {
                    readonly [x: string]: Schema.Json;
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.usage.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly cost: number & import("effect/Brand").Brand<"Money.USD">;
                readonly tokens: {
                    readonly input: number;
                    readonly output: number;
                    readonly reasoning: number;
                    readonly cache: {
                        readonly read: number;
                        readonly write: number;
                    };
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "shell.created";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly info: {
                    readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
                    readonly status: "exited" | "killed" | "running" | "timeout";
                    readonly command: string;
                    readonly cwd: string;
                    readonly shell: string;
                    readonly file: string;
                    readonly pid?: number | undefined;
                    readonly exit?: number | undefined;
                    readonly signal?: string | undefined;
                    readonly metadata: {
                        readonly [x: string]: unknown;
                    };
                    readonly time: {
                        readonly started: number;
                        readonly completed?: number | undefined;
                    };
                };
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "shell.deleted";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "shell.exited";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
                readonly exit?: number | undefined;
                readonly status: "exited" | "killed" | "running" | "timeout";
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "skill.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "tui.command.execute";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly command: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "tui.prompt.append";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly text: string;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "tui.session.select";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "tui.toast.show";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly title?: string | undefined;
                readonly message: string;
                readonly variant: "error" | "info" | "success" | "warning";
                readonly duration: number;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "vcs.branch.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly branch?: string | undefined;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "websearch.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "worktree.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: `rpc.${string}`;
            readonly location: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            };
            readonly data: {
                readonly [x: string]: unknown;
            };
        } | {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            } | undefined;
            readonly type: "server.connected";
            readonly data: {};
        }, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Sse.Retry | Schema.SchemaError | Sse.SseError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    pty: {
        list: (input?: PtyListInput) => Effect.Effect<PtyListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        create: (input?: PtyCreateInput) => Effect.Effect<PtyCreateOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: PtyGetInput) => Effect.Effect<PtyGetOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PtyNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        update: (input: PtyUpdateInput) => Effect.Effect<PtyUpdateOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PtyNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        remove: (input: PtyRemoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PtyNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        connect: {
            token: (input: PtyConnectTokenInput) => Effect.Effect<PtyConnectTokenOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PtyNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    shell: {
        list: (input?: ShellListInput) => Effect.Effect<ShellListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        create: (input: ShellCreateInput) => Effect.Effect<ShellCreateOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: ShellGetInput) => Effect.Effect<ShellGetOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ShellNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        output: (input: ShellOutputInput) => Effect.Effect<ShellOutputOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ShellNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        remove: (input: ShellRemoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    reference: {
        list: (input?: ReferenceListInput) => Effect.Effect<ReferenceListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    worktree: {
        list: (input: WorktreeListInput) => Effect.Effect<readonly {
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly strategy?: string | undefined;
        }[], ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ProjectNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        create: (input: WorktreeCreateInput) => Effect.Effect<import("@opencode/schema/worktree").Info, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ProjectNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/groups/worktree").WorktreeError, never>;
        remove: (input: WorktreeRemoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ProjectNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/groups/worktree").WorktreeError, never>;
        refresh: (input: WorktreeRefreshInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ProjectNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/groups/worktree").WorktreeError, never>;
    };
    vcs: {
        init: (input?: VcsInitInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").ConflictError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/groups/vcs").VcsInitNotSupportedError, never>;
        get: (input?: VcsGetInput) => Effect.Effect<VcsGetOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        base: (input?: VcsBaseInput) => Effect.Effect<VcsBaseOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        status: (input?: VcsStatusInput) => Effect.Effect<VcsStatusOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        branch: {
            list: (input?: VcsBranchListInput) => Effect.Effect<VcsBranchListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        diff: (input: VcsDiffInput) => Effect.Effect<VcsDiffOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    debug: {
        heapDump: (input?: DebugHeapDumpInput) => Effect.Effect<DebugHeapDumpOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        location: {
            list: () => Effect.Effect<DebugLocationListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            evict: (input?: DebugLocationEvictInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    websearch: {
        providers: (input?: WebsearchProvidersInput) => Effect.Effect<WebsearchProvidersOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        query: (input: WebsearchQueryInput) => Effect.Effect<WebsearchQueryOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    session: {
        list: (input?: SessionListInput) => Effect.Effect<SessionListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidCursorError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        create: (input?: SessionCreateInput) => Effect.Effect<import("@opencode/schema/session").Info, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        active: () => Effect.Effect<SessionActiveOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: SessionGetInput) => Effect.Effect<import("@opencode/schema/session").Info, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        remove: (input: SessionRemoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        fork: (input: SessionForkInput) => Effect.Effect<import("@opencode/schema/session").Info, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").MessageNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        switchAgent: (input: SessionSwitchAgentInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        switchModel: (input: SessionSwitchModelInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        update: (input: SessionUpdateInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        move: (input: SessionMoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        prompt: (input: SessionPromptInput) => Effect.Effect<import("@opencode/schema/session-inbox").User, ClientError | import("@opencode/protocol/errors").ConflictError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        command: (input: SessionCommandInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").CommandExecutionError | import("@opencode/protocol/errors").CommandNotFoundError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        synthetic: (input: SessionSyntheticInput) => Effect.Effect<import("@opencode/schema/session-inbox").Synthetic, ClientError | import("@opencode/protocol/errors").ConflictError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        shell: (input: SessionShellInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        compact: (input: SessionCompactInput) => Effect.Effect<import("@opencode/schema/session-inbox").Compaction, ClientError | import("@opencode/protocol/errors").ConflictError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        revert: {
            stage: (input: SessionRevertStageInput) => Effect.Effect<import("@opencode/schema/session-revert").Revert, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").MessageNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionBusyError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
            clear: (input: SessionRevertClearInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionBusyError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
            commit: (input: SessionRevertCommitInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionBusyError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        context: (input: SessionContextInput) => Effect.Effect<SessionContextOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        diff: (input: SessionDiffInput) => Effect.Effect<SessionDiffOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").MessageNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        inbox: {
            list: (input: SessionInboxListInput) => Effect.Effect<SessionInboxListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            cancel: (input: SessionInboxCancelInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            update: (input: SessionInboxUpdateInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").ConflictError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        generate: (input: SessionGenerateInput) => Effect.Effect<SessionGenerateOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        interrupt: (input: SessionInterruptInput) => Effect.Effect<SessionInterruptOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        background: (input: SessionBackgroundInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        message: {
            get: (input: SessionMessageGetInput) => Effect.Effect<import("@opencode/schema/session-message").Info, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").MessageNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        form: {
            list: (input: SessionFormListInput) => Effect.Effect<SessionFormListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            create: (input: SessionFormCreateInput) => Effect.Effect<import("@opencode/schema/form").Info, ClientError | import("@opencode/protocol/errors").ConflictError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            get: (input: SessionFormGetInput) => Effect.Effect<import("@opencode/schema/form").Detail, ClientError | import("@opencode/protocol/errors").FormNotFoundError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            reply: (input: SessionFormReplyInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").FormAlreadySettledError | import("@opencode/protocol/errors").FormInvalidAnswerError | import("@opencode/protocol/errors").FormNotFoundError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            cancel: (input: SessionFormCancelInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").FormAlreadySettledError | import("@opencode/protocol/errors").FormNotFoundError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        environment: (input: SessionEnvironmentInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        view: (input: SessionViewInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.session.stats`. Removed in the next minor. */
        stats: (input?: ExperimentalSessionStatsInput) => Effect.Effect<ExperimentalSessionStatsOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.session.import`. Removed in the next minor. */
        import: (input: ExperimentalSessionImportInput) => Effect.Effect<import("@opencode/schema/session").Info, ClientError | import("@opencode/protocol/errors").ConflictError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.session.export`. Removed in the next minor. */
        export: (input: ExperimentalSessionExportInput) => Effect.Effect<ExperimentalSessionExportOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        /** @deprecated Use `client.experimental.session.skill`. Removed in the next minor. */
        skill: (input: ExperimentalSessionSkillInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").SkillNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.session.wait`. Removed in the next minor. */
        wait: (input: ExperimentalSessionWaitInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.session.instructions`. Removed in the next minor. */
        instructions: {
            /** @deprecated Use `client.experimental.session.instructions.entry`. Removed in the next minor. */
            entry: {
                /** @deprecated Use `client.experimental.session.instructions.entry.list`. Removed in the next minor. */
                list: (input: ExperimentalSessionInstructionsEntryListInput) => Effect.Effect<ExperimentalSessionInstructionsEntryListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
                /** @deprecated Use `client.experimental.session.instructions.entry.put`. Removed in the next minor. */
                put: (input: ExperimentalSessionInstructionsEntryPutInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/schema/instruction-entry").ValueTooLargeError, never>;
                /** @deprecated Use `client.experimental.session.instructions.entry.remove`. Removed in the next minor. */
                remove: (input: ExperimentalSessionInstructionsEntryRemoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            };
        };
        /** @deprecated Use `client.experimental.session.log`. Removed in the next minor. */
        log: (input: ExperimentalSessionLogInput) => Stream.Stream<ExperimentalSessionLogOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Sse.Retry | Schema.SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | Sse.SseError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    /** @deprecated Use `client.experimental.generate`. Removed in the next minor. */
    generate: {
        /** @deprecated Use `client.experimental.generate.text`. Removed in the next minor. */
        text: (input: ExperimentalGenerateTextInput) => Effect.Effect<ExperimentalGenerateTextOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
        /** @deprecated Use `client.experimental.generate.image`. Removed in the next minor. */
        image: (input: ExperimentalGenerateImageInput) => Effect.Effect<import("@opencode/schema/generate").ImageResult, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
        /** @deprecated Use `client.experimental.generate.decisions`. Removed in the next minor. */
        decisions: (input: ExperimentalGenerateDecisionsInput) => Effect.Effect<import("@opencode/schema/generate").DecisionResult, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
    };
    /** @deprecated Use `client.experimental.voice`. Removed in the next minor. */
    voice: {
        /** @deprecated Use `client.experimental.voice.models`. Removed in the next minor. */
        models: () => Effect.Effect<ExperimentalVoiceModelsOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.voice.session`. Removed in the next minor. */
        session: (input: ExperimentalVoiceSessionInput) => Effect.Effect<ExperimentalVoiceSessionOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    transcription: {
        transcribe: (input: TranscriptionTranscribeInput) => Effect.Effect<TranscriptionTranscribeOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        /** @deprecated Use `client.experimental.transcription.transcribeWithOverrides`. Removed in the next minor. */
        transcribeWithOverrides: (input: ExperimentalTranscriptionTranscribeWithOverridesInput) => Effect.Effect<ExperimentalTranscriptionTranscribeWithOverridesOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
    };
    integration: {
        list: (input?: IntegrationListInput) => Effect.Effect<IntegrationListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: IntegrationGetInput) => Effect.Effect<IntegrationGetOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        connect: {
            key: (input: IntegrationConnectKeyInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            external: (input: IntegrationConnectExternalInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        oauth: {
            connect: (input: IntegrationOauthConnectInput) => Effect.Effect<IntegrationOauthConnectOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            status: (input: IntegrationOauthStatusInput) => Effect.Effect<IntegrationOauthStatusOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").IntegrationAttemptNotFoundError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            complete: (input: IntegrationOauthCompleteInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").IntegrationAttemptNotFoundError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            cancel: (input: IntegrationOauthCancelInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        command: {
            connect: (input: IntegrationCommandConnectInput) => Effect.Effect<IntegrationCommandConnectOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").IntegrationMethodNotFoundError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            status: (input: IntegrationCommandStatusInput) => Effect.Effect<IntegrationCommandStatusOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").IntegrationAttemptNotFoundError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            cancel: (input: IntegrationCommandCancelInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        /** @deprecated Use `client.experimental.integration.wellknown`. Removed in the next minor. */
        wellknown: {
            /** @deprecated Use `client.experimental.integration.wellknown.add`. Removed in the next minor. */
            add: (input: ExperimentalIntegrationWellknownAddInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    mcp: {
        list: (input?: McpListInput) => Effect.Effect<McpListOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        resource: {
            catalog: (input?: McpResourceCatalogInput) => Effect.Effect<McpResourceCatalogOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        /** @deprecated Use `client.experimental.mcp.add`. Removed in the next minor. */
        add: (input: ExperimentalMcpAddInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.mcp.remove`. Removed in the next minor. */
        remove: (input: ExperimentalMcpRemoveInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.mcp.connect`. Removed in the next minor. */
        connect: (input: ExperimentalMcpConnectInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.mcp.disconnect`. Removed in the next minor. */
        disconnect: (input: ExperimentalMcpDisconnectInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.mcp.client`. Removed in the next minor. */
        client: {
            /** @deprecated Use `client.experimental.mcp.client.token`. Removed in the next minor. */
            token: (input: ExperimentalMcpClientTokenInput) => Effect.Effect<ExperimentalMcpClientTokenOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    file: {
        list: (input?: FileListInput) => Effect.Effect<FileListOutput, ClientError | import("@opencode/protocol/errors").FileNotFoundError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        find: (input: FileFindInput) => Effect.Effect<FileFindOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.file.watch`. Removed in the next minor. */
        watch: (input: ExperimentalFileWatchInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").FileNotFoundError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.file.unwatch`. Removed in the next minor. */
        unwatch: (input: ExperimentalFileUnwatchInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    /** @deprecated Use `client.experimental.migration`. Removed in the next minor. */
    migration: {
        /** @deprecated Use `client.experimental.migration.v1`. Removed in the next minor. */
        v1: {
            /** @deprecated Use `client.experimental.migration.v1.status`. Removed in the next minor. */
            status: () => Effect.Effect<ExperimentalMigrationV1StatusOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    /** @deprecated Use `client.experimental.usage`. Removed in the next minor. */
    usage: {
        /** @deprecated Use `client.experimental.usage.limits`. Removed in the next minor. */
        limits: (input?: ExperimentalUsageLimitsInput) => Effect.Effect<ExperimentalUsageLimitsOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    config: {
        get: (input?: ConfigGetInput) => Effect.Effect<ConfigGetOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        shells: () => Effect.Effect<ConfigShellsOutput, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        /** @deprecated Use `client.experimental.config.update`. Removed in the next minor. */
        update: (input: ExperimentalConfigUpdateInput) => Effect.Effect<void, ClientError | HttpClientError.HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | Schema.SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
}, never, import("effect/http/HttpClient").HttpClient>;
