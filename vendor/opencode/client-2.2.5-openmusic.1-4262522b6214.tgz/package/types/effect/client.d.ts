export * as OpenCode from "./client.js";
import { Effect, Stream } from "effect";
import { HttpClient } from "effect/http";
import { ClientError } from "./generated/index.js";
import type { EventSubscribeInput } from "./api.js";
import { RpcClientRuntime } from "./rpc.js";
import type { RpcCallOptions } from "../promise/rpc.js";
type EventType = NonNullable<EventSubscribeInput["types"]>[number];
export declare const make: (options?: {
    readonly baseUrl?: URL | string;
} | undefined) => Effect.Effect<{
    server: {
        info: () => Effect.Effect<import("./api.js").ServerInfoOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        pair: () => Effect.Effect<import("./api.js").ServerPairOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        connect: (input: import("./api.js").ServerConnectInput) => Effect.Effect<import("./api.js").ServerConnectOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    location: {
        get: (input?: import("./api.js").LocationGetInput) => Effect.Effect<import("@opencode/schema/location").PublicInfo, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        reload: () => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    agent: {
        list: (input?: import("./api.js").AgentListInput) => Effect.Effect<import("./api.js").AgentListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: import("./api.js").AgentGetInput) => Effect.Effect<import("./api.js").AgentGetOutput, import("@opencode/protocol/errors").AgentNotFoundError | ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    plugin: {
        list: (input?: import("./api.js").PluginListInput) => Effect.Effect<import("./api.js").PluginListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        gui: (input: import("./api.js").PluginGuiInput) => Effect.Effect<import("./api.js").PluginGuiOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PluginNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        check: (input?: import("./api.js").PluginCheckInput) => Effect.Effect<import("./api.js").PluginCheckOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        update: (input: import("./api.js").PluginUpdateInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    experimental: {
        persistentPty: {
            read: (input: import("./api.js").ExperimentalPersistentPtyReadInput) => Effect.Effect<import("./api.js").ExperimentalPersistentPtyReadOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            list: (input: import("./api.js").ExperimentalPersistentPtyListInput) => Effect.Effect<import("./api.js").ExperimentalPersistentPtyListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            create: (input: import("./api.js").ExperimentalPersistentPtyCreateInput) => Effect.Effect<import("./api.js").ExperimentalPersistentPtyCreateOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            shutdown: () => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            handoff: () => Effect.Effect<import("./api.js").ExperimentalPersistentPtyHandoffOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            get: (input: import("./api.js").ExperimentalPersistentPtyGetInput) => Effect.Effect<import("./api.js").ExperimentalPersistentPtyGetOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PtyNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            update: (input: import("./api.js").ExperimentalPersistentPtyUpdateInput) => Effect.Effect<import("./api.js").ExperimentalPersistentPtyUpdateOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PtyFeatureUnsupportedError | import("@opencode/protocol/errors").PtyNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            snapshot: (input: import("./api.js").ExperimentalPersistentPtySnapshotInput) => Effect.Effect<import("./api.js").ExperimentalPersistentPtySnapshotOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PtyNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            remove: (input: import("./api.js").ExperimentalPersistentPtyRemoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PtyNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            connectToken: (input: import("./api.js").ExperimentalPersistentPtyConnectTokenInput) => Effect.Effect<import("@opencode/schema/pty-ticket").ConnectToken, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PtyNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        schedule: {
            create: (input: import("./api.js").ExperimentalScheduleCreateInput) => Effect.Effect<{
                readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
                readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
                readonly name?: string | undefined;
                readonly when: {
                    readonly tz?: string | undefined;
                    readonly type: "in";
                    readonly in: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "at";
                    readonly at: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "every";
                    readonly every: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "cron";
                    readonly cron: string;
                };
                readonly tz: string;
                readonly if?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly until?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly action: {
                    readonly type: "prompt";
                    readonly prompt: string;
                };
                readonly status: "active" | "done" | "paused";
                readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
                readonly endsAt?: import("effect/DateTime").Utc | undefined;
                readonly remainingRuns?: number | undefined;
                readonly runCount: number;
                readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
                readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
                readonly lastOutput?: string | undefined;
                readonly time: {
                    readonly created: import("effect/DateTime").Utc;
                    readonly updated: import("effect/DateTime").Utc;
                };
            }, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            list: (input: import("./api.js").ExperimentalScheduleListInput) => Effect.Effect<import("./api.js").ExperimentalScheduleListOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            get: (input: import("./api.js").ExperimentalScheduleGetInput) => Effect.Effect<{
                readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
                readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
                readonly name?: string | undefined;
                readonly when: {
                    readonly tz?: string | undefined;
                    readonly type: "in";
                    readonly in: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "at";
                    readonly at: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "every";
                    readonly every: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "cron";
                    readonly cron: string;
                };
                readonly tz: string;
                readonly if?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly until?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly action: {
                    readonly type: "prompt";
                    readonly prompt: string;
                };
                readonly status: "active" | "done" | "paused";
                readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
                readonly endsAt?: import("effect/DateTime").Utc | undefined;
                readonly remainingRuns?: number | undefined;
                readonly runCount: number;
                readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
                readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
                readonly lastOutput?: string | undefined;
                readonly time: {
                    readonly created: import("effect/DateTime").Utc;
                    readonly updated: import("effect/DateTime").Utc;
                };
            }, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ScheduleNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            pause: (input: import("./api.js").ExperimentalSchedulePauseInput) => Effect.Effect<{
                readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
                readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
                readonly name?: string | undefined;
                readonly when: {
                    readonly tz?: string | undefined;
                    readonly type: "in";
                    readonly in: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "at";
                    readonly at: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "every";
                    readonly every: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "cron";
                    readonly cron: string;
                };
                readonly tz: string;
                readonly if?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly until?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly action: {
                    readonly type: "prompt";
                    readonly prompt: string;
                };
                readonly status: "active" | "done" | "paused";
                readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
                readonly endsAt?: import("effect/DateTime").Utc | undefined;
                readonly remainingRuns?: number | undefined;
                readonly runCount: number;
                readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
                readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
                readonly lastOutput?: string | undefined;
                readonly time: {
                    readonly created: import("effect/DateTime").Utc;
                    readonly updated: import("effect/DateTime").Utc;
                };
            }, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ScheduleNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            resume: (input: import("./api.js").ExperimentalScheduleResumeInput) => Effect.Effect<{
                readonly id: string & import("effect/Brand").Brand<"Schedule.ID">;
                readonly sessionID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
                readonly name?: string | undefined;
                readonly when: {
                    readonly tz?: string | undefined;
                    readonly type: "in";
                    readonly in: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "at";
                    readonly at: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "every";
                    readonly every: string;
                } | {
                    readonly tz?: string | undefined;
                    readonly type: "cron";
                    readonly cron: string;
                };
                readonly tz: string;
                readonly if?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly until?: {
                    readonly type: "code";
                    readonly code: string;
                } | {
                    readonly type: "shell";
                    readonly run: string;
                    readonly is?: string | undefined;
                    readonly matches?: string | undefined;
                    readonly changes?: boolean | undefined;
                } | undefined;
                readonly action: {
                    readonly type: "prompt";
                    readonly prompt: string;
                };
                readonly status: "active" | "done" | "paused";
                readonly nextDueAt?: import("effect/DateTime").Utc | undefined;
                readonly endsAt?: import("effect/DateTime").Utc | undefined;
                readonly remainingRuns?: number | undefined;
                readonly runCount: number;
                readonly lastFiredAt?: import("effect/DateTime").Utc | undefined;
                readonly lastOutcome?: "checked" | "disabled" | "expired" | "failed" | "fired" | "late" | "skipped" | undefined;
                readonly lastOutput?: string | undefined;
                readonly time: {
                    readonly created: import("effect/DateTime").Utc;
                    readonly updated: import("effect/DateTime").Utc;
                };
            }, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ScheduleNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            delete: (input: import("./api.js").ExperimentalScheduleDeleteInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ScheduleNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        artifacts: {
            providers: (input?: import("./api.js").ExperimentalArtifactsProvidersInput) => Effect.Effect<import("./api.js").ExperimentalArtifactsProvidersOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            list: (input?: import("./api.js").ExperimentalArtifactsListInput) => Effect.Effect<import("./api.js").ExperimentalArtifactsListOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            create: (input: import("./api.js").ExperimentalArtifactsCreateInput) => Effect.Effect<import("./api.js").ExperimentalArtifactsCreateOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            get: (input: import("./api.js").ExperimentalArtifactsGetInput) => Effect.Effect<import("./api.js").ExperimentalArtifactsGetOutput, import("@opencode/protocol/errors").ArtifactNotFoundError | ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            update: (input: import("./api.js").ExperimentalArtifactsUpdateInput) => Effect.Effect<import("./api.js").ExperimentalArtifactsUpdateOutput, import("@opencode/protocol/errors").ArtifactNotFoundError | ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            delete: (input: import("./api.js").ExperimentalArtifactsDeleteInput) => Effect.Effect<void, import("@opencode/protocol/errors").ArtifactNotFoundError | ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        job: {
            list: (input?: import("./api.js").ExperimentalJobListInput) => Effect.Effect<import("./api.js").ExperimentalJobListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        plugin: {
            webList: () => Effect.Effect<import("./api.js").ExperimentalPluginWebListOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            webModule: (input: import("./api.js").ExperimentalPluginWebModuleInput) => Effect.Effect<import("./api.js").ExperimentalPluginWebModuleOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PluginNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        session: {
            stats: (input?: import("./api.js").ExperimentalSessionStatsInput) => Effect.Effect<import("./api.js").ExperimentalSessionStatsOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            import: (input: import("./api.js").ExperimentalSessionImportInput) => Effect.Effect<import("@opencode/schema/session").Info, ClientError | import("@opencode/protocol/errors").ConflictError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            export: (input: import("./api.js").ExperimentalSessionExportInput) => Effect.Effect<import("./api.js").ExperimentalSessionExportOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
            skill: (input: import("./api.js").ExperimentalSessionSkillInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").SkillNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            wait: (input: import("./api.js").ExperimentalSessionWaitInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            instructions: {
                entry: {
                    list: (input: import("./api.js").ExperimentalSessionInstructionsEntryListInput) => Effect.Effect<import("./api.js").ExperimentalSessionInstructionsEntryListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
                    put: (input: import("./api.js").ExperimentalSessionInstructionsEntryPutInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/schema/instruction-entry").ValueTooLargeError, never>;
                    remove: (input: import("./api.js").ExperimentalSessionInstructionsEntryRemoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
                };
            };
            log: (input: import("./api.js").ExperimentalSessionLogInput) => Stream.Stream<import("./api.js").ExperimentalSessionLogOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/encoding/Sse").Retry | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("effect/encoding/Sse").SseError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        generate: {
            text: (input: import("./api.js").ExperimentalGenerateTextInput) => Effect.Effect<import("./api.js").ExperimentalGenerateTextOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
            image: (input: import("./api.js").ExperimentalGenerateImageInput) => Effect.Effect<import("@opencode/schema/generate").ImageResult, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
            decisions: (input: import("./api.js").ExperimentalGenerateDecisionsInput) => Effect.Effect<import("@opencode/schema/generate").DecisionResult, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
        };
        voice: {
            models: () => Effect.Effect<import("./api.js").ExperimentalVoiceModelsOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            session: (input: import("./api.js").ExperimentalVoiceSessionInput) => Effect.Effect<import("./api.js").ExperimentalVoiceSessionOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        transcription: {
            transcribeWithOverrides: (input: import("./api.js").ExperimentalTranscriptionTranscribeWithOverridesInput) => Effect.Effect<import("./api.js").ExperimentalTranscriptionTranscribeWithOverridesOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        };
        integration: {
            wellknown: {
                add: (input: import("./api.js").ExperimentalIntegrationWellknownAddInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            };
        };
        mcp: {
            add: (input: import("./api.js").ExperimentalMcpAddInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            remove: (input: import("./api.js").ExperimentalMcpRemoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            connect: (input: import("./api.js").ExperimentalMcpConnectInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            disconnect: (input: import("./api.js").ExperimentalMcpDisconnectInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            client: {
                token: (input: import("./api.js").ExperimentalMcpClientTokenInput) => Effect.Effect<import("./api.js").ExperimentalMcpClientTokenOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            };
        };
        file: {
            watch: (input: import("./api.js").ExperimentalFileWatchInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").FileNotFoundError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            unwatch: (input: import("./api.js").ExperimentalFileUnwatchInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        migration: {
            v1: {
                status: () => Effect.Effect<import("./api.js").ExperimentalMigrationV1StatusOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            };
        };
        usage: {
            limits: (input?: import("./api.js").ExperimentalUsageLimitsInput) => Effect.Effect<import("./api.js").ExperimentalUsageLimitsOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        config: {
            update: (input: import("./api.js").ExperimentalConfigUpdateInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    message: {
        list: (input: import("./api.js").MessageListInput) => Effect.Effect<import("./api.js").MessageListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidCursorError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
    };
    model: {
        list: (input?: import("./api.js").ModelListInput) => Effect.Effect<import("./api.js").ModelListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        default: (input?: import("./api.js").ModelDefaultInput) => Effect.Effect<import("./api.js").ModelDefaultOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    provider: {
        list: (input?: import("./api.js").ProviderListInput) => Effect.Effect<import("./api.js").ProviderListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: import("./api.js").ProviderGetInput) => Effect.Effect<import("./api.js").ProviderGetOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    credential: {
        list: () => Effect.Effect<import("./api.js").CredentialListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        create: (input: import("./api.js").CredentialCreateInput) => Effect.Effect<import("@opencode/schema/credential").Entry, ClientError | import("@opencode/protocol/errors").ConflictError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        update: (input: import("./api.js").CredentialUpdateInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        activate: (input: import("./api.js").CredentialActivateInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        remove: (input: import("./api.js").CredentialRemoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    project: {
        list: (input?: import("./api.js").ProjectListInput) => Effect.Effect<import("./api.js").ProjectListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        update: (input: import("./api.js").ProjectUpdateInput) => Effect.Effect<import("@opencode/schema/project").Info, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ProjectNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    form: {
        list: (input?: import("./api.js").FormListInput) => Effect.Effect<import("./api.js").FormListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    permission: {
        request: {
            list: (input?: import("./api.js").PermissionRequestListInput) => Effect.Effect<import("./api.js").PermissionRequestListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        saved: {
            list: (input?: import("./api.js").PermissionSavedListInput) => Effect.Effect<import("./api.js").PermissionSavedListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            update: (input: import("./api.js").PermissionSavedUpdateInput) => Effect.Effect<import("@opencode/schema/permission-saved").Info, ClientError | import("@opencode/protocol/errors").ConflictError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").PermissionSavedNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            remove: (input: import("./api.js").PermissionSavedRemoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        create: (input: import("./api.js").PermissionCreateInput) => Effect.Effect<import("./api.js").PermissionCreateOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        list: (input: import("./api.js").PermissionListInput) => Effect.Effect<import("./api.js").PermissionListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: import("./api.js").PermissionGetInput) => Effect.Effect<import("@opencode/schema/permission").Request, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PermissionNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        reply: (input: import("./api.js").PermissionReplyInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PermissionNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    command: {
        list: (input?: import("./api.js").CommandListInput) => Effect.Effect<import("./api.js").CommandListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    skill: {
        list: (input?: import("./api.js").SkillListInput) => Effect.Effect<import("./api.js").SkillListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    pty: {
        list: (input?: import("./api.js").PtyListInput) => Effect.Effect<import("./api.js").PtyListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        create: (input?: import("./api.js").PtyCreateInput) => Effect.Effect<import("./api.js").PtyCreateOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: import("./api.js").PtyGetInput) => Effect.Effect<import("./api.js").PtyGetOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PtyNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        update: (input: import("./api.js").PtyUpdateInput) => Effect.Effect<import("./api.js").PtyUpdateOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PtyNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        remove: (input: import("./api.js").PtyRemoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PtyNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        connect: {
            token: (input: import("./api.js").PtyConnectTokenInput) => Effect.Effect<import("./api.js").PtyConnectTokenOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").PtyNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    shell: {
        list: (input?: import("./api.js").ShellListInput) => Effect.Effect<import("./api.js").ShellListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        create: (input: import("./api.js").ShellCreateInput) => Effect.Effect<import("./api.js").ShellCreateOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: import("./api.js").ShellGetInput) => Effect.Effect<import("./api.js").ShellGetOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ShellNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        output: (input: import("./api.js").ShellOutputInput) => Effect.Effect<import("./api.js").ShellOutputOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ShellNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        remove: (input: import("./api.js").ShellRemoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    reference: {
        list: (input?: import("./api.js").ReferenceListInput) => Effect.Effect<import("./api.js").ReferenceListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    worktree: {
        list: (input: import("./api.js").WorktreeListInput) => Effect.Effect<readonly {
            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            readonly strategy?: string | undefined;
        }[], ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ProjectNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        create: (input: import("./api.js").WorktreeCreateInput) => Effect.Effect<import("@opencode/schema/worktree").Info, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ProjectNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/groups/worktree").WorktreeError, never>;
        remove: (input: import("./api.js").WorktreeRemoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ProjectNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/groups/worktree").WorktreeError, never>;
        refresh: (input: import("./api.js").WorktreeRefreshInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").ProjectNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/groups/worktree").WorktreeError, never>;
    };
    vcs: {
        init: (input?: import("./api.js").VcsInitInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").ConflictError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/groups/vcs").VcsInitNotSupportedError, never>;
        get: (input?: import("./api.js").VcsGetInput) => Effect.Effect<import("./api.js").VcsGetOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        base: (input?: import("./api.js").VcsBaseInput) => Effect.Effect<import("./api.js").VcsBaseOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        status: (input?: import("./api.js").VcsStatusInput) => Effect.Effect<import("./api.js").VcsStatusOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        branch: {
            list: (input?: import("./api.js").VcsBranchListInput) => Effect.Effect<import("./api.js").VcsBranchListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        diff: (input: import("./api.js").VcsDiffInput) => Effect.Effect<import("./api.js").VcsDiffOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    debug: {
        heapDump: (input?: import("./api.js").DebugHeapDumpInput) => Effect.Effect<import("./api.js").DebugHeapDumpOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        location: {
            list: () => Effect.Effect<import("./api.js").DebugLocationListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            evict: (input?: import("./api.js").DebugLocationEvictInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    websearch: {
        providers: (input?: import("./api.js").WebsearchProvidersInput) => Effect.Effect<import("./api.js").WebsearchProvidersOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        query: (input: import("./api.js").WebsearchQueryInput) => Effect.Effect<import("./api.js").WebsearchQueryOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    session: {
        list: (input?: import("./api.js").SessionListInput) => Effect.Effect<import("./api.js").SessionListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidCursorError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        create: (input?: import("./api.js").SessionCreateInput) => Effect.Effect<import("@opencode/schema/session").Info, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        active: () => Effect.Effect<import("./api.js").SessionActiveOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: import("./api.js").SessionGetInput) => Effect.Effect<import("@opencode/schema/session").Info, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        remove: (input: import("./api.js").SessionRemoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        fork: (input: import("./api.js").SessionForkInput) => Effect.Effect<import("@opencode/schema/session").Info, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").MessageNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        switchAgent: (input: import("./api.js").SessionSwitchAgentInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        switchModel: (input: import("./api.js").SessionSwitchModelInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        update: (input: import("./api.js").SessionUpdateInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        move: (input: import("./api.js").SessionMoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        prompt: (input: import("./api.js").SessionPromptInput) => Effect.Effect<import("@opencode/schema/session-inbox").User, ClientError | import("@opencode/protocol/errors").ConflictError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        command: (input: import("./api.js").SessionCommandInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").CommandExecutionError | import("@opencode/protocol/errors").CommandNotFoundError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        synthetic: (input: import("./api.js").SessionSyntheticInput) => Effect.Effect<import("@opencode/schema/session-inbox").Synthetic, ClientError | import("@opencode/protocol/errors").ConflictError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        shell: (input: import("./api.js").SessionShellInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        compact: (input: import("./api.js").SessionCompactInput) => Effect.Effect<import("@opencode/schema/session-inbox").Compaction, ClientError | import("@opencode/protocol/errors").ConflictError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        revert: {
            stage: (input: import("./api.js").SessionRevertStageInput) => Effect.Effect<import("@opencode/schema/session-revert").Revert, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").MessageNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionBusyError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
            clear: (input: import("./api.js").SessionRevertClearInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionBusyError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
            commit: (input: import("./api.js").SessionRevertCommitInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionBusyError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        context: (input: import("./api.js").SessionContextInput) => Effect.Effect<import("./api.js").SessionContextOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        diff: (input: import("./api.js").SessionDiffInput) => Effect.Effect<import("./api.js").SessionDiffOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").MessageNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        inbox: {
            list: (input: import("./api.js").SessionInboxListInput) => Effect.Effect<import("./api.js").SessionInboxListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            cancel: (input: import("./api.js").SessionInboxCancelInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            update: (input: import("./api.js").SessionInboxUpdateInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").ConflictError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        generate: (input: import("./api.js").SessionGenerateInput) => Effect.Effect<import("./api.js").SessionGenerateOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        interrupt: (input: import("./api.js").SessionInterruptInput) => Effect.Effect<import("./api.js").SessionInterruptOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        background: (input: import("./api.js").SessionBackgroundInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        message: {
            get: (input: import("./api.js").SessionMessageGetInput) => Effect.Effect<import("@opencode/schema/session-message").Info, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").MessageNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        form: {
            list: (input: import("./api.js").SessionFormListInput) => Effect.Effect<import("./api.js").SessionFormListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            create: (input: import("./api.js").SessionFormCreateInput) => Effect.Effect<import("@opencode/schema/form").Info, ClientError | import("@opencode/protocol/errors").ConflictError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            get: (input: import("./api.js").SessionFormGetInput) => Effect.Effect<import("@opencode/schema/form").Detail, ClientError | import("@opencode/protocol/errors").FormNotFoundError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            reply: (input: import("./api.js").SessionFormReplyInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").FormAlreadySettledError | import("@opencode/protocol/errors").FormInvalidAnswerError | import("@opencode/protocol/errors").FormNotFoundError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            cancel: (input: import("./api.js").SessionFormCancelInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").FormAlreadySettledError | import("@opencode/protocol/errors").FormNotFoundError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        environment: (input: import("./api.js").SessionEnvironmentInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        view: (input: import("./api.js").SessionViewInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        stats: (input?: import("./api.js").ExperimentalSessionStatsInput) => Effect.Effect<import("./api.js").ExperimentalSessionStatsOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        import: (input: import("./api.js").ExperimentalSessionImportInput) => Effect.Effect<import("@opencode/schema/session").Info, ClientError | import("@opencode/protocol/errors").ConflictError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        export: (input: import("./api.js").ExperimentalSessionExportInput) => Effect.Effect<import("./api.js").ExperimentalSessionExportOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        skill: (input: import("./api.js").ExperimentalSessionSkillInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").SkillNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        wait: (input: import("./api.js").ExperimentalSessionWaitInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        instructions: {
            entry: {
                list: (input: import("./api.js").ExperimentalSessionInstructionsEntryListInput) => Effect.Effect<import("./api.js").ExperimentalSessionInstructionsEntryListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
                put: (input: import("./api.js").ExperimentalSessionInstructionsEntryPutInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/schema/instruction-entry").ValueTooLargeError, never>;
                remove: (input: import("./api.js").ExperimentalSessionInstructionsEntryRemoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            };
        };
        log: (input: import("./api.js").ExperimentalSessionLogInput) => Stream.Stream<import("./api.js").ExperimentalSessionLogOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/encoding/Sse").Retry | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").SessionNotFoundError | import("effect/encoding/Sse").SseError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    generate: {
        text: (input: import("./api.js").ExperimentalGenerateTextInput) => Effect.Effect<import("./api.js").ExperimentalGenerateTextOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
        image: (input: import("./api.js").ExperimentalGenerateImageInput) => Effect.Effect<import("@opencode/schema/generate").ImageResult, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
        decisions: (input: import("./api.js").ExperimentalGenerateDecisionsInput) => Effect.Effect<import("@opencode/schema/generate").DecisionResult, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").ModelNotFoundError | import("@opencode/protocol/errors").ProviderNotFoundError | import("@opencode/protocol/errors").ProviderRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnsupportedModelError, never>;
    };
    voice: {
        models: () => Effect.Effect<import("./api.js").ExperimentalVoiceModelsOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        session: (input: import("./api.js").ExperimentalVoiceSessionInput) => Effect.Effect<import("./api.js").ExperimentalVoiceSessionOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    transcription: {
        transcribe: (input: import("./api.js").TranscriptionTranscribeInput) => Effect.Effect<import("./api.js").TranscriptionTranscribeOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
        transcribeWithOverrides: (input: import("./api.js").ExperimentalTranscriptionTranscribeWithOverridesInput) => Effect.Effect<import("./api.js").ExperimentalTranscriptionTranscribeWithOverridesOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").SessionNotFoundError | import("@opencode/protocol/errors").UnauthorizedError | import("@opencode/protocol/errors").UnknownError, never>;
    };
    integration: {
        list: (input?: import("./api.js").IntegrationListInput) => Effect.Effect<import("./api.js").IntegrationListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        get: (input: import("./api.js").IntegrationGetInput) => Effect.Effect<import("./api.js").IntegrationGetOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        connect: {
            key: (input: import("./api.js").IntegrationConnectKeyInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            external: (input: import("./api.js").IntegrationConnectExternalInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        oauth: {
            connect: (input: import("./api.js").IntegrationOauthConnectInput) => Effect.Effect<import("./api.js").IntegrationOauthConnectOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            status: (input: import("./api.js").IntegrationOauthStatusInput) => Effect.Effect<import("./api.js").IntegrationOauthStatusOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").IntegrationAttemptNotFoundError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            complete: (input: import("./api.js").IntegrationOauthCompleteInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").IntegrationAttemptNotFoundError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            cancel: (input: import("./api.js").IntegrationOauthCancelInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        command: {
            connect: (input: import("./api.js").IntegrationCommandConnectInput) => Effect.Effect<import("./api.js").IntegrationCommandConnectOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").IntegrationMethodNotFoundError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            status: (input: import("./api.js").IntegrationCommandStatusInput) => Effect.Effect<import("./api.js").IntegrationCommandStatusOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").IntegrationAttemptNotFoundError | import("@opencode/protocol/errors").IntegrationNotFoundError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
            cancel: (input: import("./api.js").IntegrationCommandCancelInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        wellknown: {
            add: (input: import("./api.js").ExperimentalIntegrationWellknownAddInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    mcp: {
        list: (input?: import("./api.js").McpListInput) => Effect.Effect<import("./api.js").McpListOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        resource: {
            catalog: (input?: import("./api.js").McpResourceCatalogInput) => Effect.Effect<import("./api.js").McpResourceCatalogOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
        add: (input: import("./api.js").ExperimentalMcpAddInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        remove: (input: import("./api.js").ExperimentalMcpRemoveInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        connect: (input: import("./api.js").ExperimentalMcpConnectInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        disconnect: (input: import("./api.js").ExperimentalMcpDisconnectInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").McpServerNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        client: {
            token: (input: import("./api.js").ExperimentalMcpClientTokenInput) => Effect.Effect<import("./api.js").ExperimentalMcpClientTokenOutput, ClientError | import("@opencode/protocol/errors").ForbiddenError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    file: {
        list: (input?: import("./api.js").FileListInput) => Effect.Effect<import("./api.js").FileListOutput, ClientError | import("@opencode/protocol/errors").FileNotFoundError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        find: (input: import("./api.js").FileFindInput) => Effect.Effect<import("./api.js").FileFindOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        watch: (input: import("./api.js").ExperimentalFileWatchInput) => Effect.Effect<void, ClientError | import("@opencode/protocol/errors").FileNotFoundError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        unwatch: (input: import("./api.js").ExperimentalFileUnwatchInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    migration: {
        v1: {
            status: () => Effect.Effect<import("./api.js").ExperimentalMigrationV1StatusOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        };
    };
    usage: {
        limits: (input?: import("./api.js").ExperimentalUsageLimitsInput) => Effect.Effect<import("./api.js").ExperimentalUsageLimitsOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").ServiceUnavailableError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    config: {
        get: (input?: import("./api.js").ConfigGetInput) => Effect.Effect<import("./api.js").ConfigGetOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        shells: () => Effect.Effect<import("./api.js").ConfigShellsOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
        update: (input: import("./api.js").ExperimentalConfigUpdateInput) => Effect.Effect<void, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    event: {
        subscribe: <Type extends EventType = "agent.updated" | "artifact.updated" | "command.updated" | "config.updated" | "credential.switched" | "credential.updated" | "filesystem.changed" | "form.cancelled" | "form.created" | "form.replied" | "installation.update-available" | "installation.updated" | "integration.updated" | "location.shutdown" | "mcp.resources.changed" | "mcp.status.changed" | "model.updated" | "models-dev.refreshed" | "permission.asked" | "permission.replied" | "persistent-pty.added" | "persistent-pty.removed" | "persistent-pty.updated" | "plugin.updated" | "project.updated" | "provider.updated" | "pty.created" | "pty.deleted" | "pty.exited" | "pty.updated" | "reference.updated" | "session.agent.selected" | "session.archived" | "session.compaction.delta" | "session.compaction.ended" | "session.compaction.failed" | "session.compaction.started" | "session.created" | "session.deleted" | "session.execution.failed" | "session.execution.interrupted" | "session.execution.started" | "session.execution.succeeded" | "session.forked" | "session.idle" | "session.inbox.cancelled" | "session.inbox.delivered" | "session.inbox.delivery.changed" | "session.inbox.enqueued" | "session.instructions.updated" | "session.metadata.updated" | "session.model.selected" | "session.moved" | "session.permissions" | "session.reasoning.delta" | "session.reasoning.ended" | "session.reasoning.started" | "session.renamed" | "session.retry.scheduled" | "session.revert.cleared" | "session.revert.committed" | "session.revert.staged" | "session.shell.ended" | "session.shell.started" | "session.skill.activated" | "session.status" | "session.step.ended" | "session.step.failed" | "session.step.started" | "session.step.streamed" | "session.synthetic" | "session.text.delta" | "session.text.ended" | "session.text.started" | "session.tool.called" | "session.tool.failed" | "session.tool.input.delta" | "session.tool.input.ended" | "session.tool.input.started" | "session.tool.progress" | "session.tool.success" | "session.unarchived" | "session.usage.updated" | "session.viewed" | "shell.created" | "shell.deleted" | "shell.exited" | "skill.updated" | "tui.command.execute" | "tui.prompt.append" | "tui.session.select" | "tui.toast.show" | "vcs.branch.updated" | "websearch.updated" | "worktree.resolved" | "worktree.updated" | `rpc.${string}`>(input?: {
            readonly types?: ReadonlyArray<Type>;
        }) => Stream.Stream<([Extract<Type, "session.agent.selected">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.agent.selected";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly agent: string & import("effect/Brand").Brand<"Agent.ID">;
                readonly previous?: (string & import("effect/Brand").Brand<"Agent.ID">) | undefined;
            };
        }) | ([Extract<Type, "session.archived">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.archived";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        }) | ([Extract<Type, "session.compaction.ended">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.compaction.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly reason: "auto" | "manual";
                readonly model?: {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                } | undefined;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
                readonly text: string;
                readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
                readonly tokens?: {
                    readonly input: number;
                    readonly output: number;
                    readonly reasoning: number;
                    readonly cache: {
                        readonly read: number;
                        readonly write: number;
                    };
                } | undefined;
            };
        }) | ([Extract<Type, "session.compaction.failed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.compaction.failed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly reason: "auto" | "manual";
                readonly error: {
                    readonly type: string;
                    readonly message: string;
                    readonly status?: number | undefined;
                    readonly response?: {
                        readonly body: string;
                    } | undefined;
                    readonly retryAfterMs?: number | undefined;
                };
                readonly inputID?: (string & import("effect/Brand").Brand<"Session.Message.ID">) | undefined;
                readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
                readonly tokens?: {
                    readonly input: number;
                    readonly output: number;
                    readonly reasoning: number;
                    readonly cache: {
                        readonly read: number;
                        readonly write: number;
                    };
                } | undefined;
            };
        }) | ([Extract<Type, "session.compaction.started">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.compaction.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly reason: "auto" | "manual";
                readonly inputID?: (string & import("effect/Brand").Brand<"Session.Message.ID">) | undefined;
            };
        }) | ([Extract<Type, "session.created">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.created";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
                readonly location: {
                    readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                    readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
                };
                readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
                readonly parentID?: (string & import("effect/Brand").Brand<"SessionID">) | undefined;
                readonly slug: string;
                readonly title?: string | undefined;
                readonly agent?: (string & import("effect/Brand").Brand<"Agent.ID">) | undefined;
                readonly model?: {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                } | undefined;
                readonly metadata?: {
                    readonly [x: string]: import("effect/Schema").Json;
                } | undefined;
                readonly permissions?: readonly {
                    readonly action: string;
                    readonly resource: string;
                    readonly effect: "allow" | "ask" | "deny";
                }[] | undefined;
                readonly version: string;
            };
        }) | ([Extract<Type, "session.deleted">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.deleted";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        }) | ([Extract<Type, "session.execution.failed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.execution.failed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly error: {
                    readonly type: string;
                    readonly message: string;
                    readonly status?: number | undefined;
                    readonly response?: {
                        readonly body: string;
                    } | undefined;
                    readonly retryAfterMs?: number | undefined;
                };
            };
        }) | ([Extract<Type, "session.execution.interrupted">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.execution.interrupted";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly reason: "inactivity" | "shutdown" | "superseded" | "user";
            };
        }) | ([Extract<Type, "session.execution.started">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.execution.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        }) | ([Extract<Type, "session.execution.succeeded">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.execution.succeeded";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        }) | ([Extract<Type, "session.forked">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.forked";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly parentID: string & import("effect/Brand").Brand<"SessionID">;
                readonly boundary: {
                    readonly type: "before";
                    readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                } | {
                    readonly type: "through";
                    readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                };
                readonly instructions?: {
                    readonly [x: string & import("effect/Brand").Brand<"Instruction.Key">]: string & import("effect/Brand").Brand<"Instruction.Hash">;
                } | undefined;
                readonly instructionEntries?: readonly {
                    readonly key: string;
                    readonly value: import("effect/Schema").Json;
                    readonly removed: boolean;
                }[] | undefined;
            };
        }) | ([Extract<Type, "session.inbox.cancelled">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.inbox.cancelled";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }) | ([Extract<Type, "session.inbox.delivered">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.inbox.delivered";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }) | ([Extract<Type, "session.inbox.delivery.changed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.inbox.delivery.changed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly delivery: "queue" | "steer";
            };
        }) | ([Extract<Type, "session.inbox.enqueued">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.inbox.enqueued";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly inboxID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly item: {
                    readonly type: "user";
                    readonly payload: {
                        readonly text: string;
                        readonly files?: readonly {
                            readonly data: string;
                            readonly mime: string;
                            readonly source: {
                                readonly type: "inline";
                            } | {
                                readonly type: "uri";
                                readonly uri: string;
                            };
                            readonly name?: string | undefined;
                            readonly description?: string | undefined;
                            readonly mention?: {
                                readonly start: number;
                                readonly end: number;
                                readonly text: string;
                            } | undefined;
                        }[] | undefined;
                        readonly agents?: readonly {
                            readonly name: string;
                            readonly mention?: {
                                readonly start: number;
                                readonly end: number;
                                readonly text: string;
                            } | undefined;
                        }[] | undefined;
                        readonly skills?: readonly {
                            readonly id: string & import("effect/Brand").Brand<"Skill.ID">;
                            readonly name: string & import("effect/Brand").Brand<"Skill.Name">;
                            readonly text?: string | undefined;
                            readonly mention?: {
                                readonly start: number;
                                readonly end: number;
                                readonly text: string;
                            } | undefined;
                        }[] | undefined;
                        readonly metadata?: {
                            readonly [x: string]: unknown;
                        } | undefined;
                    };
                    readonly delivery: "queue" | "steer";
                } | {
                    readonly type: "synthetic";
                    readonly payload: {
                        readonly text: string;
                        readonly description?: string | undefined;
                        readonly metadata?: {
                            readonly [x: string]: unknown;
                        } | undefined;
                    };
                    readonly delivery: "queue" | "steer";
                } | {
                    readonly type: "compaction";
                    readonly payload: {};
                    readonly delivery: "queue" | "steer";
                } | {
                    readonly type: "move";
                    readonly payload: {
                        readonly location: {
                            readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                            readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
                        };
                        readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
                        readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
                    };
                    readonly delivery: "queue" | "steer";
                };
            };
        }) | ([Extract<Type, "session.instructions.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.instructions.updated";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly delta: {
                    readonly [x: string]: "removed" | (string & import("effect/Brand").Brand<"Instruction.Hash">);
                };
                readonly text?: string | undefined;
            };
        }) | ([Extract<Type, "session.metadata.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.metadata.updated";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly metadata: {
                    readonly [x: string]: import("effect/Schema").Json;
                };
            };
        }) | ([Extract<Type, "session.model.selected">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.model.selected";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly model: {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
                readonly previous?: {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                } | undefined;
            };
        }) | ([Extract<Type, "session.moved">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.moved";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly location: {
                    readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                    readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
                };
                readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
                readonly subpath?: (string & import("effect/Brand").Brand<"RelativePath">) | undefined;
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        }) | ([Extract<Type, "session.permissions">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.permissions";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly permissions: readonly {
                    readonly action: string;
                    readonly resource: string;
                    readonly effect: "allow" | "ask" | "deny";
                }[];
            };
        }) | ([Extract<Type, "session.reasoning.ended">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.reasoning.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
                readonly text: string;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        }) | ([Extract<Type, "session.reasoning.started">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.reasoning.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        }) | ([Extract<Type, "session.renamed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.renamed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly title: string;
            };
        }) | ([Extract<Type, "session.retry.scheduled">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.retry.scheduled";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly attempt: number;
                readonly at: number;
                readonly error: {
                    readonly type: string;
                    readonly message: string;
                    readonly status?: number | undefined;
                    readonly response?: {
                        readonly body: string;
                    } | undefined;
                    readonly retryAfterMs?: number | undefined;
                };
            };
        }) | ([Extract<Type, "session.revert.cleared">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.revert.cleared";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        }) | ([Extract<Type, "session.revert.committed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.revert.committed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly to: string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }) | ([Extract<Type, "session.revert.staged">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.revert.staged";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly revert: {
                    readonly messageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                    readonly partID?: string | undefined;
                    readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
                    readonly files?: readonly {
                        readonly file: string;
                        readonly patch: string;
                        readonly additions: number;
                        readonly deletions: number;
                        readonly status: "added" | "deleted" | "modified";
                        readonly more?: true | undefined;
                    }[] | undefined;
                };
            };
        }) | ([Extract<Type, "session.shell.ended">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.shell.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly shell: {
                    readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
                    readonly status: "exited" | "killed" | "running" | "timeout";
                    readonly command: string;
                    readonly cwd: string;
                    readonly shell: string;
                    readonly file: string;
                    readonly pid?: number | undefined;
                    readonly exit?: number | undefined;
                    readonly signal?: string | undefined;
                    readonly metadata: {
                        readonly [x: string]: unknown;
                    };
                    readonly time: {
                        readonly started: number;
                        readonly completed?: number | undefined;
                    };
                };
                readonly output: {
                    readonly output: string;
                    readonly cursor: number;
                    readonly size: number;
                    readonly truncated: boolean;
                };
            };
        }) | ([Extract<Type, "session.shell.started">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.shell.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly shell: {
                    readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
                    readonly status: "exited" | "killed" | "running" | "timeout";
                    readonly command: string;
                    readonly cwd: string;
                    readonly shell: string;
                    readonly file: string;
                    readonly pid?: number | undefined;
                    readonly exit?: number | undefined;
                    readonly signal?: string | undefined;
                    readonly metadata: {
                        readonly [x: string]: unknown;
                    };
                    readonly time: {
                        readonly started: number;
                        readonly completed?: number | undefined;
                    };
                };
            };
        }) | ([Extract<Type, "session.skill.activated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.skill.activated";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly id: string & import("effect/Brand").Brand<"Skill.ID">;
                readonly name: string & import("effect/Brand").Brand<"Skill.Name">;
                readonly text: string;
            };
        }) | ([Extract<Type, "session.step.ended">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.step.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly finish: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly rawFinish?: string | undefined;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
                readonly cost: number & import("effect/Brand").Brand<"Money.USD">;
                readonly tokens: {
                    readonly input: number;
                    readonly output: number;
                    readonly reasoning: number;
                    readonly cache: {
                        readonly read: number;
                        readonly write: number;
                    };
                };
                readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
                readonly files?: readonly (string & import("effect/Brand").Brand<"RelativePath">)[] | undefined;
            };
        }) | ([Extract<Type, "session.step.failed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.step.failed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly error: {
                    readonly type: string;
                    readonly message: string;
                    readonly status?: number | undefined;
                    readonly response?: {
                        readonly body: string;
                    } | undefined;
                    readonly retryAfterMs?: number | undefined;
                };
                readonly finish?: "content-filter" | undefined;
                readonly rawFinish?: string | undefined;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
                readonly cost?: (number & import("effect/Brand").Brand<"Money.USD">) | undefined;
                readonly tokens?: {
                    readonly input: number;
                    readonly output: number;
                    readonly reasoning: number;
                    readonly cache: {
                        readonly read: number;
                        readonly write: number;
                    };
                } | undefined;
                readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
                readonly files?: readonly (string & import("effect/Brand").Brand<"RelativePath">)[] | undefined;
            };
        }) | ([Extract<Type, "session.step.started">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.step.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly agent: string & import("effect/Brand").Brand<"Agent.ID">;
                readonly model: {
                    readonly id: string & import("effect/Brand").Brand<"Model.ID">;
                    readonly providerID: string & import("effect/Brand").Brand<"Provider.ID">;
                    readonly variant?: (string & import("effect/Brand").Brand<"Model.VariantID">) | undefined;
                };
                readonly snapshot?: (string & import("effect/Brand").Brand<"Snapshot.ID">) | undefined;
                readonly started: number;
            };
        }) | ([Extract<Type, "session.step.streamed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.step.streamed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
            };
        }) | ([Extract<Type, "session.synthetic">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.synthetic";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly text: string;
                readonly description?: string | undefined;
                readonly metadata?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        }) | ([Extract<Type, "session.text.ended">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.text.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
                readonly text: string;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        }) | ([Extract<Type, "session.text.started">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.text.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
            };
        }) | ([Extract<Type, "session.tool.called">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.called";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly input: {
                    readonly [x: string]: unknown;
                };
                readonly executed: boolean;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        }) | ([Extract<Type, "session.tool.failed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.failed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly error: {
                    readonly type: string;
                    readonly message: string;
                    readonly status?: number | undefined;
                    readonly response?: {
                        readonly body: string;
                    } | undefined;
                    readonly retryAfterMs?: number | undefined;
                };
                readonly content?: readonly [{
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                }, ...({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[]] | undefined;
                readonly metadata?: {
                    readonly [x: string]: import("effect/Schema").Json;
                } | undefined;
                readonly executed: boolean;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        }) | ([Extract<Type, "session.tool.input.ended">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.input.ended";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly text: string;
            };
        }) | ([Extract<Type, "session.tool.input.started">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.input.started";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly name: string;
            };
        }) | ([Extract<Type, "session.tool.success">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.success";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly content: readonly [{
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                }, ...({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[]];
                readonly metadata?: {
                    readonly [x: string]: import("effect/Schema").Json;
                } | undefined;
                readonly executed: boolean;
                readonly native?: {
                    readonly [x: string]: unknown;
                } | undefined;
            };
        }) | ([Extract<Type, "session.unarchived">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.unarchived";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        }) | ([Extract<Type, "session.viewed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.viewed";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly idle: number;
            };
        }) | ([Extract<Type, "worktree.resolved">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "worktree.resolved";
            readonly durable: {
                readonly aggregateID: string;
                readonly seq: number & import("effect/Brand").Brand<"Event.Seq">;
                readonly version: number & import("effect/Brand").Brand<"Event.Version">;
            };
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly previous: string & import("effect/Brand").Brand<"Project.ID">;
                readonly adopted?: readonly (string & import("effect/Brand").Brand<"Project.ID">)[] | undefined;
            };
        }) | ([Extract<Type, "agent.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "agent.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "artifact.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "artifact.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "command.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "command.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "config.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "config.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "credential.switched">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "credential.switched";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly integrationID: string & import("effect/Brand").Brand<"Integration.ID">;
                readonly credentialID: (string & import("effect/Brand").Brand<"Credential.ID">) | null;
            };
        }) | ([Extract<Type, "credential.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "credential.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly integrationID: string & import("effect/Brand").Brand<"Integration.ID">;
                readonly credentialID: string & import("effect/Brand").Brand<"Credential.ID">;
            };
        }) | ([Extract<Type, "filesystem.changed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "filesystem.changed";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly file: string;
                readonly event: "add" | "change" | "unlink";
            };
        }) | ([Extract<Type, "form.cancelled">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "form.cancelled";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"Form.ID">;
                readonly sessionID: string;
            };
        }) | ([Extract<Type, "form.created">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "form.created";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly form: {
                    readonly id: string & import("effect/Brand").Brand<"Form.ID">;
                    readonly sessionID: string;
                    readonly title: string;
                    readonly metadata?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                    readonly fields: readonly [{
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "string";
                        readonly format?: "date" | "date-time" | "email" | "uri" | undefined;
                        readonly minLength?: number | undefined;
                        readonly maxLength?: number | undefined;
                        readonly pattern?: string | undefined;
                        readonly placeholder?: string | undefined;
                        readonly default?: string | undefined;
                        readonly options?: readonly {
                            readonly value: string;
                            readonly label: string;
                            readonly description?: string | undefined;
                        }[] | undefined;
                        readonly custom?: boolean | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "number";
                        readonly minimum?: number | undefined;
                        readonly maximum?: number | undefined;
                        readonly default?: number | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "integer";
                        readonly minimum?: number | undefined;
                        readonly maximum?: number | undefined;
                        readonly default?: number | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "boolean";
                        readonly default?: boolean | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "multiselect";
                        readonly options: readonly {
                            readonly value: string;
                            readonly label: string;
                            readonly description?: string | undefined;
                        }[];
                        readonly minItems?: number | undefined;
                        readonly maxItems?: number | undefined;
                        readonly custom?: boolean | undefined;
                        readonly default?: readonly string[] | undefined;
                    } | {
                        readonly key: string;
                        readonly type: "external";
                        readonly url: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                    }, ...({
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "string";
                        readonly format?: "date" | "date-time" | "email" | "uri" | undefined;
                        readonly minLength?: number | undefined;
                        readonly maxLength?: number | undefined;
                        readonly pattern?: string | undefined;
                        readonly placeholder?: string | undefined;
                        readonly default?: string | undefined;
                        readonly options?: readonly {
                            readonly value: string;
                            readonly label: string;
                            readonly description?: string | undefined;
                        }[] | undefined;
                        readonly custom?: boolean | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "number";
                        readonly minimum?: number | undefined;
                        readonly maximum?: number | undefined;
                        readonly default?: number | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "integer";
                        readonly minimum?: number | undefined;
                        readonly maximum?: number | undefined;
                        readonly default?: number | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "boolean";
                        readonly default?: boolean | undefined;
                    } | {
                        readonly key: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                        readonly required?: boolean | undefined;
                        readonly hidden?: boolean | undefined;
                        readonly when?: readonly {
                            readonly key: string;
                            readonly op: "eq" | "neq";
                            readonly value: string | number | boolean;
                        }[] | undefined;
                        readonly type: "multiselect";
                        readonly options: readonly {
                            readonly value: string;
                            readonly label: string;
                            readonly description?: string | undefined;
                        }[];
                        readonly minItems?: number | undefined;
                        readonly maxItems?: number | undefined;
                        readonly custom?: boolean | undefined;
                        readonly default?: readonly string[] | undefined;
                    } | {
                        readonly key: string;
                        readonly type: "external";
                        readonly url: string;
                        readonly title?: string | undefined;
                        readonly description?: string | undefined;
                    })[]];
                };
            };
        }) | ([Extract<Type, "form.replied">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "form.replied";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"Form.ID">;
                readonly sessionID: string;
                readonly answer: {
                    readonly [x: string]: string | number | boolean | readonly string[];
                };
            };
        }) | ([Extract<Type, "installation.update-available">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "installation.update-available";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly version: string;
            };
        }) | ([Extract<Type, "installation.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "installation.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly version: string;
            };
        }) | ([Extract<Type, "integration.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "integration.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "location.shutdown">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "location.shutdown";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "mcp.resources.changed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "mcp.resources.changed";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly server: string;
            };
        }) | ([Extract<Type, "mcp.status.changed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "mcp.status.changed";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly server: string;
            };
        }) | ([Extract<Type, "model.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "model.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "models-dev.refreshed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "models-dev.refreshed";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "permission.asked">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "permission.asked";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly action: string;
                readonly resources: readonly string[];
                readonly save?: readonly string[] | undefined;
                readonly metadata?: {
                    readonly [x: string]: unknown;
                } | undefined;
                readonly source?: {
                    readonly type: "tool";
                    readonly messageID: string;
                    readonly id: string;
                } | undefined;
                readonly message?: string | undefined;
                readonly id: string & import("effect/Brand").Brand<"Permission.ID">;
            };
        }) | ([Extract<Type, "permission.replied">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "permission.replied";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly requestID: string & import("effect/Brand").Brand<"Permission.ID">;
                readonly reply: "always" | "once" | "reject";
            };
        }) | ([Extract<Type, "persistent-pty.added">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "persistent-pty.added";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly terminal: {
                    readonly id: string & import("effect/Brand").Brand<"PtyID">;
                    readonly title: string;
                    readonly command: string;
                    readonly args: readonly string[];
                    readonly cwd: string;
                    readonly status: "exited" | "running";
                    readonly pid: number;
                    readonly exitCode?: number | undefined;
                    readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                    readonly userTitle: string | null;
                    readonly foregroundProcess: string | null;
                    readonly size: {
                        readonly cols: number;
                        readonly rows: number;
                    };
                    readonly output: {
                        readonly head: number;
                        readonly tail: number;
                    };
                };
            };
        }) | ([Extract<Type, "persistent-pty.removed">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "persistent-pty.removed";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly ptyID: string & import("effect/Brand").Brand<"PtyID">;
            };
        }) | ([Extract<Type, "persistent-pty.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "persistent-pty.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly terminal: {
                    readonly id: string & import("effect/Brand").Brand<"PtyID">;
                    readonly title: string;
                    readonly command: string;
                    readonly args: readonly string[];
                    readonly cwd: string;
                    readonly status: "exited" | "running";
                    readonly pid: number;
                    readonly exitCode?: number | undefined;
                    readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                    readonly userTitle: string | null;
                    readonly foregroundProcess: string | null;
                    readonly size: {
                        readonly cols: number;
                        readonly rows: number;
                    };
                    readonly output: {
                        readonly head: number;
                        readonly tail: number;
                    };
                };
            };
        }) | ([Extract<Type, "plugin.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "plugin.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "project.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "project.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"Project.ID">;
                readonly canonical: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly vcs?: string | undefined;
                readonly name?: string | undefined;
                readonly icon?: {
                    readonly url?: string | undefined;
                    readonly override?: string | undefined;
                    readonly color?: string | undefined;
                } | undefined;
                readonly commands?: {
                    readonly start?: string | undefined;
                } | undefined;
                readonly time: {
                    readonly created: number;
                    readonly updated: number;
                    readonly active: number;
                    readonly archived?: number | undefined;
                };
                readonly sandboxes: readonly string[];
            };
        }) | ([Extract<Type, "provider.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "provider.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "pty.created">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "pty.created";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly info: {
                    readonly id: string & import("effect/Brand").Brand<"PtyID">;
                    readonly title: string;
                    readonly command: string;
                    readonly args: readonly string[];
                    readonly cwd: string;
                    readonly status: "exited" | "running";
                    readonly pid: number;
                    readonly exitCode?: number | undefined;
                };
            };
        }) | ([Extract<Type, "pty.deleted">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "pty.deleted";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"PtyID">;
            };
        }) | ([Extract<Type, "pty.exited">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "pty.exited";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"PtyID">;
                readonly exitCode: number;
            };
        }) | ([Extract<Type, "pty.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "pty.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly info: {
                    readonly id: string & import("effect/Brand").Brand<"PtyID">;
                    readonly title: string;
                    readonly command: string;
                    readonly args: readonly string[];
                    readonly cwd: string;
                    readonly status: "exited" | "running";
                    readonly pid: number;
                    readonly exitCode?: number | undefined;
                };
            };
        }) | ([Extract<Type, "reference.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "reference.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "session.compaction.delta">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.compaction.delta";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly text: string;
            };
        }) | ([Extract<Type, "session.idle">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.idle";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        }) | ([Extract<Type, "session.reasoning.delta">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.reasoning.delta";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
                readonly delta: string;
            };
        }) | ([Extract<Type, "session.status">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.status";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly status: {
                    readonly type: "idle";
                } | {
                    readonly type: "busy";
                } | {
                    readonly type: "retry";
                    readonly attempt: number;
                    readonly message: string;
                    readonly action?: {
                        readonly reason: string;
                        readonly provider: string;
                        readonly title: string;
                        readonly message: string;
                        readonly label: string;
                        readonly link?: string | undefined;
                    } | undefined;
                    readonly next: number;
                };
            };
        }) | ([Extract<Type, "session.text.delta">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.text.delta";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly ordinal: number;
                readonly delta: string;
            };
        }) | ([Extract<Type, "session.tool.input.delta">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.input.delta";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly delta: string;
            };
        }) | ([Extract<Type, "session.tool.progress">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.tool.progress";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly assistantMessageID: string & import("effect/Brand").Brand<"Session.Message.ID">;
                readonly id: string;
                readonly metadata: {
                    readonly [x: string]: import("effect/Schema").Json;
                };
            };
        }) | ([Extract<Type, "session.usage.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "session.usage.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
                readonly cost: number & import("effect/Brand").Brand<"Money.USD">;
                readonly tokens: {
                    readonly input: number;
                    readonly output: number;
                    readonly reasoning: number;
                    readonly cache: {
                        readonly read: number;
                        readonly write: number;
                    };
                };
            };
        }) | ([Extract<Type, "shell.created">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "shell.created";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly info: {
                    readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
                    readonly status: "exited" | "killed" | "running" | "timeout";
                    readonly command: string;
                    readonly cwd: string;
                    readonly shell: string;
                    readonly file: string;
                    readonly pid?: number | undefined;
                    readonly exit?: number | undefined;
                    readonly signal?: string | undefined;
                    readonly metadata: {
                        readonly [x: string]: unknown;
                    };
                    readonly time: {
                        readonly started: number;
                        readonly completed?: number | undefined;
                    };
                };
            };
        }) | ([Extract<Type, "shell.deleted">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "shell.deleted";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
            };
        }) | ([Extract<Type, "shell.exited">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "shell.exited";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly id: string & import("effect/Brand").Brand<"Shell.ID">;
                readonly exit?: number | undefined;
                readonly status: "exited" | "killed" | "running" | "timeout";
            };
        }) | ([Extract<Type, "skill.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "skill.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "tui.command.execute">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "tui.command.execute";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly command: string;
            };
        }) | ([Extract<Type, "tui.prompt.append">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "tui.prompt.append";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly text: string;
            };
        }) | ([Extract<Type, "tui.session.select">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "tui.session.select";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly sessionID: string & import("effect/Brand").Brand<"SessionID">;
            };
        }) | ([Extract<Type, "tui.toast.show">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "tui.toast.show";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly title?: string | undefined;
                readonly message: string;
                readonly variant: "error" | "info" | "success" | "warning";
                readonly duration: number;
            };
        }) | ([Extract<Type, "vcs.branch.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "vcs.branch.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly branch?: string | undefined;
            };
        }) | ([Extract<Type, "websearch.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "websearch.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {};
        }) | ([Extract<Type, "worktree.updated">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: "worktree.updated";
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
                readonly workspaceID?: (string & import("effect/Brand").Brand<"Workspace.ID">) | undefined;
            } | undefined;
            readonly data: {
                readonly projectID: string & import("effect/Brand").Brand<"Project.ID">;
            };
        }) | ([Extract<Type, `rpc.${string}`>] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly created: number;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly type: `rpc.${string}`;
            readonly location: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            };
            readonly data: {
                readonly [x: string]: unknown;
            };
        }) | (["server.connected" | Extract<Type, "server.connected">] extends [never] ? never : {
            readonly id: string & import("effect/Brand").Brand<"Event.ID">;
            readonly metadata?: {
                readonly [x: string]: unknown;
            } | undefined;
            readonly location?: {
                readonly directory: string & import("effect/Brand").Brand<"AbsolutePath">;
            } | undefined;
            readonly type: "server.connected";
            readonly data: {};
        }), ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/encoding/Sse").Retry | import("effect/Schema").SchemaError | import("effect/encoding/Sse").SseError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
    rpc: RpcClientRuntime.RpcApi<ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("effect/Schema").SchemaError | import("@opencode/schema/rpc").SystemError | import("@opencode/protocol/errors").UnauthorizedError, RpcCallOptions, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("effect/encoding/Sse").Retry | import("effect/Schema").SchemaError | import("effect/encoding/Sse").SseError | import("@opencode/protocol/errors").UnauthorizedError> & {
        call: (input: import("./api.js").RpcCallInput) => Effect.Effect<import("./api.js").RpcCallOutput, ClientError | import("effect/http/HttpClientError").HttpClientError | import("@opencode/protocol/errors").InvalidRequestError | import("@opencode/protocol/errors").LocationNotFoundError | import("@opencode/protocol/errors").RpcError | import("@opencode/protocol/errors").RpcInternalError | import("effect/Schema").SchemaError | import("@opencode/protocol/errors").UnauthorizedError, never>;
    };
}, never, HttpClient.HttpClient>;
