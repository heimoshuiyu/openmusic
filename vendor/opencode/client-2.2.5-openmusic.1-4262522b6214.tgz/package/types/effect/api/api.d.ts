import type { Effect, Stream } from "effect";
import type { Location } from "@opencode/schema/location";
import type { Agent } from "@opencode/schema/agent";
import type { Plugin } from "@opencode/schema/plugin";
import type { Session } from "@opencode/schema/session";
import type { AbsolutePath } from "@opencode/schema/schema";
import type { Project } from "@opencode/schema/project";
import type { RelativePath } from "@opencode/schema/schema";
import type { Model } from "@opencode/schema/model";
import type { Permission } from "@opencode/schema/permission";
import type { SessionMessage } from "@opencode/schema/session-message";
import type { SessionInbox } from "@opencode/schema/session-inbox";
import type { PromptInput } from "@opencode/schema/prompt-input";
import type { AgentAttachment } from "@opencode/schema/prompt";
import type { FileDiff } from "@opencode/schema/file-diff";
import type { Form } from "@opencode/schema/form";
import type { DateTime } from "effect";
import type { Money } from "@opencode/schema/money";
import type { Skill } from "@opencode/schema/skill";
import type { InstructionEntry } from "@opencode/schema/instruction-entry";
import type { Schema } from "effect";
import type { Event } from "@opencode/schema/event";
import type { EventLog } from "@opencode/schema/event-log";
import type { Workspace } from "@opencode/schema/workspace";
import type { Instruction } from "@opencode/schema/instruction";
import type { Snapshot } from "@opencode/schema/snapshot";
import type { Shell } from "@opencode/schema/shell";
import type { Generate } from "@opencode/schema/generate";
import type { Provider } from "@opencode/schema/provider";
import type { Integration } from "@opencode/schema/integration";
import type { Mcp } from "@opencode/schema/mcp";
import type { PtyTicket } from "@opencode/schema/pty-ticket";
import type { Credential } from "@opencode/schema/credential";
import type { PermissionSaved } from "@opencode/schema/permission-saved";
import type { FileSystem } from "@opencode/schema/filesystem";
import type { Command } from "@opencode/schema/command";
import type { OpenCodeEvent } from "@opencode/protocol/groups/event";
import type { Pty } from "@opencode/schema/pty";
import type { Schedule } from "@opencode/schema/schedule";
import type { Artifact } from "@opencode/schema/artifact";
import type { Job } from "@opencode/schema/job";
import type { Reference } from "@opencode/schema/reference";
import type { Worktree } from "@opencode/schema/worktree";
import type { Vcs } from "@opencode/schema/vcs";
import type { WebSearch } from "@opencode/schema/websearch";
import type { UsageLimits } from "@opencode/schema/usage-limits";
import type { Config } from "@opencode/schema/config";
export type ServerInfoOutput = {
    readonly version: string;
    readonly pid: number;
    readonly hostname?: string | undefined;
    readonly urls: ReadonlyArray<string>;
    readonly paths: {
        readonly tmp: string;
    };
    readonly capabilities?: {
        readonly persistentPty?: boolean | undefined;
    } | undefined;
};
export type ServerInfoOperation<E = never> = () => Effect.Effect<ServerInfoOutput, E>;
export type ServerPairOutput = {
    readonly code: string;
    readonly expires_in: number;
};
export type ServerPairOperation<E = never> = () => Effect.Effect<ServerPairOutput, E>;
export type ServerConnectInput = {
    readonly code: string;
};
export type ServerConnectOutput = {
    readonly token: string;
};
export type ServerConnectOperation<E = never> = (input: ServerConnectInput) => Effect.Effect<ServerConnectOutput, E>;
export interface ServerApi<E = never> {
    readonly info: ServerInfoOperation<E>;
    readonly pair: ServerPairOperation<E>;
    readonly connect: ServerConnectOperation<E>;
}
export type LocationGetInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type LocationGetOutput = Location.PublicInfo;
export type LocationGetOperation<E = never> = (input?: LocationGetInput) => Effect.Effect<LocationGetOutput, E>;
export type LocationReloadOutput = void;
export type LocationReloadOperation<E = never> = () => Effect.Effect<LocationReloadOutput, E>;
export interface LocationApi<E = never> {
    readonly get: LocationGetOperation<E>;
    readonly reload: LocationReloadOperation<E>;
}
export type AgentListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type AgentListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Agent.Info>;
};
export type AgentListOperation<E = never> = (input?: AgentListInput) => Effect.Effect<AgentListOutput, E>;
export type AgentGetInput = {
    readonly agentID: Agent.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type AgentGetOutput = {
    readonly location: Location.PublicRef;
    readonly data: Agent.Info;
};
export type AgentGetOperation<E = never> = (input: AgentGetInput) => Effect.Effect<AgentGetOutput, E>;
export interface AgentApi<E = never> {
    readonly list: AgentListOperation<E>;
    readonly get: AgentGetOperation<E>;
}
export type PluginListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type PluginListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Plugin.Info>;
};
export type PluginListOperation<E = never> = (input?: PluginListInput) => Effect.Effect<PluginListOutput, E>;
export type PluginGuiInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly id: Plugin.ID;
};
export type PluginGuiOutput = {
    readonly location: Location.PublicRef;
    readonly data: Plugin.GuiBundle;
};
export type PluginGuiOperation<E = never> = (input: PluginGuiInput) => Effect.Effect<PluginGuiOutput, E>;
export type PluginCheckInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly target?: string | undefined;
};
export type PluginCheckOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Plugin.Info>;
};
export type PluginCheckOperation<E = never> = (input?: PluginCheckInput) => Effect.Effect<PluginCheckOutput, E>;
export type PluginUpdateInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly targets: ReadonlyArray<string>;
};
export type PluginUpdateOutput = void;
export type PluginUpdateOperation<E = never> = (input: PluginUpdateInput) => Effect.Effect<PluginUpdateOutput, E>;
export interface PluginApi<E = never> {
    readonly list: PluginListOperation<E>;
    readonly gui: PluginGuiOperation<E>;
    readonly check: PluginCheckOperation<E>;
    readonly update: PluginUpdateOperation<E>;
}
export type SessionListInput = {
    readonly limit?: number | undefined;
    readonly order?: "asc" | "desc" | undefined;
    readonly search?: string | undefined;
    readonly parentID?: Session.ID | null | undefined;
    readonly archived?: boolean | undefined;
    readonly directory?: AbsolutePath | undefined;
    readonly project?: Project.ID | undefined;
    readonly subpath?: RelativePath | undefined;
    readonly cursor?: Session.ListCursor | undefined;
};
export type SessionListOutput = {
    readonly data: ReadonlyArray<Session.Info>;
    readonly cursor: {
        readonly previous?: Session.ListCursor | undefined;
        readonly next?: Session.ListCursor | undefined;
    };
};
export type SessionListOperation<E = never> = (input?: SessionListInput) => Effect.Effect<SessionListOutput, E>;
export type SessionCreateInput = {
    readonly id?: Session.ID | undefined;
    readonly parentID?: Session.ID | undefined;
    readonly title?: string | undefined;
    readonly agent?: Agent.ID | undefined;
    readonly model?: Model.Ref | undefined;
    readonly location?: Location.PublicRef | undefined;
    readonly metadata?: Session.Metadata | undefined;
    readonly permissions?: Permission.Ruleset | undefined;
};
export type SessionCreateOutput = Session.Info;
export type SessionCreateOperation<E = never> = (input?: SessionCreateInput) => Effect.Effect<SessionCreateOutput, E>;
export type SessionActiveOutput = {
    readonly [x: Session.ID]: {
        readonly type: "running";
    };
};
export type SessionActiveOperation<E = never> = () => Effect.Effect<SessionActiveOutput, E>;
export type SessionGetInput = {
    readonly sessionID: Session.ID;
};
export type SessionGetOutput = Session.Info;
export type SessionGetOperation<E = never> = (input: SessionGetInput) => Effect.Effect<SessionGetOutput, E>;
export type SessionRemoveInput = {
    readonly sessionID: Session.ID;
};
export type SessionRemoveOutput = void;
export type SessionRemoveOperation<E = never> = (input: SessionRemoveInput) => Effect.Effect<SessionRemoveOutput, E>;
export type SessionForkInput = {
    readonly sessionID: Session.ID;
    readonly before?: SessionMessage.ID | undefined;
};
export type SessionForkOutput = Session.Info;
export type SessionForkOperation<E = never> = (input: SessionForkInput) => Effect.Effect<SessionForkOutput, E>;
export type SessionSwitchAgentInput = {
    readonly sessionID: Session.ID;
    readonly agent: Agent.ID;
};
export type SessionSwitchAgentOutput = void;
export type SessionSwitchAgentOperation<E = never> = (input: SessionSwitchAgentInput) => Effect.Effect<SessionSwitchAgentOutput, E>;
export type SessionSwitchModelInput = {
    readonly sessionID: Session.ID;
    readonly model: Model.Ref;
};
export type SessionSwitchModelOutput = void;
export type SessionSwitchModelOperation<E = never> = (input: SessionSwitchModelInput) => Effect.Effect<SessionSwitchModelOutput, E>;
export type SessionUpdateInput = {
    readonly sessionID: Session.ID;
    readonly title?: string | undefined;
    readonly metadata?: Session.Metadata | undefined;
    readonly permissions?: Permission.Ruleset | undefined;
    readonly archived?: boolean | undefined;
};
export type SessionUpdateOutput = void;
export type SessionUpdateOperation<E = never> = (input: SessionUpdateInput) => Effect.Effect<SessionUpdateOutput, E>;
export type SessionMoveInput = {
    readonly sessionID: Session.ID;
    readonly directory: AbsolutePath;
    readonly delivery?: SessionInbox.Delivery | undefined;
};
export type SessionMoveOutput = void;
export type SessionMoveOperation<E = never> = (input: SessionMoveInput) => Effect.Effect<SessionMoveOutput, E>;
export type SessionPromptInput = {
    readonly sessionID: Session.ID;
    readonly id?: SessionMessage.ID | undefined;
    readonly text: string;
    readonly files?: ReadonlyArray<PromptInput.FileAttachment> | undefined;
    readonly agents?: ReadonlyArray<AgentAttachment> | undefined;
    readonly skills?: ReadonlyArray<PromptInput.SkillAttachment> | undefined;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly delivery?: SessionInbox.Delivery | undefined;
    readonly resume?: boolean | undefined;
};
export type SessionPromptOutput = SessionInbox.User;
export type SessionPromptOperation<E = never> = (input: SessionPromptInput) => Effect.Effect<SessionPromptOutput, E>;
export type SessionCommandInput = {
    readonly sessionID: Session.ID;
    readonly name: string;
    readonly text: string;
    readonly files?: ReadonlyArray<PromptInput.FileAttachment> | undefined;
    readonly agents?: ReadonlyArray<AgentAttachment> | undefined;
    readonly skills?: ReadonlyArray<PromptInput.SkillAttachment> | undefined;
    readonly delivery?: SessionInbox.Delivery | undefined;
};
export type SessionCommandOutput = void;
export type SessionCommandOperation<E = never> = (input: SessionCommandInput) => Effect.Effect<SessionCommandOutput, E>;
export type SessionSyntheticInput = {
    readonly sessionID: Session.ID;
    readonly id?: SessionMessage.ID | undefined;
    readonly text: string;
    readonly description?: string | undefined;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly delivery?: SessionInbox.Delivery | undefined;
    readonly resume?: boolean | undefined;
};
export type SessionSyntheticOutput = SessionInbox.Synthetic;
export type SessionSyntheticOperation<E = never> = (input: SessionSyntheticInput) => Effect.Effect<SessionSyntheticOutput, E>;
export type SessionShellInput = {
    readonly sessionID: Session.ID;
    readonly id?: SessionMessage.ID | undefined;
    readonly command: string;
};
export type SessionShellOutput = void;
export type SessionShellOperation<E = never> = (input: SessionShellInput) => Effect.Effect<SessionShellOutput, E>;
export type SessionCompactInput = {
    readonly sessionID: Session.ID;
    readonly id?: SessionMessage.ID | undefined;
    readonly delivery?: SessionInbox.Delivery | undefined;
};
export type SessionCompactOutput = SessionInbox.Compaction;
export type SessionCompactOperation<E = never> = (input: SessionCompactInput) => Effect.Effect<SessionCompactOutput, E>;
export type SessionRevertStageInput = {
    readonly sessionID: Session.ID;
    readonly messageID: SessionMessage.ID;
    readonly files?: boolean | undefined;
};
export type SessionRevertStageOutput = Session.Revert;
export type SessionRevertStageOperation<E = never> = (input: SessionRevertStageInput) => Effect.Effect<SessionRevertStageOutput, E>;
export type SessionRevertClearInput = {
    readonly sessionID: Session.ID;
};
export type SessionRevertClearOutput = void;
export type SessionRevertClearOperation<E = never> = (input: SessionRevertClearInput) => Effect.Effect<SessionRevertClearOutput, E>;
export type SessionRevertCommitInput = {
    readonly sessionID: Session.ID;
};
export type SessionRevertCommitOutput = void;
export type SessionRevertCommitOperation<E = never> = (input: SessionRevertCommitInput) => Effect.Effect<SessionRevertCommitOutput, E>;
export type SessionContextInput = {
    readonly sessionID: Session.ID;
};
export type SessionContextOutput = ReadonlyArray<SessionMessage.Info>;
export type SessionContextOperation<E = never> = (input: SessionContextInput) => Effect.Effect<SessionContextOutput, E>;
export type SessionDiffInput = {
    readonly sessionID: Session.ID;
    readonly from?: SessionMessage.ID | undefined;
    readonly to?: SessionMessage.ID | undefined;
    readonly context?: number | undefined;
};
export type SessionDiffOutput = ReadonlyArray<FileDiff.Info>;
export type SessionDiffOperation<E = never> = (input: SessionDiffInput) => Effect.Effect<SessionDiffOutput, E>;
export type SessionInboxListInput = {
    readonly sessionID: Session.ID;
};
export type SessionInboxListOutput = ReadonlyArray<SessionInbox.Info>;
export type SessionInboxListOperation<E = never> = (input: SessionInboxListInput) => Effect.Effect<SessionInboxListOutput, E>;
export type SessionInboxCancelInput = {
    readonly sessionID: Session.ID;
    readonly inboxID: SessionMessage.ID;
};
export type SessionInboxCancelOutput = void;
export type SessionInboxCancelOperation<E = never> = (input: SessionInboxCancelInput) => Effect.Effect<SessionInboxCancelOutput, E>;
export type SessionInboxUpdateInput = {
    readonly sessionID: Session.ID;
    readonly inboxID: SessionMessage.ID;
    readonly delivery: SessionInbox.Delivery;
};
export type SessionInboxUpdateOutput = void;
export type SessionInboxUpdateOperation<E = never> = (input: SessionInboxUpdateInput) => Effect.Effect<SessionInboxUpdateOutput, E>;
export type SessionGenerateInput = {
    readonly sessionID: Session.ID;
    readonly prompt: string;
};
export type SessionGenerateOutput = {
    readonly text: string;
};
export type SessionGenerateOperation<E = never> = (input: SessionGenerateInput) => Effect.Effect<SessionGenerateOutput, E>;
export type SessionInterruptInput = {
    readonly sessionID: Session.ID;
    readonly resume?: boolean | undefined;
};
export type SessionInterruptOutput = {
    readonly interrupted: boolean;
};
export type SessionInterruptOperation<E = never> = (input: SessionInterruptInput) => Effect.Effect<SessionInterruptOutput, E>;
export type SessionBackgroundInput = {
    readonly sessionID: Session.ID;
};
export type SessionBackgroundOutput = void;
export type SessionBackgroundOperation<E = never> = (input: SessionBackgroundInput) => Effect.Effect<SessionBackgroundOutput, E>;
export type SessionMessageGetInput = {
    readonly sessionID: Session.ID;
    readonly messageID: SessionMessage.ID;
};
export type SessionMessageGetOutput = SessionMessage.Info;
export type SessionMessageGetOperation<E = never> = (input: SessionMessageGetInput) => Effect.Effect<SessionMessageGetOutput, E>;
export type SessionFormListInput = {
    readonly sessionID: string;
};
export type SessionFormListOutput = ReadonlyArray<Form.Info>;
export type SessionFormListOperation<E = never> = (input: SessionFormListInput) => Effect.Effect<SessionFormListOutput, E>;
export type SessionFormCreateInput = {
    readonly sessionID: string;
    readonly id?: Form.ID | undefined;
    readonly title: string;
    readonly metadata?: Form.Metadata | undefined;
    readonly fields: Form.Fields;
};
export type SessionFormCreateOutput = Form.Info;
export type SessionFormCreateOperation<E = never> = (input: SessionFormCreateInput) => Effect.Effect<SessionFormCreateOutput, E>;
export type SessionFormGetInput = {
    readonly sessionID: string;
    readonly formID: Form.ID;
};
export type SessionFormGetOutput = Form.Detail;
export type SessionFormGetOperation<E = never> = (input: SessionFormGetInput) => Effect.Effect<SessionFormGetOutput, E>;
export type SessionFormReplyInput = {
    readonly sessionID: string;
    readonly formID: Form.ID;
    readonly answer: Form.Answer;
};
export type SessionFormReplyOutput = void;
export type SessionFormReplyOperation<E = never> = (input: SessionFormReplyInput) => Effect.Effect<SessionFormReplyOutput, E>;
export type SessionFormCancelInput = {
    readonly sessionID: string;
    readonly formID: Form.ID;
    readonly message?: string | undefined;
};
export type SessionFormCancelOutput = void;
export type SessionFormCancelOperation<E = never> = (input: SessionFormCancelInput) => Effect.Effect<SessionFormCancelOutput, E>;
export type SessionEnvironmentInput = {
    readonly sessionID: Session.ID;
    readonly variables: {
        readonly [x: string]: string;
    };
};
export type SessionEnvironmentOutput = void;
export type SessionEnvironmentOperation<E = never> = (input: SessionEnvironmentInput) => Effect.Effect<SessionEnvironmentOutput, E>;
export type SessionViewInput = {
    readonly sessionID: Session.ID;
    readonly idle: DateTime.Utc;
};
export type SessionViewOutput = void;
export type SessionViewOperation<E = never> = (input: SessionViewInput) => Effect.Effect<SessionViewOutput, E>;
export interface SessionApi<E = never> {
    readonly list: SessionListOperation<E>;
    readonly create: SessionCreateOperation<E>;
    readonly active: SessionActiveOperation<E>;
    readonly get: SessionGetOperation<E>;
    readonly remove: SessionRemoveOperation<E>;
    readonly fork: SessionForkOperation<E>;
    readonly switchAgent: SessionSwitchAgentOperation<E>;
    readonly switchModel: SessionSwitchModelOperation<E>;
    readonly update: SessionUpdateOperation<E>;
    readonly move: SessionMoveOperation<E>;
    readonly prompt: SessionPromptOperation<E>;
    readonly command: SessionCommandOperation<E>;
    readonly synthetic: SessionSyntheticOperation<E>;
    readonly shell: SessionShellOperation<E>;
    readonly compact: SessionCompactOperation<E>;
    readonly revert: {
        readonly stage: SessionRevertStageOperation<E>;
        readonly clear: SessionRevertClearOperation<E>;
        readonly commit: SessionRevertCommitOperation<E>;
    };
    readonly context: SessionContextOperation<E>;
    readonly diff: SessionDiffOperation<E>;
    readonly inbox: {
        readonly list: SessionInboxListOperation<E>;
        readonly cancel: SessionInboxCancelOperation<E>;
        readonly update: SessionInboxUpdateOperation<E>;
    };
    readonly generate: SessionGenerateOperation<E>;
    readonly interrupt: SessionInterruptOperation<E>;
    readonly background: SessionBackgroundOperation<E>;
    readonly message: {
        readonly get: SessionMessageGetOperation<E>;
    };
    readonly form: {
        readonly list: SessionFormListOperation<E>;
        readonly create: SessionFormCreateOperation<E>;
        readonly get: SessionFormGetOperation<E>;
        readonly reply: SessionFormReplyOperation<E>;
        readonly cancel: SessionFormCancelOperation<E>;
    };
    readonly environment: SessionEnvironmentOperation<E>;
    readonly view: SessionViewOperation<E>;
    /** @deprecated Use `client.experimental.session.stats`. Removed in the next minor. */
    readonly stats: ExperimentalSessionStatsOperation<E>;
    /** @deprecated Use `client.experimental.session.import`. Removed in the next minor. */
    readonly import: ExperimentalSessionImportOperation<E>;
    /** @deprecated Use `client.experimental.session.export`. Removed in the next minor. */
    readonly export: ExperimentalSessionExportOperation<E>;
    /** @deprecated Use `client.experimental.session.skill`. Removed in the next minor. */
    readonly skill: ExperimentalSessionSkillOperation<E>;
    /** @deprecated Use `client.experimental.session.wait`. Removed in the next minor. */
    readonly wait: ExperimentalSessionWaitOperation<E>;
    /** @deprecated Use `client.experimental.session.instructions`. Removed in the next minor. */
    readonly instructions: {
        /** @deprecated Use `client.experimental.session.instructions.entry`. Removed in the next minor. */
        readonly entry: {
            /** @deprecated Use `client.experimental.session.instructions.entry.list`. Removed in the next minor. */
            readonly list: ExperimentalSessionInstructionsEntryListOperation<E>;
            /** @deprecated Use `client.experimental.session.instructions.entry.put`. Removed in the next minor. */
            readonly put: ExperimentalSessionInstructionsEntryPutOperation<E>;
            /** @deprecated Use `client.experimental.session.instructions.entry.remove`. Removed in the next minor. */
            readonly remove: ExperimentalSessionInstructionsEntryRemoveOperation<E>;
        };
    };
    /** @deprecated Use `client.experimental.session.log`. Removed in the next minor. */
    readonly log: ExperimentalSessionLogOperation<E>;
}
export type ExperimentalSessionStatsInput = {
    readonly from?: number | undefined;
    readonly to?: number | undefined;
    readonly project?: Project.ID | undefined;
    readonly timezone?: string | undefined;
    readonly tools?: "none" | "summary" | "detail" | undefined;
};
export type ExperimentalSessionStatsOutput = {
    readonly range: {
        readonly from: DateTime.Utc;
        readonly to: DateTime.Utc;
    };
    readonly sessions: number;
    readonly subagents: number;
    readonly prompts: number;
    readonly steps: number;
    readonly tokens: {
        readonly input: number;
        readonly output: number;
        readonly reasoning: number;
        readonly cache: {
            readonly read: number;
            readonly write: number;
        };
    };
    readonly cost: Money.USD;
    readonly tools: {
        readonly mode: "none";
    } | {
        readonly mode: "summary";
        readonly totals: {
            readonly calls: number;
            readonly succeeded: number;
            readonly failed: number;
            readonly unfinished: number;
        };
    } | {
        readonly mode: "detail";
        readonly totals: {
            readonly calls: number;
            readonly succeeded: number;
            readonly failed: number;
            readonly unfinished: number;
        };
        readonly usage: ReadonlyArray<{
            readonly name: string;
            readonly calls: number;
            readonly succeeded: number;
            readonly failed: number;
            readonly unfinished: number;
            readonly durationP50?: number | undefined;
        }>;
    };
    readonly activeDays: number;
    readonly streak: number;
    readonly activity: ReadonlyArray<{
        readonly date: string;
        readonly steps: number;
    }>;
    readonly models: ReadonlyArray<{
        readonly model: Model.Ref;
        readonly steps: number;
        readonly tokens: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        };
        readonly cost: Money.USD;
    }>;
};
export type ExperimentalSessionStatsOperation<E = never> = (input?: ExperimentalSessionStatsInput) => Effect.Effect<ExperimentalSessionStatsOutput, E>;
export type ExperimentalSessionImportInput = {
    readonly info: Session.Info;
    readonly messages: ReadonlyArray<SessionMessage.Info>;
    readonly location?: Location.PublicRef | undefined;
};
export type ExperimentalSessionImportOutput = Session.Info;
export type ExperimentalSessionImportOperation<E = never> = (input: ExperimentalSessionImportInput) => Effect.Effect<ExperimentalSessionImportOutput, E>;
export type ExperimentalSessionExportInput = {
    readonly sessionID: Session.ID;
    readonly sanitize?: boolean | undefined;
};
export type ExperimentalSessionExportOutput = {
    readonly info: Session.Info;
    readonly messages: ReadonlyArray<SessionMessage.Info>;
};
export type ExperimentalSessionExportOperation<E = never> = (input: ExperimentalSessionExportInput) => Effect.Effect<ExperimentalSessionExportOutput, E>;
export type ExperimentalSessionSkillInput = {
    readonly sessionID: Session.ID;
    readonly id: Skill.ID;
    readonly resume?: boolean | undefined;
};
export type ExperimentalSessionSkillOutput = void;
export type ExperimentalSessionSkillOperation<E = never> = (input: ExperimentalSessionSkillInput) => Effect.Effect<ExperimentalSessionSkillOutput, E>;
export type ExperimentalSessionWaitInput = {
    readonly sessionID: Session.ID;
};
export type ExperimentalSessionWaitOutput = void;
export type ExperimentalSessionWaitOperation<E = never> = (input: ExperimentalSessionWaitInput) => Effect.Effect<ExperimentalSessionWaitOutput, E>;
export type ExperimentalSessionInstructionsEntryListInput = {
    readonly sessionID: Session.ID;
};
export type ExperimentalSessionInstructionsEntryListOutput = ReadonlyArray<InstructionEntry.Info>;
export type ExperimentalSessionInstructionsEntryListOperation<E = never> = (input: ExperimentalSessionInstructionsEntryListInput) => Effect.Effect<ExperimentalSessionInstructionsEntryListOutput, E>;
export type ExperimentalSessionInstructionsEntryPutInput = {
    readonly sessionID: Session.ID;
    readonly key: InstructionEntry.Key;
    readonly value: Schema.Json;
};
export type ExperimentalSessionInstructionsEntryPutOutput = void;
export type ExperimentalSessionInstructionsEntryPutOperation<E = never> = (input: ExperimentalSessionInstructionsEntryPutInput) => Effect.Effect<ExperimentalSessionInstructionsEntryPutOutput, E>;
export type ExperimentalSessionInstructionsEntryRemoveInput = {
    readonly sessionID: Session.ID;
    readonly key: InstructionEntry.Key;
};
export type ExperimentalSessionInstructionsEntryRemoveOutput = void;
export type ExperimentalSessionInstructionsEntryRemoveOperation<E = never> = (input: ExperimentalSessionInstructionsEntryRemoveInput) => Effect.Effect<ExperimentalSessionInstructionsEntryRemoveOutput, E>;
export type ExperimentalSessionLogInput = {
    readonly sessionID: Session.ID;
    readonly after?: Event.Seq | undefined;
    readonly follow?: boolean | undefined;
};
export type ExperimentalSessionLogOutput = ({
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.created";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly projectID: Project.ID;
        readonly location: {
            readonly directory: AbsolutePath;
            readonly workspaceID?: Workspace.ID | undefined;
        };
        readonly subpath?: RelativePath | undefined;
        readonly parentID?: Session.ID | undefined;
        readonly slug: string;
        readonly title?: string | undefined;
        readonly agent?: Agent.ID | undefined;
        readonly model?: Model.Ref | undefined;
        readonly metadata?: Session.Metadata | undefined;
        readonly permissions?: Permission.Ruleset | undefined;
        readonly version: string;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.agent.selected";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly agent: Agent.ID;
        readonly previous?: Agent.ID | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.model.selected";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly model: Model.Ref;
        readonly previous?: Model.Ref | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.moved";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly location: {
            readonly directory: AbsolutePath;
            readonly workspaceID?: Workspace.ID | undefined;
        };
        readonly projectID: Project.ID;
        readonly subpath?: RelativePath | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.renamed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly title: string;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.metadata.updated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly metadata: Session.Metadata;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.permissions";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly permissions: Permission.Ruleset;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.viewed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly idle: number;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.archived";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.unarchived";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.deleted";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.forked";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly parentID: Session.ID;
        readonly boundary: Session.ForkBoundary;
        readonly instructions?: {
            readonly [x: Instruction.Key]: Instruction.Hash;
        } | undefined;
        readonly instructionEntries?: InstructionEntry.Snapshot | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.delivered";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly inboxID: SessionMessage.ID;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.enqueued";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly inboxID: SessionMessage.ID;
        readonly item: SessionInbox.Item;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.cancelled";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly inboxID: SessionMessage.ID;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.inbox.delivery.changed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly inboxID: SessionMessage.ID;
        readonly delivery: SessionInbox.Delivery;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.succeeded";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.execution.interrupted";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly reason: "user" | "shutdown" | "superseded" | "inactivity";
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.instructions.updated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly delta: {
            readonly [x: string]: Instruction.Hash | "removed";
        };
        readonly text?: string | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.synthetic";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly text: string;
        readonly description?: string | undefined;
        readonly metadata?: {
            readonly [x: string]: unknown;
        } | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.skill.activated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly id: Skill.ID;
        readonly name: Skill.Name;
        readonly text: string;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.shell.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly shell: Shell.Info;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.shell.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly shell: Shell.Info;
        readonly output: {
            readonly output: string;
            readonly cursor: number;
            readonly size: number;
            readonly truncated: boolean;
        };
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly agent: Agent.ID;
        readonly model: Model.Ref;
        readonly snapshot?: Snapshot.ID | undefined;
        readonly started: number;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.streamed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly finish: "stop" | "length" | "tool-calls" | "content-filter" | "error" | "unknown";
        readonly rawFinish?: string | undefined;
        readonly native?: SessionMessage.Native | undefined;
        readonly cost: Money.USD;
        readonly tokens: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        };
        readonly snapshot?: Snapshot.ID | undefined;
        readonly files?: ReadonlyArray<RelativePath> | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.step.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly finish?: "content-filter" | undefined;
        readonly rawFinish?: string | undefined;
        readonly native?: SessionMessage.Native | undefined;
        readonly cost?: Money.USD | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
        readonly snapshot?: Snapshot.ID | undefined;
        readonly files?: ReadonlyArray<RelativePath> | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.text.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly ordinal: number;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.text.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly ordinal: number;
        readonly text: string;
        readonly native?: SessionMessage.Native | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.reasoning.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly ordinal: number;
        readonly native?: SessionMessage.Native | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.reasoning.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly ordinal: number;
        readonly text: string;
        readonly native?: SessionMessage.Native | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.input.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly id: string;
        readonly name: string;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.input.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly id: string;
        readonly text: string;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.called";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly id: string;
        readonly input: {
            readonly [x: string]: unknown;
        };
        readonly executed: boolean;
        readonly native?: SessionMessage.Native | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.success";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly id: string;
        readonly content: readonly [
            ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            }),
            ...Array<{
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            }>
        ];
        readonly metadata?: {
            readonly [x: string]: Schema.Json;
        } | undefined;
        readonly executed: boolean;
        readonly native?: SessionMessage.Native | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.tool.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly id: string;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly content?: readonly [
            ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            }),
            ...Array<{
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            }>
        ] | undefined;
        readonly metadata?: {
            readonly [x: string]: Schema.Json;
        } | undefined;
        readonly executed: boolean;
        readonly native?: SessionMessage.Native | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.retry.scheduled";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly assistantMessageID: SessionMessage.ID;
        readonly attempt: number;
        readonly at: number;
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.started";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly reason: "auto" | "manual";
        readonly inputID?: SessionMessage.ID | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.ended";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly reason: "auto" | "manual";
        readonly model?: Model.Ref | undefined;
        readonly native?: SessionMessage.Native | undefined;
        readonly text: string;
        readonly cost?: Money.USD | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.compaction.failed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly reason: "auto" | "manual";
        readonly error: {
            readonly type: string;
            readonly message: string;
            readonly status?: number | undefined;
            readonly response?: {
                readonly body: string;
            } | undefined;
            readonly retryAfterMs?: number | undefined;
        };
        readonly inputID?: SessionMessage.ID | undefined;
        readonly cost?: Money.USD | undefined;
        readonly tokens?: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        } | undefined;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.staged";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly revert: Session.Revert;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.cleared";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.revert.committed";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly to: SessionMessage.ID;
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.usage.recorded";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly source: "title" | "compaction";
        readonly cost: Money.USD;
        readonly tokens: {
            readonly input: number;
            readonly output: number;
            readonly reasoning: number;
            readonly cache: {
                readonly read: number;
                readonly write: number;
            };
        };
    };
} | {
    readonly id: Event.ID;
    readonly created: number;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly type: "session.message.content.updated";
    readonly durable: {
        readonly aggregateID: string;
        readonly seq: Event.Seq;
        readonly version: Event.Version;
    };
    readonly location?: {
        readonly directory: AbsolutePath;
        readonly workspaceID?: Workspace.ID | undefined;
    } | undefined;
    readonly data: {
        readonly sessionID: Session.ID;
        readonly messageID: SessionMessage.ID;
        readonly content: ReadonlyArray<SessionMessage.AssistantContentEncoded>;
    };
}) | EventLog.Synced;
export type ExperimentalSessionLogOperation<E = never> = (input: ExperimentalSessionLogInput) => Stream.Stream<ExperimentalSessionLogOutput, E>;
export interface ExperimentalSessionApi<E = never> {
    readonly stats: ExperimentalSessionStatsOperation<E>;
    readonly import: ExperimentalSessionImportOperation<E>;
    readonly export: ExperimentalSessionExportOperation<E>;
    readonly skill: ExperimentalSessionSkillOperation<E>;
    readonly wait: ExperimentalSessionWaitOperation<E>;
    readonly instructions: {
        readonly entry: {
            readonly list: ExperimentalSessionInstructionsEntryListOperation<E>;
            readonly put: ExperimentalSessionInstructionsEntryPutOperation<E>;
            readonly remove: ExperimentalSessionInstructionsEntryRemoveOperation<E>;
        };
    };
    readonly log: ExperimentalSessionLogOperation<E>;
}
export type MessageListInput = {
    readonly sessionID: Session.ID;
    readonly limit?: number | undefined;
    readonly order?: "asc" | "desc" | undefined;
    readonly cursor?: string | undefined;
    readonly type?: "agent-switched" | "model-switched" | "location-switched" | "user" | "synthetic" | "system" | "skill" | "shell" | "assistant" | "compaction" | "idle" | undefined;
};
export type MessageListOutput = {
    readonly data: ReadonlyArray<SessionMessage.Info>;
    readonly cursor: {
        readonly previous?: string | undefined;
        readonly next?: string | undefined;
    };
};
export type MessageListOperation<E = never> = (input: MessageListInput) => Effect.Effect<MessageListOutput, E>;
export interface MessageApi<E = never> {
    readonly list: MessageListOperation<E>;
}
export type ModelListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly types?: ReadonlyArray<Model.Type> | undefined;
};
export type ModelListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Model.Info>;
};
export type ModelListOperation<E = never> = (input?: ModelListInput) => Effect.Effect<ModelListOutput, E>;
export type ModelDefaultInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ModelDefaultOutput = {
    readonly location: Location.PublicRef;
    readonly data: Model.Info | undefined;
};
export type ModelDefaultOperation<E = never> = (input?: ModelDefaultInput) => Effect.Effect<ModelDefaultOutput, E>;
export interface ModelApi<E = never> {
    readonly list: ModelListOperation<E>;
    readonly default: ModelDefaultOperation<E>;
}
export type ExperimentalGenerateTextInput = {
    readonly prompt: string;
    readonly model?: Model.Ref | undefined;
};
export type ExperimentalGenerateTextOutput = {
    readonly text: string;
};
export type ExperimentalGenerateTextOperation<E = never> = (input: ExperimentalGenerateTextInput) => Effect.Effect<ExperimentalGenerateTextOutput, E>;
export type ExperimentalGenerateImageInput = {
    readonly model: Model.Ref;
    readonly prompt: string;
    readonly images?: ReadonlyArray<Generate.File> | undefined;
    readonly n?: number | undefined;
    readonly aspect?: Generate.ImageAspect | undefined;
    readonly resolution?: Generate.ImageResolution | undefined;
};
export type ExperimentalGenerateImageOutput = Generate.ImageResult;
export type ExperimentalGenerateImageOperation<E = never> = (input: ExperimentalGenerateImageInput) => Effect.Effect<ExperimentalGenerateImageOutput, E>;
export type ExperimentalGenerateDecisionsInput = {
    readonly model: Model.Ref;
    readonly input: ReadonlyArray<Generate.DecisionPart>;
    readonly questions: ReadonlyArray<Generate.DecisionQuestion>;
};
export type ExperimentalGenerateDecisionsOutput = Generate.DecisionResult;
export type ExperimentalGenerateDecisionsOperation<E = never> = (input: ExperimentalGenerateDecisionsInput) => Effect.Effect<ExperimentalGenerateDecisionsOutput, E>;
export interface ExperimentalGenerateApi<E = never> {
    readonly text: ExperimentalGenerateTextOperation<E>;
    readonly image: ExperimentalGenerateImageOperation<E>;
    readonly decisions: ExperimentalGenerateDecisionsOperation<E>;
}
export type ExperimentalVoiceModelsOutput = {
    readonly models: ReadonlyArray<{
        readonly model: string;
        readonly provider: string;
        readonly transports: ReadonlyArray<"webrtc" | "websocket">;
        readonly available: boolean;
    }>;
    readonly default?: string | undefined;
};
export type ExperimentalVoiceModelsOperation<E = never> = () => Effect.Effect<ExperimentalVoiceModelsOutput, E>;
export type ExperimentalVoiceSessionInput = {
    readonly model: string;
    readonly session?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly transport: {
        readonly type: "webrtc";
        readonly sdp: string;
        readonly dcid?: number | undefined;
    } | {
        readonly type: "websocket";
    };
};
export type ExperimentalVoiceSessionOutput = {
    readonly transport: {
        readonly type: "webrtc";
        readonly sdp: string;
    } | {
        readonly type: "websocket";
        readonly url: string;
        readonly token: string;
        readonly expiresAt: number;
    };
};
export type ExperimentalVoiceSessionOperation<E = never> = (input: ExperimentalVoiceSessionInput) => Effect.Effect<ExperimentalVoiceSessionOutput, E>;
export interface ExperimentalVoiceApi<E = never> {
    readonly models: ExperimentalVoiceModelsOperation<E>;
    readonly session: ExperimentalVoiceSessionOperation<E>;
}
export type TranscriptionTranscribeInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly audio: string;
    readonly mime: string;
    readonly prompt?: string | undefined;
    readonly contextSessionID?: Session.ID | undefined;
    readonly images?: ReadonlyArray<string> | undefined;
    readonly settings?: {
        readonly type?: ("whisper" | "lalm") | undefined;
        readonly whisper?: {
            readonly model?: string | undefined;
            readonly language?: string | undefined;
        } | undefined;
        readonly lalm?: {
            readonly model?: string | undefined;
            readonly variant?: string | undefined;
            readonly system?: string | undefined;
            readonly instruction?: string | undefined;
            readonly audio_input_format?: "input_audio" | "audio_url" | undefined;
        } | undefined;
        readonly hot_words?: ReadonlyArray<string> | undefined;
    } | undefined;
};
export type TranscriptionTranscribeOutput = {
    readonly location: Location.PublicRef;
    readonly data: {
        readonly text: string;
        readonly usage?: {
            readonly input_tokens?: number | undefined;
            readonly output_tokens?: number | undefined;
        } | undefined;
    };
};
export type TranscriptionTranscribeOperation<E = never> = (input: TranscriptionTranscribeInput) => Effect.Effect<TranscriptionTranscribeOutput, E>;
export interface TranscriptionApi<E = never> {
    readonly transcribe: TranscriptionTranscribeOperation<E>;
    /** @deprecated Use `client.experimental.transcription.transcribeWithOverrides`. Removed in the next minor. */
    readonly transcribeWithOverrides: ExperimentalTranscriptionTranscribeWithOverridesOperation<E>;
}
export type ExperimentalTranscriptionTranscribeWithOverridesInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly audio: string;
    readonly mime: string;
    readonly prompt?: string | undefined;
    readonly contextSessionID?: Session.ID | undefined;
    readonly images?: ReadonlyArray<string> | undefined;
    readonly settings?: {
        readonly type?: ("whisper" | "lalm") | undefined;
        readonly whisper?: {
            readonly model?: string | undefined;
            readonly language?: string | undefined;
        } | undefined;
        readonly lalm?: {
            readonly model?: string | undefined;
            readonly variant?: string | undefined;
            readonly system?: string | undefined;
            readonly instruction?: string | undefined;
            readonly audio_input_format?: "input_audio" | "audio_url" | undefined;
        } | undefined;
        readonly hot_words?: ReadonlyArray<string> | undefined;
    } | undefined;
    readonly overrides: {
        readonly context_pairs?: 0 | number | undefined;
        readonly hot_words?: ReadonlyArray<string> | undefined;
        readonly whisper?: {
            readonly url: string;
            readonly apiKey?: string | undefined;
        } | undefined;
    };
};
export type ExperimentalTranscriptionTranscribeWithOverridesOutput = {
    readonly location: Location.PublicRef;
    readonly data: {
        readonly text: string;
        readonly usage?: {
            readonly input_tokens?: number | undefined;
            readonly output_tokens?: number | undefined;
        } | undefined;
    };
};
export type ExperimentalTranscriptionTranscribeWithOverridesOperation<E = never> = (input: ExperimentalTranscriptionTranscribeWithOverridesInput) => Effect.Effect<ExperimentalTranscriptionTranscribeWithOverridesOutput, E>;
export interface ExperimentalTranscriptionApi<E = never> {
    readonly transcribeWithOverrides: ExperimentalTranscriptionTranscribeWithOverridesOperation<E>;
}
export type ProviderListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ProviderListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Provider.Info>;
};
export type ProviderListOperation<E = never> = (input?: ProviderListInput) => Effect.Effect<ProviderListOutput, E>;
export type ProviderGetInput = {
    readonly providerID: Provider.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ProviderGetOutput = {
    readonly location: Location.PublicRef;
    readonly data: Provider.Info;
};
export type ProviderGetOperation<E = never> = (input: ProviderGetInput) => Effect.Effect<ProviderGetOutput, E>;
export interface ProviderApi<E = never> {
    readonly list: ProviderListOperation<E>;
    readonly get: ProviderGetOperation<E>;
}
export type IntegrationListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type IntegrationListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Integration.Info>;
};
export type IntegrationListOperation<E = never> = (input?: IntegrationListInput) => Effect.Effect<IntegrationListOutput, E>;
export type IntegrationGetInput = {
    readonly integrationID: Integration.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type IntegrationGetOutput = {
    readonly location: Location.PublicRef;
    readonly data: Integration.Info;
};
export type IntegrationGetOperation<E = never> = (input: IntegrationGetInput) => Effect.Effect<IntegrationGetOutput, E>;
export type IntegrationConnectKeyInput = {
    readonly integrationID: Integration.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly key: string;
    readonly answer?: Form.Answer | undefined;
    readonly label?: string | undefined;
};
export type IntegrationConnectKeyOutput = void;
export type IntegrationConnectKeyOperation<E = never> = (input: IntegrationConnectKeyInput) => Effect.Effect<IntegrationConnectKeyOutput, E>;
export type IntegrationConnectExternalInput = {
    readonly integrationID: Integration.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly methodID: Integration.MethodID;
    readonly answer?: Form.Answer | undefined;
    readonly label?: string | undefined;
};
export type IntegrationConnectExternalOutput = void;
export type IntegrationConnectExternalOperation<E = never> = (input: IntegrationConnectExternalInput) => Effect.Effect<IntegrationConnectExternalOutput, E>;
export type IntegrationOauthConnectInput = {
    readonly integrationID: Integration.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly methodID: Integration.MethodID;
    readonly answer?: Form.Answer | undefined;
    readonly label?: string | undefined;
};
export type IntegrationOauthConnectOutput = {
    readonly location: Location.PublicRef;
    readonly data: Integration.Attempt;
};
export type IntegrationOauthConnectOperation<E = never> = (input: IntegrationOauthConnectInput) => Effect.Effect<IntegrationOauthConnectOutput, E>;
export type IntegrationOauthStatusInput = {
    readonly integrationID: Integration.ID;
    readonly attemptID: Integration.AttemptID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type IntegrationOauthStatusOutput = {
    readonly location: Location.PublicRef;
    readonly data: Integration.AttemptStatus;
};
export type IntegrationOauthStatusOperation<E = never> = (input: IntegrationOauthStatusInput) => Effect.Effect<IntegrationOauthStatusOutput, E>;
export type IntegrationOauthCompleteInput = {
    readonly integrationID: Integration.ID;
    readonly attemptID: Integration.AttemptID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly code?: string | undefined;
};
export type IntegrationOauthCompleteOutput = void;
export type IntegrationOauthCompleteOperation<E = never> = (input: IntegrationOauthCompleteInput) => Effect.Effect<IntegrationOauthCompleteOutput, E>;
export type IntegrationOauthCancelInput = {
    readonly integrationID: Integration.ID;
    readonly attemptID: Integration.AttemptID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type IntegrationOauthCancelOutput = void;
export type IntegrationOauthCancelOperation<E = never> = (input: IntegrationOauthCancelInput) => Effect.Effect<IntegrationOauthCancelOutput, E>;
export type IntegrationCommandConnectInput = {
    readonly integrationID: Integration.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly methodID: Integration.MethodID;
    readonly label?: string | undefined;
};
export type IntegrationCommandConnectOutput = {
    readonly location: Location.PublicRef;
    readonly data: Integration.CommandAttempt;
};
export type IntegrationCommandConnectOperation<E = never> = (input: IntegrationCommandConnectInput) => Effect.Effect<IntegrationCommandConnectOutput, E>;
export type IntegrationCommandStatusInput = {
    readonly integrationID: Integration.ID;
    readonly attemptID: Integration.AttemptID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type IntegrationCommandStatusOutput = {
    readonly location: Location.PublicRef;
    readonly data: Integration.CommandAttemptStatus;
};
export type IntegrationCommandStatusOperation<E = never> = (input: IntegrationCommandStatusInput) => Effect.Effect<IntegrationCommandStatusOutput, E>;
export type IntegrationCommandCancelInput = {
    readonly integrationID: Integration.ID;
    readonly attemptID: Integration.AttemptID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type IntegrationCommandCancelOutput = void;
export type IntegrationCommandCancelOperation<E = never> = (input: IntegrationCommandCancelInput) => Effect.Effect<IntegrationCommandCancelOutput, E>;
export interface IntegrationApi<E = never> {
    readonly list: IntegrationListOperation<E>;
    readonly get: IntegrationGetOperation<E>;
    readonly connect: {
        readonly key: IntegrationConnectKeyOperation<E>;
        readonly external: IntegrationConnectExternalOperation<E>;
    };
    readonly oauth: {
        readonly connect: IntegrationOauthConnectOperation<E>;
        readonly status: IntegrationOauthStatusOperation<E>;
        readonly complete: IntegrationOauthCompleteOperation<E>;
        readonly cancel: IntegrationOauthCancelOperation<E>;
    };
    readonly command: {
        readonly connect: IntegrationCommandConnectOperation<E>;
        readonly status: IntegrationCommandStatusOperation<E>;
        readonly cancel: IntegrationCommandCancelOperation<E>;
    };
    /** @deprecated Use `client.experimental.integration.wellknown`. Removed in the next minor. */
    readonly wellknown: {
        /** @deprecated Use `client.experimental.integration.wellknown.add`. Removed in the next minor. */
        readonly add: ExperimentalIntegrationWellknownAddOperation<E>;
    };
}
export type ExperimentalIntegrationWellknownAddInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly url: string;
};
export type ExperimentalIntegrationWellknownAddOutput = void;
export type ExperimentalIntegrationWellknownAddOperation<E = never> = (input: ExperimentalIntegrationWellknownAddInput) => Effect.Effect<ExperimentalIntegrationWellknownAddOutput, E>;
export interface ExperimentalIntegrationApi<E = never> {
    readonly wellknown: {
        readonly add: ExperimentalIntegrationWellknownAddOperation<E>;
    };
}
export type McpListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type McpListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Mcp.Server>;
};
export type McpListOperation<E = never> = (input?: McpListInput) => Effect.Effect<McpListOutput, E>;
export type McpResourceCatalogInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type McpResourceCatalogOutput = {
    readonly location: Location.PublicRef;
    readonly data: Mcp.ResourceCatalog;
};
export type McpResourceCatalogOperation<E = never> = (input?: McpResourceCatalogInput) => Effect.Effect<McpResourceCatalogOutput, E>;
export interface McpApi<E = never> {
    readonly list: McpListOperation<E>;
    readonly resource: {
        readonly catalog: McpResourceCatalogOperation<E>;
    };
    /** @deprecated Use `client.experimental.mcp.add`. Removed in the next minor. */
    readonly add: ExperimentalMcpAddOperation<E>;
    /** @deprecated Use `client.experimental.mcp.remove`. Removed in the next minor. */
    readonly remove: ExperimentalMcpRemoveOperation<E>;
    /** @deprecated Use `client.experimental.mcp.connect`. Removed in the next minor. */
    readonly connect: ExperimentalMcpConnectOperation<E>;
    /** @deprecated Use `client.experimental.mcp.disconnect`. Removed in the next minor. */
    readonly disconnect: ExperimentalMcpDisconnectOperation<E>;
    /** @deprecated Use `client.experimental.mcp.client`. Removed in the next minor. */
    readonly client: {
        /** @deprecated Use `client.experimental.mcp.client.token`. Removed in the next minor. */
        readonly token: ExperimentalMcpClientTokenOperation<E>;
    };
}
export type ExperimentalMcpAddInput = {
    readonly server: string;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly config: Mcp.LocalConfig | Mcp.RemoteConfig;
};
export type ExperimentalMcpAddOutput = void;
export type ExperimentalMcpAddOperation<E = never> = (input: ExperimentalMcpAddInput) => Effect.Effect<ExperimentalMcpAddOutput, E>;
export type ExperimentalMcpRemoveInput = {
    readonly server: string;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ExperimentalMcpRemoveOutput = void;
export type ExperimentalMcpRemoveOperation<E = never> = (input: ExperimentalMcpRemoveInput) => Effect.Effect<ExperimentalMcpRemoveOutput, E>;
export type ExperimentalMcpConnectInput = {
    readonly server: string;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ExperimentalMcpConnectOutput = void;
export type ExperimentalMcpConnectOperation<E = never> = (input: ExperimentalMcpConnectInput) => Effect.Effect<ExperimentalMcpConnectOutput, E>;
export type ExperimentalMcpDisconnectInput = {
    readonly server: string;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ExperimentalMcpDisconnectOutput = void;
export type ExperimentalMcpDisconnectOperation<E = never> = (input: ExperimentalMcpDisconnectInput) => Effect.Effect<ExperimentalMcpDisconnectOutput, E>;
export type ExperimentalMcpClientTokenInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly name: string;
    readonly "x-opencode-ticket"?: string | undefined;
};
export type ExperimentalMcpClientTokenOutput = {
    readonly location: Location.PublicRef;
    readonly data: PtyTicket.ConnectToken;
};
export type ExperimentalMcpClientTokenOperation<E = never> = (input: ExperimentalMcpClientTokenInput) => Effect.Effect<ExperimentalMcpClientTokenOutput, E>;
export interface ExperimentalMcpApi<E = never> {
    readonly add: ExperimentalMcpAddOperation<E>;
    readonly remove: ExperimentalMcpRemoveOperation<E>;
    readonly connect: ExperimentalMcpConnectOperation<E>;
    readonly disconnect: ExperimentalMcpDisconnectOperation<E>;
    readonly client: {
        readonly token: ExperimentalMcpClientTokenOperation<E>;
    };
}
export type CredentialListOutput = ReadonlyArray<Credential.Entry>;
export type CredentialListOperation<E = never> = () => Effect.Effect<CredentialListOutput, E>;
export type CredentialCreateInput = {
    readonly id?: Credential.ID | undefined;
    readonly integrationID: Integration.ID;
    readonly label?: string | undefined;
    readonly value: Credential.Value;
    readonly activate?: boolean | undefined;
};
export type CredentialCreateOutput = Credential.Entry;
export type CredentialCreateOperation<E = never> = (input: CredentialCreateInput) => Effect.Effect<CredentialCreateOutput, E>;
export type CredentialUpdateInput = {
    readonly credentialID: Credential.ID;
    readonly label: string;
};
export type CredentialUpdateOutput = void;
export type CredentialUpdateOperation<E = never> = (input: CredentialUpdateInput) => Effect.Effect<CredentialUpdateOutput, E>;
export type CredentialActivateInput = {
    readonly credentialID: Credential.ID;
};
export type CredentialActivateOutput = void;
export type CredentialActivateOperation<E = never> = (input: CredentialActivateInput) => Effect.Effect<CredentialActivateOutput, E>;
export type CredentialRemoveInput = {
    readonly credentialID: Credential.ID;
};
export type CredentialRemoveOutput = void;
export type CredentialRemoveOperation<E = never> = (input: CredentialRemoveInput) => Effect.Effect<CredentialRemoveOutput, E>;
export interface CredentialApi<E = never> {
    readonly list: CredentialListOperation<E>;
    readonly create: CredentialCreateOperation<E>;
    readonly update: CredentialUpdateOperation<E>;
    readonly activate: CredentialActivateOperation<E>;
    readonly remove: CredentialRemoveOperation<E>;
}
export type ProjectListInput = {
    readonly archived?: boolean | undefined;
};
export type ProjectListOutput = ReadonlyArray<Project.Info>;
export type ProjectListOperation<E = never> = (input?: ProjectListInput) => Effect.Effect<ProjectListOutput, E>;
export type ProjectUpdateInput = {
    readonly projectID: Project.ID;
    readonly canonical?: AbsolutePath | undefined;
    readonly name?: string | undefined;
    readonly icon?: Project.Icon | undefined;
    readonly commands?: Project.Commands | undefined;
};
export type ProjectUpdateOutput = Project.Info;
export type ProjectUpdateOperation<E = never> = (input: ProjectUpdateInput) => Effect.Effect<ProjectUpdateOutput, E>;
export interface ProjectApi<E = never> {
    readonly list: ProjectListOperation<E>;
    readonly update: ProjectUpdateOperation<E>;
}
export type FormListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type FormListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Form.Info>;
};
export type FormListOperation<E = never> = (input?: FormListInput) => Effect.Effect<FormListOutput, E>;
export interface FormApi<E = never> {
    readonly list: FormListOperation<E>;
}
export type PermissionRequestListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type PermissionRequestListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Permission.Request>;
};
export type PermissionRequestListOperation<E = never> = (input?: PermissionRequestListInput) => Effect.Effect<PermissionRequestListOutput, E>;
export type PermissionSavedListInput = {
    readonly projectID?: Project.ID | undefined;
};
export type PermissionSavedListOutput = ReadonlyArray<PermissionSaved.Info>;
export type PermissionSavedListOperation<E = never> = (input?: PermissionSavedListInput) => Effect.Effect<PermissionSavedListOutput, E>;
export type PermissionSavedUpdateInput = {
    readonly id: PermissionSaved.ID;
    readonly action?: string | undefined;
    readonly resource?: string | undefined;
};
export type PermissionSavedUpdateOutput = PermissionSaved.Info;
export type PermissionSavedUpdateOperation<E = never> = (input: PermissionSavedUpdateInput) => Effect.Effect<PermissionSavedUpdateOutput, E>;
export type PermissionSavedRemoveInput = {
    readonly id: PermissionSaved.ID;
};
export type PermissionSavedRemoveOutput = void;
export type PermissionSavedRemoveOperation<E = never> = (input: PermissionSavedRemoveInput) => Effect.Effect<PermissionSavedRemoveOutput, E>;
export type PermissionCreateInput = {
    readonly sessionID: Session.ID;
    readonly id?: Permission.ID | undefined;
    readonly action: string;
    readonly resources: ReadonlyArray<string>;
    readonly save?: ReadonlyArray<string> | undefined;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly source?: Permission.Source | undefined;
    readonly agent?: Agent.ID | undefined;
};
export type PermissionCreateOutput = {
    readonly id: Permission.ID;
    readonly effect: Permission.Effect;
};
export type PermissionCreateOperation<E = never> = (input: PermissionCreateInput) => Effect.Effect<PermissionCreateOutput, E>;
export type PermissionListInput = {
    readonly sessionID: Session.ID;
};
export type PermissionListOutput = ReadonlyArray<Permission.Request>;
export type PermissionListOperation<E = never> = (input: PermissionListInput) => Effect.Effect<PermissionListOutput, E>;
export type PermissionGetInput = {
    readonly sessionID: Session.ID;
    readonly requestID: Permission.ID;
};
export type PermissionGetOutput = Permission.Request;
export type PermissionGetOperation<E = never> = (input: PermissionGetInput) => Effect.Effect<PermissionGetOutput, E>;
export type PermissionReplyInput = {
    readonly sessionID: Session.ID;
    readonly requestID: Permission.ID;
    readonly decision: Permission.Reply;
    readonly message?: string | undefined;
};
export type PermissionReplyOutput = void;
export type PermissionReplyOperation<E = never> = (input: PermissionReplyInput) => Effect.Effect<PermissionReplyOutput, E>;
export interface PermissionApi<E = never> {
    readonly request: {
        readonly list: PermissionRequestListOperation<E>;
    };
    readonly saved: {
        readonly list: PermissionSavedListOperation<E>;
        readonly update: PermissionSavedUpdateOperation<E>;
        readonly remove: PermissionSavedRemoveOperation<E>;
    };
    readonly create: PermissionCreateOperation<E>;
    readonly list: PermissionListOperation<E>;
    readonly get: PermissionGetOperation<E>;
    readonly reply: PermissionReplyOperation<E>;
}
export type FileListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly path?: string | undefined;
};
export type FileListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<FileSystem.Entry>;
};
export type FileListOperation<E = never> = (input?: FileListInput) => Effect.Effect<FileListOutput, E>;
export type FileFindInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly query: string;
    readonly type?: "file" | "directory" | undefined;
    readonly limit?: number | undefined;
};
export type FileFindOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<FileSystem.Entry>;
};
export type FileFindOperation<E = never> = (input: FileFindInput) => Effect.Effect<FileFindOutput, E>;
export interface FileApi<E = never> {
    readonly list: FileListOperation<E>;
    readonly find: FileFindOperation<E>;
    /** @deprecated Use `client.experimental.file.watch`. Removed in the next minor. */
    readonly watch: ExperimentalFileWatchOperation<E>;
    /** @deprecated Use `client.experimental.file.unwatch`. Removed in the next minor. */
    readonly unwatch: ExperimentalFileUnwatchOperation<E>;
}
export type ExperimentalFileWatchInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly path: string;
};
export type ExperimentalFileWatchOutput = void;
export type ExperimentalFileWatchOperation<E = never> = (input: ExperimentalFileWatchInput) => Effect.Effect<ExperimentalFileWatchOutput, E>;
export type ExperimentalFileUnwatchInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly path: string;
};
export type ExperimentalFileUnwatchOutput = void;
export type ExperimentalFileUnwatchOperation<E = never> = (input: ExperimentalFileUnwatchInput) => Effect.Effect<ExperimentalFileUnwatchOutput, E>;
export interface ExperimentalFileApi<E = never> {
    readonly watch: ExperimentalFileWatchOperation<E>;
    readonly unwatch: ExperimentalFileUnwatchOperation<E>;
}
export type CommandListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type CommandListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Command.Info>;
};
export type CommandListOperation<E = never> = (input?: CommandListInput) => Effect.Effect<CommandListOutput, E>;
export interface CommandApi<E = never> {
    readonly list: CommandListOperation<E>;
}
export type SkillListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type SkillListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Skill.Info>;
};
export type SkillListOperation<E = never> = (input?: SkillListInput) => Effect.Effect<SkillListOutput, E>;
export interface SkillApi<E = never> {
    readonly list: SkillListOperation<E>;
}
export type RpcCallInput = {
    readonly rpcID: string;
    readonly method: string;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly input?: unknown | undefined;
};
export type RpcCallOutput = {
    readonly output?: unknown;
};
export type RpcCallOperation<E = never> = (input: RpcCallInput) => Effect.Effect<RpcCallOutput, E>;
export interface RpcApi<E = never> {
    readonly call: RpcCallOperation<E>;
}
export type EventSubscribeInput = {
    readonly types?: ReadonlyArray<"location.shutdown" | "models-dev.refreshed" | "credential.updated" | "credential.switched" | "integration.updated" | "provider.updated" | "model.updated" | "agent.updated" | "session.created" | "session.agent.selected" | "session.model.selected" | "session.moved" | "session.renamed" | "session.metadata.updated" | "session.permissions" | "session.viewed" | "session.archived" | "session.unarchived" | "session.usage.updated" | "session.deleted" | "session.forked" | "session.inbox.delivered" | "session.inbox.enqueued" | "session.inbox.cancelled" | "session.inbox.delivery.changed" | "session.execution.started" | "session.execution.succeeded" | "session.execution.failed" | "session.execution.interrupted" | "session.instructions.updated" | "session.synthetic" | "session.skill.activated" | "session.shell.started" | "session.shell.ended" | "session.step.started" | "session.step.streamed" | "session.step.ended" | "session.step.failed" | "session.text.started" | "session.text.delta" | "session.text.ended" | "session.reasoning.started" | "session.reasoning.delta" | "session.reasoning.ended" | "session.tool.input.started" | "session.tool.input.delta" | "session.tool.input.ended" | "session.tool.called" | "session.tool.progress" | "session.tool.success" | "session.tool.failed" | "session.retry.scheduled" | "session.compaction.started" | "session.compaction.delta" | "session.compaction.ended" | "session.compaction.failed" | "session.revert.staged" | "session.revert.cleared" | "session.revert.committed" | "filesystem.changed" | "reference.updated" | "permission.asked" | "permission.replied" | "plugin.updated" | "project.updated" | "worktree.updated" | "worktree.resolved" | "command.updated" | "config.updated" | "skill.updated" | "pty.created" | "pty.updated" | "pty.exited" | "pty.deleted" | "persistent-pty.added" | "persistent-pty.removed" | "persistent-pty.updated" | "shell.created" | "shell.exited" | "shell.deleted" | "form.created" | "form.replied" | "form.cancelled" | "websearch.updated" | "artifact.updated" | "session.status" | "session.idle" | "tui.prompt.append" | "tui.command.execute" | "tui.toast.show" | "tui.session.select" | "installation.updated" | "installation.update-available" | "vcs.branch.updated" | "mcp.status.changed" | "mcp.resources.changed" | `${"rpc."}${string}`> | undefined;
};
export type EventSubscribeOutput = OpenCodeEvent;
export type EventSubscribeOperation<E = never> = (input?: EventSubscribeInput) => Stream.Stream<EventSubscribeOutput, E>;
export interface EventApi<E = never> {
    readonly subscribe: EventSubscribeOperation<E>;
}
export type PtyListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type PtyListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Pty.Info>;
};
export type PtyListOperation<E = never> = (input?: PtyListInput) => Effect.Effect<PtyListOutput, E>;
export type PtyCreateInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly command?: string | undefined;
    readonly args?: ReadonlyArray<string> | undefined;
    readonly cwd?: string | undefined;
    readonly title?: string | undefined;
    readonly env?: {
        readonly [x: string]: string;
    } | undefined;
};
export type PtyCreateOutput = {
    readonly location: Location.PublicRef;
    readonly data: Pty.Info;
};
export type PtyCreateOperation<E = never> = (input?: PtyCreateInput) => Effect.Effect<PtyCreateOutput, E>;
export type PtyGetInput = {
    readonly ptyID: Pty.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type PtyGetOutput = {
    readonly location: Location.PublicRef;
    readonly data: Pty.Info;
};
export type PtyGetOperation<E = never> = (input: PtyGetInput) => Effect.Effect<PtyGetOutput, E>;
export type PtyUpdateInput = {
    readonly ptyID: Pty.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly title?: string | undefined;
    readonly size?: {
        readonly rows: number;
        readonly cols: number;
    } | undefined;
};
export type PtyUpdateOutput = {
    readonly location: Location.PublicRef;
    readonly data: Pty.Info;
};
export type PtyUpdateOperation<E = never> = (input: PtyUpdateInput) => Effect.Effect<PtyUpdateOutput, E>;
export type PtyRemoveInput = {
    readonly ptyID: Pty.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type PtyRemoveOutput = void;
export type PtyRemoveOperation<E = never> = (input: PtyRemoveInput) => Effect.Effect<PtyRemoveOutput, E>;
export type PtyConnectTokenInput = {
    readonly ptyID: Pty.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly "x-opencode-ticket"?: string | undefined;
};
export type PtyConnectTokenOutput = {
    readonly location: Location.PublicRef;
    readonly data: PtyTicket.ConnectToken;
};
export type PtyConnectTokenOperation<E = never> = (input: PtyConnectTokenInput) => Effect.Effect<PtyConnectTokenOutput, E>;
export interface PtyApi<E = never> {
    readonly list: PtyListOperation<E>;
    readonly create: PtyCreateOperation<E>;
    readonly get: PtyGetOperation<E>;
    readonly update: PtyUpdateOperation<E>;
    readonly remove: PtyRemoveOperation<E>;
    readonly connect: {
        readonly token: PtyConnectTokenOperation<E>;
    };
}
export type ExperimentalPersistentPtyReadInput = {
    readonly sessionID: Session.ID;
    readonly lines?: number | undefined;
};
export type ExperimentalPersistentPtyReadOutput = {
    readonly ptyID: Pty.ID;
    readonly title: string;
    readonly cwd: string;
    readonly foregroundProcess: string | null;
    readonly screen: {
        readonly text: string;
        readonly cols: number;
        readonly rows: number;
        readonly cursor: {
            readonly x: number;
            readonly y: number;
        };
    };
} | null;
export type ExperimentalPersistentPtyReadOperation<E = never> = (input: ExperimentalPersistentPtyReadInput) => Effect.Effect<ExperimentalPersistentPtyReadOutput, E>;
export type ExperimentalPersistentPtyListInput = {
    readonly sessionID: Session.ID;
};
export type ExperimentalPersistentPtyListOutput = ReadonlyArray<{
    readonly id: Pty.ID;
    readonly title: string;
    readonly command: string;
    readonly args: ReadonlyArray<string>;
    readonly cwd: string;
    readonly status: "running" | "exited";
    readonly pid: number;
    readonly exitCode?: number | undefined;
    readonly sessionID: Session.ID;
    readonly userTitle: string | null;
    readonly foregroundProcess: string | null;
    readonly size: {
        readonly cols: number;
        readonly rows: number;
    };
    readonly output: {
        readonly head: number;
        readonly tail: number;
    };
}>;
export type ExperimentalPersistentPtyListOperation<E = never> = (input: ExperimentalPersistentPtyListInput) => Effect.Effect<ExperimentalPersistentPtyListOutput, E>;
export type ExperimentalPersistentPtyCreateInput = {
    readonly sessionID: Session.ID;
    readonly command?: string | undefined;
    readonly args: ReadonlyArray<string>;
    readonly cwd?: string | undefined;
    readonly title: string;
    readonly env: {
        readonly [x: string]: string;
    };
    readonly size?: {
        readonly cols: number;
        readonly rows: number;
    } | undefined;
};
export type ExperimentalPersistentPtyCreateOutput = {
    readonly id: Pty.ID;
    readonly title: string;
    readonly command: string;
    readonly args: ReadonlyArray<string>;
    readonly cwd: string;
    readonly status: "running" | "exited";
    readonly pid: number;
    readonly exitCode?: number | undefined;
    readonly sessionID: Session.ID;
    readonly userTitle: string | null;
    readonly foregroundProcess: string | null;
    readonly size: {
        readonly cols: number;
        readonly rows: number;
    };
    readonly output: {
        readonly head: number;
        readonly tail: number;
    };
};
export type ExperimentalPersistentPtyCreateOperation<E = never> = (input: ExperimentalPersistentPtyCreateInput) => Effect.Effect<ExperimentalPersistentPtyCreateOutput, E>;
export type ExperimentalPersistentPtyShutdownOutput = void;
export type ExperimentalPersistentPtyShutdownOperation<E = never> = () => Effect.Effect<ExperimentalPersistentPtyShutdownOutput, E>;
export type ExperimentalPersistentPtyHandoffOutput = {
    readonly handoff: {
        readonly directory: string;
        readonly instanceID: string;
        readonly ticket: string;
        readonly expiresAt: number;
    } | null;
};
export type ExperimentalPersistentPtyHandoffOperation<E = never> = () => Effect.Effect<ExperimentalPersistentPtyHandoffOutput, E>;
export type ExperimentalPersistentPtyGetInput = {
    readonly ptyID: Pty.ID;
};
export type ExperimentalPersistentPtyGetOutput = {
    readonly id: Pty.ID;
    readonly title: string;
    readonly command: string;
    readonly args: ReadonlyArray<string>;
    readonly cwd: string;
    readonly status: "running" | "exited";
    readonly pid: number;
    readonly exitCode?: number | undefined;
    readonly sessionID: Session.ID;
    readonly userTitle: string | null;
    readonly foregroundProcess: string | null;
    readonly size: {
        readonly cols: number;
        readonly rows: number;
    };
    readonly output: {
        readonly head: number;
        readonly tail: number;
    };
};
export type ExperimentalPersistentPtyGetOperation<E = never> = (input: ExperimentalPersistentPtyGetInput) => Effect.Effect<ExperimentalPersistentPtyGetOutput, E>;
export type ExperimentalPersistentPtyUpdateInput = {
    readonly ptyID: Pty.ID;
    readonly attachmentID?: string | undefined;
    readonly size?: {
        readonly cols: number;
        readonly rows: number;
    } | undefined;
    readonly title?: string | null | undefined;
};
export type ExperimentalPersistentPtyUpdateOutput = {
    readonly id: Pty.ID;
    readonly title: string;
    readonly command: string;
    readonly args: ReadonlyArray<string>;
    readonly cwd: string;
    readonly status: "running" | "exited";
    readonly pid: number;
    readonly exitCode?: number | undefined;
    readonly sessionID: Session.ID;
    readonly userTitle: string | null;
    readonly foregroundProcess: string | null;
    readonly size: {
        readonly cols: number;
        readonly rows: number;
    };
    readonly output: {
        readonly head: number;
        readonly tail: number;
    };
};
export type ExperimentalPersistentPtyUpdateOperation<E = never> = (input: ExperimentalPersistentPtyUpdateInput) => Effect.Effect<ExperimentalPersistentPtyUpdateOutput, E>;
export type ExperimentalPersistentPtySnapshotInput = {
    readonly ptyID: Pty.ID;
};
export type ExperimentalPersistentPtySnapshotOutput = {
    readonly info: {
        readonly id: Pty.ID;
        readonly title: string;
        readonly command: string;
        readonly args: ReadonlyArray<string>;
        readonly cwd: string;
        readonly status: "running" | "exited";
        readonly pid: number;
        readonly exitCode?: number | undefined;
        readonly sessionID: Session.ID;
        readonly userTitle: string | null;
        readonly foregroundProcess: string | null;
        readonly size: {
            readonly cols: number;
            readonly rows: number;
        };
        readonly output: {
            readonly head: number;
            readonly tail: number;
        };
    };
    readonly text: string;
    readonly checkpoint: globalThis.Uint8Array;
    readonly cursor: {
        readonly x: number;
        readonly y: number;
    };
};
export type ExperimentalPersistentPtySnapshotOperation<E = never> = (input: ExperimentalPersistentPtySnapshotInput) => Effect.Effect<ExperimentalPersistentPtySnapshotOutput, E>;
export type ExperimentalPersistentPtyRemoveInput = {
    readonly ptyID: Pty.ID;
};
export type ExperimentalPersistentPtyRemoveOutput = void;
export type ExperimentalPersistentPtyRemoveOperation<E = never> = (input: ExperimentalPersistentPtyRemoveInput) => Effect.Effect<ExperimentalPersistentPtyRemoveOutput, E>;
export type ExperimentalPersistentPtyConnectTokenInput = {
    readonly ptyID: Pty.ID;
    readonly "x-opencode-ticket"?: string | undefined;
};
export type ExperimentalPersistentPtyConnectTokenOutput = PtyTicket.ConnectToken;
export type ExperimentalPersistentPtyConnectTokenOperation<E = never> = (input: ExperimentalPersistentPtyConnectTokenInput) => Effect.Effect<ExperimentalPersistentPtyConnectTokenOutput, E>;
export type ExperimentalScheduleCreateInput = {
    readonly sessionID: Session.ID;
    readonly name?: string | undefined;
    readonly when?: Schedule.WhenInput | undefined;
    readonly if?: Schedule.ConditionInput | undefined;
    readonly until?: Schedule.ConditionInput | undefined;
    readonly ends?: Schedule.Ends | undefined;
    readonly prompt: string;
};
export type ExperimentalScheduleCreateOutput = Schedule.Info;
export type ExperimentalScheduleCreateOperation<E = never> = (input: ExperimentalScheduleCreateInput) => Effect.Effect<ExperimentalScheduleCreateOutput, E>;
export type ExperimentalScheduleListInput = {
    readonly sessionID: Session.ID;
};
export type ExperimentalScheduleListOutput = ReadonlyArray<Schedule.Info>;
export type ExperimentalScheduleListOperation<E = never> = (input: ExperimentalScheduleListInput) => Effect.Effect<ExperimentalScheduleListOutput, E>;
export type ExperimentalScheduleGetInput = {
    readonly scheduleID: Schedule.ID;
};
export type ExperimentalScheduleGetOutput = Schedule.Info;
export type ExperimentalScheduleGetOperation<E = never> = (input: ExperimentalScheduleGetInput) => Effect.Effect<ExperimentalScheduleGetOutput, E>;
export type ExperimentalSchedulePauseInput = {
    readonly scheduleID: Schedule.ID;
};
export type ExperimentalSchedulePauseOutput = Schedule.Info;
export type ExperimentalSchedulePauseOperation<E = never> = (input: ExperimentalSchedulePauseInput) => Effect.Effect<ExperimentalSchedulePauseOutput, E>;
export type ExperimentalScheduleResumeInput = {
    readonly scheduleID: Schedule.ID;
};
export type ExperimentalScheduleResumeOutput = Schedule.Info;
export type ExperimentalScheduleResumeOperation<E = never> = (input: ExperimentalScheduleResumeInput) => Effect.Effect<ExperimentalScheduleResumeOutput, E>;
export type ExperimentalScheduleDeleteInput = {
    readonly scheduleID: Schedule.ID;
};
export type ExperimentalScheduleDeleteOutput = void;
export type ExperimentalScheduleDeleteOperation<E = never> = (input: ExperimentalScheduleDeleteInput) => Effect.Effect<ExperimentalScheduleDeleteOutput, E>;
export type ExperimentalArtifactsProvidersInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ExperimentalArtifactsProvidersOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Artifact.Provider>;
};
export type ExperimentalArtifactsProvidersOperation<E = never> = (input?: ExperimentalArtifactsProvidersInput) => Effect.Effect<ExperimentalArtifactsProvidersOutput, E>;
export type ExperimentalArtifactsListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly sessionID?: Session.ID | undefined;
    readonly provider?: Artifact.ProviderID | undefined;
};
export type ExperimentalArtifactsListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Artifact.Info>;
};
export type ExperimentalArtifactsListOperation<E = never> = (input?: ExperimentalArtifactsListInput) => Effect.Effect<ExperimentalArtifactsListOutput, E>;
export type ExperimentalArtifactsCreateInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly title: string;
    readonly files: {
        readonly [x: string]: string;
    };
    readonly entry?: string | undefined;
    readonly provider?: Artifact.ProviderID | undefined;
    readonly sessionID?: Session.ID | undefined;
};
export type ExperimentalArtifactsCreateOutput = {
    readonly location: Location.PublicRef;
    readonly data: Artifact.Info;
};
export type ExperimentalArtifactsCreateOperation<E = never> = (input: ExperimentalArtifactsCreateInput) => Effect.Effect<ExperimentalArtifactsCreateOutput, E>;
export type ExperimentalArtifactsGetInput = {
    readonly artifactID: Artifact.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ExperimentalArtifactsGetOutput = {
    readonly location: Location.PublicRef;
    readonly data: Artifact.Content;
};
export type ExperimentalArtifactsGetOperation<E = never> = (input: ExperimentalArtifactsGetInput) => Effect.Effect<ExperimentalArtifactsGetOutput, E>;
export type ExperimentalArtifactsUpdateInput = {
    readonly artifactID: Artifact.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly title?: string | undefined;
    readonly files: {
        readonly [x: string]: string;
    };
    readonly entry?: string | undefined;
    readonly sessionID?: Session.ID | undefined;
};
export type ExperimentalArtifactsUpdateOutput = {
    readonly location: Location.PublicRef;
    readonly data: Artifact.Info;
};
export type ExperimentalArtifactsUpdateOperation<E = never> = (input: ExperimentalArtifactsUpdateInput) => Effect.Effect<ExperimentalArtifactsUpdateOutput, E>;
export type ExperimentalArtifactsDeleteInput = {
    readonly artifactID: Artifact.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ExperimentalArtifactsDeleteOutput = void;
export type ExperimentalArtifactsDeleteOperation<E = never> = (input: ExperimentalArtifactsDeleteInput) => Effect.Effect<ExperimentalArtifactsDeleteOutput, E>;
export type ExperimentalJobListInput = {
    readonly sessionID?: Session.ID | undefined;
    readonly kind?: Job.Kind | undefined;
    readonly status?: Job.Status | undefined;
    readonly descendants?: boolean | undefined;
};
export type ExperimentalJobListOutput = ReadonlyArray<Job.Info>;
export type ExperimentalJobListOperation<E = never> = (input?: ExperimentalJobListInput) => Effect.Effect<ExperimentalJobListOutput, E>;
export type ExperimentalPluginWebListOutput = ReadonlyArray<{
    readonly id: Plugin.ID;
    readonly revision: string;
    readonly options: {
        readonly [x: string]: Schema.Json;
    };
    readonly ticket: string;
}>;
export type ExperimentalPluginWebListOperation<E = never> = () => Effect.Effect<ExperimentalPluginWebListOutput, E>;
export type ExperimentalPluginWebModuleInput = {
    readonly id: Plugin.ID;
    readonly revision: string;
    readonly ticket: string;
};
export type ExperimentalPluginWebModuleOutput = globalThis.Uint8Array;
export type ExperimentalPluginWebModuleOperation<E = never> = (input: ExperimentalPluginWebModuleInput) => Effect.Effect<ExperimentalPluginWebModuleOutput, E>;
export interface ExperimentalApi<E = never> {
    readonly persistentPty: {
        readonly read: ExperimentalPersistentPtyReadOperation<E>;
        readonly list: ExperimentalPersistentPtyListOperation<E>;
        readonly create: ExperimentalPersistentPtyCreateOperation<E>;
        readonly shutdown: ExperimentalPersistentPtyShutdownOperation<E>;
        readonly handoff: ExperimentalPersistentPtyHandoffOperation<E>;
        readonly get: ExperimentalPersistentPtyGetOperation<E>;
        readonly update: ExperimentalPersistentPtyUpdateOperation<E>;
        readonly snapshot: ExperimentalPersistentPtySnapshotOperation<E>;
        readonly remove: ExperimentalPersistentPtyRemoveOperation<E>;
        readonly connectToken: ExperimentalPersistentPtyConnectTokenOperation<E>;
    };
    readonly schedule: {
        readonly create: ExperimentalScheduleCreateOperation<E>;
        readonly list: ExperimentalScheduleListOperation<E>;
        readonly get: ExperimentalScheduleGetOperation<E>;
        readonly pause: ExperimentalSchedulePauseOperation<E>;
        readonly resume: ExperimentalScheduleResumeOperation<E>;
        readonly delete: ExperimentalScheduleDeleteOperation<E>;
    };
    readonly artifacts: {
        readonly providers: ExperimentalArtifactsProvidersOperation<E>;
        readonly list: ExperimentalArtifactsListOperation<E>;
        readonly create: ExperimentalArtifactsCreateOperation<E>;
        readonly get: ExperimentalArtifactsGetOperation<E>;
        readonly update: ExperimentalArtifactsUpdateOperation<E>;
        readonly delete: ExperimentalArtifactsDeleteOperation<E>;
    };
    readonly job: {
        readonly list: ExperimentalJobListOperation<E>;
    };
    readonly plugin: {
        readonly webList: ExperimentalPluginWebListOperation<E>;
        readonly webModule: ExperimentalPluginWebModuleOperation<E>;
    };
}
export type ShellListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ShellListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Shell.Info>;
};
export type ShellListOperation<E = never> = (input?: ShellListInput) => Effect.Effect<ShellListOutput, E>;
export type ShellCreateInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly command: string;
    readonly cwd?: string | undefined;
    readonly timeout?: number | undefined;
    readonly metadata?: {
        readonly [x: string]: unknown;
    } | undefined;
};
export type ShellCreateOutput = {
    readonly location: Location.PublicRef;
    readonly data: Shell.Info;
};
export type ShellCreateOperation<E = never> = (input: ShellCreateInput) => Effect.Effect<ShellCreateOutput, E>;
export type ShellGetInput = {
    readonly id: Shell.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ShellGetOutput = {
    readonly location: Location.PublicRef;
    readonly data: Shell.Info;
};
export type ShellGetOperation<E = never> = (input: ShellGetInput) => Effect.Effect<ShellGetOutput, E>;
export type ShellOutputInput = {
    readonly id: Shell.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly cursor?: number | undefined;
    readonly limit?: number | undefined;
};
export type ShellOutputOutput = {
    readonly location: Location.PublicRef;
    readonly data: {
        readonly output: string;
        readonly cursor: number;
        readonly size: number;
        readonly truncated: boolean;
    };
};
export type ShellOutputOperation<E = never> = (input: ShellOutputInput) => Effect.Effect<ShellOutputOutput, E>;
export type ShellRemoveInput = {
    readonly id: Shell.ID;
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ShellRemoveOutput = void;
export type ShellRemoveOperation<E = never> = (input: ShellRemoveInput) => Effect.Effect<ShellRemoveOutput, E>;
export interface ShellApi<E = never> {
    readonly list: ShellListOperation<E>;
    readonly create: ShellCreateOperation<E>;
    readonly get: ShellGetOperation<E>;
    readonly output: ShellOutputOperation<E>;
    readonly remove: ShellRemoveOperation<E>;
}
export type ReferenceListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ReferenceListOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Reference.Info>;
};
export type ReferenceListOperation<E = never> = (input?: ReferenceListInput) => Effect.Effect<ReferenceListOutput, E>;
export interface ReferenceApi<E = never> {
    readonly list: ReferenceListOperation<E>;
}
export type WorktreeListInput = {
    readonly projectID: Project.ID;
};
export type WorktreeListOutput = Worktree.List;
export type WorktreeListOperation<E = never> = (input: WorktreeListInput) => Effect.Effect<WorktreeListOutput, E>;
export type WorktreeCreateInput = {
    readonly projectID: Project.ID;
    readonly from?: AbsolutePath | undefined;
    readonly branch?: string | undefined;
    readonly directory?: AbsolutePath | undefined;
    readonly name?: string | undefined;
};
export type WorktreeCreateOutput = Worktree.Info;
export type WorktreeCreateOperation<E = never> = (input: WorktreeCreateInput) => Effect.Effect<WorktreeCreateOutput, E>;
export type WorktreeRemoveInput = {
    readonly projectID: Project.ID;
    readonly directory: AbsolutePath;
    readonly force: boolean;
};
export type WorktreeRemoveOutput = void;
export type WorktreeRemoveOperation<E = never> = (input: WorktreeRemoveInput) => Effect.Effect<WorktreeRemoveOutput, E>;
export type WorktreeRefreshInput = {
    readonly projectID: Project.ID;
};
export type WorktreeRefreshOutput = void;
export type WorktreeRefreshOperation<E = never> = (input: WorktreeRefreshInput) => Effect.Effect<WorktreeRefreshOutput, E>;
export interface WorktreeApi<E = never> {
    readonly list: WorktreeListOperation<E>;
    readonly create: WorktreeCreateOperation<E>;
    readonly remove: WorktreeRemoveOperation<E>;
    readonly refresh: WorktreeRefreshOperation<E>;
}
export type VcsInitInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly provider?: string | undefined;
};
export type VcsInitOutput = void;
export type VcsInitOperation<E = never> = (input?: VcsInitInput) => Effect.Effect<VcsInitOutput, E>;
export type VcsGetInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type VcsGetOutput = {
    readonly location: Location.PublicRef;
    readonly data: Vcs.Info;
};
export type VcsGetOperation<E = never> = (input?: VcsGetInput) => Effect.Effect<VcsGetOutput, E>;
export type VcsBaseInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type VcsBaseOutput = {
    readonly location: Location.PublicRef;
    readonly data: Vcs.Base | null;
};
export type VcsBaseOperation<E = never> = (input?: VcsBaseInput) => Effect.Effect<VcsBaseOutput, E>;
export type VcsStatusInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type VcsStatusOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<Vcs.FileStatus>;
};
export type VcsStatusOperation<E = never> = (input?: VcsStatusInput) => Effect.Effect<VcsStatusOutput, E>;
export type VcsBranchListInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly search?: string | undefined;
    readonly limit?: number | undefined;
};
export type VcsBranchListOutput = {
    readonly location: Location.PublicRef;
    readonly data: Vcs.BranchList;
};
export type VcsBranchListOperation<E = never> = (input?: VcsBranchListInput) => Effect.Effect<VcsBranchListOutput, E>;
export type VcsDiffInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly mode: Vcs.Mode;
    readonly base?: string | undefined;
    readonly context?: number | undefined;
    readonly untracked?: Vcs.Untracked | undefined;
};
export type VcsDiffOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<FileDiff.Info>;
};
export type VcsDiffOperation<E = never> = (input: VcsDiffInput) => Effect.Effect<VcsDiffOutput, E>;
export interface VcsApi<E = never> {
    readonly init: VcsInitOperation<E>;
    readonly get: VcsGetOperation<E>;
    readonly base: VcsBaseOperation<E>;
    readonly status: VcsStatusOperation<E>;
    readonly branch: {
        readonly list: VcsBranchListOperation<E>;
    };
    readonly diff: VcsDiffOperation<E>;
}
export type DebugHeapDumpInput = {
    readonly directory?: string | undefined;
};
export type DebugHeapDumpOutput = {
    readonly path: string;
    readonly pid: number;
    readonly memory: {
        readonly rss: number;
        readonly heapTotal: number;
        readonly heapUsed: number;
        readonly external: number;
        readonly arrayBuffers: number;
    };
};
export type DebugHeapDumpOperation<E = never> = (input?: DebugHeapDumpInput) => Effect.Effect<DebugHeapDumpOutput, E>;
export type DebugLocationListOutput = ReadonlyArray<Location.PublicRef>;
export type DebugLocationListOperation<E = never> = () => Effect.Effect<DebugLocationListOutput, E>;
export type DebugLocationEvictInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type DebugLocationEvictOutput = void;
export type DebugLocationEvictOperation<E = never> = (input?: DebugLocationEvictInput) => Effect.Effect<DebugLocationEvictOutput, E>;
export interface DebugApi<E = never> {
    readonly heapDump: DebugHeapDumpOperation<E>;
    readonly location: {
        readonly list: DebugLocationListOperation<E>;
        readonly evict: DebugLocationEvictOperation<E>;
    };
}
export type ExperimentalMigrationV1StatusOutput = {
    readonly status: "required" | "completed";
} | {
    readonly status: "running";
    readonly progress: {
        readonly label: string;
        readonly numerator?: number | undefined;
        readonly denominator?: number | undefined;
    };
} | {
    readonly status: "error";
    readonly error: string;
};
export type ExperimentalMigrationV1StatusOperation<E = never> = () => Effect.Effect<ExperimentalMigrationV1StatusOutput, E>;
export interface ExperimentalMigrationApi<E = never> {
    readonly v1: {
        readonly status: ExperimentalMigrationV1StatusOperation<E>;
    };
}
export type WebsearchProvidersInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type WebsearchProvidersOutput = {
    readonly location: Location.PublicRef;
    readonly data: ReadonlyArray<WebSearch.Provider>;
};
export type WebsearchProvidersOperation<E = never> = (input?: WebsearchProvidersInput) => Effect.Effect<WebsearchProvidersOutput, E>;
export type WebsearchQueryInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
    readonly query: string;
    readonly providerID?: WebSearch.ID | undefined;
};
export type WebsearchQueryOutput = {
    readonly location: Location.PublicRef;
    readonly data: WebSearch.Response;
};
export type WebsearchQueryOperation<E = never> = (input: WebsearchQueryInput) => Effect.Effect<WebsearchQueryOutput, E>;
export interface WebsearchApi<E = never> {
    readonly providers: WebsearchProvidersOperation<E>;
    readonly query: WebsearchQueryOperation<E>;
}
export type ExperimentalUsageLimitsInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ExperimentalUsageLimitsOutput = {
    readonly location: Location.PublicRef;
    readonly data: UsageLimits.Info | null;
};
export type ExperimentalUsageLimitsOperation<E = never> = (input?: ExperimentalUsageLimitsInput) => Effect.Effect<ExperimentalUsageLimitsOutput, E>;
export interface ExperimentalUsageApi<E = never> {
    readonly limits: ExperimentalUsageLimitsOperation<E>;
}
export type ConfigGetInput = {
    readonly location?: {
        readonly directory?: string | undefined;
    } | undefined;
};
export type ConfigGetOutput = ReadonlyArray<Config.Entry>;
export type ConfigGetOperation<E = never> = (input?: ConfigGetInput) => Effect.Effect<ConfigGetOutput, E>;
export type ConfigShellsOutput = ReadonlyArray<{
    readonly path: string;
    readonly name: string;
    readonly acceptable: boolean;
}>;
export type ConfigShellsOperation<E = never> = () => Effect.Effect<ConfigShellsOutput, E>;
export interface ConfigApi<E = never> {
    readonly get: ConfigGetOperation<E>;
    readonly shells: ConfigShellsOperation<E>;
    /** @deprecated Use `client.experimental.config.update`. Removed in the next minor. */
    readonly update: ExperimentalConfigUpdateOperation<E>;
}
export type ExperimentalConfigUpdateInput = {
    readonly shell: string | null;
};
export type ExperimentalConfigUpdateOutput = void;
export type ExperimentalConfigUpdateOperation<E = never> = (input: ExperimentalConfigUpdateInput) => Effect.Effect<ExperimentalConfigUpdateOutput, E>;
export interface ExperimentalConfigApi<E = never> {
    readonly update: ExperimentalConfigUpdateOperation<E>;
}
/** @deprecated Use `ExperimentalSessionStatsInput`. Removed in the next minor. */
export type SessionStatsInput = ExperimentalSessionStatsInput;
/** @deprecated Use `ExperimentalSessionStatsOutput`. Removed in the next minor. */
export type SessionStatsOutput = ExperimentalSessionStatsOutput;
/** @deprecated Use `ExperimentalSessionStatsOperation`. Removed in the next minor. */
export type SessionStatsOperation<E = never> = ExperimentalSessionStatsOperation<E>;
/** @deprecated Use `ExperimentalSessionImportInput`. Removed in the next minor. */
export type SessionImportInput = ExperimentalSessionImportInput;
/** @deprecated Use `ExperimentalSessionImportOutput`. Removed in the next minor. */
export type SessionImportOutput = ExperimentalSessionImportOutput;
/** @deprecated Use `ExperimentalSessionImportOperation`. Removed in the next minor. */
export type SessionImportOperation<E = never> = ExperimentalSessionImportOperation<E>;
/** @deprecated Use `ExperimentalSessionExportInput`. Removed in the next minor. */
export type SessionExportInput = ExperimentalSessionExportInput;
/** @deprecated Use `ExperimentalSessionExportOutput`. Removed in the next minor. */
export type SessionExportOutput = ExperimentalSessionExportOutput;
/** @deprecated Use `ExperimentalSessionExportOperation`. Removed in the next minor. */
export type SessionExportOperation<E = never> = ExperimentalSessionExportOperation<E>;
/** @deprecated Use `ExperimentalSessionSkillInput`. Removed in the next minor. */
export type SessionSkillInput = ExperimentalSessionSkillInput;
/** @deprecated Use `ExperimentalSessionSkillOutput`. Removed in the next minor. */
export type SessionSkillOutput = ExperimentalSessionSkillOutput;
/** @deprecated Use `ExperimentalSessionSkillOperation`. Removed in the next minor. */
export type SessionSkillOperation<E = never> = ExperimentalSessionSkillOperation<E>;
/** @deprecated Use `ExperimentalSessionWaitInput`. Removed in the next minor. */
export type SessionWaitInput = ExperimentalSessionWaitInput;
/** @deprecated Use `ExperimentalSessionWaitOutput`. Removed in the next minor. */
export type SessionWaitOutput = ExperimentalSessionWaitOutput;
/** @deprecated Use `ExperimentalSessionWaitOperation`. Removed in the next minor. */
export type SessionWaitOperation<E = never> = ExperimentalSessionWaitOperation<E>;
/** @deprecated Use `ExperimentalSessionInstructionsEntryListInput`. Removed in the next minor. */
export type SessionInstructionsEntryListInput = ExperimentalSessionInstructionsEntryListInput;
/** @deprecated Use `ExperimentalSessionInstructionsEntryListOutput`. Removed in the next minor. */
export type SessionInstructionsEntryListOutput = ExperimentalSessionInstructionsEntryListOutput;
/** @deprecated Use `ExperimentalSessionInstructionsEntryListOperation`. Removed in the next minor. */
export type SessionInstructionsEntryListOperation<E = never> = ExperimentalSessionInstructionsEntryListOperation<E>;
/** @deprecated Use `ExperimentalSessionInstructionsEntryPutInput`. Removed in the next minor. */
export type SessionInstructionsEntryPutInput = ExperimentalSessionInstructionsEntryPutInput;
/** @deprecated Use `ExperimentalSessionInstructionsEntryPutOutput`. Removed in the next minor. */
export type SessionInstructionsEntryPutOutput = ExperimentalSessionInstructionsEntryPutOutput;
/** @deprecated Use `ExperimentalSessionInstructionsEntryPutOperation`. Removed in the next minor. */
export type SessionInstructionsEntryPutOperation<E = never> = ExperimentalSessionInstructionsEntryPutOperation<E>;
/** @deprecated Use `ExperimentalSessionInstructionsEntryRemoveInput`. Removed in the next minor. */
export type SessionInstructionsEntryRemoveInput = ExperimentalSessionInstructionsEntryRemoveInput;
/** @deprecated Use `ExperimentalSessionInstructionsEntryRemoveOutput`. Removed in the next minor. */
export type SessionInstructionsEntryRemoveOutput = ExperimentalSessionInstructionsEntryRemoveOutput;
/** @deprecated Use `ExperimentalSessionInstructionsEntryRemoveOperation`. Removed in the next minor. */
export type SessionInstructionsEntryRemoveOperation<E = never> = ExperimentalSessionInstructionsEntryRemoveOperation<E>;
/** @deprecated Use `ExperimentalSessionLogInput`. Removed in the next minor. */
export type SessionLogInput = ExperimentalSessionLogInput;
/** @deprecated Use `ExperimentalSessionLogOutput`. Removed in the next minor. */
export type SessionLogOutput = ExperimentalSessionLogOutput;
/** @deprecated Use `ExperimentalSessionLogOperation`. Removed in the next minor. */
export type SessionLogOperation<E = never> = ExperimentalSessionLogOperation<E>;
/** @deprecated Use `ExperimentalGenerateTextInput`. Removed in the next minor. */
export type GenerateTextInput = ExperimentalGenerateTextInput;
/** @deprecated Use `ExperimentalGenerateTextOutput`. Removed in the next minor. */
export type GenerateTextOutput = ExperimentalGenerateTextOutput;
/** @deprecated Use `ExperimentalGenerateTextOperation`. Removed in the next minor. */
export type GenerateTextOperation<E = never> = ExperimentalGenerateTextOperation<E>;
/** @deprecated Use `ExperimentalGenerateImageInput`. Removed in the next minor. */
export type GenerateImageInput = ExperimentalGenerateImageInput;
/** @deprecated Use `ExperimentalGenerateImageOutput`. Removed in the next minor. */
export type GenerateImageOutput = ExperimentalGenerateImageOutput;
/** @deprecated Use `ExperimentalGenerateImageOperation`. Removed in the next minor. */
export type GenerateImageOperation<E = never> = ExperimentalGenerateImageOperation<E>;
/** @deprecated Use `ExperimentalGenerateDecisionsInput`. Removed in the next minor. */
export type GenerateDecisionsInput = ExperimentalGenerateDecisionsInput;
/** @deprecated Use `ExperimentalGenerateDecisionsOutput`. Removed in the next minor. */
export type GenerateDecisionsOutput = ExperimentalGenerateDecisionsOutput;
/** @deprecated Use `ExperimentalGenerateDecisionsOperation`. Removed in the next minor. */
export type GenerateDecisionsOperation<E = never> = ExperimentalGenerateDecisionsOperation<E>;
/** @deprecated Use `ExperimentalVoiceModelsOutput`. Removed in the next minor. */
export type VoiceModelsOutput = ExperimentalVoiceModelsOutput;
/** @deprecated Use `ExperimentalVoiceModelsOperation`. Removed in the next minor. */
export type VoiceModelsOperation<E = never> = ExperimentalVoiceModelsOperation<E>;
/** @deprecated Use `ExperimentalVoiceSessionInput`. Removed in the next minor. */
export type VoiceSessionInput = ExperimentalVoiceSessionInput;
/** @deprecated Use `ExperimentalVoiceSessionOutput`. Removed in the next minor. */
export type VoiceSessionOutput = ExperimentalVoiceSessionOutput;
/** @deprecated Use `ExperimentalVoiceSessionOperation`. Removed in the next minor. */
export type VoiceSessionOperation<E = never> = ExperimentalVoiceSessionOperation<E>;
/** @deprecated Use `ExperimentalTranscriptionTranscribeWithOverridesInput`. Removed in the next minor. */
export type TranscriptionTranscribeWithOverridesInput = ExperimentalTranscriptionTranscribeWithOverridesInput;
/** @deprecated Use `ExperimentalTranscriptionTranscribeWithOverridesOutput`. Removed in the next minor. */
export type TranscriptionTranscribeWithOverridesOutput = ExperimentalTranscriptionTranscribeWithOverridesOutput;
/** @deprecated Use `ExperimentalTranscriptionTranscribeWithOverridesOperation`. Removed in the next minor. */
export type TranscriptionTranscribeWithOverridesOperation<E = never> = ExperimentalTranscriptionTranscribeWithOverridesOperation<E>;
/** @deprecated Use `ExperimentalIntegrationWellknownAddInput`. Removed in the next minor. */
export type IntegrationWellknownAddInput = ExperimentalIntegrationWellknownAddInput;
/** @deprecated Use `ExperimentalIntegrationWellknownAddOutput`. Removed in the next minor. */
export type IntegrationWellknownAddOutput = ExperimentalIntegrationWellknownAddOutput;
/** @deprecated Use `ExperimentalIntegrationWellknownAddOperation`. Removed in the next minor. */
export type IntegrationWellknownAddOperation<E = never> = ExperimentalIntegrationWellknownAddOperation<E>;
/** @deprecated Use `ExperimentalMcpAddInput`. Removed in the next minor. */
export type McpAddInput = ExperimentalMcpAddInput;
/** @deprecated Use `ExperimentalMcpAddOutput`. Removed in the next minor. */
export type McpAddOutput = ExperimentalMcpAddOutput;
/** @deprecated Use `ExperimentalMcpAddOperation`. Removed in the next minor. */
export type McpAddOperation<E = never> = ExperimentalMcpAddOperation<E>;
/** @deprecated Use `ExperimentalMcpRemoveInput`. Removed in the next minor. */
export type McpRemoveInput = ExperimentalMcpRemoveInput;
/** @deprecated Use `ExperimentalMcpRemoveOutput`. Removed in the next minor. */
export type McpRemoveOutput = ExperimentalMcpRemoveOutput;
/** @deprecated Use `ExperimentalMcpRemoveOperation`. Removed in the next minor. */
export type McpRemoveOperation<E = never> = ExperimentalMcpRemoveOperation<E>;
/** @deprecated Use `ExperimentalMcpConnectInput`. Removed in the next minor. */
export type McpConnectInput = ExperimentalMcpConnectInput;
/** @deprecated Use `ExperimentalMcpConnectOutput`. Removed in the next minor. */
export type McpConnectOutput = ExperimentalMcpConnectOutput;
/** @deprecated Use `ExperimentalMcpConnectOperation`. Removed in the next minor. */
export type McpConnectOperation<E = never> = ExperimentalMcpConnectOperation<E>;
/** @deprecated Use `ExperimentalMcpDisconnectInput`. Removed in the next minor. */
export type McpDisconnectInput = ExperimentalMcpDisconnectInput;
/** @deprecated Use `ExperimentalMcpDisconnectOutput`. Removed in the next minor. */
export type McpDisconnectOutput = ExperimentalMcpDisconnectOutput;
/** @deprecated Use `ExperimentalMcpDisconnectOperation`. Removed in the next minor. */
export type McpDisconnectOperation<E = never> = ExperimentalMcpDisconnectOperation<E>;
/** @deprecated Use `ExperimentalMcpClientTokenInput`. Removed in the next minor. */
export type McpClientTokenInput = ExperimentalMcpClientTokenInput;
/** @deprecated Use `ExperimentalMcpClientTokenOutput`. Removed in the next minor. */
export type McpClientTokenOutput = ExperimentalMcpClientTokenOutput;
/** @deprecated Use `ExperimentalMcpClientTokenOperation`. Removed in the next minor. */
export type McpClientTokenOperation<E = never> = ExperimentalMcpClientTokenOperation<E>;
/** @deprecated Use `ExperimentalFileWatchInput`. Removed in the next minor. */
export type FileWatchInput = ExperimentalFileWatchInput;
/** @deprecated Use `ExperimentalFileWatchOutput`. Removed in the next minor. */
export type FileWatchOutput = ExperimentalFileWatchOutput;
/** @deprecated Use `ExperimentalFileWatchOperation`. Removed in the next minor. */
export type FileWatchOperation<E = never> = ExperimentalFileWatchOperation<E>;
/** @deprecated Use `ExperimentalFileUnwatchInput`. Removed in the next minor. */
export type FileUnwatchInput = ExperimentalFileUnwatchInput;
/** @deprecated Use `ExperimentalFileUnwatchOutput`. Removed in the next minor. */
export type FileUnwatchOutput = ExperimentalFileUnwatchOutput;
/** @deprecated Use `ExperimentalFileUnwatchOperation`. Removed in the next minor. */
export type FileUnwatchOperation<E = never> = ExperimentalFileUnwatchOperation<E>;
/** @deprecated Use `ExperimentalMigrationV1StatusOutput`. Removed in the next minor. */
export type MigrationV1StatusOutput = ExperimentalMigrationV1StatusOutput;
/** @deprecated Use `ExperimentalMigrationV1StatusOperation`. Removed in the next minor. */
export type MigrationV1StatusOperation<E = never> = ExperimentalMigrationV1StatusOperation<E>;
/** @deprecated Use `ExperimentalUsageLimitsInput`. Removed in the next minor. */
export type UsageLimitsInput = ExperimentalUsageLimitsInput;
/** @deprecated Use `ExperimentalUsageLimitsOutput`. Removed in the next minor. */
export type UsageLimitsOutput = ExperimentalUsageLimitsOutput;
/** @deprecated Use `ExperimentalUsageLimitsOperation`. Removed in the next minor. */
export type UsageLimitsOperation<E = never> = ExperimentalUsageLimitsOperation<E>;
/** @deprecated Use `ExperimentalConfigUpdateInput`. Removed in the next minor. */
export type ConfigUpdateInput = ExperimentalConfigUpdateInput;
/** @deprecated Use `ExperimentalConfigUpdateOutput`. Removed in the next minor. */
export type ConfigUpdateOutput = ExperimentalConfigUpdateOutput;
/** @deprecated Use `ExperimentalConfigUpdateOperation`. Removed in the next minor. */
export type ConfigUpdateOperation<E = never> = ExperimentalConfigUpdateOperation<E>;
/** @deprecated Use `ExperimentalGenerateApi`. Removed in the next minor. */
export type GenerateApi<E = never> = ExperimentalGenerateApi<E>;
/** @deprecated Use `ExperimentalVoiceApi`. Removed in the next minor. */
export type VoiceApi<E = never> = ExperimentalVoiceApi<E>;
/** @deprecated Use `ExperimentalMigrationApi`. Removed in the next minor. */
export type MigrationApi<E = never> = ExperimentalMigrationApi<E>;
/** @deprecated Use `ExperimentalUsageApi`. Removed in the next minor. */
export type UsageApi<E = never> = ExperimentalUsageApi<E>;
export interface AppApi<E = never> {
    readonly server: ServerApi<E>;
    readonly location: LocationApi<E>;
    readonly agent: AgentApi<E>;
    readonly plugin: PluginApi<E>;
    readonly session: SessionApi<E>;
    readonly experimental: ExperimentalApi<E> & {
        readonly session: ExperimentalSessionApi<E>;
        readonly generate: ExperimentalGenerateApi<E>;
        readonly voice: ExperimentalVoiceApi<E>;
        readonly transcription: ExperimentalTranscriptionApi<E>;
        readonly integration: ExperimentalIntegrationApi<E>;
        readonly mcp: ExperimentalMcpApi<E>;
        readonly file: ExperimentalFileApi<E>;
        readonly migration: ExperimentalMigrationApi<E>;
        readonly usage: ExperimentalUsageApi<E>;
        readonly config: ExperimentalConfigApi<E>;
    };
    readonly message: MessageApi<E>;
    readonly model: ModelApi<E>;
    readonly transcription: TranscriptionApi<E>;
    readonly provider: ProviderApi<E>;
    readonly integration: IntegrationApi<E>;
    readonly mcp: McpApi<E>;
    readonly credential: CredentialApi<E>;
    readonly project: ProjectApi<E>;
    readonly form: FormApi<E>;
    readonly permission: PermissionApi<E>;
    readonly file: FileApi<E>;
    readonly command: CommandApi<E>;
    readonly skill: SkillApi<E>;
    readonly rpc: RpcApi<E>;
    readonly event: EventApi<E>;
    readonly pty: PtyApi<E>;
    readonly shell: ShellApi<E>;
    readonly reference: ReferenceApi<E>;
    readonly worktree: WorktreeApi<E>;
    readonly vcs: VcsApi<E>;
    readonly debug: DebugApi<E>;
    readonly websearch: WebsearchApi<E>;
    readonly config: ConfigApi<E>;
    /** @deprecated Use `client.experimental.generate`. Removed in the next minor. */
    readonly generate: {
        /** @deprecated Use `client.experimental.generate.text`. Removed in the next minor. */
        readonly text: ExperimentalGenerateTextOperation<E>;
        /** @deprecated Use `client.experimental.generate.image`. Removed in the next minor. */
        readonly image: ExperimentalGenerateImageOperation<E>;
        /** @deprecated Use `client.experimental.generate.decisions`. Removed in the next minor. */
        readonly decisions: ExperimentalGenerateDecisionsOperation<E>;
    };
    /** @deprecated Use `client.experimental.voice`. Removed in the next minor. */
    readonly voice: {
        /** @deprecated Use `client.experimental.voice.models`. Removed in the next minor. */
        readonly models: ExperimentalVoiceModelsOperation<E>;
        /** @deprecated Use `client.experimental.voice.session`. Removed in the next minor. */
        readonly session: ExperimentalVoiceSessionOperation<E>;
    };
    /** @deprecated Use `client.experimental.migration`. Removed in the next minor. */
    readonly migration: {
        /** @deprecated Use `client.experimental.migration.v1`. Removed in the next minor. */
        readonly v1: {
            /** @deprecated Use `client.experimental.migration.v1.status`. Removed in the next minor. */
            readonly status: ExperimentalMigrationV1StatusOperation<E>;
        };
    };
    /** @deprecated Use `client.experimental.usage`. Removed in the next minor. */
    readonly usage: {
        /** @deprecated Use `client.experimental.usage.limits`. Removed in the next minor. */
        readonly limits: ExperimentalUsageLimitsOperation<E>;
    };
}
