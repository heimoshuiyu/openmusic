import { Schema } from "effect";
import { Plugin } from "./index.js";
export declare const plugin: Plugin.Definition<{
    readonly prefs: import("./core.js").StoreDeclaration<Schema.Struct<{
        readonly on: Schema.Boolean;
    }>, "global">;
}>;
export declare const split: Plugin.Definition<{
    readonly count: import("./core.js").StoreDeclaration<Schema.Struct<{
        readonly n: Schema.Number;
    }>, "global">;
}>;
export declare const wrongImpl: Plugin.Definition<{}>;
export declare const asyncWindow: Plugin.Definition<{}>;
