import type { Cleanup } from "./core.js";
/**
 * A lifetime, named after Effect's `Scope` without its runtime. Closing it aborts `signal`, then runs its finalizers
 * in reverse order, each isolated from the others' failures, under a deadline. The main host makes one per plugin
 * instance, closed when the plugin is disabled, reloaded, removed, or the app quits; a plugin reaches it through
 * `ctx.signal` and `ctx.onCleanup`.
 *
 * @example
 * ```ts
 * const timer = setInterval(poll, 60_000)
 * scope.addFinalizer(() => clearInterval(timer))
 * const session = scope.fork("session")
 * ```
 */
export interface Scope {
    /** Aborts when the scope closes. Pass it to long work, and return after an `await` if it aborted. */
    readonly signal: AbortSignal;
    /**
     * Runs `fn` when the scope closes, or at once when it already has. A throw or rejection is logged and the other
     * finalizers still run.
     *
     * @param fn - The teardown. A named function's name labels it in the timeout log.
     * @returns Runs `fn` early instead, and removes it from the scope.
     */
    addFinalizer(fn: Cleanup): Cleanup;
    /**
     * A child scope. It closes with this one, in reverse order like a finalizer, or earlier on its own.
     *
     * @param name - Labels the child in logs, as `parent/name`.
     */
    fork(name: string): Scope;
    /**
     * Aborts `signal` at once; the finalizers start once the calling code yields. Settles when they have, or at the
     * deadline: a finalizer still running then is logged and no longer waited for, and the rest start. Closing again
     * also waits for the finalizers added since.
     */
    close(): Promise<void>;
}
/** Writes a structured log entry; the logger serializes each field of `data` as it is. */
type Log = <Data extends Readonly<Record<string, unknown>>>(message: string, data: Data) => void;
type Options = {
    /** How long `close` waits for the finalizers, in milliseconds. */
    readonly timeout: number;
    /** Reports finalizers that failed or timed out. */
    readonly log: Log;
};
/**
 * Creates scopes. The main host makes one per plugin instance.
 *
 * @example
 * ```ts
 * const scope = Scope.make("example", { timeout: 3_000, log: (message, data) => console.error(message, data) })
 * ```
 */
export declare const Scope: {
    /**
     * Creates an open scope.
     *
     * @param name - Labels the scope in logs.
     * @param options - The deadline and the log.
     */
    make: (name: string, options: Options) => Scope;
};
export {};
