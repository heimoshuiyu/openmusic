import type { Plugin } from "vite";
/** Where `gui()` reads a plugin's GUI and writes its `./gui-experimental` bundle. */
export interface GuiOptions {
    /** The module whose default export is the plugin's `Plugin.define`. Defaults to `src/gui.tsx`. */
    readonly entry?: string;
    /** The CommonJS bundle to write, the file `./gui-experimental` exports. Defaults to `dist/gui-experimental.cjs`. */
    readonly outFile?: string;
}
/**
 * Builds a plugin's `./gui-experimental` bundle with Vite: compiles Solid JSX, writes one CommonJS file with every
 * dynamic `import()` inlined, since the app loads no second chunk, and keeps the modules the app provides external,
 * with Electron and Node built-ins. Another module of Effect, Solid or OpenCode fails the build: the app does not
 * provide it, and a bundled copy would not share the app's instance.
 *
 * @param options - The entry and the bundle to write.
 * @returns The Vite plugins.
 *
 * @example
 * ```ts
 * // vite.config.ts
 * export default defineConfig({ plugins: [gui()] })
 * ```
 */
export declare function gui(options?: GuiOptions): Plugin[];
