import { Plugin } from "./index.js";
declare const Fixture: Plugin.Declarations<{}>;
export declare const menus: Plugin.Setup<typeof Fixture>;
export declare const codeBlocks: Plugin.Setup<typeof Fixture>;
export declare const themes: Plugin.Setup<typeof Fixture>;
export {};
