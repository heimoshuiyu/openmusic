import { Schema } from "effect";
import { Ipc } from "./core.js";
/**
 * The updater's state, the same in every window.
 * - `disabled`: this build does not update itself.
 * - `idle`: no check has run yet.
 * - `checking`: a check is running.
 * - `downloading`: `version` is downloading.
 * - `ready`: `version` is staged; `install` restarts into it.
 * - `download-required`: `version` needs a manual download; `install` opens it.
 * - `up-to-date`: the last check found nothing newer.
 * - `installing`: `version` is installing.
 * - `error`: the last check or download failed with `message`.
 */
export declare const UpdaterState: Schema.Union<readonly [Schema.Struct<{
    readonly status: Schema.Literal<"disabled">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"idle">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"checking">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"downloading">;
    readonly version: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"ready">;
    readonly version: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"download-required">;
    readonly version: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"up-to-date">;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"installing">;
    readonly version: Schema.String;
}>, Schema.Struct<{
    readonly status: Schema.Literal<"error">;
    readonly message: Schema.String;
}>]>;
/** The updater's state; see `UpdaterState`. */
export type UpdaterState = typeof UpdaterState.Type;
/** The desktop app updater. Its state is app-wide; every window receives the same value. */
export declare const Updater: Ipc<{
    readonly id: "updater";
    readonly state: Schema.Union<readonly [Schema.Struct<{
        readonly status: Schema.Literal<"disabled">;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"idle">;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"checking">;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"downloading">;
        readonly version: Schema.String;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"ready">;
        readonly version: Schema.String;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"download-required">;
        readonly version: Schema.String;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"up-to-date">;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"installing">;
        readonly version: Schema.String;
    }>, Schema.Struct<{
        readonly status: Schema.Literal<"error">;
        readonly message: Schema.String;
    }>]>;
    readonly methods: {
        check: {
            output: Schema.Union<readonly [Schema.Struct<{
                readonly status: Schema.Literal<"disabled">;
            }>, Schema.Struct<{
                readonly status: Schema.Literal<"idle">;
            }>, Schema.Struct<{
                readonly status: Schema.Literal<"checking">;
            }>, Schema.Struct<{
                readonly status: Schema.Literal<"downloading">;
                readonly version: Schema.String;
            }>, Schema.Struct<{
                readonly status: Schema.Literal<"ready">;
                readonly version: Schema.String;
            }>, Schema.Struct<{
                readonly status: Schema.Literal<"download-required">;
                readonly version: Schema.String;
            }>, Schema.Struct<{
                readonly status: Schema.Literal<"up-to-date">;
            }>, Schema.Struct<{
                readonly status: Schema.Literal<"installing">;
                readonly version: Schema.String;
            }>, Schema.Struct<{
                readonly status: Schema.Literal<"error">;
                readonly message: Schema.String;
            }>]>;
        };
        /** Restarts into a staged update, or opens the installer download. */
        install: {};
    };
    readonly events: {
        /** The app menu asks the focused window to check with in-app feedback (beta builds). */
        check: Schema.Null;
    };
}>;
