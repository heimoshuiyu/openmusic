import { type Accessor, type JSX } from "solid-js";
import type { Context } from "./context.js";
import type { Live } from "./core.js";
import type { PanelFrame } from "./solid.js";
/** The host provides this around every contribution it renders and in the plugin's setup. `usePlugin` reads it. */
export declare const PluginContext: import("solid-js").Context<Context | undefined>;
/**
 * Marks a scope that ends before the plugin does, such as a `createKeyed` run. The host disposes at once a
 * registration made in a scope that already ended.
 */
export declare const LifetimeContext: import("solid-js").Context<{
    /** The scope has ended. */
    readonly ended: boolean;
} | undefined>;
/** The host provides this around panel renders. `usePanel` reads it. */
export declare const PanelContext: import("solid-js").Context<PanelFrame | undefined>;
/** The host provides this around a panel it shows in a narrow-screen drawer (`MobileView.kind` `"drawer"`). */
export declare const DrawerContext: import("solid-js").Context<{
    /** Closes the drawer. */
    readonly close: () => void;
    /** Shows content in place of the drawer's view, with a back control. */
    readonly open: (view: {
        /** The drawer's title while the content shows. */
        readonly title: string;
        /** The content to show. */
        readonly content: JSX.Element;
        /** The element that receives focus when the back control returns to the drawer's view. */
        readonly trigger: HTMLElement;
    }) => void;
} | undefined>;
/**
 * Marks an accessor `ctx.use` returns, so `createKeyed` follows its generations.
 *
 * @param read - Returns the provider's current `Live` value, one object per transition.
 * @returns The same function, marked.
 */
export declare function liveAccessor<T>(read: () => Live<T>): Accessor<Live<T>>;
/**
 * Whether the host marked the accessor with `liveAccessor`.
 *
 * @param source - Any accessor.
 * @returns True for the accessors `ctx.use` returns.
 */
export declare function isLiveAccessor(source: Accessor<unknown>): source is Accessor<Live<unknown>>;
