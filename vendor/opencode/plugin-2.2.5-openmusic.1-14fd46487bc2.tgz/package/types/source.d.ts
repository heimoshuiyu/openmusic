export declare function createPluginSources(watch: (file: string) => Promise<void>): {
    read: (entrypoint: string) => Promise<{
        version: string;
        module: unknown;
    }>;
    dispose: () => void;
};
export declare function localSource(spec: string, directory: string): URL | undefined;
