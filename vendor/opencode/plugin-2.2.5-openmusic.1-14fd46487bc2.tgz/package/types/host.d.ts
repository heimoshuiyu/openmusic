export * as Host from "./host.js";
export interface Target {
    readonly directory: string;
    readonly name?: string;
}
export interface Entrypoints {
    readonly server?: string;
    readonly tui?: string;
    readonly rpc?: string;
    /**
     * The prebuilt CommonJS GUI bundle (`./gui-experimental`, or `gui-experimental.cjs` or `gui-experimental.js` in a
     * local directory without `exports`). Each desktop app window runs its default export; the desktop app's main
     * process runs its `main` export.
     */
    readonly gui?: string;
}
export declare function resolve(input: Target): Entrypoints;
export declare function load(entrypoint: string): Promise<unknown>;
/**
 * The id of a plugin without a server part: its package name, or a local directory's name when it has no
 * package.json name. A server part names its plugin in `Plugin.define` instead.
 */
export declare function packageID(target: Target): string;
