import type { OpenCodeClient } from "@opencode/client";
import type { CredentialApi, ExperimentalGenerateApi, PluginApi } from "@opencode/client/promise/api";
import type { Location } from "@opencode/schema/location";
import type { PluginOptions } from "../options.js";
import type { App } from "../app.js";
import type { AgentDomain } from "./agent.js";
import type { ExperimentalArtifactDomain } from "./artifact.js";
import type { AISDKDomain } from "./aisdk.js";
import type { CommandDomain } from "./command.js";
import type { EventDomain } from "./event.js";
import type { IntegrationDomain } from "./integration.js";
import type { MCPDomain } from "./mcp.js";
import type { ModelDomain } from "./model.js";
import type { PermissionDomain } from "./permission.js";
import type { ProviderDomain } from "./provider.js";
import type { ReferenceDomain } from "./reference.js";
import type { RpcDomain } from "./rpc.js";
import type { SessionDomain } from "./session.js";
import type { ShellDomain } from "./shell.js";
import type { SkillDomain } from "./skill.js";
import type { StorageDomain } from "./storage.js";
import type { ToolDomain } from "./tool.js";
import type { VcsDomain } from "./vcs.js";
import type { WebSearchDomain } from "./websearch.js";
import type { WorktreeDomain } from "./worktree.js";
export interface Context {
    readonly app: App;
    readonly location: Location.Info;
    readonly options: PluginOptions;
    readonly agent: AgentDomain;
    readonly aisdk: AISDKDomain;
    readonly command: CommandDomain;
    readonly credential: Pick<CredentialApi, "activate">;
    readonly event: EventDomain;
    readonly experimental: {
        readonly terminal: Pick<OpenCodeClient["experimental"]["persistentPty"], "read">;
        /** Stateless generation with a model and a prompt: no session, history or tools. */
        readonly generate: ExperimentalGenerateApi;
        readonly artifact: ExperimentalArtifactDomain;
    };
    readonly integration: IntegrationDomain;
    readonly mcp: MCPDomain;
    readonly model: ModelDomain;
    /** @deprecated Use `experimental.generate.text`. */
    readonly generate: Pick<ExperimentalGenerateApi, "text">;
    readonly permission: PermissionDomain;
    readonly plugin: Pick<PluginApi, "list">;
    readonly provider: ProviderDomain;
    readonly reference: ReferenceDomain;
    readonly rpc: RpcDomain;
    readonly session: SessionDomain;
    readonly shell: ShellDomain;
    readonly skill: SkillDomain;
    readonly storage: StorageDomain;
    readonly tool: ToolDomain;
    readonly vcs: VcsDomain;
    readonly websearch: WebSearchDomain;
    readonly worktree: WorktreeDomain;
}
export type Cleanup = () => Promise<void> | void;
export interface Plugin {
    readonly id: string;
    readonly setup: (context: Context) => Promise<Cleanup | void> | Cleanup | void;
}
export declare function define(plugin: Plugin): Plugin;
