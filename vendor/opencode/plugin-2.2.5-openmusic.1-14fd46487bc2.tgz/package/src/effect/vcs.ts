import type { VcsApi } from "@opencode/client/effect/api"
import type { FileDiff } from "@opencode/schema/file-diff"
import type { Vcs } from "@opencode/schema/vcs"
import type { Effect } from "effect"
import type { Transform } from "./registration.js"

export interface VcsScope {
  readonly directory: string
  readonly worktree: string
  readonly canonical: string
  readonly store?: string
}

export interface VcsBranchesInput extends VcsScope {
  readonly search?: string
  readonly limit?: number
}

export interface VcsDiffInput extends VcsScope {
  readonly mode: Vcs.Mode
  readonly base?: string
  readonly context: number
  readonly maxOutputBytes: number
  readonly untracked?: Vcs.Untracked
}

export interface VcsDefinition {
  readonly id: string
  readonly name: string
  readonly init?: (input: VcsScope) => Effect.Effect<void, unknown>
  readonly info: (input: VcsScope) => Effect.Effect<Vcs.Info, unknown>
  readonly base?: (input: VcsScope) => Effect.Effect<Vcs.Base | null, unknown>
  readonly branches: (input: VcsBranchesInput) => Effect.Effect<Vcs.BranchList, unknown>
  readonly status: (input: VcsScope) => Effect.Effect<readonly Vcs.FileStatus[], unknown>
  readonly diff: (input: VcsDiffInput) => Effect.Effect<readonly FileDiff.Info[], unknown>
}

export interface VcsDomain extends Omit<VcsApi<unknown>, "init"> {
  readonly transform: Transform<VcsEditor>
  readonly reload: () => Effect.Effect<void>
}

export interface VcsEditor {
  add(definition: VcsDefinition): void
  readonly default: {
    get(): string | undefined
    set(selection: string): void
  }
}
