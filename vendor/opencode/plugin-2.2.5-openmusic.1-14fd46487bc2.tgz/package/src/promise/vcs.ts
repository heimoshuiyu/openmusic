import type { VcsApi } from "@opencode/client/promise/api"
import type { FileDiff } from "@opencode/schema/file-diff"
import type { Vcs } from "@opencode/schema/vcs"
import type { Transform } from "./registration.js"

export interface VcsScope {
  readonly directory: string
  readonly worktree: string
  readonly canonical: string
  readonly store?: string
}

export interface VcsBranchesInput extends VcsScope {
  readonly search?: string
  readonly limit?: number
}

export interface VcsDiffInput extends VcsScope {
  readonly mode: Vcs.Mode
  readonly base?: string
  readonly context: number
  readonly maxOutputBytes: number
}

export interface VcsDefinition {
  readonly id: string
  readonly name: string
  readonly init?: (input: VcsScope, context: { readonly signal: AbortSignal }) => Promise<void>
  readonly info: (input: VcsScope, context: { readonly signal: AbortSignal }) => Promise<Vcs.Info>
  readonly base?: (input: VcsScope, context: { readonly signal: AbortSignal }) => Promise<Vcs.Base | null>
  readonly branches: (input: VcsBranchesInput, context: { readonly signal: AbortSignal }) => Promise<Vcs.BranchList>
  readonly status: (input: VcsScope, context: { readonly signal: AbortSignal }) => Promise<readonly Vcs.FileStatus[]>
  readonly diff: (input: VcsDiffInput, context: { readonly signal: AbortSignal }) => Promise<readonly FileDiff.Info[]>
}

export interface VcsDomain extends Omit<VcsApi, "init"> {
  readonly transform: Transform<VcsEditor>
  readonly reload: () => Promise<void>
}

export interface VcsEditor {
  add(definition: VcsDefinition): void
  readonly default: {
    get(): string | undefined
    set(selection: string): void
  }
}
