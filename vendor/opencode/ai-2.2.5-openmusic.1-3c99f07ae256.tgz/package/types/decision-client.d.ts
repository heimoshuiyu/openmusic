import { Context, Effect, Layer } from "effect";
import type { DecisionModel, DecisionOptions, DecisionQuestions, DecisionRequest, DecisionResponseFor } from "./decision.js";
import { RequestExecutor } from "./route/executor.js";
import { AIError } from "./schema/index.js";
export type Execute = RequestExecutor.Interface["execute"];
export interface Interface {
    readonly generate: <Options extends DecisionOptions, const Questions extends DecisionQuestions>(request: DecisionRequest<DecisionModel<Options>, Questions>) => Effect.Effect<DecisionResponseFor<Questions>, AIError>;
}
declare const Service_base: Context.ServiceClass<Service, "@opencode/AI/DecisionClient", Interface>;
export declare class Service extends Service_base {
}
export declare const generate: <Options extends DecisionOptions, const Questions extends DecisionQuestions>(request: DecisionRequest<DecisionModel<Options>, Questions>) => Effect.Effect<DecisionResponseFor<Questions>, AIError, Service>;
export declare const layer: Layer.Layer<Service, never, RequestExecutor.Service>;
export declare const fetchLayer: Layer.Layer<RequestExecutor.RequestExecutorService | Service, never, never>;
export declare const DecisionClient: {
    readonly Service: typeof Service;
    readonly layer: Layer.Layer<Service, never, RequestExecutor.RequestExecutorService>;
    readonly fetchLayer: Layer.Layer<RequestExecutor.RequestExecutorService | Service, never, never>;
    readonly generate: typeof generate;
};
export {};
