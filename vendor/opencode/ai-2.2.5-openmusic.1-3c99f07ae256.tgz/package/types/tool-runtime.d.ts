import { Effect } from "effect";
import { LLMEvent, type ToolCallPart, type ToolOutput as ToolOutputType, type ToolResultValue as ToolResultValueType } from "./schema/index.js";
import { type Tool } from "./tool.js";
export interface ToolSettlement {
    readonly result: ToolResultValueType;
    readonly output?: ToolOutputType;
}
export interface DispatchResult extends ToolSettlement {
    readonly events: ReadonlyArray<LLMEvent>;
}
/** Execute one canonical tool call without owning provider IO or continuation. */
export declare const dispatch: (tools: ReadonlyArray<Tool>, call: ToolCallPart) => Effect.Effect<DispatchResult>;
/** A call the loop answers before the next step. With `error`, it is not run and the model gets the error back. */
export interface PendingCall {
    readonly call: ToolCallPart;
    readonly error?: string;
}
/** Run a step's tool calls concurrently, with results in call order. */
export declare const runTools: (tools: ReadonlyArray<Tool>, calls: ReadonlyArray<PendingCall>) => Effect.Effect<DispatchResult[], never, never>;
export declare const ToolRuntime: {
    readonly dispatch: typeof dispatch;
};
