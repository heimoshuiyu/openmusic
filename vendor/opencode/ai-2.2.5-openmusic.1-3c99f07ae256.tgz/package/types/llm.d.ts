import { Effect, JsonSchema, Schema, Stream } from "effect";
import { Service, canCompact, type CheckpointRequest, type CompactionRequest, type EndpointCompactOptions, type StreamOptions, type TriggerCompactOptions } from "./route/client.js";
import { AIError, LLMEvent, LLMResponse, Message, LanguageModel, SystemPart, type BaseRequest, type CachePolicy, type CompactionCheckpointResponse, type CompactionResponse, type Finish, ToolChoice, type LanguageModelProviderOptions, type GenerationOptionsFields, type LLMRequest, type ToolEntryInput } from "./schema/index.js";
import { type ExecutableTool, type Tool, type ToolSchema } from "./tool.js";
/** Input accepted by `ai.request`, `ai.generate`, `ai.stream` and `ai.compact`. An `LLMRequest` is also a valid input. */
export type LLMRequestInput<Model extends LanguageModel = LanguageModel> = TextRequestFields<Model> & PromptOrMessages;
/** Exactly one of `prompt`, a single user message, or `messages`, the full conversation. */
export type PromptOrMessages = {
    readonly prompt: Message.UserContentInput;
    readonly messages?: never;
} | {
    readonly messages: ReadonlyArray<Message | Message.Input>;
    readonly prompt?: never;
};
interface TextRequestFields<Model extends LanguageModel> extends BaseRequest<Model, NoInfer<LanguageModelProviderOptions<Model>>>, GenerationOptionsFields {
    readonly id?: string;
    readonly system?: string | SystemPart | ReadonlyArray<SystemPart>;
    /** Sent in array order. Pass `tool(...)` values or wire entries such as hosted provider tools. */
    readonly tools?: ReadonlyArray<Tool | ToolEntryInput>;
    readonly toolChoice?: ToolChoice.Input;
    readonly cache?: CachePolicy;
    /** Stable cache affinity for protocols that support provider-managed prompt caching. */
    readonly promptCacheKey?: string;
    /** Emit a `raw` event with each provider frame before the events parsed from it. */
    readonly includeRaw?: boolean;
}
/** An Effect Schema decodes and types `object`; a raw JSON Schema leaves it `unknown`. */
export type OutputSchema = ToolSchema<any> | JsonSchema.JsonSchema;
export type OutputType<S extends OutputSchema> = S extends Schema.Top ? Schema.Schema.Type<S> : unknown;
export type ObjectResponse<T> = LLMResponse & {
    readonly object: T;
};
/** Stream events for a request with `schema`: the `finish` event carries the decoded `object`. */
export type ObjectEvent<T> = Exclude<LLMEvent, Finish> | (Finish & {
    readonly object: T;
});
/** Loop events for a request with `schema`: the loop's `finish` event carries the decoded `object`. */
export type LoopObjectEvent<T> = Exclude<LLMEvent, Finish> | (Finish & {
    readonly object?: T;
});
/** Run one model call. With `schema`, the model must answer through a forced tool call decoded into `object`. */
export declare function generate<const Model extends LanguageModel, S extends OutputSchema>(input: LLMRequestInput<Model> & {
    readonly schema: S;
}, options?: StreamOptions): Effect.Effect<ObjectResponse<OutputType<S>>, AIError, Service>;
export declare function generate<const Model extends LanguageModel>(input: LLMRequestInput<Model>, options?: StreamOptions): Effect.Effect<LLMResponse, AIError, Service>;
/**
 * Stream one model call. The `finish` event carries the assistant `message` and `usage`; with `schema`, also the
 * decoded `object`.
 */
export declare function stream<const Model extends LanguageModel, S extends OutputSchema>(input: LLMRequestInput<Model> & {
    readonly schema: S;
}, options?: StreamOptions): Stream.Stream<ObjectEvent<OutputType<S>>, AIError, Service>;
export declare function stream<const Model extends LanguageModel>(input: LLMRequestInput<Model>, options?: StreamOptions): Stream.Stream<LLMEvent, AIError, Service>;
export type LLMLoopInput<Model extends LanguageModel = LanguageModel> = Omit<TextRequestFields<Model>, "tools"> & PromptOrMessages & {
    readonly tools: ReadonlyArray<ExecutableTool>;
    /** Called after each step that has tool calls; returning `true` ends the loop without running them. */
    readonly until?: (state: {
        readonly steps: ReadonlyArray<LLMResponse>;
    }) => boolean;
};
/**
 * Stream model calls, running the model's tool calls between them, until a step has no client-executed tool calls,
 * hits the output token limit, or `until` returns `true`. Tool calls whose input is not valid JSON get an error result
 * so the model can retry. A forced `toolChoice` applies to the first step only. Each step's `step-start` and `step-finish` carry its step index and usage; one `finish` ends
 * the loop with the final step's reason and `message` and the usage summed across steps. With `schema`, the model ends
 * by calling the hidden answer tool, decoded into `object` on the `finish`.
 */
export declare function loop<const Model extends LanguageModel, S extends OutputSchema>(input: LLMLoopInput<Model> & {
    readonly schema: S;
}, options?: StreamOptions): Stream.Stream<LoopObjectEvent<OutputType<S>>, AIError, Service>;
export declare function loop<const Model extends LanguageModel>(input: LLMLoopInput<Model>, options?: StreamOptions): Stream.Stream<LLMEvent, AIError, Service>;
export { collect, type Collected, type CollectResult } from "./loop.js";
/** Normalize text request input into a plain `LLMRequest`, with `prompt` turned into the one user message. */
export declare const request: <const Model extends LanguageModel>(input: LLMRequestInput<Model>) => LLMRequest<Model>;
/** Compact a text request: a replacement window, or a checkpoint with `mechanism: "trigger"`. */
export declare function compact(input: CheckpointRequest, options: TriggerCompactOptions): Effect.Effect<CompactionCheckpointResponse, AIError, Service>;
export declare function compact(input: CompactionRequest, options?: EndpointCompactOptions): Effect.Effect<CompactionResponse, AIError, Service>;
export { canCompact };
export * as LLM from "./llm.js";
