import { type LLMRequest } from "./schema/messages.js";
/** The requested cache lifetime, for routes that send it as a request-level option instead of on markers. */
export declare const requestTTL: (request: LLMRequest) => `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
export declare const applyCachePolicy: (request: LLMRequest) => LLMRequest;
/** Whether the cache policy places inline markers, which then carry the requested lifetime. */
export declare const placesMarkers: (request: LLMRequest) => boolean;
