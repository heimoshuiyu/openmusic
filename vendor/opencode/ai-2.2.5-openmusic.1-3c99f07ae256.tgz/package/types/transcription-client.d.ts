import { Context } from "effect";
import { MediaClient } from "./media-client.js";
import { type TranscriptionEvent, type TranscriptionRequest, type TranscriptionResponse } from "./transcription.js";
export type Interface = MediaClient.Interface<TranscriptionRequest, TranscriptionEvent, TranscriptionResponse>;
declare const TranscriptionClientService_base: Context.ServiceClass<TranscriptionClientService, "@opencode/TranscriptionClient", Interface>;
export declare class TranscriptionClientService extends TranscriptionClientService_base {
}
export declare const Service: typeof TranscriptionClientService;
export type Service = TranscriptionClientService;
export declare const TranscriptionClient: {
    readonly responseEvents: (response: TranscriptionResponse) => readonly ({
        readonly type: "text-delta";
        readonly delta: string;
    } | {
        readonly type: "segment";
        readonly segment: {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        };
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly text: string;
        readonly segments?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        }[] | undefined;
        readonly words?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
            readonly confidence?: number | undefined;
        }[] | undefined;
        readonly language?: string | undefined;
        readonly durationSeconds?: number | undefined;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
        readonly type: "finish";
    })[];
    readonly layer: import("effect/Layer").Layer<TranscriptionClientService, never, import("./route.js").RequestExecutorService>;
    readonly generate: (request: TranscriptionRequest, options?: import("./generation.js").AwaitOptions) => import("effect/Effect").Effect<TranscriptionResponse, import("./public.js").AIError, TranscriptionClientService>;
    readonly stream: (request: TranscriptionRequest, options?: import("./generation.js").AwaitOptions) => import("effect/Stream").Stream<{
        readonly type: "text-delta";
        readonly delta: string;
    } | {
        readonly type: "segment";
        readonly segment: {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        };
    } | {
        readonly text: string;
        readonly segments?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        }[] | undefined;
        readonly words?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
            readonly confidence?: number | undefined;
        }[] | undefined;
        readonly language?: string | undefined;
        readonly durationSeconds?: number | undefined;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
        readonly type: "finish";
    } | import("./generation.js").Observation, import("./public.js").AIError, TranscriptionClientService>;
    readonly start: (request: TranscriptionRequest) => import("effect/Effect").Effect<import("./generation.js").Generation<TranscriptionResponse>, import("./public.js").AIError, TranscriptionClientService>;
    readonly resume: (model: import("./transcription.js").TranscriptionModel<{
        readonly [x: string]: unknown;
    }>, token: unknown) => import("effect/Effect").Effect<import("./generation.js").Generation<TranscriptionResponse>, import("./public.js").AIError, TranscriptionClientService>;
    readonly Service: typeof TranscriptionClientService;
};
export {};
