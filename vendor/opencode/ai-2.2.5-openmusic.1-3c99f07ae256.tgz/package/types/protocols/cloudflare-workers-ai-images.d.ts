import { ImageModel, ImageResponse, type ImageRequest } from "../image.js";
import { MediaProtocol } from "../route/media-protocol.js";
import type { MediaRoute } from "../route/media.js";
/**
 * Native Run API inputs. Step counts are `steps` on FLUX and Lucid Origin and `num_steps` on the other models;
 * `aspect` and `resolution` lower to `width` and `height`.
 */
export type CloudflareWorkersAIImageOptions = {
    readonly width?: number;
    readonly height?: number;
    readonly seed?: number;
    readonly steps?: number;
    readonly num_steps?: number;
    readonly guidance?: number;
    readonly negative_prompt?: string;
} & Record<string, unknown>;
export type Request = ImageRequest<ImageModel<CloudflareWorkersAIImageOptions>>;
export declare const protocol: MediaProtocol.Inline<Request, ImageResponse>;
export declare const model: (input: MediaRoute.ModelInput) => ImageModel<CloudflareWorkersAIImageOptions>;
export declare const CloudflareWorkersAIImages: {
    readonly protocol: MediaProtocol.Inline<Request, ImageResponse>;
    readonly model: typeof model;
};
