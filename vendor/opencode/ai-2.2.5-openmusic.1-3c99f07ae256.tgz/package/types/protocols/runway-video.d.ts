import { Schema } from "effect";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type OpenString } from "../schema/index.js";
import { VideoModel, VideoResponse, type VideoRequest } from "../video.js";
export declare const DEFAULT_BASE_URL = "https://api.dev.runwayml.com/v1";
/** Every Runway request must pin the API version. */
export declare const API_VERSION = "2024-11-06";
export declare const TEXT_TO_VIDEO_PATH = "/text_to_video";
export declare const IMAGE_TO_VIDEO_PATH = "/image_to_video";
export declare const VIDEO_TO_VIDEO_PATH = "/video_to_video";
export declare const TASKS_PATH = "/tasks";
/**
 * Provider-native options. Common fields lower to Runway's names: `aspect` → `ratio` (Runway expects pixel
 * ratios such as `1280:720` for most models), `durationSeconds` → `duration`, `audio`, `negativePrompt`,
 * `resolution`, `references`, and `frames` → `promptImage`.
 */
export type RunwayVideoOptions = {
    readonly contentModeration?: {
        readonly publicFigureThreshold?: OpenString<"auto" | "low">;
    };
    readonly outputFormat?: OpenString<"mp4" | "prores" | "png_sequence">;
} & Record<string, unknown>;
export type Request = VideoRequest<VideoModel<RunwayVideoOptions>>;
export declare const Token: Schema.Struct<{
    readonly taskID: Schema.String;
}>;
export type Token = Schema.Schema.Type<typeof Token>;
export declare const protocol: MediaProtocol.Queued<Request, VideoResponse, {
    readonly taskID: string;
}>;
export declare const model: (input: MediaRoute.ModelInput) => VideoModel<RunwayVideoOptions>;
export declare const RunwayVideo: {
    readonly protocol: MediaProtocol.Queued<Request, VideoResponse, {
        readonly taskID: string;
    }>;
    readonly model: typeof model;
};
