import { Schema } from "effect";
import { Route } from "../route/client.js";
import { Protocol } from "../route/protocol.js";
import { HttpTransport, type Transport, type TransportPrepareInput } from "../route/transport/index.js";
import { type ProviderOptions } from "../schema/index.js";
import { Lifecycle } from "./utils/lifecycle.js";
export declare const DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta";
/** Caller-facing provider options; unknown keys are accepted and ignored. */
export type OptionsInput = ProviderOptions & typeof Options.Encoded;
export type ProviderOptionsInput = OptionsInput;
declare const Options: Schema.Struct<{
    readonly cachedContent: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.String>, never>>;
    readonly safetySettings: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.$Array<Schema.Struct<{
        readonly category: Schema.declare<import("../schema/options.js").OpenString<"HARM_CATEGORY_CIVIC_INTEGRITY" | "HARM_CATEGORY_DANGEROUS_CONTENT" | "HARM_CATEGORY_HARASSMENT" | "HARM_CATEGORY_HATE_SPEECH" | "HARM_CATEGORY_SEXUALLY_EXPLICIT" | "HARM_CATEGORY_UNSPECIFIED">, import("../schema/options.js").OpenString<"HARM_CATEGORY_CIVIC_INTEGRITY" | "HARM_CATEGORY_DANGEROUS_CONTENT" | "HARM_CATEGORY_HARASSMENT" | "HARM_CATEGORY_HATE_SPEECH" | "HARM_CATEGORY_SEXUALLY_EXPLICIT" | "HARM_CATEGORY_UNSPECIFIED">>;
        readonly threshold: Schema.declare<import("../schema/options.js").OpenString<"BLOCK_LOW_AND_ABOVE" | "BLOCK_MEDIUM_AND_ABOVE" | "BLOCK_NONE" | "BLOCK_ONLY_HIGH" | "HARM_BLOCK_THRESHOLD_UNSPECIFIED" | "OFF">, import("../schema/options.js").OpenString<"BLOCK_LOW_AND_ABOVE" | "BLOCK_MEDIUM_AND_ABOVE" | "BLOCK_NONE" | "BLOCK_ONLY_HIGH" | "HARM_BLOCK_THRESHOLD_UNSPECIFIED" | "OFF">>;
    }>>>, never>>;
    readonly serviceTier: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.declare<import("../schema/options.js").OpenString<"flex" | "priority" | "standard">, import("../schema/options.js").OpenString<"flex" | "priority" | "standard">>>, never>>;
    readonly thinkingConfig: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Struct<{
        readonly thinkingBudget: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
        readonly includeThoughts: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Boolean>, never>>;
        readonly thinkingLevel: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.declare<import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal">, import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal">>>, never>>;
    }>>, never>>;
}>;
declare const GeminiBody: Schema.Struct<{
    cachedContent: Schema.optional<Schema.String>;
    contents: Schema.$Array<Schema.Struct<{
        readonly role: Schema.optional<Schema.NullOr<Schema.Literals<readonly ["user", "model"]>>>;
        readonly parts: Schema.optional<Schema.NullOr<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly text: Schema.String;
            readonly thought: Schema.optional<Schema.NullOr<Schema.Boolean>>;
            readonly thoughtSignature: Schema.optional<Schema.NullOr<Schema.String>>;
        }>, Schema.Struct<{
            readonly inlineData: Schema.Struct<{
                readonly mimeType: Schema.String;
                readonly data: Schema.String;
            }>;
            readonly thoughtSignature: Schema.optional<Schema.NullOr<Schema.String>>;
        }>, Schema.Struct<{
            readonly fileData: Schema.Struct<{
                readonly mimeType: Schema.String;
                readonly fileUri: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly functionCall: Schema.Struct<{
                readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
                readonly name: Schema.String;
                readonly args: Schema.optional<Schema.Unknown>;
            }>;
            readonly thoughtSignature: Schema.optional<Schema.NullOr<Schema.String>>;
        }>, Schema.Struct<{
            readonly functionResponse: Schema.Struct<{
                readonly id: Schema.optional<Schema.String>;
                readonly name: Schema.String;
                readonly response: Schema.Unknown;
                readonly parts: Schema.optional<Schema.$Array<Schema.Struct<{
                    readonly inlineData: Schema.Struct<{
                        readonly mimeType: Schema.String;
                        readonly data: Schema.String;
                    }>;
                    readonly thoughtSignature: Schema.optional<Schema.NullOr<Schema.String>>;
                }>>>;
            }>;
        }>]>>>>;
    }>>;
    labels: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
    safetySettings: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly category: Schema.declare<import("../schema/options.js").OpenString<"HARM_CATEGORY_CIVIC_INTEGRITY" | "HARM_CATEGORY_DANGEROUS_CONTENT" | "HARM_CATEGORY_HARASSMENT" | "HARM_CATEGORY_HATE_SPEECH" | "HARM_CATEGORY_SEXUALLY_EXPLICIT" | "HARM_CATEGORY_UNSPECIFIED">, import("../schema/options.js").OpenString<"HARM_CATEGORY_CIVIC_INTEGRITY" | "HARM_CATEGORY_DANGEROUS_CONTENT" | "HARM_CATEGORY_HARASSMENT" | "HARM_CATEGORY_HATE_SPEECH" | "HARM_CATEGORY_SEXUALLY_EXPLICIT" | "HARM_CATEGORY_UNSPECIFIED">>;
        readonly threshold: Schema.declare<import("../schema/options.js").OpenString<"BLOCK_LOW_AND_ABOVE" | "BLOCK_MEDIUM_AND_ABOVE" | "BLOCK_NONE" | "BLOCK_ONLY_HIGH" | "HARM_BLOCK_THRESHOLD_UNSPECIFIED" | "OFF">, import("../schema/options.js").OpenString<"BLOCK_LOW_AND_ABOVE" | "BLOCK_MEDIUM_AND_ABOVE" | "BLOCK_NONE" | "BLOCK_ONLY_HIGH" | "HARM_BLOCK_THRESHOLD_UNSPECIFIED" | "OFF">>;
    }>>>;
    serviceTier: Schema.optional<Schema.String>;
    systemInstruction: Schema.optional<Schema.Struct<{
        readonly parts: Schema.$Array<Schema.Struct<{
            readonly text: Schema.String;
        }>>;
    }>>;
    tools: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly functionDeclarations: Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly description: Schema.String;
            readonly parametersJsonSchema: Schema.$Record<Schema.String, Schema.Unknown>;
        }>>;
    }>>>;
    toolConfig: Schema.optional<Schema.Struct<{
        readonly functionCallingConfig: Schema.Struct<{
            readonly mode: Schema.Literals<readonly ["AUTO", "NONE", "ANY"]>;
            readonly allowedFunctionNames: Schema.optional<Schema.$Array<Schema.String>>;
        }>;
    }>>;
    generationConfig: Schema.optional<Schema.Struct<{
        readonly maxOutputTokens: Schema.optional<Schema.Number>;
        readonly temperature: Schema.optional<Schema.Number>;
        readonly topP: Schema.optional<Schema.Number>;
        readonly topK: Schema.optional<Schema.Number>;
        readonly frequencyPenalty: Schema.optional<Schema.Number>;
        readonly presencePenalty: Schema.optional<Schema.Number>;
        readonly seed: Schema.optional<Schema.Number>;
        readonly stopSequences: Schema.optional<Schema.$Array<Schema.String>>;
        readonly thinkingConfig: Schema.optional<Schema.Struct<{
            readonly thinkingBudget: Schema.optional<Schema.Number>;
            readonly includeThoughts: Schema.optional<Schema.Boolean>;
            readonly thinkingLevel: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal">, import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal">>>;
        }>>;
    }>>;
    continuationToken: Schema.optional<Schema.String>;
}>;
export type GeminiBody = Schema.Schema.Type<typeof GeminiBody>;
declare const GeminiUsage: Schema.Struct<{
    readonly cost: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Finite>, never>>;
    readonly cachedContentTokenCount: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly thoughtsTokenCount: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly promptTokenCount: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly toolUsePromptTokenCount: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly candidatesTokenCount: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly totalTokenCount: Schema.optional<Schema.NullOr<Schema.Number>>;
}>;
type GeminiUsage = Schema.Schema.Type<typeof GeminiUsage>;
declare const GeminiPromptFeedback: Schema.StructWithRest<Schema.Struct<{
    readonly blockReason: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly blockReasonMessage: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly safetyRatings: Schema.optional<Schema.NullOr<Schema.Unknown>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
type GeminiPromptFeedback = Schema.Schema.Type<typeof GeminiPromptFeedback>;
interface ParserState {
    readonly route: string;
    readonly providerMetadataKey: string;
    readonly finishReason?: string;
    readonly hasToolCalls: boolean;
    readonly promptFeedback?: GeminiPromptFeedback;
    readonly usage?: GeminiUsage;
    /** Usage of the earlier requests of a response Gemini continued across requests. */
    readonly continuedUsage?: ReadonlyArray<GeminiUsage>;
    readonly lifecycle: Lifecycle.State;
    readonly reasoningSignature?: string;
    readonly textSignature?: string;
    readonly reasoningId?: string;
    readonly textId?: string;
    readonly nextReasoningId: number;
    readonly nextTextId: number;
    readonly seenCallIds?: ReadonlySet<string>;
}
/** Marks where the transport starts another request for the same response; provider JSON can never match it. */
declare class NextRequest {
}
export interface Prepared {
    readonly http: HttpTransport.HttpPrepared<string>;
    readonly input: TransportPrepareInput<GeminiBody>;
}
/**
 * SSE transport that continues responses Gemini splits across requests. Chunks carry `continuationToken` checkpoints,
 * and a request that reaches its output cap finishes with `CONTINUATION`. The transport resends the original body with
 * the latest token, which also resumes a request that ended or dropped before finishing.
 */
export declare const transport: Transport<GeminiBody, Prepared, unknown>;
/**
 * The Gemini protocol — request body construction, body schema, and the
 * streaming-event state machine shared by Google AI Studio and Vertex Gemini.
 */
export declare const protocol: Protocol<{
    readonly cachedContent?: string | undefined;
    readonly contents: readonly {
        readonly role?: "model" | "user" | null | undefined;
        readonly parts?: readonly ({
            readonly fileData: {
                readonly mimeType: string;
                readonly fileUri: string;
            };
        } | {
            readonly functionResponse: {
                readonly id?: string | undefined;
                readonly name: string;
                readonly response: unknown;
                readonly parts?: readonly {
                    readonly inlineData: {
                        readonly mimeType: string;
                        readonly data: string;
                    };
                    readonly thoughtSignature?: string | null | undefined;
                }[] | undefined;
            };
        } | {
            readonly text: string;
            readonly thought?: boolean | null | undefined;
            readonly thoughtSignature?: string | null | undefined;
        } | {
            readonly inlineData: {
                readonly mimeType: string;
                readonly data: string;
            };
            readonly thoughtSignature?: string | null | undefined;
        } | {
            readonly functionCall: {
                readonly id?: string | null | undefined;
                readonly name: string;
                readonly args?: unknown;
            };
            readonly thoughtSignature?: string | null | undefined;
        })[] | null | undefined;
    }[];
    readonly labels?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safetySettings?: readonly {
        readonly category: import("../schema/options.js").OpenString<"HARM_CATEGORY_CIVIC_INTEGRITY" | "HARM_CATEGORY_DANGEROUS_CONTENT" | "HARM_CATEGORY_HARASSMENT" | "HARM_CATEGORY_HATE_SPEECH" | "HARM_CATEGORY_SEXUALLY_EXPLICIT" | "HARM_CATEGORY_UNSPECIFIED">;
        readonly threshold: import("../schema/options.js").OpenString<"BLOCK_LOW_AND_ABOVE" | "BLOCK_MEDIUM_AND_ABOVE" | "BLOCK_NONE" | "BLOCK_ONLY_HIGH" | "HARM_BLOCK_THRESHOLD_UNSPECIFIED" | "OFF">;
    }[] | undefined;
    readonly serviceTier?: string | undefined;
    readonly systemInstruction?: {
        readonly parts: readonly {
            readonly text: string;
        }[];
    } | undefined;
    readonly tools?: readonly {
        readonly functionDeclarations: readonly {
            readonly name: string;
            readonly description: string;
            readonly parametersJsonSchema: {
                readonly [x: string]: unknown;
            };
        }[];
    }[] | undefined;
    readonly toolConfig?: {
        readonly functionCallingConfig: {
            readonly mode: "ANY" | "AUTO" | "NONE";
            readonly allowedFunctionNames?: readonly string[] | undefined;
        };
    } | undefined;
    readonly generationConfig?: {
        readonly maxOutputTokens?: number | undefined;
        readonly temperature?: number | undefined;
        readonly topP?: number | undefined;
        readonly topK?: number | undefined;
        readonly frequencyPenalty?: number | undefined;
        readonly presencePenalty?: number | undefined;
        readonly seed?: number | undefined;
        readonly stopSequences?: readonly string[] | undefined;
        readonly thinkingConfig?: {
            readonly thinkingBudget?: number | undefined;
            readonly includeThoughts?: boolean | undefined;
            readonly thinkingLevel?: import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal"> | undefined;
        } | undefined;
    } | undefined;
    readonly continuationToken?: string | undefined;
}, NextRequest | {
    readonly error?: {
        readonly [x: string]: unknown;
        readonly code?: number | undefined;
        readonly message?: string | undefined;
        readonly status?: string | undefined;
    } | undefined;
    readonly candidates?: readonly {
        readonly content?: {
            readonly role?: "model" | "user" | null | undefined;
            readonly parts?: readonly unknown[] | null | undefined;
        } | null | undefined;
        readonly finishReason?: string | null | undefined;
    }[] | null | undefined;
    readonly promptFeedback?: {
        readonly [x: string]: unknown;
        readonly blockReason?: string | null | undefined;
        readonly blockReasonMessage?: string | null | undefined;
        readonly safetyRatings?: unknown;
    } | null | undefined;
    readonly usageMetadata?: {
        readonly cost?: number | undefined;
        readonly cachedContentTokenCount?: number | null | undefined;
        readonly thoughtsTokenCount?: number | null | undefined;
        readonly promptTokenCount?: number | null | undefined;
        readonly toolUsePromptTokenCount?: number | null | undefined;
        readonly candidatesTokenCount?: number | null | undefined;
        readonly totalTokenCount?: number | null | undefined;
    } | null | undefined;
}, NextRequest | {
    readonly error?: {
        readonly [x: string]: unknown;
        readonly code?: number | undefined;
        readonly message?: string | undefined;
        readonly status?: string | undefined;
    } | undefined;
    readonly candidates?: readonly {
        readonly content?: {
            readonly role?: "model" | "user" | null | undefined;
            readonly parts?: readonly unknown[] | null | undefined;
        } | null | undefined;
        readonly finishReason?: string | null | undefined;
    }[] | null | undefined;
    readonly promptFeedback?: {
        readonly [x: string]: unknown;
        readonly blockReason?: string | null | undefined;
        readonly blockReasonMessage?: string | null | undefined;
        readonly safetyRatings?: unknown;
    } | null | undefined;
    readonly usageMetadata?: {
        readonly cost?: number | undefined;
        readonly cachedContentTokenCount?: number | null | undefined;
        readonly thoughtsTokenCount?: number | null | undefined;
        readonly promptTokenCount?: number | null | undefined;
        readonly toolUsePromptTokenCount?: number | null | undefined;
        readonly candidatesTokenCount?: number | null | undefined;
        readonly totalTokenCount?: number | null | undefined;
    } | null | undefined;
}, ParserState>;
export declare const route: Route<{
    readonly cachedContent?: string | undefined;
    readonly contents: readonly {
        readonly role?: "model" | "user" | null | undefined;
        readonly parts?: readonly ({
            readonly fileData: {
                readonly mimeType: string;
                readonly fileUri: string;
            };
        } | {
            readonly functionResponse: {
                readonly id?: string | undefined;
                readonly name: string;
                readonly response: unknown;
                readonly parts?: readonly {
                    readonly inlineData: {
                        readonly mimeType: string;
                        readonly data: string;
                    };
                    readonly thoughtSignature?: string | null | undefined;
                }[] | undefined;
            };
        } | {
            readonly text: string;
            readonly thought?: boolean | null | undefined;
            readonly thoughtSignature?: string | null | undefined;
        } | {
            readonly inlineData: {
                readonly mimeType: string;
                readonly data: string;
            };
            readonly thoughtSignature?: string | null | undefined;
        } | {
            readonly functionCall: {
                readonly id?: string | null | undefined;
                readonly name: string;
                readonly args?: unknown;
            };
            readonly thoughtSignature?: string | null | undefined;
        })[] | null | undefined;
    }[];
    readonly labels?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safetySettings?: readonly {
        readonly category: import("../schema/options.js").OpenString<"HARM_CATEGORY_CIVIC_INTEGRITY" | "HARM_CATEGORY_DANGEROUS_CONTENT" | "HARM_CATEGORY_HARASSMENT" | "HARM_CATEGORY_HATE_SPEECH" | "HARM_CATEGORY_SEXUALLY_EXPLICIT" | "HARM_CATEGORY_UNSPECIFIED">;
        readonly threshold: import("../schema/options.js").OpenString<"BLOCK_LOW_AND_ABOVE" | "BLOCK_MEDIUM_AND_ABOVE" | "BLOCK_NONE" | "BLOCK_ONLY_HIGH" | "HARM_BLOCK_THRESHOLD_UNSPECIFIED" | "OFF">;
    }[] | undefined;
    readonly serviceTier?: string | undefined;
    readonly systemInstruction?: {
        readonly parts: readonly {
            readonly text: string;
        }[];
    } | undefined;
    readonly tools?: readonly {
        readonly functionDeclarations: readonly {
            readonly name: string;
            readonly description: string;
            readonly parametersJsonSchema: {
                readonly [x: string]: unknown;
            };
        }[];
    }[] | undefined;
    readonly toolConfig?: {
        readonly functionCallingConfig: {
            readonly mode: "ANY" | "AUTO" | "NONE";
            readonly allowedFunctionNames?: readonly string[] | undefined;
        };
    } | undefined;
    readonly generationConfig?: {
        readonly maxOutputTokens?: number | undefined;
        readonly temperature?: number | undefined;
        readonly topP?: number | undefined;
        readonly topK?: number | undefined;
        readonly frequencyPenalty?: number | undefined;
        readonly presencePenalty?: number | undefined;
        readonly seed?: number | undefined;
        readonly stopSequences?: readonly string[] | undefined;
        readonly thinkingConfig?: {
            readonly thinkingBudget?: number | undefined;
            readonly includeThoughts?: boolean | undefined;
            readonly thinkingLevel?: import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal"> | undefined;
        } | undefined;
    } | undefined;
    readonly continuationToken?: string | undefined;
}, Prepared, import("../route/client.js").CompactionOperations | undefined>;
export * as Gemini from "./gemini.js";
