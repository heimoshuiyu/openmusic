import { Schema } from "effect";
import { ImageModel, type ImageRequest } from "../image.js";
import { Media } from "../media.js";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type OpenString } from "../schema/index.js";
export declare const DEFAULT_BASE_URL = "https://api.openai.com/v1";
export declare const PATH = "/images/generations";
export declare const EDIT_PATH = "/images/edits";
/** Provider-native options. Common fields (`n`, `aspect`, `resolution`, `images`) live on the request. */
export type OpenAIImageOptions = {
    /** Exact `WIDTHxHEIGHT` or `auto`; it replaces `aspect` and `resolution`, so setting both fails. */
    readonly size?: OpenString<"auto" | "1024x1024" | "1536x1024" | "1024x1536">;
    readonly outputFormat?: OpenString<"png" | "jpeg" | "webp">;
    /** Inpainting mask for the first input image. */
    readonly mask?: Media.Asset;
    readonly quality?: OpenString<"auto" | "low" | "medium" | "high" | "standard" | "hd">;
    readonly background?: OpenString<"auto" | "opaque" | "transparent">;
    readonly moderation?: OpenString<"auto" | "low">;
    readonly outputCompression?: number;
    /** Previews sent before the final image when streaming (default 2); ignored by `Image.generate`. */
    readonly partialImages?: number;
} & Record<string, unknown>;
export type Request = ImageRequest<ImageModel<OpenAIImageOptions>>;
declare const Usage: Schema.Struct<{
    readonly input_tokens: Schema.optional<Schema.Number>;
    readonly output_tokens: Schema.optional<Schema.Number>;
    readonly total_tokens: Schema.optional<Schema.Number>;
    readonly input_tokens_details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly output_tokens_details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
}>;
/** `generate` reads the whole JSON response as one frame. */
type Frame = string | {
    readonly document: string;
};
interface State {
    readonly completed: number;
    readonly format?: string;
    readonly size?: string;
    readonly quality?: string;
    readonly background?: string;
    readonly usage?: Schema.Schema.Type<typeof Usage>;
}
/** The body fields `aspect` and `resolution` lower to; gateways that read other fields than `size` pass their own. */
export type OpenAIImageSizing = (request: Request) => Record<string, unknown> | undefined;
/**
 * How input images travel. `edits` is OpenAI's `/images/edits`, uploading owned bytes as multipart; `json-edits` sends
 * every edit there as JSON with data URLs, for hosts that reject multipart (the ChatGPT backend); `references` keeps
 * every request on `/images/generations` and lists them as `input_references`, for gateways without an edits endpoint
 * (OpenRouter).
 */
export type OpenAIImageInput = "edits" | "json-edits" | "references";
export declare const protocol: MediaProtocol.Streamed<Request, {
    readonly type: "image-partial";
    readonly index: number;
    readonly image: Media.Asset;
} | {
    readonly type: "image";
    readonly index: number;
    readonly image: Media.Asset;
} | {
    readonly type: "generation-queued";
    readonly id: string;
    readonly position?: number | undefined;
} | {
    readonly type: "generation-progress";
    readonly id: string;
    readonly progress?: number | undefined;
} | {
    readonly type: "finish";
    readonly usage?: {
        readonly type: "seconds";
        readonly seconds: number;
    } | {
        readonly type: "characters";
        readonly characters: number;
    } | {
        readonly type: "credits";
        readonly credits: number;
    } | {
        readonly type: "compute";
        readonly seconds: number;
    } | {
        readonly type: "tokens";
        readonly input?: number | undefined;
        readonly output?: number | undefined;
        readonly total?: number | undefined;
        readonly details?: {
            readonly [x: string]: unknown;
        } | undefined;
    } | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
}, Frame, State>;
/**
 * `provider` attributes models, refs, and metadata to an OpenAI-compatible host; it defaults to `openai`. `sizing`
 * replaces the `size` that `aspect` and `resolution` lower to, and `imageInput` how input images are sent.
 */
export declare const model: (input: MediaRoute.ModelInput & {
    readonly provider?: string;
    readonly sizing?: OpenAIImageSizing;
    readonly imageInput?: OpenAIImageInput;
}) => ImageModel<OpenAIImageOptions>;
export declare const OpenAIImages: {
    readonly protocol: MediaProtocol.Streamed<Request, {
        readonly type: "image-partial";
        readonly index: number;
        readonly image: Media.Asset;
    } | {
        readonly type: "image";
        readonly index: number;
        readonly image: Media.Asset;
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly type: "finish";
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, Frame, State>;
    readonly model: typeof model;
    readonly pixelSize: OpenAIImageSizing;
};
export {};
