import { ToolDefinition, type Freeform, type LLMEvent, type LLMRequest, type ProviderMetadata } from "../schema/index.js";
import { ToolStream } from "./utils/tool-stream.js";
export interface Custom {
    /** The tool's one required string parameter, which the raw text fills. */
    readonly field: string;
    readonly format: Freeform;
}
/** How a tool goes out: a custom tool when it declares `freeform` with one required string parameter. */
export declare const resolve: (tool: ToolDefinition) => Custom | undefined;
/** Custom tools in this request, by flattened tool name. */
export declare const tools: (request: LLMRequest) => ReadonlyMap<string, Custom>;
/** The format's grammar, or `undefined` for unconstrained text. */
export declare const grammar: (format: Freeform) => {
    syntax: "lark" | "regex";
    definition: string;
} | undefined;
/** Raw text replayed for a past call: its field, or the whole input as JSON when the field is not a string. */
export declare const toRaw: (custom: Custom, input: unknown) => string;
/** JSON arguments for a raw call. A call to an undeclared custom tool fills `input`. */
export declare const fromRaw: (custom: Custom | undefined, raw: string) => string;
/** The opening fragment, `{"field":"`, followed by the escaped first text. */
export declare const streamStart: (custom: Custom | undefined, raw?: string) => string;
export declare const streamDelta: (raw: string) => string;
/**
 * Close the JSON fragment of each open custom call. With a `final` raw input, a call only closes when its fragments
 * decode to it, so an authoritative final input that disagrees replaces the streamed one instead.
 */
export declare const close: <K extends string | number>(tools: ToolStream.State<K>, keys: Iterable<K>, final?: {
    readonly custom: Custom | undefined;
    readonly raw: string;
}) => {
    readonly tools: ToolStream.State<K>;
    readonly events: ReadonlyArray<LLMEvent>;
};
/** Provider metadata marking a call that arrived as a custom tool call. */
export declare const metadata: (itemId: string, custom: boolean) => {
    itemId: string;
    custom: boolean;
} | {
    itemId: string;
};
/**
 * Whether a replayed call keeps its item id: only when it goes out as the type it arrived as, since OpenAI item ids
 * name their type (`fc_`, `ctc_`). The `call_id` always survives.
 */
export declare const keepsItemID: (providerMetadata: ProviderMetadata | undefined, key: string, custom: boolean) => boolean;
export * as OpenAIFreeform from "./openai-freeform.js";
