import { Schema } from "effect";
import { Framing } from "../route/framing.js";
export declare const Frame: Schema.StructWithRest<Schema.Struct<{
    readonly rawBody: Schema.String;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
export type Frame = typeof Frame.Type;
/**
 * AWS event-stream framing for Bedrock Converse. Each frame is decoded by
 * `@smithy/eventstream-codec` (length + header + payload + CRC) and rewrapped
 * under its `:event-type` header so the chunk schema can match the JSON
 * payload directly.
 */
export declare const framing: (route: string) => Framing.Definition<Frame>;
export * as BedrockEventStream from "./bedrock-event-stream.js";
