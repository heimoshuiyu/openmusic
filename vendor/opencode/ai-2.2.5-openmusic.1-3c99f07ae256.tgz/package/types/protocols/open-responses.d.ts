import { Effect, Schema } from "effect";
import { HttpTransport } from "../route/transport/index.js";
import { Protocol } from "../route/protocol.js";
import { AIError, LLMEvent, Usage, type LLMRequest, type MediaPart, type ProviderMetadata, type ToolDefinition } from "../schema/index.js";
import type { Media } from "../media.js";
import { OpenResponsesOptions } from "./utils/open-responses-options.js";
import { Lifecycle } from "./utils/lifecycle.js";
import { ToolStream } from "./utils/tool-stream.js";
import { OpenAIFreeform } from "./openai-freeform.js";
export declare const PATH = "/responses";
export declare const OpenResponsesInputText: Schema.Struct<{
    readonly type: Schema.tag<"input_text">;
    readonly text: Schema.String;
}>;
export declare const OpenResponsesInputImage: Schema.Struct<{
    readonly type: Schema.tag<"input_image">;
    readonly image_url: Schema.String;
    readonly detail: Schema.optional<Schema.String>;
}>;
export declare const OpenResponsesInputFile: Schema.Struct<{
    readonly type: Schema.tag<"input_file">;
    readonly filename: Schema.optional<Schema.String>;
    readonly detail: Schema.optional<Schema.String>;
    readonly file_data: Schema.optional<Schema.String>;
    readonly file_url: Schema.optional<Schema.String>;
}>;
declare const MediaInput: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.tag<"input_image">;
    readonly image_url: Schema.String;
    readonly detail: Schema.optional<Schema.String>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"input_audio">;
    readonly input_audio: Schema.Struct<{
        readonly data: Schema.String;
        readonly format: Schema.String;
    }>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"input_file">;
    readonly filename: Schema.optional<Schema.String>;
    readonly detail: Schema.optional<Schema.String>;
    readonly file_data: Schema.optional<Schema.String>;
    readonly file_url: Schema.optional<Schema.String>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"input_video">;
    readonly video_url: Schema.String;
}>]>;
export type MediaInput = Schema.Schema.Type<typeof MediaInput>;
export declare const OpenResponsesOutputText: Schema.Struct<{
    readonly type: Schema.tag<"output_text">;
    readonly text: Schema.String;
}>;
export declare const MessagePhase: Schema.NullOr<Schema.Literals<readonly ["commentary", "final_answer"]>>;
type MessagePhase = Schema.Schema.Type<typeof MessagePhase>;
export declare const MessageMetadata: Schema.Struct<{
    readonly itemId: Schema.optional<Schema.String>;
    readonly status: Schema.optional<Schema.String>;
    readonly phase: Schema.optional<Schema.NullOr<Schema.Literals<readonly ["commentary", "final_answer"]>>>;
}>;
export declare const OpenResponsesReasoningItem: Schema.Struct<{
    readonly type: Schema.tag<"reasoning">;
    readonly id: Schema.optionalKey<Schema.String>;
    readonly summary: Schema.$Array<Schema.Struct<{
        readonly type: Schema.tag<"summary_text">;
        readonly text: Schema.String;
    }>>;
    readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
}>;
export declare const HostedToolItem: Schema.Union<readonly [Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.tag<"web_search_call">;
    readonly id: Schema.String;
    readonly status: Schema.optional<Schema.String>;
    readonly action: Schema.optional<Schema.NullOr<Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.tag<"file_search_call">;
    readonly id: Schema.String;
    readonly status: Schema.optional<Schema.String>;
    readonly queries: Schema.optional<Schema.$Array<Schema.String>>;
    readonly results: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.tag<"code_interpreter_call">;
    readonly id: Schema.String;
    readonly status: Schema.optional<Schema.String>;
    readonly code: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly container_id: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly outputs: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.tag<"mcp_call">;
    readonly id: Schema.String;
    readonly status: Schema.optional<Schema.String>;
    readonly server_label: Schema.optional<Schema.String>;
    readonly name: Schema.optional<Schema.String>;
    readonly arguments: Schema.optional<Schema.String>;
    readonly output: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly error: Schema.optional<Schema.Unknown>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>;
export type HostedToolItem = Schema.Schema.Type<typeof HostedToolItem>;
export declare const CompactionItem: Schema.Struct<{
    readonly type: Schema.Literal<"compaction">;
    readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly encrypted_content: Schema.String;
}>;
export declare const ConfigurationUpdate: Schema.Struct<{
    readonly type: Schema.Literal<"configuration_update">;
    readonly reasoning: Schema.Struct<{
        readonly effort: Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>;
    }>;
}>;
export type ConfigurationUpdate = Schema.Schema.Type<typeof ConfigurationUpdate>;
export declare const HostedToolReplay: Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.String;
    readonly id: Schema.String;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
export type HostedToolReplayItem = Schema.Schema.Type<typeof HostedToolReplay>;
export declare const InputItem: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"compaction">;
    readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly encrypted_content: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"configuration_update">;
    readonly reasoning: Schema.Struct<{
        readonly effort: Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>;
    }>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"message">;
    readonly role: Schema.tag<"system">;
    readonly content: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.tag<"message">;
    readonly role: Schema.tag<"developer">;
    readonly content: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.tag<"message">;
    readonly role: Schema.tag<"user">;
    readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"input_text">;
        readonly text: Schema.String;
    }>, Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"input_image">;
        readonly image_url: Schema.String;
        readonly detail: Schema.optional<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"input_audio">;
        readonly input_audio: Schema.Struct<{
            readonly data: Schema.String;
            readonly format: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"input_file">;
        readonly filename: Schema.optional<Schema.String>;
        readonly detail: Schema.optional<Schema.String>;
        readonly file_data: Schema.optional<Schema.String>;
        readonly file_url: Schema.optional<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"input_video">;
        readonly video_url: Schema.String;
    }>]>]>>;
    readonly id: Schema.optional<Schema.String>;
    readonly status: Schema.optional<Schema.String>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"message">;
    readonly id: Schema.optionalKey<Schema.String>;
    readonly role: Schema.tag<"assistant">;
    readonly content: Schema.$Array<Schema.Struct<{
        readonly type: Schema.tag<"output_text">;
        readonly text: Schema.String;
    }>>;
    readonly phase: Schema.optionalKey<Schema.NullOr<Schema.Literals<readonly ["commentary", "final_answer"]>>>;
    readonly status: Schema.optional<Schema.String>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"reasoning">;
    readonly id: Schema.optionalKey<Schema.String>;
    readonly summary: Schema.$Array<Schema.Struct<{
        readonly type: Schema.tag<"summary_text">;
        readonly text: Schema.String;
    }>>;
    readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"function_call">;
    readonly id: Schema.optionalKey<Schema.String>;
    readonly call_id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly arguments: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literals<readonly ["function_call_output", "custom_tool_call_output"]>;
    readonly call_id: Schema.String;
    readonly output: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"input_text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"input_image">;
        readonly image_url: Schema.String;
        readonly detail: Schema.optional<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"input_audio">;
        readonly input_audio: Schema.Struct<{
            readonly data: Schema.String;
            readonly format: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"input_file">;
        readonly filename: Schema.optional<Schema.String>;
        readonly detail: Schema.optional<Schema.String>;
        readonly file_data: Schema.optional<Schema.String>;
        readonly file_url: Schema.optional<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"input_video">;
        readonly video_url: Schema.String;
    }>]>>]>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"custom_tool_call">;
    readonly id: Schema.optionalKey<Schema.String>;
    readonly call_id: Schema.String;
    readonly name: Schema.String;
    readonly input: Schema.String;
}>, Schema.Union<readonly [Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.tag<"web_search_call">;
    readonly id: Schema.String;
    readonly status: Schema.optional<Schema.String>;
    readonly action: Schema.optional<Schema.NullOr<Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.tag<"file_search_call">;
    readonly id: Schema.String;
    readonly status: Schema.optional<Schema.String>;
    readonly queries: Schema.optional<Schema.$Array<Schema.String>>;
    readonly results: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.tag<"code_interpreter_call">;
    readonly id: Schema.String;
    readonly status: Schema.optional<Schema.String>;
    readonly code: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly container_id: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly outputs: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.tag<"mcp_call">;
    readonly id: Schema.String;
    readonly status: Schema.optional<Schema.String>;
    readonly server_label: Schema.optional<Schema.String>;
    readonly name: Schema.optional<Schema.String>;
    readonly arguments: Schema.optional<Schema.String>;
    readonly output: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly error: Schema.optional<Schema.Unknown>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>, Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.String;
    readonly id: Schema.String;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>;
export declare const Tool: Schema.Struct<{
    readonly type: Schema.tag<"function">;
    readonly name: Schema.String;
    readonly description: Schema.String;
    readonly parameters: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly strict: Schema.optional<Schema.Boolean>;
}>;
export declare const CustomTool: Schema.Struct<{
    readonly type: Schema.tag<"custom">;
    readonly name: Schema.String;
    readonly description: Schema.String;
    readonly format: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"text">;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"grammar">;
        readonly syntax: Schema.Literals<readonly ["lark", "regex"]>;
        readonly definition: Schema.String;
    }>]>;
}>;
export declare const HostedTool: Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.String;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
export type HostedTool = Schema.Schema.Type<typeof HostedTool>;
export declare const ToolChoice: Schema.Union<readonly [Schema.Literals<readonly ["auto", "none", "required"]>, Schema.Struct<{
    readonly type: Schema.Literals<readonly ["function", "custom"]>;
    readonly name: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.tag<"allowed_tools">;
    readonly mode: Schema.Literals<readonly ["auto", "none", "required"]>;
    readonly tools: Schema.$Array<Schema.Struct<{
        readonly type: Schema.Literals<readonly ["function", "custom"]>;
        readonly name: Schema.String;
    }>>;
}>]>;
export declare const coreFields: {
    model: Schema.String;
    input: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"compaction">;
        readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly encrypted_content: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"configuration_update">;
        readonly reasoning: Schema.Struct<{
            readonly effort: Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly role: Schema.tag<"system">;
        readonly content: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly role: Schema.tag<"developer">;
        readonly content: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly role: Schema.tag<"user">;
        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"input_text">;
            readonly text: Schema.String;
        }>, Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"input_image">;
            readonly image_url: Schema.String;
            readonly detail: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_file">;
            readonly filename: Schema.optional<Schema.String>;
            readonly detail: Schema.optional<Schema.String>;
            readonly file_data: Schema.optional<Schema.String>;
            readonly file_url: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_video">;
            readonly video_url: Schema.String;
        }>]>]>>;
        readonly id: Schema.optional<Schema.String>;
        readonly status: Schema.optional<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly role: Schema.tag<"assistant">;
        readonly content: Schema.$Array<Schema.Struct<{
            readonly type: Schema.tag<"output_text">;
            readonly text: Schema.String;
        }>>;
        readonly phase: Schema.optionalKey<Schema.NullOr<Schema.Literals<readonly ["commentary", "final_answer"]>>>;
        readonly status: Schema.optional<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"reasoning">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly summary: Schema.$Array<Schema.Struct<{
            readonly type: Schema.tag<"summary_text">;
            readonly text: Schema.String;
        }>>;
        readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"function_call">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly call_id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly arguments: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literals<readonly ["function_call_output", "custom_tool_call_output"]>;
        readonly call_id: Schema.String;
        readonly output: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"input_text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_image">;
            readonly image_url: Schema.String;
            readonly detail: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_file">;
            readonly filename: Schema.optional<Schema.String>;
            readonly detail: Schema.optional<Schema.String>;
            readonly file_data: Schema.optional<Schema.String>;
            readonly file_url: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_video">;
            readonly video_url: Schema.String;
        }>]>>]>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom_tool_call">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly call_id: Schema.String;
        readonly name: Schema.String;
        readonly input: Schema.String;
    }>, Schema.Union<readonly [Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"web_search_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly action: Schema.optional<Schema.NullOr<Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"file_search_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly queries: Schema.optional<Schema.$Array<Schema.String>>;
        readonly results: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"code_interpreter_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly code: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly container_id: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly outputs: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"mcp_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly server_label: Schema.optional<Schema.String>;
        readonly name: Schema.optional<Schema.String>;
        readonly arguments: Schema.optional<Schema.String>;
        readonly output: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly error: Schema.optional<Schema.Unknown>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.String;
        readonly id: Schema.String;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>>;
    instructions: Schema.optional<Schema.String>;
    tools: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"function">;
        readonly name: Schema.String;
        readonly description: Schema.String;
        readonly parameters: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly strict: Schema.optional<Schema.Boolean>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom">;
        readonly name: Schema.String;
        readonly description: Schema.String;
        readonly format: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"text">;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"grammar">;
            readonly syntax: Schema.Literals<readonly ["lark", "regex"]>;
            readonly definition: Schema.String;
        }>]>;
    }>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.String;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>>>;
    tool_choice: Schema.optional<Schema.Union<readonly [Schema.Literals<readonly ["auto", "none", "required"]>, Schema.Struct<{
        readonly type: Schema.Literals<readonly ["function", "custom"]>;
        readonly name: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"allowed_tools">;
        readonly mode: Schema.Literals<readonly ["auto", "none", "required"]>;
        readonly tools: Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literals<readonly ["function", "custom"]>;
            readonly name: Schema.String;
        }>>;
    }>]>>;
    store: Schema.optional<Schema.Boolean>;
    metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
    safety_identifier: Schema.optional<Schema.String>;
    stream_options: Schema.optional<Schema.Struct<{
        readonly include_obfuscation: Schema.optional<Schema.Boolean>;
    }>>;
    top_logprobs: Schema.optional<Schema.Int>;
    truncation: Schema.optional<Schema.Literals<readonly ["auto", "disabled"]>>;
    service_tier: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority">, import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority">>>;
    prompt_cache_key: Schema.optional<Schema.String>;
    include: Schema.optional<Schema.$Array<Schema.declare<import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">, import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">>>>;
    reasoning: Schema.optional<Schema.Struct<{
        readonly effort: Schema.optional<Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>>;
        readonly summary: Schema.optional<Schema.Literals<readonly ["auto", "concise", "detailed"]>>;
    }>>;
    text: Schema.optional<Schema.Struct<{
        readonly verbosity: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"high" | "low" | "medium">, import("../schema/options.js").OpenString<"high" | "low" | "medium">>>;
    }>>;
    max_output_tokens: Schema.optional<Schema.Number>;
    max_tool_calls: Schema.optional<Schema.Int>;
    parallel_tool_calls: Schema.optional<Schema.Boolean>;
    temperature: Schema.optional<Schema.Number>;
    top_p: Schema.optional<Schema.Number>;
    presence_penalty: Schema.optional<Schema.Number>;
    frequency_penalty: Schema.optional<Schema.Number>;
};
export declare const OpenResponsesBody: Schema.Struct<{
    readonly model: Schema.String;
    readonly input: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"compaction">;
        readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly encrypted_content: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"configuration_update">;
        readonly reasoning: Schema.Struct<{
            readonly effort: Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly role: Schema.tag<"system">;
        readonly content: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly role: Schema.tag<"developer">;
        readonly content: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly role: Schema.tag<"user">;
        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"input_text">;
            readonly text: Schema.String;
        }>, Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"input_image">;
            readonly image_url: Schema.String;
            readonly detail: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_file">;
            readonly filename: Schema.optional<Schema.String>;
            readonly detail: Schema.optional<Schema.String>;
            readonly file_data: Schema.optional<Schema.String>;
            readonly file_url: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_video">;
            readonly video_url: Schema.String;
        }>]>]>>;
        readonly id: Schema.optional<Schema.String>;
        readonly status: Schema.optional<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly role: Schema.tag<"assistant">;
        readonly content: Schema.$Array<Schema.Struct<{
            readonly type: Schema.tag<"output_text">;
            readonly text: Schema.String;
        }>>;
        readonly phase: Schema.optionalKey<Schema.NullOr<Schema.Literals<readonly ["commentary", "final_answer"]>>>;
        readonly status: Schema.optional<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"reasoning">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly summary: Schema.$Array<Schema.Struct<{
            readonly type: Schema.tag<"summary_text">;
            readonly text: Schema.String;
        }>>;
        readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"function_call">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly call_id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly arguments: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literals<readonly ["function_call_output", "custom_tool_call_output"]>;
        readonly call_id: Schema.String;
        readonly output: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"input_text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_image">;
            readonly image_url: Schema.String;
            readonly detail: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_file">;
            readonly filename: Schema.optional<Schema.String>;
            readonly detail: Schema.optional<Schema.String>;
            readonly file_data: Schema.optional<Schema.String>;
            readonly file_url: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_video">;
            readonly video_url: Schema.String;
        }>]>>]>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom_tool_call">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly call_id: Schema.String;
        readonly name: Schema.String;
        readonly input: Schema.String;
    }>, Schema.Union<readonly [Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"web_search_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly action: Schema.optional<Schema.NullOr<Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"file_search_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly queries: Schema.optional<Schema.$Array<Schema.String>>;
        readonly results: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"code_interpreter_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly code: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly container_id: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly outputs: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"mcp_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly server_label: Schema.optional<Schema.String>;
        readonly name: Schema.optional<Schema.String>;
        readonly arguments: Schema.optional<Schema.String>;
        readonly output: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly error: Schema.optional<Schema.Unknown>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.String;
        readonly id: Schema.String;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>>;
    readonly instructions: Schema.optional<Schema.String>;
    readonly tools: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"function">;
        readonly name: Schema.String;
        readonly description: Schema.String;
        readonly parameters: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly strict: Schema.optional<Schema.Boolean>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom">;
        readonly name: Schema.String;
        readonly description: Schema.String;
        readonly format: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"text">;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"grammar">;
            readonly syntax: Schema.Literals<readonly ["lark", "regex"]>;
            readonly definition: Schema.String;
        }>]>;
    }>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.String;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>>>;
    readonly tool_choice: Schema.optional<Schema.Union<readonly [Schema.Literals<readonly ["auto", "none", "required"]>, Schema.Struct<{
        readonly type: Schema.Literals<readonly ["function", "custom"]>;
        readonly name: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"allowed_tools">;
        readonly mode: Schema.Literals<readonly ["auto", "none", "required"]>;
        readonly tools: Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literals<readonly ["function", "custom"]>;
            readonly name: Schema.String;
        }>>;
    }>]>>;
    readonly store: Schema.optional<Schema.Boolean>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
    readonly safety_identifier: Schema.optional<Schema.String>;
    readonly stream_options: Schema.optional<Schema.Struct<{
        readonly include_obfuscation: Schema.optional<Schema.Boolean>;
    }>>;
    readonly top_logprobs: Schema.optional<Schema.Int>;
    readonly truncation: Schema.optional<Schema.Literals<readonly ["auto", "disabled"]>>;
    readonly service_tier: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority">, import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority">>>;
    readonly prompt_cache_key: Schema.optional<Schema.String>;
    readonly include: Schema.optional<Schema.$Array<Schema.declare<import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">, import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">>>>;
    readonly reasoning: Schema.optional<Schema.Struct<{
        readonly effort: Schema.optional<Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>>;
        readonly summary: Schema.optional<Schema.Literals<readonly ["auto", "concise", "detailed"]>>;
    }>>;
    readonly text: Schema.optional<Schema.Struct<{
        readonly verbosity: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"high" | "low" | "medium">, import("../schema/options.js").OpenString<"high" | "low" | "medium">>>;
    }>>;
    readonly max_output_tokens: Schema.optional<Schema.Number>;
    readonly max_tool_calls: Schema.optional<Schema.Int>;
    readonly parallel_tool_calls: Schema.optional<Schema.Boolean>;
    readonly temperature: Schema.optional<Schema.Number>;
    readonly top_p: Schema.optional<Schema.Number>;
    readonly presence_penalty: Schema.optional<Schema.Number>;
    readonly frequency_penalty: Schema.optional<Schema.Number>;
    readonly stream: Schema.Literal<true>;
}>;
export type OpenResponsesBody = Schema.Schema.Type<typeof OpenResponsesBody>;
export declare const OpenResponsesUsage: Schema.StructWithRest<Schema.Struct<{
    readonly input_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
    readonly input_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly cached_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
        readonly cache_write_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
    readonly output_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
    readonly output_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly reasoning_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
    readonly total_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
type OpenResponsesUsage = Schema.Schema.Type<typeof OpenResponsesUsage>;
export declare const StreamItem: Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.String;
    readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
    readonly call_id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
    readonly namespace: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
    readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
    readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
export type StreamItem = Schema.Schema.Type<typeof StreamItem>;
export type OutputItem = StreamItem & {
    readonly id: string;
};
export declare const Event: Schema.Union<readonly [Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.String;
    readonly delta: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
    readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
    readonly item_id: Schema.optional<Schema.String>;
    readonly output_index: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optional<Schema.NullOr<Schema.Number>>, never, never>;
    readonly summary_index: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optional<Schema.NullOr<Schema.Number>>, never, never>;
    readonly item: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.String;
        readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly call_id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly namespace: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
    readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
        readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly service_tier: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly incomplete_details: Schema.optional<Schema.NullOr<Schema.Struct<{
            readonly reason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        }>>>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.StructWithRest<Schema.Struct<{
            readonly type: Schema.String;
            readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly call_id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly namespace: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>>, Schema.optional<Schema.NullOr<Schema.$Array<Schema.StructWithRest<Schema.Struct<{
            readonly type: Schema.String;
            readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly call_id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly namespace: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>>, never, never>;
        readonly usage: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
            readonly input_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            readonly input_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
                readonly cached_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
                readonly cache_write_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
            readonly output_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            readonly output_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
                readonly reasoning_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
            readonly total_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
        readonly error: Schema.optional<Schema.Unknown>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>, Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly service_tier: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly incomplete_details: Schema.optional<Schema.NullOr<Schema.Struct<{
            readonly reason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        }>>>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.StructWithRest<Schema.Struct<{
            readonly type: Schema.String;
            readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly call_id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly namespace: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>>, Schema.optional<Schema.NullOr<Schema.$Array<Schema.StructWithRest<Schema.Struct<{
            readonly type: Schema.String;
            readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly call_id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly namespace: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>>, never, never>;
        readonly usage: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
            readonly input_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            readonly input_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
                readonly cached_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
                readonly cache_write_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
            readonly output_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            readonly output_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
                readonly reasoning_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
            readonly total_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
        readonly error: Schema.optional<Schema.Unknown>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>, never, never>;
    readonly code: Schema.optional<Schema.Unknown>;
    readonly message: Schema.optional<Schema.Unknown>;
    readonly error: Schema.optional<Schema.Unknown>;
    readonly status: Schema.optional<Schema.Unknown>;
    readonly status_code: Schema.optional<Schema.Unknown>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.decodeTo<Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.String;
    readonly delta: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
    readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
    readonly item_id: Schema.optional<Schema.String>;
    readonly output_index: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optional<Schema.NullOr<Schema.Number>>, never, never>;
    readonly summary_index: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Number>>, Schema.optional<Schema.NullOr<Schema.Number>>, never, never>;
    readonly item: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.String;
        readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly call_id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly namespace: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
    readonly response: Schema.decodeTo<Schema.optional<Schema.toType<Schema.StructWithRest<Schema.Struct<{
        readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly service_tier: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly incomplete_details: Schema.optional<Schema.NullOr<Schema.Struct<{
            readonly reason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        }>>>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.StructWithRest<Schema.Struct<{
            readonly type: Schema.String;
            readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly call_id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly namespace: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>>, Schema.optional<Schema.NullOr<Schema.$Array<Schema.StructWithRest<Schema.Struct<{
            readonly type: Schema.String;
            readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly call_id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly namespace: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>>, never, never>;
        readonly usage: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
            readonly input_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            readonly input_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
                readonly cached_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
                readonly cache_write_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
            readonly output_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            readonly output_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
                readonly reasoning_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
            readonly total_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
        readonly error: Schema.optional<Schema.Unknown>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>, Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        readonly service_tier: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly incomplete_details: Schema.optional<Schema.NullOr<Schema.Struct<{
            readonly reason: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
        }>>>;
        readonly output: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.StructWithRest<Schema.Struct<{
            readonly type: Schema.String;
            readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly call_id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly namespace: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>>, Schema.optional<Schema.NullOr<Schema.$Array<Schema.StructWithRest<Schema.Struct<{
            readonly type: Schema.String;
            readonly id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly call_id: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly namespace: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly arguments: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optional<Schema.NullOr<Schema.String>>, never, never>;
            readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>>, never, never>;
        readonly usage: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
            readonly input_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            readonly input_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
                readonly cached_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
                readonly cache_write_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
            readonly output_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            readonly output_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
                readonly reasoning_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
            readonly total_tokens: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Number>, never>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
        readonly error: Schema.optional<Schema.Unknown>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>, never, never>;
    readonly code: Schema.optional<Schema.Unknown>;
    readonly message: Schema.optional<Schema.Unknown>;
    readonly error: Schema.optional<Schema.Unknown>;
    readonly status: Schema.optional<Schema.Unknown>;
    readonly status_code: Schema.optional<Schema.Unknown>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.$Record<Schema.String, Schema.Unknown>, never, never>]>;
export type Event = Schema.Schema.Type<typeof Event>;
export type NormalizedEvent = Event & {
    readonly item?: OutputItem | null;
};
/** Decodes one WebSocket frame. */
export declare const decodeChannelEvent: (input: unknown, options?: import("effect/SchemaAST").ParseOptions) => Effect.Effect<{
    readonly [x: string]: unknown;
    readonly type: string;
    readonly delta?: string | undefined;
    readonly arguments?: string | undefined;
    readonly text?: string | undefined;
    readonly item_id?: string | undefined;
    readonly output_index?: number | undefined;
    readonly summary_index?: number | undefined;
    readonly item?: {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id?: string | undefined;
        readonly call_id?: string | undefined;
        readonly name?: string | undefined;
        readonly namespace?: string | undefined;
        readonly arguments?: string | undefined;
        readonly encrypted_content?: string | null | undefined;
    } | null | undefined;
    readonly response?: {
        readonly [x: string]: unknown;
        readonly id?: string | undefined;
        readonly service_tier?: string | null | undefined;
        readonly incomplete_details?: {
            readonly reason?: string | undefined;
        } | null | undefined;
        readonly output?: readonly {
            readonly [x: string]: unknown;
            readonly type: string;
            readonly id?: string | undefined;
            readonly call_id?: string | undefined;
            readonly name?: string | undefined;
            readonly namespace?: string | undefined;
            readonly arguments?: string | undefined;
            readonly encrypted_content?: string | null | undefined;
        }[] | undefined;
        readonly usage?: {
            readonly [x: string]: unknown;
            readonly input_tokens?: number | undefined;
            readonly input_tokens_details?: {
                readonly [x: string]: unknown;
                readonly cached_tokens?: number | undefined;
                readonly cache_write_tokens?: number | undefined;
            } | null | undefined;
            readonly output_tokens?: number | undefined;
            readonly output_tokens_details?: {
                readonly [x: string]: unknown;
                readonly reasoning_tokens?: number | undefined;
            } | null | undefined;
            readonly total_tokens?: number | undefined;
        } | null | undefined;
        readonly error?: unknown;
    } | undefined;
    readonly code?: unknown;
    readonly message?: unknown;
    readonly error?: unknown;
    readonly status?: unknown;
    readonly status_code?: unknown;
}, Schema.SchemaError, never>;
export interface ProviderAdapter {
    readonly id: string;
    readonly name: string;
    readonly nativeTool?: (native: NonNullable<ToolDefinition["native"]>) => Effect.Effect<HostedTool, AIError>;
    readonly lowerMedia?: (input: {
        readonly part: MediaPart;
        readonly media: Media.Inline | undefined;
        readonly request: LLMRequest;
    }) => MediaInput | undefined;
    readonly restoreHostedToolItem?: (item: unknown) => HostedToolReplayItem | undefined;
}
export interface ParserState {
    readonly provider: LLMRequest["model"]["provider"];
    readonly completedCompactions: ReadonlySet<string>;
    readonly id: string;
    readonly name: string;
    readonly providerMetadataKey: string;
    readonly tools: ToolStream.State<string>;
    readonly custom: ReadonlyMap<string, OpenAIFreeform.Custom>;
    readonly hasFunctionCall: boolean;
    readonly lifecycle: Lifecycle.State;
    readonly outputItems: Readonly<Record<number, string>>;
    readonly message: {
        readonly id: string;
        readonly phase: MessagePhase | null | undefined;
    } | undefined;
    readonly reasoningItems: Readonly<Record<string, ReasoningStreamItem>>;
}
type ReasoningSummaryStatus = "active" | "can-conclude" | "concluded";
interface ReasoningStreamItem {
    readonly encryptedContent: string | null | undefined;
    readonly summaryParts: Readonly<Record<number, ReasoningSummaryStatus>>;
    readonly deltaIndexes: ReadonlySet<number>;
}
export declare const lowerTool: (protocolName: string, tool: ToolDefinition) => Effect.Effect<{
    type: "function";
    name: string;
    description: string;
    parameters: {
        readonly [x: string]: unknown;
    };
    strict: boolean;
}, AIError, never>;
export declare const lowerCustomTool: (tool: ToolDefinition, custom: OpenAIFreeform.Custom) => {
    type: "custom";
    name: string;
    description: string;
    format: {
        syntax: "lark" | "regex";
        definition: string;
        type: "grammar";
    } | {
        type: "text";
    };
};
export declare const lowerTools: (tools: ReadonlyArray<ToolDefinition>, adapter: ProviderAdapter, custom: ReadonlyMap<string, OpenAIFreeform.Custom>) => Effect.Effect<({
    readonly type: "custom";
    readonly name: string;
    readonly description: string;
    readonly format: {
        readonly type: "text";
    } | {
        readonly type: "grammar";
        readonly syntax: "lark" | "regex";
        readonly definition: string;
    };
} | {
    readonly type: "function";
    readonly name: string;
    readonly description: string;
    readonly parameters: {
        readonly [x: string]: unknown;
    };
    readonly strict?: boolean | undefined;
} | {
    readonly [x: string]: unknown;
    readonly type: string;
})[], AIError, never>;
export declare const namedTool: (name: string, custom: ReadonlyMap<string, OpenAIFreeform.Custom>) => {
    type: "custom" | "function";
    name: string;
};
export declare const lowerToolChoice: (protocolName: string, toolChoice: NonNullable<LLMRequest["toolChoice"]>, custom: ReadonlyMap<string, OpenAIFreeform.Custom>) => Effect.Effect<"auto" | "none" | "required" | {
    type: "custom" | "function";
    name: string;
}, AIError, never>;
export declare const lowerConversation: (request: LLMRequest<import("../schema/options.js").LanguageModel<{
    readonly [x: string]: unknown;
}, import("../route.js").CompactionOperations | undefined>>, adapter: ProviderAdapter) => Effect.Effect<{
    model: string & import("effect/Brand").Brand<"AI.ModelID">;
    input: ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: OpenResponsesOptions.ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    instructions?: string | undefined;
}, AIError, never>;
export declare const lowerGeneration: (request: LLMRequest, options?: OpenResponsesOptions.Resolved) => {
    stream: true;
    max_output_tokens: number | undefined;
    temperature: number | undefined;
    top_p: number | undefined;
    presence_penalty: number | undefined;
    frequency_penalty: number | undefined;
    store?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    stream_options?: {
        include_obfuscation: boolean;
    } | undefined;
    top_logprobs?: number | undefined;
    prompt_cache_key?: string | undefined;
    include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    reasoning?: {
        effort: OpenResponsesOptions.ReasoningEffort | undefined;
        summary: "auto" | "concise" | "detailed" | undefined;
    } | undefined;
    text?: {
        verbosity: import("../schema/options.js").OpenString<"high" | "low" | "medium">;
    } | undefined;
    service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    max_tool_calls?: number | undefined;
    parallel_tool_calls?: boolean | undefined;
    truncation?: "auto" | "disabled" | undefined;
};
export declare const resolveParallelToolCalls: (request: LLMRequest, options?: OpenResponsesOptions.Resolved) => boolean | undefined;
export declare const allowedToolChoice: (options: OpenResponsesOptions.Resolved, custom: ReadonlyMap<string, OpenAIFreeform.Custom>) => {
    type: "allowed_tools";
    mode: "auto" | "none" | "required";
    tools: {
        type: "custom" | "function";
        name: string;
    }[];
} | undefined;
export declare const fromRequestWithAdapter: (request: LLMRequest<import("../schema/options.js").LanguageModel<{
    readonly [x: string]: unknown;
}, import("../route.js").CompactionOperations | undefined>>, adapter: ProviderAdapter) => Effect.Effect<{
    model: string & import("effect/Brand").Brand<"AI.ModelID">;
    input: ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: OpenResponsesOptions.ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    instructions?: string | undefined;
    stream: true;
    max_output_tokens: number | undefined;
    temperature: number | undefined;
    top_p: number | undefined;
    presence_penalty: number | undefined;
    frequency_penalty: number | undefined;
    store?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    stream_options?: {
        include_obfuscation: boolean;
    } | undefined;
    top_logprobs?: number | undefined;
    prompt_cache_key?: string | undefined;
    include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    reasoning?: {
        effort: OpenResponsesOptions.ReasoningEffort | undefined;
        summary: "auto" | "concise" | "detailed" | undefined;
    } | undefined;
    text?: {
        verbosity: import("../schema/options.js").OpenString<"high" | "low" | "medium">;
    } | undefined;
    service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    max_tool_calls?: number | undefined;
    parallel_tool_calls?: boolean | undefined;
    truncation?: "auto" | "disabled" | undefined;
    tools: ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
    })[] | undefined;
    tool_choice: "auto" | "none" | "required" | {
        type: "custom" | "function";
        name: string;
    } | {
        type: "allowed_tools";
        mode: "auto" | "none" | "required";
        tools: {
            type: "custom" | "function";
            name: string;
        }[];
    } | undefined;
}, AIError, never>;
export declare const fromRequest: (request: LLMRequest) => Effect.Effect<{
    model: string & import("effect/Brand").Brand<"AI.ModelID">;
    input: ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: OpenResponsesOptions.ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    instructions?: string | undefined;
    stream: true;
    max_output_tokens: number | undefined;
    temperature: number | undefined;
    top_p: number | undefined;
    presence_penalty: number | undefined;
    frequency_penalty: number | undefined;
    store?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    stream_options?: {
        include_obfuscation: boolean;
    } | undefined;
    top_logprobs?: number | undefined;
    prompt_cache_key?: string | undefined;
    include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    reasoning?: {
        effort: OpenResponsesOptions.ReasoningEffort | undefined;
        summary: "auto" | "concise" | "detailed" | undefined;
    } | undefined;
    text?: {
        verbosity: import("../schema/options.js").OpenString<"high" | "low" | "medium">;
    } | undefined;
    service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    max_tool_calls?: number | undefined;
    parallel_tool_calls?: boolean | undefined;
    truncation?: "auto" | "disabled" | undefined;
    tools: ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
    })[] | undefined;
    tool_choice: "auto" | "none" | "required" | {
        type: "custom" | "function";
        name: string;
    } | {
        type: "allowed_tools";
        mode: "auto" | "none" | "required";
        tools: {
            type: "custom" | "function";
            name: string;
        }[];
    } | undefined;
}, AIError, never>;
export declare const mapUsage: (usage: OpenResponsesUsage | null | undefined, providerMetadataKey: string, ...frames: ReadonlyArray<unknown>) => Usage | undefined;
export declare const metadataKey: (model: LLMRequest["model"]) => string;
export declare const providerMetadata: (state: ParserState, metadata: Record<string, unknown>) => ProviderMetadata;
export type StepResult = readonly [ParserState, ReadonlyArray<LLMEvent>];
export declare const terminal: (event: Event) => boolean;
export declare const normalize: (state: Pick<ParserState, "outputItems">, input: Event) => NormalizedEvent;
export declare const onReasoningDelta: (state: ParserState, event: Event, itemID: string) => StepResult;
export declare const onReasoningDone: (state: ParserState, event: Event, itemID: string) => StepResult;
/** Error code and message from wherever the frame put them; top-level fields win over nested ones. */
export declare const errorDetail: (event: Event) => {
    message: string | undefined;
    code: string | undefined;
};
export declare const providerFailure: (event: Event, fallback: string, body?: string) => AIError;
export declare const step: (state: ParserState, event: NormalizedEvent) => AIError | Effect.Effect<StepResult, never, never> | Effect.Effect<[ParserState, readonly ({
    readonly type: "step-start";
    readonly index: number;
} | {
    readonly type: "raw";
    readonly data: unknown;
} | {
    readonly type: "text-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-start";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-delta";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly text: string;
    readonly input?: unknown;
} | {
    readonly type: "tool-input-end";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-error";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly raw: string;
} | {
    readonly type: "tool-call";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly input: unknown;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-result";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly result: {
        readonly type: "json";
        readonly value: unknown;
    } | {
        readonly type: "text";
        readonly value: unknown;
    } | {
        readonly type: "error";
        readonly value: unknown;
    } | {
        readonly type: "content";
        readonly value: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    };
    readonly output?: {
        readonly structured: unknown;
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    } | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "step-finish";
    readonly index: number;
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: Usage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "finish";
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: Usage | undefined;
    readonly message?: import("../schema/messages.js").AssistantMessage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "media";
    readonly media: Media.Asset;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | ({
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
})))[]], AIError, never>;
/**
 * The provider-neutral Open Responses protocol. Provider-specific Responses
 * implementations compose this baseline with their own tools and event variants.
 */
export declare const initial: (request: LLMRequest, adapter?: ProviderAdapter) => ParserState;
export declare const protocol: Protocol<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: OpenResponsesOptions.ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly reasoning?: {
        readonly effort?: OpenResponsesOptions.ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
    } | undefined;
    readonly text?: {
        readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly stream: true;
}, string, {
    readonly [x: string]: unknown;
    readonly type: string;
    readonly delta?: string | undefined;
    readonly arguments?: string | undefined;
    readonly text?: string | undefined;
    readonly item_id?: string | undefined;
    readonly output_index?: number | undefined;
    readonly summary_index?: number | undefined;
    readonly item?: {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id?: string | undefined;
        readonly call_id?: string | undefined;
        readonly name?: string | undefined;
        readonly namespace?: string | undefined;
        readonly arguments?: string | undefined;
        readonly encrypted_content?: string | null | undefined;
    } | null | undefined;
    readonly response?: {
        readonly [x: string]: unknown;
        readonly id?: string | undefined;
        readonly service_tier?: string | null | undefined;
        readonly incomplete_details?: {
            readonly reason?: string | undefined;
        } | null | undefined;
        readonly output?: readonly {
            readonly [x: string]: unknown;
            readonly type: string;
            readonly id?: string | undefined;
            readonly call_id?: string | undefined;
            readonly name?: string | undefined;
            readonly namespace?: string | undefined;
            readonly arguments?: string | undefined;
            readonly encrypted_content?: string | null | undefined;
        }[] | undefined;
        readonly usage?: {
            readonly [x: string]: unknown;
            readonly input_tokens?: number | undefined;
            readonly input_tokens_details?: {
                readonly [x: string]: unknown;
                readonly cached_tokens?: number | undefined;
                readonly cache_write_tokens?: number | undefined;
            } | null | undefined;
            readonly output_tokens?: number | undefined;
            readonly output_tokens_details?: {
                readonly [x: string]: unknown;
                readonly reasoning_tokens?: number | undefined;
            } | null | undefined;
            readonly total_tokens?: number | undefined;
        } | null | undefined;
        readonly error?: unknown;
    } | undefined;
    readonly code?: unknown;
    readonly message?: unknown;
    readonly error?: unknown;
    readonly status?: unknown;
    readonly status_code?: unknown;
}, ParserState>;
export declare const httpTransport: HttpTransport.HttpJsonTransport<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: OpenResponsesOptions.ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly reasoning?: {
        readonly effort?: OpenResponsesOptions.ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
    } | undefined;
    readonly text?: {
        readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly stream: true;
}, string>;
export * as OpenResponses from "./open-responses.js";
