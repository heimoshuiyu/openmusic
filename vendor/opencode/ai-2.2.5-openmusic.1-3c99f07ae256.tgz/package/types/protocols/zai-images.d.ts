import { ImageModel, ImageResponse, type ImageRequest } from "../image.js";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type OpenString } from "../schema/index.js";
export declare const DEFAULT_BASE_URL = "https://api.z.ai/api/paas/v4";
export declare const PATH = "/images/generations";
/** Provider-native options. Common `aspect` and `resolution` lower to `size`. */
export type ZAIImageOptions = {
    /** Exact `WIDTHxHEIGHT`; it wins over `aspect` and `resolution`. */
    readonly size?: string;
    readonly quality?: OpenString<"hd" | "standard">;
    readonly userID?: string;
} & Record<string, unknown>;
export type Request = ImageRequest<ImageModel<ZAIImageOptions>>;
export declare const protocol: MediaProtocol.Inline<Request, ImageResponse>;
export declare const model: (input: MediaRoute.ModelInput) => ImageModel<ZAIImageOptions>;
export declare const ZAIImages: {
    readonly protocol: MediaProtocol.Inline<Request, ImageResponse>;
    readonly model: typeof model;
};
