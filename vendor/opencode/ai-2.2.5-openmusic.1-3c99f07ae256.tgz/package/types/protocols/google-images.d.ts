import { ImageModel, ImageResponse, type ImageRequest } from "../image.js";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type OpenString } from "../schema/index.js";
export declare const DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta";
/** Provider-native `generationConfig` fields. Common fields (`aspect`, `resolution`, `images`) live on the request. */
export type GoogleImageOptions = {
    readonly seed?: number;
    readonly thinkingLevel?: OpenString<"MINIMAL" | "LOW" | "MEDIUM" | "HIGH">;
    readonly includeThoughts?: boolean;
} & Record<string, unknown>;
export type Request = ImageRequest<ImageModel<GoogleImageOptions>>;
export declare const protocol: MediaProtocol.Inline<Request, ImageResponse>;
export declare const model: (input: MediaRoute.ModelInput) => ImageModel<GoogleImageOptions>;
export declare const GoogleImages: {
    readonly protocol: MediaProtocol.Inline<Request, ImageResponse>;
    readonly model: typeof model;
};
