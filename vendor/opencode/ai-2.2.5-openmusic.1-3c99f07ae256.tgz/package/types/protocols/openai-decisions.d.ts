import { Schema } from "effect";
import { DecisionRoute } from "../route/decision.js";
import { type ProviderOptions } from "../schema/index.js";
export declare const DEFAULT_BASE_URL = "https://api.openai.com/v1";
export declare const PATH = "/decisions";
declare const Options: Schema.Struct<{
    readonly promptCacheKey: Schema.optional<Schema.String>;
    readonly promptCacheOptions: Schema.optional<Schema.Struct<{
        readonly mode: Schema.optional<Schema.String>;
        readonly ttl: Schema.optional<Schema.String>;
    }>>;
    readonly safetyIdentifier: Schema.optional<Schema.String>;
}>;
/** Known fields map to their wire names; anything else is sent as given. */
export type OptionsInput = ProviderOptions & typeof Options.Encoded;
export declare const protocol: DecisionRoute.Protocol;
export declare const route: DecisionRoute.Route;
export declare const OpenAIDecisions: {
    readonly protocol: DecisionRoute.Protocol;
    readonly route: DecisionRoute.Route;
};
export {};
