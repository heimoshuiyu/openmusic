import { DecisionRoute } from "../route/decision.js";
/** Posts `{ model, input }` to Cloudflare's `/ai/run` with the System One body as `input`; media defaults to Clef's top-level lists. */
export declare const protocol: DecisionRoute.Protocol;
/** Providers set the Run API base, `.../client/v4/accounts/{account}/ai/run`, with `route.with(...)`. */
export declare const route: DecisionRoute.Route;
export declare const CloudflareRunDecisions: {
    readonly protocol: DecisionRoute.Protocol;
    readonly route: DecisionRoute.Route;
};
