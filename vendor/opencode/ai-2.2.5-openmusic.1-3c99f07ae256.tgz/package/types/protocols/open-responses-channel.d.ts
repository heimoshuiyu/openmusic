import { Headers } from "effect/http";
import { HttpTransport, type Transport, type WebSocketChannelDriver } from "../route/transport/index.js";
import { OpenResponsesContinuation } from "./open-responses-continuation.js";
export interface Options {
    readonly id: string;
    readonly name: string;
    readonly rotateAfterMs?: number;
    readonly enabled?: (url: string) => boolean;
    readonly url?: (url: string) => string;
    readonly headers?: (headers: Headers.Headers) => Headers.Headers;
    readonly continuation?: OpenResponsesContinuation.Shape;
}
export interface Prepared {
    readonly http: HttpTransport.HttpPrepared<string>;
    readonly channel?: {
        readonly url: string;
        readonly headers: Headers.Headers;
        readonly rotateAfterMs?: number;
        readonly driver: WebSocketChannelDriver;
    };
}
export declare const transport: <Body>(options: Options) => Transport<Body, Prepared, string>;
export declare const OpenResponsesChannel: {
    readonly transport: typeof transport;
};
