import { Effect } from "effect";
import { AIError, LLMEvent, type ProviderMetadata } from "../../schema/index.js";
import { type ToolAccumulator } from "../shared.js";
type StreamKey = string | number;
/**
 * One pending streamed tool call. Providers emit the tool identity and JSON
 * argument text across separate chunks; `input` is the raw JSON string collected
 * so far, not the parsed object.
 */
export interface PendingTool extends ToolAccumulator {
    readonly providerExecuted?: boolean;
    readonly providerMetadata?: ProviderMetadata;
}
/**
 * Sparse parser state keyed by the provider's stream-local tool identifier.
 *
 * This key is not the final tool-call id (`call_...`). It is the id/index the
 * provider uses while streaming a partial call: OpenAI Chat / Anthropic /
 * Bedrock use numeric content indexes, while OpenAI Responses uses string
 * `item_id`s. The generic keeps each protocol internally consistent.
 */
export type State<K extends StreamKey> = Partial<Record<K, PendingTool>>;
/**
 * Result of adding argument text to one pending tool call. It returns both the
 * next `tools` state and the updated `tool` because parsers often need the
 * current id/name immediately. `events` contains lifecycle and delta events
 * produced by the append; metadata-only deltas update identity without output.
 */
export interface AppendOutcome<K extends StreamKey> {
    readonly tools: State<K>;
    readonly tool: PendingTool;
    readonly events: ReadonlyArray<LLMEvent>;
}
/** Create empty accumulator state for one provider stream. */
export declare const empty: <K extends StreamKey>() => State<K>;
export declare const isError: <K extends StreamKey>(result: AppendOutcome<K> | AIError) => result is AIError;
/**
 * Register a tool call whose start event arrived before any argument deltas.
 * Used by Anthropic `content_block_start`, Bedrock `contentBlockStart`, and
 * OpenAI Responses `response.output_item.added`.
 */
export declare const start: <K extends StreamKey>(tools: State<K>, key: K, tool: Omit<PendingTool, "input"> & {
    readonly input?: string;
}) => Partial<Record<K, PendingTool>>;
/**
 * Append a streamed argument delta, starting the tool if this provider encodes
 * identity on the first delta instead of a separate start event. OpenAI Chat has
 * this shape: `tool_calls[].index` is the stream key, and `id` / `name` may only
 * appear on the first delta for that index.
 */
export declare const appendOrStart: <K extends StreamKey>(route: string, tools: State<K>, key: K, delta: {
    readonly id?: string;
    readonly name?: string;
    readonly text: string;
    readonly providerMetadata?: ProviderMetadata;
}, missingToolMessage: string) => AppendOutcome<K> | AIError;
/**
 * Append argument text to a started tool. Returns `undefined` when no tool is
 * open under `key`, for protocols that ignore deltas without a matching block.
 */
export declare const append: <K extends StreamKey>(tools: State<K>, key: K, text: string) => AppendOutcome<K> | undefined;
/**
 * Append argument text to a tool that must already have been started. This keeps
 * protocols honest when their stream grammar promises a start event before any
 * argument delta.
 */
export declare const appendExisting: <K extends StreamKey>(route: string, tools: State<K>, key: K, text: string, missingToolMessage: string) => AppendOutcome<K> | AIError;
/**
 * Finalize one pending tool call: parse the accumulated raw JSON, remove it
 * from state, and reject malformed local arguments without repairing them.
 * Missing keys are a no-op because some providers emit stop events for
 * non-tool content blocks.
 *
 * Pass `input` when the provider sends an authoritative final input string.
 * OpenAI Responses can send accumulated deltas and then repeat the completed
 * arguments on `response.output_item.done`; the final value wins.
 */
export declare const finish: <K extends StreamKey>(route: string, tools: State<K>, key: K, input?: string) => Effect.Effect<{
    tools: Partial<Record<K, PendingTool>>;
    events?: undefined;
} | {
    tools: Partial<Record<K, PendingTool>>;
    events: readonly ({
        readonly type: "step-start";
        readonly index: number;
    } | {
        readonly type: "raw";
        readonly data: unknown;
    } | {
        readonly type: "text-start";
        readonly id: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "text-delta";
        readonly id: string;
        readonly text: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "text-end";
        readonly id: string;
        readonly text?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "reasoning-start";
        readonly id: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "reasoning-delta";
        readonly id: string;
        readonly text: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "reasoning-end";
        readonly id: string;
        readonly text?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-input-start";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-input-delta";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly text: string;
        readonly input?: unknown;
    } | {
        readonly type: "tool-input-end";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-input-error";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly raw: string;
    } | {
        readonly type: "tool-call";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly input: unknown;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-result";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly result: {
            readonly type: "json";
            readonly value: unknown;
        } | {
            readonly type: "text";
            readonly value: unknown;
        } | {
            readonly type: "error";
            readonly value: unknown;
        } | {
            readonly type: "content";
            readonly value: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        };
        readonly output?: {
            readonly structured: unknown;
            readonly content: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        } | undefined;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "step-finish";
        readonly index: number;
        readonly reason: {
            readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
            readonly raw?: string | undefined;
            readonly category?: string | undefined;
            readonly explanation?: string | undefined;
        };
        readonly usage?: import("../../schema/events.js").Usage | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "finish";
        readonly reason: {
            readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
            readonly raw?: string | undefined;
            readonly category?: string | undefined;
            readonly explanation?: string | undefined;
        };
        readonly usage?: import("../../schema/events.js").Usage | undefined;
        readonly message?: import("../../schema/messages.js").AssistantMessage | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "media";
        readonly media: import("../../media.js").Asset;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | ({
        readonly type: "compaction";
        readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
        readonly id?: string | undefined;
        readonly encrypted?: string | undefined;
        readonly text?: string | null | undefined;
    } & ({
        readonly encrypted: string;
        readonly text?: never;
    } | {
        readonly text: string | null;
        readonly encrypted?: never;
    })))[];
}, AIError, never>;
/**
 * Finalize every pending tool call at once. OpenAI Chat has this shape: it does
 * not emit per-tool stop events, so all accumulated calls finish independently
 * when the choice receives a terminal `finish_reason`.
 */
export declare const finishAll: <K extends StreamKey>(route: string, tools: State<K>) => Effect.Effect<{
    tools: Partial<Record<K, PendingTool>>;
    events: ({
        readonly type: "step-start";
        readonly index: number;
    } | {
        readonly type: "raw";
        readonly data: unknown;
    } | {
        readonly type: "text-start";
        readonly id: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "text-delta";
        readonly id: string;
        readonly text: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "text-end";
        readonly id: string;
        readonly text?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "reasoning-start";
        readonly id: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "reasoning-delta";
        readonly id: string;
        readonly text: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "reasoning-end";
        readonly id: string;
        readonly text?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-input-start";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-input-delta";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly text: string;
        readonly input?: unknown;
    } | {
        readonly type: "tool-input-end";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-input-error";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly raw: string;
    } | {
        readonly type: "tool-call";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly input: unknown;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-result";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly result: {
            readonly type: "json";
            readonly value: unknown;
        } | {
            readonly type: "text";
            readonly value: unknown;
        } | {
            readonly type: "error";
            readonly value: unknown;
        } | {
            readonly type: "content";
            readonly value: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        };
        readonly output?: {
            readonly structured: unknown;
            readonly content: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        } | undefined;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "step-finish";
        readonly index: number;
        readonly reason: {
            readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
            readonly raw?: string | undefined;
            readonly category?: string | undefined;
            readonly explanation?: string | undefined;
        };
        readonly usage?: import("../../schema/events.js").Usage | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "finish";
        readonly reason: {
            readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
            readonly raw?: string | undefined;
            readonly category?: string | undefined;
            readonly explanation?: string | undefined;
        };
        readonly usage?: import("../../schema/events.js").Usage | undefined;
        readonly message?: import("../../schema/messages.js").AssistantMessage | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "media";
        readonly media: import("../../media.js").Asset;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | ({
        readonly type: "compaction";
        readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
        readonly id?: string | undefined;
        readonly encrypted?: string | undefined;
        readonly text?: string | null | undefined;
    } & ({
        readonly encrypted: string;
        readonly text?: never;
    } | {
        readonly text: string | null;
        readonly encrypted?: never;
    })))[];
}, AIError, never>;
export * as ToolStream from "./tool-stream.js";
