import type { JsonSchema } from "../../schema/index.js";
export declare const SCHEMA_MAPS: Set<string>;
export declare const VALUES: Set<string>;
export declare const mapValues: (record: Record<string, unknown>, map: (value: unknown, key: string) => unknown) => {
    [k: string]: unknown;
};
export declare const normalize: (schema: JsonSchema) => JsonSchema;
export * as GeminiJsonSchema from "./gemini-json-schema.js";
