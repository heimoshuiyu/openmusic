import { type JsonSchema, type LanguageModel, type LLMRequest } from "../../schema/index.js";
import { GeminiJsonSchema } from "./gemini-json-schema.js";
declare const moonshot: (schema: JsonSchema) => JsonSchema;
declare const tools: (entries: LLMRequest["tools"], model: LanguageModel) => LLMRequest["tools"];
export declare const ToolSchemaProjection: {
    readonly gemini: typeof GeminiJsonSchema.normalize;
    readonly moonshot: typeof moonshot;
    readonly tools: typeof tools;
};
export {};
