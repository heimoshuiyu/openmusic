import { Schema } from "effect";
import { type CacheHint, type LLMRequest } from "../../schema/index.js";
export declare const CachePointBlock: Schema.Struct<{
    readonly cachePoint: Schema.Struct<{
        readonly type: Schema.tag<"default">;
        readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
    }>;
}>;
export type CachePointBlock = Schema.Schema.Type<typeof CachePointBlock>;
export declare const BEDROCK_BREAKPOINT_CAP = 4;
export declare const breakpoints: (model: LLMRequest["model"]) => {
    remaining: number;
    dropped: number;
    supported: boolean;
    ttl1h: boolean;
};
export type Breakpoints = ReturnType<typeof breakpoints>;
export declare const block: (breakpoints: Breakpoints, cache: CacheHint | undefined) => CachePointBlock | undefined;
export * as BedrockCache from "./bedrock-cache.js";
