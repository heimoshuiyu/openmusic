import { Effect } from "effect";
import { Media } from "../../media.js";
import type { MediaProtocol } from "../../route/media-protocol.js";
import type { AIError, MediaUsage, ProviderMetadata } from "../../schema/index.js";
import { type SpeechEvent, type SpeechVoice } from "../../speech.js";
export interface Audio {
    /** Appended in place: the route creates fresh state for each response through `initial`. */
    readonly chunks: Array<Uint8Array>;
}
export type StepResult<State> = readonly [State, ReadonlyArray<SpeechEvent>];
/** Empty chunks (keep-alive records) emit nothing. */
export declare const delta: <State extends Audio>(state: State, chunk: Uint8Array) => StepResult<State>;
export declare const step: <State extends Audio>(onRecord: (state: State, frame: string) => Effect.Effect<StepResult<State>, AIError>) => (state: State, frame: string | Uint8Array) => Effect.Effect<StepResult<State>, AIError, never>;
export declare const timestamps: (texts: ReadonlyArray<string>, starts: ReadonlyArray<number>, ends: ReadonlyArray<number>) => ReadonlyArray<SpeechEvent>;
export declare const voiceID: (voice: SpeechVoice | undefined) => string | undefined;
export declare const container: (format: string, sampleRate?: number) => {
    mediaType: string;
    info: {
        format: string;
        sampleRate: number | undefined;
    };
};
declare const PCM_MEDIA_TYPES: {
    readonly pcm_s16le: "audio/pcm";
    readonly pcm_f32le: "audio/pcm";
    readonly pcm_mulaw: "audio/mulaw";
    readonly pcm_alaw: "audio/alaw";
};
export type PcmEncoding = keyof typeof PCM_MEDIA_TYPES;
export declare const pcm: (encoding: PcmEncoding, sampleRate: number | undefined, mediaType?: string) => {
    mediaType: string;
    info: {
        format: string;
        encoding: "pcm_alaw" | "pcm_f32le" | "pcm_mulaw" | "pcm_s16le";
        sampleRate: number | undefined;
        channels: number;
    };
};
export declare const sampleRate: (mediaType: string | undefined) => number | undefined;
/** A declared `mediaType` wins over sniffing: headerless PCM can start with bytes that look like an MPEG frame sync. */
export declare const finish: (route: MediaProtocol.Identity, state: Audio, output: {
    readonly mediaType: string | undefined;
    readonly info?: Media.Info;
    readonly usage?: MediaUsage;
    readonly providerMetadata?: ProviderMetadata;
    readonly detail?: string;
}) => Effect.Effect<ReadonlyArray<SpeechEvent>, AIError>;
export declare const headerUsage: (type: "characters" | "credits", value: string | undefined) => MediaUsage | undefined;
export * as SpeechStream from "./speech-stream.js";
