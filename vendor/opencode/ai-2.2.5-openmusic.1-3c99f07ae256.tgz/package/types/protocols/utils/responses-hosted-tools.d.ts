import { Effect } from "effect";
import { type AIError, type LLMRequest, type ToolResultPart } from "../../schema/index.js";
import { OpenResponses } from "../open-responses.js";
export type Item = OpenResponses.OutputItem & {
    readonly status?: string;
    readonly action?: unknown;
    readonly queries?: unknown;
    readonly results?: unknown;
    readonly code?: string;
    readonly container_id?: string;
    readonly outputs?: unknown;
    readonly server_label?: string;
    readonly output?: unknown;
    readonly result?: string;
    readonly output_format?: "png" | "jpeg" | "webp";
    readonly error?: unknown;
};
export interface Definition {
    readonly name: string;
    readonly input: (item: Item) => unknown;
    readonly result?: (item: Item) => Effect.Effect<ToolResultPart["result"], AIError>;
}
export type Definitions = Readonly<Record<string, Definition>>;
/** Hosted tools that several Responses providers report with the same item shape. */
export declare const common: {
    readonly web_search_call: {
        readonly name: "web_search";
        readonly input: (item: Item) => {};
    };
    readonly file_search_call: {
        readonly name: "file_search";
        readonly input: (item: Item) => {
            queries: {};
        };
    };
    readonly code_interpreter_call: {
        readonly name: "code_interpreter";
        readonly input: (item: Item) => {
            code: string | undefined;
            container_id: string | undefined;
        };
    };
    readonly mcp_call: {
        readonly name: "mcp";
        readonly input: (item: Item) => {
            server_label: string | undefined;
            name: string | undefined;
            arguments: string | undefined;
        };
    };
};
export declare const isItem: <Tools extends Definitions>(item: OpenResponses.OutputItem, tools: Tools) => item is Item;
/**
 * Responses stream that turns completed hosted tool items into a provider-executed
 * tool call and result. `override` sees each normalized event first and may handle it.
 */
export declare const stream: (adapter: OpenResponses.ProviderAdapter, tools: Definitions, override?: (state: OpenResponses.ParserState, event: OpenResponses.NormalizedEvent) => Effect.Effect<OpenResponses.StepResult, AIError> | undefined) => {
    event: import("effect/Schema").Codec<{
        readonly [x: string]: unknown;
        readonly type: string;
        readonly delta?: string | undefined;
        readonly arguments?: string | undefined;
        readonly text?: string | undefined;
        readonly item_id?: string | undefined;
        readonly output_index?: number | undefined;
        readonly summary_index?: number | undefined;
        readonly item?: {
            readonly [x: string]: unknown;
            readonly type: string;
            readonly id?: string | undefined;
            readonly call_id?: string | undefined;
            readonly name?: string | undefined;
            readonly namespace?: string | undefined;
            readonly arguments?: string | undefined;
            readonly encrypted_content?: string | null | undefined;
        } | null | undefined;
        readonly response?: {
            readonly [x: string]: unknown;
            readonly id?: string | undefined;
            readonly service_tier?: string | null | undefined;
            readonly incomplete_details?: {
                readonly reason?: string | undefined;
            } | null | undefined;
            readonly output?: readonly {
                readonly [x: string]: unknown;
                readonly type: string;
                readonly id?: string | undefined;
                readonly call_id?: string | undefined;
                readonly name?: string | undefined;
                readonly namespace?: string | undefined;
                readonly arguments?: string | undefined;
                readonly encrypted_content?: string | null | undefined;
            }[] | undefined;
            readonly usage?: {
                readonly [x: string]: unknown;
                readonly input_tokens?: number | undefined;
                readonly input_tokens_details?: {
                    readonly [x: string]: unknown;
                    readonly cached_tokens?: number | undefined;
                    readonly cache_write_tokens?: number | undefined;
                } | null | undefined;
                readonly output_tokens?: number | undefined;
                readonly output_tokens_details?: {
                    readonly [x: string]: unknown;
                    readonly reasoning_tokens?: number | undefined;
                } | null | undefined;
                readonly total_tokens?: number | undefined;
            } | null | undefined;
            readonly error?: unknown;
        } | undefined;
        readonly code?: unknown;
        readonly message?: unknown;
        readonly error?: unknown;
        readonly status?: unknown;
        readonly status_code?: unknown;
    }, string, never, never>;
    initial: (request: LLMRequest) => OpenResponses.ParserState;
    step: (state: OpenResponses.ParserState, input: OpenResponses.Event) => AIError | Effect.Effect<OpenResponses.StepResult, AIError, never>;
    terminal: typeof OpenResponses.terminal;
};
export declare const onDone: (state: OpenResponses.ParserState, item: Item, tools: Definitions) => Effect.Effect<OpenResponses.StepResult, AIError>;
export * as ResponsesHostedTools from "./responses-hosted-tools.js";
