import { Effect } from "effect";
import type { MediaProtocol } from "../../route/media-protocol.js";
export interface Size {
    readonly width: number;
    readonly height: number;
}
/** The shared `aspect` and `resolution` fields of an image request. */
export interface Shape {
    readonly aspect?: string;
    readonly resolution?: string;
}
/** What a provider accepts for free width and height. */
export interface Limits {
    readonly multiple: number;
    readonly minEdge?: number;
    readonly maxEdge?: number;
    readonly minPixels?: number;
    readonly maxPixels?: number;
    /** Long edge over short edge. */
    readonly maxRatio?: number;
}
export declare const isRequested: (shape: Shape) => boolean;
/** `1K` is 1, `2K` is 2, `0.5K` is 0.5; anything else is not a tier. */
export declare const tier: (resolution: string) => number | undefined;
/** Free width and height: the tier sets the pixel count (`1K` is about 1024²), the aspect sets the proportions. */
export declare const fit: (shape: Shape, limits: Limits) => Size;
/** The listed size closest to the shape: nearest aspect ratio first, then nearest pixel count. */
export declare const nearest: (shape: Shape, sizes: ReadonlyArray<Size>) => Size;
/** Free width and height that must honor the shape; a size that misses it fails. */
export declare const exact: (route: MediaProtocol.Identity, shape: Shape, limits: Limits) => Effect.Effect<undefined, never, never> | Effect.Effect<never, import("../../public.js").AIError, never> | Effect.Effect<Size, never, never>;
export * as ImageSizing from "./image-sizing.js";
