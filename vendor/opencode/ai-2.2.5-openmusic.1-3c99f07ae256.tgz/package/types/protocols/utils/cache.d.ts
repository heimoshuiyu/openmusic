import { Effect } from "effect";
import type { CacheHint, CacheTTL } from "../../schema/index.js";
export interface Breakpoints {
    remaining: number;
    dropped: number;
}
export declare const newBreakpoints: (cap: number) => Breakpoints;
export declare const take: (breakpoints: Breakpoints) => boolean;
export declare const warnDropped: (breakpoints: Breakpoints, protocol: string, cap: number) => Effect.Effect<void, never, never>;
export declare const cacheControl: () => (cache: CacheHint | undefined) => {
    type: "ephemeral";
    ttl: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
} | undefined;
export declare const openAIRequestTTL: (ttl: CacheTTL | undefined) => {
    prompt_cache_retention?: undefined;
    prompt_cache_options?: undefined;
} | {
    prompt_cache_retention: string;
    prompt_cache_options?: undefined;
} | {
    prompt_cache_retention?: undefined;
    prompt_cache_options: {
        ttl: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s`;
    };
};
