import { Effect, Schema } from "effect";
import { DecisionResponse, type DecisionModelCompatibility, type DecisionRequest } from "../decision.js";
import { DecisionRoute } from "../route/decision.js";
import { AIError } from "../schema/index.js";
export declare const DEFAULT_PATH = "/systemone";
export declare const DEFAULT_BASE_URL = "https://api.typesafe.ai/v1";
/** `state.messages` is Baseten's own placement (parts in a user message inside `state.messages`), set by its provider. */
type MediaInput = NonNullable<DecisionModelCompatibility["mediaInput"]> | "state.messages";
export declare const Response: Schema.Struct<{
    readonly model: Schema.String;
    readonly answers: Schema.$Record<Schema.String, Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
        readonly type: Schema.Literal<"noul">;
        readonly noul: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"choice">;
        readonly choice: Schema.String;
        readonly probabilities: Schema.$Record<Schema.String, Schema.Number>;
        readonly confidence: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"score">;
        readonly score: Schema.Number;
        readonly probabilities: Schema.$Record<Schema.String, Schema.Number>;
        readonly confidence: Schema.Number;
    }>]>>;
    readonly usage: Schema.optional<Schema.StructWithRest<Schema.Struct<{
        readonly input_tokens: Schema.optional<Schema.Number>;
        readonly output_tokens: Schema.optional<Schema.Number>;
        readonly cost: Schema.optional<Schema.Number>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>;
    readonly id: Schema.optional<Schema.String>;
    readonly provider: Schema.optional<Schema.String>;
    readonly provider_metadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type Response = Schema.Schema.Type<typeof Response>;
/** The System One body without `model`; media goes where the model's `mediaInput` says, else `fallback`. */
export declare const encodeBody: (request: DecisionRequest<import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>, import("../decision.js").DecisionQuestions>, fallback: MediaInput) => Effect.Effect<{
    questions: any;
    state: unknown;
    assets?: undefined;
} | {
    questions: any;
    state: readonly unknown[];
    assets: {
        [k: string]: {
            type: string;
            format: string;
            data_base64: string;
        };
    };
}, AIError, never>;
/** Map System One's answers, keyed by question name, back to the request's question order. */
export declare const toResponse: (data: Response, request: DecisionRequest, providerMetadataKey: string, invalid: (message: string) => AIError) => Effect.Effect<never, AIError, never> | Effect.Effect<DecisionResponse, never, never>;
export declare const protocol: DecisionRoute.Protocol;
/** TypeSafe's API, the reference System One host; other hosts change the endpoint and auth with `route.with(...)`. */
export declare const route: DecisionRoute.Route;
export declare const SystemOne: {
    readonly Response: Schema.Struct<{
        readonly model: Schema.String;
        readonly answers: Schema.$Record<Schema.String, Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
            readonly type: Schema.Literal<"noul">;
            readonly noul: Schema.Number;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"choice">;
            readonly choice: Schema.String;
            readonly probabilities: Schema.$Record<Schema.String, Schema.Number>;
            readonly confidence: Schema.Number;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"score">;
            readonly score: Schema.Number;
            readonly probabilities: Schema.$Record<Schema.String, Schema.Number>;
            readonly confidence: Schema.Number;
        }>]>>;
        readonly usage: Schema.optional<Schema.StructWithRest<Schema.Struct<{
            readonly input_tokens: Schema.optional<Schema.Number>;
            readonly output_tokens: Schema.optional<Schema.Number>;
            readonly cost: Schema.optional<Schema.Number>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>;
        readonly id: Schema.optional<Schema.String>;
        readonly provider: Schema.optional<Schema.String>;
        readonly provider_metadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>;
    readonly encodeBody: (request: DecisionRequest<import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>, import("../decision.js").DecisionQuestions>, fallback: MediaInput) => Effect.Effect<{
        questions: any;
        state: unknown;
        assets?: undefined;
    } | {
        questions: any;
        state: readonly unknown[];
        assets: {
            [k: string]: {
                type: string;
                format: string;
                data_base64: string;
            };
        };
    }, AIError, never>;
    readonly toResponse: typeof toResponse;
    readonly protocol: DecisionRoute.Protocol;
    readonly route: DecisionRoute.Route;
};
export {};
