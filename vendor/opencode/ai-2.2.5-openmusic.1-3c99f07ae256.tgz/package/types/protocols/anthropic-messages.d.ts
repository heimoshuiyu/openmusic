import { Effect, Schema } from "effect";
import { Route } from "../route/client.js";
import { Framing } from "../route/framing.js";
import { Protocol } from "../route/protocol.js";
import { HttpTransport } from "../route/transport/index.js";
import { AIError, type LLMRequest, type ProviderOptions } from "../schema/index.js";
import { Lifecycle } from "./utils/lifecycle.js";
import { ToolStream } from "./utils/tool-stream.js";
export declare const DEFAULT_BASE_URL = "https://api.anthropic.com/v1";
export declare const PATH = "/messages";
export declare const DEFAULT_MAX_TOKENS = 32000;
export declare const framing: Framing.Definition<string>;
export type ThinkingInput = typeof Thinking.Encoded;
/** Caller-facing provider options; unknown keys are accepted and ignored. `Options.Type` is the wire-ready form. */
export type OptionsInput = ProviderOptions & typeof Options.Encoded;
export type ProviderOptionsInput = OptionsInput;
export declare const ContextManagement: Schema.Struct<{
    readonly edits: Schema.$Array<Schema.Struct<{
        readonly type: Schema.Literal<"compact_20260112">;
        readonly trigger: Schema.optional<Schema.Struct<{
            readonly type: Schema.Literal<"input_tokens">;
            readonly value: Schema.Int;
        }>>;
        readonly pauseAfterCompaction: Schema.optional<Schema.Boolean>;
        readonly instructions: Schema.optional<Schema.String>;
    }>>;
}>;
export type ContextManagement = typeof ContextManagement.Type;
declare const Thinking: Schema.Union<readonly [Schema.decodeTo<Schema.Struct<{
    readonly display: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"omitted" | "summarized">, import("../schema/options.js").OpenString<"omitted" | "summarized">>>;
    readonly block_binding: Schema.optional<Schema.Struct<{
        readonly prefix_mismatch_behavior: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"drop_block" | "error">, import("../schema/options.js").OpenString<"drop_block" | "error">>>;
    }>>;
    readonly type: Schema.tag<"enabled">;
    readonly budget_tokens: Schema.Number;
}>, Schema.Union<readonly [Schema.Struct<{
    readonly display: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"omitted" | "summarized">, import("../schema/options.js").OpenString<"omitted" | "summarized">>>;
    readonly block_binding: Schema.optional<Schema.Struct<{
        readonly prefix_mismatch_behavior: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"drop_block" | "error">, import("../schema/options.js").OpenString<"drop_block" | "error">>>;
    }>>;
    readonly type: Schema.tag<"enabled">;
    readonly budgetTokens: Schema.Number;
}>, Schema.Struct<{
    readonly display: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"omitted" | "summarized">, import("../schema/options.js").OpenString<"omitted" | "summarized">>>;
    readonly block_binding: Schema.optional<Schema.Struct<{
        readonly prefix_mismatch_behavior: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"drop_block" | "error">, import("../schema/options.js").OpenString<"drop_block" | "error">>>;
    }>>;
    readonly type: Schema.tag<"enabled">;
    readonly budget_tokens: Schema.Number;
}>]>, never, never>, Schema.Struct<{
    readonly display: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"omitted" | "summarized">, import("../schema/options.js").OpenString<"omitted" | "summarized">>>;
    readonly block_binding: Schema.optional<Schema.Struct<{
        readonly prefix_mismatch_behavior: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"drop_block" | "error">, import("../schema/options.js").OpenString<"drop_block" | "error">>>;
    }>>;
    readonly type: Schema.tag<"adaptive">;
}>, Schema.Struct<{
    readonly type: Schema.Literals<readonly ["disabled", "between_tools"]>;
}>]>;
declare const Options: Schema.Struct<{
    /** Advanced in-band compaction. The caller owns checkpoint persistence and recovery. */
    readonly contextManagement: Schema.optional<Schema.Struct<{
        readonly edits: Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literal<"compact_20260112">;
            readonly trigger: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"input_tokens">;
                readonly value: Schema.Int;
            }>>;
            readonly pauseAfterCompaction: Schema.optional<Schema.Boolean>;
            readonly instructions: Schema.optional<Schema.String>;
        }>>;
    }>>;
    readonly thinking: Schema.optional<Schema.Union<readonly [Schema.decodeTo<Schema.Struct<{
        readonly display: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"omitted" | "summarized">, import("../schema/options.js").OpenString<"omitted" | "summarized">>>;
        readonly block_binding: Schema.optional<Schema.Struct<{
            readonly prefix_mismatch_behavior: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"drop_block" | "error">, import("../schema/options.js").OpenString<"drop_block" | "error">>>;
        }>>;
        readonly type: Schema.tag<"enabled">;
        readonly budget_tokens: Schema.Number;
    }>, Schema.Union<readonly [Schema.Struct<{
        readonly display: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"omitted" | "summarized">, import("../schema/options.js").OpenString<"omitted" | "summarized">>>;
        readonly block_binding: Schema.optional<Schema.Struct<{
            readonly prefix_mismatch_behavior: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"drop_block" | "error">, import("../schema/options.js").OpenString<"drop_block" | "error">>>;
        }>>;
        readonly type: Schema.tag<"enabled">;
        readonly budgetTokens: Schema.Number;
    }>, Schema.Struct<{
        readonly display: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"omitted" | "summarized">, import("../schema/options.js").OpenString<"omitted" | "summarized">>>;
        readonly block_binding: Schema.optional<Schema.Struct<{
            readonly prefix_mismatch_behavior: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"drop_block" | "error">, import("../schema/options.js").OpenString<"drop_block" | "error">>>;
        }>>;
        readonly type: Schema.tag<"enabled">;
        readonly budget_tokens: Schema.Number;
    }>]>, never, never>, Schema.Struct<{
        readonly display: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"omitted" | "summarized">, import("../schema/options.js").OpenString<"omitted" | "summarized">>>;
        readonly block_binding: Schema.optional<Schema.Struct<{
            readonly prefix_mismatch_behavior: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"drop_block" | "error">, import("../schema/options.js").OpenString<"drop_block" | "error">>>;
        }>>;
        readonly type: Schema.tag<"adaptive">;
    }>, Schema.Struct<{
        readonly type: Schema.Literals<readonly ["disabled", "between_tools"]>;
    }>]>>;
    readonly effort: Schema.optional<Schema.String>;
    readonly service_tier: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"auto" | "standard_only">, import("../schema/options.js").OpenString<"auto" | "standard_only">>>;
    readonly serviceTier: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"auto" | "standard_only">, import("../schema/options.js").OpenString<"auto" | "standard_only">>>;
    readonly speed: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"fast" | "standard">, import("../schema/options.js").OpenString<"fast" | "standard">>>;
    readonly metadata: Schema.optional<Schema.Struct<{
        readonly user_id: Schema.optional<Schema.NullOr<Schema.String>>;
    }>>;
    readonly container: Schema.optional<Schema.Union<readonly [Schema.String, Schema.Struct<{
        readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly skills: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
    }>]>>;
    readonly inference_geo: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly inferenceGeo: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly cache_control: Schema.optional<Schema.Struct<{
        readonly type: Schema.tag<"ephemeral">;
        readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
    }>>;
    readonly cacheControl: Schema.optional<Schema.Struct<{
        readonly type: Schema.tag<"ephemeral">;
        readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
    }>>;
    readonly output_config: Schema.optional<Schema.Struct<{
        readonly effort: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly format: Schema.optional<Schema.NullOr<Schema.Struct<{
            readonly type: Schema.Literal<"json_schema">;
            readonly schema: Schema.$Record<Schema.String, Schema.Unknown>;
        }>>>;
    }>>;
    readonly outputConfig: Schema.optional<Schema.Struct<{
        readonly effort: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly format: Schema.optional<Schema.NullOr<Schema.Struct<{
            readonly type: Schema.Literal<"json_schema">;
            readonly schema: Schema.$Record<Schema.String, Schema.Unknown>;
        }>>>;
    }>>;
}>;
export declare const AnthropicMessagesBody: Schema.Struct<{
    context_management: Schema.optional<Schema.Struct<{
        readonly edits: Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literal<"compact_20260112">;
            readonly trigger: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"input_tokens">;
                readonly value: Schema.Int;
            }>>;
            readonly pause_after_compaction: Schema.optional<Schema.Boolean>;
            readonly instructions: Schema.optional<Schema.String>;
        }>>;
    }>>;
    model: Schema.String;
    system: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly type: Schema.tag<"text">;
        readonly text: Schema.String;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.tag<"ephemeral">;
            readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
        }>>;
    }>>>;
    messages: Schema.$Array<Schema.toTaggedUnion<"role", readonly [Schema.Struct<{
        readonly role: Schema.Literal<"user">;
        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"image">;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.tag<"base64">;
                readonly media_type: Schema.String;
                readonly data: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"url">;
                readonly url: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"file">;
                readonly file_id: Schema.String;
            }>]>;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
            readonly transformations: Schema.optional<Schema.Struct<{
                readonly oversized_image: Schema.optional<Schema.Literals<readonly ["downsize", "error"]>>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"document">;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.tag<"base64">;
                readonly media_type: Schema.Literal<"application/pdf">;
                readonly data: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"text">;
                readonly media_type: Schema.Literal<"text/plain">;
                readonly data: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"url">;
                readonly url: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"file">;
                readonly file_id: Schema.String;
            }>]>;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
            readonly title: Schema.optional<Schema.String>;
            readonly context: Schema.optional<Schema.String>;
            readonly citations: Schema.optional<Schema.Struct<{
                readonly enabled: Schema.Boolean;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"video">;
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.tag<"base64">;
                readonly media_type: Schema.String;
                readonly data: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"url">;
                readonly url: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"file">;
                readonly file_id: Schema.String;
            }>]>;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"tool_result">;
            readonly tool_use_id: Schema.String;
            readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.tag<"text">;
                readonly text: Schema.String;
                readonly cache_control: Schema.optional<Schema.Struct<{
                    readonly type: Schema.tag<"ephemeral">;
                    readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
                }>>;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"image">;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.tag<"base64">;
                    readonly media_type: Schema.String;
                    readonly data: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.tag<"url">;
                    readonly url: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.tag<"file">;
                    readonly file_id: Schema.String;
                }>]>;
                readonly cache_control: Schema.optional<Schema.Struct<{
                    readonly type: Schema.tag<"ephemeral">;
                    readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
                }>>;
                readonly transformations: Schema.optional<Schema.Struct<{
                    readonly oversized_image: Schema.optional<Schema.Literals<readonly ["downsize", "error"]>>;
                }>>;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"document">;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.tag<"base64">;
                    readonly media_type: Schema.Literal<"application/pdf">;
                    readonly data: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.tag<"text">;
                    readonly media_type: Schema.Literal<"text/plain">;
                    readonly data: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.tag<"url">;
                    readonly url: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.tag<"file">;
                    readonly file_id: Schema.String;
                }>]>;
                readonly cache_control: Schema.optional<Schema.Struct<{
                    readonly type: Schema.tag<"ephemeral">;
                    readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
                }>>;
                readonly title: Schema.optional<Schema.String>;
                readonly context: Schema.optional<Schema.String>;
                readonly citations: Schema.optional<Schema.Struct<{
                    readonly enabled: Schema.Boolean;
                }>>;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"video">;
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.tag<"base64">;
                    readonly media_type: Schema.String;
                    readonly data: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.tag<"url">;
                    readonly url: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.tag<"file">;
                    readonly file_id: Schema.String;
                }>]>;
                readonly cache_control: Schema.optional<Schema.Struct<{
                    readonly type: Schema.tag<"ephemeral">;
                    readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
                }>>;
            }>]>>]>;
            readonly is_error: Schema.optional<Schema.Boolean>;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
        }>]>>;
    }>, Schema.Struct<{
        readonly role: Schema.Literal<"assistant">;
        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"compaction">;
            readonly content: Schema.NullOr<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"thinking">;
            readonly thinking: Schema.String;
            readonly signature: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"redacted_thinking">;
            readonly data: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"tool_use">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly input: Schema.Unknown;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"server_tool_use">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly input: Schema.Unknown;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.Literals<readonly ["web_search_tool_result", "code_execution_tool_result", "web_fetch_tool_result"]>;
            readonly tool_use_id: Schema.String;
            readonly content: Schema.Unknown;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
        }>]>>;
    }>, Schema.Struct<{
        readonly role: Schema.Literal<"system">;
        readonly content: Schema.$Array<Schema.Struct<{
            readonly type: Schema.tag<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.tag<"ephemeral">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>>;
        }>>;
        readonly output_config: Schema.optional<Schema.Struct<{
            readonly effort: Schema.String;
        }>>;
    }>]>>;
    tools: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
        readonly description: Schema.String;
        readonly input_schema: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.tag<"ephemeral">;
            readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
        }>>;
    }>>>;
    tool_choice: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literals<readonly ["auto", "any", "none"]>;
        readonly disable_parallel_tool_use: Schema.optional<Schema.Boolean>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"tool">;
        readonly name: Schema.String;
        readonly disable_parallel_tool_use: Schema.optional<Schema.Boolean>;
    }>]>>;
    stream: Schema.Literal<true>;
    max_tokens: Schema.Number;
    temperature: Schema.optional<Schema.Number>;
    top_p: Schema.optional<Schema.Number>;
    top_k: Schema.optional<Schema.Number>;
    stop_sequences: Schema.optional<Schema.$Array<Schema.String>>;
    thinking: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly display: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"omitted" | "summarized">, import("../schema/options.js").OpenString<"omitted" | "summarized">>>;
        readonly block_binding: Schema.optional<Schema.Struct<{
            readonly prefix_mismatch_behavior: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"drop_block" | "error">, import("../schema/options.js").OpenString<"drop_block" | "error">>>;
        }>>;
        readonly type: Schema.tag<"enabled">;
        readonly budget_tokens: Schema.Number;
    }>, Schema.Struct<{
        readonly display: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"omitted" | "summarized">, import("../schema/options.js").OpenString<"omitted" | "summarized">>>;
        readonly block_binding: Schema.optional<Schema.Struct<{
            readonly prefix_mismatch_behavior: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"drop_block" | "error">, import("../schema/options.js").OpenString<"drop_block" | "error">>>;
        }>>;
        readonly type: Schema.tag<"adaptive">;
    }>, Schema.Struct<{
        readonly type: Schema.Literals<readonly ["disabled", "between_tools"]>;
    }>]>>;
    output_config: Schema.optional<Schema.Struct<{
        readonly effort: Schema.optional<Schema.String>;
        readonly format: Schema.optional<Schema.NullOr<Schema.Struct<{
            readonly type: Schema.Literal<"json_schema">;
            readonly schema: Schema.$Record<Schema.String, Schema.Unknown>;
        }>>>;
    }>>;
    cache_control: Schema.optional<Schema.Struct<{
        readonly type: Schema.tag<"ephemeral">;
        readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
    }>>;
    container: Schema.optional<Schema.NullOr<Schema.Union<readonly [Schema.String, Schema.Struct<{
        readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly skills: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
    }>]>>>;
    inference_geo: Schema.optional<Schema.NullOr<Schema.String>>;
    metadata: Schema.optional<Schema.Struct<{
        readonly user_id: Schema.optional<Schema.NullOr<Schema.String>>;
    }>>;
    service_tier: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"auto" | "standard_only">, import("../schema/options.js").OpenString<"auto" | "standard_only">>>;
    speed: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"fast" | "standard">, import("../schema/options.js").OpenString<"fast" | "standard">>>;
}>;
export type AnthropicMessagesBody = Schema.Schema.Type<typeof AnthropicMessagesBody>;
/**
 * The Anthropic Messages protocol — request body construction, body schema,
 * and the streaming-event state machine shared by Anthropic-compatible and
 * Vertex-hosted Messages routes.
 */
export declare const protocol: Protocol<{
    readonly context_management?: {
        readonly edits: readonly {
            readonly type: "compact_20260112";
            readonly trigger?: {
                readonly type: "input_tokens";
                readonly value: number;
            } | undefined;
            readonly pause_after_compaction?: boolean | undefined;
            readonly instructions?: string | undefined;
        }[];
    } | undefined;
    readonly model: string;
    readonly system?: readonly {
        readonly type: "text";
        readonly text: string;
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly messages: readonly ({
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "image";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly transformations?: {
                readonly oversized_image?: "downsize" | "error" | undefined;
            } | undefined;
        } | {
            readonly type: "video";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "document";
            readonly source: {
                readonly type: "base64";
                readonly media_type: "application/pdf";
                readonly data: string;
            } | {
                readonly type: "text";
                readonly media_type: "text/plain";
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly title?: string | undefined;
            readonly context?: string | undefined;
            readonly citations?: {
                readonly enabled: boolean;
            } | undefined;
        } | {
            readonly type: "tool_result";
            readonly tool_use_id: string;
            readonly content: string | readonly ({
                readonly type: "text";
                readonly text: string;
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "image";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly transformations?: {
                    readonly oversized_image?: "downsize" | "error" | undefined;
                } | undefined;
            } | {
                readonly type: "video";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "document";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: "application/pdf";
                    readonly data: string;
                } | {
                    readonly type: "text";
                    readonly media_type: "text/plain";
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly title?: string | undefined;
                readonly context?: string | undefined;
                readonly citations?: {
                    readonly enabled: boolean;
                } | undefined;
            })[];
            readonly is_error?: boolean | undefined;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: readonly ({
            readonly type: "compaction";
            readonly content: string | null;
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "thinking";
            readonly thinking: string;
            readonly signature: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "redacted_thinking";
            readonly data: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "server_tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "code_execution_tool_result" | "web_fetch_tool_result" | "web_search_tool_result";
            readonly tool_use_id: string;
            readonly content: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "system";
        readonly content: readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        }[];
        readonly output_config?: {
            readonly effort: string;
        } | undefined;
    })[];
    readonly tools?: readonly {
        readonly name: string;
        readonly description: string;
        readonly input_schema: {
            readonly [x: string]: unknown;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly tool_choice?: {
        readonly type: "any" | "auto" | "none";
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | {
        readonly type: "tool";
        readonly name: string;
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | undefined;
    readonly stream: true;
    readonly max_tokens: number;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly top_k?: number | undefined;
    readonly stop_sequences?: readonly string[] | undefined;
    readonly thinking?: {
        readonly type: "between_tools" | "disabled";
    } | {
        readonly display?: import("../schema/options.js").OpenString<"omitted" | "summarized"> | undefined;
        readonly block_binding?: {
            readonly prefix_mismatch_behavior?: import("../schema/options.js").OpenString<"drop_block" | "error"> | undefined;
        } | undefined;
        readonly type: "enabled";
        readonly budget_tokens: number;
    } | {
        readonly display?: import("../schema/options.js").OpenString<"omitted" | "summarized"> | undefined;
        readonly block_binding?: {
            readonly prefix_mismatch_behavior?: import("../schema/options.js").OpenString<"drop_block" | "error"> | undefined;
        } | undefined;
        readonly type: "adaptive";
    } | undefined;
    readonly output_config?: {
        readonly effort?: string | undefined;
        readonly format?: {
            readonly type: "json_schema";
            readonly schema: {
                readonly [x: string]: unknown;
            };
        } | null | undefined;
    } | undefined;
    readonly cache_control?: {
        readonly type: "ephemeral";
        readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
    } | undefined;
    readonly container?: string | {
        readonly id?: string | null | undefined;
        readonly skills?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | null | undefined;
    readonly inference_geo?: string | null | undefined;
    readonly metadata?: {
        readonly user_id?: string | null | undefined;
    } | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "standard_only"> | undefined;
    readonly speed?: import("../schema/options.js").OpenString<"fast" | "standard"> | undefined;
}, string, {
    readonly [x: string]: unknown;
    readonly type: string;
    readonly index?: number | undefined;
    readonly message?: {
        readonly [x: string]: unknown;
        readonly usage?: {
            readonly [x: string]: unknown;
            readonly input_tokens?: number | null | undefined;
            readonly output_tokens?: number | undefined;
            readonly cache_creation_input_tokens?: number | null | undefined;
            readonly cache_read_input_tokens?: number | null | undefined;
            readonly server_tool_use?: {
                readonly [x: string]: unknown;
                readonly web_search_requests?: number | undefined;
            } | null | undefined;
            readonly output_tokens_details?: {
                readonly [x: string]: unknown;
                readonly thinking_tokens?: number | undefined;
            } | null | undefined;
            readonly iterations?: readonly {
                readonly [x: string]: unknown;
                readonly input_tokens?: number | null | undefined;
                readonly output_tokens?: number | undefined;
                readonly cache_creation_input_tokens?: number | null | undefined;
                readonly cache_read_input_tokens?: number | null | undefined;
                readonly server_tool_use?: {
                    readonly [x: string]: unknown;
                    readonly web_search_requests?: number | undefined;
                } | null | undefined;
                readonly output_tokens_details?: {
                    readonly [x: string]: unknown;
                    readonly thinking_tokens?: number | undefined;
                } | null | undefined;
            }[] | undefined;
        } | undefined;
    } | undefined;
    readonly content_block?: unknown;
    readonly delta?: unknown;
    readonly usage?: {
        readonly [x: string]: unknown;
        readonly input_tokens?: number | null | undefined;
        readonly output_tokens?: number | undefined;
        readonly cache_creation_input_tokens?: number | null | undefined;
        readonly cache_read_input_tokens?: number | null | undefined;
        readonly server_tool_use?: {
            readonly [x: string]: unknown;
            readonly web_search_requests?: number | undefined;
        } | null | undefined;
        readonly output_tokens_details?: {
            readonly [x: string]: unknown;
            readonly thinking_tokens?: number | undefined;
        } | null | undefined;
        readonly iterations?: readonly {
            readonly [x: string]: unknown;
            readonly input_tokens?: number | null | undefined;
            readonly output_tokens?: number | undefined;
            readonly cache_creation_input_tokens?: number | null | undefined;
            readonly cache_read_input_tokens?: number | null | undefined;
            readonly server_tool_use?: {
                readonly [x: string]: unknown;
                readonly web_search_requests?: number | undefined;
            } | null | undefined;
            readonly output_tokens_details?: {
                readonly [x: string]: unknown;
                readonly thinking_tokens?: number | undefined;
            } | null | undefined;
        }[] | undefined;
    } | undefined;
    readonly error?: {
        readonly [x: string]: unknown;
        readonly type?: string | undefined;
        readonly message?: string | undefined;
    } | undefined;
}, {
    provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    compactions: {};
    providerMetadataKey: string;
    tools: Partial<Record<number, ToolStream.PendingTool>>;
    reasoningSignatures: {};
    lifecycle: Lifecycle.State;
}>;
export declare const transport: <Body extends Pick<AnthropicMessagesBody, "messages" | "context_management" | "thinking" | "speed">>() => {
    with: (patch: Partial<HttpTransport.HttpJsonInput<Body, string>>) => HttpTransport.HttpJsonTransport<Body, string>;
    id: string;
    execute: (prepared: HttpTransport.HttpPrepared<string>, request: LLMRequest, runtime: import("../route/transport/index.js").TransportRuntime, options?: import("../route/transport/index.js").TransportExecuteOptions) => Effect.Effect<import("../route/transport/index.js").TransportExecution<string>, AIError, import("effect/Scope").Scope>;
    prepare: (input: Parameters<(input: import("../route/transport/index.js").TransportPrepareInput<Body>) => Effect.Effect<HttpTransport.HttpPrepared<string>, AIError, never>>[0]) => Effect.Effect<HttpTransport.HttpPrepared<string>, AIError, never>;
};
export declare const route: Route<{
    readonly context_management?: {
        readonly edits: readonly {
            readonly type: "compact_20260112";
            readonly trigger?: {
                readonly type: "input_tokens";
                readonly value: number;
            } | undefined;
            readonly pause_after_compaction?: boolean | undefined;
            readonly instructions?: string | undefined;
        }[];
    } | undefined;
    readonly model: string;
    readonly system?: readonly {
        readonly type: "text";
        readonly text: string;
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly messages: readonly ({
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "image";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly transformations?: {
                readonly oversized_image?: "downsize" | "error" | undefined;
            } | undefined;
        } | {
            readonly type: "video";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "document";
            readonly source: {
                readonly type: "base64";
                readonly media_type: "application/pdf";
                readonly data: string;
            } | {
                readonly type: "text";
                readonly media_type: "text/plain";
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly title?: string | undefined;
            readonly context?: string | undefined;
            readonly citations?: {
                readonly enabled: boolean;
            } | undefined;
        } | {
            readonly type: "tool_result";
            readonly tool_use_id: string;
            readonly content: string | readonly ({
                readonly type: "text";
                readonly text: string;
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "image";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly transformations?: {
                    readonly oversized_image?: "downsize" | "error" | undefined;
                } | undefined;
            } | {
                readonly type: "video";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "document";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: "application/pdf";
                    readonly data: string;
                } | {
                    readonly type: "text";
                    readonly media_type: "text/plain";
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly title?: string | undefined;
                readonly context?: string | undefined;
                readonly citations?: {
                    readonly enabled: boolean;
                } | undefined;
            })[];
            readonly is_error?: boolean | undefined;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: readonly ({
            readonly type: "compaction";
            readonly content: string | null;
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "thinking";
            readonly thinking: string;
            readonly signature: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "redacted_thinking";
            readonly data: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "server_tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "code_execution_tool_result" | "web_fetch_tool_result" | "web_search_tool_result";
            readonly tool_use_id: string;
            readonly content: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "system";
        readonly content: readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        }[];
        readonly output_config?: {
            readonly effort: string;
        } | undefined;
    })[];
    readonly tools?: readonly {
        readonly name: string;
        readonly description: string;
        readonly input_schema: {
            readonly [x: string]: unknown;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly tool_choice?: {
        readonly type: "any" | "auto" | "none";
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | {
        readonly type: "tool";
        readonly name: string;
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | undefined;
    readonly stream: true;
    readonly max_tokens: number;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly top_k?: number | undefined;
    readonly stop_sequences?: readonly string[] | undefined;
    readonly thinking?: {
        readonly type: "between_tools" | "disabled";
    } | {
        readonly display?: import("../schema/options.js").OpenString<"omitted" | "summarized"> | undefined;
        readonly block_binding?: {
            readonly prefix_mismatch_behavior?: import("../schema/options.js").OpenString<"drop_block" | "error"> | undefined;
        } | undefined;
        readonly type: "enabled";
        readonly budget_tokens: number;
    } | {
        readonly display?: import("../schema/options.js").OpenString<"omitted" | "summarized"> | undefined;
        readonly block_binding?: {
            readonly prefix_mismatch_behavior?: import("../schema/options.js").OpenString<"drop_block" | "error"> | undefined;
        } | undefined;
        readonly type: "adaptive";
    } | undefined;
    readonly output_config?: {
        readonly effort?: string | undefined;
        readonly format?: {
            readonly type: "json_schema";
            readonly schema: {
                readonly [x: string]: unknown;
            };
        } | null | undefined;
    } | undefined;
    readonly cache_control?: {
        readonly type: "ephemeral";
        readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
    } | undefined;
    readonly container?: string | {
        readonly id?: string | null | undefined;
        readonly skills?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | null | undefined;
    readonly inference_geo?: string | null | undefined;
    readonly metadata?: {
        readonly user_id?: string | null | undefined;
    } | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "standard_only"> | undefined;
    readonly speed?: import("../schema/options.js").OpenString<"fast" | "standard"> | undefined;
}, HttpTransport.HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>;
export * as AnthropicMessages from "./anthropic-messages.js";
