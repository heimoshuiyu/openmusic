import { ImageModel, ImageResponse, type ImageRequest } from "../image.js";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type OpenString } from "../schema/index.js";
export declare const DEFAULT_BASE_URL = "https://api.minimax.io/v1";
export declare const PATH = "/image_generation";
/** Provider-native options. Common `aspect` and `resolution` lower to `aspect_ratio` or `width` and `height`. */
export type MiniMaxImageOptions = {
    /** Defaults to `base64`, which returns the bytes inline; `url` links expire after 24 hours. */
    readonly responseFormat?: OpenString<"url" | "base64">;
    readonly seed?: number;
    readonly promptOptimizer?: boolean;
    /** Native preset; it replaces `aspect` and `resolution`. */
    readonly aspect_ratio?: string;
    /** Native size, 512 to 2048 in steps of 8 (`image-01` only); it replaces `aspect` and `resolution`. */
    readonly width?: number;
    readonly height?: number;
} & Record<string, unknown>;
export type Request = ImageRequest<ImageModel<MiniMaxImageOptions>>;
export declare const protocol: MediaProtocol.Inline<Request, ImageResponse>;
export declare const model: (input: MediaRoute.ModelInput) => ImageModel<MiniMaxImageOptions>;
export declare const MiniMaxImages: {
    readonly protocol: MediaProtocol.Inline<Request, ImageResponse>;
    readonly model: typeof model;
};
