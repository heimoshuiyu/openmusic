import { Schema } from "effect";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type OpenString } from "../schema/index.js";
import { VideoModel, VideoResponse, type VideoRequest } from "../video.js";
export declare const DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta";
/** Provider-native `parameters`. Common fields (`aspect`, `resolution`, `durationSeconds`, `seed`) live on the request. */
export type GoogleVideoOptions = {
    readonly personGeneration?: OpenString<"allow_all" | "allow_adult" | "dont_allow">;
} & Record<string, unknown>;
export type Request = VideoRequest<VideoModel<GoogleVideoOptions>>;
/** The long-running operation name, e.g. `models/veo-3.1-generate-preview/operations/abc123`. */
export declare const Token: Schema.Struct<{
    readonly operation: Schema.String;
}>;
export type Token = Schema.Schema.Type<typeof Token>;
export declare const protocol: MediaProtocol.Queued<Request, VideoResponse, {
    readonly operation: string;
}>;
export declare const model: (input: MediaRoute.ModelInput) => VideoModel<GoogleVideoOptions>;
export declare const GoogleVideo: {
    readonly protocol: MediaProtocol.Queued<Request, VideoResponse, {
        readonly operation: string;
    }>;
    readonly model: typeof model;
};
