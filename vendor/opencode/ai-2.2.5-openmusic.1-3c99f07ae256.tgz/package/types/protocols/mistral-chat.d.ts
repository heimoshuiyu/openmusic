import { Effect, Schema } from "effect";
import { Route } from "../route/client.js";
import { Framing } from "../route/framing.js";
import { Protocol } from "../route/protocol.js";
import { HttpTransport } from "../route/transport/index.js";
import { AIError, LLMEvent, Usage, type FinishReasonDetails, type LLMRequest } from "../schema/index.js";
import { Lifecycle } from "./utils/lifecycle.js";
import { ToolStream } from "./utils/tool-stream.js";
export declare const DEFAULT_BASE_URL = "https://api.mistral.ai/v1";
export declare const PATH = "/chat/completions";
declare const MistralThinkingUnit: Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.optional<Schema.String>;
    readonly text: Schema.optional<Schema.String>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
type MistralThinkingUnit = Schema.Schema.Type<typeof MistralThinkingUnit>;
declare const MistralThinkingContent: Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.Literal<"thinking">;
    readonly thinking: Schema.$Array<Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.optional<Schema.String>;
        readonly text: Schema.optional<Schema.String>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
type MistralThinkingContent = Schema.Schema.Type<typeof MistralThinkingContent>;
declare const ReasoningEffort: Schema.declare<import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal" | "none" | "xhigh">, import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal" | "none" | "xhigh">>;
export type ReasoningEffort = typeof ReasoningEffort.Type;
declare const MistralOptions: Schema.Struct<{
    readonly safePrompt: Schema.optional<Schema.Boolean>;
    readonly documentImageLimit: Schema.optional<Schema.Number>;
    readonly documentPageLimit: Schema.optional<Schema.Number>;
    readonly parallelToolCalls: Schema.optional<Schema.Boolean>;
    readonly reasoningEffort: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal" | "none" | "xhigh">, import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal" | "none" | "xhigh">>>;
    readonly promptMode: Schema.optional<Schema.Literal<"reasoning">>;
    readonly promptCacheKey: Schema.optional<Schema.String>;
}>;
export type ProviderOptionsInput = typeof MistralOptions.Type & {
    readonly [key: string]: unknown;
};
export declare const MistralBody: Schema.Struct<{
    readonly model: Schema.String;
    readonly messages: Schema.$Array<Schema.toTaggedUnion<"role", readonly [Schema.Struct<{
        readonly role: Schema.Literal<"system">;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>>]>;
    }>, Schema.Struct<{
        readonly role: Schema.Literal<"user">;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"image_url">;
            readonly image_url: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"document_url">;
            readonly document_url: Schema.String;
        }>]>>]>;
    }>, Schema.Struct<{
        readonly role: Schema.Literal<"assistant">;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.StructWithRest<Schema.Struct<{
            readonly type: Schema.Literal<"thinking">;
            readonly thinking: Schema.$Array<Schema.StructWithRest<Schema.Struct<{
                readonly type: Schema.optional<Schema.String>;
                readonly text: Schema.optional<Schema.String>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>>]>;
        readonly tool_calls: Schema.optional<Schema.$Array<Schema.Struct<{
            readonly id: Schema.String;
            readonly type: Schema.Literal<"function">;
            readonly function: Schema.Struct<{
                readonly name: Schema.String;
                readonly arguments: Schema.String;
            }>;
        }>>>;
        readonly prefix: Schema.optional<Schema.Literal<true>>;
    }>, Schema.Struct<{
        readonly role: Schema.Literal<"tool">;
        readonly tool_call_id: Schema.String;
        readonly name: Schema.String;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"image_url">;
            readonly image_url: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"document_url">;
            readonly document_url: Schema.String;
        }>]>>]>;
    }>]>>;
    readonly tools: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly type: Schema.Literal<"function">;
        readonly function: Schema.Struct<{
            readonly name: Schema.String;
            readonly description: Schema.String;
            readonly parameters: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly strict: Schema.Literal<false>;
        }>;
    }>>>;
    readonly tool_choice: Schema.optional<Schema.Union<readonly [Schema.Literals<readonly ["auto", "none", "any"]>, Schema.Struct<{
        readonly type: Schema.Literal<"function">;
        readonly function: Schema.Struct<{
            readonly name: Schema.String;
        }>;
    }>]>>;
    readonly stream: Schema.Literal<true>;
    readonly max_tokens: Schema.optional<Schema.Number>;
    readonly random_seed: Schema.optional<Schema.Number>;
    readonly temperature: Schema.optional<Schema.Number>;
    readonly top_p: Schema.optional<Schema.Number>;
    readonly frequency_penalty: Schema.optional<Schema.Number>;
    readonly presence_penalty: Schema.optional<Schema.Number>;
    readonly stop: Schema.optional<Schema.$Array<Schema.String>>;
    readonly prompt_cache_key: Schema.optional<Schema.String>;
    readonly safe_prompt: Schema.optional<Schema.Boolean>;
    readonly document_image_limit: Schema.optional<Schema.Number>;
    readonly document_page_limit: Schema.optional<Schema.Number>;
    readonly parallel_tool_calls: Schema.optional<Schema.Boolean>;
    readonly reasoning_effort: Schema.optional<Schema.String>;
    readonly prompt_mode: Schema.optional<Schema.Literal<"reasoning">>;
}>;
export type MistralBody = Schema.Schema.Type<typeof MistralBody>;
export declare const fromRequest: (request: LLMRequest<import("../schema/options.js").LanguageModel<{
    readonly [x: string]: unknown;
}, import("../route/client.js").CompactionOperations | undefined>>) => Effect.Effect<{
    model: string & import("effect/Brand").Brand<"AI.ModelID">;
    messages: ({
        readonly role: "system";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
        }[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly name: string;
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly [x: string]: unknown;
            readonly type: "thinking";
            readonly thinking: readonly {
                readonly [x: string]: unknown;
                readonly type?: string | undefined;
                readonly text?: string | undefined;
            }[];
        })[];
        readonly tool_calls?: readonly {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
        }[] | undefined;
        readonly prefix?: true | undefined;
    })[];
    tools: {
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict: false;
        };
    }[] | undefined;
    tool_choice: "any" | "auto" | "none" | {
        type: "function";
        function: {
            name: string;
        };
    } | undefined;
    stream: true;
    max_tokens: number | undefined;
    random_seed: number | undefined;
    temperature: number | undefined;
    top_p: number | undefined;
    frequency_penalty: number | undefined;
    presence_penalty: number | undefined;
    stop: readonly string[] | undefined;
    prompt_cache_key: string | undefined;
    safe_prompt: boolean | undefined;
    document_image_limit: number | undefined;
    document_page_limit: number | undefined;
    parallel_tool_calls: boolean | undefined;
    reasoning_effort: import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal" | "none" | "xhigh"> | undefined;
    prompt_mode: "reasoning" | undefined;
}, AIError, never>;
type ToolKey = string | number;
interface PendingTool {
    readonly id: string;
    readonly name?: string;
    readonly input: string;
}
interface ActiveContent {
    readonly type: "text" | "reasoning";
    readonly id: string;
    readonly thinking?: MistralThinkingContent;
    readonly thinkingUnits?: MistralThinkingUnit[];
}
export interface ParserState {
    readonly tools: ToolStream.State<ToolKey>;
    readonly pendingTools: Partial<Record<ToolKey, PendingTool>>;
    readonly toolIDs: ReadonlyMap<string, string>;
    readonly usedToolIDs: ReadonlySet<string>;
    readonly completedTools: ReadonlyArray<LLMEvent>;
    readonly latestToolKey?: ToolKey;
    readonly generatedTools: number;
    readonly lifecycle: Lifecycle.State;
    readonly active?: ActiveContent;
    readonly nextContent: number;
    readonly usage?: Usage;
    readonly finishReason?: FinishReasonDetails;
}
export declare const protocol: Protocol<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
        }[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly name: string;
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly [x: string]: unknown;
            readonly type: "thinking";
            readonly thinking: readonly {
                readonly [x: string]: unknown;
                readonly type?: string | undefined;
                readonly text?: string | undefined;
            }[];
        })[];
        readonly tool_calls?: readonly {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
        }[] | undefined;
        readonly prefix?: true | undefined;
    })[];
    readonly tools?: readonly {
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict: false;
        };
    }[] | undefined;
    readonly tool_choice?: "any" | "auto" | "none" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly max_tokens?: number | undefined;
    readonly random_seed?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly stop?: readonly string[] | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly safe_prompt?: boolean | undefined;
    readonly document_image_limit?: number | undefined;
    readonly document_page_limit?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly reasoning_effort?: string | undefined;
    readonly prompt_mode?: "reasoning" | undefined;
}, string, "[DONE]" | {
    readonly [x: string]: unknown;
    readonly choices?: readonly {
        readonly [x: string]: unknown;
        readonly delta?: {
            readonly [x: string]: unknown;
            readonly content?: string | readonly {
                readonly [x: string]: unknown;
                readonly type: string;
                readonly text?: string | null | undefined;
                readonly thinking?: unknown;
            }[] | null | undefined;
            readonly tool_calls?: readonly {
                readonly index?: number | null | undefined;
                readonly id?: string | null | undefined;
                readonly function?: {
                    readonly name?: string | null | undefined;
                    readonly arguments?: string | {
                        readonly [x: string]: unknown;
                    } | null | undefined;
                } | null | undefined;
            }[] | null | undefined;
        } | null | undefined;
        readonly finish_reason?: string | null | undefined;
    }[] | null | undefined;
    readonly usage?: {
        readonly [x: string]: unknown;
        readonly prompt_tokens?: number | null | undefined;
        readonly completion_tokens?: number | null | undefined;
        readonly total_tokens?: number | null | undefined;
        readonly num_cached_tokens?: number | null | undefined;
        readonly prompt_token_details?: {
            readonly [x: string]: unknown;
            readonly cached_tokens?: number | null | undefined;
        } | null | undefined;
        readonly prompt_tokens_details?: {
            readonly [x: string]: unknown;
            readonly cached_tokens?: number | null | undefined;
        } | null | undefined;
    } | null | undefined;
    readonly error?: {
        readonly [x: string]: unknown;
        readonly message: string;
        readonly code?: string | number | null | undefined;
    } | null | undefined;
}, ParserState>;
export declare const framing: Framing.Definition<string>;
export declare const httpTransport: HttpTransport.HttpJsonTransport<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
        }[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly name: string;
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly [x: string]: unknown;
            readonly type: "thinking";
            readonly thinking: readonly {
                readonly [x: string]: unknown;
                readonly type?: string | undefined;
                readonly text?: string | undefined;
            }[];
        })[];
        readonly tool_calls?: readonly {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
        }[] | undefined;
        readonly prefix?: true | undefined;
    })[];
    readonly tools?: readonly {
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict: false;
        };
    }[] | undefined;
    readonly tool_choice?: "any" | "auto" | "none" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly max_tokens?: number | undefined;
    readonly random_seed?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly stop?: readonly string[] | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly safe_prompt?: boolean | undefined;
    readonly document_image_limit?: number | undefined;
    readonly document_page_limit?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly reasoning_effort?: string | undefined;
    readonly prompt_mode?: "reasoning" | undefined;
}, string>;
export declare const route: Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
        }[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly name: string;
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly [x: string]: unknown;
            readonly type: "thinking";
            readonly thinking: readonly {
                readonly [x: string]: unknown;
                readonly type?: string | undefined;
                readonly text?: string | undefined;
            }[];
        })[];
        readonly tool_calls?: readonly {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
        }[] | undefined;
        readonly prefix?: true | undefined;
    })[];
    readonly tools?: readonly {
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict: false;
        };
    }[] | undefined;
    readonly tool_choice?: "any" | "auto" | "none" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly max_tokens?: number | undefined;
    readonly random_seed?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly stop?: readonly string[] | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly safe_prompt?: boolean | undefined;
    readonly document_image_limit?: number | undefined;
    readonly document_page_limit?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly reasoning_effort?: string | undefined;
    readonly prompt_mode?: "reasoning" | undefined;
}, HttpTransport.HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>;
export * as MistralChat from "./mistral-chat.js";
