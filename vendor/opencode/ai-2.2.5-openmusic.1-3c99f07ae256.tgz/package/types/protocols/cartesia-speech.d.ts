import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type OpenString } from "../schema/index.js";
import { SpeechModel, type SpeechRequest } from "../speech.js";
import { SpeechStream } from "./utils/speech-stream.js";
export declare const DEFAULT_BASE_URL = "https://api.cartesia.ai";
export declare const API_VERSION = "2026-08-14";
export declare const BYTES_PATH = "/tts/bytes";
export declare const SSE_PATH = "/tts/sse";
export type CartesiaEncoding = SpeechStream.PcmEncoding;
export type CartesiaSpeechOptions = {
    readonly sampleRate?: 8000 | 16000 | 22050 | 24000 | 44100 | 48000;
    readonly bitRate?: 32000 | 64000 | 96000 | 128000 | 192000;
    readonly encoding?: CartesiaEncoding;
    readonly generation_config?: {
        readonly volume?: number;
        readonly emotion?: OpenString<"neutral" | "calm" | "angry" | "content" | "sad" | "scared">;
    };
    readonly pronunciation_dict_id?: string;
} & Record<string, unknown>;
export type Request = SpeechRequest<SpeechModel<CartesiaSpeechOptions>>;
interface State extends SpeechStream.Audio {
    readonly done: boolean;
}
export declare const protocol: MediaProtocol.Streamed<Request, {
    readonly type: "audio-delta";
    readonly chunk: Uint8Array<ArrayBufferLike>;
} | {
    readonly type: "timestamps";
    readonly items: readonly {
        readonly text: string;
        readonly startSeconds: number;
        readonly endSeconds: number;
    }[];
} | {
    readonly type: "generation-queued";
    readonly id: string;
    readonly position?: number | undefined;
} | {
    readonly type: "generation-progress";
    readonly id: string;
    readonly progress?: number | undefined;
} | {
    readonly type: "finish";
    readonly audio: import("../media.js").Asset;
    readonly usage?: {
        readonly type: "seconds";
        readonly seconds: number;
    } | {
        readonly type: "characters";
        readonly characters: number;
    } | {
        readonly type: "credits";
        readonly credits: number;
    } | {
        readonly type: "compute";
        readonly seconds: number;
    } | {
        readonly type: "tokens";
        readonly input?: number | undefined;
        readonly output?: number | undefined;
        readonly total?: number | undefined;
        readonly details?: {
            readonly [x: string]: unknown;
        } | undefined;
    } | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
}, string | Uint8Array<ArrayBufferLike>, State>;
export declare const model: (input: MediaRoute.ModelInput) => SpeechModel<CartesiaSpeechOptions>;
export declare const CartesiaSpeech: {
    readonly protocol: MediaProtocol.Streamed<Request, {
        readonly type: "audio-delta";
        readonly chunk: Uint8Array<ArrayBufferLike>;
    } | {
        readonly type: "timestamps";
        readonly items: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
        }[];
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly type: "finish";
        readonly audio: import("../media.js").Asset;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, string | Uint8Array<ArrayBufferLike>, State>;
    readonly model: typeof model;
};
export {};
