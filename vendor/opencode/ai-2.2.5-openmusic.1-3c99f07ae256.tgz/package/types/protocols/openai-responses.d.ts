import { Schema } from "effect";
import { Route } from "../route/client.js";
import { Protocol } from "../route/protocol.js";
import { HttpTransport } from "../route/transport/index.js";
import { OpenResponses } from "./open-responses.js";
import { OpenResponsesOptions } from "./utils/open-responses-options.js";
export declare const DEFAULT_BASE_URL = "https://api.openai.com/v1";
export declare const PATH = "/responses";
export declare const ContextManagement: Schema.$Array<Schema.Struct<{
    readonly type: Schema.Literal<"compaction">;
    readonly compactThreshold: Schema.optional<Schema.Int>;
}>>;
export type ContextManagement = typeof ContextManagement.Type;
export declare const ReasoningMode: Schema.declare<import("../schema/options.js").OpenString<"pro" | "standard">, import("../schema/options.js").OpenString<"pro" | "standard">>;
export type ReasoningMode = typeof ReasoningMode.Type;
export declare const ReasoningContext: Schema.declare<import("../schema/options.js").OpenString<"all_turns" | "auto" | "current_turn">, import("../schema/options.js").OpenString<"all_turns" | "auto" | "current_turn">>;
export type ReasoningContext = typeof ReasoningContext.Type;
declare const OpenAIResponsesBody: Schema.Struct<{
    readonly model: Schema.String;
    readonly input: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"compaction">;
        readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly encrypted_content: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"configuration_update">;
        readonly reasoning: Schema.Struct<{
            readonly effort: Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly role: Schema.tag<"system">;
        readonly content: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly role: Schema.tag<"developer">;
        readonly content: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly role: Schema.tag<"user">;
        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"input_text">;
            readonly text: Schema.String;
        }>, Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"input_image">;
            readonly image_url: Schema.String;
            readonly detail: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_file">;
            readonly filename: Schema.optional<Schema.String>;
            readonly detail: Schema.optional<Schema.String>;
            readonly file_data: Schema.optional<Schema.String>;
            readonly file_url: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_video">;
            readonly video_url: Schema.String;
        }>]>]>>;
        readonly id: Schema.optional<Schema.String>;
        readonly status: Schema.optional<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"message">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly role: Schema.tag<"assistant">;
        readonly content: Schema.$Array<Schema.Struct<{
            readonly type: Schema.tag<"output_text">;
            readonly text: Schema.String;
        }>>;
        readonly phase: Schema.optionalKey<Schema.NullOr<Schema.Literals<readonly ["commentary", "final_answer"]>>>;
        readonly status: Schema.optional<Schema.String>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"reasoning">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly summary: Schema.$Array<Schema.Struct<{
            readonly type: Schema.tag<"summary_text">;
            readonly text: Schema.String;
        }>>;
        readonly encrypted_content: Schema.optional<Schema.NullOr<Schema.String>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"function_call">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly call_id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly arguments: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literals<readonly ["function_call_output", "custom_tool_call_output"]>;
        readonly call_id: Schema.String;
        readonly output: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"input_text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_image">;
            readonly image_url: Schema.String;
            readonly detail: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_file">;
            readonly filename: Schema.optional<Schema.String>;
            readonly detail: Schema.optional<Schema.String>;
            readonly file_data: Schema.optional<Schema.String>;
            readonly file_url: Schema.optional<Schema.String>;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"input_video">;
            readonly video_url: Schema.String;
        }>]>>]>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom_tool_call">;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly call_id: Schema.String;
        readonly name: Schema.String;
        readonly input: Schema.String;
    }>, Schema.Union<readonly [Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"web_search_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly action: Schema.optional<Schema.NullOr<Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"file_search_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly queries: Schema.optional<Schema.$Array<Schema.String>>;
        readonly results: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"code_interpreter_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly code: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly container_id: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly outputs: Schema.optional<Schema.NullOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.tag<"mcp_call">;
        readonly id: Schema.String;
        readonly status: Schema.optional<Schema.String>;
        readonly server_label: Schema.optional<Schema.String>;
        readonly name: Schema.optional<Schema.String>;
        readonly arguments: Schema.optional<Schema.String>;
        readonly output: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly error: Schema.optional<Schema.Unknown>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>, Schema.StructWithRest<Schema.Struct<{
        readonly type: Schema.String;
        readonly id: Schema.String;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>]>>;
    readonly instructions: Schema.optional<Schema.String>;
    readonly store: Schema.optional<Schema.Boolean>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
    readonly safety_identifier: Schema.optional<Schema.String>;
    readonly stream_options: Schema.optional<Schema.Struct<{
        readonly include_obfuscation: Schema.optional<Schema.Boolean>;
    }>>;
    readonly top_logprobs: Schema.optional<Schema.Int>;
    readonly truncation: Schema.optional<Schema.Literals<readonly ["auto", "disabled"]>>;
    readonly service_tier: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority">, import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority">>>;
    readonly prompt_cache_key: Schema.optional<Schema.String>;
    readonly include: Schema.optional<Schema.$Array<Schema.declare<import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">, import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">>>>;
    readonly text: Schema.optional<Schema.Struct<{
        readonly verbosity: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"high" | "low" | "medium">, import("../schema/options.js").OpenString<"high" | "low" | "medium">>>;
    }>>;
    readonly max_output_tokens: Schema.optional<Schema.Number>;
    readonly max_tool_calls: Schema.optional<Schema.Int>;
    readonly parallel_tool_calls: Schema.optional<Schema.Boolean>;
    readonly temperature: Schema.optional<Schema.Number>;
    readonly top_p: Schema.optional<Schema.Number>;
    readonly presence_penalty: Schema.optional<Schema.Number>;
    readonly frequency_penalty: Schema.optional<Schema.Number>;
    readonly prompt_cache_retention: Schema.optional<Schema.String>;
    readonly prompt_cache_options: Schema.optional<Schema.Struct<{
        readonly ttl: Schema.optional<Schema.String>;
    }>>;
    readonly tools: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"function">;
        readonly name: Schema.String;
        readonly description: Schema.String;
        readonly parameters: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly strict: Schema.optional<Schema.Boolean>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom">;
        readonly name: Schema.String;
        readonly description: Schema.String;
        readonly format: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.tag<"text">;
        }>, Schema.Struct<{
            readonly type: Schema.tag<"grammar">;
            readonly syntax: Schema.Literals<readonly ["lark", "regex"]>;
            readonly definition: Schema.String;
        }>]>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"namespace">;
        readonly name: Schema.String;
        readonly description: Schema.String;
        readonly tools: Schema.$Array<Schema.Struct<{
            readonly type: Schema.tag<"function">;
            readonly name: Schema.String;
            readonly description: Schema.String;
            readonly parameters: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly strict: Schema.optional<Schema.Boolean>;
        }>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"image_generation">;
        readonly action: Schema.optional<Schema.Literals<readonly ["auto", "generate", "edit"]>>;
        readonly background: Schema.optional<Schema.Literals<readonly ["auto", "opaque", "transparent"]>>;
        readonly input_fidelity: Schema.optional<Schema.Literals<readonly ["low", "high"]>>;
        readonly output_compression: Schema.optional<Schema.Int>;
        readonly output_format: Schema.optional<Schema.Literals<readonly ["png", "jpeg", "webp"]>>;
        readonly partial_images: Schema.optional<Schema.Int>;
        readonly quality: Schema.optional<Schema.Literals<readonly ["auto", "low", "medium", "high"]>>;
        readonly size: Schema.optional<Schema.String>;
    }>]>>>;
    readonly tool_choice: Schema.optional<Schema.Union<readonly [Schema.Union<readonly [Schema.Literals<readonly ["auto", "none", "required"]>, Schema.Struct<{
        readonly type: Schema.Literals<readonly ["function", "custom"]>;
        readonly name: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"allowed_tools">;
        readonly mode: Schema.Literals<readonly ["auto", "none", "required"]>;
        readonly tools: Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literals<readonly ["function", "custom"]>;
            readonly name: Schema.String;
        }>>;
    }>]>, Schema.Struct<{
        readonly type: Schema.tag<"image_generation">;
    }>]>>;
    readonly reasoning: Schema.optional<Schema.Struct<{
        readonly effort: Schema.optional<Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>>;
        readonly summary: Schema.optional<Schema.Literals<readonly ["auto", "concise", "detailed"]>>;
        readonly mode: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"pro" | "standard">, import("../schema/options.js").OpenString<"pro" | "standard">>>;
        readonly context: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"all_turns" | "auto" | "current_turn">, import("../schema/options.js").OpenString<"all_turns" | "auto" | "current_turn">>>;
    }>>;
    readonly context_management: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly type: Schema.Literal<"compaction">;
        readonly compact_threshold: Schema.optional<Schema.Int>;
    }>>>;
    readonly stream: Schema.Literal<true>;
}>;
export type OpenAIResponsesBody = Schema.Schema.Type<typeof OpenAIResponsesBody>;
/** Request control, never conversation content. */
export declare const CompactionTrigger: Schema.Struct<{
    readonly type: Schema.Literal<"compaction_trigger">;
}>;
export declare const protocol: Protocol<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: OpenResponsesOptions.ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly text?: {
        readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "namespace";
        readonly name: string;
        readonly description: string;
        readonly tools: readonly {
            readonly type: "function";
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        }[];
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly type: "image_generation";
        readonly action?: "auto" | "edit" | "generate" | undefined;
        readonly background?: "auto" | "opaque" | "transparent" | undefined;
        readonly input_fidelity?: "high" | "low" | undefined;
        readonly output_compression?: number | undefined;
        readonly output_format?: "jpeg" | "png" | "webp" | undefined;
        readonly partial_images?: number | undefined;
        readonly quality?: "auto" | "high" | "low" | "medium" | undefined;
        readonly size?: string | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | {
        readonly type: "image_generation";
    } | undefined;
    readonly reasoning?: {
        readonly effort?: OpenResponsesOptions.ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
        readonly mode?: import("../schema/options.js").OpenString<"pro" | "standard"> | undefined;
        readonly context?: import("../schema/options.js").OpenString<"all_turns" | "auto" | "current_turn"> | undefined;
    } | undefined;
    readonly context_management?: readonly {
        readonly type: "compaction";
        readonly compact_threshold?: number | undefined;
    }[] | undefined;
    readonly stream: true;
}, string, {
    readonly [x: string]: unknown;
    readonly type: string;
    readonly delta?: string | undefined;
    readonly arguments?: string | undefined;
    readonly text?: string | undefined;
    readonly item_id?: string | undefined;
    readonly output_index?: number | undefined;
    readonly summary_index?: number | undefined;
    readonly item?: {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id?: string | undefined;
        readonly call_id?: string | undefined;
        readonly name?: string | undefined;
        readonly namespace?: string | undefined;
        readonly arguments?: string | undefined;
        readonly encrypted_content?: string | null | undefined;
    } | null | undefined;
    readonly response?: {
        readonly [x: string]: unknown;
        readonly id?: string | undefined;
        readonly service_tier?: string | null | undefined;
        readonly incomplete_details?: {
            readonly reason?: string | undefined;
        } | null | undefined;
        readonly output?: readonly {
            readonly [x: string]: unknown;
            readonly type: string;
            readonly id?: string | undefined;
            readonly call_id?: string | undefined;
            readonly name?: string | undefined;
            readonly namespace?: string | undefined;
            readonly arguments?: string | undefined;
            readonly encrypted_content?: string | null | undefined;
        }[] | undefined;
        readonly usage?: {
            readonly [x: string]: unknown;
            readonly input_tokens?: number | undefined;
            readonly input_tokens_details?: {
                readonly [x: string]: unknown;
                readonly cached_tokens?: number | undefined;
                readonly cache_write_tokens?: number | undefined;
            } | null | undefined;
            readonly output_tokens?: number | undefined;
            readonly output_tokens_details?: {
                readonly [x: string]: unknown;
                readonly reasoning_tokens?: number | undefined;
            } | null | undefined;
            readonly total_tokens?: number | undefined;
        } | null | undefined;
        readonly error?: unknown;
    } | undefined;
    readonly code?: unknown;
    readonly message?: unknown;
    readonly error?: unknown;
    readonly status?: unknown;
    readonly status_code?: unknown;
}, OpenResponses.ParserState>;
export declare const httpTransport: HttpTransport.HttpJsonTransport<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: OpenResponsesOptions.ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly text?: {
        readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "namespace";
        readonly name: string;
        readonly description: string;
        readonly tools: readonly {
            readonly type: "function";
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        }[];
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly type: "image_generation";
        readonly action?: "auto" | "edit" | "generate" | undefined;
        readonly background?: "auto" | "opaque" | "transparent" | undefined;
        readonly input_fidelity?: "high" | "low" | undefined;
        readonly output_compression?: number | undefined;
        readonly output_format?: "jpeg" | "png" | "webp" | undefined;
        readonly partial_images?: number | undefined;
        readonly quality?: "auto" | "high" | "low" | "medium" | undefined;
        readonly size?: string | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | {
        readonly type: "image_generation";
    } | undefined;
    readonly reasoning?: {
        readonly effort?: OpenResponsesOptions.ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
        readonly mode?: import("../schema/options.js").OpenString<"pro" | "standard"> | undefined;
        readonly context?: import("../schema/options.js").OpenString<"all_turns" | "auto" | "current_turn"> | undefined;
    } | undefined;
    readonly context_management?: readonly {
        readonly type: "compaction";
        readonly compact_threshold?: number | undefined;
    }[] | undefined;
    readonly stream: true;
}, string>;
export declare const channelTransport: (options: import("./open-responses-channel.js").Options) => import("../route/transport/index.js").Transport<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: OpenResponsesOptions.ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly text?: {
        readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "namespace";
        readonly name: string;
        readonly description: string;
        readonly tools: readonly {
            readonly type: "function";
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        }[];
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly type: "image_generation";
        readonly action?: "auto" | "edit" | "generate" | undefined;
        readonly background?: "auto" | "opaque" | "transparent" | undefined;
        readonly input_fidelity?: "high" | "low" | undefined;
        readonly output_compression?: number | undefined;
        readonly output_format?: "jpeg" | "png" | "webp" | undefined;
        readonly partial_images?: number | undefined;
        readonly quality?: "auto" | "high" | "low" | "medium" | undefined;
        readonly size?: string | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | {
        readonly type: "image_generation";
    } | undefined;
    readonly reasoning?: {
        readonly effort?: OpenResponsesOptions.ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
        readonly mode?: import("../schema/options.js").OpenString<"pro" | "standard"> | undefined;
        readonly context?: import("../schema/options.js").OpenString<"all_turns" | "auto" | "current_turn"> | undefined;
    } | undefined;
    readonly context_management?: readonly {
        readonly type: "compaction";
        readonly compact_threshold?: number | undefined;
    }[] | undefined;
    readonly stream: true;
}, import("./open-responses-channel.js").Prepared, string>;
export declare const transport: import("../route/transport/index.js").Transport<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: OpenResponsesOptions.ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly text?: {
        readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "namespace";
        readonly name: string;
        readonly description: string;
        readonly tools: readonly {
            readonly type: "function";
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        }[];
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly type: "image_generation";
        readonly action?: "auto" | "edit" | "generate" | undefined;
        readonly background?: "auto" | "opaque" | "transparent" | undefined;
        readonly input_fidelity?: "high" | "low" | undefined;
        readonly output_compression?: number | undefined;
        readonly output_format?: "jpeg" | "png" | "webp" | undefined;
        readonly partial_images?: number | undefined;
        readonly quality?: "auto" | "high" | "low" | "medium" | undefined;
        readonly size?: string | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | {
        readonly type: "image_generation";
    } | undefined;
    readonly reasoning?: {
        readonly effort?: OpenResponsesOptions.ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
        readonly mode?: import("../schema/options.js").OpenString<"pro" | "standard"> | undefined;
        readonly context?: import("../schema/options.js").OpenString<"all_turns" | "auto" | "current_turn"> | undefined;
    } | undefined;
    readonly context_management?: readonly {
        readonly type: "compaction";
        readonly compact_threshold?: number | undefined;
    }[] | undefined;
    readonly stream: true;
}, import("./open-responses-channel.js").Prepared, string>;
export declare const route: Route<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: OpenResponsesOptions.ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly text?: {
        readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "namespace";
        readonly name: string;
        readonly description: string;
        readonly tools: readonly {
            readonly type: "function";
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        }[];
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly type: "image_generation";
        readonly action?: "auto" | "edit" | "generate" | undefined;
        readonly background?: "auto" | "opaque" | "transparent" | undefined;
        readonly input_fidelity?: "high" | "low" | undefined;
        readonly output_compression?: number | undefined;
        readonly output_format?: "jpeg" | "png" | "webp" | undefined;
        readonly partial_images?: number | undefined;
        readonly quality?: "auto" | "high" | "low" | "medium" | undefined;
        readonly size?: string | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | {
        readonly type: "image_generation";
    } | undefined;
    readonly reasoning?: {
        readonly effort?: OpenResponsesOptions.ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
        readonly mode?: import("../schema/options.js").OpenString<"pro" | "standard"> | undefined;
        readonly context?: import("../schema/options.js").OpenString<"all_turns" | "auto" | "current_turn"> | undefined;
    } | undefined;
    readonly context_management?: readonly {
        readonly type: "compaction";
        readonly compact_threshold?: number | undefined;
    }[] | undefined;
    readonly stream: true;
}, import("./open-responses-channel.js").Prepared, {
    endpoint: import("../route/client.js").CompactOperation;
    trigger: import("../route/client.js").TriggerCompactOperation;
}>;
export * as OpenAIResponses from "./openai-responses.js";
