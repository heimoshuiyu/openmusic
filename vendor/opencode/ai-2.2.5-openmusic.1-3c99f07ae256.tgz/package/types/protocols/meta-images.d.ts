import { ImageModel, ImageResponse, type ImageRequest } from "../image.js";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type OpenString } from "../schema/index.js";
export declare const DEFAULT_BASE_URL = "https://api.meta.ai/v1";
/**
 * Provider-native options. Common fields (`n`, `aspect`, `images`) live on the request; Meta picks its own output
 * resolution (about 2.5 megapixels), so `resolution` is ignored.
 */
export type ImageOptions = {
    /** `WIDTHxHEIGHT` aspect ratio hint; it replaces `aspect`, so setting both fails. */
    readonly size?: string;
    readonly outputFormat?: OpenString<"webp" | "png" | "jpeg">;
    readonly responseFormat?: OpenString<"b64_json" | "url">;
    readonly reasoningStrength?: OpenString<"low" | "high">;
    readonly toolEnablement?: {
        readonly enable_image_search?: boolean;
        readonly enable_web_search?: boolean;
        readonly enable_shell?: boolean;
    };
    readonly [key: string]: unknown;
};
export type Request = ImageRequest<ImageModel<ImageOptions>>;
export declare const protocol: MediaProtocol.Inline<Request, ImageResponse>;
export declare const model: (input: MediaRoute.ModelInput) => ImageModel<ImageOptions>;
export * as MetaImages from "./meta-images.js";
