import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type MediaUsage } from "../schema/index.js";
import { SpeechModel, type SpeechRequest } from "../speech.js";
import { SpeechStream } from "./utils/speech-stream.js";
export declare const DEFAULT_BASE_URL = "https://api.openai.com/v1";
export declare const PATH = "/audio/speech";
/** `voice`, `instructions`, `speed`, and `format` are common request fields; other native body fields pass through. */
export type OpenAISpeechOptions = {
    /** Defaults to `"sse"` in `stream` mode on models that support it; the merged value selects the response framing. */
    readonly stream_format?: "sse" | "audio";
} & Record<string, unknown>;
export type Request = SpeechRequest<SpeechModel<OpenAISpeechOptions>>;
interface State extends SpeechStream.Audio {
    readonly done: boolean;
    readonly usage?: MediaUsage;
}
export declare const protocol: MediaProtocol.Streamed<Request, {
    readonly type: "audio-delta";
    readonly chunk: Uint8Array<ArrayBufferLike>;
} | {
    readonly type: "timestamps";
    readonly items: readonly {
        readonly text: string;
        readonly startSeconds: number;
        readonly endSeconds: number;
    }[];
} | {
    readonly type: "generation-queued";
    readonly id: string;
    readonly position?: number | undefined;
} | {
    readonly type: "generation-progress";
    readonly id: string;
    readonly progress?: number | undefined;
} | {
    readonly type: "finish";
    readonly audio: import("../media.js").Asset;
    readonly usage?: {
        readonly type: "seconds";
        readonly seconds: number;
    } | {
        readonly type: "characters";
        readonly characters: number;
    } | {
        readonly type: "credits";
        readonly credits: number;
    } | {
        readonly type: "compute";
        readonly seconds: number;
    } | {
        readonly type: "tokens";
        readonly input?: number | undefined;
        readonly output?: number | undefined;
        readonly total?: number | undefined;
        readonly details?: {
            readonly [x: string]: unknown;
        } | undefined;
    } | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
}, string | Uint8Array<ArrayBufferLike>, State>;
export declare const model: (input: MediaRoute.ModelInput) => SpeechModel<OpenAISpeechOptions>;
export declare const OpenAISpeech: {
    readonly protocol: MediaProtocol.Streamed<Request, {
        readonly type: "audio-delta";
        readonly chunk: Uint8Array<ArrayBufferLike>;
    } | {
        readonly type: "timestamps";
        readonly items: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
        }[];
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly type: "finish";
        readonly audio: import("../media.js").Asset;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, string | Uint8Array<ArrayBufferLike>, State>;
    readonly model: typeof model;
};
export {};
