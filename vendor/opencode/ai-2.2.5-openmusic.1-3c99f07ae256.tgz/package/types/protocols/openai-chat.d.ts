import { Effect, Schema } from "effect";
import { Route } from "../route/client.js";
import { Framing } from "../route/framing.js";
import { HttpTransport } from "../route/transport/index.js";
import { Protocol } from "../route/protocol.js";
import { AIError, LLMEvent, Usage, type FinishReasonDetails, type AssistantMessage, type CacheHint, type LLMRequest } from "../schema/index.js";
import { OpenResponsesOptions } from "./utils/open-responses-options.js";
import { Lifecycle } from "./utils/lifecycle.js";
import { ToolStream } from "./utils/tool-stream.js";
import { OpenAIFreeform } from "./openai-freeform.js";
export declare const DEFAULT_BASE_URL = "https://api.openai.com/v1";
export declare const PATH = "/chat/completions";
declare const OpenAIChatCacheControl: Schema.Struct<{
    readonly type: Schema.Literal<"ephemeral">;
    readonly ttl: Schema.optional<Schema.String>;
}>;
type OpenAIChatCacheControl = Schema.Schema.Type<typeof OpenAIChatCacheControl>;
declare const ExtraContent: Schema.Struct<{
    readonly google: Schema.Struct<{
        readonly thought_signature: Schema.String;
    }>;
}>;
export declare const OpenAIChatAssistantToolCall: Schema.Struct<{
    readonly id: Schema.String;
    readonly type: Schema.tag<"function">;
    readonly function: Schema.Struct<{
        readonly name: Schema.String;
        readonly arguments: Schema.String;
    }>;
    readonly extra_content: Schema.optional<Schema.Struct<{
        readonly google: Schema.Struct<{
            readonly thought_signature: Schema.String;
        }>;
    }>>;
}>;
export declare const OpenAIChatAssistantCustomToolCall: Schema.Struct<{
    readonly id: Schema.String;
    readonly type: Schema.tag<"custom">;
    readonly custom: Schema.Struct<{
        readonly name: Schema.String;
        readonly input: Schema.String;
    }>;
}>;
declare const ReasoningDetail: Schema.Union<readonly [Schema.StructWithRest<Schema.Struct<{
    readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly format: Schema.optional<Schema.String>;
    readonly index: Schema.optional<Schema.Number>;
    readonly signature: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly type: Schema.Literal<"reasoning.text">;
    readonly text: Schema.optional<Schema.String>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
    readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly format: Schema.optional<Schema.String>;
    readonly index: Schema.optional<Schema.Number>;
    readonly signature: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly type: Schema.Literal<"reasoning.summary">;
    readonly summary: Schema.optional<Schema.String>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.StructWithRest<Schema.Struct<{
    readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly format: Schema.optional<Schema.String>;
    readonly index: Schema.optional<Schema.Number>;
    readonly signature: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly type: Schema.Literal<"reasoning.encrypted">;
    readonly data: Schema.String;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.Struct<{
    readonly type: Schema.Literal<"summary">;
    readonly summary: Schema.String;
    readonly index: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"encrypted">;
    readonly encrypted: Schema.String;
    readonly index: Schema.optional<Schema.Number>;
}>]>;
type ReasoningDetail = Schema.Schema.Type<typeof ReasoningDetail>;
export declare const OpenAIChatMessage: Schema.toTaggedUnion<"role", readonly [Schema.Struct<{
    readonly role: Schema.Literal<"system">;
    readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.Literal<"ephemeral">;
            readonly ttl: Schema.optional<Schema.String>;
        }>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"image_url">;
        readonly image_url: Schema.Struct<{
            readonly url: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"video_url">;
        readonly video_url: Schema.Struct<{
            readonly url: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"file">;
        readonly file: Schema.Struct<{
            readonly filename: Schema.String;
            readonly file_data: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"input_audio">;
        readonly input_audio: Schema.Struct<{
            readonly data: Schema.String;
            readonly format: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"audio_url">;
        readonly audio_url: Schema.Struct<{
            readonly url: Schema.String;
        }>;
    }>]>>]>;
}>, Schema.Struct<{
    readonly role: Schema.Literal<"user">;
    readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.Literal<"ephemeral">;
            readonly ttl: Schema.optional<Schema.String>;
        }>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"image_url">;
        readonly image_url: Schema.Struct<{
            readonly url: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"video_url">;
        readonly video_url: Schema.Struct<{
            readonly url: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"file">;
        readonly file: Schema.Struct<{
            readonly filename: Schema.String;
            readonly file_data: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"input_audio">;
        readonly input_audio: Schema.Struct<{
            readonly data: Schema.String;
            readonly format: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"audio_url">;
        readonly audio_url: Schema.Struct<{
            readonly url: Schema.String;
        }>;
    }>]>>]>;
}>, Schema.StructWithRest<Schema.Struct<{
    readonly role: Schema.Literal<"assistant">;
    readonly content: Schema.NullOr<Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.Literal<"ephemeral">;
            readonly ttl: Schema.optional<Schema.String>;
        }>>;
    }>>]>>;
    readonly tool_calls: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly id: Schema.String;
        readonly type: Schema.tag<"function">;
        readonly function: Schema.Struct<{
            readonly name: Schema.String;
            readonly arguments: Schema.String;
        }>;
        readonly extra_content: Schema.optional<Schema.Struct<{
            readonly google: Schema.Struct<{
                readonly thought_signature: Schema.String;
            }>;
        }>>;
    }>, Schema.Struct<{
        readonly id: Schema.String;
        readonly type: Schema.tag<"custom">;
        readonly custom: Schema.Struct<{
            readonly name: Schema.String;
            readonly input: Schema.String;
        }>;
    }>]>>>;
    readonly reasoning_content: Schema.optional<Schema.String>;
    readonly reasoning: Schema.optional<Schema.String>;
    readonly reasoning_text: Schema.optional<Schema.String>;
    readonly reasoning_details: Schema.optional<Schema.Unknown>;
    readonly reasoning_opaque: Schema.optional<Schema.String>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.Struct<{
    readonly role: Schema.Literal<"tool">;
    readonly tool_call_id: Schema.String;
    readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.Literal<"ephemeral">;
            readonly ttl: Schema.optional<Schema.String>;
        }>>;
    }>>]>;
}>]>;
type OpenAIChatMessage = Schema.Schema.Type<typeof OpenAIChatMessage>;
export declare const bodyFields: {
    model: Schema.String;
    messages: Schema.$Array<Schema.toTaggedUnion<"role", readonly [Schema.Struct<{
        readonly role: Schema.Literal<"system">;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"image_url">;
            readonly image_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"video_url">;
            readonly video_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly file: Schema.Struct<{
                readonly filename: Schema.String;
                readonly file_data: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"audio_url">;
            readonly audio_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>]>>]>;
    }>, Schema.Struct<{
        readonly role: Schema.Literal<"user">;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"image_url">;
            readonly image_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"video_url">;
            readonly video_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly file: Schema.Struct<{
                readonly filename: Schema.String;
                readonly file_data: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"audio_url">;
            readonly audio_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>]>>]>;
    }>, Schema.StructWithRest<Schema.Struct<{
        readonly role: Schema.Literal<"assistant">;
        readonly content: Schema.NullOr<Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>>]>>;
        readonly tool_calls: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly id: Schema.String;
            readonly type: Schema.tag<"function">;
            readonly function: Schema.Struct<{
                readonly name: Schema.String;
                readonly arguments: Schema.String;
            }>;
            readonly extra_content: Schema.optional<Schema.Struct<{
                readonly google: Schema.Struct<{
                    readonly thought_signature: Schema.String;
                }>;
            }>>;
        }>, Schema.Struct<{
            readonly id: Schema.String;
            readonly type: Schema.tag<"custom">;
            readonly custom: Schema.Struct<{
                readonly name: Schema.String;
                readonly input: Schema.String;
            }>;
        }>]>>>;
        readonly reasoning_content: Schema.optional<Schema.String>;
        readonly reasoning: Schema.optional<Schema.String>;
        readonly reasoning_text: Schema.optional<Schema.String>;
        readonly reasoning_details: Schema.optional<Schema.Unknown>;
        readonly reasoning_opaque: Schema.optional<Schema.String>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.Struct<{
        readonly role: Schema.Literal<"tool">;
        readonly tool_call_id: Schema.String;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>>]>;
    }>]>>;
    tools: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"function">;
        readonly function: Schema.Struct<{
            readonly name: Schema.String;
            readonly description: Schema.String;
            readonly parameters: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly strict: Schema.optional<Schema.Boolean>;
        }>;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.Literal<"ephemeral">;
            readonly ttl: Schema.optional<Schema.String>;
        }>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom">;
        readonly custom: Schema.Struct<{
            readonly name: Schema.String;
            readonly description: Schema.String;
            readonly format: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.tag<"text">;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"grammar">;
                readonly grammar: Schema.Struct<{
                    readonly syntax: Schema.Literals<readonly ["lark", "regex"]>;
                    readonly definition: Schema.String;
                }>;
            }>]>;
        }>;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.Literal<"ephemeral">;
            readonly ttl: Schema.optional<Schema.String>;
        }>>;
    }>]>>>;
    tool_choice: Schema.optional<Schema.Union<readonly [Schema.Literals<readonly ["auto", "none", "required"]>, Schema.Struct<{
        readonly type: Schema.tag<"function">;
        readonly function: Schema.Struct<{
            readonly name: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom">;
        readonly custom: Schema.Struct<{
            readonly name: Schema.String;
        }>;
    }>]>>;
    stream: Schema.Literal<true>;
    stream_options: Schema.optional<Schema.Struct<{
        readonly include_usage: Schema.Boolean;
    }>>;
    store: Schema.optional<Schema.Boolean>;
    prompt_cache_key: Schema.optional<Schema.String>;
    prompt_cache_retention: Schema.optional<Schema.String>;
    prompt_cache_options: Schema.optional<Schema.Struct<{
        readonly ttl: Schema.optional<Schema.String>;
    }>>;
    reasoning_effort: Schema.optional<Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>>;
    verbosity: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"high" | "low" | "medium">, import("../schema/options.js").OpenString<"high" | "low" | "medium">>>;
    service_tier: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority">, import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority">>>;
    parallel_tool_calls: Schema.optional<Schema.Boolean>;
    metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
    safety_identifier: Schema.optional<Schema.String>;
    tool_stream: Schema.optional<Schema.Boolean>;
    max_completion_tokens: Schema.optional<Schema.Number>;
    max_tokens: Schema.optional<Schema.Number>;
    temperature: Schema.optional<Schema.Number>;
    top_p: Schema.optional<Schema.Number>;
    frequency_penalty: Schema.optional<Schema.Number>;
    presence_penalty: Schema.optional<Schema.Number>;
    seed: Schema.optional<Schema.Number>;
    stop: Schema.optional<Schema.$Array<Schema.String>>;
};
declare const OpenAIChatBody: Schema.Struct<{
    model: Schema.String;
    messages: Schema.$Array<Schema.toTaggedUnion<"role", readonly [Schema.Struct<{
        readonly role: Schema.Literal<"system">;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"image_url">;
            readonly image_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"video_url">;
            readonly video_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly file: Schema.Struct<{
                readonly filename: Schema.String;
                readonly file_data: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"audio_url">;
            readonly audio_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>]>>]>;
    }>, Schema.Struct<{
        readonly role: Schema.Literal<"user">;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"image_url">;
            readonly image_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"video_url">;
            readonly video_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly file: Schema.Struct<{
                readonly filename: Schema.String;
                readonly file_data: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"audio_url">;
            readonly audio_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>]>>]>;
    }>, Schema.StructWithRest<Schema.Struct<{
        readonly role: Schema.Literal<"assistant">;
        readonly content: Schema.NullOr<Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>>]>>;
        readonly tool_calls: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly id: Schema.String;
            readonly type: Schema.tag<"function">;
            readonly function: Schema.Struct<{
                readonly name: Schema.String;
                readonly arguments: Schema.String;
            }>;
            readonly extra_content: Schema.optional<Schema.Struct<{
                readonly google: Schema.Struct<{
                    readonly thought_signature: Schema.String;
                }>;
            }>>;
        }>, Schema.Struct<{
            readonly id: Schema.String;
            readonly type: Schema.tag<"custom">;
            readonly custom: Schema.Struct<{
                readonly name: Schema.String;
                readonly input: Schema.String;
            }>;
        }>]>>>;
        readonly reasoning_content: Schema.optional<Schema.String>;
        readonly reasoning: Schema.optional<Schema.String>;
        readonly reasoning_text: Schema.optional<Schema.String>;
        readonly reasoning_details: Schema.optional<Schema.Unknown>;
        readonly reasoning_opaque: Schema.optional<Schema.String>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.Struct<{
        readonly role: Schema.Literal<"tool">;
        readonly tool_call_id: Schema.String;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>>]>;
    }>]>>;
    tools: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"function">;
        readonly function: Schema.Struct<{
            readonly name: Schema.String;
            readonly description: Schema.String;
            readonly parameters: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly strict: Schema.optional<Schema.Boolean>;
        }>;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.Literal<"ephemeral">;
            readonly ttl: Schema.optional<Schema.String>;
        }>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom">;
        readonly custom: Schema.Struct<{
            readonly name: Schema.String;
            readonly description: Schema.String;
            readonly format: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.tag<"text">;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"grammar">;
                readonly grammar: Schema.Struct<{
                    readonly syntax: Schema.Literals<readonly ["lark", "regex"]>;
                    readonly definition: Schema.String;
                }>;
            }>]>;
        }>;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.Literal<"ephemeral">;
            readonly ttl: Schema.optional<Schema.String>;
        }>>;
    }>]>>>;
    tool_choice: Schema.optional<Schema.Union<readonly [Schema.Literals<readonly ["auto", "none", "required"]>, Schema.Struct<{
        readonly type: Schema.tag<"function">;
        readonly function: Schema.Struct<{
            readonly name: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom">;
        readonly custom: Schema.Struct<{
            readonly name: Schema.String;
        }>;
    }>]>>;
    stream: Schema.Literal<true>;
    stream_options: Schema.optional<Schema.Struct<{
        readonly include_usage: Schema.Boolean;
    }>>;
    store: Schema.optional<Schema.Boolean>;
    prompt_cache_key: Schema.optional<Schema.String>;
    prompt_cache_retention: Schema.optional<Schema.String>;
    prompt_cache_options: Schema.optional<Schema.Struct<{
        readonly ttl: Schema.optional<Schema.String>;
    }>>;
    reasoning_effort: Schema.optional<Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>>;
    verbosity: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"high" | "low" | "medium">, import("../schema/options.js").OpenString<"high" | "low" | "medium">>>;
    service_tier: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority">, import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority">>>;
    parallel_tool_calls: Schema.optional<Schema.Boolean>;
    metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
    safety_identifier: Schema.optional<Schema.String>;
    tool_stream: Schema.optional<Schema.Boolean>;
    max_completion_tokens: Schema.optional<Schema.Number>;
    max_tokens: Schema.optional<Schema.Number>;
    temperature: Schema.optional<Schema.Number>;
    top_p: Schema.optional<Schema.Number>;
    frequency_penalty: Schema.optional<Schema.Number>;
    presence_penalty: Schema.optional<Schema.Number>;
    seed: Schema.optional<Schema.Number>;
    stop: Schema.optional<Schema.$Array<Schema.String>>;
}>;
export type OpenAIChatBody = Schema.Schema.Type<typeof OpenAIChatBody>;
export declare const OpenAIChatUsage: Schema.StructWithRest<Schema.Struct<{
    readonly prompt_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly completion_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly total_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly cached_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly prompt_cache_hit_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly cache_read_input_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly cache_created_input_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly reasoning_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly prompt_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly cached_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly cache_write_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
    readonly completion_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly reasoning_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly accepted_prediction_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly rejected_prediction_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
export declare const OpenAIChatToolCallDelta: Schema.Struct<{
    readonly index: Schema.optional<Schema.NullOr<Schema.Number>>;
    readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly function: Schema.optional<Schema.NullOr<Schema.Struct<{
        readonly name: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly arguments: Schema.optional<Schema.NullOr<Schema.String>>;
    }>>>;
    readonly custom: Schema.optional<Schema.NullOr<Schema.Struct<{
        readonly name: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly input: Schema.optional<Schema.NullOr<Schema.String>>;
    }>>>;
    readonly extra_content: Schema.optional<Schema.NullOr<Schema.Unknown>>;
}>;
export declare const OpenAIChatDelta: Schema.StructWithRest<Schema.Struct<{
    readonly content: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly refusal: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly reasoning_content: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly reasoning: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly reasoning_text: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly reasoning_details: Schema.optional<Schema.NullOr<Schema.Unknown>>;
    readonly reasoning_opaque: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly tool_calls: Schema.optional<Schema.NullOr<Schema.$Array<Schema.Struct<{
        readonly index: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly function: Schema.optional<Schema.NullOr<Schema.Struct<{
            readonly name: Schema.optional<Schema.NullOr<Schema.String>>;
            readonly arguments: Schema.optional<Schema.NullOr<Schema.String>>;
        }>>>;
        readonly custom: Schema.optional<Schema.NullOr<Schema.Struct<{
            readonly name: Schema.optional<Schema.NullOr<Schema.String>>;
            readonly input: Schema.optional<Schema.NullOr<Schema.String>>;
        }>>>;
        readonly extra_content: Schema.optional<Schema.NullOr<Schema.Unknown>>;
    }>>>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
export declare const OpenAIChatChoice: Schema.StructWithRest<Schema.Struct<{
    readonly delta: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly content: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly refusal: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly reasoning_content: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly reasoning: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly reasoning_text: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly reasoning_details: Schema.optional<Schema.NullOr<Schema.Unknown>>;
        readonly reasoning_opaque: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly tool_calls: Schema.optional<Schema.NullOr<Schema.$Array<Schema.Struct<{
            readonly index: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
            readonly function: Schema.optional<Schema.NullOr<Schema.Struct<{
                readonly name: Schema.optional<Schema.NullOr<Schema.String>>;
                readonly arguments: Schema.optional<Schema.NullOr<Schema.String>>;
            }>>>;
            readonly custom: Schema.optional<Schema.NullOr<Schema.Struct<{
                readonly name: Schema.optional<Schema.NullOr<Schema.String>>;
                readonly input: Schema.optional<Schema.NullOr<Schema.String>>;
            }>>>;
            readonly extra_content: Schema.optional<Schema.NullOr<Schema.Unknown>>;
        }>>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
    readonly finish_reason: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly native_finish_reason: Schema.optional<Schema.NullOr<Schema.String>>;
    readonly usage: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly prompt_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly completion_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly total_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly cached_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly prompt_cache_hit_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly cache_read_input_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly cache_created_input_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly reasoning_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly prompt_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
            readonly cached_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly cache_write_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
        readonly completion_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
            readonly reasoning_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly accepted_prediction_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly rejected_prediction_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
export declare const OpenAIChatEvent: Schema.StructWithRest<Schema.Struct<{
    readonly choices: Schema.optional<Schema.NullOr<Schema.$Array<Schema.StructWithRest<Schema.Struct<{
        readonly delta: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
            readonly content: Schema.optional<Schema.NullOr<Schema.String>>;
            readonly refusal: Schema.optional<Schema.NullOr<Schema.String>>;
            readonly reasoning_content: Schema.optional<Schema.NullOr<Schema.String>>;
            readonly reasoning: Schema.optional<Schema.NullOr<Schema.String>>;
            readonly reasoning_text: Schema.optional<Schema.NullOr<Schema.String>>;
            readonly reasoning_details: Schema.optional<Schema.NullOr<Schema.Unknown>>;
            readonly reasoning_opaque: Schema.optional<Schema.NullOr<Schema.String>>;
            readonly tool_calls: Schema.optional<Schema.NullOr<Schema.$Array<Schema.Struct<{
                readonly index: Schema.optional<Schema.NullOr<Schema.Number>>;
                readonly id: Schema.optional<Schema.NullOr<Schema.String>>;
                readonly function: Schema.optional<Schema.NullOr<Schema.Struct<{
                    readonly name: Schema.optional<Schema.NullOr<Schema.String>>;
                    readonly arguments: Schema.optional<Schema.NullOr<Schema.String>>;
                }>>>;
                readonly custom: Schema.optional<Schema.NullOr<Schema.Struct<{
                    readonly name: Schema.optional<Schema.NullOr<Schema.String>>;
                    readonly input: Schema.optional<Schema.NullOr<Schema.String>>;
                }>>>;
                readonly extra_content: Schema.optional<Schema.NullOr<Schema.Unknown>>;
            }>>>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
        readonly finish_reason: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly native_finish_reason: Schema.optional<Schema.NullOr<Schema.String>>;
        readonly usage: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
            readonly prompt_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly completion_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly total_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly cached_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly prompt_cache_hit_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly cache_read_input_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly cache_created_input_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly reasoning_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly prompt_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
                readonly cached_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
                readonly cache_write_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
            readonly completion_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
                readonly reasoning_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
                readonly accepted_prediction_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
                readonly rejected_prediction_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>>;
    readonly usage: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly prompt_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly completion_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly total_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly cached_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly prompt_cache_hit_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly cache_read_input_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly cache_created_input_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly reasoning_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        readonly prompt_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
            readonly cached_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly cache_write_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
        readonly completion_tokens_details: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
            readonly reasoning_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly accepted_prediction_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
            readonly rejected_prediction_tokens: Schema.optional<Schema.NullOr<Schema.Number>>;
        }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
    readonly error: Schema.optional<Schema.NullOr<Schema.StructWithRest<Schema.Struct<{
        readonly code: Schema.optional<Schema.NullOr<Schema.Union<readonly [Schema.String, Schema.Number]>>>;
        readonly message: Schema.String;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
export type OpenAIChatEvent = Schema.Schema.Type<typeof OpenAIChatEvent>;
interface PendingToolDelta {
    readonly id?: string;
    readonly name?: string;
    readonly input: string;
    readonly extraContent?: Schema.Schema.Type<typeof ExtraContent>;
}
export interface ParserState {
    readonly providerMetadataKey: string;
    readonly tools: ToolStream.State<number>;
    readonly custom: ReadonlyMap<string, OpenAIFreeform.Custom>;
    /** Stream indexes of custom tool calls, whose JSON fragment closes when the call finishes. */
    readonly customCalls: ReadonlySet<number>;
    readonly pendingTools: Partial<Record<number, PendingToolDelta>>;
    readonly toolCallEvents: ReadonlyArray<LLMEvent>;
    readonly usage?: Usage;
    readonly finishReason?: FinishReasonDetails;
    readonly lifecycle: Lifecycle.State;
    readonly reasoningField?: string;
    /** A scalar reasoning field (`reasoning_content`, ...) has carried text in this stream. */
    readonly reasoningTextObserved: boolean;
    readonly reasoningDetails: Array<ReasoningDetail>;
    readonly reasoningDetailsObserved: boolean;
    /** Latest `reasoning_opaque`; interleaved reasoning sends a new one before each tool call. */
    readonly reasoningOpaque?: string;
    readonly reasoningEmitted: boolean;
    readonly latestToolIndex?: number;
    readonly nextToolIndex: number;
    readonly requireFinishReason: boolean;
}
interface LoweringOptions {
    readonly cacheControl?: (cache: CacheHint | undefined) => OpenAIChatCacheControl | undefined;
    readonly toolCallID?: (id: string) => string;
    /** Project provider-specific fields from the exact source, even when other messages are dropped during lowering. */
    readonly assistant?: (source: AssistantMessage, message: OpenAIChatMessage) => OpenAIChatMessage;
}
export declare const fromRequest: (request: LLMRequest<import("../schema/options.js").LanguageModel<{
    readonly [x: string]: unknown;
}, import("../route/client.js").CompactionOperations | undefined>>, options?: LoweringOptions | undefined) => Effect.Effect<{
    prompt_cache_retention?: undefined;
    prompt_cache_options?: undefined;
    store?: boolean | undefined;
    prompt_cache_key?: string | undefined;
    reasoning_effort?: OpenResponsesOptions.ReasoningEffort | undefined;
    verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    parallel_tool_calls?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    model: string & import("effect/Brand").Brand<"AI.ModelID">;
    messages: ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    tools: ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    tool_choice: "auto" | "none" | "required" | {
        type: "custom";
        custom: {
            name: string;
        };
        function?: undefined;
    } | {
        custom?: undefined;
        type: "function";
        function: {
            name: string;
        };
    } | undefined;
    stream: true;
    stream_options?: {
        include_usage: boolean;
    } | undefined;
    tool_stream?: boolean | undefined;
    max_completion_tokens: number | undefined;
    temperature: number | undefined;
    top_p: number | undefined;
    frequency_penalty: number | undefined;
    presence_penalty: number | undefined;
    seed: number | undefined;
    stop: readonly string[] | undefined;
} | {
    prompt_cache_retention: string;
    prompt_cache_options?: undefined;
    store?: boolean | undefined;
    prompt_cache_key?: string | undefined;
    reasoning_effort?: OpenResponsesOptions.ReasoningEffort | undefined;
    verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    parallel_tool_calls?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    model: string & import("effect/Brand").Brand<"AI.ModelID">;
    messages: ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    tools: ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    tool_choice: "auto" | "none" | "required" | {
        type: "custom";
        custom: {
            name: string;
        };
        function?: undefined;
    } | {
        custom?: undefined;
        type: "function";
        function: {
            name: string;
        };
    } | undefined;
    stream: true;
    stream_options?: {
        include_usage: boolean;
    } | undefined;
    tool_stream?: boolean | undefined;
    max_completion_tokens: number | undefined;
    temperature: number | undefined;
    top_p: number | undefined;
    frequency_penalty: number | undefined;
    presence_penalty: number | undefined;
    seed: number | undefined;
    stop: readonly string[] | undefined;
} | {
    prompt_cache_retention?: undefined;
    prompt_cache_options: {
        ttl: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s`;
    };
    store?: boolean | undefined;
    prompt_cache_key?: string | undefined;
    reasoning_effort?: OpenResponsesOptions.ReasoningEffort | undefined;
    verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    parallel_tool_calls?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    model: string & import("effect/Brand").Brand<"AI.ModelID">;
    messages: ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    tools: ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    tool_choice: "auto" | "none" | "required" | {
        type: "custom";
        custom: {
            name: string;
        };
        function?: undefined;
    } | {
        custom?: undefined;
        type: "function";
        function: {
            name: string;
        };
    } | undefined;
    stream: true;
    stream_options?: {
        include_usage: boolean;
    } | undefined;
    tool_stream?: boolean | undefined;
    max_completion_tokens: number | undefined;
    temperature: number | undefined;
    top_p: number | undefined;
    frequency_penalty: number | undefined;
    presence_penalty: number | undefined;
    seed: number | undefined;
    stop: readonly string[] | undefined;
} | {
    prompt_cache_retention?: undefined;
    prompt_cache_options?: undefined;
    store?: boolean | undefined;
    prompt_cache_key?: string | undefined;
    reasoning_effort?: OpenResponsesOptions.ReasoningEffort | undefined;
    verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    parallel_tool_calls?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    model: string & import("effect/Brand").Brand<"AI.ModelID">;
    messages: ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    tools: ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    tool_choice: "auto" | "none" | "required" | {
        type: "custom";
        custom: {
            name: string;
        };
        function?: undefined;
    } | {
        custom?: undefined;
        type: "function";
        function: {
            name: string;
        };
    } | undefined;
    stream: true;
    stream_options?: {
        include_usage: boolean;
    } | undefined;
    tool_stream?: boolean | undefined;
    max_tokens: number | undefined;
    temperature: number | undefined;
    top_p: number | undefined;
    frequency_penalty: number | undefined;
    presence_penalty: number | undefined;
    seed: number | undefined;
    stop: readonly string[] | undefined;
} | {
    prompt_cache_retention: string;
    prompt_cache_options?: undefined;
    store?: boolean | undefined;
    prompt_cache_key?: string | undefined;
    reasoning_effort?: OpenResponsesOptions.ReasoningEffort | undefined;
    verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    parallel_tool_calls?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    model: string & import("effect/Brand").Brand<"AI.ModelID">;
    messages: ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    tools: ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    tool_choice: "auto" | "none" | "required" | {
        type: "custom";
        custom: {
            name: string;
        };
        function?: undefined;
    } | {
        custom?: undefined;
        type: "function";
        function: {
            name: string;
        };
    } | undefined;
    stream: true;
    stream_options?: {
        include_usage: boolean;
    } | undefined;
    tool_stream?: boolean | undefined;
    max_tokens: number | undefined;
    temperature: number | undefined;
    top_p: number | undefined;
    frequency_penalty: number | undefined;
    presence_penalty: number | undefined;
    seed: number | undefined;
    stop: readonly string[] | undefined;
} | {
    prompt_cache_retention?: undefined;
    prompt_cache_options: {
        ttl: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s`;
    };
    store?: boolean | undefined;
    prompt_cache_key?: string | undefined;
    reasoning_effort?: OpenResponsesOptions.ReasoningEffort | undefined;
    verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    parallel_tool_calls?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    model: string & import("effect/Brand").Brand<"AI.ModelID">;
    messages: ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    tools: ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    tool_choice: "auto" | "none" | "required" | {
        type: "custom";
        custom: {
            name: string;
        };
        function?: undefined;
    } | {
        custom?: undefined;
        type: "function";
        function: {
            name: string;
        };
    } | undefined;
    stream: true;
    stream_options?: {
        include_usage: boolean;
    } | undefined;
    tool_stream?: boolean | undefined;
    max_tokens: number | undefined;
    temperature: number | undefined;
    top_p: number | undefined;
    frequency_penalty: number | undefined;
    presence_penalty: number | undefined;
    seed: number | undefined;
    stop: readonly string[] | undefined;
}, AIError, never>;
export declare const finishEvents: (state: ParserState) => Effect.Effect<({
    readonly type: "step-start";
    readonly index: number;
} | {
    readonly type: "raw";
    readonly data: unknown;
} | {
    readonly type: "text-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-start";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-delta";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly text: string;
    readonly input?: unknown;
} | {
    readonly type: "tool-input-end";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-error";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly raw: string;
} | {
    readonly type: "tool-call";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly input: unknown;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-result";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly result: {
        readonly type: "json";
        readonly value: unknown;
    } | {
        readonly type: "text";
        readonly value: unknown;
    } | {
        readonly type: "error";
        readonly value: unknown;
    } | {
        readonly type: "content";
        readonly value: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    };
    readonly output?: {
        readonly structured: unknown;
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    } | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "step-finish";
    readonly index: number;
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: Usage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "finish";
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: Usage | undefined;
    readonly message?: AssistantMessage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "media";
    readonly media: import("../media.js").Asset;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | ({
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
})))[], AIError, never>;
/**
 * The OpenAI Chat protocol — request body construction, body schema, and the
 * streaming-event state machine. Reused by every route that speaks OpenAI Chat
 * over HTTP+SSE: native OpenAI, DeepSeek, TogetherAI, Cerebras, Baseten,
 * Fireworks, DeepInfra, and (once added) Azure OpenAI Chat.
 */
export declare const protocol: Protocol<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: OpenResponsesOptions.ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
}, string, "[DONE]" | {
    readonly [x: string]: unknown;
    readonly choices?: readonly {
        readonly [x: string]: unknown;
        readonly delta?: {
            readonly [x: string]: unknown;
            readonly content?: string | null | undefined;
            readonly refusal?: string | null | undefined;
            readonly reasoning_content?: string | null | undefined;
            readonly reasoning?: string | null | undefined;
            readonly reasoning_text?: string | null | undefined;
            readonly reasoning_details?: unknown;
            readonly reasoning_opaque?: string | null | undefined;
            readonly tool_calls?: readonly {
                readonly index?: number | null | undefined;
                readonly id?: string | null | undefined;
                readonly function?: {
                    readonly name?: string | null | undefined;
                    readonly arguments?: string | null | undefined;
                } | null | undefined;
                readonly custom?: {
                    readonly name?: string | null | undefined;
                    readonly input?: string | null | undefined;
                } | null | undefined;
                readonly extra_content?: unknown;
            }[] | null | undefined;
        } | null | undefined;
        readonly finish_reason?: string | null | undefined;
        readonly native_finish_reason?: string | null | undefined;
        readonly usage?: {
            readonly [x: string]: unknown;
            readonly prompt_tokens?: number | null | undefined;
            readonly completion_tokens?: number | null | undefined;
            readonly total_tokens?: number | null | undefined;
            readonly cached_tokens?: number | null | undefined;
            readonly prompt_cache_hit_tokens?: number | null | undefined;
            readonly cache_read_input_tokens?: number | null | undefined;
            readonly cache_created_input_tokens?: number | null | undefined;
            readonly reasoning_tokens?: number | null | undefined;
            readonly prompt_tokens_details?: {
                readonly [x: string]: unknown;
                readonly cached_tokens?: number | null | undefined;
                readonly cache_write_tokens?: number | null | undefined;
            } | null | undefined;
            readonly completion_tokens_details?: {
                readonly [x: string]: unknown;
                readonly reasoning_tokens?: number | null | undefined;
                readonly accepted_prediction_tokens?: number | null | undefined;
                readonly rejected_prediction_tokens?: number | null | undefined;
            } | null | undefined;
        } | null | undefined;
    }[] | null | undefined;
    readonly usage?: {
        readonly [x: string]: unknown;
        readonly prompt_tokens?: number | null | undefined;
        readonly completion_tokens?: number | null | undefined;
        readonly total_tokens?: number | null | undefined;
        readonly cached_tokens?: number | null | undefined;
        readonly prompt_cache_hit_tokens?: number | null | undefined;
        readonly cache_read_input_tokens?: number | null | undefined;
        readonly cache_created_input_tokens?: number | null | undefined;
        readonly reasoning_tokens?: number | null | undefined;
        readonly prompt_tokens_details?: {
            readonly [x: string]: unknown;
            readonly cached_tokens?: number | null | undefined;
            readonly cache_write_tokens?: number | null | undefined;
        } | null | undefined;
        readonly completion_tokens_details?: {
            readonly [x: string]: unknown;
            readonly reasoning_tokens?: number | null | undefined;
            readonly accepted_prediction_tokens?: number | null | undefined;
            readonly rejected_prediction_tokens?: number | null | undefined;
        } | null | undefined;
    } | null | undefined;
    readonly error?: {
        readonly [x: string]: unknown;
        readonly code?: string | number | null | undefined;
        readonly message: string;
    } | null | undefined;
}, ParserState>;
export declare const framing: Framing.Definition<string>;
export declare const httpTransport: HttpTransport.HttpJsonTransport<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: OpenResponsesOptions.ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
}, string>;
export declare const route: Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: OpenResponsesOptions.ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
}, HttpTransport.HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>;
export * as OpenAIChat from "./openai-chat.js";
