import { ImageModel, ImageResponse, type ImageRequest } from "../image.js";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type OpenString } from "../schema/index.js";
export declare const DEFAULT_BASE_URL = "https://api.x.ai/v1";
export declare const PATH = "/images/generations";
export declare const EDIT_PATH = "/images/edits";
/** Provider-native options. Common fields (`n`, `aspect`, `resolution`, `images`) live on the request. */
export type XAIImageOptions = {
    /** Defaults to `b64_json`; `url` returns a short-lived hosted URL instead. */
    readonly responseFormat?: OpenString<"url" | "b64_json">;
    readonly response_format?: OpenString<"url" | "b64_json">;
} & Record<string, unknown>;
export type Request = ImageRequest<ImageModel<XAIImageOptions>>;
/** xAI renders `1k` or `2k`; other tiers use the nearest one. */
export declare const resolution: (request: {
    readonly resolution?: string;
}) => "1k" | "2k" | undefined;
export declare const protocol: MediaProtocol.Inline<Request, ImageResponse>;
export declare const model: (input: MediaRoute.ModelInput) => ImageModel<XAIImageOptions>;
export declare const XAIImages: {
    readonly protocol: MediaProtocol.Inline<Request, ImageResponse>;
    readonly model: typeof model;
    readonly resolution: typeof resolution;
};
