import { Schema } from "effect";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { TranscriptionModel, type TranscriptionRequest, type TranscriptionSegment } from "../transcription.js";
export declare const DEFAULT_BASE_URL = "https://api.openai.com/v1";
export declare const PATH = "/audio/transcriptions";
export type OpenAITranscriptionOptions = {
    readonly chunking_strategy?: "auto" | {
        readonly type: "server_vad";
        readonly prefix_padding_ms?: number;
        readonly silence_duration_ms?: number;
        readonly threshold?: number;
    };
    readonly include?: ReadonlyArray<"logprobs">;
    readonly keywords?: ReadonlyArray<string>;
    readonly known_speaker_names?: ReadonlyArray<string>;
    readonly known_speaker_references?: ReadonlyArray<string>;
    readonly temperature?: number;
} & Record<string, unknown>;
export type Request = TranscriptionRequest<TranscriptionModel<OpenAITranscriptionOptions>>;
declare const Transcript: Schema.Struct<{
    text: Schema.String;
    language: Schema.optional<Schema.String>;
    languages: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly code: Schema.String;
    }>>>;
    duration: Schema.optional<Schema.Number>;
    segments: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly start: Schema.Number;
        readonly end: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
    }>>>;
    words: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly word: Schema.String;
        readonly start: Schema.Number;
        readonly end: Schema.Number;
    }>>>;
    usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input_tokens: Schema.optional<Schema.Number>;
        readonly output_tokens: Schema.optional<Schema.Number>;
        readonly total_tokens: Schema.optional<Schema.Number>;
        readonly input_token_details: Schema.optional<Schema.Struct<{
            readonly audio_tokens: Schema.optional<Schema.Number>;
            readonly text_tokens: Schema.optional<Schema.Number>;
        }>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"duration">;
        readonly seconds: Schema.Number;
    }>]>>;
}>;
type Transcript = Schema.Schema.Type<typeof Transcript>;
type Frame = string | {
    readonly document: string;
};
interface State {
    readonly segments: Array<TranscriptionSegment>;
    readonly transcript?: Transcript;
}
export declare const protocol: MediaProtocol.Streamed<Request, {
    readonly type: "text-delta";
    readonly delta: string;
} | {
    readonly type: "segment";
    readonly segment: {
        readonly text: string;
        readonly startSeconds: number;
        readonly endSeconds: number;
        readonly speaker?: string | undefined;
    };
} | {
    readonly type: "generation-queued";
    readonly id: string;
    readonly position?: number | undefined;
} | {
    readonly type: "generation-progress";
    readonly id: string;
    readonly progress?: number | undefined;
} | {
    readonly text: string;
    readonly segments?: readonly {
        readonly text: string;
        readonly startSeconds: number;
        readonly endSeconds: number;
        readonly speaker?: string | undefined;
    }[] | undefined;
    readonly words?: readonly {
        readonly text: string;
        readonly startSeconds: number;
        readonly endSeconds: number;
        readonly speaker?: string | undefined;
        readonly confidence?: number | undefined;
    }[] | undefined;
    readonly language?: string | undefined;
    readonly durationSeconds?: number | undefined;
    readonly usage?: {
        readonly type: "seconds";
        readonly seconds: number;
    } | {
        readonly type: "characters";
        readonly characters: number;
    } | {
        readonly type: "credits";
        readonly credits: number;
    } | {
        readonly type: "compute";
        readonly seconds: number;
    } | {
        readonly type: "tokens";
        readonly input?: number | undefined;
        readonly output?: number | undefined;
        readonly total?: number | undefined;
        readonly details?: {
            readonly [x: string]: unknown;
        } | undefined;
    } | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
    readonly type: "finish";
}, Frame, State>;
export declare const model: (input: MediaRoute.ModelInput) => TranscriptionModel<OpenAITranscriptionOptions>;
export declare const OpenAITranscription: {
    readonly protocol: MediaProtocol.Streamed<Request, {
        readonly type: "text-delta";
        readonly delta: string;
    } | {
        readonly type: "segment";
        readonly segment: {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        };
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly text: string;
        readonly segments?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        }[] | undefined;
        readonly words?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
            readonly confidence?: number | undefined;
        }[] | undefined;
        readonly language?: string | undefined;
        readonly durationSeconds?: number | undefined;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
        readonly type: "finish";
    }, Frame, State>;
    readonly model: typeof model;
};
export {};
