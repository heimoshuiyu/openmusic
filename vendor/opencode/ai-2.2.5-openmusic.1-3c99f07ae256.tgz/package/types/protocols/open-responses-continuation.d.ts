import { AIError } from "../schema/index.js";
import type { ChannelCreate, ChannelObservation, WebSocketChannelDriver } from "../route/transport/index.js";
import { Effect } from "effect";
import { OpenResponses } from "./open-responses.js";
/**
 * Fields to send next to `previous_response_id` on an incremental step, or undefined to send the step in full.
 * Whether omitted fields carry over from the continued response is provider behavior the route must know.
 */
export type Shape = (request: Readonly<Record<string, unknown>>) => Readonly<Record<string, unknown>> | undefined;
export interface DriverInput {
    readonly id: string;
    readonly name: string;
    readonly request: Readonly<Record<string, unknown>>;
    readonly base: (create: ChannelCreate, frame: string, event: OpenResponses.Event) => Effect.Effect<ChannelObservation, AIError>;
    readonly continuation?: Shape;
}
export declare const driver: (input: DriverInput) => WebSocketChannelDriver;
export * as OpenResponsesContinuation from "./open-responses-continuation.js";
