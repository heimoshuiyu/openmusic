import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { SpeechModel, type SpeechRequest } from "../speech.js";
import { GeminiGenerateContent } from "./utils/gemini-generate-content.js";
import { SpeechStream } from "./utils/speech-stream.js";
export declare const DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta";
/** Style is directed in the text itself, and `speechConfig.multiSpeakerVoiceConfig` excludes `voice`. */
export type GoogleSpeechOptions = {
    readonly temperature?: number;
    readonly seed?: number;
    readonly speechConfig?: {
        readonly multiSpeakerVoiceConfig?: {
            readonly speakerVoiceConfigs: ReadonlyArray<{
                readonly speaker: string;
                readonly voiceConfig: {
                    readonly prebuiltVoiceConfig: {
                        readonly voiceName: string;
                    };
                };
            }>;
        };
    };
} & Record<string, unknown>;
export type Request = SpeechRequest<SpeechModel<GoogleSpeechOptions>>;
interface State extends SpeechStream.Audio, GeminiGenerateContent.Metadata {
    readonly mimeType?: string;
}
export declare const protocol: MediaProtocol.Streamed<Request, {
    readonly type: "audio-delta";
    readonly chunk: Uint8Array<ArrayBufferLike>;
} | {
    readonly type: "timestamps";
    readonly items: readonly {
        readonly text: string;
        readonly startSeconds: number;
        readonly endSeconds: number;
    }[];
} | {
    readonly type: "generation-queued";
    readonly id: string;
    readonly position?: number | undefined;
} | {
    readonly type: "generation-progress";
    readonly id: string;
    readonly progress?: number | undefined;
} | {
    readonly type: "finish";
    readonly audio: import("../media.js").Asset;
    readonly usage?: {
        readonly type: "seconds";
        readonly seconds: number;
    } | {
        readonly type: "characters";
        readonly characters: number;
    } | {
        readonly type: "credits";
        readonly credits: number;
    } | {
        readonly type: "compute";
        readonly seconds: number;
    } | {
        readonly type: "tokens";
        readonly input?: number | undefined;
        readonly output?: number | undefined;
        readonly total?: number | undefined;
        readonly details?: {
            readonly [x: string]: unknown;
        } | undefined;
    } | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
}, string, State>;
export declare const model: (input: MediaRoute.ModelInput) => SpeechModel<GoogleSpeechOptions>;
export declare const GoogleSpeech: {
    readonly protocol: MediaProtocol.Streamed<Request, {
        readonly type: "audio-delta";
        readonly chunk: Uint8Array<ArrayBufferLike>;
    } | {
        readonly type: "timestamps";
        readonly items: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
        }[];
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly type: "finish";
        readonly audio: import("../media.js").Asset;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, string, State>;
    readonly model: typeof model;
};
export {};
