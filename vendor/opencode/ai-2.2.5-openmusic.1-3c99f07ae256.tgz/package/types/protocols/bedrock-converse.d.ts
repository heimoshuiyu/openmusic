import { Schema } from "effect";
import { Route } from "../route/client.js";
import { Protocol } from "../route/protocol.js";
import { Usage, type FinishReasonDetails, type ProviderOptions } from "../schema/index.js";
import { Lifecycle } from "./utils/lifecycle.js";
import { ToolStream } from "./utils/tool-stream.js";
export type { Credentials as BedrockCredentials } from "./utils/bedrock-auth.js";
declare const BedrockConverseBody: Schema.Struct<{
    modelId: Schema.String;
    messages: Schema.$Array<Schema.toTaggedUnion<"role", readonly [Schema.Struct<{
        readonly role: Schema.Literal<"user">;
        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly image: Schema.Struct<{
                readonly format: Schema.Literals<readonly ["png", "jpeg", "gif", "webp"]>;
                readonly source: Schema.Struct<{
                    readonly bytes: Schema.String;
                }>;
            }>;
        }>, Schema.Struct<{
            readonly document: Schema.Struct<{
                readonly format: Schema.Literals<readonly ["pdf", "csv", "doc", "docx", "xls", "xlsx", "html", "txt", "md"]>;
                readonly name: Schema.String;
                readonly source: Schema.Struct<{
                    readonly bytes: Schema.String;
                }>;
            }>;
        }>, Schema.Struct<{
            readonly toolResult: Schema.Struct<{
                readonly toolUseId: Schema.String;
                readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly json: Schema.Unknown;
                }>, Schema.Struct<{
                    readonly image: Schema.Struct<{
                        readonly format: Schema.Literals<readonly ["png", "jpeg", "gif", "webp"]>;
                        readonly source: Schema.Struct<{
                            readonly bytes: Schema.String;
                        }>;
                    }>;
                }>, Schema.Struct<{
                    readonly document: Schema.Struct<{
                        readonly format: Schema.Literals<readonly ["pdf", "csv", "doc", "docx", "xls", "xlsx", "html", "txt", "md"]>;
                        readonly name: Schema.String;
                        readonly source: Schema.Struct<{
                            readonly bytes: Schema.String;
                        }>;
                    }>;
                }>]>>;
                readonly status: Schema.optional<Schema.Literals<readonly ["success", "error"]>>;
            }>;
        }>, Schema.Struct<{
            readonly cachePoint: Schema.Struct<{
                readonly type: Schema.tag<"default">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>;
        }>]>>;
    }>, Schema.Struct<{
        readonly role: Schema.Literal<"assistant">;
        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly reasoningContent: Schema.Union<readonly [Schema.Struct<{
                readonly reasoningText: Schema.Struct<{
                    readonly text: Schema.String;
                    readonly signature: Schema.optional<Schema.String>;
                }>;
            }>, Schema.Struct<{
                readonly redactedContent: Schema.String;
            }>]>;
        }>, Schema.Struct<{
            readonly toolUse: Schema.Struct<{
                readonly toolUseId: Schema.String;
                readonly name: Schema.String;
                readonly input: Schema.Unknown;
            }>;
        }>, Schema.Struct<{
            readonly cachePoint: Schema.Struct<{
                readonly type: Schema.tag<"default">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>;
        }>]>>;
    }>]>>;
    system: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly cachePoint: Schema.Struct<{
            readonly type: Schema.tag<"default">;
            readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
        }>;
    }>]>>>;
    inferenceConfig: Schema.optional<Schema.Struct<{
        readonly maxTokens: Schema.optional<Schema.Number>;
        readonly temperature: Schema.optional<Schema.Number>;
        readonly topP: Schema.optional<Schema.Number>;
        readonly stopSequences: Schema.optional<Schema.$Array<Schema.String>>;
    }>>;
    toolConfig: Schema.optional<Schema.Struct<{
        readonly tools: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly toolSpec: Schema.Struct<{
                readonly name: Schema.String;
                readonly description: Schema.optional<Schema.String>;
                readonly inputSchema: Schema.Struct<{
                    readonly json: Schema.$Record<Schema.String, Schema.Unknown>;
                }>;
            }>;
        }>, Schema.Struct<{
            readonly cachePoint: Schema.Struct<{
                readonly type: Schema.tag<"default">;
                readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
            }>;
        }>]>>;
        readonly toolChoice: Schema.optional<Schema.Union<readonly [Schema.Struct<{
            readonly auto: Schema.Struct<{}>;
        }>, Schema.Struct<{
            readonly any: Schema.Struct<{}>;
        }>, Schema.Struct<{
            readonly tool: Schema.Struct<{
                readonly name: Schema.String;
            }>;
        }>]>>;
    }>>;
    additionalModelRequestFields: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    serviceTier: Schema.optional<Schema.Struct<{
        readonly type: Schema.declare<import("../schema/options.js").OpenString<"default" | "flex" | "priority" | "reserved">, import("../schema/options.js").OpenString<"default" | "flex" | "priority" | "reserved">>;
    }>>;
    guardrailConfig: Schema.optional<Schema.Struct<{
        readonly guardrailIdentifier: Schema.String;
        readonly guardrailVersion: Schema.String;
        readonly trace: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"disabled" | "enabled" | "enabled_full">, import("../schema/options.js").OpenString<"disabled" | "enabled" | "enabled_full">>>;
        readonly streamProcessingMode: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"async" | "sync">, import("../schema/options.js").OpenString<"async" | "sync">>>;
    }>>;
    outputConfig: Schema.optional<Schema.Struct<{
        readonly textFormat: Schema.Struct<{
            readonly type: Schema.declare<import("../schema/options.js").OpenString<"json_schema">, import("../schema/options.js").OpenString<"json_schema">>;
            readonly structure: Schema.Struct<{
                readonly jsonSchema: Schema.Struct<{
                    readonly schema: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                    readonly description: Schema.optional<Schema.String>;
                }>;
            }>;
        }>;
    }>>;
    requestMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
}>;
export type BedrockConverseBody = Schema.Schema.Type<typeof BedrockConverseBody>;
declare const Options: Schema.Struct<{
    /** Claude thinking. `adaptive` and `disabled` apply to Claude models only. */
    readonly thinking: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"enabled">;
        readonly budgetTokens: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"adaptive">;
        readonly display: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"omitted" | "summarized">, import("../schema/options.js").OpenString<"omitted" | "summarized">>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"disabled">;
    }>]>>;
    /** Reasoning effort, sent in the field each model family reads. */
    readonly effort: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"high" | "low" | "max" | "medium" | "xhigh">, import("../schema/options.js").OpenString<"high" | "low" | "max" | "medium" | "xhigh">>>;
    readonly serviceTier: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"default" | "flex" | "priority" | "reserved">, import("../schema/options.js").OpenString<"default" | "flex" | "priority" | "reserved">>>;
    /** Constrains the response text to a JSON schema. */
    readonly outputFormat: Schema.optional<Schema.Struct<{
        readonly type: Schema.declare<import("../schema/options.js").OpenString<"json_schema">, import("../schema/options.js").OpenString<"json_schema">>;
        readonly schema: Schema.$Record<Schema.String, Schema.Unknown>;
        readonly name: Schema.optional<Schema.String>;
        readonly description: Schema.optional<Schema.String>;
    }>>;
    readonly guardrail: Schema.optional<Schema.Struct<{
        readonly identifier: Schema.String;
        readonly version: Schema.String;
        readonly trace: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"disabled" | "enabled" | "enabled_full">, import("../schema/options.js").OpenString<"disabled" | "enabled" | "enabled_full">>>;
        readonly streamProcessingMode: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"async" | "sync">, import("../schema/options.js").OpenString<"async" | "sync">>>;
    }>>;
    /** Key-value pairs for filtering invocation logs. */
    readonly requestMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
}>;
/** Caller-facing provider options; unknown keys are accepted and ignored. */
export type OptionsInput = ProviderOptions & typeof Options.Encoded;
/**
 * The Bedrock Converse protocol — request body construction, body schema, and
 * the streaming-event state machine.
 */
export declare const protocol: Protocol<{
    readonly modelId: string;
    readonly messages: readonly ({
        readonly role: "user";
        readonly content: readonly ({
            readonly cachePoint: {
                readonly type: "default";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            };
        } | {
            readonly image: {
                readonly format: "gif" | "jpeg" | "png" | "webp";
                readonly source: {
                    readonly bytes: string;
                };
            };
        } | {
            readonly document: {
                readonly format: "csv" | "doc" | "docx" | "html" | "md" | "pdf" | "txt" | "xls" | "xlsx";
                readonly name: string;
                readonly source: {
                    readonly bytes: string;
                };
            };
        } | {
            readonly text: string;
        } | {
            readonly toolResult: {
                readonly toolUseId: string;
                readonly content: readonly ({
                    readonly image: {
                        readonly format: "gif" | "jpeg" | "png" | "webp";
                        readonly source: {
                            readonly bytes: string;
                        };
                    };
                } | {
                    readonly document: {
                        readonly format: "csv" | "doc" | "docx" | "html" | "md" | "pdf" | "txt" | "xls" | "xlsx";
                        readonly name: string;
                        readonly source: {
                            readonly bytes: string;
                        };
                    };
                } | {
                    readonly text: string;
                } | {
                    readonly json: unknown;
                })[];
                readonly status?: "error" | "success" | undefined;
            };
        })[];
    } | {
        readonly role: "assistant";
        readonly content: readonly ({
            readonly cachePoint: {
                readonly type: "default";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            };
        } | {
            readonly text: string;
        } | {
            readonly toolUse: {
                readonly toolUseId: string;
                readonly name: string;
                readonly input: unknown;
            };
        } | {
            readonly reasoningContent: {
                readonly reasoningText: {
                    readonly text: string;
                    readonly signature?: string | undefined;
                };
            } | {
                readonly redactedContent: string;
            };
        })[];
    })[];
    readonly system?: readonly ({
        readonly cachePoint: {
            readonly type: "default";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        };
    } | {
        readonly text: string;
    })[] | undefined;
    readonly inferenceConfig?: {
        readonly maxTokens?: number | undefined;
        readonly temperature?: number | undefined;
        readonly topP?: number | undefined;
        readonly stopSequences?: readonly string[] | undefined;
    } | undefined;
    readonly toolConfig?: {
        readonly tools: readonly ({
            readonly cachePoint: {
                readonly type: "default";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            };
        } | {
            readonly toolSpec: {
                readonly name: string;
                readonly description?: string | undefined;
                readonly inputSchema: {
                    readonly json: {
                        readonly [x: string]: unknown;
                    };
                };
            };
        })[];
        readonly toolChoice?: {
            readonly auto: {};
        } | {
            readonly any: {};
        } | {
            readonly tool: {
                readonly name: string;
            };
        } | undefined;
    } | undefined;
    readonly additionalModelRequestFields?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly serviceTier?: {
        readonly type: import("../schema/options.js").OpenString<"default" | "flex" | "priority" | "reserved">;
    } | undefined;
    readonly guardrailConfig?: {
        readonly guardrailIdentifier: string;
        readonly guardrailVersion: string;
        readonly trace?: import("../schema/options.js").OpenString<"disabled" | "enabled" | "enabled_full"> | undefined;
        readonly streamProcessingMode?: import("../schema/options.js").OpenString<"async" | "sync"> | undefined;
    } | undefined;
    readonly outputConfig?: {
        readonly textFormat: {
            readonly type: import("../schema/options.js").OpenString<"json_schema">;
            readonly structure: {
                readonly jsonSchema: {
                    readonly schema: string;
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                };
            };
        };
    } | undefined;
    readonly requestMetadata?: {
        readonly [x: string]: string;
    } | undefined;
}, {
    readonly [x: string]: unknown;
    readonly rawBody: string;
}, {
    readonly messageStart?: {
        readonly role: string;
    } | undefined;
    readonly contentBlockStart?: {
        readonly contentBlockIndex: number;
        readonly start?: {
            readonly toolUse?: {
                readonly toolUseId: string;
                readonly name: string;
            } | undefined;
        } | undefined;
    } | undefined;
    readonly contentBlockDelta?: {
        readonly contentBlockIndex: number;
        readonly delta?: {
            readonly text?: string | undefined;
            readonly toolUse?: {
                readonly input: string;
            } | undefined;
            readonly reasoningContent?: {
                readonly text?: string | undefined;
                readonly signature?: string | undefined;
                readonly redactedContent?: string | undefined;
                readonly data?: string | undefined;
            } | undefined;
        } | undefined;
    } | undefined;
    readonly contentBlockStop?: {
        readonly contentBlockIndex: number;
    } | undefined;
    readonly messageStop?: {
        readonly stopReason: string;
        readonly additionalModelResponseFields?: unknown;
    } | undefined;
    readonly metadata?: {
        readonly usage?: {
            readonly inputTokens?: number | undefined;
            readonly outputTokens?: number | undefined;
            readonly totalTokens?: number | undefined;
            readonly cacheReadInputTokens?: number | undefined;
            readonly cacheWriteInputTokens?: number | undefined;
        } | undefined;
        readonly metrics?: unknown;
    } | undefined;
    readonly exception?: {
        readonly type: string;
        readonly details: {
            readonly message?: string | undefined;
            readonly originalMessage?: string | undefined;
            readonly originalStatusCode?: number | undefined;
        };
    } | undefined;
}, {
    readonly providerMetadataKey: string;
    readonly tools: ToolStream.State<number>;
    readonly finishReason: FinishReasonDetails | undefined;
    readonly usage: Usage | undefined;
    readonly hasToolCalls: boolean;
    readonly reasoningSignatures: Readonly<Record<number, string>>;
    readonly reasoningRedactedContent: Readonly<Record<number, Uint8Array[]>>;
    readonly lifecycle: Lifecycle.State;
}>;
export declare const route: Route<{
    readonly modelId: string;
    readonly messages: readonly ({
        readonly role: "user";
        readonly content: readonly ({
            readonly cachePoint: {
                readonly type: "default";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            };
        } | {
            readonly image: {
                readonly format: "gif" | "jpeg" | "png" | "webp";
                readonly source: {
                    readonly bytes: string;
                };
            };
        } | {
            readonly document: {
                readonly format: "csv" | "doc" | "docx" | "html" | "md" | "pdf" | "txt" | "xls" | "xlsx";
                readonly name: string;
                readonly source: {
                    readonly bytes: string;
                };
            };
        } | {
            readonly text: string;
        } | {
            readonly toolResult: {
                readonly toolUseId: string;
                readonly content: readonly ({
                    readonly image: {
                        readonly format: "gif" | "jpeg" | "png" | "webp";
                        readonly source: {
                            readonly bytes: string;
                        };
                    };
                } | {
                    readonly document: {
                        readonly format: "csv" | "doc" | "docx" | "html" | "md" | "pdf" | "txt" | "xls" | "xlsx";
                        readonly name: string;
                        readonly source: {
                            readonly bytes: string;
                        };
                    };
                } | {
                    readonly text: string;
                } | {
                    readonly json: unknown;
                })[];
                readonly status?: "error" | "success" | undefined;
            };
        })[];
    } | {
        readonly role: "assistant";
        readonly content: readonly ({
            readonly cachePoint: {
                readonly type: "default";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            };
        } | {
            readonly text: string;
        } | {
            readonly toolUse: {
                readonly toolUseId: string;
                readonly name: string;
                readonly input: unknown;
            };
        } | {
            readonly reasoningContent: {
                readonly reasoningText: {
                    readonly text: string;
                    readonly signature?: string | undefined;
                };
            } | {
                readonly redactedContent: string;
            };
        })[];
    })[];
    readonly system?: readonly ({
        readonly cachePoint: {
            readonly type: "default";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        };
    } | {
        readonly text: string;
    })[] | undefined;
    readonly inferenceConfig?: {
        readonly maxTokens?: number | undefined;
        readonly temperature?: number | undefined;
        readonly topP?: number | undefined;
        readonly stopSequences?: readonly string[] | undefined;
    } | undefined;
    readonly toolConfig?: {
        readonly tools: readonly ({
            readonly cachePoint: {
                readonly type: "default";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            };
        } | {
            readonly toolSpec: {
                readonly name: string;
                readonly description?: string | undefined;
                readonly inputSchema: {
                    readonly json: {
                        readonly [x: string]: unknown;
                    };
                };
            };
        })[];
        readonly toolChoice?: {
            readonly auto: {};
        } | {
            readonly any: {};
        } | {
            readonly tool: {
                readonly name: string;
            };
        } | undefined;
    } | undefined;
    readonly additionalModelRequestFields?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly serviceTier?: {
        readonly type: import("../schema/options.js").OpenString<"default" | "flex" | "priority" | "reserved">;
    } | undefined;
    readonly guardrailConfig?: {
        readonly guardrailIdentifier: string;
        readonly guardrailVersion: string;
        readonly trace?: import("../schema/options.js").OpenString<"disabled" | "enabled" | "enabled_full"> | undefined;
        readonly streamProcessingMode?: import("../schema/options.js").OpenString<"async" | "sync"> | undefined;
    } | undefined;
    readonly outputConfig?: {
        readonly textFormat: {
            readonly type: import("../schema/options.js").OpenString<"json_schema">;
            readonly structure: {
                readonly jsonSchema: {
                    readonly schema: string;
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                };
            };
        };
    } | undefined;
    readonly requestMetadata?: {
        readonly [x: string]: string;
    } | undefined;
}, import("../route/transport/http.js").HttpPrepared<{
    readonly [x: string]: unknown;
    readonly rawBody: string;
}>, import("../route/client.js").CompactionOperations | undefined>;
export * as BedrockConverse from "./bedrock-converse.js";
