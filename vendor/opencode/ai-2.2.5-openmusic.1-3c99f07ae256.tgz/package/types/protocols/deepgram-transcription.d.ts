import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type OpenString } from "../schema/index.js";
import { TranscriptionModel, TranscriptionResponse, type TranscriptionRequest } from "../transcription.js";
export declare const DEFAULT_BASE_URL = "https://api.deepgram.com";
export declare const PATH = "/v1/listen";
export type DeepgramTranscriptionOptions = {
    readonly smart_format?: boolean;
    readonly punctuate?: boolean;
    readonly paragraphs?: boolean;
    readonly utterances?: boolean;
    readonly detect_language?: boolean | ReadonlyArray<string>;
    readonly keyterm?: ReadonlyArray<string>;
    readonly diarize_model?: OpenString<"latest" | "v1" | "v2">;
    readonly filler_words?: boolean;
    readonly numerals?: boolean;
    readonly mip_opt_out?: boolean;
    readonly tag?: string | ReadonlyArray<string>;
} & Record<string, unknown>;
export type Request = TranscriptionRequest<TranscriptionModel<DeepgramTranscriptionOptions>>;
export declare const protocol: MediaProtocol.Inline<Request, TranscriptionResponse>;
export declare const model: (input: MediaRoute.ModelInput) => TranscriptionModel<DeepgramTranscriptionOptions>;
export declare const DeepgramTranscription: {
    readonly protocol: MediaProtocol.Inline<Request, TranscriptionResponse>;
    readonly model: typeof model;
};
