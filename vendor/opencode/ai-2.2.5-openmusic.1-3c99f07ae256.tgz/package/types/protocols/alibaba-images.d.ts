import { ImageModel, ImageResponse, type ImageRequest } from "../image.js";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
export declare const PATH = "/services/aigc/multimodal-generation/generation";
/** Provider-native `parameters`. Common fields (`n`, `aspect`, `resolution`, `images`) live on the request. */
export type AlibabaImageOptions = {
    /** Exact `WIDTH*HEIGHT`; it wins over `aspect` and `resolution`. */
    readonly size?: string;
    readonly seed?: number;
    readonly negativePrompt?: string;
    readonly promptExtend?: boolean;
    readonly watermark?: boolean;
    readonly thinkingMode?: boolean;
    readonly enableSequential?: boolean;
} & Record<string, unknown>;
export type Request = ImageRequest<ImageModel<AlibabaImageOptions>>;
export declare const protocol: MediaProtocol.Inline<Request, ImageResponse>;
export declare const model: (input: MediaRoute.ModelInput) => ImageModel<AlibabaImageOptions>;
export declare const AlibabaImages: {
    readonly protocol: MediaProtocol.Inline<Request, ImageResponse>;
    readonly model: typeof model;
};
