import { Schema } from "effect";
import { Protocol } from "../route/protocol.js";
import { OpenAIChat } from "./openai-chat.js";
import { OpenResponsesOptions } from "./utils/open-responses-options.js";
export type ReasoningEffort = OpenResponsesOptions.ReasoningEffort;
declare const Options: Schema.Struct<{
    readonly reasoningEffort: Schema.optional<Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>>;
    readonly reasoning: Schema.optional<Schema.Struct<{
        readonly effort: Schema.optional<Schema.declare<OpenResponsesOptions.ReasoningEffort, OpenResponsesOptions.ReasoningEffort>>;
        readonly enabled: Schema.optional<Schema.Boolean>;
        readonly summary: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"auto" | "concise" | "detailed">, import("../schema/options.js").OpenString<"auto" | "concise" | "detailed">>>;
    }>>;
    readonly veniceParameters: Schema.optional<Schema.Struct<{
        readonly enableWebSearch: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"auto" | "off" | "on">, import("../schema/options.js").OpenString<"auto" | "off" | "on">>>;
        readonly enableWebScraping: Schema.optional<Schema.Boolean>;
        readonly enableWebCitations: Schema.optional<Schema.Boolean>;
        readonly enableXSearch: Schema.optional<Schema.Boolean>;
        readonly stripThinkingResponse: Schema.optional<Schema.Boolean>;
        readonly disableThinking: Schema.optional<Schema.Boolean>;
        readonly includeVeniceSystemPrompt: Schema.optional<Schema.Boolean>;
        readonly characterSlug: Schema.optional<Schema.String>;
        readonly includeSearchResultsInStream: Schema.optional<Schema.Boolean>;
        readonly returnSearchResultsAsDocuments: Schema.optional<Schema.Boolean>;
    }>>;
    readonly promptCacheKey: Schema.optional<Schema.String>;
    readonly promptCacheRetention: Schema.optional<Schema.declare<import("../schema/options.js").OpenString<"24h" | "default" | "extended">, import("../schema/options.js").OpenString<"24h" | "default" | "extended">>>;
    readonly parallelToolCalls: Schema.optional<Schema.Boolean>;
    readonly maxCompletionTokens: Schema.optional<Schema.Number>;
    readonly maxTokens: Schema.optional<Schema.Number>;
    readonly minP: Schema.optional<Schema.Number>;
    readonly repetitionPenalty: Schema.optional<Schema.Number>;
    readonly stopTokenIds: Schema.optional<Schema.$Array<Schema.Number>>;
    readonly logprobs: Schema.optional<Schema.Boolean>;
    readonly topLogprobs: Schema.optional<Schema.Number>;
    readonly maxTemp: Schema.optional<Schema.Number>;
    readonly minTemp: Schema.optional<Schema.Number>;
    readonly responseFormat: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly user: Schema.optional<Schema.String>;
}>;
export type OptionsInput = typeof Options.Type;
interface State {
    readonly shared: OpenAIChat.ParserState;
    readonly pending: string;
    readonly reasoning: string;
    readonly encrypted: boolean;
    readonly signature?: string;
    readonly tools: Readonly<Record<string, string>>;
}
export declare const compatibility: {
    maxTokensField: "max_completion_tokens";
};
export declare const capabilities: {
    promptCacheKey: true;
};
export declare const protocol: Protocol<{
    readonly model: string;
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: OpenResponsesOptions.ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
            readonly thought_signature?: string | undefined;
        })[] | undefined;
        readonly thought_signature?: string | undefined;
    })[];
    readonly reasoning?: {
        readonly effort?: OpenResponsesOptions.ReasoningEffort | undefined;
        readonly enabled?: boolean | undefined;
        readonly summary?: import("../schema/options.js").OpenString<"auto" | "concise" | "detailed"> | undefined;
    } | undefined;
    readonly venice_parameters: {
        readonly [x: string]: string | boolean;
    };
    readonly prompt_cache_retention?: import("../schema/options.js").OpenString<"24h" | "default" | "extended"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly min_p?: number | undefined;
    readonly top_k?: number | undefined;
    readonly repetition_penalty?: number | undefined;
    readonly stop_token_ids?: readonly number[] | undefined;
    readonly logprobs?: boolean | undefined;
    readonly top_logprobs?: number | undefined;
    readonly max_temp?: number | undefined;
    readonly min_temp?: number | undefined;
    readonly response_format?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly user?: string | undefined;
}, string, "[DONE]" | {
    readonly [x: string]: unknown;
    readonly choices?: readonly {
        readonly [x: string]: unknown;
        readonly finish_reason?: string | null | undefined;
        readonly native_finish_reason?: string | null | undefined;
        readonly usage?: {
            readonly [x: string]: unknown;
            readonly prompt_tokens?: number | null | undefined;
            readonly completion_tokens?: number | null | undefined;
            readonly total_tokens?: number | null | undefined;
            readonly cached_tokens?: number | null | undefined;
            readonly prompt_cache_hit_tokens?: number | null | undefined;
            readonly cache_read_input_tokens?: number | null | undefined;
            readonly cache_created_input_tokens?: number | null | undefined;
            readonly reasoning_tokens?: number | null | undefined;
            readonly prompt_tokens_details?: {
                readonly [x: string]: unknown;
                readonly cached_tokens?: number | null | undefined;
                readonly cache_write_tokens?: number | null | undefined;
            } | null | undefined;
            readonly completion_tokens_details?: {
                readonly [x: string]: unknown;
                readonly reasoning_tokens?: number | null | undefined;
                readonly accepted_prediction_tokens?: number | null | undefined;
                readonly rejected_prediction_tokens?: number | null | undefined;
            } | null | undefined;
        } | null | undefined;
        readonly delta?: {
            readonly [x: string]: unknown;
            readonly content?: string | null | undefined;
            readonly refusal?: string | null | undefined;
            readonly reasoning_content?: string | null | undefined;
            readonly reasoning?: string | null | undefined;
            readonly reasoning_text?: string | null | undefined;
            readonly reasoning_details?: unknown;
            readonly reasoning_opaque?: string | null | undefined;
            readonly tool_calls?: readonly {
                readonly index?: number | null | undefined;
                readonly id?: string | null | undefined;
                readonly function?: {
                    readonly name?: string | null | undefined;
                    readonly arguments?: string | null | undefined;
                } | null | undefined;
                readonly custom?: {
                    readonly name?: string | null | undefined;
                    readonly input?: string | null | undefined;
                } | null | undefined;
                readonly extra_content?: unknown;
                readonly thought_signature?: string | null | undefined;
            }[] | null | undefined;
            readonly thought_signature?: string | null | undefined;
        } | null | undefined;
    }[] | null | undefined;
    readonly usage?: {
        readonly [x: string]: unknown;
        readonly prompt_tokens?: number | null | undefined;
        readonly completion_tokens?: number | null | undefined;
        readonly total_tokens?: number | null | undefined;
        readonly cached_tokens?: number | null | undefined;
        readonly prompt_cache_hit_tokens?: number | null | undefined;
        readonly cache_read_input_tokens?: number | null | undefined;
        readonly cache_created_input_tokens?: number | null | undefined;
        readonly reasoning_tokens?: number | null | undefined;
        readonly completion_tokens_details?: {
            readonly [x: string]: unknown;
            readonly reasoning_tokens?: number | null | undefined;
            readonly accepted_prediction_tokens?: number | null | undefined;
            readonly rejected_prediction_tokens?: number | null | undefined;
        } | null | undefined;
        readonly prompt_tokens_details?: {
            readonly [x: string]: unknown;
            readonly cached_tokens?: number | null | undefined;
            readonly cache_write_tokens?: number | null | undefined;
            readonly cache_creation_input_tokens?: number | null | undefined;
        } | null | undefined;
    } | null | undefined;
    readonly error?: string | {
        readonly [x: string]: unknown;
        readonly code?: string | number | null | undefined;
        readonly message: string;
    } | null | undefined;
    readonly issues?: readonly {
        readonly message: string;
        readonly path?: readonly (string | number)[] | undefined;
    }[] | undefined;
}, State>;
export * as VeniceChat from "./venice-chat.js";
