import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { type OpenString } from "../schema/index.js";
import { TranscriptionModel, type TranscriptionRequest, type TranscriptionSegment, type TranscriptionWord } from "../transcription.js";
import { GeminiGenerateContent } from "./utils/gemini-generate-content.js";
export declare const DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta";
/**
 * Merged into `generationConfig`. The API rejects `customVocabulary` and `mode: "SMART"` alongside diarization or word
 * timestamps.
 */
export type GoogleTranscriptionOptions = {
    readonly audioTranscriptionConfig?: {
        readonly mode?: OpenString<"VERBATIM" | "SMART">;
        readonly customVocabulary?: ReadonlyArray<string>;
        readonly languageCodes?: ReadonlyArray<string>;
    };
} & Record<string, unknown>;
export type Request = TranscriptionRequest<TranscriptionModel<GoogleTranscriptionOptions>>;
interface State extends GeminiGenerateContent.Metadata {
    readonly text: string;
    readonly segments: Array<TranscriptionSegment>;
    readonly words: Array<TranscriptionWord>;
}
export declare const protocol: MediaProtocol.Streamed<Request, {
    readonly type: "text-delta";
    readonly delta: string;
} | {
    readonly type: "segment";
    readonly segment: {
        readonly text: string;
        readonly startSeconds: number;
        readonly endSeconds: number;
        readonly speaker?: string | undefined;
    };
} | {
    readonly type: "generation-queued";
    readonly id: string;
    readonly position?: number | undefined;
} | {
    readonly type: "generation-progress";
    readonly id: string;
    readonly progress?: number | undefined;
} | {
    readonly text: string;
    readonly segments?: readonly {
        readonly text: string;
        readonly startSeconds: number;
        readonly endSeconds: number;
        readonly speaker?: string | undefined;
    }[] | undefined;
    readonly words?: readonly {
        readonly text: string;
        readonly startSeconds: number;
        readonly endSeconds: number;
        readonly speaker?: string | undefined;
        readonly confidence?: number | undefined;
    }[] | undefined;
    readonly language?: string | undefined;
    readonly durationSeconds?: number | undefined;
    readonly usage?: {
        readonly type: "seconds";
        readonly seconds: number;
    } | {
        readonly type: "characters";
        readonly characters: number;
    } | {
        readonly type: "credits";
        readonly credits: number;
    } | {
        readonly type: "compute";
        readonly seconds: number;
    } | {
        readonly type: "tokens";
        readonly input?: number | undefined;
        readonly output?: number | undefined;
        readonly total?: number | undefined;
        readonly details?: {
            readonly [x: string]: unknown;
        } | undefined;
    } | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
    readonly type: "finish";
}, string, State>;
export declare const model: (input: MediaRoute.ModelInput) => TranscriptionModel<GoogleTranscriptionOptions>;
export declare const GoogleTranscription: {
    readonly protocol: MediaProtocol.Streamed<Request, {
        readonly type: "text-delta";
        readonly delta: string;
    } | {
        readonly type: "segment";
        readonly segment: {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        };
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly text: string;
        readonly segments?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        }[] | undefined;
        readonly words?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
            readonly confidence?: number | undefined;
        }[] | undefined;
        readonly language?: string | undefined;
        readonly durationSeconds?: number | undefined;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
        readonly type: "finish";
    }, string, State>;
    readonly model: typeof model;
};
export {};
