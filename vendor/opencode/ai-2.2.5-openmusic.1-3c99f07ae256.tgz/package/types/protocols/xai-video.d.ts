import { Schema } from "effect";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
import { VideoModel, VideoResponse, type VideoRequest } from "../video.js";
export declare const DEFAULT_BASE_URL = "https://api.x.ai/v1";
export declare const PATH = "/videos/generations";
export declare const EDIT_PATH = "/videos/edits";
export declare const EXTEND_PATH = "/videos/extensions";
export declare const STATUS_PATH = "/videos";
/**
 * Provider-native options. Common fields (`frames`, `references`, `video`, `durationSeconds`, `aspect`,
 * `resolution`, `audio`) live on the request. `mode` selects the endpoint a `video` input is sent to.
 */
export type XAIVideoOptions = {
    readonly mode?: "edit" | "extend";
    readonly reference_audios?: ReadonlyArray<{
        readonly voice_id: string;
    }>;
} & Record<string, unknown>;
export type Request = VideoRequest<VideoModel<XAIVideoOptions>>;
export declare const Token: Schema.Struct<{
    readonly requestID: Schema.String;
}>;
export type Token = Schema.Schema.Type<typeof Token>;
export declare const protocol: MediaProtocol.Queued<Request, VideoResponse, {
    readonly requestID: string;
}>;
export declare const model: (input: MediaRoute.ModelInput) => VideoModel<XAIVideoOptions>;
export declare const XAIVideo: {
    readonly protocol: MediaProtocol.Queued<Request, VideoResponse, {
        readonly requestID: string;
    }>;
    readonly model: typeof model;
};
