import { Tool } from "@opencode/schema/tool";
import { Effect, Schema } from "effect";
import { Headers, HttpClientRequest } from "effect/http";
import { Media } from "../media.js";
import { AIError, type LLMRequest, Message, ToolDefinition, type ContentPart, type MediaPart, type OpenString, type ProviderID, type RequestEncoding, type ToolEntry, type ToolResultPart } from "../schema/index.js";
import { Json, decodeJson, encodeJson } from "../utils/json.js";
import { isRecord } from "../utils/record.js";
export { Json, decodeJson, encodeJson, isRecord };
export declare const JsonObject: Schema.$Record<Schema.String, Schema.Unknown>;
export declare const optionalArray: <const S extends Schema.Top>(schema: S) => Schema.optional<Schema.$Array<S>>;
export declare const optionalNull: <const S extends Schema.Top>(schema: S) => Schema.optional<Schema.NullOr<S>>;
/** Optional provider field where an explicit `null` means absent, so decoding never yields `null`. */
export declare const optionalNullish: <const S extends Schema.Top>(schema: S) => Schema.decodeTo<Schema.optional<Schema.toType<S>>, Schema.optional<Schema.NullOr<S>>, never, never>;
/** Optional field whose malformed value decodes to `undefined` instead of failing the enclosing struct. */
export declare const lenient: <const S extends Schema.Top>(schema: S) => Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<S>, S["DecodingServices"]>>;
/** Billing an endpoint reports beside its token usage: `cost` is the USD it charged (OpenRouter, LiteLLM, OpenCode Zen). */
export declare const ReportedBilling: Schema.Struct<{
    readonly cost: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.Finite>, never>>;
}>;
/**
 * Reads `ReportedBilling` from a raw usage object, which provider metadata keeps as the endpoint sent it, or
 * Copilot's billing from the frames that carry the usage.
 */
export declare const reportedBilling: (usage: unknown, ...frames: ReadonlyArray<unknown>) => {
    cost: number;
} | {
    cost?: undefined;
};
/**
 * The filter that blocked a response, from maps keyed by filter name: Azure's `content_filter_results`
 * (`{ hate: { filtered: true } }`) or GitHub Copilot's `copilot_annotations` (`{ TextCopyright: [...] }`).
 */
export declare const contentFilterCategory: (...sources: ReadonlyArray<unknown>) => string | undefined;
/**
 * Accepts stream frames that carry no `type`, alongside the typed event schema. Gateways inject such frames as
 * keep-alives, so they decode as an ignored event; one with an `error` still decodes as an error event.
 */
export declare const withUntypedFrames: <const S extends Schema.Codec<{
    readonly type: string;
}, {
    readonly type: string;
}>>(event: S) => Schema.Union<readonly [S, Schema.decodeTo<S, Schema.$Record<Schema.String, Schema.Unknown>, never, never>]>;
/** Provider-defined string enum: known values for autocomplete, any string accepted at runtime. */
export declare const knownString: <Known extends string>() => Schema.declare<OpenString<Known>, OpenString<Known>>;
export declare const OPENAI_PROMPT_CACHE_KEY_MAX_LENGTH = 64;
export declare const sendsPromptCacheKey: (request: LLMRequest) => boolean;
export declare const promptCacheKey: (request: LLMRequest) => string | undefined;
/**
 * Streaming tool-call accumulator. Adapters that build a tool call across
 * multiple `tool-input-delta` chunks store the partial JSON input string here
 * and finalize it with `parseToolInput` once the call completes.
 */
export interface ToolAccumulator {
    readonly id: string;
    readonly name: string;
    readonly namespace?: string;
    readonly input: string;
}
/**
 * `Usage.totalTokens` policy shared by every route. Honors a provider-
 * supplied total; otherwise falls back to `inputTokens + outputTokens` only
 * when at least one is defined. Returns `undefined` when neither input nor
 * output is known so routes don't publish a misleading `0`.
 *
 * Under the inclusive `AI.Usage` contract, `inputTokens` includes cached input
 * and `outputTokens` includes reasoning. Protocol mappers normalize those
 * inclusive values before calling this helper. The provider-supplied total is
 * the source of truth when present; otherwise their sum is the canonical total.
 */
export declare const totalTokens: (inputTokens: number | undefined, outputTokens: number | undefined, total: number | undefined) => number | undefined;
/**
 * Subtract `subtrahend` from `total`, clamping to zero if the provider
 * reports a non-sensical breakdown (e.g. `cached_tokens > prompt_tokens`).
 * Used by protocol mappers when deriving a non-overlapping breakdown field
 * from a provider's inclusive total — `nonCachedInputTokens` from
 * `inputTokens - cacheReadInputTokens - cacheWriteInputTokens`.
 *
 * If `total` is `undefined`, returns `undefined` (we don't fabricate
 * counts). If `subtrahend` is `undefined`, returns `total` unchanged. The
 * provider-native breakdown stays available on `Usage.providerMetadata` for debugging.
 */
export declare const subtractTokens: (total: number | undefined, subtrahend: number | undefined) => number | undefined;
/**
 * Sum a list of optional token counts, returning `undefined` only when
 * every value is `undefined` (so we don't fabricate a `0`). Used by
 * protocol mappers to derive the inclusive `inputTokens` total from a
 * provider that natively reports a non-overlapping breakdown
 * (e.g. Anthropic, whose `input_tokens` is already non-cached only).
 */
export declare const sumTokens: (...values: ReadonlyArray<number | undefined>) => number | undefined;
/**
 * Caps an explicit thinking budget at half the output limit. Thinking counts against the output limit, so a budget
 * near it leaves the answer, a tool call, or a summary without room. Smaller budgets, special values such as `-1` and
 * `0`, and requests without an output limit pass through unchanged.
 */
export declare const fitThinkingBudget: (budget: number, maxTokens: number | undefined, minimum?: number) => number;
export declare const eventError: (route: string, message: string, body?: string, cause?: unknown) => AIError;
export declare const parseJson: (route: string, input: string, message: string) => Effect.Effect<unknown, AIError, never>;
/**
 * Join the `text` field of a list of parts with newlines. Used by routes
 * that flatten system / message content arrays into a single provider string
 * (OpenAI Chat `system` content, OpenAI Responses `system` content, Gemini
 * `systemInstruction.parts[].text`).
 */
export declare const joinText: (parts: ReadonlyArray<{
    readonly text: string;
}>) => string;
/**
 * Stable fallback representation for chronological `Message.system(...)`
 * updates on routes that do not support that privileged role natively. The
 * wrapper remains visibly lower-authority user text, preserves the original
 * temporal position, and XML-escapes content so it cannot close the wrapper.
 */
export declare const wrapSystemUpdate: (parts: ReadonlyArray<{
    readonly text: string;
}>) => string;
/**
 * Chronological system updates deliberately accept text only. Do not insert
 * raw retrieved, tool, or web content into privileged updates: keep untrusted
 * data in ordinary user/tool messages instead.
 */
export declare const systemUpdateText: (route: string, message: Message) => Effect.Effect<{
    readonly type: "text";
    readonly text: string;
    readonly cache?: import("../schema/options.js").CacheHint | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
}[], AIError, never>;
/** Lower an unsupported privileged update into visible, in-order user text. */
export declare const wrappedSystemUpdate: (route: string, message: Message) => Effect.Effect<{
    type: "text";
    text: string;
    cache: import("../schema/options.js").CacheHint | undefined;
}, AIError, never>;
/**
 * Parse the streamed JSON input of a tool call. Treats an empty string as
 * `"{}"` — providers occasionally finish a tool call without ever emitting
 * input deltas (e.g. zero-arg tools). The error message is uniform across
 * routes: `Invalid JSON input for <route> tool call <name>`.
 */
export declare const parseToolInput: (route: string, name: string, raw: string) => Effect.Effect<unknown, AIError, never>;
/** Inline view or a typed `InvalidRequest` for routes that cannot fetch URLs or dereference provider refs. */
export declare const requireInlineMedia: (route: string, asset: Media.Asset) => Effect.Effect<Media.Inline, AIError>;
export declare const inlineRequired: (route: string, asset: Media.Asset) => AIError;
/** The remote URL of a `url` asset, for protocols that accept `http(s)` references natively. */
export declare const mediaUrl: (asset: Media.Asset) => string | undefined;
export type MediaReference = {
    readonly type: "dataUrl" | "url" | "ref";
    readonly value: string;
};
/**
 * The one string a provider can address an asset by: inline payloads as a data URL, `url` sources as their URL, and
 * this provider's own `ref` as its id. Other providers' refs are never forwarded and fail typed; omit `provider` for
 * APIs with no file handles at all.
 */
export declare const mediaReference: (asset: Media.Asset, provider: ProviderID | undefined, label: string) => Effect.Effect<MediaReference, AIError>;
/**
 * Lift a tool-result file into a `MediaPart`. Tool files carry either a data URL, a URI, or raw base64 in
 * `uri`; the declared `mime` wins over any data-URL prefix so tool authors control the type the model sees.
 */
export declare const toolFileMedia: (item: Tool.FileContent) => MediaPart;
export declare const toolResultText: (part: ToolResultPart) => string;
export declare const errorText: (error: unknown) => string;
/**
 * Canonical invalid-request constructor shared by protocol lowering.
 */
export declare const invalidRequest: (message: string, cause?: unknown) => AIError;
/**
 * Canonical constructor for operations the selected route does not implement.
 * Prefer this over `invalidRequest` when the failure is a missing route
 * capability rather than a malformed caller input, so consumers can branch on
 * `reason._tag` plus `reason.operation` instead of matching message text.
 */
export declare const unsupportedOperation: (input: {
    readonly operation: string;
    readonly message: string;
    readonly provider?: ProviderID;
    readonly route?: string;
    readonly cause?: unknown;
}) => AIError;
/**
 * Lower namespaces to flat definitions for protocols without a native
 * namespace construct. Leaf names join their namespace path with `_` because
 * `.` is not broadly accepted in provider tool names.
 */
export declare const flattenTools: (tools: ReadonlyArray<ToolEntry>, path?: ReadonlyArray<string>) => ToolDefinition[];
export declare const flattenToolRequest: (request: LLMRequest) => {
    tools: ToolDefinition[];
    request: LLMRequest<import("../schema/options.js").LanguageModel<{
        readonly [x: string]: unknown;
    }, import("../route.js").CompactionOperations | undefined>>;
};
export declare const matchToolChoice: <Auto, None, Required, Tool>(route: string, toolChoice: NonNullable<LLMRequest["toolChoice"]>, cases: {
    readonly auto: () => Auto;
    readonly none: () => None;
    readonly required: () => Required;
    readonly tool: (name: string) => Tool;
}) => Effect.Effect<Auto | None | Required | Tool, AIError, never>;
type ContentType = ContentPart["type"];
export declare const supportsContent: <const Type extends ContentType>(part: ContentPart, types: ReadonlyArray<Type>) => part is Extract<ContentPart, {
    readonly type: Type;
}>;
export declare const unsupportedContent: (route: string, role: LLMRequest["messages"][number]["role"], types: ReadonlyArray<ContentType>) => AIError;
/**
 * Build a `validate` step from a Schema decoder. Replaces the per-route
 * lambda body `(payload) => decode(payload).pipe(Effect.mapError((e) =>
 * invalid(e.message)))`. Any decode error is translated into
 * `AIError` carrying the original parse-error message.
 */
export declare const validateWith: <A, I, E extends {
    readonly message: string;
}>(decode: (input: I) => Effect.Effect<A, E>) => (payload: I) => Effect.Effect<A, AIError, never>;
/**
 * Build an HTTP POST with a JSON body. Sets `content-type: application/json`
 * automatically after caller-supplied headers so routes cannot accidentally
 * send JSON with a stale content type. The body is passed pre-encoded so
 * routes can choose between
 * `Schema.encodeSync(payload)` and `ProviderShared.encodeJson(payload)`.
 * A `zstd` or `gzip` encoding compresses the body and sets `content-encoding`;
 * it falls back to plain JSON when the runtime has no zlib.
 */
export declare const jsonPost: (input: {
    readonly url: string;
    readonly body: string;
    readonly headers?: Headers.Input;
    readonly encoding?: RequestEncoding;
}) => HttpClientRequest.HttpClientRequest;
export * as ProviderShared from "./shared.js";
