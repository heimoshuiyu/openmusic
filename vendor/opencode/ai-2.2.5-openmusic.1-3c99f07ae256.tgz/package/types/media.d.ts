export * as Media from "./media.js";
import { Effect, FileSystem, Schema } from "effect";
import { ProviderID } from "./schema/ids.js";
import { AIError } from "./schema/errors.js";
import { ProviderMetadata } from "./schema/options.js";
import { Service } from "./route/executor-service.js";
export { detectMediaType } from "./utils/media-type.js";
export declare const Source: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"bytes">;
    readonly data: Schema.Uint8Array;
    readonly mediaType: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"base64">;
    readonly data: Schema.String;
    readonly mediaType: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"url">;
    readonly url: Schema.String;
    readonly mediaType: Schema.optional<Schema.String>;
    /** Epoch milliseconds after which the provider no longer serves the URL. */
    readonly expiresAt: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"ref">;
    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
    readonly id: Schema.String;
    readonly mediaType: Schema.optional<Schema.String>;
}>]>;
export type Source = Schema.Schema.Type<typeof Source>;
export type AspectRatio = `${number}:${number}`;
export declare const AspectRatio: Schema.declare<`${number}:${number}`, `${number}:${number}`>;
export declare const Kind: Schema.Literals<readonly ["image", "video", "audio", "document", "other"]>;
export type Kind = Schema.Schema.Type<typeof Kind>;
export declare const kindOf: (mediaType: string) => Kind;
/** Container-independent facts about the payload; raw PCM audio relies on these because it has no header. */
export declare const Info: Schema.Struct<{
    readonly width: Schema.optional<Schema.Number>;
    readonly height: Schema.optional<Schema.Number>;
    readonly durationSeconds: Schema.optional<Schema.Number>;
    readonly sampleRate: Schema.optional<Schema.Number>;
    readonly channels: Schema.optional<Schema.Number>;
    readonly encoding: Schema.optional<Schema.String>;
    readonly format: Schema.optional<Schema.String>;
}>;
export type Info = Schema.Schema.Type<typeof Info>;
/** Synchronous view of an inline payload; `undefined` for `url` and `ref` sources, which carry no local bytes. */
export interface Inline {
    readonly mime: string;
    readonly base64: string;
    readonly dataUrl: string;
}
export declare class Asset {
    #private;
    readonly source: Source;
    /** Derived from the source: declared type, sniffed magic bytes, then `application/octet-stream`. */
    readonly mediaType: string;
    readonly kind: Kind;
    readonly info?: Info;
    /** Epoch milliseconds after which a `url` source stops resolving. */
    readonly expiresAt?: number;
    readonly providerMetadata?: ProviderMetadata;
    /** Transient download credentials for `url` sources; see `Asset.Input.headers`. */
    readonly headers?: Record<string, string>;
    constructor(input: Asset.Input);
    /** Inline payload without effects, for protocols that embed base64 or data URLs directly. */
    inline(): Inline | undefined;
    /** Decoded payload; downloads `url` sources through the request executor and caches the result. */
    bytes(): Effect.Effect<Uint8Array, AIError, Service>;
    base64(): Effect.Effect<string, AIError, Service>;
    dataUrl(): Effect.Effect<string, AIError, Service>;
    /**
     * The `AssetEncoded` JSON form with `bytes` sources as base64, matching `Schema.toCodecJson(AssetSchema)`, so a
     * plain `JSON.stringify` of messages or events stays lossless and decodes back through the JSON codec.
     */
    toJSON(): {
        source: {
            readonly type: "base64";
            readonly data: string;
            readonly mediaType: string;
        } | {
            readonly type: "url";
            readonly url: string;
            readonly mediaType?: string | undefined;
            readonly expiresAt?: number | undefined;
        } | {
            readonly type: "ref";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id: string;
            readonly mediaType?: string | undefined;
        } | {
            type: "bytes";
            mediaType: string;
            data: string;
        };
        info: {
            readonly width?: number | undefined;
            readonly height?: number | undefined;
            readonly durationSeconds?: number | undefined;
            readonly sampleRate?: number | undefined;
            readonly channels?: number | undefined;
            readonly encoding?: string | undefined;
            readonly format?: string | undefined;
        } | undefined;
        providerMetadata: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    /** Pull `url` sources into owned bytes before the URL expires. Inline sources return themselves. */
    materialize(): Effect.Effect<Asset, AIError, Service>;
}
export declare namespace Asset {
    interface Input {
        readonly source: Source;
        readonly info?: Info;
        readonly providerMetadata?: ProviderMetadata;
        /**
         * Headers required to download a `url` source, such as the provider API key Veo demands for its file URIs.
         * They are runtime-only: never part of `source`, `toJSON()`, or `AssetSchema`, so a persisted asset cannot leak
         * credentials and cannot be downloaded again after a round-trip. Call `materialize()` before persisting.
         */
        readonly headers?: Record<string, string>;
    }
}
/** JSON form of an asset: the serializable `Source` plus caller-supplied metadata. `bytes` sources encode as base64. */
export declare const AssetEncoded: Schema.Struct<{
    readonly source: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"bytes">;
        readonly data: Schema.Uint8Array;
        readonly mediaType: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"base64">;
        readonly data: Schema.String;
        readonly mediaType: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"url">;
        readonly url: Schema.String;
        readonly mediaType: Schema.optional<Schema.String>;
        /** Epoch milliseconds after which the provider no longer serves the URL. */
        readonly expiresAt: Schema.optional<Schema.Number>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"ref">;
        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
        readonly id: Schema.String;
        readonly mediaType: Schema.optional<Schema.String>;
    }>]>;
    readonly info: Schema.optional<Schema.Struct<{
        readonly width: Schema.optional<Schema.Number>;
        readonly height: Schema.optional<Schema.Number>;
        readonly durationSeconds: Schema.optional<Schema.Number>;
        readonly sampleRate: Schema.optional<Schema.Number>;
        readonly channels: Schema.optional<Schema.Number>;
        readonly encoding: Schema.optional<Schema.String>;
        readonly format: Schema.optional<Schema.String>;
    }>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
/** `Asset` in the type domain and `AssetEncoded` on the wire, so messages and events holding assets serialize. */
export declare const AssetSchema: Schema.decodeTo<Schema.declare<Asset, Asset>, Schema.Struct<{
    readonly source: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"bytes">;
        readonly data: Schema.Uint8Array;
        readonly mediaType: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"base64">;
        readonly data: Schema.String;
        readonly mediaType: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"url">;
        readonly url: Schema.String;
        readonly mediaType: Schema.optional<Schema.String>;
        /** Epoch milliseconds after which the provider no longer serves the URL. */
        readonly expiresAt: Schema.optional<Schema.Number>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"ref">;
        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
        readonly id: Schema.String;
        readonly mediaType: Schema.optional<Schema.String>;
    }>]>;
    readonly info: Schema.optional<Schema.Struct<{
        readonly width: Schema.optional<Schema.Number>;
        readonly height: Schema.optional<Schema.Number>;
        readonly durationSeconds: Schema.optional<Schema.Number>;
        readonly sampleRate: Schema.optional<Schema.Number>;
        readonly channels: Schema.optional<Schema.Number>;
        readonly encoding: Schema.optional<Schema.String>;
        readonly format: Schema.optional<Schema.String>;
    }>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, never, never>;
export type AssetOptions = Omit<Asset.Input, "source">;
export declare const from: (source: Source, options?: AssetOptions) => Asset;
export declare const bytes: (data: Uint8Array, mediaType?: string, options?: AssetOptions) => Asset;
export declare const base64: (data: string, mediaType: string, options?: AssetOptions) => Asset;
export declare const url: (value: string, options?: AssetOptions & Omit<Extract<Source, {
    readonly type: "url";
}>, "type" | "url">) => Asset;
export declare const ref: (provider: string | ProviderID, id: string, mediaType?: string, options?: AssetOptions) => Asset;
/** Parse a `data:<mime>;base64,<data>` URL, or `undefined` when the value is not a base64 data URL. */
export declare const parseDataUrl: (value: string, options?: AssetOptions) => Asset | undefined;
/** Parse a `data:<mime>;base64,<data>` URL. Malformed input throws a typed `AIError` because constructors are sync. */
export declare const fromDataUrl: (dataUrl: string, options?: AssetOptions) => Asset;
/** Plain file data: bytes, a URL, or a string holding a data URL, an http(s) URL or base64. */
export type Data = Uint8Array | ArrayBuffer | URL | string;
/** What file inputs accept: an `Asset` or plain `Data`. */
export type Input = Asset | Data;
/**
 * Normalize file input into an `Asset`. Data URLs carry their media type and bytes or base64 are sniffed from magic
 * bytes; `mediaType` is required when sniffing fails. Assets pass through unchanged.
 */
export declare const make: (input: Input, mediaType?: string) => Asset;
/** Read a file through `FileSystem` and sniff its media type from magic bytes, then the extension. */
export declare const file: (path: string, options?: AssetOptions) => Effect.Effect<Asset, AIError, FileSystem.FileSystem>;
/** Materialize an asset and write its bytes through `FileSystem`. */
export declare const write: (asset: Asset, path: string) => Effect.Effect<void, AIError, FileSystem.FileSystem | Service>;
