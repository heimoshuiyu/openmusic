import { Effect, Schema, Stream } from "effect";
import { Generation, type AwaitOptions } from "./generation.js";
import { Media } from "./media.js";
import { MediaModel } from "./media-model.js";
import { MediaRoute } from "./route/media.js";
import { AIError, type BaseRequest } from "./schema/index.js";
import { Service } from "./transcription-client.js";
export type TranscriptionOptions = MediaModel.Options;
export type TranscriptionRoute = MediaRoute.AnyRoute<TranscriptionRequest, TranscriptionEvent, TranscriptionResponse>;
export declare class TranscriptionModel<Options extends TranscriptionOptions = TranscriptionOptions> extends MediaModel<TranscriptionRoute, Options> {
    protected readonly _TranscriptionModel: void;
    /** The number of type arguments selects the kind: `<Options>`, `<Options, Frame, State>`, or `<Options, Token>`. */
    static fromRoute<Options extends TranscriptionOptions>(route: MediaModel.InlineRouteInput<TranscriptionRequest<TranscriptionModel<Options>>, TranscriptionResponse>, input: MediaRoute.ModelInput): TranscriptionModel<Options>;
    static fromRoute<Options extends TranscriptionOptions, Frame, State>(route: MediaModel.StreamRouteInput<TranscriptionRequest<TranscriptionModel<Options>>, TranscriptionEvent, Frame, State>, input: MediaRoute.ModelInput): TranscriptionModel<Options>;
    static fromRoute<Options extends TranscriptionOptions, Token>(route: MediaModel.QueuedRouteInput<TranscriptionRequest<TranscriptionModel<Options>>, TranscriptionResponse, Token>, input: MediaRoute.ModelInput): TranscriptionModel<Options>;
}
export declare const TranscriptionModelSchema: Schema.declare<TranscriptionModel<{
    readonly [x: string]: unknown;
}>, TranscriptionModel<{
    readonly [x: string]: unknown;
}>>;
export declare const TranscriptionTimestamps: Schema.Literals<readonly ["none", "segment", "word"]>;
export type TranscriptionTimestamps = Schema.Schema.Type<typeof TranscriptionTimestamps>;
declare const TranscriptionRequestSchema: Schema.Struct<{
    readonly model: Schema.declare<TranscriptionModel<{
        readonly [x: string]: unknown;
    }>, TranscriptionModel<{
        readonly [x: string]: unknown;
    }>>;
    readonly audio: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly language: Schema.optional<Schema.String>;
    readonly prompt: Schema.optional<Schema.String>;
    /** Routes that cannot produce the requested granularity fail typed; routes may return more than asked. */
    readonly timestamps: Schema.optional<Schema.Literals<readonly ["none", "segment", "word"]>>;
    readonly diarize: Schema.optional<Schema.Boolean>;
    readonly speakers: Schema.optional<Schema.Int>;
    readonly providerOptions: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
}>;
/** A normalized transcription request, the plain object `Transcription.request(...)` returns. */
export type TranscriptionRequest<Model extends TranscriptionModel = TranscriptionModel> = Omit<typeof TranscriptionRequestSchema.Type, "model" | "providerOptions"> & BaseRequest<Model, TranscriptionModelOptions<Model>>;
export type TranscriptionModelOptions<Model> = Model extends TranscriptionModel<infer Options> ? Options : never;
/** Input accepted by `Transcription.request` and the calls; a `TranscriptionRequest` is also a valid input. */
export type TranscriptionRequestInput<Model extends TranscriptionModel = TranscriptionModel> = Omit<TranscriptionRequest<Model>, "providerOptions"> & {
    readonly providerOptions?: NoInfer<TranscriptionModelOptions<Model>>;
};
/** Speaker labels are provider-native (`A`, `0`, `spk:0`, `speaker_0`, or a known speaker name). */
export declare const TranscriptionSegment: Schema.Struct<{
    readonly text: Schema.String;
    readonly startSeconds: Schema.Number;
    readonly endSeconds: Schema.Number;
    readonly speaker: Schema.optional<Schema.String>;
}>;
export type TranscriptionSegment = Schema.Schema.Type<typeof TranscriptionSegment>;
export declare const TranscriptionWord: Schema.Struct<{
    readonly text: Schema.String;
    readonly startSeconds: Schema.Number;
    readonly endSeconds: Schema.Number;
    readonly speaker: Schema.optional<Schema.String>;
    readonly confidence: Schema.optional<Schema.Number>;
}>;
export type TranscriptionWord = Schema.Schema.Type<typeof TranscriptionWord>;
declare const TranscriptionResponse_base: Schema.Class<TranscriptionResponse, Schema.Struct<{
    text: Schema.String;
    segments: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
    }>>>;
    words: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
        readonly confidence: Schema.optional<Schema.Number>;
    }>>>;
    /** Provider-native language as detected or echoed (`en`, `english`, `en_us`), lowercased but not normalized. */
    language: Schema.optional<Schema.String>;
    durationSeconds: Schema.optional<Schema.Number>;
    usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, {}>;
export declare class TranscriptionResponse extends TranscriptionResponse_base {
}
export declare const TranscriptionTextDeltaEvent: Schema.Struct<{
    readonly type: Schema.tag<"text-delta">;
    readonly delta: Schema.String;
}>;
export declare const TranscriptionSegmentEvent: Schema.Struct<{
    readonly type: Schema.tag<"segment">;
    readonly segment: Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
    }>;
}>;
export declare const TranscriptionFinishEvent: Schema.Struct<{
    readonly text: Schema.String;
    readonly segments: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
    }>>>;
    readonly words: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
        readonly confidence: Schema.optional<Schema.Number>;
    }>>>;
    readonly language: Schema.optional<Schema.String>;
    readonly durationSeconds: Schema.optional<Schema.Number>;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    readonly type: Schema.tag<"finish">;
}>;
declare const transcriptionEventTagged: Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
    readonly type: Schema.tag<"generation-queued">;
    readonly id: Schema.String;
    readonly position: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"generation-progress">;
    readonly id: Schema.String;
    readonly progress: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"text-delta">;
    readonly delta: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.tag<"segment">;
    readonly segment: Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
    }>;
}>, Schema.Struct<{
    readonly text: Schema.String;
    readonly segments: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
    }>>>;
    readonly words: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
        readonly confidence: Schema.optional<Schema.Number>;
    }>>>;
    readonly language: Schema.optional<Schema.String>;
    readonly durationSeconds: Schema.optional<Schema.Number>;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    readonly type: Schema.tag<"finish">;
}>]>;
export declare const TranscriptionEvent: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.tag<"generation-queued">;
    readonly id: Schema.String;
    readonly position: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"generation-progress">;
    readonly id: Schema.String;
    readonly progress: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"text-delta">;
    readonly delta: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.tag<"segment">;
    readonly segment: Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
    }>;
}>, Schema.Struct<{
    readonly text: Schema.String;
    readonly segments: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
    }>>>;
    readonly words: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
        readonly speaker: Schema.optional<Schema.String>;
        readonly confidence: Schema.optional<Schema.Number>;
    }>>>;
    readonly language: Schema.optional<Schema.String>;
    readonly durationSeconds: Schema.optional<Schema.Number>;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    readonly type: Schema.tag<"finish">;
}>]> & {
    readonly tag: "type";
    readonly discriminants: readonly ["generation-queued", "generation-progress", "text-delta", "segment", "finish"];
    readonly cases: {
        finish: Schema.Struct<{
            readonly text: Schema.String;
            readonly segments: Schema.optional<Schema.$Array<Schema.Struct<{
                readonly text: Schema.String;
                readonly startSeconds: Schema.Number;
                readonly endSeconds: Schema.Number;
                readonly speaker: Schema.optional<Schema.String>;
            }>>>;
            readonly words: Schema.optional<Schema.$Array<Schema.Struct<{
                readonly text: Schema.String;
                readonly startSeconds: Schema.Number;
                readonly endSeconds: Schema.Number;
                readonly speaker: Schema.optional<Schema.String>;
                readonly confidence: Schema.optional<Schema.Number>;
            }>>>;
            readonly language: Schema.optional<Schema.String>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"tokens">;
                readonly input: Schema.optional<Schema.Number>;
                readonly output: Schema.optional<Schema.Number>;
                readonly total: Schema.optional<Schema.Number>;
                readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"seconds">;
                readonly seconds: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"characters">;
                readonly characters: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"credits">;
                readonly credits: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"compute">;
                readonly seconds: Schema.Number;
            }>]>>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            readonly type: Schema.tag<"finish">;
        }>;
        "generation-progress": Schema.Struct<{
            readonly type: Schema.tag<"generation-progress">;
            readonly id: Schema.String;
            readonly progress: Schema.optional<Schema.Number>;
        }>;
        "generation-queued": Schema.Struct<{
            readonly type: Schema.tag<"generation-queued">;
            readonly id: Schema.String;
            readonly position: Schema.optional<Schema.Number>;
        }>;
        segment: Schema.Struct<{
            readonly type: Schema.tag<"segment">;
            readonly segment: Schema.Struct<{
                readonly text: Schema.String;
                readonly startSeconds: Schema.Number;
                readonly endSeconds: Schema.Number;
                readonly speaker: Schema.optional<Schema.String>;
            }>;
        }>;
        "text-delta": Schema.Struct<{
            readonly type: Schema.tag<"text-delta">;
            readonly delta: Schema.String;
        }>;
    };
    readonly isAnyOf: <const Keys>(keys: readonly Keys[]) => (value: {
        readonly type: "text-delta";
        readonly delta: string;
    } | {
        readonly type: "segment";
        readonly segment: {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        };
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly text: string;
        readonly segments?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        }[] | undefined;
        readonly words?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
            readonly confidence?: number | undefined;
        }[] | undefined;
        readonly language?: string | undefined;
        readonly durationSeconds?: number | undefined;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
        readonly type: "finish";
    }) => value is Extract<{
        readonly type: "text-delta";
        readonly delta: string;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "segment";
        readonly segment: {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        };
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly text: string;
        readonly segments?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
        }[] | undefined;
        readonly words?: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
            readonly speaker?: string | undefined;
            readonly confidence?: number | undefined;
        }[] | undefined;
        readonly language?: string | undefined;
        readonly durationSeconds?: number | undefined;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
        readonly type: "finish";
    }, {
        readonly type: Keys;
    }>;
    readonly guards: {
        finish: (u: unknown) => u is {
            readonly text: string;
            readonly segments?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            }[] | undefined;
            readonly words?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
                readonly confidence?: number | undefined;
            }[] | undefined;
            readonly language?: string | undefined;
            readonly durationSeconds?: number | undefined;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
            readonly type: "finish";
        };
        "generation-progress": (u: unknown) => u is {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        };
        "generation-queued": (u: unknown) => u is {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        };
        segment: (u: unknown) => u is {
            readonly type: "segment";
            readonly segment: {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            };
        };
        "text-delta": (u: unknown) => u is {
            readonly type: "text-delta";
            readonly delta: string;
        };
    };
    readonly match: {
        <Handlers extends { [K in "finish" | "generation-progress" | "generation-queued" | "segment" | "text-delta"]: (value: {
            readonly finish: Schema.Struct<{
                readonly text: Schema.String;
                readonly segments: Schema.optional<Schema.$Array<Schema.Struct<{
                    readonly text: Schema.String;
                    readonly startSeconds: Schema.Number;
                    readonly endSeconds: Schema.Number;
                    readonly speaker: Schema.optional<Schema.String>;
                }>>>;
                readonly words: Schema.optional<Schema.$Array<Schema.Struct<{
                    readonly text: Schema.String;
                    readonly startSeconds: Schema.Number;
                    readonly endSeconds: Schema.Number;
                    readonly speaker: Schema.optional<Schema.String>;
                    readonly confidence: Schema.optional<Schema.Number>;
                }>>>;
                readonly language: Schema.optional<Schema.String>;
                readonly durationSeconds: Schema.optional<Schema.Number>;
                readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"tokens">;
                    readonly input: Schema.optional<Schema.Number>;
                    readonly output: Schema.optional<Schema.Number>;
                    readonly total: Schema.optional<Schema.Number>;
                    readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"seconds">;
                    readonly seconds: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"characters">;
                    readonly characters: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"credits">;
                    readonly credits: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"compute">;
                    readonly seconds: Schema.Number;
                }>]>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                readonly type: Schema.tag<"finish">;
            }>;
            readonly "generation-progress": Schema.Struct<{
                readonly type: Schema.tag<"generation-progress">;
                readonly id: Schema.String;
                readonly progress: Schema.optional<Schema.Number>;
            }>;
            readonly "generation-queued": Schema.Struct<{
                readonly type: Schema.tag<"generation-queued">;
                readonly id: Schema.String;
                readonly position: Schema.optional<Schema.Number>;
            }>;
            readonly segment: Schema.Struct<{
                readonly type: Schema.tag<"segment">;
                readonly segment: Schema.Struct<{
                    readonly text: Schema.String;
                    readonly startSeconds: Schema.Number;
                    readonly endSeconds: Schema.Number;
                    readonly speaker: Schema.optional<Schema.String>;
                }>;
            }>;
            readonly "text-delta": Schema.Struct<{
                readonly type: Schema.tag<"text-delta">;
                readonly delta: Schema.String;
            }>;
        }[K]["Type"]) => any; }>(value: {
            readonly type: "text-delta";
            readonly delta: string;
        } | {
            readonly type: "segment";
            readonly segment: {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            };
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly text: string;
            readonly segments?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            }[] | undefined;
            readonly words?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
                readonly confidence?: number | undefined;
            }[] | undefined;
            readonly language?: string | undefined;
            readonly durationSeconds?: number | undefined;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
            readonly type: "finish";
        }, cases: Handlers): import("effect/Unify").Unify<ReturnType<Handlers["finish" | "generation-progress" | "generation-queued" | "segment" | "text-delta"]>>;
        <Handlers extends { [K in "finish" | "generation-progress" | "generation-queued" | "segment" | "text-delta"]: (value: {
            readonly finish: Schema.Struct<{
                readonly text: Schema.String;
                readonly segments: Schema.optional<Schema.$Array<Schema.Struct<{
                    readonly text: Schema.String;
                    readonly startSeconds: Schema.Number;
                    readonly endSeconds: Schema.Number;
                    readonly speaker: Schema.optional<Schema.String>;
                }>>>;
                readonly words: Schema.optional<Schema.$Array<Schema.Struct<{
                    readonly text: Schema.String;
                    readonly startSeconds: Schema.Number;
                    readonly endSeconds: Schema.Number;
                    readonly speaker: Schema.optional<Schema.String>;
                    readonly confidence: Schema.optional<Schema.Number>;
                }>>>;
                readonly language: Schema.optional<Schema.String>;
                readonly durationSeconds: Schema.optional<Schema.Number>;
                readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"tokens">;
                    readonly input: Schema.optional<Schema.Number>;
                    readonly output: Schema.optional<Schema.Number>;
                    readonly total: Schema.optional<Schema.Number>;
                    readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"seconds">;
                    readonly seconds: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"characters">;
                    readonly characters: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"credits">;
                    readonly credits: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"compute">;
                    readonly seconds: Schema.Number;
                }>]>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                readonly type: Schema.tag<"finish">;
            }>;
            readonly "generation-progress": Schema.Struct<{
                readonly type: Schema.tag<"generation-progress">;
                readonly id: Schema.String;
                readonly progress: Schema.optional<Schema.Number>;
            }>;
            readonly "generation-queued": Schema.Struct<{
                readonly type: Schema.tag<"generation-queued">;
                readonly id: Schema.String;
                readonly position: Schema.optional<Schema.Number>;
            }>;
            readonly segment: Schema.Struct<{
                readonly type: Schema.tag<"segment">;
                readonly segment: Schema.Struct<{
                    readonly text: Schema.String;
                    readonly startSeconds: Schema.Number;
                    readonly endSeconds: Schema.Number;
                    readonly speaker: Schema.optional<Schema.String>;
                }>;
            }>;
            readonly "text-delta": Schema.Struct<{
                readonly type: Schema.tag<"text-delta">;
                readonly delta: Schema.String;
            }>;
        }[K]["Type"]) => any; }>(cases: Handlers): (value: {
            readonly type: "text-delta";
            readonly delta: string;
        } | {
            readonly type: "segment";
            readonly segment: {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            };
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly text: string;
            readonly segments?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            }[] | undefined;
            readonly words?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
                readonly confidence?: number | undefined;
            }[] | undefined;
            readonly language?: string | undefined;
            readonly durationSeconds?: number | undefined;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
            readonly type: "finish";
        }) => import("effect/Unify").Unify<ReturnType<Handlers["finish" | "generation-progress" | "generation-queued" | "segment" | "text-delta"]>>;
    };
    readonly matchOrElse: {
        <Handlers, OrElse>(value: {
            readonly type: "text-delta";
            readonly delta: string;
        } | {
            readonly type: "segment";
            readonly segment: {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            };
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly text: string;
            readonly segments?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            }[] | undefined;
            readonly words?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
                readonly confidence?: number | undefined;
            }[] | undefined;
            readonly language?: string | undefined;
            readonly durationSeconds?: number | undefined;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
            readonly type: "finish";
        }, cases: Handlers & {
            readonly finish?: ((value: {
                readonly text: string;
                readonly segments?: readonly {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                    readonly speaker?: string | undefined;
                }[] | undefined;
                readonly words?: readonly {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                    readonly speaker?: string | undefined;
                    readonly confidence?: number | undefined;
                }[] | undefined;
                readonly language?: string | undefined;
                readonly durationSeconds?: number | undefined;
                readonly usage?: {
                    readonly type: "seconds";
                    readonly seconds: number;
                } | {
                    readonly type: "characters";
                    readonly characters: number;
                } | {
                    readonly type: "credits";
                    readonly credits: number;
                } | {
                    readonly type: "compute";
                    readonly seconds: number;
                } | {
                    readonly type: "tokens";
                    readonly input?: number | undefined;
                    readonly output?: number | undefined;
                    readonly total?: number | undefined;
                    readonly details?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                } | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
                readonly type: "finish";
            }) => any) | undefined;
            readonly "generation-progress"?: ((value: {
                readonly type: "generation-progress";
                readonly id: string;
                readonly progress?: number | undefined;
            }) => any) | undefined;
            readonly "generation-queued"?: ((value: {
                readonly type: "generation-queued";
                readonly id: string;
                readonly position?: number | undefined;
            }) => any) | undefined;
            readonly segment?: ((value: {
                readonly type: "segment";
                readonly segment: {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                    readonly speaker?: string | undefined;
                };
            }) => any) | undefined;
            readonly "text-delta"?: ((value: {
                readonly type: "text-delta";
                readonly delta: string;
            }) => any) | undefined;
        } & (Exclude<keyof Handlers, "finish" | "generation-progress" | "generation-queued" | "segment" | "text-delta"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
            readonly type: "text-delta";
            readonly delta: string;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "segment";
            readonly segment: {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            };
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly text: string;
            readonly segments?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            }[] | undefined;
            readonly words?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
                readonly confidence?: number | undefined;
            }[] | undefined;
            readonly language?: string | undefined;
            readonly durationSeconds?: number | undefined;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
            readonly type: "finish";
        }, {
            readonly type: keyof Handlers;
        }>) => any)): import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
        <Handlers, OrElse>(cases: Handlers & {
            readonly finish?: ((value: {
                readonly text: string;
                readonly segments?: readonly {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                    readonly speaker?: string | undefined;
                }[] | undefined;
                readonly words?: readonly {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                    readonly speaker?: string | undefined;
                    readonly confidence?: number | undefined;
                }[] | undefined;
                readonly language?: string | undefined;
                readonly durationSeconds?: number | undefined;
                readonly usage?: {
                    readonly type: "seconds";
                    readonly seconds: number;
                } | {
                    readonly type: "characters";
                    readonly characters: number;
                } | {
                    readonly type: "credits";
                    readonly credits: number;
                } | {
                    readonly type: "compute";
                    readonly seconds: number;
                } | {
                    readonly type: "tokens";
                    readonly input?: number | undefined;
                    readonly output?: number | undefined;
                    readonly total?: number | undefined;
                    readonly details?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                } | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
                readonly type: "finish";
            }) => any) | undefined;
            readonly "generation-progress"?: ((value: {
                readonly type: "generation-progress";
                readonly id: string;
                readonly progress?: number | undefined;
            }) => any) | undefined;
            readonly "generation-queued"?: ((value: {
                readonly type: "generation-queued";
                readonly id: string;
                readonly position?: number | undefined;
            }) => any) | undefined;
            readonly segment?: ((value: {
                readonly type: "segment";
                readonly segment: {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                    readonly speaker?: string | undefined;
                };
            }) => any) | undefined;
            readonly "text-delta"?: ((value: {
                readonly type: "text-delta";
                readonly delta: string;
            }) => any) | undefined;
        } & (Exclude<keyof Handlers, "finish" | "generation-progress" | "generation-queued" | "segment" | "text-delta"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
            readonly type: "text-delta";
            readonly delta: string;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "segment";
            readonly segment: {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            };
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly text: string;
            readonly segments?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            }[] | undefined;
            readonly words?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
                readonly confidence?: number | undefined;
            }[] | undefined;
            readonly language?: string | undefined;
            readonly durationSeconds?: number | undefined;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
            readonly type: "finish";
        }, {
            readonly type: keyof Handlers;
        }>) => any)): (value: {
            readonly type: "text-delta";
            readonly delta: string;
        } | {
            readonly type: "segment";
            readonly segment: {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            };
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly text: string;
            readonly segments?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            }[] | undefined;
            readonly words?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
                readonly confidence?: number | undefined;
            }[] | undefined;
            readonly language?: string | undefined;
            readonly durationSeconds?: number | undefined;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
            readonly type: "finish";
        }) => import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
    };
} & {
    is: {
        generationQueued: (u: unknown) => u is {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        };
        generationProgress: (u: unknown) => u is {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        };
        textDelta: (u: unknown) => u is {
            readonly type: "text-delta";
            readonly delta: string;
        };
        segment: (u: unknown) => u is {
            readonly type: "segment";
            readonly segment: {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            };
        };
        finish: (u: unknown) => u is {
            readonly text: string;
            readonly segments?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
            }[] | undefined;
            readonly words?: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
                readonly speaker?: string | undefined;
                readonly confidence?: number | undefined;
            }[] | undefined;
            readonly language?: string | undefined;
            readonly durationSeconds?: number | undefined;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
            readonly type: "finish";
        };
    };
};
export type TranscriptionEvent = Schema.Schema.Type<typeof transcriptionEventTagged>;
/** Normalize transcription request input into a plain `TranscriptionRequest`. */
export declare const request: <const Model extends TranscriptionModel>(input: TranscriptionRequestInput<Model>) => TranscriptionRequest<Model>;
export declare function generate<const Model extends TranscriptionModel>(input: TranscriptionRequestInput<Model>, options?: AwaitOptions): Effect.Effect<TranscriptionResponse, AIError, Service>;
export declare function stream<const Model extends TranscriptionModel>(input: TranscriptionRequestInput<Model>, options?: AwaitOptions): Stream.Stream<TranscriptionEvent, AIError, Service>;
/** Inline and streaming routes fail with `UnsupportedOperation`. */
export declare function start<const Model extends TranscriptionModel>(input: TranscriptionRequestInput<Model>): Effect.Effect<Generation<TranscriptionResponse>, AIError, Service>;
export declare const resume: (model: TranscriptionModel, token: unknown) => Effect.Effect<Generation<TranscriptionResponse>, AIError, Service>;
export declare const Transcription: {
    readonly request: typeof request;
    readonly generate: typeof generate;
    readonly stream: typeof stream;
    readonly start: typeof start;
    readonly resume: typeof resume;
};
export {};
