import { Effect, Schema, Stream } from "effect";
import { Generation, type AwaitOptions } from "./generation.js";
import { Media } from "./media.js";
import { MediaModel } from "./media-model.js";
import { MediaRoute } from "./route/media.js";
import { AIError, type OpenString, type BaseRequest } from "./schema/index.js";
import { Service } from "./video-client.js";
export type VideoOptions = MediaModel.Options;
export type VideoRoute = MediaRoute.AnyRoute<VideoRequest, VideoEvent, VideoResponse>;
export declare class VideoModel<Options extends VideoOptions = VideoOptions> extends MediaModel<VideoRoute, Options> {
    protected readonly _VideoModel: void;
    /** The number of type arguments selects the kind: `<Options>`, `<Options, Frame, State>`, or `<Options, Token>`. */
    static fromRoute<Options extends VideoOptions>(route: MediaModel.InlineRouteInput<VideoRequest<VideoModel<Options>>, VideoResponse>, input: MediaRoute.ModelInput): VideoModel<Options>;
    static fromRoute<Options extends VideoOptions, Frame, State>(route: MediaModel.StreamRouteInput<VideoRequest<VideoModel<Options>>, VideoEvent, Frame, State>, input: MediaRoute.ModelInput): VideoModel<Options>;
    static fromRoute<Options extends VideoOptions, Token>(route: MediaModel.QueuedRouteInput<VideoRequest<VideoModel<Options>>, VideoResponse, Token>, input: MediaRoute.ModelInput): VideoModel<Options>;
}
export declare const VideoModelSchema: Schema.declare<VideoModel<{
    readonly [x: string]: unknown;
}>, VideoModel<{
    readonly [x: string]: unknown;
}>>;
export type VideoAspectRatio = Media.AspectRatio;
export declare const VideoAspectRatio: Schema.declare<`${number}:${number}`, `${number}:${number}`>;
export type VideoResolution = OpenString<"480p" | "720p" | "1080p" | "4k">;
/** Pinned frames. Routes that accept only a first frame fail typed when `last` is present. */
export declare const VideoFrames: Schema.Struct<{
    readonly first: Schema.optional<Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>>;
    readonly last: Schema.optional<Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>>;
}>;
export type VideoFrames = Schema.Schema.Type<typeof VideoFrames>;
declare const VideoRequestSchema: Schema.Struct<{
    readonly model: Schema.declare<VideoModel<{
        readonly [x: string]: unknown;
    }>, VideoModel<{
        readonly [x: string]: unknown;
    }>>;
    readonly prompt: Schema.String;
    readonly frames: Schema.optional<Schema.Struct<{
        readonly first: Schema.optional<Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"bytes">;
                readonly data: Schema.Uint8Array;
                readonly mediaType: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"base64">;
                readonly data: Schema.String;
                readonly mediaType: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"url">;
                readonly url: Schema.String;
                readonly mediaType: Schema.optional<Schema.String>;
                readonly expiresAt: Schema.optional<Schema.Number>;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"ref">;
                readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                readonly id: Schema.String;
                readonly mediaType: Schema.optional<Schema.String>;
            }>]>;
            readonly info: Schema.optional<Schema.Struct<{
                readonly width: Schema.optional<Schema.Number>;
                readonly height: Schema.optional<Schema.Number>;
                readonly durationSeconds: Schema.optional<Schema.Number>;
                readonly sampleRate: Schema.optional<Schema.Number>;
                readonly channels: Schema.optional<Schema.Number>;
                readonly encoding: Schema.optional<Schema.String>;
                readonly format: Schema.optional<Schema.String>;
            }>>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>, never, never>>;
        readonly last: Schema.optional<Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"bytes">;
                readonly data: Schema.Uint8Array;
                readonly mediaType: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"base64">;
                readonly data: Schema.String;
                readonly mediaType: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"url">;
                readonly url: Schema.String;
                readonly mediaType: Schema.optional<Schema.String>;
                readonly expiresAt: Schema.optional<Schema.Number>;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"ref">;
                readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                readonly id: Schema.String;
                readonly mediaType: Schema.optional<Schema.String>;
            }>]>;
            readonly info: Schema.optional<Schema.Struct<{
                readonly width: Schema.optional<Schema.Number>;
                readonly height: Schema.optional<Schema.Number>;
                readonly durationSeconds: Schema.optional<Schema.Number>;
                readonly sampleRate: Schema.optional<Schema.Number>;
                readonly channels: Schema.optional<Schema.Number>;
                readonly encoding: Schema.optional<Schema.String>;
                readonly format: Schema.optional<Schema.String>;
            }>>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>, never, never>>;
    }>>;
    /** Style or subject references that guide the output without pinning a frame. */
    readonly references: Schema.optional<Schema.$Array<Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>>>;
    /** Source video for edit or extension routes. */
    readonly video: Schema.optional<Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>>;
    readonly durationSeconds: Schema.optional<Schema.Number>;
    readonly aspect: Schema.optional<Schema.declare<`${number}:${number}`, `${number}:${number}`>>;
    readonly resolution: Schema.optional<Schema.String>;
    /** Whether to generate an audio track; routes whose audio is always on fail typed on `false`. */
    readonly audio: Schema.optional<Schema.Boolean>;
    readonly n: Schema.optional<Schema.Int>;
    readonly seed: Schema.optional<Schema.Number>;
    readonly negativePrompt: Schema.optional<Schema.String>;
    readonly providerOptions: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
}>;
/** A normalized video request, the plain object `Video.request(...)` returns. */
export type VideoRequest<Model extends VideoModel = VideoModel> = Omit<typeof VideoRequestSchema.Type, "model" | "providerOptions" | "resolution"> & BaseRequest<Model, VideoModelOptions<Model>> & {
    readonly resolution?: VideoResolution;
};
export type VideoModelOptions<Model> = Model extends VideoModel<infer Options> ? Options : never;
/** Input accepted by `Video.request` and the calls; a `VideoRequest` is also a valid input. */
export type VideoRequestInput<Model extends VideoModel = VideoModel> = Omit<VideoRequest<Model>, "providerOptions"> & {
    readonly providerOptions?: NoInfer<VideoModelOptions<Model>>;
};
declare const VideoResponse_base: Schema.Class<VideoResponse, Schema.Struct<{
    readonly videos: Schema.$Array<Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>>;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, {}>;
export declare class VideoResponse extends VideoResponse_base {
    get video(): Media.Asset;
}
export declare const VideoOutputEvent: Schema.Struct<{
    readonly type: Schema.tag<"video">;
    readonly index: Schema.Number;
    readonly video: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
}>;
export declare const VideoFinishEvent: Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
declare const videoEventTagged: Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
    readonly type: Schema.tag<"generation-queued">;
    readonly id: Schema.String;
    readonly position: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"generation-progress">;
    readonly id: Schema.String;
    readonly progress: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"video">;
    readonly index: Schema.Number;
    readonly video: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>]>;
export declare const VideoEvent: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.tag<"generation-queued">;
    readonly id: Schema.String;
    readonly position: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"generation-progress">;
    readonly id: Schema.String;
    readonly progress: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"video">;
    readonly index: Schema.Number;
    readonly video: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>]> & {
    readonly tag: "type";
    readonly discriminants: readonly ["generation-queued", "generation-progress", "video", "finish"];
    readonly cases: {
        finish: Schema.Struct<{
            readonly type: Schema.tag<"finish">;
            readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"tokens">;
                readonly input: Schema.optional<Schema.Number>;
                readonly output: Schema.optional<Schema.Number>;
                readonly total: Schema.optional<Schema.Number>;
                readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"seconds">;
                readonly seconds: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"characters">;
                readonly characters: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"credits">;
                readonly credits: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"compute">;
                readonly seconds: Schema.Number;
            }>]>>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "generation-progress": Schema.Struct<{
            readonly type: Schema.tag<"generation-progress">;
            readonly id: Schema.String;
            readonly progress: Schema.optional<Schema.Number>;
        }>;
        "generation-queued": Schema.Struct<{
            readonly type: Schema.tag<"generation-queued">;
            readonly id: Schema.String;
            readonly position: Schema.optional<Schema.Number>;
        }>;
        video: Schema.Struct<{
            readonly type: Schema.tag<"video">;
            readonly index: Schema.Number;
            readonly video: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"bytes">;
                    readonly data: Schema.Uint8Array;
                    readonly mediaType: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"base64">;
                    readonly data: Schema.String;
                    readonly mediaType: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"url">;
                    readonly url: Schema.String;
                    readonly mediaType: Schema.optional<Schema.String>;
                    readonly expiresAt: Schema.optional<Schema.Number>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"ref">;
                    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                    readonly id: Schema.String;
                    readonly mediaType: Schema.optional<Schema.String>;
                }>]>;
                readonly info: Schema.optional<Schema.Struct<{
                    readonly width: Schema.optional<Schema.Number>;
                    readonly height: Schema.optional<Schema.Number>;
                    readonly durationSeconds: Schema.optional<Schema.Number>;
                    readonly sampleRate: Schema.optional<Schema.Number>;
                    readonly channels: Schema.optional<Schema.Number>;
                    readonly encoding: Schema.optional<Schema.String>;
                    readonly format: Schema.optional<Schema.String>;
                }>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>, never, never>;
        }>;
    };
    readonly isAnyOf: <const Keys>(keys: readonly Keys[]) => (value: {
        readonly type: "video";
        readonly index: number;
        readonly video: Media.Asset;
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly type: "finish";
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }) => value is Extract<{
        readonly type: "video";
        readonly index: number;
        readonly video: Media.Asset;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "finish";
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }>;
    readonly guards: {
        finish: (u: unknown) => u is {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "generation-progress": (u: unknown) => u is {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        };
        "generation-queued": (u: unknown) => u is {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        };
        video: (u: unknown) => u is {
            readonly type: "video";
            readonly index: number;
            readonly video: Media.Asset;
        };
    };
    readonly match: {
        <Handlers extends { [K in "finish" | "generation-progress" | "generation-queued" | "video"]: (value: {
            readonly finish: Schema.Struct<{
                readonly type: Schema.tag<"finish">;
                readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"tokens">;
                    readonly input: Schema.optional<Schema.Number>;
                    readonly output: Schema.optional<Schema.Number>;
                    readonly total: Schema.optional<Schema.Number>;
                    readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"seconds">;
                    readonly seconds: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"characters">;
                    readonly characters: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"credits">;
                    readonly credits: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"compute">;
                    readonly seconds: Schema.Number;
                }>]>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "generation-progress": Schema.Struct<{
                readonly type: Schema.tag<"generation-progress">;
                readonly id: Schema.String;
                readonly progress: Schema.optional<Schema.Number>;
            }>;
            readonly "generation-queued": Schema.Struct<{
                readonly type: Schema.tag<"generation-queued">;
                readonly id: Schema.String;
                readonly position: Schema.optional<Schema.Number>;
            }>;
            readonly video: Schema.Struct<{
                readonly type: Schema.tag<"video">;
                readonly index: Schema.Number;
                readonly video: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"bytes">;
                        readonly data: Schema.Uint8Array;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"base64">;
                        readonly data: Schema.String;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"url">;
                        readonly url: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                        readonly expiresAt: Schema.optional<Schema.Number>;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"ref">;
                        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                        readonly id: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                    }>]>;
                    readonly info: Schema.optional<Schema.Struct<{
                        readonly width: Schema.optional<Schema.Number>;
                        readonly height: Schema.optional<Schema.Number>;
                        readonly durationSeconds: Schema.optional<Schema.Number>;
                        readonly sampleRate: Schema.optional<Schema.Number>;
                        readonly channels: Schema.optional<Schema.Number>;
                        readonly encoding: Schema.optional<Schema.String>;
                        readonly format: Schema.optional<Schema.String>;
                    }>>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>, never, never>;
            }>;
        }[K]["Type"]) => any; }>(value: {
            readonly type: "video";
            readonly index: number;
            readonly video: Media.Asset;
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, cases: Handlers): import("effect/Unify").Unify<ReturnType<Handlers["finish" | "generation-progress" | "generation-queued" | "video"]>>;
        <Handlers extends { [K in "finish" | "generation-progress" | "generation-queued" | "video"]: (value: {
            readonly finish: Schema.Struct<{
                readonly type: Schema.tag<"finish">;
                readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"tokens">;
                    readonly input: Schema.optional<Schema.Number>;
                    readonly output: Schema.optional<Schema.Number>;
                    readonly total: Schema.optional<Schema.Number>;
                    readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"seconds">;
                    readonly seconds: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"characters">;
                    readonly characters: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"credits">;
                    readonly credits: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"compute">;
                    readonly seconds: Schema.Number;
                }>]>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "generation-progress": Schema.Struct<{
                readonly type: Schema.tag<"generation-progress">;
                readonly id: Schema.String;
                readonly progress: Schema.optional<Schema.Number>;
            }>;
            readonly "generation-queued": Schema.Struct<{
                readonly type: Schema.tag<"generation-queued">;
                readonly id: Schema.String;
                readonly position: Schema.optional<Schema.Number>;
            }>;
            readonly video: Schema.Struct<{
                readonly type: Schema.tag<"video">;
                readonly index: Schema.Number;
                readonly video: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"bytes">;
                        readonly data: Schema.Uint8Array;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"base64">;
                        readonly data: Schema.String;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"url">;
                        readonly url: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                        readonly expiresAt: Schema.optional<Schema.Number>;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"ref">;
                        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                        readonly id: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                    }>]>;
                    readonly info: Schema.optional<Schema.Struct<{
                        readonly width: Schema.optional<Schema.Number>;
                        readonly height: Schema.optional<Schema.Number>;
                        readonly durationSeconds: Schema.optional<Schema.Number>;
                        readonly sampleRate: Schema.optional<Schema.Number>;
                        readonly channels: Schema.optional<Schema.Number>;
                        readonly encoding: Schema.optional<Schema.String>;
                        readonly format: Schema.optional<Schema.String>;
                    }>>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>, never, never>;
            }>;
        }[K]["Type"]) => any; }>(cases: Handlers): (value: {
            readonly type: "video";
            readonly index: number;
            readonly video: Media.Asset;
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }) => import("effect/Unify").Unify<ReturnType<Handlers["finish" | "generation-progress" | "generation-queued" | "video"]>>;
    };
    readonly matchOrElse: {
        <Handlers, OrElse>(value: {
            readonly type: "video";
            readonly index: number;
            readonly video: Media.Asset;
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, cases: Handlers & {
            readonly finish?: ((value: {
                readonly type: "finish";
                readonly usage?: {
                    readonly type: "seconds";
                    readonly seconds: number;
                } | {
                    readonly type: "characters";
                    readonly characters: number;
                } | {
                    readonly type: "credits";
                    readonly credits: number;
                } | {
                    readonly type: "compute";
                    readonly seconds: number;
                } | {
                    readonly type: "tokens";
                    readonly input?: number | undefined;
                    readonly output?: number | undefined;
                    readonly total?: number | undefined;
                    readonly details?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                } | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "generation-progress"?: ((value: {
                readonly type: "generation-progress";
                readonly id: string;
                readonly progress?: number | undefined;
            }) => any) | undefined;
            readonly "generation-queued"?: ((value: {
                readonly type: "generation-queued";
                readonly id: string;
                readonly position?: number | undefined;
            }) => any) | undefined;
            readonly video?: ((value: {
                readonly type: "video";
                readonly index: number;
                readonly video: Media.Asset;
            }) => any) | undefined;
        } & (Exclude<keyof Handlers, "finish" | "generation-progress" | "generation-queued" | "video"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
            readonly type: "video";
            readonly index: number;
            readonly video: Media.Asset;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }>) => any)): import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
        <Handlers, OrElse>(cases: Handlers & {
            readonly finish?: ((value: {
                readonly type: "finish";
                readonly usage?: {
                    readonly type: "seconds";
                    readonly seconds: number;
                } | {
                    readonly type: "characters";
                    readonly characters: number;
                } | {
                    readonly type: "credits";
                    readonly credits: number;
                } | {
                    readonly type: "compute";
                    readonly seconds: number;
                } | {
                    readonly type: "tokens";
                    readonly input?: number | undefined;
                    readonly output?: number | undefined;
                    readonly total?: number | undefined;
                    readonly details?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                } | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "generation-progress"?: ((value: {
                readonly type: "generation-progress";
                readonly id: string;
                readonly progress?: number | undefined;
            }) => any) | undefined;
            readonly "generation-queued"?: ((value: {
                readonly type: "generation-queued";
                readonly id: string;
                readonly position?: number | undefined;
            }) => any) | undefined;
            readonly video?: ((value: {
                readonly type: "video";
                readonly index: number;
                readonly video: Media.Asset;
            }) => any) | undefined;
        } & (Exclude<keyof Handlers, "finish" | "generation-progress" | "generation-queued" | "video"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
            readonly type: "video";
            readonly index: number;
            readonly video: Media.Asset;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }>) => any)): (value: {
            readonly type: "video";
            readonly index: number;
            readonly video: Media.Asset;
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }) => import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
    };
} & {
    is: {
        generationQueued: (u: unknown) => u is {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        };
        generationProgress: (u: unknown) => u is {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        };
        video: (u: unknown) => u is {
            readonly type: "video";
            readonly index: number;
            readonly video: Media.Asset;
        };
        finish: (u: unknown) => u is {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
    };
};
export type VideoEvent = Schema.Schema.Type<typeof videoEventTagged>;
/** Normalize video request input into a plain `VideoRequest`. */
export declare const request: <const Model extends VideoModel>(input: VideoRequestInput<Model>) => VideoRequest<Model>;
export declare function start<const Model extends VideoModel>(input: VideoRequestInput<Model>): Effect.Effect<Generation<VideoResponse>, AIError, Service>;
export declare function generate<const Model extends VideoModel>(input: VideoRequestInput<Model>, options?: AwaitOptions): Effect.Effect<VideoResponse, AIError, Service>;
/** Rebuild a generation handle from a persisted `Generation.token`, refreshing its status once. */
export declare const resume: (model: VideoModel, token: unknown) => Effect.Effect<Generation<VideoResponse>, AIError, Service>;
export declare function stream<const Model extends VideoModel>(input: VideoRequestInput<Model>, options?: AwaitOptions): Stream.Stream<VideoEvent, AIError, Service>;
export declare const Video: {
    readonly request: typeof request;
    readonly start: typeof start;
    readonly generate: typeof generate;
    readonly resume: typeof resume;
    readonly stream: typeof stream;
};
export {};
