import { Schema } from "effect";
import { Tool } from "@opencode/schema/tool";
import type { LLMResponse } from "./events.js";
export declare const ProviderFailureClassification: Schema.Literals<readonly ["context-overflow", "payload-too-large"]>;
export type ProviderFailureClassification = typeof ProviderFailureClassification.Type;
declare const HttpContext_base: Schema.Class<HttpContext, Schema.Struct<{
    readonly url: Schema.String;
    readonly status: Schema.Int;
    readonly headers: Schema.$Record<Schema.String, Schema.String>;
}>, {}>;
export declare class HttpContext extends HttpContext_base {
}
declare const HttpRateLimitDetails_base: Schema.Class<HttpRateLimitDetails, Schema.Struct<{
    readonly retryAfterMs: Schema.optional<Schema.Int>;
    readonly limit: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
    readonly remaining: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
    readonly reset: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
}>, {}>;
export declare class HttpRateLimitDetails extends HttpRateLimitDetails_base {
}
declare const InvalidRequestError_base: Schema.Class<InvalidRequestError, Schema.TaggedStruct<"InvalidRequest", {
    readonly message: Schema.String;
    readonly body: Schema.optional<Schema.String>;
    readonly http: Schema.optional<typeof HttpContext>;
    readonly cause: Schema.optional<Schema.Defect>;
    readonly parameter: Schema.optional<Schema.String>;
    readonly classification: Schema.optional<Schema.Literals<readonly ["context-overflow", "payload-too-large"]>>;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidRequestError extends InvalidRequestError_base {
}
declare const UnsupportedOperationError_base: Schema.Class<UnsupportedOperationError, Schema.TaggedStruct<"UnsupportedOperation", {
    readonly message: Schema.String;
    readonly body: Schema.optional<Schema.String>;
    readonly http: Schema.optional<typeof HttpContext>;
    readonly cause: Schema.optional<Schema.Defect>;
    readonly operation: Schema.String;
    readonly provider: Schema.optional<Schema.brand<Schema.String, "AI.ProviderID">>;
    readonly route: Schema.optional<Schema.String>;
}>, import("effect/Cause").YieldableError>;
/**
 * A caller-requested operation the selected route does not implement, such as
 * explicit compaction on a route without a compact endpoint. Detected locally
 * before any network I/O, so unlike transport or provider-output failures it
 * never carries HTTP context from a provider round-trip.
 */
export declare class UnsupportedOperationError extends UnsupportedOperationError_base {
}
declare const ProviderConfigurationError_base: Schema.Class<ProviderConfigurationError, Schema.TaggedStruct<"ProviderConfiguration", {
    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
/**
 * Provider settings that are missing, conflicting, or unsupported, such as
 * Azure without `resourceName` or `baseURL`. Thrown synchronously while a
 * provider facade or package entrypoint configures a model, before any
 * request exists, so it is not an `AIError` reason.
 */
export declare class ProviderConfigurationError extends ProviderConfigurationError_base {
}
declare const AuthenticationError_base: Schema.Class<AuthenticationError, Schema.TaggedStruct<"Authentication", {
    message: Schema.String;
    body: Schema.optional<Schema.String>;
    http: Schema.optional<typeof HttpContext>;
    cause: Schema.optional<Schema.Defect>;
}>, import("effect/Cause").YieldableError>;
export declare class AuthenticationError extends AuthenticationError_base {
}
declare const RateLimitError_base: Schema.Class<RateLimitError, Schema.TaggedStruct<"RateLimit", {
    readonly message: Schema.String;
    readonly body: Schema.optional<Schema.String>;
    readonly http: Schema.optional<typeof HttpContext>;
    readonly cause: Schema.optional<Schema.Defect>;
    readonly retryAfterMs: Schema.optional<Schema.Int>;
    readonly rateLimit: Schema.optional<typeof HttpRateLimitDetails>;
}>, import("effect/Cause").YieldableError>;
export declare class RateLimitError extends RateLimitError_base {
}
declare const QuotaExceededError_base: Schema.Class<QuotaExceededError, Schema.TaggedStruct<"QuotaExceeded", {
    readonly message: Schema.String;
    readonly body: Schema.optional<Schema.String>;
    readonly http: Schema.optional<typeof HttpContext>;
    readonly cause: Schema.optional<Schema.Defect>;
    readonly retryAfterMs: Schema.optional<Schema.Int>;
}>, import("effect/Cause").YieldableError>;
export declare class QuotaExceededError extends QuotaExceededError_base {
}
declare const ContentPolicyError_base: Schema.Class<ContentPolicyError, Schema.TaggedStruct<"ContentPolicy", {
    message: Schema.String;
    body: Schema.optional<Schema.String>;
    http: Schema.optional<typeof HttpContext>;
    cause: Schema.optional<Schema.Defect>;
}>, import("effect/Cause").YieldableError>;
export declare class ContentPolicyError extends ContentPolicyError_base {
}
declare const ProviderInternalError_base: Schema.Class<ProviderInternalError, Schema.TaggedStruct<"ProviderInternal", {
    readonly message: Schema.String;
    readonly body: Schema.optional<Schema.String>;
    readonly http: Schema.optional<typeof HttpContext>;
    readonly cause: Schema.optional<Schema.Defect>;
    readonly retryAfterMs: Schema.optional<Schema.Int>;
}>, import("effect/Cause").YieldableError>;
export declare class ProviderInternalError extends ProviderInternalError_base {
}
export declare const TransportType: Schema.Literals<readonly ["http", "websocket"]>;
export type TransportType = typeof TransportType.Type;
export declare const TransportOperation: Schema.Literals<readonly ["request", "read", "write"]>;
export type TransportOperation = typeof TransportOperation.Type;
declare const TransportError_base: Schema.Class<TransportError, Schema.TaggedStruct<"Transport", {
    readonly message: Schema.String;
    readonly body: Schema.optional<Schema.String>;
    readonly http: Schema.optional<typeof HttpContext>;
    readonly cause: Schema.optional<Schema.Defect>;
    readonly transport: Schema.Literals<readonly ["http", "websocket"]>;
    readonly operation: Schema.Literals<readonly ["request", "read", "write"]>;
    readonly code: Schema.optional<Schema.String>;
    readonly url: Schema.optional<Schema.String>;
    readonly phase: Schema.optional<Schema.Literals<readonly ["prepare", "queue", "connect", "send", "receive", "decode", "complete", "fallback", "close"]>>;
    readonly delivery: Schema.optional<Schema.Literals<readonly ["not-sent", "rejected", "ambiguous", "accepted"]>>;
    readonly recovery: Schema.optional<Schema.Literals<readonly ["retry-connect", "retry-full", "rotate-and-retry-full", "fallback-http", "fail"]>>;
}>, import("effect/Cause").YieldableError>;
export declare class TransportError extends TransportError_base {
}
declare const InvalidProviderOutputError_base: Schema.Class<InvalidProviderOutputError, Schema.TaggedStruct<"InvalidProviderOutput", {
    readonly message: Schema.String;
    readonly body: Schema.optional<Schema.String>;
    readonly http: Schema.optional<typeof HttpContext>;
    readonly cause: Schema.optional<Schema.Defect>;
    readonly classification: Schema.optional<Schema.Literals<readonly ["incomplete-stream"]>>;
    readonly route: Schema.optional<Schema.String>;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidProviderOutputError extends InvalidProviderOutputError_base {
}
declare const UnknownProviderError_base: Schema.Class<UnknownProviderError, Schema.TaggedStruct<"UnknownProvider", {
    message: Schema.String;
    body: Schema.optional<Schema.String>;
    http: Schema.optional<typeof HttpContext>;
    cause: Schema.optional<Schema.Defect>;
}>, import("effect/Cause").YieldableError>;
export declare class UnknownProviderError extends UnknownProviderError_base {
}
declare const TimeoutError_base: Schema.Class<TimeoutError, Schema.TaggedStruct<"Timeout", {
    readonly message: Schema.String;
    readonly body: Schema.optional<Schema.String>;
    readonly http: Schema.optional<typeof HttpContext>;
    readonly cause: Schema.optional<Schema.Defect>;
    readonly timeoutMs: Schema.optional<Schema.Int>;
}>, import("effect/Cause").YieldableError>;
/** A caller-supplied deadline elapsed, such as `Generation.await` polling past its `Poll.timeout`. */
export declare class TimeoutError extends TimeoutError_base {
}
export declare const AIErrorReason: Schema.toTaggedUnion<"_tag", readonly [typeof InvalidRequestError, typeof UnsupportedOperationError, typeof AuthenticationError, typeof RateLimitError, typeof QuotaExceededError, typeof ContentPolicyError, typeof ProviderInternalError, typeof TransportError, typeof InvalidProviderOutputError, typeof UnknownProviderError, typeof TimeoutError]>;
export type AIErrorReason = Schema.Schema.Type<typeof AIErrorReason>;
declare const AIError_base: Schema.Class<AIError, Schema.TaggedStruct<"AI.Error", {
    readonly reason: Schema.toTaggedUnion<"_tag", readonly [typeof InvalidRequestError, typeof UnsupportedOperationError, typeof AuthenticationError, typeof RateLimitError, typeof QuotaExceededError, typeof ContentPolicyError, typeof ProviderInternalError, typeof TransportError, typeof InvalidProviderOutputError, typeof UnknownProviderError, typeof TimeoutError]>;
}>, import("effect/Cause").YieldableError>;
export declare class AIError extends AIError_base {
    readonly cause: AuthenticationError | ContentPolicyError | InvalidProviderOutputError | InvalidRequestError | ProviderInternalError | QuotaExceededError | RateLimitError | TimeoutError | TransportError | UnknownProviderError | UnsupportedOperationError;
    /** Output that arrived before `generate` (including its `schema` decode) or a `loop` step failed. Not in the schema, so encoding omits it. */
    readonly partial?: LLMResponse;
    constructor(props: Pick<AIError, "reason" | "partial">);
    get message(): string;
    /** HTTP status of the failed response, when the failure came from one. */
    get status(): number | undefined;
    /** The provider's error code from the response body or `x-amzn-errortype`, or the transport's system error code. */
    get code(): string | undefined;
    /** Delay the provider asked for before retrying, from `retry-after` style headers. */
    get retryAfterMs(): number | undefined;
    /**
     * Whether a failed call may succeed when sent again: rate limits, provider-side failures, transport failures that did
     * not deliver an accepted write, and unrecognized failures. Callers decide which calls are safe to repeat.
     */
    get isRetryable(): boolean;
}
/** Return `error` with `partial` attached, or unchanged when there is no partial output. */
export declare const withPartial: (error: AIError, partial: LLMResponse | undefined) => AIError;
/**
 * Failure type for tool execute handlers. Handlers must map their internal
 * errors to this shape; the runtime catches `ToolFailure`s and surfaces them
 * as a `tool-result` of `type: "error"` so the model can self-correct.
 *
 * Anything thrown or yielded by a handler that is not a `ToolFailure` is
 * treated as a defect and fails the stream.
 */
export declare class ToolFailure extends Tool.Error {
}
export {};
