import { Schema } from "effect";
import { Tool } from "@opencode/schema/tool";
import { type BaseRequest, CacheHint, type CachePolicy, JsonSchema, type LanguageModel, type LanguageModelProviderOptions, ReasoningEffort, type GenerationOptionsFields } from "./options.js";
import { Media } from "../media.js";
export declare const MessageRole: Schema.Literals<readonly ["system", "user", "assistant", "tool"]>;
export type MessageRole = Schema.Schema.Type<typeof MessageRole>;
declare const systemPartSchema: Schema.Struct<{
    readonly type: Schema.Literal<"text">;
    readonly text: Schema.String;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
}>;
export type SystemPart = Schema.Schema.Type<typeof systemPartSchema>;
declare const makeSystemPart: (text: string) => SystemPart;
export declare const SystemPart: Schema.Struct<{
    readonly type: Schema.Literal<"text">;
    readonly text: Schema.String;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
}> & {
    make: typeof makeSystemPart;
    content: (input?: string | SystemPart | ReadonlyArray<SystemPart>) => any[];
};
export declare const TextPart: Schema.Struct<{
    readonly type: Schema.Literal<"text">;
    readonly text: Schema.String;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type TextPart = Schema.Schema.Type<typeof TextPart>;
export declare const MediaPart: Schema.Struct<{
    readonly type: Schema.Literal<"media">;
    readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly filename: Schema.optional<Schema.String>;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type MediaPart = Schema.Schema.Type<typeof MediaPart>;
/** A media part as input: `media` may be plain data, with `mediaType` naming its type when the content can't. */
export type MediaPartInput = Omit<MediaPart, "media"> & {
    readonly media: Media.Input;
    readonly mediaType?: string;
};
declare const toolResultValueSchema: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"json">;
    readonly value: Schema.Unknown;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"text">;
    readonly value: Schema.Unknown;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"error">;
    readonly value: Schema.Unknown;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"content">;
    readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"file">;
        readonly uri: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.optional<Schema.String>;
    }>]>>;
}>]>;
export type ToolResultValue = Schema.Schema.Type<typeof toolResultValueSchema>;
export declare const ToolResultValue: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"json">;
    readonly value: Schema.Unknown;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"text">;
    readonly value: Schema.Unknown;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"error">;
    readonly value: Schema.Unknown;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"content">;
    readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"file">;
        readonly uri: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.optional<Schema.String>;
    }>]>>;
}>]> & {
    is: <I>(input: I) => input is I & ({
        readonly type: "json";
        readonly value: unknown;
    } | {
        readonly type: "text";
        readonly value: unknown;
    } | {
        readonly type: "error";
        readonly value: unknown;
    } | {
        readonly type: "content";
        readonly value: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    });
    make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
};
export interface ToolOutput {
    readonly structured: unknown;
    readonly content: ReadonlyArray<Tool.Content>;
}
export declare const ToolOutput: Schema.Struct<{
    readonly structured: Schema.Unknown;
    readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"file">;
        readonly uri: Schema.String;
        readonly mime: Schema.String;
        readonly name: Schema.optional<Schema.String>;
    }>]>>;
}> & {
    make: (structured: unknown, content?: ReadonlyArray<Tool.Content>) => ToolOutput;
    fromResultValue: (result: ToolResultValue) => ToolOutput | undefined;
    toResultValue: (output: ToolOutput) => ToolResultValue;
};
export declare const ToolCallPart: Schema.Struct<{
    readonly type: Schema.Literal<"tool-call">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly input: Schema.Unknown;
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}> & {
    make: (input: Omit<ToolCallPart, "type">) => ToolCallPart;
};
export type ToolCallPart = Schema.Schema.Type<typeof ToolCallPart>;
export declare const ToolResultPart: Schema.Struct<{
    readonly type: Schema.Literal<"tool-result">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly result: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"json">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"error">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"content">;
        readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
    }>]> & {
        is: <I>(input: I) => input is I & ({
            readonly type: "json";
            readonly value: unknown;
        } | {
            readonly type: "text";
            readonly value: unknown;
        } | {
            readonly type: "error";
            readonly value: unknown;
        } | {
            readonly type: "content";
            readonly value: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        });
        make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
    };
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}> & {
    make: (input: Omit<ToolResultPart, "type" | "result"> & {
        readonly result: unknown;
        readonly resultType?: ToolResultValue["type"];
    }) => ToolResultPart;
};
export type ToolResultPart = Schema.Schema.Type<typeof ToolResultPart>;
export declare const ReasoningPart: Schema.Struct<{
    readonly type: Schema.Literal<"reasoning">;
    readonly text: Schema.String;
    readonly encrypted: Schema.optional<Schema.String>;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type ReasoningPart = Schema.Schema.Type<typeof ReasoningPart>;
/** A provider-generated context checkpoint, distinct from visible assistant text. */
type CompactionContent = {
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
};
declare const compactionPartSchema: Schema.refine<{
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & CompactionContent, Schema.Struct<{
    readonly type: Schema.Literal<"compaction">;
    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
    readonly id: Schema.optional<Schema.String>;
    readonly encrypted: Schema.optional<Schema.String>;
    /** Null means the provider failed to produce a summary; prior history must be retained. */
    readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
}>>;
export type CompactionPart = typeof compactionPartSchema.Type;
export declare const CompactionPart: Schema.refine<{
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & CompactionContent, Schema.Struct<{
    readonly type: Schema.Literal<"compaction">;
    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
    readonly id: Schema.optional<Schema.String>;
    readonly encrypted: Schema.optional<Schema.String>;
    /** Null means the provider failed to produce a summary; prior history must be retained. */
    readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
}>> & {
    make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & CompactionContent) => CompactionPart;
};
/** Reasoning effort changed here, from `previous` to `effort`; `undefined` is the model default. */
export declare const EffortPart: Schema.Struct<{
    readonly type: Schema.Literal<"effort">;
    readonly effort: Schema.optional<Schema.declare<ReasoningEffort, ReasoningEffort>>;
    readonly previous: Schema.optional<Schema.declare<ReasoningEffort, ReasoningEffort>>;
}>;
export type EffortPart = Schema.Schema.Type<typeof EffortPart>;
export declare const ContentPart: Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
    readonly type: Schema.Literal<"text">;
    readonly text: Schema.String;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"media">;
    readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly filename: Schema.optional<Schema.String>;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"tool-call">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly input: Schema.Unknown;
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}> & {
    make: (input: Omit<ToolCallPart, "type">) => ToolCallPart;
}, Schema.Struct<{
    readonly type: Schema.Literal<"tool-result">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly result: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"json">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"error">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"content">;
        readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
    }>]> & {
        is: <I>(input: I) => input is I & ({
            readonly type: "json";
            readonly value: unknown;
        } | {
            readonly type: "text";
            readonly value: unknown;
        } | {
            readonly type: "error";
            readonly value: unknown;
        } | {
            readonly type: "content";
            readonly value: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        });
        make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
    };
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}> & {
    make: (input: Omit<ToolResultPart, "type" | "result"> & {
        readonly result: unknown;
        readonly resultType?: ToolResultValue["type"];
    }) => ToolResultPart;
}, Schema.Struct<{
    readonly type: Schema.Literal<"reasoning">;
    readonly text: Schema.String;
    readonly encrypted: Schema.optional<Schema.String>;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.refine<{
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & CompactionContent, Schema.Struct<{
    readonly type: Schema.Literal<"compaction">;
    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
    readonly id: Schema.optional<Schema.String>;
    readonly encrypted: Schema.optional<Schema.String>;
    /** Null means the provider failed to produce a summary; prior history must be retained. */
    readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
}>> & {
    make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & CompactionContent) => CompactionPart;
}, Schema.Struct<{
    readonly type: Schema.Literal<"effort">;
    readonly effort: Schema.optional<Schema.declare<ReasoningEffort, ReasoningEffort>>;
    readonly previous: Schema.optional<Schema.declare<ReasoningEffort, ReasoningEffort>>;
}>]>;
export type ContentPart = Schema.Schema.Type<typeof ContentPart>;
declare const SystemMessage_base: Schema.Class<SystemMessage, Schema.Struct<{
    readonly id: Schema.optional<Schema.String>;
    readonly role: Schema.Literal<"system">;
    readonly content: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
        readonly cache: Schema.optional<typeof CacheHint>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"effort">;
        readonly effort: Schema.optional<Schema.declare<ReasoningEffort, ReasoningEffort>>;
        readonly previous: Schema.optional<Schema.declare<ReasoningEffort, ReasoningEffort>>;
    }>]>>;
}>, {}>;
export declare class SystemMessage extends SystemMessage_base {
}
declare const UserMessage_base: Schema.Class<UserMessage, Schema.Struct<{
    readonly id: Schema.optional<Schema.String>;
    readonly role: Schema.Literal<"user">;
    readonly content: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
        readonly cache: Schema.optional<typeof CacheHint>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"media">;
        readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"bytes">;
                readonly data: Schema.Uint8Array;
                readonly mediaType: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"base64">;
                readonly data: Schema.String;
                readonly mediaType: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"url">;
                readonly url: Schema.String;
                readonly mediaType: Schema.optional<Schema.String>;
                readonly expiresAt: Schema.optional<Schema.Number>;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"ref">;
                readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                readonly id: Schema.String;
                readonly mediaType: Schema.optional<Schema.String>;
            }>]>;
            readonly info: Schema.optional<Schema.Struct<{
                readonly width: Schema.optional<Schema.Number>;
                readonly height: Schema.optional<Schema.Number>;
                readonly durationSeconds: Schema.optional<Schema.Number>;
                readonly sampleRate: Schema.optional<Schema.Number>;
                readonly channels: Schema.optional<Schema.Number>;
                readonly encoding: Schema.optional<Schema.String>;
                readonly format: Schema.optional<Schema.String>;
            }>>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>, never, never>;
        readonly filename: Schema.optional<Schema.String>;
        readonly cache: Schema.optional<typeof CacheHint>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, {}>;
export declare class UserMessage extends UserMessage_base {
}
declare const AssistantMessage_base: Schema.Class<AssistantMessage, Schema.Struct<{
    readonly id: Schema.optional<Schema.String>;
    readonly role: Schema.Literal<"assistant">;
    readonly content: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly text: Schema.String;
        readonly cache: Schema.optional<typeof CacheHint>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"reasoning">;
        readonly text: Schema.String;
        readonly encrypted: Schema.optional<Schema.String>;
        readonly cache: Schema.optional<typeof CacheHint>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"tool-call">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly input: Schema.Unknown;
        readonly providerExecuted: Schema.optional<Schema.Boolean>;
        readonly cache: Schema.optional<typeof CacheHint>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }> & {
        make: (input: Omit<ToolCallPart, "type">) => ToolCallPart;
    }, Schema.Struct<{
        readonly type: Schema.Literal<"tool-result">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly result: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"json">;
            readonly value: Schema.Unknown;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly value: Schema.Unknown;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"error">;
            readonly value: Schema.Unknown;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"content">;
            readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>;
        }>]> & {
            is: <I>(input: I) => input is I & ({
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            });
            make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
        };
        readonly providerExecuted: Schema.optional<Schema.Boolean>;
        readonly cache: Schema.optional<typeof CacheHint>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }> & {
        make: (input: Omit<ToolResultPart, "type" | "result"> & {
            readonly result: unknown;
            readonly resultType?: ToolResultValue["type"];
        }) => ToolResultPart;
    }, Schema.Struct<{
        readonly type: Schema.Literal<"media">;
        readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"bytes">;
                readonly data: Schema.Uint8Array;
                readonly mediaType: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"base64">;
                readonly data: Schema.String;
                readonly mediaType: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"url">;
                readonly url: Schema.String;
                readonly mediaType: Schema.optional<Schema.String>;
                readonly expiresAt: Schema.optional<Schema.Number>;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"ref">;
                readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                readonly id: Schema.String;
                readonly mediaType: Schema.optional<Schema.String>;
            }>]>;
            readonly info: Schema.optional<Schema.Struct<{
                readonly width: Schema.optional<Schema.Number>;
                readonly height: Schema.optional<Schema.Number>;
                readonly durationSeconds: Schema.optional<Schema.Number>;
                readonly sampleRate: Schema.optional<Schema.Number>;
                readonly channels: Schema.optional<Schema.Number>;
                readonly encoding: Schema.optional<Schema.String>;
                readonly format: Schema.optional<Schema.String>;
            }>>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>, never, never>;
        readonly filename: Schema.optional<Schema.String>;
        readonly cache: Schema.optional<typeof CacheHint>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.refine<{
        readonly type: "compaction";
        readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
        readonly id?: string | undefined;
        readonly encrypted?: string | undefined;
        readonly text?: string | null | undefined;
    } & CompactionContent, Schema.Struct<{
        readonly type: Schema.Literal<"compaction">;
        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
        readonly id: Schema.optional<Schema.String>;
        readonly encrypted: Schema.optional<Schema.String>;
        /** Null means the provider failed to produce a summary; prior history must be retained. */
        readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
    }>> & {
        make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & CompactionContent) => CompactionPart;
    }]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, {}>;
export declare class AssistantMessage extends AssistantMessage_base {
}
declare const ToolMessage_base: Schema.Class<ToolMessage, Schema.Struct<{
    readonly id: Schema.optional<Schema.String>;
    readonly role: Schema.Literal<"tool">;
    readonly content: Schema.$Array<Schema.Struct<{
        readonly type: Schema.Literal<"tool-result">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly result: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"json">;
            readonly value: Schema.Unknown;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly value: Schema.Unknown;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"error">;
            readonly value: Schema.Unknown;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"content">;
            readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>;
        }>]> & {
            is: <I>(input: I) => input is I & ({
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            });
            make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
        };
        readonly providerExecuted: Schema.optional<Schema.Boolean>;
        readonly cache: Schema.optional<typeof CacheHint>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }> & {
        make: (input: Omit<ToolResultPart, "type" | "result"> & {
            readonly result: unknown;
            readonly resultType?: ToolResultValue["type"];
        }) => ToolResultPart;
    }>;
}>, {}>;
export declare class ToolMessage extends ToolMessage_base {
}
export type Message = SystemMessage | UserMessage | AssistantMessage | ToolMessage;
export type ContentPartInput = Exclude<ContentPart, MediaPart> | MediaPartInput;
export declare namespace Message {
    export type ContentInput<Part extends {
        readonly type: string;
    } = ContentPartInput> = string | Part | ReadonlyArray<Part>;
    export type SystemContentInput = ContentInput<TextPart>;
    export type UserContentInput = ContentInput<TextPart | MediaPartInput>;
    export type AssistantContentInput = ContentInput<Exclude<AssistantMessage["content"][number], MediaPart> | MediaPartInput>;
    type RoleInput<Props, Content> = Omit<Props, "content"> & {
        readonly content: Content;
    };
    export type SystemInput = RoleInput<ConstructorParameters<typeof SystemMessage>[0], ContentInput<SystemMessage["content"][number]>>;
    export type UserInput = RoleInput<ConstructorParameters<typeof UserMessage>[0], UserContentInput>;
    export type AssistantInput = RoleInput<ConstructorParameters<typeof AssistantMessage>[0], AssistantContentInput>;
    export type ToolInput = RoleInput<ConstructorParameters<typeof ToolMessage>[0], ToolResultPart | ReadonlyArray<ToolResultPart>>;
    export type Input = SystemInput | UserInput | AssistantInput | ToolInput;
    export {};
}
declare const text: (value: string) => TextPart;
declare function contentWithMedia(input: Message.UserContentInput): UserMessage["content"];
declare function contentWithMedia(input: Message.AssistantContentInput): AssistantMessage["content"];
declare function contentWithMedia(input: Message.ContentInput): ReadonlyArray<ContentPart>;
declare function make(input: SystemMessage | Message.SystemInput): SystemMessage;
declare function make(input: UserMessage | Message.UserInput): UserMessage;
declare function make(input: AssistantMessage | Message.AssistantInput): AssistantMessage;
declare function make(input: ToolMessage | Message.ToolInput): ToolMessage;
declare function make(input: Message | Message.Input): Message;
export declare const Message: Schema.Union<readonly [typeof SystemMessage, typeof UserMessage, typeof AssistantMessage, typeof ToolMessage]> & {
    text: typeof text;
    media: (media: MediaPartInput["media"], options?: Omit<MediaPartInput, "type" | "media">) => MediaPart;
    content: typeof contentWithMedia;
    make: typeof make;
    user: (input: Message.UserContentInput) => UserMessage;
    assistant: (input: Message.AssistantContentInput) => AssistantMessage;
    /**
     * Add an operator-authored instruction at this chronological point in the
     * conversation. This is distinct from the initial `LLMRequest.system`
     * prompt. Keep raw retrieved, tool, and web content out of privileged system
     * updates; pass that untrusted content through ordinary user/tool channels.
     */
    system: (input: Message.SystemContentInput) => SystemMessage;
    effort: (input: {
        readonly effort?: ReasoningEffort;
        readonly previous?: ReasoningEffort;
    }) => SystemMessage;
    tool: (result: ToolResultPart | Parameters<typeof ToolResultPart.make>[0]) => ToolMessage;
};
/**
 * Raw-text wire encoding for a tool with exactly one required string parameter. Models that accept the format
 * write that parameter's value directly instead of JSON arguments; calls still decode to the normal object input.
 */
export declare const Freeform: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"text">;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"regex">;
    readonly pattern: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"lark">;
    readonly grammar: Schema.String;
}>]>;
export type Freeform = Schema.Schema.Type<typeof Freeform>;
declare const toolDefinitionFields: {
    name: Schema.String;
    description: Schema.String;
    inputSchema: Schema.$Record<Schema.String, Schema.Unknown>;
    outputSchema: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    freeform: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"regex">;
        readonly pattern: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"lark">;
        readonly grammar: Schema.String;
    }>]>>;
    cache: Schema.optional<typeof CacheHint>;
    native: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
};
export type ToolDefinitionInput = Schema.Struct.Type<typeof toolDefinitionFields>;
declare const ToolDefinition_base: Schema.Class<ToolDefinition, Schema.Struct<{
    readonly name: Schema.String;
    readonly description: Schema.String;
    readonly inputSchema: Schema.$Record<Schema.String, Schema.Unknown>;
    readonly outputSchema: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly freeform: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"text">;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"regex">;
        readonly pattern: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"lark">;
        readonly grammar: Schema.String;
    }>]>>;
    readonly cache: Schema.optional<typeof CacheHint>;
    readonly native: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly type: Schema.Literal<"tool">;
}>, {}>;
export declare class ToolDefinition extends ToolDefinition_base {
    constructor(input: ToolDefinitionInput);
}
export declare namespace ToolDefinition {
    type Input = ToolDefinition | ToolDefinitionInput;
    /** Normalize tool definition input into the canonical `ToolDefinition` class. */
    const make: (input: Input) => ToolDefinition;
    /** The parameter a freeform call fills: the input schema's only property, when it is a required string. */
    const freeformField: (schema: JsonSchema) => string | undefined;
}
export type ToolNamespace = {
    readonly type: "namespace";
    readonly name: string;
    readonly description?: string;
    readonly tools: ReadonlyArray<ToolEntry>;
};
export type ToolNamespaceInput = Omit<ToolNamespace, "type" | "tools"> & {
    readonly tools: ReadonlyArray<ToolEntryInput>;
};
export type ToolNamespaceEntryInput = ToolNamespaceInput & {
    readonly type: "namespace";
};
export declare const ToolNamespace: Schema.Codec<ToolNamespace> & {
    readonly make: (input: ToolNamespace | ToolNamespaceInput) => ToolNamespace;
};
export type ToolEntry = ToolDefinition | ToolNamespace;
export type ToolEntryInput = ToolDefinition.Input | ToolNamespaceEntryInput;
export declare const ToolEntry: Schema.Codec<ToolEntry> & {
    readonly make: (input: ToolEntryInput) => ToolEntry;
};
declare const ToolChoice_base: Schema.Class<ToolChoice, Schema.Struct<{
    readonly type: Schema.Literals<readonly ["auto", "none", "required", "tool"]>;
    readonly name: Schema.optional<Schema.String>;
    readonly disableParallelToolUse: Schema.optional<Schema.Boolean>;
}>, {}>;
export declare class ToolChoice extends ToolChoice_base {
}
export declare namespace ToolChoice {
    type Mode = Exclude<ToolChoice["type"], "tool">;
    type Input = ToolChoice | ConstructorParameters<typeof ToolChoice>[0] | ToolDefinition | string;
    /** Select a specific named tool. */
    const named: (value: string) => ToolChoice;
    /** Normalize ergonomic tool-choice inputs into the canonical `ToolChoice` class. */
    const make: (input: Input) => ToolChoice;
}
/**
 * A normalized text request, the plain object `ai.request(...)` returns. Edit it with a spread, such as
 * `{ ...request, messages: [...request.messages, next] }`, or pass the edited object back to `ai.request`.
 */
export interface LLMRequest<Model extends LanguageModel = LanguageModel> extends BaseRequest<Model, LanguageModelProviderOptions<Model>>, GenerationOptionsFields {
    readonly id?: string;
    readonly system: ReadonlyArray<SystemPart>;
    readonly messages: ReadonlyArray<Message>;
    readonly tools: ReadonlyArray<ToolEntry>;
    readonly toolChoice?: ToolChoice;
    readonly cache?: CachePolicy;
    /** Stable cache affinity for protocols that support provider-managed prompt caching. */
    readonly promptCacheKey?: string;
    /** Emit a `raw` event with each provider frame before the events parsed from it. */
    readonly includeRaw?: boolean;
}
export {};
