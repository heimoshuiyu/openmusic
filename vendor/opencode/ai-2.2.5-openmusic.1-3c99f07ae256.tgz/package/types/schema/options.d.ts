import { Schema } from "effect";
import { ModelID, ProviderID } from "./ids.js";
import type { AnyRoute, CompactionOperations } from "../route/client.js";
export declare const JsonSchema: Schema.$Record<Schema.String, Schema.Unknown>;
export type JsonSchema = Schema.Schema.Type<typeof JsonSchema>;
export declare const mergeJsonRecords: (...items: ReadonlyArray<Record<string, unknown> | undefined>) => Record<string, unknown> | undefined;
export declare const ProviderOptions: Schema.$Record<Schema.String, Schema.Unknown>;
export type ProviderOptions = Schema.Schema.Type<typeof ProviderOptions>;
export declare const ProviderMetadata: Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>;
export type ProviderMetadata = Schema.Schema.Type<typeof ProviderMetadata>;
export declare const mergeProviderOptions: (...items: ReadonlyArray<ProviderOptions | undefined>) => ProviderOptions | undefined;
/** Milliseconds for an HTTP timeout, or `false` to disable it. */
export declare const HttpTimeout: Schema.Union<readonly [Schema.Number, Schema.Literal<false>]>;
export type HttpTimeout = Schema.Schema.Type<typeof HttpTimeout>;
/** Applied to `timeout.headers` when a request leaves it unset. */
export declare const DEFAULT_HTTP_TIMEOUT_MS = 300000;
/**
 * Applied to `timeout.chunk` when a request leaves it unset. Some providers, such as DeepSeek, have specifically asked
 * clients to allow at least 15 minutes, because their models can stream nothing for minutes while they reason.
 */
export declare const DEFAULT_CHUNK_TIMEOUT_MS = 900000;
/** `Content-Encoding` for JSON request bodies; `none` sends plain JSON. */
export declare const RequestEncoding: Schema.Literals<readonly ["zstd", "gzip", "none"]>;
export type RequestEncoding = Schema.Schema.Type<typeof RequestEncoding>;
/** Rare wire-level overrides. */
export interface HttpOptions {
    readonly query?: Record<string, string>;
    /** Deep-merged over the provider-native JSON body. */
    readonly body?: Record<string, unknown>;
    /** Compression for JSON request bodies. Only set it for endpoints known to decode it. */
    readonly encoding?: RequestEncoding;
}
/** Per-phase time limits in milliseconds. */
export interface TimeoutConfig {
    /** The whole request, from send until the response completes. Unbounded when unset. */
    readonly total?: HttpTimeout;
    /** Until response headers arrive. */
    readonly headers?: HttpTimeout;
    /** Between streamed response chunks once headers have arrived. */
    readonly chunk?: HttpTimeout;
}
/** Milliseconds for the whole request, `false` to disable it, or per-phase limits. */
export type RequestTimeout = HttpTimeout | TimeoutConfig;
/** Transport settings shared by requests, models and routes. */
export interface TransportOptions {
    /** Merged over the provider's headers; these win. */
    readonly headers?: Record<string, string>;
    /** Applied to text requests; media requests do not apply it yet. */
    readonly timeout?: RequestTimeout;
    readonly http?: HttpOptions;
}
/** The fields every request shares, whatever its modality. */
export interface BaseRequest<Model, Options = ProviderOptions> extends TransportOptions {
    readonly model: Model;
    readonly providerOptions?: Options;
    /** Sends this call through `fetch` instead of the client's HTTP executor. */
    readonly fetch?: typeof globalThis.fetch;
}
export declare const timeoutConfig: (timeout: RequestTimeout | undefined) => TimeoutConfig;
/** Merge transport settings; later items win, headers, query and body merge by key. */
export declare const mergeTransport: (...items: ReadonlyArray<TransportOptions | undefined>) => TransportOptions;
/** Portable sampling knobs, set at the top level of text requests, model defaults and route defaults. */
export interface GenerationOptionsFields {
    readonly maxTokens?: number;
    readonly temperature?: number;
    readonly topP?: number;
    readonly topK?: number;
    readonly frequencyPenalty?: number;
    readonly presencePenalty?: number;
    readonly seed?: number;
    readonly stop?: ReadonlyArray<string>;
}
/** The keys of `GenerationOptionsFields`, for splitting a flat record into portable knobs and provider options. */
export declare const GENERATION_KEYS: ReadonlySet<string>;
/** Pick the generation knobs out of each item; later items win per knob. */
export declare const mergeGeneration: (...items: ReadonlyArray<GenerationOptionsFields | undefined>) => GenerationOptionsFields;
/** Request options a model applies under each request: the same keys as a request, and the request wins. */
export interface RequestOptions extends TransportOptions, GenerationOptionsFields {
    readonly providerOptions?: ProviderOptions;
}
/** Merge model options; later items win per key. Empty results are `undefined`. */
export declare const mergeRequestOptions: (...items: ReadonlyArray<RequestOptions | undefined>) => RequestOptions | undefined;
/** Provider-defined string enum: known values for autocomplete, any string accepted. */
export type OpenString<Known extends string> = Known | (string & {});
export declare const ReasoningEfforts: readonly ["none", "minimal", "low", "medium", "high", "xhigh", "max"];
export type ReasoningEffort = OpenString<(typeof ReasoningEfforts)[number]>;
export declare const ReasoningEffort: Schema.declare<ReasoningEffort, ReasoningEffort>;
/** Tool schema sanitizer for a model family. `none` opts out of the protocol and model-name defaults. */
export declare const LanguageModelSanitizerCompatibility: Schema.Literals<readonly ["gemini", "moonshot", "none"]>;
export type LanguageModelSanitizerCompatibility = Schema.Schema.Type<typeof LanguageModelSanitizerCompatibility>;
export declare const LanguageModelMaxTokensFieldCompatibility: Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>;
export type LanguageModelMaxTokensFieldCompatibility = Schema.Schema.Type<typeof LanguageModelMaxTokensFieldCompatibility>;
export declare const LanguageModelCacheFormatCompatibility: Schema.Literals<readonly ["anthropic", "alibaba"]>;
export type LanguageModelCacheFormatCompatibility = Schema.Schema.Type<typeof LanguageModelCacheFormatCompatibility>;
declare const LanguageModelCompatibility_base: Schema.Class<LanguageModelCompatibility, Schema.Struct<{
    readonly sanitizer: Schema.optional<Schema.Literals<readonly ["gemini", "moonshot", "none"]>>;
    readonly reasoningField: Schema.optional<Schema.String>;
    /** Require every assistant message to include its reasoning field, even when empty. */
    readonly requireReasoning: Schema.optional<Schema.Boolean>;
    readonly maxTokensField: Schema.optional<Schema.Literals<readonly ["max_completion_tokens", "max_tokens"]>>;
    readonly requireFinishReason: Schema.optional<Schema.Boolean>;
    readonly requireAssistantAfterTool: Schema.optional<Schema.Boolean>;
    /** Prompt-cache marker syntax the endpoint accepts. Overrides the route default; both send `cache_control`, and `alibaba` skips tool definitions. */
    readonly cacheFormat: Schema.optional<Schema.Literals<readonly ["anthropic", "alibaba"]>>;
    readonly zaiToolStream: Schema.optional<Schema.Boolean>;
    readonly requireSignature: Schema.optional<Schema.Boolean>;
    /** Supports Anthropic's thinking-prefix mismatch controls. Overrides model-ID detection. */
    readonly supportsThinkingBlockBinding: Schema.optional<Schema.Boolean>;
}>, {}>;
export declare class LanguageModelCompatibility extends LanguageModelCompatibility_base {
}
export declare namespace LanguageModelCompatibility {
    type Input = LanguageModelCompatibility | ConstructorParameters<typeof LanguageModelCompatibility>[0];
    /** Normalize model/upstream compatibility metadata without projecting requests. */
    const make: (input: Input) => LanguageModelCompatibility;
}
/**
 * What the model accepts on its API: models.dev v2 `capabilities` in camelCase, with the API's own overrides merged in.
 * Unset fields keep the protocol default, which may still guess from the provider, base URL or model ID.
 */
export interface Capabilities {
    readonly tools?: {
        readonly supported?: boolean;
        /** Accepts `strict` on function tools. OpenAI Chat detects it from the provider when unset. */
        readonly strict?: boolean;
        readonly choice?: ReadonlyArray<"auto" | "none" | "required" | "tool">;
        readonly search?: boolean;
        /** Input formats accepted by custom (free-form) tools. */
        readonly freeform?: ReadonlyArray<"text" | "lark" | "regex">;
        /** Accepts a changed tool list mid-conversation. */
        readonly updates?: boolean;
    };
    readonly reasoning?: {
        readonly supported?: boolean;
        readonly default?: {
            readonly type: "toggle";
            readonly value: boolean;
        } | {
            readonly type: "effort";
            readonly value: ReasoningEffort;
        } | {
            readonly type: "budget";
            readonly value: number;
        };
        readonly toggle?: boolean;
        readonly effort?: ReadonlyArray<ReasoningEffort>;
        readonly budget?: {
            readonly min?: number;
            readonly max?: number;
        };
        /** Accepts per-message effort updates. Detected from the model ID when unset. */
        readonly updates?: boolean;
    };
    readonly cache?: false | {
        readonly implicit?: true | {
            readonly ttl?: ReadonlyArray<CacheTTL>;
            readonly minTokens?: number;
        };
        readonly explicit?: true | {
            readonly ttl?: ReadonlyArray<CacheTTL>;
            readonly maxBreakpoints?: number;
            readonly targets?: ReadonlyArray<"tools" | "system" | "messages">;
            readonly minTokens?: number;
        };
    };
    readonly structuredOutput?: boolean;
    readonly temperature?: boolean;
    readonly topP?: boolean;
    readonly topK?: boolean;
    /** Accepts mid-conversation system messages. Anthropic Messages detects it from the model ID when unset. */
    readonly systemUpdates?: boolean;
    /** Accepts `store`. OpenAI Chat detects it from the provider when unset. */
    readonly store?: boolean;
    /** Accepts `stream_options.include_usage`. OpenAI Chat defaults to true. */
    readonly streamUsage?: boolean;
    readonly promptCacheKey?: boolean;
    readonly serviceTier?: ReadonlyArray<OpenString<"flex" | "priority" | "fast" | "ultrafast" | "standby">>;
}
export declare class LanguageModel<Options extends ProviderOptions = ProviderOptions, Compact extends CompactionOperations | undefined = CompactionOperations | undefined> {
    protected readonly _ProviderOptions: Options;
    readonly id: ModelID;
    readonly provider: ProviderID;
    readonly route: AnyRoute<Compact>;
    readonly options?: RequestOptions;
    readonly capabilities?: Capabilities;
    readonly compatibility?: LanguageModelCompatibility;
    constructor(input: LanguageModel.ConstructorInput<Compact>);
    static make<Options extends ProviderOptions = ProviderOptions, Compact extends CompactionOperations | undefined = CompactionOperations | undefined>(input: LanguageModel.Input<Compact>): LanguageModel<Options, Compact>;
    static input<Options extends ProviderOptions, Compact extends CompactionOperations | undefined>(model: LanguageModel<Options, Compact>): LanguageModel.ConstructorInput<Compact>;
    static update<Options extends ProviderOptions, Compact extends CompactionOperations | undefined>(model: LanguageModel<Options>, patch: Partial<LanguageModel.Input<Compact>> & {
        readonly route: AnyRoute<Compact>;
    }): LanguageModel<Options, Compact>;
    static update<Options extends ProviderOptions, Compact extends CompactionOperations | undefined>(model: LanguageModel<Options, Compact>, patch: Partial<Omit<LanguageModel.Input, "route">> & {
        readonly route?: undefined;
    }): LanguageModel<Options, Compact>;
    static update<Options extends ProviderOptions>(model: LanguageModel<Options>, patch: Partial<LanguageModel.Input>): LanguageModel<Options>;
}
export declare namespace LanguageModel {
    type ConstructorInput<Compact extends CompactionOperations | undefined = CompactionOperations | undefined> = {
        readonly id: ModelID;
        readonly provider: ProviderID;
        readonly route: AnyRoute<Compact>;
        readonly options?: RequestOptions;
        readonly capabilities?: Capabilities;
        readonly compatibility?: LanguageModelCompatibility;
    };
    type Input<Compact extends CompactionOperations | undefined = CompactionOperations | undefined> = Omit<ConstructorInput<Compact>, "id" | "provider" | "compatibility"> & {
        readonly id: string | ModelID;
        readonly provider: string | ProviderID;
        readonly compatibility?: LanguageModelCompatibility.Input;
    };
}
export type LanguageModelInput = LanguageModel.Input;
export type LanguageModelProviderOptions<SelectedModel> = SelectedModel extends LanguageModel<infer Options> ? Options : never;
export declare const LanguageModelSchema: Schema.declare<LanguageModel<{
    readonly [x: string]: unknown;
}, CompactionOperations | undefined>, LanguageModel<{
    readonly [x: string]: unknown;
}, CompactionOperations | undefined>>;
export declare const CacheTTL: Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>;
export type CacheTTL = typeof CacheTTL.Type;
declare const CacheHint_base: Schema.Class<CacheHint, Schema.Struct<{
    readonly type: Schema.Literals<readonly ["ephemeral", "persistent"]>;
    readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
}>, {}>;
export declare class CacheHint extends CacheHint_base {
}
export declare const CachePolicyObject: Schema.Struct<{
    readonly tools: Schema.optional<Schema.Boolean>;
    readonly system: Schema.optional<Schema.Boolean>;
    readonly messages: Schema.optional<Schema.Union<readonly [Schema.Literal<"latest-user-message">, Schema.Literal<"latest-assistant">, Schema.Struct<{
        readonly tail: Schema.Natural;
    }>]>>;
    readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
}>;
export type CachePolicyObject = Schema.Schema.Type<typeof CachePolicyObject>;
export declare const CachePolicy: Schema.Union<readonly [Schema.Literal<"auto">, Schema.Literal<"none">, Schema.Struct<{
    readonly tools: Schema.optional<Schema.Boolean>;
    readonly system: Schema.optional<Schema.Boolean>;
    readonly messages: Schema.optional<Schema.Union<readonly [Schema.Literal<"latest-user-message">, Schema.Literal<"latest-assistant">, Schema.Struct<{
        readonly tail: Schema.Natural;
    }>]>>;
    readonly ttl: Schema.optional<Schema.TemplateLiteral<readonly [Schema.Number, Schema.Literals<readonly ["ms", "s", "m", "h", "d"]>]>>;
}>]>;
export type CachePolicy = Schema.Schema.Type<typeof CachePolicy>;
export {};
