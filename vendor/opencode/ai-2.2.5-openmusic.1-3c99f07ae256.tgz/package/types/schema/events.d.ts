import { Schema } from "effect";
import { ContentBlockID, ToolCallID } from "./ids.js";
import { AssistantMessage, Message, CompactionPart, ToolOutput, ToolResultPart, ToolResultValue } from "./messages.js";
import { ProviderMetadata } from "./options.js";
import { Media } from "../media.js";
export declare const FinishReason: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
export type FinishReason = Schema.Schema.Type<typeof FinishReason>;
declare const Usage_base: Schema.Class<Usage, Schema.Struct<{
    /** Effective input size of the final message iteration, when reported; not billed totals. */
    readonly contextTokens: Schema.optional<Schema.Number>;
    readonly inputTokens: Schema.optional<Schema.Number>;
    readonly outputTokens: Schema.optional<Schema.Number>;
    readonly nonCachedInputTokens: Schema.optional<Schema.Number>;
    readonly cacheReadInputTokens: Schema.optional<Schema.Number>;
    readonly cacheWriteInputTokens: Schema.optional<Schema.Number>;
    readonly reasoningTokens: Schema.optional<Schema.Number>;
    readonly totalTokens: Schema.optional<Schema.Number>;
    /**
     * USD the endpoint says it charged for this request, as OpenRouter, LiteLLM and OpenCode Zen report it in
     * `usage.cost`. `0` is authoritative: the request was free or a subscription covered it. Absent, callers price the
     * tokens themselves.
     */
    readonly cost: Schema.optional<Schema.Number>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, {}>;
/**
 * Token usage reported by an LLM provider.
 *
 * **Inclusive totals** (match AI SDK / OpenAI / LangChain convention — a
 * reader from any of those ecosystems sees the number they expect):
 *
 * - `inputTokens` — total prompt tokens, *including* cached reads/writes.
 * - `outputTokens` — total output tokens, *including* reasoning.
 * - `totalTokens` — provider-supplied total, or `inputTokens + outputTokens`.
 *
 * **Non-overlapping breakdown** (every field is independently meaningful;
 * consumers never have to subtract):
 *
 * - `nonCachedInputTokens` — the "fresh" portion of the prompt.
 * - `cacheReadInputTokens` — input tokens served from cache.
 * - `cacheWriteInputTokens` — input tokens written to cache.
 * - `reasoningTokens` — subset of `outputTokens` spent on hidden reasoning.
 *
 * **Invariant**: `nonCachedInputTokens + cacheReadInputTokens +
 * cacheWriteInputTokens = inputTokens`, and `reasoningTokens ≤ outputTokens`.
 * Each protocol mapper computes whichever side it doesn't get natively,
 * with `Math.max(0, …)` clamping for defense against provider bugs. Because
 * every breakdown field is stored independently, downstream consumers can
 * read whatever they need (cost-by-category, context-pressure, AI-SDK-style
 * inclusive total) without ever subtracting — eliminating the underflow
 * class of bug where a clamped difference would silently store the wrong
 * value.
 *
 * **Semantics by provider**:
 *
 * - OpenAI Chat / Responses / Gemini: provider reports inclusive
 *   `inputTokens` and an inclusive `outputTokens`; mapper subtracts to
 *   derive the breakdown.
 * - Anthropic and Bedrock report the input breakdown natively: Anthropic's
 *   `input_tokens` and Bedrock's `inputTokens` are non-cached only. Their
 *   mappers sum the breakdown to derive the inclusive `inputTokens`.
 *   Anthropic's `outputTokens` includes extended thinking. Newer responses
 *   expose that subset as `output_tokens_details.thinking_tokens`, which maps
 *   to `reasoningTokens`; older responses leave it undefined.
 *
 * `providerMetadata` always carries the provider's raw usage payload —
 * keyed by provider name (`{ openai: ... }`, `{ anthropic: ... }`, etc.)
 * — for fields we don't normalize and for billing-level audit trails.
 * Matches the same escape-hatch field on `LLMEvent`.
 */
export declare class Usage extends Usage_base {
    /**
     * Non-reasoning output tokens (including compaction summaries) — `outputTokens` minus `reasoningTokens`, clamped
     * to zero. The one place subtraction happens in this contract; the clamp
     * means a provider reporting `reasoningTokens > outputTokens` produces a
     * harmless zero rather than a negative that crashes downstream schemas.
     */
    get visibleOutputTokens(): number;
    static from(input: UsageInput): Usage;
}
export type UsageInput = Usage | ConstructorParameters<typeof Usage>[0];
/**
 * Usage reported by media routes. Providers bill images, video, speech, and transcription in different units, so
 * each response carries the unit it was actually metered in instead of forcing everything into tokens.
 */
export declare const MediaUsage: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"tokens">;
    readonly input: Schema.optional<Schema.Number>;
    readonly output: Schema.optional<Schema.Number>;
    readonly total: Schema.optional<Schema.Number>;
    readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"seconds">;
    readonly seconds: Schema.Number;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"characters">;
    readonly characters: Schema.Number;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"credits">;
    readonly credits: Schema.Number;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"compute">;
    readonly seconds: Schema.Number;
}>]>;
export type MediaUsage = Schema.Schema.Type<typeof MediaUsage>;
/** Token usage from a provider's counts. A usage object without any count is no usage, so it returns undefined. */
export declare const tokenUsage: (counts: {
    readonly input?: number;
    readonly output?: number;
    readonly total?: number;
    readonly details?: Record<string, unknown>;
}) => MediaUsage | undefined;
declare const CompactionResponse_base: Schema.Class<CompactionResponse, Schema.Struct<{
    readonly replacement: Schema.$Array<Schema.Union<readonly [typeof import("./messages.js").SystemMessage, typeof import("./messages.js").UserMessage, typeof AssistantMessage, typeof import("./messages.js").ToolMessage]> & {
        text: (value: string) => import("./messages.js").TextPart;
        media: (media: import("./messages.js").MediaPartInput["media"], options?: Omit<import("./messages.js").MediaPartInput, "type" | "media">) => import("./messages.js").MediaPart;
        content: {
            (input: Message.UserContentInput): import("./messages.js").UserMessage["content"];
            (input: Message.AssistantContentInput): AssistantMessage["content"];
            (input: Message.ContentInput): ReadonlyArray<import("./messages.js").ContentPart>;
        };
        make: {
            (input: import("./messages.js").SystemMessage | Message.SystemInput): import("./messages.js").SystemMessage;
            (input: import("./messages.js").UserMessage | Message.UserInput): import("./messages.js").UserMessage;
            (input: AssistantMessage | Message.AssistantInput): AssistantMessage;
            (input: import("./messages.js").ToolMessage | Message.ToolInput): import("./messages.js").ToolMessage;
            (input: Message | Message.Input): Message;
        };
        user: (input: Message.UserContentInput) => import("./messages.js").UserMessage;
        assistant: (input: Message.AssistantContentInput) => AssistantMessage;
        system: (input: Message.SystemContentInput) => import("./messages.js").SystemMessage;
        effort: (input: {
            readonly effort?: import("./options.js").ReasoningEffort;
            readonly previous?: import("./options.js").ReasoningEffort;
        }) => import("./messages.js").SystemMessage;
        tool: (result: ToolResultPart | Parameters<typeof ToolResultPart.make>[0]) => import("./messages.js").ToolMessage;
    }>;
    readonly usage: Schema.optional<typeof Usage>;
}>, {}>;
/** A replacement context window, not an assistant message to append to prior history. */
export declare class CompactionResponse extends CompactionResponse_base {
}
declare const CompactionCheckpointResponse_base: Schema.Class<CompactionCheckpointResponse, Schema.Struct<{
    readonly checkpoint: Schema.refine<{
        readonly type: "compaction";
        readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
        readonly id?: string | undefined;
        readonly encrypted?: string | undefined;
        readonly text?: string | null | undefined;
    } & {
        readonly encrypted: string;
        readonly text?: never;
    } & {
        readonly encrypted: string;
        readonly text?: never;
    }, Schema.refine<{
        readonly type: "compaction";
        readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
        readonly id?: string | undefined;
        readonly encrypted?: string | undefined;
        readonly text?: string | null | undefined;
    } & ({
        readonly encrypted: string;
        readonly text?: never;
    } | {
        readonly text: string | null;
        readonly encrypted?: never;
    }), Schema.Struct<{
        readonly type: Schema.Literal<"compaction">;
        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
        readonly id: Schema.optional<Schema.String>;
        readonly encrypted: Schema.optional<Schema.String>;
        readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
    }>> & {
        make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        })) => CompactionPart;
    }>;
    readonly responseID: Schema.String;
    readonly usage: Schema.optional<typeof Usage>;
}>, {}>;
/** A checkpoint only; retained history and replacement-window construction belong to the caller. */
export declare class CompactionCheckpointResponse extends CompactionCheckpointResponse_base {
}
export declare const StepStart: Schema.Struct<{
    readonly type: Schema.tag<"step-start">;
    readonly index: Schema.Number;
}>;
export type StepStart = Schema.Schema.Type<typeof StepStart>;
export declare const TextStart: Schema.Struct<{
    readonly type: Schema.tag<"text-start">;
    readonly id: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type TextStart = Schema.Schema.Type<typeof TextStart>;
export declare const TextDelta: Schema.Struct<{
    readonly type: Schema.tag<"text-delta">;
    readonly id: Schema.String;
    readonly text: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type TextDelta = Schema.Schema.Type<typeof TextDelta>;
export declare const TextEnd: Schema.Struct<{
    readonly type: Schema.tag<"text-end">;
    readonly id: Schema.String;
    /** Authoritative complete value; replaces accumulated deltas when present. */
    readonly text: Schema.optional<Schema.String>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type TextEnd = Schema.Schema.Type<typeof TextEnd>;
export declare const ReasoningStart: Schema.Struct<{
    readonly type: Schema.tag<"reasoning-start">;
    readonly id: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type ReasoningStart = Schema.Schema.Type<typeof ReasoningStart>;
export declare const ReasoningDelta: Schema.Struct<{
    readonly type: Schema.tag<"reasoning-delta">;
    readonly id: Schema.String;
    readonly text: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type ReasoningDelta = Schema.Schema.Type<typeof ReasoningDelta>;
export declare const ReasoningEnd: Schema.Struct<{
    readonly type: Schema.tag<"reasoning-end">;
    readonly id: Schema.String;
    /** Authoritative complete value; replaces accumulated deltas when present. */
    readonly text: Schema.optional<Schema.String>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type ReasoningEnd = Schema.Schema.Type<typeof ReasoningEnd>;
export declare const ToolInputStart: Schema.Struct<{
    readonly type: Schema.tag<"tool-input-start">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type ToolInputStart = Schema.Schema.Type<typeof ToolInputStart>;
export declare const ToolInputDelta: Schema.Struct<{
    readonly type: Schema.tag<"tool-input-delta">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly text: Schema.String;
    /** Best-effort parse of all input fragments received through this delta. */
    readonly input: Schema.optional<Schema.Unknown>;
}>;
export type ToolInputDelta = Schema.Schema.Type<typeof ToolInputDelta>;
export declare const ToolInputEnd: Schema.Struct<{
    readonly type: Schema.tag<"tool-input-end">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type ToolInputEnd = Schema.Schema.Type<typeof ToolInputEnd>;
/** A local tool call whose final input could not be decoded. */
export declare const ToolInputError: Schema.Struct<{
    readonly type: Schema.tag<"tool-input-error">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly raw: Schema.String;
}>;
export type ToolInputError = Schema.Schema.Type<typeof ToolInputError>;
export declare const ToolCall: Schema.Struct<{
    readonly type: Schema.tag<"tool-call">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly input: Schema.Unknown;
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type ToolCall = Schema.Schema.Type<typeof ToolCall>;
export declare const ToolResult: Schema.Struct<{
    readonly type: Schema.tag<"tool-result">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly result: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"json">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"error">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"content">;
        readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
    }>]> & {
        is: <I>(input: I) => input is I & ({
            readonly type: "json";
            readonly value: unknown;
        } | {
            readonly type: "text";
            readonly value: unknown;
        } | {
            readonly type: "error";
            readonly value: unknown;
        } | {
            readonly type: "content";
            readonly value: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        });
        make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
    };
    readonly output: Schema.optional<Schema.Struct<{
        readonly structured: Schema.Unknown;
        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
    }> & {
        make: (structured: unknown, content?: ReadonlyArray<import("@opencode/schema/tool").Content>) => ToolOutput;
        fromResultValue: (result: ToolResultValue) => ToolOutput | undefined;
        toResultValue: (output: ToolOutput) => ToolResultValue;
    }>;
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type ToolResult = Schema.Schema.Type<typeof ToolResult>;
export declare const FinishReasonDetails: Schema.Struct<{
    readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
    readonly raw: Schema.optional<Schema.String>;
    /** The provider's policy area for a content-filter finish, such as `cyber`. */
    readonly category: Schema.optional<Schema.String>;
    /** The provider's human-readable reason for a content-filter finish. */
    readonly explanation: Schema.optional<Schema.String>;
}>;
export type FinishReasonDetails = Schema.Schema.Type<typeof FinishReasonDetails>;
export declare const StepFinish: Schema.Struct<{
    readonly type: Schema.tag<"step-finish">;
    readonly index: Schema.Number;
    readonly reason: Schema.Struct<{
        readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly raw: Schema.optional<Schema.String>;
        /** The provider's policy area for a content-filter finish, such as `cyber`. */
        readonly category: Schema.optional<Schema.String>;
        /** The provider's human-readable reason for a content-filter finish. */
        readonly explanation: Schema.optional<Schema.String>;
    }>;
    readonly usage: Schema.optional<typeof Usage>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type StepFinish = Schema.Schema.Type<typeof StepFinish>;
export declare const Finish: Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly reason: Schema.Struct<{
        readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly raw: Schema.optional<Schema.String>;
        /** The provider's policy area for a content-filter finish, such as `cyber`. */
        readonly category: Schema.optional<Schema.String>;
        /** The provider's human-readable reason for a content-filter finish. */
        readonly explanation: Schema.optional<Schema.String>;
    }>;
    readonly usage: Schema.optional<typeof Usage>;
    /** The final assistant message, set by `ai.stream` and `ai.loop`. */
    readonly message: Schema.optional<typeof AssistantMessage>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type Finish = Schema.Schema.Type<typeof Finish>;
/** A generated media asset (image, audio, …) emitted by the model as first-class output rather than a tool result. */
export declare const MediaEvent: Schema.Struct<{
    readonly type: Schema.tag<"media">;
    readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
export type MediaEvent = Schema.Schema.Type<typeof MediaEvent>;
/** One provider frame as received, emitted before the events parsed from it when the request sets `includeRaw`. */
export declare const RawEvent: Schema.Struct<{
    readonly type: Schema.tag<"raw">;
    readonly data: Schema.Unknown;
}>;
export type RawEvent = Schema.Schema.Type<typeof RawEvent>;
declare const llmEventTagged: Schema.toTaggedUnion<"type", readonly [Schema.refine<{
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
}), Schema.Struct<{
    readonly type: Schema.Literal<"compaction">;
    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
    readonly id: Schema.optional<Schema.String>;
    readonly encrypted: Schema.optional<Schema.String>;
    readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
}>> & {
    make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
        readonly encrypted: string;
        readonly text?: never;
    } | {
        readonly text: string | null;
        readonly encrypted?: never;
    })) => CompactionPart;
}, Schema.Struct<{
    readonly type: Schema.tag<"step-start">;
    readonly index: Schema.Number;
}>, Schema.Struct<{
    readonly type: Schema.tag<"text-start">;
    readonly id: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"text-delta">;
    readonly id: Schema.String;
    readonly text: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"text-end">;
    readonly id: Schema.String;
    /** Authoritative complete value; replaces accumulated deltas when present. */
    readonly text: Schema.optional<Schema.String>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"reasoning-start">;
    readonly id: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"reasoning-delta">;
    readonly id: Schema.String;
    readonly text: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"reasoning-end">;
    readonly id: Schema.String;
    /** Authoritative complete value; replaces accumulated deltas when present. */
    readonly text: Schema.optional<Schema.String>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-input-start">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-input-delta">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly text: Schema.String;
    /** Best-effort parse of all input fragments received through this delta. */
    readonly input: Schema.optional<Schema.Unknown>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-input-end">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-input-error">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly raw: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-call">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly input: Schema.Unknown;
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-result">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly result: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"json">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"error">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"content">;
        readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
    }>]> & {
        is: <I>(input: I) => input is I & ({
            readonly type: "json";
            readonly value: unknown;
        } | {
            readonly type: "text";
            readonly value: unknown;
        } | {
            readonly type: "error";
            readonly value: unknown;
        } | {
            readonly type: "content";
            readonly value: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        });
        make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
    };
    readonly output: Schema.optional<Schema.Struct<{
        readonly structured: Schema.Unknown;
        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
    }> & {
        make: (structured: unknown, content?: ReadonlyArray<import("@opencode/schema/tool").Content>) => ToolOutput;
        fromResultValue: (result: ToolResultValue) => ToolOutput | undefined;
        toResultValue: (output: ToolOutput) => ToolResultValue;
    }>;
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"media">;
    readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"step-finish">;
    readonly index: Schema.Number;
    readonly reason: Schema.Struct<{
        readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly raw: Schema.optional<Schema.String>;
        /** The provider's policy area for a content-filter finish, such as `cyber`. */
        readonly category: Schema.optional<Schema.String>;
        /** The provider's human-readable reason for a content-filter finish. */
        readonly explanation: Schema.optional<Schema.String>;
    }>;
    readonly usage: Schema.optional<typeof Usage>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly reason: Schema.Struct<{
        readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly raw: Schema.optional<Schema.String>;
        /** The provider's policy area for a content-filter finish, such as `cyber`. */
        readonly category: Schema.optional<Schema.String>;
        /** The provider's human-readable reason for a content-filter finish. */
        readonly explanation: Schema.optional<Schema.String>;
    }>;
    readonly usage: Schema.optional<typeof Usage>;
    /** The final assistant message, set by `ai.stream` and `ai.loop`. */
    readonly message: Schema.optional<typeof AssistantMessage>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"raw">;
    readonly data: Schema.Unknown;
}>]>;
type WithID<Event extends {
    readonly id: unknown;
}, ID> = Omit<Event, "type" | "id"> & {
    readonly id: ID | string;
};
type WithUsage<Event extends {
    readonly usage?: Usage;
}> = Omit<Event, "type" | "usage"> & {
    readonly usage?: UsageInput;
};
/**
 * camelCase aliases for `LLMEvent.guards` (provided by `Schema.toTaggedUnion`).
 * Lets consumers write `events.filter(LLMEvent.is.toolCall)` instead of
 * `events.filter(LLMEvent.guards["tool-call"])`.
 */
export declare const LLMEvent: Schema.Union<readonly [Schema.refine<{
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
}), Schema.Struct<{
    readonly type: Schema.Literal<"compaction">;
    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
    readonly id: Schema.optional<Schema.String>;
    readonly encrypted: Schema.optional<Schema.String>;
    readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
}>> & {
    make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
        readonly encrypted: string;
        readonly text?: never;
    } | {
        readonly text: string | null;
        readonly encrypted?: never;
    })) => CompactionPart;
}, Schema.Struct<{
    readonly type: Schema.tag<"step-start">;
    readonly index: Schema.Number;
}>, Schema.Struct<{
    readonly type: Schema.tag<"text-start">;
    readonly id: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"text-delta">;
    readonly id: Schema.String;
    readonly text: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"text-end">;
    readonly id: Schema.String;
    /** Authoritative complete value; replaces accumulated deltas when present. */
    readonly text: Schema.optional<Schema.String>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"reasoning-start">;
    readonly id: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"reasoning-delta">;
    readonly id: Schema.String;
    readonly text: Schema.String;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"reasoning-end">;
    readonly id: Schema.String;
    /** Authoritative complete value; replaces accumulated deltas when present. */
    readonly text: Schema.optional<Schema.String>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-input-start">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-input-delta">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly text: Schema.String;
    /** Best-effort parse of all input fragments received through this delta. */
    readonly input: Schema.optional<Schema.Unknown>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-input-end">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-input-error">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly raw: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-call">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly input: Schema.Unknown;
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"tool-result">;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly namespace: Schema.optional<Schema.String>;
    readonly result: Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"json">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"text">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"error">;
        readonly value: Schema.Unknown;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"content">;
        readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
    }>]> & {
        is: <I>(input: I) => input is I & ({
            readonly type: "json";
            readonly value: unknown;
        } | {
            readonly type: "text";
            readonly value: unknown;
        } | {
            readonly type: "error";
            readonly value: unknown;
        } | {
            readonly type: "content";
            readonly value: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        });
        make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
    };
    readonly output: Schema.optional<Schema.Struct<{
        readonly structured: Schema.Unknown;
        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly uri: Schema.String;
            readonly mime: Schema.String;
            readonly name: Schema.optional<Schema.String>;
        }>]>>;
    }> & {
        make: (structured: unknown, content?: ReadonlyArray<import("@opencode/schema/tool").Content>) => ToolOutput;
        fromResultValue: (result: ToolResultValue) => ToolOutput | undefined;
        toResultValue: (output: ToolOutput) => ToolResultValue;
    }>;
    readonly providerExecuted: Schema.optional<Schema.Boolean>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"media">;
    readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"step-finish">;
    readonly index: Schema.Number;
    readonly reason: Schema.Struct<{
        readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly raw: Schema.optional<Schema.String>;
        /** The provider's policy area for a content-filter finish, such as `cyber`. */
        readonly category: Schema.optional<Schema.String>;
        /** The provider's human-readable reason for a content-filter finish. */
        readonly explanation: Schema.optional<Schema.String>;
    }>;
    readonly usage: Schema.optional<typeof Usage>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly reason: Schema.Struct<{
        readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly raw: Schema.optional<Schema.String>;
        /** The provider's policy area for a content-filter finish, such as `cyber`. */
        readonly category: Schema.optional<Schema.String>;
        /** The provider's human-readable reason for a content-filter finish. */
        readonly explanation: Schema.optional<Schema.String>;
    }>;
    readonly usage: Schema.optional<typeof Usage>;
    /** The final assistant message, set by `ai.stream` and `ai.loop`. */
    readonly message: Schema.optional<typeof AssistantMessage>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"raw">;
    readonly data: Schema.Unknown;
}>]> & {
    readonly tag: "type";
    readonly discriminants: readonly ["compaction", "step-start", "text-start", "text-delta", "text-end", "reasoning-start", "reasoning-delta", "reasoning-end", "tool-input-start", "tool-input-delta", "tool-input-end", "tool-input-error", "tool-call", "tool-result", "media", "step-finish", "finish", "raw"];
    readonly cases: {
        compaction: Schema.refine<{
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        }), Schema.Struct<{
            readonly type: Schema.Literal<"compaction">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.optional<Schema.String>;
            readonly encrypted: Schema.optional<Schema.String>;
            readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
        }>> & {
            make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            })) => CompactionPart;
        };
        finish: Schema.Struct<{
            readonly type: Schema.tag<"finish">;
            readonly reason: Schema.Struct<{
                readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                readonly raw: Schema.optional<Schema.String>;
                /** The provider's policy area for a content-filter finish, such as `cyber`. */
                readonly category: Schema.optional<Schema.String>;
                /** The provider's human-readable reason for a content-filter finish. */
                readonly explanation: Schema.optional<Schema.String>;
            }>;
            readonly usage: Schema.optional<typeof Usage>;
            /** The final assistant message, set by `ai.stream` and `ai.loop`. */
            readonly message: Schema.optional<typeof AssistantMessage>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        media: Schema.Struct<{
            readonly type: Schema.tag<"media">;
            readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"bytes">;
                    readonly data: Schema.Uint8Array;
                    readonly mediaType: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"base64">;
                    readonly data: Schema.String;
                    readonly mediaType: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"url">;
                    readonly url: Schema.String;
                    readonly mediaType: Schema.optional<Schema.String>;
                    readonly expiresAt: Schema.optional<Schema.Number>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"ref">;
                    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                    readonly id: Schema.String;
                    readonly mediaType: Schema.optional<Schema.String>;
                }>]>;
                readonly info: Schema.optional<Schema.Struct<{
                    readonly width: Schema.optional<Schema.Number>;
                    readonly height: Schema.optional<Schema.Number>;
                    readonly durationSeconds: Schema.optional<Schema.Number>;
                    readonly sampleRate: Schema.optional<Schema.Number>;
                    readonly channels: Schema.optional<Schema.Number>;
                    readonly encoding: Schema.optional<Schema.String>;
                    readonly format: Schema.optional<Schema.String>;
                }>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>, never, never>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        raw: Schema.Struct<{
            readonly type: Schema.tag<"raw">;
            readonly data: Schema.Unknown;
        }>;
        "reasoning-delta": Schema.Struct<{
            readonly type: Schema.tag<"reasoning-delta">;
            readonly id: Schema.String;
            readonly text: Schema.String;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "reasoning-end": Schema.Struct<{
            readonly type: Schema.tag<"reasoning-end">;
            readonly id: Schema.String;
            /** Authoritative complete value; replaces accumulated deltas when present. */
            readonly text: Schema.optional<Schema.String>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "reasoning-start": Schema.Struct<{
            readonly type: Schema.tag<"reasoning-start">;
            readonly id: Schema.String;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "step-finish": Schema.Struct<{
            readonly type: Schema.tag<"step-finish">;
            readonly index: Schema.Number;
            readonly reason: Schema.Struct<{
                readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                readonly raw: Schema.optional<Schema.String>;
                /** The provider's policy area for a content-filter finish, such as `cyber`. */
                readonly category: Schema.optional<Schema.String>;
                /** The provider's human-readable reason for a content-filter finish. */
                readonly explanation: Schema.optional<Schema.String>;
            }>;
            readonly usage: Schema.optional<typeof Usage>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "step-start": Schema.Struct<{
            readonly type: Schema.tag<"step-start">;
            readonly index: Schema.Number;
        }>;
        "text-delta": Schema.Struct<{
            readonly type: Schema.tag<"text-delta">;
            readonly id: Schema.String;
            readonly text: Schema.String;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "text-end": Schema.Struct<{
            readonly type: Schema.tag<"text-end">;
            readonly id: Schema.String;
            /** Authoritative complete value; replaces accumulated deltas when present. */
            readonly text: Schema.optional<Schema.String>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "text-start": Schema.Struct<{
            readonly type: Schema.tag<"text-start">;
            readonly id: Schema.String;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "tool-call": Schema.Struct<{
            readonly type: Schema.tag<"tool-call">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly namespace: Schema.optional<Schema.String>;
            readonly input: Schema.Unknown;
            readonly providerExecuted: Schema.optional<Schema.Boolean>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "tool-input-delta": Schema.Struct<{
            readonly type: Schema.tag<"tool-input-delta">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly namespace: Schema.optional<Schema.String>;
            readonly text: Schema.String;
            /** Best-effort parse of all input fragments received through this delta. */
            readonly input: Schema.optional<Schema.Unknown>;
        }>;
        "tool-input-end": Schema.Struct<{
            readonly type: Schema.tag<"tool-input-end">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly namespace: Schema.optional<Schema.String>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "tool-input-error": Schema.Struct<{
            readonly type: Schema.tag<"tool-input-error">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly namespace: Schema.optional<Schema.String>;
            readonly raw: Schema.String;
        }>;
        "tool-input-start": Schema.Struct<{
            readonly type: Schema.tag<"tool-input-start">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly namespace: Schema.optional<Schema.String>;
            readonly providerExecuted: Schema.optional<Schema.Boolean>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "tool-result": Schema.Struct<{
            readonly type: Schema.tag<"tool-result">;
            readonly id: Schema.String;
            readonly name: Schema.String;
            readonly namespace: Schema.optional<Schema.String>;
            readonly result: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"json">;
                readonly value: Schema.Unknown;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly value: Schema.Unknown;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"error">;
                readonly value: Schema.Unknown;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"content">;
                readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>;
            }>]> & {
                is: <I>(input: I) => input is I & ({
                    readonly type: "json";
                    readonly value: unknown;
                } | {
                    readonly type: "text";
                    readonly value: unknown;
                } | {
                    readonly type: "error";
                    readonly value: unknown;
                } | {
                    readonly type: "content";
                    readonly value: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                });
                make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
            };
            readonly output: Schema.optional<Schema.Struct<{
                readonly structured: Schema.Unknown;
                readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly text: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"file">;
                    readonly uri: Schema.String;
                    readonly mime: Schema.String;
                    readonly name: Schema.optional<Schema.String>;
                }>]>>;
            }> & {
                make: (structured: unknown, content?: ReadonlyArray<import("@opencode/schema/tool").Content>) => ToolOutput;
                fromResultValue: (result: ToolResultValue) => ToolOutput | undefined;
                toResultValue: (output: ToolOutput) => ToolResultValue;
            }>;
            readonly providerExecuted: Schema.optional<Schema.Boolean>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
    };
    readonly isAnyOf: <const Keys>(keys: readonly Keys[]) => (value: {
        readonly type: "step-start";
        readonly index: number;
    } | {
        readonly type: "raw";
        readonly data: unknown;
    } | {
        readonly type: "text-start";
        readonly id: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "text-delta";
        readonly id: string;
        readonly text: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "text-end";
        readonly id: string;
        readonly text?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "reasoning-start";
        readonly id: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "reasoning-delta";
        readonly id: string;
        readonly text: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "reasoning-end";
        readonly id: string;
        readonly text?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-input-start";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-input-delta";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly text: string;
        readonly input?: unknown;
    } | {
        readonly type: "tool-input-end";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-input-error";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly raw: string;
    } | {
        readonly type: "tool-call";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly input: unknown;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "tool-result";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly result: {
            readonly type: "json";
            readonly value: unknown;
        } | {
            readonly type: "text";
            readonly value: unknown;
        } | {
            readonly type: "error";
            readonly value: unknown;
        } | {
            readonly type: "content";
            readonly value: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        };
        readonly output?: {
            readonly structured: unknown;
            readonly content: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        } | undefined;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "step-finish";
        readonly index: number;
        readonly reason: {
            readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
            readonly raw?: string | undefined;
            readonly category?: string | undefined;
            readonly explanation?: string | undefined;
        };
        readonly usage?: Usage | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "finish";
        readonly reason: {
            readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
            readonly raw?: string | undefined;
            readonly category?: string | undefined;
            readonly explanation?: string | undefined;
        };
        readonly usage?: Usage | undefined;
        readonly message?: AssistantMessage | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | {
        readonly type: "media";
        readonly media: Media.Asset;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | ({
        readonly type: "compaction";
        readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
        readonly id?: string | undefined;
        readonly encrypted?: string | undefined;
        readonly text?: string | null | undefined;
    } & ({
        readonly encrypted: string;
        readonly text?: never;
    } | {
        readonly text: string | null;
        readonly encrypted?: never;
    }))) => value is Extract<{
        readonly type: "step-start";
        readonly index: number;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "raw";
        readonly data: unknown;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "text-start";
        readonly id: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "text-delta";
        readonly id: string;
        readonly text: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "text-end";
        readonly id: string;
        readonly text?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "reasoning-start";
        readonly id: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "reasoning-delta";
        readonly id: string;
        readonly text: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "reasoning-end";
        readonly id: string;
        readonly text?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "tool-input-start";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "tool-input-delta";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly text: string;
        readonly input?: unknown;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "tool-input-end";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "tool-input-error";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly raw: string;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "tool-call";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly input: unknown;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "tool-result";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly result: {
            readonly type: "json";
            readonly value: unknown;
        } | {
            readonly type: "text";
            readonly value: unknown;
        } | {
            readonly type: "error";
            readonly value: unknown;
        } | {
            readonly type: "content";
            readonly value: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        };
        readonly output?: {
            readonly structured: unknown;
            readonly content: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        } | undefined;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "step-finish";
        readonly index: number;
        readonly reason: {
            readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
            readonly raw?: string | undefined;
            readonly category?: string | undefined;
            readonly explanation?: string | undefined;
        };
        readonly usage?: Usage | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "finish";
        readonly reason: {
            readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
            readonly raw?: string | undefined;
            readonly category?: string | undefined;
            readonly explanation?: string | undefined;
        };
        readonly usage?: Usage | undefined;
        readonly message?: AssistantMessage | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "media";
        readonly media: Media.Asset;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "compaction";
        readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
        readonly id?: string | undefined;
        readonly encrypted?: string | undefined;
        readonly text?: string | null | undefined;
    } & {
        readonly encrypted: string;
        readonly text?: never;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "compaction";
        readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
        readonly id?: string | undefined;
        readonly encrypted?: string | undefined;
        readonly text?: string | null | undefined;
    } & {
        readonly text: string | null;
        readonly encrypted?: never;
    }, {
        readonly type: Keys;
    }>;
    readonly guards: {
        compaction: (u: unknown) => u is {
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        });
        finish: (u: unknown) => u is {
            readonly type: "finish";
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly message?: AssistantMessage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        media: (u: unknown) => u is {
            readonly type: "media";
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        raw: (u: unknown) => u is {
            readonly type: "raw";
            readonly data: unknown;
        };
        "reasoning-delta": (u: unknown) => u is {
            readonly type: "reasoning-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "reasoning-end": (u: unknown) => u is {
            readonly type: "reasoning-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "reasoning-start": (u: unknown) => u is {
            readonly type: "reasoning-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "step-finish": (u: unknown) => u is {
            readonly type: "step-finish";
            readonly index: number;
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "step-start": (u: unknown) => u is {
            readonly type: "step-start";
            readonly index: number;
        };
        "text-delta": (u: unknown) => u is {
            readonly type: "text-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "text-end": (u: unknown) => u is {
            readonly type: "text-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "text-start": (u: unknown) => u is {
            readonly type: "text-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "tool-call": (u: unknown) => u is {
            readonly type: "tool-call";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly input: unknown;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "tool-input-delta": (u: unknown) => u is {
            readonly type: "tool-input-delta";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly text: string;
            readonly input?: unknown;
        };
        "tool-input-end": (u: unknown) => u is {
            readonly type: "tool-input-end";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "tool-input-error": (u: unknown) => u is {
            readonly type: "tool-input-error";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly raw: string;
        };
        "tool-input-start": (u: unknown) => u is {
            readonly type: "tool-input-start";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "tool-result": (u: unknown) => u is {
            readonly type: "tool-result";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly result: {
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            };
            readonly output?: {
                readonly structured: unknown;
                readonly content: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            } | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
    };
    readonly match: {
        <Handlers extends { [K in "compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"]: (value: {
            readonly compaction: Schema.refine<{
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            }), Schema.Struct<{
                readonly type: Schema.Literal<"compaction">;
                readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                readonly id: Schema.optional<Schema.String>;
                readonly encrypted: Schema.optional<Schema.String>;
                readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
            }>> & {
                make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
                    readonly encrypted: string;
                    readonly text?: never;
                } | {
                    readonly text: string | null;
                    readonly encrypted?: never;
                })) => CompactionPart;
            };
            readonly finish: Schema.Struct<{
                readonly type: Schema.tag<"finish">;
                readonly reason: Schema.Struct<{
                    readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                    readonly raw: Schema.optional<Schema.String>;
                    /** The provider's policy area for a content-filter finish, such as `cyber`. */
                    readonly category: Schema.optional<Schema.String>;
                    /** The provider's human-readable reason for a content-filter finish. */
                    readonly explanation: Schema.optional<Schema.String>;
                }>;
                readonly usage: Schema.optional<typeof Usage>;
                /** The final assistant message, set by `ai.stream` and `ai.loop`. */
                readonly message: Schema.optional<typeof AssistantMessage>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly media: Schema.Struct<{
                readonly type: Schema.tag<"media">;
                readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"bytes">;
                        readonly data: Schema.Uint8Array;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"base64">;
                        readonly data: Schema.String;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"url">;
                        readonly url: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                        readonly expiresAt: Schema.optional<Schema.Number>;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"ref">;
                        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                        readonly id: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                    }>]>;
                    readonly info: Schema.optional<Schema.Struct<{
                        readonly width: Schema.optional<Schema.Number>;
                        readonly height: Schema.optional<Schema.Number>;
                        readonly durationSeconds: Schema.optional<Schema.Number>;
                        readonly sampleRate: Schema.optional<Schema.Number>;
                        readonly channels: Schema.optional<Schema.Number>;
                        readonly encoding: Schema.optional<Schema.String>;
                        readonly format: Schema.optional<Schema.String>;
                    }>>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>, never, never>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly raw: Schema.Struct<{
                readonly type: Schema.tag<"raw">;
                readonly data: Schema.Unknown;
            }>;
            readonly "reasoning-delta": Schema.Struct<{
                readonly type: Schema.tag<"reasoning-delta">;
                readonly id: Schema.String;
                readonly text: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "reasoning-end": Schema.Struct<{
                readonly type: Schema.tag<"reasoning-end">;
                readonly id: Schema.String;
                /** Authoritative complete value; replaces accumulated deltas when present. */
                readonly text: Schema.optional<Schema.String>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "reasoning-start": Schema.Struct<{
                readonly type: Schema.tag<"reasoning-start">;
                readonly id: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "step-finish": Schema.Struct<{
                readonly type: Schema.tag<"step-finish">;
                readonly index: Schema.Number;
                readonly reason: Schema.Struct<{
                    readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                    readonly raw: Schema.optional<Schema.String>;
                    /** The provider's policy area for a content-filter finish, such as `cyber`. */
                    readonly category: Schema.optional<Schema.String>;
                    /** The provider's human-readable reason for a content-filter finish. */
                    readonly explanation: Schema.optional<Schema.String>;
                }>;
                readonly usage: Schema.optional<typeof Usage>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "step-start": Schema.Struct<{
                readonly type: Schema.tag<"step-start">;
                readonly index: Schema.Number;
            }>;
            readonly "text-delta": Schema.Struct<{
                readonly type: Schema.tag<"text-delta">;
                readonly id: Schema.String;
                readonly text: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "text-end": Schema.Struct<{
                readonly type: Schema.tag<"text-end">;
                readonly id: Schema.String;
                /** Authoritative complete value; replaces accumulated deltas when present. */
                readonly text: Schema.optional<Schema.String>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "text-start": Schema.Struct<{
                readonly type: Schema.tag<"text-start">;
                readonly id: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "tool-call": Schema.Struct<{
                readonly type: Schema.tag<"tool-call">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly input: Schema.Unknown;
                readonly providerExecuted: Schema.optional<Schema.Boolean>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "tool-input-delta": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-delta">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly text: Schema.String;
                /** Best-effort parse of all input fragments received through this delta. */
                readonly input: Schema.optional<Schema.Unknown>;
            }>;
            readonly "tool-input-end": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-end">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "tool-input-error": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-error">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly raw: Schema.String;
            }>;
            readonly "tool-input-start": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-start">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly providerExecuted: Schema.optional<Schema.Boolean>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "tool-result": Schema.Struct<{
                readonly type: Schema.tag<"tool-result">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly result: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"json">;
                    readonly value: Schema.Unknown;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly value: Schema.Unknown;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"error">;
                    readonly value: Schema.Unknown;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"content">;
                    readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"text">;
                        readonly text: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"file">;
                        readonly uri: Schema.String;
                        readonly mime: Schema.String;
                        readonly name: Schema.optional<Schema.String>;
                    }>]>>;
                }>]> & {
                    is: <I>(input: I) => input is I & ({
                        readonly type: "json";
                        readonly value: unknown;
                    } | {
                        readonly type: "text";
                        readonly value: unknown;
                    } | {
                        readonly type: "error";
                        readonly value: unknown;
                    } | {
                        readonly type: "content";
                        readonly value: readonly ({
                            readonly type: "text";
                            readonly text: string;
                        } | {
                            readonly type: "file";
                            readonly uri: string;
                            readonly mime: string;
                            readonly name?: string | undefined;
                        })[];
                    });
                    make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
                };
                readonly output: Schema.optional<Schema.Struct<{
                    readonly structured: Schema.Unknown;
                    readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"text">;
                        readonly text: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"file">;
                        readonly uri: Schema.String;
                        readonly mime: Schema.String;
                        readonly name: Schema.optional<Schema.String>;
                    }>]>>;
                }> & {
                    make: (structured: unknown, content?: ReadonlyArray<import("@opencode/schema/tool").Content>) => ToolOutput;
                    fromResultValue: (result: ToolResultValue) => ToolOutput | undefined;
                    toResultValue: (output: ToolOutput) => ToolResultValue;
                }>;
                readonly providerExecuted: Schema.optional<Schema.Boolean>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
        }[K]["Type"]) => any; }>(value: {
            readonly type: "step-start";
            readonly index: number;
        } | {
            readonly type: "raw";
            readonly data: unknown;
        } | {
            readonly type: "text-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "text-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "text-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-start";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-delta";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly text: string;
            readonly input?: unknown;
        } | {
            readonly type: "tool-input-end";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-error";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly raw: string;
        } | {
            readonly type: "tool-call";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly input: unknown;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-result";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly result: {
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            };
            readonly output?: {
                readonly structured: unknown;
                readonly content: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            } | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "step-finish";
            readonly index: number;
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "finish";
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly message?: AssistantMessage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "media";
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | ({
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        })), cases: Handlers): import("effect/Unify").Unify<ReturnType<Handlers["compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"]>>;
        <Handlers extends { [K in "compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"]: (value: {
            readonly compaction: Schema.refine<{
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            }), Schema.Struct<{
                readonly type: Schema.Literal<"compaction">;
                readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                readonly id: Schema.optional<Schema.String>;
                readonly encrypted: Schema.optional<Schema.String>;
                readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
            }>> & {
                make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
                    readonly encrypted: string;
                    readonly text?: never;
                } | {
                    readonly text: string | null;
                    readonly encrypted?: never;
                })) => CompactionPart;
            };
            readonly finish: Schema.Struct<{
                readonly type: Schema.tag<"finish">;
                readonly reason: Schema.Struct<{
                    readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                    readonly raw: Schema.optional<Schema.String>;
                    /** The provider's policy area for a content-filter finish, such as `cyber`. */
                    readonly category: Schema.optional<Schema.String>;
                    /** The provider's human-readable reason for a content-filter finish. */
                    readonly explanation: Schema.optional<Schema.String>;
                }>;
                readonly usage: Schema.optional<typeof Usage>;
                /** The final assistant message, set by `ai.stream` and `ai.loop`. */
                readonly message: Schema.optional<typeof AssistantMessage>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly media: Schema.Struct<{
                readonly type: Schema.tag<"media">;
                readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"bytes">;
                        readonly data: Schema.Uint8Array;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"base64">;
                        readonly data: Schema.String;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"url">;
                        readonly url: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                        readonly expiresAt: Schema.optional<Schema.Number>;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"ref">;
                        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                        readonly id: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                    }>]>;
                    readonly info: Schema.optional<Schema.Struct<{
                        readonly width: Schema.optional<Schema.Number>;
                        readonly height: Schema.optional<Schema.Number>;
                        readonly durationSeconds: Schema.optional<Schema.Number>;
                        readonly sampleRate: Schema.optional<Schema.Number>;
                        readonly channels: Schema.optional<Schema.Number>;
                        readonly encoding: Schema.optional<Schema.String>;
                        readonly format: Schema.optional<Schema.String>;
                    }>>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>, never, never>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly raw: Schema.Struct<{
                readonly type: Schema.tag<"raw">;
                readonly data: Schema.Unknown;
            }>;
            readonly "reasoning-delta": Schema.Struct<{
                readonly type: Schema.tag<"reasoning-delta">;
                readonly id: Schema.String;
                readonly text: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "reasoning-end": Schema.Struct<{
                readonly type: Schema.tag<"reasoning-end">;
                readonly id: Schema.String;
                /** Authoritative complete value; replaces accumulated deltas when present. */
                readonly text: Schema.optional<Schema.String>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "reasoning-start": Schema.Struct<{
                readonly type: Schema.tag<"reasoning-start">;
                readonly id: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "step-finish": Schema.Struct<{
                readonly type: Schema.tag<"step-finish">;
                readonly index: Schema.Number;
                readonly reason: Schema.Struct<{
                    readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                    readonly raw: Schema.optional<Schema.String>;
                    /** The provider's policy area for a content-filter finish, such as `cyber`. */
                    readonly category: Schema.optional<Schema.String>;
                    /** The provider's human-readable reason for a content-filter finish. */
                    readonly explanation: Schema.optional<Schema.String>;
                }>;
                readonly usage: Schema.optional<typeof Usage>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "step-start": Schema.Struct<{
                readonly type: Schema.tag<"step-start">;
                readonly index: Schema.Number;
            }>;
            readonly "text-delta": Schema.Struct<{
                readonly type: Schema.tag<"text-delta">;
                readonly id: Schema.String;
                readonly text: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "text-end": Schema.Struct<{
                readonly type: Schema.tag<"text-end">;
                readonly id: Schema.String;
                /** Authoritative complete value; replaces accumulated deltas when present. */
                readonly text: Schema.optional<Schema.String>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "text-start": Schema.Struct<{
                readonly type: Schema.tag<"text-start">;
                readonly id: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "tool-call": Schema.Struct<{
                readonly type: Schema.tag<"tool-call">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly input: Schema.Unknown;
                readonly providerExecuted: Schema.optional<Schema.Boolean>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "tool-input-delta": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-delta">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly text: Schema.String;
                /** Best-effort parse of all input fragments received through this delta. */
                readonly input: Schema.optional<Schema.Unknown>;
            }>;
            readonly "tool-input-end": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-end">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "tool-input-error": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-error">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly raw: Schema.String;
            }>;
            readonly "tool-input-start": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-start">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly providerExecuted: Schema.optional<Schema.Boolean>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "tool-result": Schema.Struct<{
                readonly type: Schema.tag<"tool-result">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly result: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"json">;
                    readonly value: Schema.Unknown;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly value: Schema.Unknown;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"error">;
                    readonly value: Schema.Unknown;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"content">;
                    readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"text">;
                        readonly text: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"file">;
                        readonly uri: Schema.String;
                        readonly mime: Schema.String;
                        readonly name: Schema.optional<Schema.String>;
                    }>]>>;
                }>]> & {
                    is: <I>(input: I) => input is I & ({
                        readonly type: "json";
                        readonly value: unknown;
                    } | {
                        readonly type: "text";
                        readonly value: unknown;
                    } | {
                        readonly type: "error";
                        readonly value: unknown;
                    } | {
                        readonly type: "content";
                        readonly value: readonly ({
                            readonly type: "text";
                            readonly text: string;
                        } | {
                            readonly type: "file";
                            readonly uri: string;
                            readonly mime: string;
                            readonly name?: string | undefined;
                        })[];
                    });
                    make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
                };
                readonly output: Schema.optional<Schema.Struct<{
                    readonly structured: Schema.Unknown;
                    readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"text">;
                        readonly text: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"file">;
                        readonly uri: Schema.String;
                        readonly mime: Schema.String;
                        readonly name: Schema.optional<Schema.String>;
                    }>]>>;
                }> & {
                    make: (structured: unknown, content?: ReadonlyArray<import("@opencode/schema/tool").Content>) => ToolOutput;
                    fromResultValue: (result: ToolResultValue) => ToolOutput | undefined;
                    toResultValue: (output: ToolOutput) => ToolResultValue;
                }>;
                readonly providerExecuted: Schema.optional<Schema.Boolean>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
        }[K]["Type"]) => any; }>(cases: Handlers): (value: {
            readonly type: "step-start";
            readonly index: number;
        } | {
            readonly type: "raw";
            readonly data: unknown;
        } | {
            readonly type: "text-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "text-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "text-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-start";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-delta";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly text: string;
            readonly input?: unknown;
        } | {
            readonly type: "tool-input-end";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-error";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly raw: string;
        } | {
            readonly type: "tool-call";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly input: unknown;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-result";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly result: {
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            };
            readonly output?: {
                readonly structured: unknown;
                readonly content: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            } | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "step-finish";
            readonly index: number;
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "finish";
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly message?: AssistantMessage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "media";
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | ({
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        }))) => import("effect/Unify").Unify<ReturnType<Handlers["compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"]>>;
    };
    readonly matchOrElse: {
        <Handlers, OrElse>(value: {
            readonly type: "step-start";
            readonly index: number;
        } | {
            readonly type: "raw";
            readonly data: unknown;
        } | {
            readonly type: "text-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "text-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "text-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-start";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-delta";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly text: string;
            readonly input?: unknown;
        } | {
            readonly type: "tool-input-end";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-error";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly raw: string;
        } | {
            readonly type: "tool-call";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly input: unknown;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-result";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly result: {
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            };
            readonly output?: {
                readonly structured: unknown;
                readonly content: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            } | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "step-finish";
            readonly index: number;
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "finish";
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly message?: AssistantMessage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "media";
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | ({
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        })), cases: Handlers & {
            readonly compaction?: ((value: {
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            })) => any) | undefined;
            readonly finish?: ((value: {
                readonly type: "finish";
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly message?: AssistantMessage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly media?: ((value: {
                readonly type: "media";
                readonly media: Media.Asset;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly raw?: ((value: {
                readonly type: "raw";
                readonly data: unknown;
            }) => any) | undefined;
            readonly "reasoning-delta"?: ((value: {
                readonly type: "reasoning-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "reasoning-end"?: ((value: {
                readonly type: "reasoning-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "reasoning-start"?: ((value: {
                readonly type: "reasoning-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "step-finish"?: ((value: {
                readonly type: "step-finish";
                readonly index: number;
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "step-start"?: ((value: {
                readonly type: "step-start";
                readonly index: number;
            }) => any) | undefined;
            readonly "text-delta"?: ((value: {
                readonly type: "text-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "text-end"?: ((value: {
                readonly type: "text-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "text-start"?: ((value: {
                readonly type: "text-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "tool-call"?: ((value: {
                readonly type: "tool-call";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly input: unknown;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "tool-input-delta"?: ((value: {
                readonly type: "tool-input-delta";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly text: string;
                readonly input?: unknown;
            }) => any) | undefined;
            readonly "tool-input-end"?: ((value: {
                readonly type: "tool-input-end";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "tool-input-error"?: ((value: {
                readonly type: "tool-input-error";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly raw: string;
            }) => any) | undefined;
            readonly "tool-input-start"?: ((value: {
                readonly type: "tool-input-start";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "tool-result"?: ((value: {
                readonly type: "tool-result";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly result: {
                    readonly type: "json";
                    readonly value: unknown;
                } | {
                    readonly type: "text";
                    readonly value: unknown;
                } | {
                    readonly type: "error";
                    readonly value: unknown;
                } | {
                    readonly type: "content";
                    readonly value: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                };
                readonly output?: {
                    readonly structured: unknown;
                    readonly content: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                } | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
        } & (Exclude<keyof Handlers, "compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
            readonly type: "step-start";
            readonly index: number;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "raw";
            readonly data: unknown;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "text-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "text-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "text-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "reasoning-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "reasoning-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "reasoning-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-input-start";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-input-delta";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly text: string;
            readonly input?: unknown;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-input-end";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-input-error";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly raw: string;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-call";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly input: unknown;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-result";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly result: {
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            };
            readonly output?: {
                readonly structured: unknown;
                readonly content: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            } | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "step-finish";
            readonly index: number;
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "finish";
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly message?: AssistantMessage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "media";
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & {
            readonly encrypted: string;
            readonly text?: never;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & {
            readonly text: string | null;
            readonly encrypted?: never;
        }, {
            readonly type: keyof Handlers;
        }>) => any)): import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
        <Handlers, OrElse>(cases: Handlers & {
            readonly compaction?: ((value: {
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            })) => any) | undefined;
            readonly finish?: ((value: {
                readonly type: "finish";
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly message?: AssistantMessage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly media?: ((value: {
                readonly type: "media";
                readonly media: Media.Asset;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly raw?: ((value: {
                readonly type: "raw";
                readonly data: unknown;
            }) => any) | undefined;
            readonly "reasoning-delta"?: ((value: {
                readonly type: "reasoning-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "reasoning-end"?: ((value: {
                readonly type: "reasoning-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "reasoning-start"?: ((value: {
                readonly type: "reasoning-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "step-finish"?: ((value: {
                readonly type: "step-finish";
                readonly index: number;
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "step-start"?: ((value: {
                readonly type: "step-start";
                readonly index: number;
            }) => any) | undefined;
            readonly "text-delta"?: ((value: {
                readonly type: "text-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "text-end"?: ((value: {
                readonly type: "text-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "text-start"?: ((value: {
                readonly type: "text-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "tool-call"?: ((value: {
                readonly type: "tool-call";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly input: unknown;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "tool-input-delta"?: ((value: {
                readonly type: "tool-input-delta";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly text: string;
                readonly input?: unknown;
            }) => any) | undefined;
            readonly "tool-input-end"?: ((value: {
                readonly type: "tool-input-end";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "tool-input-error"?: ((value: {
                readonly type: "tool-input-error";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly raw: string;
            }) => any) | undefined;
            readonly "tool-input-start"?: ((value: {
                readonly type: "tool-input-start";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "tool-result"?: ((value: {
                readonly type: "tool-result";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly result: {
                    readonly type: "json";
                    readonly value: unknown;
                } | {
                    readonly type: "text";
                    readonly value: unknown;
                } | {
                    readonly type: "error";
                    readonly value: unknown;
                } | {
                    readonly type: "content";
                    readonly value: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                };
                readonly output?: {
                    readonly structured: unknown;
                    readonly content: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                } | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
        } & (Exclude<keyof Handlers, "compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
            readonly type: "step-start";
            readonly index: number;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "raw";
            readonly data: unknown;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "text-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "text-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "text-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "reasoning-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "reasoning-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "reasoning-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-input-start";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-input-delta";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly text: string;
            readonly input?: unknown;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-input-end";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-input-error";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly raw: string;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-call";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly input: unknown;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "tool-result";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly result: {
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            };
            readonly output?: {
                readonly structured: unknown;
                readonly content: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            } | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "step-finish";
            readonly index: number;
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "finish";
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly message?: AssistantMessage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "media";
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & {
            readonly encrypted: string;
            readonly text?: never;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & {
            readonly text: string | null;
            readonly encrypted?: never;
        }, {
            readonly type: keyof Handlers;
        }>) => any)): (value: {
            readonly type: "step-start";
            readonly index: number;
        } | {
            readonly type: "raw";
            readonly data: unknown;
        } | {
            readonly type: "text-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "text-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "text-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-start";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-delta";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly text: string;
            readonly input?: unknown;
        } | {
            readonly type: "tool-input-end";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-error";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly raw: string;
        } | {
            readonly type: "tool-call";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly input: unknown;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-result";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly result: {
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            };
            readonly output?: {
                readonly structured: unknown;
                readonly content: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            } | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "step-finish";
            readonly index: number;
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "finish";
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly message?: AssistantMessage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "media";
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | ({
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        }))) => import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
    };
} & {
    compaction: ((input: {
        readonly type: "compaction";
        readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
        readonly id?: string | undefined;
        readonly encrypted?: string | undefined;
        readonly text?: string | null | undefined;
    }, options?: Schema.MakeOptions) => {
        readonly type: "compaction";
        readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
        readonly id?: string | undefined;
        readonly encrypted?: string | undefined;
        readonly text?: string | null | undefined;
    } & ({
        readonly encrypted: string;
        readonly text?: never;
    } | {
        readonly text: string | null;
        readonly encrypted?: never;
    })) & ((input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
        readonly encrypted: string;
        readonly text?: never;
    } | {
        readonly text: string | null;
        readonly encrypted?: never;
    })) => CompactionPart);
    stepStart: (input: {
        readonly type?: "step-start" | undefined;
        readonly index: number;
    }, options?: Schema.MakeOptions) => {
        readonly type: "step-start";
        readonly index: number;
    };
    textStart: (input: WithID<TextStart, ContentBlockID>) => {
        readonly type: "text-start";
        readonly id: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    textDelta: (input: WithID<TextDelta, ContentBlockID>) => {
        readonly type: "text-delta";
        readonly id: string;
        readonly text: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    textEnd: (input: WithID<TextEnd, ContentBlockID>) => {
        readonly type: "text-end";
        readonly id: string;
        readonly text?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    reasoningStart: (input: WithID<ReasoningStart, ContentBlockID>) => {
        readonly type: "reasoning-start";
        readonly id: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    reasoningDelta: (input: WithID<ReasoningDelta, ContentBlockID>) => {
        readonly type: "reasoning-delta";
        readonly id: string;
        readonly text: string;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    reasoningEnd: (input: WithID<ReasoningEnd, ContentBlockID>) => {
        readonly type: "reasoning-end";
        readonly id: string;
        readonly text?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    toolInputStart: (input: WithID<ToolInputStart, ToolCallID>) => {
        readonly type: "tool-input-start";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    toolInputDelta: (input: WithID<ToolInputDelta, ToolCallID>) => {
        readonly type: "tool-input-delta";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly text: string;
        readonly input?: unknown;
    };
    toolInputEnd: (input: WithID<ToolInputEnd, ToolCallID>) => {
        readonly type: "tool-input-end";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    toolInputError: (input: WithID<ToolInputError, ToolCallID>) => {
        readonly type: "tool-input-error";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly raw: string;
    };
    toolCall: (input: WithID<ToolCall, ToolCallID>) => {
        readonly type: "tool-call";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly input: unknown;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    toolResult: (input: WithID<ToolResult, ToolCallID>) => {
        readonly type: "tool-result";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly result: {
            readonly type: "json";
            readonly value: unknown;
        } | {
            readonly type: "text";
            readonly value: unknown;
        } | {
            readonly type: "error";
            readonly value: unknown;
        } | {
            readonly type: "content";
            readonly value: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        };
        readonly output?: {
            readonly structured: unknown;
            readonly content: readonly ({
                readonly type: "text";
                readonly text: string;
            } | {
                readonly type: "file";
                readonly uri: string;
                readonly mime: string;
                readonly name?: string | undefined;
            })[];
        } | undefined;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    media: (input: {
        readonly type?: "media" | undefined;
        readonly media: Media.Asset;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, options?: Schema.MakeOptions) => {
        readonly type: "media";
        readonly media: Media.Asset;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    stepFinish: (input: WithUsage<StepFinish>) => {
        readonly type: "step-finish";
        readonly index: number;
        readonly reason: {
            readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
            readonly raw?: string | undefined;
            readonly category?: string | undefined;
            readonly explanation?: string | undefined;
        };
        readonly usage?: Usage | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    finish: (input: WithUsage<Finish>) => {
        readonly type: "finish";
        readonly reason: {
            readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
            readonly raw?: string | undefined;
            readonly category?: string | undefined;
            readonly explanation?: string | undefined;
        };
        readonly usage?: Usage | undefined;
        readonly message?: AssistantMessage | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    };
    raw: (input: {
        readonly type?: "raw" | undefined;
        readonly data: unknown;
    }, options?: Schema.MakeOptions) => {
        readonly type: "raw";
        readonly data: unknown;
    };
    is: {
        compaction: (u: unknown) => u is {
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        });
        stepStart: (u: unknown) => u is {
            readonly type: "step-start";
            readonly index: number;
        };
        textStart: (u: unknown) => u is {
            readonly type: "text-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        textDelta: (u: unknown) => u is {
            readonly type: "text-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        textEnd: (u: unknown) => u is {
            readonly type: "text-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        reasoningStart: (u: unknown) => u is {
            readonly type: "reasoning-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        reasoningDelta: (u: unknown) => u is {
            readonly type: "reasoning-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        reasoningEnd: (u: unknown) => u is {
            readonly type: "reasoning-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        toolInputStart: (u: unknown) => u is {
            readonly type: "tool-input-start";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        toolInputDelta: (u: unknown) => u is {
            readonly type: "tool-input-delta";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly text: string;
            readonly input?: unknown;
        };
        toolInputEnd: (u: unknown) => u is {
            readonly type: "tool-input-end";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        toolInputError: (u: unknown) => u is {
            readonly type: "tool-input-error";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly raw: string;
        };
        toolCall: (u: unknown) => u is {
            readonly type: "tool-call";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly input: unknown;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        toolResult: (u: unknown) => u is {
            readonly type: "tool-result";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly result: {
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            };
            readonly output?: {
                readonly structured: unknown;
                readonly content: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            } | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        media: (u: unknown) => u is {
            readonly type: "media";
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        stepFinish: (u: unknown) => u is {
            readonly type: "step-finish";
            readonly index: number;
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        finish: (u: unknown) => u is {
            readonly type: "finish";
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly message?: AssistantMessage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        raw: (u: unknown) => u is {
            readonly type: "raw";
            readonly data: unknown;
        };
    };
};
export type LLMEvent = Schema.Schema.Type<typeof llmEventTagged>;
interface ContentAssembly {
    readonly contentIndex: number;
    readonly text: string;
    readonly providerMetadata?: ProviderMetadata;
}
interface ToolInputAssembly {
    readonly name: string;
    readonly namespace?: string;
    readonly text: string;
    readonly providerMetadata?: ProviderMetadata;
}
interface ResponseState {
    readonly events: LLMEvent[];
    readonly message: AssistantMessage;
    readonly usage?: Usage;
    readonly finishReason?: FinishReasonDetails;
    readonly textParts: Readonly<Record<string, ContentAssembly>>;
    readonly reasoningParts: Readonly<Record<string, ContentAssembly>>;
    readonly toolInputs: Readonly<Record<string, ToolInputAssembly>>;
}
declare const emptyResponseState: () => ResponseState;
declare const reduceResponseState: (state: ResponseState, event: LLMEvent) => ResponseState;
declare const LLMResponse_base: Schema.Class<LLMResponse, Schema.Struct<{
    readonly message: typeof AssistantMessage;
    readonly events: Schema.$Array<Schema.Union<readonly [Schema.refine<{
        readonly type: "compaction";
        readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
        readonly id?: string | undefined;
        readonly encrypted?: string | undefined;
        readonly text?: string | null | undefined;
    } & ({
        readonly encrypted: string;
        readonly text?: never;
    } | {
        readonly text: string | null;
        readonly encrypted?: never;
    }), Schema.Struct<{
        readonly type: Schema.Literal<"compaction">;
        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
        readonly id: Schema.optional<Schema.String>;
        readonly encrypted: Schema.optional<Schema.String>;
        readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
    }>> & {
        make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        })) => CompactionPart;
    }, Schema.Struct<{
        readonly type: Schema.tag<"step-start">;
        readonly index: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"text-start">;
        readonly id: Schema.String;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"text-delta">;
        readonly id: Schema.String;
        readonly text: Schema.String;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"text-end">;
        readonly id: Schema.String;
        /** Authoritative complete value; replaces accumulated deltas when present. */
        readonly text: Schema.optional<Schema.String>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"reasoning-start">;
        readonly id: Schema.String;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"reasoning-delta">;
        readonly id: Schema.String;
        readonly text: Schema.String;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"reasoning-end">;
        readonly id: Schema.String;
        /** Authoritative complete value; replaces accumulated deltas when present. */
        readonly text: Schema.optional<Schema.String>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"tool-input-start">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly providerExecuted: Schema.optional<Schema.Boolean>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"tool-input-delta">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly text: Schema.String;
        /** Best-effort parse of all input fragments received through this delta. */
        readonly input: Schema.optional<Schema.Unknown>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"tool-input-end">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"tool-input-error">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly raw: Schema.String;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"tool-call">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly input: Schema.Unknown;
        readonly providerExecuted: Schema.optional<Schema.Boolean>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"tool-result">;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly namespace: Schema.optional<Schema.String>;
        readonly result: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"json">;
            readonly value: Schema.Unknown;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly value: Schema.Unknown;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"error">;
            readonly value: Schema.Unknown;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"content">;
            readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>;
        }>]> & {
            is: <I>(input: I) => input is I & ({
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            });
            make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
        };
        readonly output: Schema.optional<Schema.Struct<{
            readonly structured: Schema.Unknown;
            readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"text">;
                readonly text: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"file">;
                readonly uri: Schema.String;
                readonly mime: Schema.String;
                readonly name: Schema.optional<Schema.String>;
            }>]>>;
        }> & {
            make: (structured: unknown, content?: ReadonlyArray<import("@opencode/schema/tool").Content>) => ToolOutput;
            fromResultValue: (result: ToolResultValue) => ToolOutput | undefined;
            toResultValue: (output: ToolOutput) => ToolResultValue;
        }>;
        readonly providerExecuted: Schema.optional<Schema.Boolean>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"media">;
        readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
            readonly source: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"bytes">;
                readonly data: Schema.Uint8Array;
                readonly mediaType: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"base64">;
                readonly data: Schema.String;
                readonly mediaType: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"url">;
                readonly url: Schema.String;
                readonly mediaType: Schema.optional<Schema.String>;
                readonly expiresAt: Schema.optional<Schema.Number>;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"ref">;
                readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                readonly id: Schema.String;
                readonly mediaType: Schema.optional<Schema.String>;
            }>]>;
            readonly info: Schema.optional<Schema.Struct<{
                readonly width: Schema.optional<Schema.Number>;
                readonly height: Schema.optional<Schema.Number>;
                readonly durationSeconds: Schema.optional<Schema.Number>;
                readonly sampleRate: Schema.optional<Schema.Number>;
                readonly channels: Schema.optional<Schema.Number>;
                readonly encoding: Schema.optional<Schema.String>;
                readonly format: Schema.optional<Schema.String>;
            }>>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>, never, never>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"step-finish">;
        readonly index: Schema.Number;
        readonly reason: Schema.Struct<{
            readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
            readonly raw: Schema.optional<Schema.String>;
            /** The provider's policy area for a content-filter finish, such as `cyber`. */
            readonly category: Schema.optional<Schema.String>;
            /** The provider's human-readable reason for a content-filter finish. */
            readonly explanation: Schema.optional<Schema.String>;
        }>;
        readonly usage: Schema.optional<typeof Usage>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"finish">;
        readonly reason: Schema.Struct<{
            readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
            readonly raw: Schema.optional<Schema.String>;
            /** The provider's policy area for a content-filter finish, such as `cyber`. */
            readonly category: Schema.optional<Schema.String>;
            /** The provider's human-readable reason for a content-filter finish. */
            readonly explanation: Schema.optional<Schema.String>;
        }>;
        readonly usage: Schema.optional<typeof Usage>;
        /** The final assistant message, set by `ai.stream` and `ai.loop`. */
        readonly message: Schema.optional<typeof AssistantMessage>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"raw">;
        readonly data: Schema.Unknown;
    }>]> & {
        readonly tag: "type";
        readonly discriminants: readonly ["compaction", "step-start", "text-start", "text-delta", "text-end", "reasoning-start", "reasoning-delta", "reasoning-end", "tool-input-start", "tool-input-delta", "tool-input-end", "tool-input-error", "tool-call", "tool-result", "media", "step-finish", "finish", "raw"];
        readonly cases: {
            compaction: Schema.refine<{
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            }), Schema.Struct<{
                readonly type: Schema.Literal<"compaction">;
                readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                readonly id: Schema.optional<Schema.String>;
                readonly encrypted: Schema.optional<Schema.String>;
                readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
            }>> & {
                make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
                    readonly encrypted: string;
                    readonly text?: never;
                } | {
                    readonly text: string | null;
                    readonly encrypted?: never;
                })) => CompactionPart;
            };
            finish: Schema.Struct<{
                readonly type: Schema.tag<"finish">;
                readonly reason: Schema.Struct<{
                    readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                    readonly raw: Schema.optional<Schema.String>;
                    /** The provider's policy area for a content-filter finish, such as `cyber`. */
                    readonly category: Schema.optional<Schema.String>;
                    /** The provider's human-readable reason for a content-filter finish. */
                    readonly explanation: Schema.optional<Schema.String>;
                }>;
                readonly usage: Schema.optional<typeof Usage>;
                /** The final assistant message, set by `ai.stream` and `ai.loop`. */
                readonly message: Schema.optional<typeof AssistantMessage>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            media: Schema.Struct<{
                readonly type: Schema.tag<"media">;
                readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"bytes">;
                        readonly data: Schema.Uint8Array;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"base64">;
                        readonly data: Schema.String;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"url">;
                        readonly url: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                        readonly expiresAt: Schema.optional<Schema.Number>;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"ref">;
                        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                        readonly id: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                    }>]>;
                    readonly info: Schema.optional<Schema.Struct<{
                        readonly width: Schema.optional<Schema.Number>;
                        readonly height: Schema.optional<Schema.Number>;
                        readonly durationSeconds: Schema.optional<Schema.Number>;
                        readonly sampleRate: Schema.optional<Schema.Number>;
                        readonly channels: Schema.optional<Schema.Number>;
                        readonly encoding: Schema.optional<Schema.String>;
                        readonly format: Schema.optional<Schema.String>;
                    }>>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>, never, never>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            raw: Schema.Struct<{
                readonly type: Schema.tag<"raw">;
                readonly data: Schema.Unknown;
            }>;
            "reasoning-delta": Schema.Struct<{
                readonly type: Schema.tag<"reasoning-delta">;
                readonly id: Schema.String;
                readonly text: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            "reasoning-end": Schema.Struct<{
                readonly type: Schema.tag<"reasoning-end">;
                readonly id: Schema.String;
                /** Authoritative complete value; replaces accumulated deltas when present. */
                readonly text: Schema.optional<Schema.String>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            "reasoning-start": Schema.Struct<{
                readonly type: Schema.tag<"reasoning-start">;
                readonly id: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            "step-finish": Schema.Struct<{
                readonly type: Schema.tag<"step-finish">;
                readonly index: Schema.Number;
                readonly reason: Schema.Struct<{
                    readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                    readonly raw: Schema.optional<Schema.String>;
                    /** The provider's policy area for a content-filter finish, such as `cyber`. */
                    readonly category: Schema.optional<Schema.String>;
                    /** The provider's human-readable reason for a content-filter finish. */
                    readonly explanation: Schema.optional<Schema.String>;
                }>;
                readonly usage: Schema.optional<typeof Usage>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            "step-start": Schema.Struct<{
                readonly type: Schema.tag<"step-start">;
                readonly index: Schema.Number;
            }>;
            "text-delta": Schema.Struct<{
                readonly type: Schema.tag<"text-delta">;
                readonly id: Schema.String;
                readonly text: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            "text-end": Schema.Struct<{
                readonly type: Schema.tag<"text-end">;
                readonly id: Schema.String;
                /** Authoritative complete value; replaces accumulated deltas when present. */
                readonly text: Schema.optional<Schema.String>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            "text-start": Schema.Struct<{
                readonly type: Schema.tag<"text-start">;
                readonly id: Schema.String;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            "tool-call": Schema.Struct<{
                readonly type: Schema.tag<"tool-call">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly input: Schema.Unknown;
                readonly providerExecuted: Schema.optional<Schema.Boolean>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            "tool-input-delta": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-delta">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly text: Schema.String;
                /** Best-effort parse of all input fragments received through this delta. */
                readonly input: Schema.optional<Schema.Unknown>;
            }>;
            "tool-input-end": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-end">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            "tool-input-error": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-error">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly raw: Schema.String;
            }>;
            "tool-input-start": Schema.Struct<{
                readonly type: Schema.tag<"tool-input-start">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly providerExecuted: Schema.optional<Schema.Boolean>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            "tool-result": Schema.Struct<{
                readonly type: Schema.tag<"tool-result">;
                readonly id: Schema.String;
                readonly name: Schema.String;
                readonly namespace: Schema.optional<Schema.String>;
                readonly result: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"json">;
                    readonly value: Schema.Unknown;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"text">;
                    readonly value: Schema.Unknown;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"error">;
                    readonly value: Schema.Unknown;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"content">;
                    readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"text">;
                        readonly text: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"file">;
                        readonly uri: Schema.String;
                        readonly mime: Schema.String;
                        readonly name: Schema.optional<Schema.String>;
                    }>]>>;
                }>]> & {
                    is: <I>(input: I) => input is I & ({
                        readonly type: "json";
                        readonly value: unknown;
                    } | {
                        readonly type: "text";
                        readonly value: unknown;
                    } | {
                        readonly type: "error";
                        readonly value: unknown;
                    } | {
                        readonly type: "content";
                        readonly value: readonly ({
                            readonly type: "text";
                            readonly text: string;
                        } | {
                            readonly type: "file";
                            readonly uri: string;
                            readonly mime: string;
                            readonly name?: string | undefined;
                        })[];
                    });
                    make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
                };
                readonly output: Schema.optional<Schema.Struct<{
                    readonly structured: Schema.Unknown;
                    readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"text">;
                        readonly text: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"file">;
                        readonly uri: Schema.String;
                        readonly mime: Schema.String;
                        readonly name: Schema.optional<Schema.String>;
                    }>]>>;
                }> & {
                    make: (structured: unknown, content?: ReadonlyArray<import("@opencode/schema/tool").Content>) => ToolOutput;
                    fromResultValue: (result: ToolResultValue) => ToolOutput | undefined;
                    toResultValue: (output: ToolOutput) => ToolResultValue;
                }>;
                readonly providerExecuted: Schema.optional<Schema.Boolean>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
        };
        readonly isAnyOf: <const Keys>(keys: readonly Keys[]) => (value: {
            readonly type: "step-start";
            readonly index: number;
        } | {
            readonly type: "raw";
            readonly data: unknown;
        } | {
            readonly type: "text-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "text-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "text-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "reasoning-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-start";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-delta";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly text: string;
            readonly input?: unknown;
        } | {
            readonly type: "tool-input-end";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-input-error";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly raw: string;
        } | {
            readonly type: "tool-call";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly input: unknown;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "tool-result";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly result: {
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            };
            readonly output?: {
                readonly structured: unknown;
                readonly content: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            } | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "step-finish";
            readonly index: number;
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "finish";
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly message?: AssistantMessage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | {
            readonly type: "media";
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        } | ({
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        }))) => value is Extract<{
            readonly type: "step-start";
            readonly index: number;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "raw";
            readonly data: unknown;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "text-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "text-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "text-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "reasoning-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "reasoning-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "reasoning-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "tool-input-start";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "tool-input-delta";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly text: string;
            readonly input?: unknown;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "tool-input-end";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "tool-input-error";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly raw: string;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "tool-call";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly input: unknown;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "tool-result";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly result: {
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            };
            readonly output?: {
                readonly structured: unknown;
                readonly content: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            } | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "step-finish";
            readonly index: number;
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "finish";
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly message?: AssistantMessage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "media";
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & {
            readonly encrypted: string;
            readonly text?: never;
        }, {
            readonly type: Keys;
        }> | Extract<{
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & {
            readonly text: string | null;
            readonly encrypted?: never;
        }, {
            readonly type: Keys;
        }>;
        readonly guards: {
            compaction: (u: unknown) => u is {
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            });
            finish: (u: unknown) => u is {
                readonly type: "finish";
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly message?: AssistantMessage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            media: (u: unknown) => u is {
                readonly type: "media";
                readonly media: Media.Asset;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            raw: (u: unknown) => u is {
                readonly type: "raw";
                readonly data: unknown;
            };
            "reasoning-delta": (u: unknown) => u is {
                readonly type: "reasoning-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            "reasoning-end": (u: unknown) => u is {
                readonly type: "reasoning-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            "reasoning-start": (u: unknown) => u is {
                readonly type: "reasoning-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            "step-finish": (u: unknown) => u is {
                readonly type: "step-finish";
                readonly index: number;
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            "step-start": (u: unknown) => u is {
                readonly type: "step-start";
                readonly index: number;
            };
            "text-delta": (u: unknown) => u is {
                readonly type: "text-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            "text-end": (u: unknown) => u is {
                readonly type: "text-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            "text-start": (u: unknown) => u is {
                readonly type: "text-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            "tool-call": (u: unknown) => u is {
                readonly type: "tool-call";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly input: unknown;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            "tool-input-delta": (u: unknown) => u is {
                readonly type: "tool-input-delta";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly text: string;
                readonly input?: unknown;
            };
            "tool-input-end": (u: unknown) => u is {
                readonly type: "tool-input-end";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            "tool-input-error": (u: unknown) => u is {
                readonly type: "tool-input-error";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly raw: string;
            };
            "tool-input-start": (u: unknown) => u is {
                readonly type: "tool-input-start";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            "tool-result": (u: unknown) => u is {
                readonly type: "tool-result";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly result: {
                    readonly type: "json";
                    readonly value: unknown;
                } | {
                    readonly type: "text";
                    readonly value: unknown;
                } | {
                    readonly type: "error";
                    readonly value: unknown;
                } | {
                    readonly type: "content";
                    readonly value: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                };
                readonly output?: {
                    readonly structured: unknown;
                    readonly content: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                } | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
        };
        readonly match: {
            <Handlers extends { [K in "compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"]: (value: {
                readonly compaction: Schema.refine<{
                    readonly type: "compaction";
                    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                    readonly id?: string | undefined;
                    readonly encrypted?: string | undefined;
                    readonly text?: string | null | undefined;
                } & ({
                    readonly encrypted: string;
                    readonly text?: never;
                } | {
                    readonly text: string | null;
                    readonly encrypted?: never;
                }), Schema.Struct<{
                    readonly type: Schema.Literal<"compaction">;
                    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                    readonly id: Schema.optional<Schema.String>;
                    readonly encrypted: Schema.optional<Schema.String>;
                    readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
                }>> & {
                    make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
                        readonly encrypted: string;
                        readonly text?: never;
                    } | {
                        readonly text: string | null;
                        readonly encrypted?: never;
                    })) => CompactionPart;
                };
                readonly finish: Schema.Struct<{
                    readonly type: Schema.tag<"finish">;
                    readonly reason: Schema.Struct<{
                        readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                        readonly raw: Schema.optional<Schema.String>;
                        /** The provider's policy area for a content-filter finish, such as `cyber`. */
                        readonly category: Schema.optional<Schema.String>;
                        /** The provider's human-readable reason for a content-filter finish. */
                        readonly explanation: Schema.optional<Schema.String>;
                    }>;
                    readonly usage: Schema.optional<typeof Usage>;
                    /** The final assistant message, set by `ai.stream` and `ai.loop`. */
                    readonly message: Schema.optional<typeof AssistantMessage>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly media: Schema.Struct<{
                    readonly type: Schema.tag<"media">;
                    readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                        readonly source: Schema.Union<readonly [Schema.Struct<{
                            readonly type: Schema.Literal<"bytes">;
                            readonly data: Schema.Uint8Array;
                            readonly mediaType: Schema.String;
                        }>, Schema.Struct<{
                            readonly type: Schema.Literal<"base64">;
                            readonly data: Schema.String;
                            readonly mediaType: Schema.String;
                        }>, Schema.Struct<{
                            readonly type: Schema.Literal<"url">;
                            readonly url: Schema.String;
                            readonly mediaType: Schema.optional<Schema.String>;
                            readonly expiresAt: Schema.optional<Schema.Number>;
                        }>, Schema.Struct<{
                            readonly type: Schema.Literal<"ref">;
                            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                            readonly id: Schema.String;
                            readonly mediaType: Schema.optional<Schema.String>;
                        }>]>;
                        readonly info: Schema.optional<Schema.Struct<{
                            readonly width: Schema.optional<Schema.Number>;
                            readonly height: Schema.optional<Schema.Number>;
                            readonly durationSeconds: Schema.optional<Schema.Number>;
                            readonly sampleRate: Schema.optional<Schema.Number>;
                            readonly channels: Schema.optional<Schema.Number>;
                            readonly encoding: Schema.optional<Schema.String>;
                            readonly format: Schema.optional<Schema.String>;
                        }>>;
                        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                    }>, never, never>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly raw: Schema.Struct<{
                    readonly type: Schema.tag<"raw">;
                    readonly data: Schema.Unknown;
                }>;
                readonly "reasoning-delta": Schema.Struct<{
                    readonly type: Schema.tag<"reasoning-delta">;
                    readonly id: Schema.String;
                    readonly text: Schema.String;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "reasoning-end": Schema.Struct<{
                    readonly type: Schema.tag<"reasoning-end">;
                    readonly id: Schema.String;
                    /** Authoritative complete value; replaces accumulated deltas when present. */
                    readonly text: Schema.optional<Schema.String>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "reasoning-start": Schema.Struct<{
                    readonly type: Schema.tag<"reasoning-start">;
                    readonly id: Schema.String;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "step-finish": Schema.Struct<{
                    readonly type: Schema.tag<"step-finish">;
                    readonly index: Schema.Number;
                    readonly reason: Schema.Struct<{
                        readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                        readonly raw: Schema.optional<Schema.String>;
                        /** The provider's policy area for a content-filter finish, such as `cyber`. */
                        readonly category: Schema.optional<Schema.String>;
                        /** The provider's human-readable reason for a content-filter finish. */
                        readonly explanation: Schema.optional<Schema.String>;
                    }>;
                    readonly usage: Schema.optional<typeof Usage>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "step-start": Schema.Struct<{
                    readonly type: Schema.tag<"step-start">;
                    readonly index: Schema.Number;
                }>;
                readonly "text-delta": Schema.Struct<{
                    readonly type: Schema.tag<"text-delta">;
                    readonly id: Schema.String;
                    readonly text: Schema.String;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "text-end": Schema.Struct<{
                    readonly type: Schema.tag<"text-end">;
                    readonly id: Schema.String;
                    /** Authoritative complete value; replaces accumulated deltas when present. */
                    readonly text: Schema.optional<Schema.String>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "text-start": Schema.Struct<{
                    readonly type: Schema.tag<"text-start">;
                    readonly id: Schema.String;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "tool-call": Schema.Struct<{
                    readonly type: Schema.tag<"tool-call">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly input: Schema.Unknown;
                    readonly providerExecuted: Schema.optional<Schema.Boolean>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "tool-input-delta": Schema.Struct<{
                    readonly type: Schema.tag<"tool-input-delta">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly text: Schema.String;
                    /** Best-effort parse of all input fragments received through this delta. */
                    readonly input: Schema.optional<Schema.Unknown>;
                }>;
                readonly "tool-input-end": Schema.Struct<{
                    readonly type: Schema.tag<"tool-input-end">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "tool-input-error": Schema.Struct<{
                    readonly type: Schema.tag<"tool-input-error">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly raw: Schema.String;
                }>;
                readonly "tool-input-start": Schema.Struct<{
                    readonly type: Schema.tag<"tool-input-start">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly providerExecuted: Schema.optional<Schema.Boolean>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "tool-result": Schema.Struct<{
                    readonly type: Schema.tag<"tool-result">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly result: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"json">;
                        readonly value: Schema.Unknown;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"text">;
                        readonly value: Schema.Unknown;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"error">;
                        readonly value: Schema.Unknown;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"content">;
                        readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                            readonly type: Schema.Literal<"text">;
                            readonly text: Schema.String;
                        }>, Schema.Struct<{
                            readonly type: Schema.Literal<"file">;
                            readonly uri: Schema.String;
                            readonly mime: Schema.String;
                            readonly name: Schema.optional<Schema.String>;
                        }>]>>;
                    }>]> & {
                        is: <I>(input: I) => input is I & ({
                            readonly type: "json";
                            readonly value: unknown;
                        } | {
                            readonly type: "text";
                            readonly value: unknown;
                        } | {
                            readonly type: "error";
                            readonly value: unknown;
                        } | {
                            readonly type: "content";
                            readonly value: readonly ({
                                readonly type: "text";
                                readonly text: string;
                            } | {
                                readonly type: "file";
                                readonly uri: string;
                                readonly mime: string;
                                readonly name?: string | undefined;
                            })[];
                        });
                        make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
                    };
                    readonly output: Schema.optional<Schema.Struct<{
                        readonly structured: Schema.Unknown;
                        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                            readonly type: Schema.Literal<"text">;
                            readonly text: Schema.String;
                        }>, Schema.Struct<{
                            readonly type: Schema.Literal<"file">;
                            readonly uri: Schema.String;
                            readonly mime: Schema.String;
                            readonly name: Schema.optional<Schema.String>;
                        }>]>>;
                    }> & {
                        make: (structured: unknown, content?: ReadonlyArray<import("@opencode/schema/tool").Content>) => ToolOutput;
                        fromResultValue: (result: ToolResultValue) => ToolOutput | undefined;
                        toResultValue: (output: ToolOutput) => ToolResultValue;
                    }>;
                    readonly providerExecuted: Schema.optional<Schema.Boolean>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
            }[K]["Type"]) => any; }>(value: {
                readonly type: "step-start";
                readonly index: number;
            } | {
                readonly type: "raw";
                readonly data: unknown;
            } | {
                readonly type: "text-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "text-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "text-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-start";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-delta";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly text: string;
                readonly input?: unknown;
            } | {
                readonly type: "tool-input-end";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-error";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly raw: string;
            } | {
                readonly type: "tool-call";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly input: unknown;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-result";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly result: {
                    readonly type: "json";
                    readonly value: unknown;
                } | {
                    readonly type: "text";
                    readonly value: unknown;
                } | {
                    readonly type: "error";
                    readonly value: unknown;
                } | {
                    readonly type: "content";
                    readonly value: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                };
                readonly output?: {
                    readonly structured: unknown;
                    readonly content: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                } | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "step-finish";
                readonly index: number;
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "finish";
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly message?: AssistantMessage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "media";
                readonly media: Media.Asset;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | ({
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            })), cases: Handlers): import("effect/Unify").Unify<ReturnType<Handlers["compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"]>>;
            <Handlers extends { [K in "compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"]: (value: {
                readonly compaction: Schema.refine<{
                    readonly type: "compaction";
                    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                    readonly id?: string | undefined;
                    readonly encrypted?: string | undefined;
                    readonly text?: string | null | undefined;
                } & ({
                    readonly encrypted: string;
                    readonly text?: never;
                } | {
                    readonly text: string | null;
                    readonly encrypted?: never;
                }), Schema.Struct<{
                    readonly type: Schema.Literal<"compaction">;
                    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                    readonly id: Schema.optional<Schema.String>;
                    readonly encrypted: Schema.optional<Schema.String>;
                    readonly text: Schema.optional<Schema.NullOr<Schema.String>>;
                }>> & {
                    make: (input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
                        readonly encrypted: string;
                        readonly text?: never;
                    } | {
                        readonly text: string | null;
                        readonly encrypted?: never;
                    })) => CompactionPart;
                };
                readonly finish: Schema.Struct<{
                    readonly type: Schema.tag<"finish">;
                    readonly reason: Schema.Struct<{
                        readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                        readonly raw: Schema.optional<Schema.String>;
                        /** The provider's policy area for a content-filter finish, such as `cyber`. */
                        readonly category: Schema.optional<Schema.String>;
                        /** The provider's human-readable reason for a content-filter finish. */
                        readonly explanation: Schema.optional<Schema.String>;
                    }>;
                    readonly usage: Schema.optional<typeof Usage>;
                    /** The final assistant message, set by `ai.stream` and `ai.loop`. */
                    readonly message: Schema.optional<typeof AssistantMessage>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly media: Schema.Struct<{
                    readonly type: Schema.tag<"media">;
                    readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                        readonly source: Schema.Union<readonly [Schema.Struct<{
                            readonly type: Schema.Literal<"bytes">;
                            readonly data: Schema.Uint8Array;
                            readonly mediaType: Schema.String;
                        }>, Schema.Struct<{
                            readonly type: Schema.Literal<"base64">;
                            readonly data: Schema.String;
                            readonly mediaType: Schema.String;
                        }>, Schema.Struct<{
                            readonly type: Schema.Literal<"url">;
                            readonly url: Schema.String;
                            readonly mediaType: Schema.optional<Schema.String>;
                            readonly expiresAt: Schema.optional<Schema.Number>;
                        }>, Schema.Struct<{
                            readonly type: Schema.Literal<"ref">;
                            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                            readonly id: Schema.String;
                            readonly mediaType: Schema.optional<Schema.String>;
                        }>]>;
                        readonly info: Schema.optional<Schema.Struct<{
                            readonly width: Schema.optional<Schema.Number>;
                            readonly height: Schema.optional<Schema.Number>;
                            readonly durationSeconds: Schema.optional<Schema.Number>;
                            readonly sampleRate: Schema.optional<Schema.Number>;
                            readonly channels: Schema.optional<Schema.Number>;
                            readonly encoding: Schema.optional<Schema.String>;
                            readonly format: Schema.optional<Schema.String>;
                        }>>;
                        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                    }>, never, never>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly raw: Schema.Struct<{
                    readonly type: Schema.tag<"raw">;
                    readonly data: Schema.Unknown;
                }>;
                readonly "reasoning-delta": Schema.Struct<{
                    readonly type: Schema.tag<"reasoning-delta">;
                    readonly id: Schema.String;
                    readonly text: Schema.String;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "reasoning-end": Schema.Struct<{
                    readonly type: Schema.tag<"reasoning-end">;
                    readonly id: Schema.String;
                    /** Authoritative complete value; replaces accumulated deltas when present. */
                    readonly text: Schema.optional<Schema.String>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "reasoning-start": Schema.Struct<{
                    readonly type: Schema.tag<"reasoning-start">;
                    readonly id: Schema.String;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "step-finish": Schema.Struct<{
                    readonly type: Schema.tag<"step-finish">;
                    readonly index: Schema.Number;
                    readonly reason: Schema.Struct<{
                        readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
                        readonly raw: Schema.optional<Schema.String>;
                        /** The provider's policy area for a content-filter finish, such as `cyber`. */
                        readonly category: Schema.optional<Schema.String>;
                        /** The provider's human-readable reason for a content-filter finish. */
                        readonly explanation: Schema.optional<Schema.String>;
                    }>;
                    readonly usage: Schema.optional<typeof Usage>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "step-start": Schema.Struct<{
                    readonly type: Schema.tag<"step-start">;
                    readonly index: Schema.Number;
                }>;
                readonly "text-delta": Schema.Struct<{
                    readonly type: Schema.tag<"text-delta">;
                    readonly id: Schema.String;
                    readonly text: Schema.String;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "text-end": Schema.Struct<{
                    readonly type: Schema.tag<"text-end">;
                    readonly id: Schema.String;
                    /** Authoritative complete value; replaces accumulated deltas when present. */
                    readonly text: Schema.optional<Schema.String>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "text-start": Schema.Struct<{
                    readonly type: Schema.tag<"text-start">;
                    readonly id: Schema.String;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "tool-call": Schema.Struct<{
                    readonly type: Schema.tag<"tool-call">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly input: Schema.Unknown;
                    readonly providerExecuted: Schema.optional<Schema.Boolean>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "tool-input-delta": Schema.Struct<{
                    readonly type: Schema.tag<"tool-input-delta">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly text: Schema.String;
                    /** Best-effort parse of all input fragments received through this delta. */
                    readonly input: Schema.optional<Schema.Unknown>;
                }>;
                readonly "tool-input-end": Schema.Struct<{
                    readonly type: Schema.tag<"tool-input-end">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "tool-input-error": Schema.Struct<{
                    readonly type: Schema.tag<"tool-input-error">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly raw: Schema.String;
                }>;
                readonly "tool-input-start": Schema.Struct<{
                    readonly type: Schema.tag<"tool-input-start">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly providerExecuted: Schema.optional<Schema.Boolean>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
                readonly "tool-result": Schema.Struct<{
                    readonly type: Schema.tag<"tool-result">;
                    readonly id: Schema.String;
                    readonly name: Schema.String;
                    readonly namespace: Schema.optional<Schema.String>;
                    readonly result: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"json">;
                        readonly value: Schema.Unknown;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"text">;
                        readonly value: Schema.Unknown;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"error">;
                        readonly value: Schema.Unknown;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"content">;
                        readonly value: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                            readonly type: Schema.Literal<"text">;
                            readonly text: Schema.String;
                        }>, Schema.Struct<{
                            readonly type: Schema.Literal<"file">;
                            readonly uri: Schema.String;
                            readonly mime: Schema.String;
                            readonly name: Schema.optional<Schema.String>;
                        }>]>>;
                    }>]> & {
                        is: <I>(input: I) => input is I & ({
                            readonly type: "json";
                            readonly value: unknown;
                        } | {
                            readonly type: "text";
                            readonly value: unknown;
                        } | {
                            readonly type: "error";
                            readonly value: unknown;
                        } | {
                            readonly type: "content";
                            readonly value: readonly ({
                                readonly type: "text";
                                readonly text: string;
                            } | {
                                readonly type: "file";
                                readonly uri: string;
                                readonly mime: string;
                                readonly name?: string | undefined;
                            })[];
                        });
                        make: (value: unknown, type?: ToolResultValue["type"]) => ToolResultValue;
                    };
                    readonly output: Schema.optional<Schema.Struct<{
                        readonly structured: Schema.Unknown;
                        readonly content: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                            readonly type: Schema.Literal<"text">;
                            readonly text: Schema.String;
                        }>, Schema.Struct<{
                            readonly type: Schema.Literal<"file">;
                            readonly uri: Schema.String;
                            readonly mime: Schema.String;
                            readonly name: Schema.optional<Schema.String>;
                        }>]>>;
                    }> & {
                        make: (structured: unknown, content?: ReadonlyArray<import("@opencode/schema/tool").Content>) => ToolOutput;
                        fromResultValue: (result: ToolResultValue) => ToolOutput | undefined;
                        toResultValue: (output: ToolOutput) => ToolResultValue;
                    }>;
                    readonly providerExecuted: Schema.optional<Schema.Boolean>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>;
            }[K]["Type"]) => any; }>(cases: Handlers): (value: {
                readonly type: "step-start";
                readonly index: number;
            } | {
                readonly type: "raw";
                readonly data: unknown;
            } | {
                readonly type: "text-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "text-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "text-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-start";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-delta";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly text: string;
                readonly input?: unknown;
            } | {
                readonly type: "tool-input-end";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-error";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly raw: string;
            } | {
                readonly type: "tool-call";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly input: unknown;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-result";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly result: {
                    readonly type: "json";
                    readonly value: unknown;
                } | {
                    readonly type: "text";
                    readonly value: unknown;
                } | {
                    readonly type: "error";
                    readonly value: unknown;
                } | {
                    readonly type: "content";
                    readonly value: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                };
                readonly output?: {
                    readonly structured: unknown;
                    readonly content: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                } | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "step-finish";
                readonly index: number;
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "finish";
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly message?: AssistantMessage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "media";
                readonly media: Media.Asset;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | ({
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            }))) => import("effect/Unify").Unify<ReturnType<Handlers["compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"]>>;
        };
        readonly matchOrElse: {
            <Handlers, OrElse>(value: {
                readonly type: "step-start";
                readonly index: number;
            } | {
                readonly type: "raw";
                readonly data: unknown;
            } | {
                readonly type: "text-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "text-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "text-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-start";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-delta";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly text: string;
                readonly input?: unknown;
            } | {
                readonly type: "tool-input-end";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-error";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly raw: string;
            } | {
                readonly type: "tool-call";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly input: unknown;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-result";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly result: {
                    readonly type: "json";
                    readonly value: unknown;
                } | {
                    readonly type: "text";
                    readonly value: unknown;
                } | {
                    readonly type: "error";
                    readonly value: unknown;
                } | {
                    readonly type: "content";
                    readonly value: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                };
                readonly output?: {
                    readonly structured: unknown;
                    readonly content: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                } | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "step-finish";
                readonly index: number;
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "finish";
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly message?: AssistantMessage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "media";
                readonly media: Media.Asset;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | ({
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            })), cases: Handlers & {
                readonly compaction?: ((value: {
                    readonly type: "compaction";
                    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                    readonly id?: string | undefined;
                    readonly encrypted?: string | undefined;
                    readonly text?: string | null | undefined;
                } & ({
                    readonly encrypted: string;
                    readonly text?: never;
                } | {
                    readonly text: string | null;
                    readonly encrypted?: never;
                })) => any) | undefined;
                readonly finish?: ((value: {
                    readonly type: "finish";
                    readonly reason: {
                        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                        readonly raw?: string | undefined;
                        readonly category?: string | undefined;
                        readonly explanation?: string | undefined;
                    };
                    readonly usage?: Usage | undefined;
                    readonly message?: AssistantMessage | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly media?: ((value: {
                    readonly type: "media";
                    readonly media: Media.Asset;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly raw?: ((value: {
                    readonly type: "raw";
                    readonly data: unknown;
                }) => any) | undefined;
                readonly "reasoning-delta"?: ((value: {
                    readonly type: "reasoning-delta";
                    readonly id: string;
                    readonly text: string;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "reasoning-end"?: ((value: {
                    readonly type: "reasoning-end";
                    readonly id: string;
                    readonly text?: string | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "reasoning-start"?: ((value: {
                    readonly type: "reasoning-start";
                    readonly id: string;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "step-finish"?: ((value: {
                    readonly type: "step-finish";
                    readonly index: number;
                    readonly reason: {
                        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                        readonly raw?: string | undefined;
                        readonly category?: string | undefined;
                        readonly explanation?: string | undefined;
                    };
                    readonly usage?: Usage | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "step-start"?: ((value: {
                    readonly type: "step-start";
                    readonly index: number;
                }) => any) | undefined;
                readonly "text-delta"?: ((value: {
                    readonly type: "text-delta";
                    readonly id: string;
                    readonly text: string;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "text-end"?: ((value: {
                    readonly type: "text-end";
                    readonly id: string;
                    readonly text?: string | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "text-start"?: ((value: {
                    readonly type: "text-start";
                    readonly id: string;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "tool-call"?: ((value: {
                    readonly type: "tool-call";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly input: unknown;
                    readonly providerExecuted?: boolean | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "tool-input-delta"?: ((value: {
                    readonly type: "tool-input-delta";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly text: string;
                    readonly input?: unknown;
                }) => any) | undefined;
                readonly "tool-input-end"?: ((value: {
                    readonly type: "tool-input-end";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "tool-input-error"?: ((value: {
                    readonly type: "tool-input-error";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly raw: string;
                }) => any) | undefined;
                readonly "tool-input-start"?: ((value: {
                    readonly type: "tool-input-start";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly providerExecuted?: boolean | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "tool-result"?: ((value: {
                    readonly type: "tool-result";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly result: {
                        readonly type: "json";
                        readonly value: unknown;
                    } | {
                        readonly type: "text";
                        readonly value: unknown;
                    } | {
                        readonly type: "error";
                        readonly value: unknown;
                    } | {
                        readonly type: "content";
                        readonly value: readonly ({
                            readonly type: "text";
                            readonly text: string;
                        } | {
                            readonly type: "file";
                            readonly uri: string;
                            readonly mime: string;
                            readonly name?: string | undefined;
                        })[];
                    };
                    readonly output?: {
                        readonly structured: unknown;
                        readonly content: readonly ({
                            readonly type: "text";
                            readonly text: string;
                        } | {
                            readonly type: "file";
                            readonly uri: string;
                            readonly mime: string;
                            readonly name?: string | undefined;
                        })[];
                    } | undefined;
                    readonly providerExecuted?: boolean | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
            } & (Exclude<keyof Handlers, "compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
                readonly type: "step-start";
                readonly index: number;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "raw";
                readonly data: unknown;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "text-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "text-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "text-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "reasoning-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "reasoning-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "reasoning-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-input-start";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-input-delta";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly text: string;
                readonly input?: unknown;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-input-end";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-input-error";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly raw: string;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-call";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly input: unknown;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-result";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly result: {
                    readonly type: "json";
                    readonly value: unknown;
                } | {
                    readonly type: "text";
                    readonly value: unknown;
                } | {
                    readonly type: "error";
                    readonly value: unknown;
                } | {
                    readonly type: "content";
                    readonly value: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                };
                readonly output?: {
                    readonly structured: unknown;
                    readonly content: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                } | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "step-finish";
                readonly index: number;
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "finish";
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly message?: AssistantMessage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "media";
                readonly media: Media.Asset;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & {
                readonly encrypted: string;
                readonly text?: never;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & {
                readonly text: string | null;
                readonly encrypted?: never;
            }, {
                readonly type: keyof Handlers;
            }>) => any)): import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
            <Handlers, OrElse>(cases: Handlers & {
                readonly compaction?: ((value: {
                    readonly type: "compaction";
                    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                    readonly id?: string | undefined;
                    readonly encrypted?: string | undefined;
                    readonly text?: string | null | undefined;
                } & ({
                    readonly encrypted: string;
                    readonly text?: never;
                } | {
                    readonly text: string | null;
                    readonly encrypted?: never;
                })) => any) | undefined;
                readonly finish?: ((value: {
                    readonly type: "finish";
                    readonly reason: {
                        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                        readonly raw?: string | undefined;
                        readonly category?: string | undefined;
                        readonly explanation?: string | undefined;
                    };
                    readonly usage?: Usage | undefined;
                    readonly message?: AssistantMessage | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly media?: ((value: {
                    readonly type: "media";
                    readonly media: Media.Asset;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly raw?: ((value: {
                    readonly type: "raw";
                    readonly data: unknown;
                }) => any) | undefined;
                readonly "reasoning-delta"?: ((value: {
                    readonly type: "reasoning-delta";
                    readonly id: string;
                    readonly text: string;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "reasoning-end"?: ((value: {
                    readonly type: "reasoning-end";
                    readonly id: string;
                    readonly text?: string | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "reasoning-start"?: ((value: {
                    readonly type: "reasoning-start";
                    readonly id: string;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "step-finish"?: ((value: {
                    readonly type: "step-finish";
                    readonly index: number;
                    readonly reason: {
                        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                        readonly raw?: string | undefined;
                        readonly category?: string | undefined;
                        readonly explanation?: string | undefined;
                    };
                    readonly usage?: Usage | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "step-start"?: ((value: {
                    readonly type: "step-start";
                    readonly index: number;
                }) => any) | undefined;
                readonly "text-delta"?: ((value: {
                    readonly type: "text-delta";
                    readonly id: string;
                    readonly text: string;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "text-end"?: ((value: {
                    readonly type: "text-end";
                    readonly id: string;
                    readonly text?: string | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "text-start"?: ((value: {
                    readonly type: "text-start";
                    readonly id: string;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "tool-call"?: ((value: {
                    readonly type: "tool-call";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly input: unknown;
                    readonly providerExecuted?: boolean | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "tool-input-delta"?: ((value: {
                    readonly type: "tool-input-delta";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly text: string;
                    readonly input?: unknown;
                }) => any) | undefined;
                readonly "tool-input-end"?: ((value: {
                    readonly type: "tool-input-end";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "tool-input-error"?: ((value: {
                    readonly type: "tool-input-error";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly raw: string;
                }) => any) | undefined;
                readonly "tool-input-start"?: ((value: {
                    readonly type: "tool-input-start";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly providerExecuted?: boolean | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
                readonly "tool-result"?: ((value: {
                    readonly type: "tool-result";
                    readonly id: string;
                    readonly name: string;
                    readonly namespace?: string | undefined;
                    readonly result: {
                        readonly type: "json";
                        readonly value: unknown;
                    } | {
                        readonly type: "text";
                        readonly value: unknown;
                    } | {
                        readonly type: "error";
                        readonly value: unknown;
                    } | {
                        readonly type: "content";
                        readonly value: readonly ({
                            readonly type: "text";
                            readonly text: string;
                        } | {
                            readonly type: "file";
                            readonly uri: string;
                            readonly mime: string;
                            readonly name?: string | undefined;
                        })[];
                    };
                    readonly output?: {
                        readonly structured: unknown;
                        readonly content: readonly ({
                            readonly type: "text";
                            readonly text: string;
                        } | {
                            readonly type: "file";
                            readonly uri: string;
                            readonly mime: string;
                            readonly name?: string | undefined;
                        })[];
                    } | undefined;
                    readonly providerExecuted?: boolean | undefined;
                    readonly providerMetadata?: {
                        readonly [x: string]: {
                            readonly [x: string]: unknown;
                        };
                    } | undefined;
                }) => any) | undefined;
            } & (Exclude<keyof Handlers, "compaction" | "finish" | "media" | "raw" | "reasoning-delta" | "reasoning-end" | "reasoning-start" | "step-finish" | "step-start" | "text-delta" | "text-end" | "text-start" | "tool-call" | "tool-input-delta" | "tool-input-end" | "tool-input-error" | "tool-input-start" | "tool-result"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
                readonly type: "step-start";
                readonly index: number;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "raw";
                readonly data: unknown;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "text-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "text-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "text-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "reasoning-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "reasoning-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "reasoning-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-input-start";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-input-delta";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly text: string;
                readonly input?: unknown;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-input-end";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-input-error";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly raw: string;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-call";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly input: unknown;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "tool-result";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly result: {
                    readonly type: "json";
                    readonly value: unknown;
                } | {
                    readonly type: "text";
                    readonly value: unknown;
                } | {
                    readonly type: "error";
                    readonly value: unknown;
                } | {
                    readonly type: "content";
                    readonly value: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                };
                readonly output?: {
                    readonly structured: unknown;
                    readonly content: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                } | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "step-finish";
                readonly index: number;
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "finish";
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly message?: AssistantMessage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "media";
                readonly media: Media.Asset;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & {
                readonly encrypted: string;
                readonly text?: never;
            }, {
                readonly type: keyof Handlers;
            }> | Exclude<{
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & {
                readonly text: string | null;
                readonly encrypted?: never;
            }, {
                readonly type: keyof Handlers;
            }>) => any)): (value: {
                readonly type: "step-start";
                readonly index: number;
            } | {
                readonly type: "raw";
                readonly data: unknown;
            } | {
                readonly type: "text-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "text-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "text-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "reasoning-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-start";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-delta";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly text: string;
                readonly input?: unknown;
            } | {
                readonly type: "tool-input-end";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-input-error";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly raw: string;
            } | {
                readonly type: "tool-call";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly input: unknown;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "tool-result";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly result: {
                    readonly type: "json";
                    readonly value: unknown;
                } | {
                    readonly type: "text";
                    readonly value: unknown;
                } | {
                    readonly type: "error";
                    readonly value: unknown;
                } | {
                    readonly type: "content";
                    readonly value: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                };
                readonly output?: {
                    readonly structured: unknown;
                    readonly content: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                } | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "step-finish";
                readonly index: number;
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "finish";
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly message?: AssistantMessage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | {
                readonly type: "media";
                readonly media: Media.Asset;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            } | ({
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            }))) => import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
        };
    } & {
        compaction: ((input: {
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        }, options?: Schema.MakeOptions) => {
            readonly type: "compaction";
            readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
            readonly id?: string | undefined;
            readonly encrypted?: string | undefined;
            readonly text?: string | null | undefined;
        } & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        })) & ((input: Omit<CompactionPart, "type" | "encrypted" | "text"> & ({
            readonly encrypted: string;
            readonly text?: never;
        } | {
            readonly text: string | null;
            readonly encrypted?: never;
        })) => CompactionPart);
        stepStart: (input: {
            readonly type?: "step-start" | undefined;
            readonly index: number;
        }, options?: Schema.MakeOptions) => {
            readonly type: "step-start";
            readonly index: number;
        };
        textStart: (input: WithID<TextStart, ContentBlockID>) => {
            readonly type: "text-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        textDelta: (input: WithID<TextDelta, ContentBlockID>) => {
            readonly type: "text-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        textEnd: (input: WithID<TextEnd, ContentBlockID>) => {
            readonly type: "text-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        reasoningStart: (input: WithID<ReasoningStart, ContentBlockID>) => {
            readonly type: "reasoning-start";
            readonly id: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        reasoningDelta: (input: WithID<ReasoningDelta, ContentBlockID>) => {
            readonly type: "reasoning-delta";
            readonly id: string;
            readonly text: string;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        reasoningEnd: (input: WithID<ReasoningEnd, ContentBlockID>) => {
            readonly type: "reasoning-end";
            readonly id: string;
            readonly text?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        toolInputStart: (input: WithID<ToolInputStart, ToolCallID>) => {
            readonly type: "tool-input-start";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        toolInputDelta: (input: WithID<ToolInputDelta, ToolCallID>) => {
            readonly type: "tool-input-delta";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly text: string;
            readonly input?: unknown;
        };
        toolInputEnd: (input: WithID<ToolInputEnd, ToolCallID>) => {
            readonly type: "tool-input-end";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        toolInputError: (input: WithID<ToolInputError, ToolCallID>) => {
            readonly type: "tool-input-error";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly raw: string;
        };
        toolCall: (input: WithID<ToolCall, ToolCallID>) => {
            readonly type: "tool-call";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly input: unknown;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        toolResult: (input: WithID<ToolResult, ToolCallID>) => {
            readonly type: "tool-result";
            readonly id: string;
            readonly name: string;
            readonly namespace?: string | undefined;
            readonly result: {
                readonly type: "json";
                readonly value: unknown;
            } | {
                readonly type: "text";
                readonly value: unknown;
            } | {
                readonly type: "error";
                readonly value: unknown;
            } | {
                readonly type: "content";
                readonly value: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            };
            readonly output?: {
                readonly structured: unknown;
                readonly content: readonly ({
                    readonly type: "text";
                    readonly text: string;
                } | {
                    readonly type: "file";
                    readonly uri: string;
                    readonly mime: string;
                    readonly name?: string | undefined;
                })[];
            } | undefined;
            readonly providerExecuted?: boolean | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        media: (input: {
            readonly type?: "media" | undefined;
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, options?: Schema.MakeOptions) => {
            readonly type: "media";
            readonly media: Media.Asset;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        stepFinish: (input: WithUsage<StepFinish>) => {
            readonly type: "step-finish";
            readonly index: number;
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        finish: (input: WithUsage<Finish>) => {
            readonly type: "finish";
            readonly reason: {
                readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                readonly raw?: string | undefined;
                readonly category?: string | undefined;
                readonly explanation?: string | undefined;
            };
            readonly usage?: Usage | undefined;
            readonly message?: AssistantMessage | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        raw: (input: {
            readonly type?: "raw" | undefined;
            readonly data: unknown;
        }, options?: Schema.MakeOptions) => {
            readonly type: "raw";
            readonly data: unknown;
        };
        is: {
            compaction: (u: unknown) => u is {
                readonly type: "compaction";
                readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
                readonly id?: string | undefined;
                readonly encrypted?: string | undefined;
                readonly text?: string | null | undefined;
            } & ({
                readonly encrypted: string;
                readonly text?: never;
            } | {
                readonly text: string | null;
                readonly encrypted?: never;
            });
            stepStart: (u: unknown) => u is {
                readonly type: "step-start";
                readonly index: number;
            };
            textStart: (u: unknown) => u is {
                readonly type: "text-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            textDelta: (u: unknown) => u is {
                readonly type: "text-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            textEnd: (u: unknown) => u is {
                readonly type: "text-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            reasoningStart: (u: unknown) => u is {
                readonly type: "reasoning-start";
                readonly id: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            reasoningDelta: (u: unknown) => u is {
                readonly type: "reasoning-delta";
                readonly id: string;
                readonly text: string;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            reasoningEnd: (u: unknown) => u is {
                readonly type: "reasoning-end";
                readonly id: string;
                readonly text?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            toolInputStart: (u: unknown) => u is {
                readonly type: "tool-input-start";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            toolInputDelta: (u: unknown) => u is {
                readonly type: "tool-input-delta";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly text: string;
                readonly input?: unknown;
            };
            toolInputEnd: (u: unknown) => u is {
                readonly type: "tool-input-end";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            toolInputError: (u: unknown) => u is {
                readonly type: "tool-input-error";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly raw: string;
            };
            toolCall: (u: unknown) => u is {
                readonly type: "tool-call";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly input: unknown;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            toolResult: (u: unknown) => u is {
                readonly type: "tool-result";
                readonly id: string;
                readonly name: string;
                readonly namespace?: string | undefined;
                readonly result: {
                    readonly type: "json";
                    readonly value: unknown;
                } | {
                    readonly type: "text";
                    readonly value: unknown;
                } | {
                    readonly type: "error";
                    readonly value: unknown;
                } | {
                    readonly type: "content";
                    readonly value: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                };
                readonly output?: {
                    readonly structured: unknown;
                    readonly content: readonly ({
                        readonly type: "text";
                        readonly text: string;
                    } | {
                        readonly type: "file";
                        readonly uri: string;
                        readonly mime: string;
                        readonly name?: string | undefined;
                    })[];
                } | undefined;
                readonly providerExecuted?: boolean | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            media: (u: unknown) => u is {
                readonly type: "media";
                readonly media: Media.Asset;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            stepFinish: (u: unknown) => u is {
                readonly type: "step-finish";
                readonly index: number;
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            finish: (u: unknown) => u is {
                readonly type: "finish";
                readonly reason: {
                    readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
                    readonly raw?: string | undefined;
                    readonly category?: string | undefined;
                    readonly explanation?: string | undefined;
                };
                readonly usage?: Usage | undefined;
                readonly message?: AssistantMessage | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            };
            raw: (u: unknown) => u is {
                readonly type: "raw";
                readonly data: unknown;
            };
        };
    }>;
    readonly usage: Schema.optional<typeof Usage>;
    readonly finishReason: Schema.Struct<{
        readonly normalized: Schema.Literals<readonly ["stop", "length", "tool-calls", "content-filter", "error", "unknown"]>;
        readonly raw: Schema.optional<Schema.String>;
        /** The provider's policy area for a content-filter finish, such as `cyber`. */
        readonly category: Schema.optional<Schema.String>;
        /** The provider's human-readable reason for a content-filter finish. */
        readonly explanation: Schema.optional<Schema.String>;
    }>;
}>, {}>;
export declare class LLMResponse extends LLMResponse_base {
    /** Concatenated assistant text; each fragment's `text-end` value replaces its accumulated deltas when present. */
    get text(): string;
    /** Concatenated reasoning text; each fragment's `reasoning-end` value replaces its accumulated deltas when present. */
    get reasoning(): string;
    /** Completed tool calls emitted by the provider. */
    get toolCalls(): {
        readonly type: "tool-call";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly input: unknown;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }[];
}
/**
 * Internal fold that assembles one provider attempt. Not exported from the package.
 * A state has a single owner: `reduce` appends to the events buffer in place, so earlier states must not be reused.
 */
export declare namespace ResponseFold {
    type State = ResponseState;
    /** Initial state with a fresh events buffer. */
    const empty: typeof emptyResponseState;
    /** Fold one provider-neutral event into the state. */
    const reduce: typeof reduceResponseState;
    /** Return a completed response only after the terminal finish. The response gets its own copy of the events. */
    const complete: (state: State) => LLMResponse | undefined;
    /** Output that arrived before a failure, or `undefined` if only `step-start` did; an unfinished response reports `error`. */
    const partial: (state: State) => LLMResponse | undefined;
}
export declare namespace LLMResponse {
    type Output = LLMResponse | {
        readonly events: ReadonlyArray<LLMEvent>;
        readonly usage?: Usage;
    };
    /** Assemble a response from a collected event list, or `undefined` if it has no terminal finish. */
    const fromEvents: (events: ReadonlyArray<LLMEvent>) => LLMResponse | undefined;
    /** Concatenate assistant text from a response or collected event list. */
    const text: (response: Output) => string;
    /** Return response usage, falling back to the latest usage-bearing event. */
    const usage: (response: Output) => Usage | undefined;
    /** Return completed tool calls from a response or collected event list. */
    const toolCalls: (response: Output) => {
        readonly type: "tool-call";
        readonly id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly input: unknown;
        readonly providerExecuted?: boolean | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }[];
    /** Concatenate reasoning text from a response or collected event list. */
    const reasoning: (response: Output) => string;
}
export {};
