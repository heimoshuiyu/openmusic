import { type Context, Effect, Layer, Stream } from "effect";
import { type AwaitOptions, type Generation, type Observation } from "./generation.js";
import { RequestExecutor } from "./route/executor.js";
import type { MediaRoute } from "./route/media.js";
import { AIError } from "./schema/index.js";
/** A media request whose model carries the route that executes it. */
export interface RoutedRequest<Self extends MediaRoute.MediaRequest, Event, Response> extends MediaRoute.MediaRequest {
    readonly model: MediaRoute.MediaRequest["model"] & {
        readonly route: MediaRoute.AnyRoute<Self, Event, Response>;
    };
}
/** `start` and `resume` fail with `UnsupportedOperation` on inline and stream routes. */
export interface Interface<Req extends RoutedRequest<Req, Event, Response>, Event, Response> {
    readonly generate: (request: Req, options?: AwaitOptions) => Effect.Effect<Response, AIError>;
    readonly stream: (request: Req, options?: AwaitOptions) => Stream.Stream<Event | Observation, AIError>;
    readonly start: (request: Req) => Effect.Effect<Generation<Response>, AIError>;
    readonly resume: (model: Req["model"], token: unknown) => Effect.Effect<Generation<Response>, AIError>;
}
/** One modality's layer and service accessors, dispatching each request on its route's `kind`. */
export declare const make: <Self, Req extends RoutedRequest<Req, Event, Response>, Event, Response>(service: Context.Service<Self, Interface<Req, Event, Response>>, input: {
    readonly modality: string;
    /** A completed response expanded into the streaming event shape. */
    readonly responseEvents: (response: Response) => ReadonlyArray<Event>;
}) => {
    responseEvents: (response: Response) => ReadonlyArray<Event>;
    layer: Layer.Layer<Self, never, RequestExecutor.RequestExecutorService>;
    generate: (request: Req, options?: AwaitOptions) => Effect.Effect<Response, AIError, Self>;
    stream: (request: Req, options?: AwaitOptions) => Stream.Stream<Event | Observation, AIError, Exclude<Self, import("effect/Scope").Scope>>;
    start: (request: Req) => Effect.Effect<Generation<Response>, AIError, Self>;
    resume: (model: Req["model"], token: unknown) => Effect.Effect<Generation<Response>, AIError, Self>;
};
export * as MediaClient from "./media-client.js";
