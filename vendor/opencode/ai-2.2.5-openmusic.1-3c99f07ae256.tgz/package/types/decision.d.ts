import { Effect, Schema } from "effect";
import { Service, type Execute } from "./decision-client.js";
import { Media } from "./media.js";
import { AIError, type BaseRequest, type HttpOptions, ModelID, ProviderID, ProviderOptions, type OpenString } from "./schema/index.js";
export declare const DecisionTextPart: Schema.Struct<{
    readonly type: Schema.Literal<"text">;
    readonly text: Schema.String;
}>;
export declare const DecisionJsonPart: Schema.Struct<{
    readonly type: Schema.Literal<"json">;
    readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
}>;
export declare const DecisionMediaPart: Schema.Struct<{
    readonly type: Schema.Literal<"media">;
    readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly filename: Schema.optional<Schema.String>;
}>;
export declare const DecisionPart: Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
    readonly type: Schema.Literal<"text">;
    readonly text: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"json">;
    readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"media">;
    readonly media: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly filename: Schema.optional<Schema.String>;
}>]>;
export type DecisionPart = Schema.Schema.Type<typeof DecisionPart>;
/** A media part as input: `media` may be plain data, with `mediaType` naming its type when the content can't. */
export type DecisionMediaPartInput = Omit<typeof DecisionMediaPart.Type, "media"> & {
    readonly media: Media.Input;
    readonly mediaType?: string;
};
export type DecisionPartInput = Exclude<DecisionPart, {
    readonly type: "media";
}> | DecisionMediaPartInput;
/** A plain object is one `json` part. */
export type DecisionInput = typeof Schema.JsonObject.Type | ReadonlyArray<DecisionPartInput>;
/** Choice values are typed: `true` and `"true"` are different values. */
export declare const ChoiceValue: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
export type ChoiceValue = Schema.Schema.Type<typeof ChoiceValue>;
export declare const PredicateQuestion: Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"predicate">;
    readonly instructions: Schema.String;
    /** What counts as true and as false, for statements the instructions alone leave ambiguous. */
    readonly criteria: Schema.optional<Schema.Struct<{
        readonly true: Schema.optional<Schema.String>;
        readonly false: Schema.optional<Schema.String>;
    }>>;
}>;
export type PredicateQuestion = Schema.Schema.Type<typeof PredicateQuestion>;
export declare const ChoiceQuestion: Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"choice">;
    readonly instructions: Schema.String;
    readonly choices: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
        readonly description: Schema.optional<Schema.String>;
    }>>;
}>;
export type ChoiceQuestion = Schema.Schema.Type<typeof ChoiceQuestion>;
export declare const ScoreQuestion: Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"score">;
    readonly instructions: Schema.String;
    readonly levels: Schema.$Array<Schema.Struct<{
        readonly label: Schema.String;
        readonly description: Schema.optional<Schema.String>;
    }>>;
}>;
export type ScoreQuestion = Schema.Schema.Type<typeof ScoreQuestion>;
export declare const DecisionQuestion: Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"predicate">;
    readonly instructions: Schema.String;
    /** What counts as true and as false, for statements the instructions alone leave ambiguous. */
    readonly criteria: Schema.optional<Schema.Struct<{
        readonly true: Schema.optional<Schema.String>;
        readonly false: Schema.optional<Schema.String>;
    }>>;
}>, Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"choice">;
    readonly instructions: Schema.String;
    readonly choices: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
        readonly description: Schema.optional<Schema.String>;
    }>>;
}>, Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"score">;
    readonly instructions: Schema.String;
    readonly levels: Schema.$Array<Schema.Struct<{
        readonly label: Schema.String;
        readonly description: Schema.optional<Schema.String>;
    }>>;
}>]>;
export type DecisionQuestion = Schema.Schema.Type<typeof DecisionQuestion>;
export type DecisionQuestions = ReadonlyArray<DecisionQuestion>;
export declare const PredicateAnswer: Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"predicate">;
    readonly probability: Schema.Number;
}>;
export type PredicateAnswer = Schema.Schema.Type<typeof PredicateAnswer>;
export declare const ChoiceAnswer: Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"choice">;
    readonly choice: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
    readonly probabilities: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
        readonly probability: Schema.Number;
    }>>;
    readonly confidence: Schema.Number;
}>;
export type ChoiceAnswer = Schema.Schema.Type<typeof ChoiceAnswer>;
/** `score` is the probability-weighted level index; `probabilities` has one entry per level. */
export declare const ScoreAnswer: Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"score">;
    readonly score: Schema.Number;
    readonly probabilities: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Int;
        readonly label: Schema.String;
        readonly probability: Schema.Number;
    }>>;
    readonly confidence: Schema.Number;
}>;
export type ScoreAnswer = Schema.Schema.Type<typeof ScoreAnswer>;
/** Why a question has no answer; hosts may report reasons beyond these. */
export type ErrorReason = OpenString<"refusal">;
export declare const ErrorReason: Schema.Codec<ErrorReason>;
/** This one question has no answer; the other answers still came back. */
export declare const ErrorAnswer: Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"error">;
    readonly reason: Schema.Codec<ErrorReason, ErrorReason, never, never>;
    readonly message: Schema.optional<Schema.String>;
}>;
export type ErrorAnswer = Schema.Schema.Type<typeof ErrorAnswer>;
export declare const DecisionAnswer: Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"predicate">;
    readonly probability: Schema.Number;
}>, Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"choice">;
    readonly choice: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
    readonly probabilities: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
        readonly probability: Schema.Number;
    }>>;
    readonly confidence: Schema.Number;
}>, Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"score">;
    readonly score: Schema.Number;
    readonly probabilities: Schema.$Array<Schema.Struct<{
        readonly value: Schema.Int;
        readonly label: Schema.String;
        readonly probability: Schema.Number;
    }>>;
    readonly confidence: Schema.Number;
}>, Schema.Struct<{
    readonly name: Schema.String;
    readonly type: Schema.Literal<"error">;
    readonly reason: Schema.Codec<ErrorReason, ErrorReason, never, never>;
    readonly message: Schema.optional<Schema.String>;
}>]>;
export type DecisionAnswer = Schema.Schema.Type<typeof DecisionAnswer>;
type ChoiceValueOf<Question> = Question extends {
    readonly choices: ReadonlyArray<{
        readonly value: infer Value;
    }>;
} ? Value : never;
export type AnswerFor<Question extends DecisionQuestion> = (Question extends {
    readonly type: "predicate";
} ? PredicateAnswer & {
    readonly name: Question["name"];
} : Question extends {
    readonly type: "choice";
} ? {
    readonly name: Question["name"];
    readonly type: "choice";
    readonly choice: ChoiceValueOf<Question>;
    readonly probabilities: ReadonlyArray<{
        readonly value: ChoiceValueOf<Question>;
        readonly probability: number;
    }>;
    readonly confidence: number;
} : ScoreAnswer & {
    readonly name: Question["name"];
}) | (ErrorAnswer & {
    readonly name: Question["name"];
});
/** One answer per question, in question order. */
export type AnswersFor<Questions extends DecisionQuestions> = {
    readonly [Index in keyof Questions]: AnswerFor<Questions[Index]>;
};
export type DecisionOptions = Record<string, unknown>;
/** What a decision model's route does; `DecisionRoute.make(...).model(...)` builds one from a protocol. */
export interface DecisionModelRoute<Options extends DecisionOptions = DecisionOptions> {
    readonly id: string;
    generate(request: DecisionRequest<DecisionModel<Options>>, execute: Execute): Effect.Effect<DecisionResponse, AIError>;
}
declare const DecisionModelCompatibility_base: Schema.Class<DecisionModelCompatibility, Schema.Struct<{
    /**
     * Where a System One host reads media, from models.dev `[api.systemone] compatibility.media_input`, named after
     * where the media goes in the body: `assets` (TypeSafe's assets map, referenced from the state), `state` (items
     * inside a state list) or `root` (one top-level list per kind: `images`, `audio`, `videos`).
     */
    readonly mediaInput: Schema.optional<Schema.Literals<readonly ["assets", "state", "root"]>>;
}>, {}>;
/** Host quirks a protocol adapts to, like `LanguageModelCompatibility` for language models. */
export declare class DecisionModelCompatibility extends DecisionModelCompatibility_base {
}
export declare namespace DecisionModelCompatibility {
    type Input = DecisionModelCompatibility | ConstructorParameters<typeof DecisionModelCompatibility>[0];
    const make: (input: Input) => DecisionModelCompatibility;
}
export declare class DecisionModel<Options extends DecisionOptions = DecisionOptions> {
    protected readonly _Options: Options;
    readonly id: ModelID;
    readonly provider: ProviderID;
    readonly route: DecisionModelRoute<Options>;
    readonly http?: HttpOptions;
    readonly compatibility?: DecisionModelCompatibility;
    /** Defaults under each request's `providerOptions`, such as options a provider package reads from its settings. */
    readonly providerOptions?: ProviderOptions;
    constructor(input: DecisionModel.Input<Options>);
    static make<Options extends DecisionOptions = DecisionOptions>(input: DecisionModel.MakeInput<Options>): DecisionModel<Options>;
}
export declare namespace DecisionModel {
    interface Input<Options extends DecisionOptions = DecisionOptions> {
        readonly id: ModelID;
        readonly provider: ProviderID;
        readonly route: DecisionModelRoute<Options>;
        readonly http?: HttpOptions;
        readonly compatibility?: DecisionModelCompatibility;
        readonly providerOptions?: ProviderOptions;
    }
    interface MakeInput<Options extends DecisionOptions = DecisionOptions> extends Omit<Input<Options>, "id" | "provider"> {
        readonly id: string | ModelID;
        readonly provider: string | ProviderID;
    }
}
export declare const DecisionModelSchema: Schema.declare<DecisionModel<DecisionOptions>, DecisionModel<DecisionOptions>>;
export type DecisionModelOptions<Model> = Model extends DecisionModel<infer Options> ? Options : never;
/** A normalized decision request, the plain object `ai.decision.request(...)` returns. */
export interface DecisionRequest<Model extends DecisionModel = DecisionModel, Questions extends DecisionQuestions = DecisionQuestions> extends BaseRequest<Model, DecisionModelOptions<Model>> {
    readonly input: ReadonlyArray<DecisionPart>;
    readonly questions: Questions;
}
/** Input accepted by `ai.decision.request` and `generate`. A `DecisionRequest` is also a valid input. */
export interface DecisionRequestInput<Model extends DecisionModel = DecisionModel, Questions extends DecisionQuestions = DecisionQuestions> extends BaseRequest<Model, NoInfer<DecisionModelOptions<Model>>> {
    readonly input: DecisionInput;
    readonly questions: Questions;
}
declare const DecisionUsage_base: Schema.Class<DecisionUsage, Schema.Struct<{
    readonly inputTokens: Schema.optional<Schema.Number>;
    readonly outputTokens: Schema.optional<Schema.Number>;
    readonly totalTokens: Schema.optional<Schema.Number>;
    /** USD the host says it charged for this request. */
    readonly cost: Schema.optional<Schema.Number>;
}>, {}>;
/** What decision hosts report; their raw usage stays in the response's `providerMetadata`. */
export declare class DecisionUsage extends DecisionUsage_base {
}
declare const DecisionResponse_base: Schema.Class<DecisionResponse, Schema.Struct<{
    readonly answers: Schema.$Array<Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
        readonly name: Schema.String;
        readonly type: Schema.Literal<"predicate">;
        readonly probability: Schema.Number;
    }>, Schema.Struct<{
        readonly name: Schema.String;
        readonly type: Schema.Literal<"choice">;
        readonly choice: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
        readonly probabilities: Schema.$Array<Schema.Struct<{
            readonly value: Schema.Union<readonly [Schema.String, Schema.Boolean]>;
            readonly probability: Schema.Number;
        }>>;
        readonly confidence: Schema.Number;
    }>, Schema.Struct<{
        readonly name: Schema.String;
        readonly type: Schema.Literal<"score">;
        readonly score: Schema.Number;
        readonly probabilities: Schema.$Array<Schema.Struct<{
            readonly value: Schema.Int;
            readonly label: Schema.String;
            readonly probability: Schema.Number;
        }>>;
        readonly confidence: Schema.Number;
    }>, Schema.Struct<{
        readonly name: Schema.String;
        readonly type: Schema.Literal<"error">;
        readonly reason: Schema.Codec<ErrorReason, ErrorReason, never, never>;
        readonly message: Schema.optional<Schema.String>;
    }>]>>;
    readonly usage: Schema.optional<typeof DecisionUsage>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, {}>;
export declare class DecisionResponse extends DecisionResponse_base {
}
export type DecisionResponseFor<Questions extends DecisionQuestions> = Omit<DecisionResponse, "answers"> & {
    readonly answers: AnswersFor<Questions>;
};
/** Normalize decision request input into a plain `DecisionRequest`; a plain object `input` becomes one `json` part. */
export declare const request: <const Model extends DecisionModel, const Questions extends DecisionQuestions>(input: DecisionRequestInput<Model, Questions>) => DecisionRequest<Model, Questions>;
export declare function generate<const Model extends DecisionModel, const Questions extends DecisionQuestions>(input: DecisionRequestInput<Model, Questions>): Effect.Effect<DecisionResponseFor<Questions>, AIError, Service>;
export declare const Decision: {
    readonly request: typeof request;
    readonly generate: typeof generate;
};
export {};
