/** Error codes a provider error body carries, in their original case. The first is its primary code (`AIError.code`). */
export declare function providerCodes(value: unknown): string[];
export declare function awsErrorType(value: unknown): string[];
