import { Context } from "effect";
import { MediaClient } from "./media-client.js";
import { type ImageEvent, type ImageRequest, type ImageResponse } from "./image.js";
export type Interface = MediaClient.Interface<ImageRequest, ImageEvent, ImageResponse>;
declare const ImageClientService_base: Context.ServiceClass<ImageClientService, "@opencode/ImageClient", Interface>;
export declare class ImageClientService extends ImageClientService_base {
}
export declare const Service: typeof ImageClientService;
export type Service = ImageClientService;
export declare const ImageClient: {
    readonly responseEvents: (response: ImageResponse) => readonly ({
        readonly type: "image-partial";
        readonly index: number;
        readonly image: import("./media.js").Asset;
    } | {
        readonly type: "image";
        readonly index: number;
        readonly image: import("./media.js").Asset;
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly type: "finish";
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    })[];
    readonly layer: import("effect/Layer").Layer<ImageClientService, never, import("./route.js").RequestExecutorService>;
    readonly generate: (request: ImageRequest<import("./image.js").ImageModel<{
        readonly [x: string]: unknown;
    }>>, options?: import("./generation.js").AwaitOptions) => import("effect/Effect").Effect<ImageResponse, import("./public.js").AIError, ImageClientService>;
    readonly stream: (request: ImageRequest<import("./image.js").ImageModel<{
        readonly [x: string]: unknown;
    }>>, options?: import("./generation.js").AwaitOptions) => import("effect/Stream").Stream<{
        readonly type: "image-partial";
        readonly index: number;
        readonly image: import("./media.js").Asset;
    } | {
        readonly type: "image";
        readonly index: number;
        readonly image: import("./media.js").Asset;
    } | {
        readonly type: "finish";
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | import("./generation.js").Observation, import("./public.js").AIError, ImageClientService>;
    readonly start: (request: ImageRequest<import("./image.js").ImageModel<{
        readonly [x: string]: unknown;
    }>>) => import("effect/Effect").Effect<import("./generation.js").Generation<ImageResponse>, import("./public.js").AIError, ImageClientService>;
    readonly resume: (model: import("./image.js").ImageModel<{
        readonly [x: string]: unknown;
    }>, token: unknown) => import("effect/Effect").Effect<import("./generation.js").Generation<ImageResponse>, import("./public.js").AIError, ImageClientService>;
    readonly Service: typeof ImageClientService;
};
export {};
