import { Context } from "effect";
import { MediaClient } from "./media-client.js";
import { type VideoEvent, type VideoRequest, type VideoResponse } from "./video.js";
export type Interface = MediaClient.Interface<VideoRequest, VideoEvent, VideoResponse>;
declare const VideoClientService_base: Context.ServiceClass<VideoClientService, "@opencode/VideoClient", Interface>;
export declare class VideoClientService extends VideoClientService_base {
}
export declare const Service: typeof VideoClientService;
export type Service = VideoClientService;
export declare const VideoClient: {
    readonly responseEvents: (response: VideoResponse) => readonly ({
        readonly type: "video";
        readonly index: number;
        readonly video: import("./media.js").Asset;
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly type: "finish";
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    })[];
    readonly layer: import("effect/Layer").Layer<VideoClientService, never, import("./route.js").RequestExecutorService>;
    readonly generate: (request: VideoRequest, options?: import("./generation.js").AwaitOptions) => import("effect/Effect").Effect<VideoResponse, import("./public.js").AIError, VideoClientService>;
    readonly stream: (request: VideoRequest, options?: import("./generation.js").AwaitOptions) => import("effect/Stream").Stream<{
        readonly type: "video";
        readonly index: number;
        readonly video: import("./media.js").Asset;
    } | {
        readonly type: "finish";
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | import("./generation.js").Observation, import("./public.js").AIError, VideoClientService>;
    readonly start: (request: VideoRequest) => import("effect/Effect").Effect<import("./generation.js").Generation<VideoResponse>, import("./public.js").AIError, VideoClientService>;
    readonly resume: (model: import("./video.js").VideoModel<{
        readonly [x: string]: unknown;
    }>, token: unknown) => import("effect/Effect").Effect<import("./generation.js").Generation<VideoResponse>, import("./public.js").AIError, VideoClientService>;
    readonly Service: typeof VideoClientService;
};
export {};
