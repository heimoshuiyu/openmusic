import { LLM } from "./llm.js";
/** The Effect API: the same shape as `ai` from `@opencode/ai`, returning `Effect` and `Stream`. */
export declare const ai: {
    readonly request: typeof LLM.request;
    readonly generate: typeof LLM.generate;
    readonly stream: typeof LLM.stream;
    readonly loop: typeof LLM.loop;
    readonly collect: typeof LLM.collect;
    readonly compact: typeof LLM.compact;
    readonly canCompact: typeof LLM.canCompact;
    readonly image: {
        readonly request: typeof import("./image.js").request;
        readonly generate: typeof import("./image.js").generate;
        readonly stream: typeof import("./image.js").stream;
        readonly start: typeof import("./image.js").start;
        readonly resume: typeof import("./image.js").resume;
    };
    readonly decision: {
        readonly request: typeof import("./decision.js").request;
        readonly generate: typeof import("./decision.js").generate;
    };
    /** Experimental: may change without compatibility guarantees. */
    readonly experimental: {
        readonly speech: {
            readonly request: typeof import("./speech.js").request;
            readonly generate: typeof import("./speech.js").generate;
            readonly stream: typeof import("./speech.js").stream;
        };
        readonly transcription: {
            readonly request: typeof import("./transcription.js").request;
            readonly generate: typeof import("./transcription.js").generate;
            readonly stream: typeof import("./transcription.js").stream;
            readonly start: typeof import("./transcription.js").start;
            readonly resume: typeof import("./transcription.js").resume;
        };
        readonly video: {
            readonly request: typeof import("./video.js").request;
            readonly start: typeof import("./video.js").start;
            readonly generate: typeof import("./video.js").generate;
            readonly resume: typeof import("./video.js").resume;
            readonly stream: typeof import("./video.js").stream;
        };
    };
};
export { AIClient } from "./ai-client.js";
export { LLMClient } from "./route/client.js";
export { ImageClient } from "./image-client.js";
export { Auth } from "./route/auth.js";
export { ProviderPackage } from "./provider-package.js";
export type { LLMClientService } from "./route/client.js";
export { DecisionClient } from "./decision-client.js";
export { DecisionRoute } from "./route/decision.js";
export { Generation } from "./generation.js";
export { ToolFailure, emptyInputJsonSchema, toDefinitions, tool } from "./tool.js";
export { ToolRuntime } from "./tool-runtime.js";
export type { ToolSettlement } from "./tool-runtime.js";
export * from "./public.js";
