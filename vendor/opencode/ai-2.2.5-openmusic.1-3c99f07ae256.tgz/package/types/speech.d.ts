import { Effect, Schema, Stream } from "effect";
import { Media } from "./media.js";
import { MediaModel } from "./media-model.js";
import { MediaRoute } from "./route/media.js";
import { AIError, type OpenString, type BaseRequest } from "./schema/index.js";
import { Service } from "./speech-client.js";
export type SpeechOptions = MediaModel.Options;
export type SpeechRoute = MediaRoute.AnyRoute<SpeechRequest, SpeechEvent, SpeechResponse>;
export declare class SpeechModel<Options extends SpeechOptions = SpeechOptions> extends MediaModel<SpeechRoute, Options> {
    protected readonly _SpeechModel: void;
    /** The number of type arguments selects the kind: `<Options>`, `<Options, Frame, State>`, or `<Options, Token>`. */
    static fromRoute<Options extends SpeechOptions>(route: MediaModel.InlineRouteInput<SpeechRequest<SpeechModel<Options>>, SpeechResponse>, input: MediaRoute.ModelInput): SpeechModel<Options>;
    static fromRoute<Options extends SpeechOptions, Frame, State>(route: MediaModel.StreamRouteInput<SpeechRequest<SpeechModel<Options>>, SpeechEvent, Frame, State>, input: MediaRoute.ModelInput): SpeechModel<Options>;
    static fromRoute<Options extends SpeechOptions, Token>(route: MediaModel.QueuedRouteInput<SpeechRequest<SpeechModel<Options>>, SpeechResponse, Token>, input: MediaRoute.ModelInput): SpeechModel<Options>;
}
export declare const SpeechModelSchema: Schema.declare<SpeechModel<{
    readonly [x: string]: unknown;
}>, SpeechModel<{
    readonly [x: string]: unknown;
}>>;
/** Provider-native: a name on OpenAI and Gemini, a voice id on ElevenLabs and Cartesia; `{ id }` is an OpenAI custom voice. */
export declare const SpeechVoice: Schema.Union<readonly [Schema.String, Schema.Struct<{
    readonly id: Schema.String;
}>]>;
export type SpeechVoice = Schema.Schema.Type<typeof SpeechVoice>;
export type SpeechFormat = OpenString<"mp3" | "wav" | "pcm" | "opus" | "aac" | "flac">;
/** Granularity is provider-native: characters on ElevenLabs, words on Cartesia. */
export declare const SpeechTimestamp: Schema.Struct<{
    readonly text: Schema.String;
    readonly startSeconds: Schema.Number;
    readonly endSeconds: Schema.Number;
}>;
export type SpeechTimestamp = Schema.Schema.Type<typeof SpeechTimestamp>;
declare const SpeechRequestSchema: Schema.Struct<{
    readonly model: Schema.declare<SpeechModel<{
        readonly [x: string]: unknown;
    }>, SpeechModel<{
        readonly [x: string]: unknown;
    }>>;
    readonly text: Schema.String;
    readonly voice: Schema.optional<Schema.Union<readonly [Schema.String, Schema.Struct<{
        readonly id: Schema.String;
    }>]>>;
    readonly format: Schema.optional<Schema.String>;
    readonly speed: Schema.optional<Schema.Number>;
    readonly language: Schema.optional<Schema.String>;
    readonly instructions: Schema.optional<Schema.String>;
    readonly timestamps: Schema.optional<Schema.Boolean>;
    readonly providerOptions: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
}>;
/** A normalized speech request, the plain object `Speech.request(...)` returns. */
export type SpeechRequest<Model extends SpeechModel = SpeechModel> = Omit<typeof SpeechRequestSchema.Type, "model" | "providerOptions" | "format"> & BaseRequest<Model, SpeechModelOptions<Model>> & {
    readonly format?: SpeechFormat;
};
export type SpeechModelOptions<Model> = Model extends SpeechModel<infer Options> ? Options : never;
/** Input accepted by `Speech.request` and the calls; a `SpeechRequest` is also a valid input. */
export type SpeechRequestInput<Model extends SpeechModel = SpeechModel> = Omit<SpeechRequest<Model>, "providerOptions"> & {
    readonly providerOptions?: NoInfer<SpeechModelOptions<Model>>;
};
declare const SpeechResponse_base: Schema.Class<SpeechResponse, Schema.Struct<{
    /** The complete audio. Headerless PCM carries `info.encoding`, `info.sampleRate`, and `info.channels`. */
    readonly audio: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly timestamps: Schema.optional<Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
    }>>>;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, {}>;
export declare class SpeechResponse extends SpeechResponse_base {
}
export declare const SpeechAudioDeltaEvent: Schema.Struct<{
    readonly type: Schema.tag<"audio-delta">;
    readonly chunk: Schema.Uint8Array;
}>;
export declare const SpeechTimestampsEvent: Schema.Struct<{
    readonly type: Schema.tag<"timestamps">;
    readonly items: Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
    }>>;
}>;
/** `audio` is every `audio-delta` chunk concatenated, so the route holds the whole clip in memory until `finish`. */
export declare const SpeechFinishEvent: Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly audio: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
declare const speechEventTagged: Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
    readonly type: Schema.tag<"generation-queued">;
    readonly id: Schema.String;
    readonly position: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"generation-progress">;
    readonly id: Schema.String;
    readonly progress: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"audio-delta">;
    readonly chunk: Schema.Uint8Array;
}>, Schema.Struct<{
    readonly type: Schema.tag<"timestamps">;
    readonly items: Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
    }>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly audio: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>]>;
export declare const SpeechEvent: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.tag<"generation-queued">;
    readonly id: Schema.String;
    readonly position: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"generation-progress">;
    readonly id: Schema.String;
    readonly progress: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"audio-delta">;
    readonly chunk: Schema.Uint8Array;
}>, Schema.Struct<{
    readonly type: Schema.tag<"timestamps">;
    readonly items: Schema.$Array<Schema.Struct<{
        readonly text: Schema.String;
        readonly startSeconds: Schema.Number;
        readonly endSeconds: Schema.Number;
    }>>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly audio: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>]> & {
    readonly tag: "type";
    readonly discriminants: readonly ["generation-queued", "generation-progress", "audio-delta", "timestamps", "finish"];
    readonly cases: {
        "audio-delta": Schema.Struct<{
            readonly type: Schema.tag<"audio-delta">;
            readonly chunk: Schema.Uint8Array;
        }>;
        finish: Schema.Struct<{
            readonly type: Schema.tag<"finish">;
            readonly audio: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"bytes">;
                    readonly data: Schema.Uint8Array;
                    readonly mediaType: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"base64">;
                    readonly data: Schema.String;
                    readonly mediaType: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"url">;
                    readonly url: Schema.String;
                    readonly mediaType: Schema.optional<Schema.String>;
                    readonly expiresAt: Schema.optional<Schema.Number>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"ref">;
                    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                    readonly id: Schema.String;
                    readonly mediaType: Schema.optional<Schema.String>;
                }>]>;
                readonly info: Schema.optional<Schema.Struct<{
                    readonly width: Schema.optional<Schema.Number>;
                    readonly height: Schema.optional<Schema.Number>;
                    readonly durationSeconds: Schema.optional<Schema.Number>;
                    readonly sampleRate: Schema.optional<Schema.Number>;
                    readonly channels: Schema.optional<Schema.Number>;
                    readonly encoding: Schema.optional<Schema.String>;
                    readonly format: Schema.optional<Schema.String>;
                }>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>, never, never>;
            readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"tokens">;
                readonly input: Schema.optional<Schema.Number>;
                readonly output: Schema.optional<Schema.Number>;
                readonly total: Schema.optional<Schema.Number>;
                readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"seconds">;
                readonly seconds: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"characters">;
                readonly characters: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"credits">;
                readonly credits: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"compute">;
                readonly seconds: Schema.Number;
            }>]>>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "generation-progress": Schema.Struct<{
            readonly type: Schema.tag<"generation-progress">;
            readonly id: Schema.String;
            readonly progress: Schema.optional<Schema.Number>;
        }>;
        "generation-queued": Schema.Struct<{
            readonly type: Schema.tag<"generation-queued">;
            readonly id: Schema.String;
            readonly position: Schema.optional<Schema.Number>;
        }>;
        timestamps: Schema.Struct<{
            readonly type: Schema.tag<"timestamps">;
            readonly items: Schema.$Array<Schema.Struct<{
                readonly text: Schema.String;
                readonly startSeconds: Schema.Number;
                readonly endSeconds: Schema.Number;
            }>>;
        }>;
    };
    readonly isAnyOf: <const Keys>(keys: readonly Keys[]) => (value: {
        readonly type: "audio-delta";
        readonly chunk: Uint8Array<ArrayBufferLike>;
    } | {
        readonly type: "timestamps";
        readonly items: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
        }[];
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly type: "finish";
        readonly audio: Media.Asset;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }) => value is Extract<{
        readonly type: "audio-delta";
        readonly chunk: Uint8Array<ArrayBufferLike>;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "timestamps";
        readonly items: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
        }[];
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "finish";
        readonly audio: Media.Asset;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }>;
    readonly guards: {
        "audio-delta": (u: unknown) => u is {
            readonly type: "audio-delta";
            readonly chunk: Uint8Array<ArrayBufferLike>;
        };
        finish: (u: unknown) => u is {
            readonly type: "finish";
            readonly audio: Media.Asset;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "generation-progress": (u: unknown) => u is {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        };
        "generation-queued": (u: unknown) => u is {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        };
        timestamps: (u: unknown) => u is {
            readonly type: "timestamps";
            readonly items: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
            }[];
        };
    };
    readonly match: {
        <Handlers extends { [K in "audio-delta" | "finish" | "generation-progress" | "generation-queued" | "timestamps"]: (value: {
            readonly "audio-delta": Schema.Struct<{
                readonly type: Schema.tag<"audio-delta">;
                readonly chunk: Schema.Uint8Array;
            }>;
            readonly finish: Schema.Struct<{
                readonly type: Schema.tag<"finish">;
                readonly audio: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"bytes">;
                        readonly data: Schema.Uint8Array;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"base64">;
                        readonly data: Schema.String;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"url">;
                        readonly url: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                        readonly expiresAt: Schema.optional<Schema.Number>;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"ref">;
                        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                        readonly id: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                    }>]>;
                    readonly info: Schema.optional<Schema.Struct<{
                        readonly width: Schema.optional<Schema.Number>;
                        readonly height: Schema.optional<Schema.Number>;
                        readonly durationSeconds: Schema.optional<Schema.Number>;
                        readonly sampleRate: Schema.optional<Schema.Number>;
                        readonly channels: Schema.optional<Schema.Number>;
                        readonly encoding: Schema.optional<Schema.String>;
                        readonly format: Schema.optional<Schema.String>;
                    }>>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>, never, never>;
                readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"tokens">;
                    readonly input: Schema.optional<Schema.Number>;
                    readonly output: Schema.optional<Schema.Number>;
                    readonly total: Schema.optional<Schema.Number>;
                    readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"seconds">;
                    readonly seconds: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"characters">;
                    readonly characters: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"credits">;
                    readonly credits: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"compute">;
                    readonly seconds: Schema.Number;
                }>]>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "generation-progress": Schema.Struct<{
                readonly type: Schema.tag<"generation-progress">;
                readonly id: Schema.String;
                readonly progress: Schema.optional<Schema.Number>;
            }>;
            readonly "generation-queued": Schema.Struct<{
                readonly type: Schema.tag<"generation-queued">;
                readonly id: Schema.String;
                readonly position: Schema.optional<Schema.Number>;
            }>;
            readonly timestamps: Schema.Struct<{
                readonly type: Schema.tag<"timestamps">;
                readonly items: Schema.$Array<Schema.Struct<{
                    readonly text: Schema.String;
                    readonly startSeconds: Schema.Number;
                    readonly endSeconds: Schema.Number;
                }>>;
            }>;
        }[K]["Type"]) => any; }>(value: {
            readonly type: "audio-delta";
            readonly chunk: Uint8Array<ArrayBufferLike>;
        } | {
            readonly type: "timestamps";
            readonly items: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
            }[];
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly audio: Media.Asset;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, cases: Handlers): import("effect/Unify").Unify<ReturnType<Handlers["audio-delta" | "finish" | "generation-progress" | "generation-queued" | "timestamps"]>>;
        <Handlers extends { [K in "audio-delta" | "finish" | "generation-progress" | "generation-queued" | "timestamps"]: (value: {
            readonly "audio-delta": Schema.Struct<{
                readonly type: Schema.tag<"audio-delta">;
                readonly chunk: Schema.Uint8Array;
            }>;
            readonly finish: Schema.Struct<{
                readonly type: Schema.tag<"finish">;
                readonly audio: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"bytes">;
                        readonly data: Schema.Uint8Array;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"base64">;
                        readonly data: Schema.String;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"url">;
                        readonly url: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                        readonly expiresAt: Schema.optional<Schema.Number>;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"ref">;
                        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                        readonly id: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                    }>]>;
                    readonly info: Schema.optional<Schema.Struct<{
                        readonly width: Schema.optional<Schema.Number>;
                        readonly height: Schema.optional<Schema.Number>;
                        readonly durationSeconds: Schema.optional<Schema.Number>;
                        readonly sampleRate: Schema.optional<Schema.Number>;
                        readonly channels: Schema.optional<Schema.Number>;
                        readonly encoding: Schema.optional<Schema.String>;
                        readonly format: Schema.optional<Schema.String>;
                    }>>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>, never, never>;
                readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"tokens">;
                    readonly input: Schema.optional<Schema.Number>;
                    readonly output: Schema.optional<Schema.Number>;
                    readonly total: Schema.optional<Schema.Number>;
                    readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"seconds">;
                    readonly seconds: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"characters">;
                    readonly characters: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"credits">;
                    readonly credits: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"compute">;
                    readonly seconds: Schema.Number;
                }>]>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "generation-progress": Schema.Struct<{
                readonly type: Schema.tag<"generation-progress">;
                readonly id: Schema.String;
                readonly progress: Schema.optional<Schema.Number>;
            }>;
            readonly "generation-queued": Schema.Struct<{
                readonly type: Schema.tag<"generation-queued">;
                readonly id: Schema.String;
                readonly position: Schema.optional<Schema.Number>;
            }>;
            readonly timestamps: Schema.Struct<{
                readonly type: Schema.tag<"timestamps">;
                readonly items: Schema.$Array<Schema.Struct<{
                    readonly text: Schema.String;
                    readonly startSeconds: Schema.Number;
                    readonly endSeconds: Schema.Number;
                }>>;
            }>;
        }[K]["Type"]) => any; }>(cases: Handlers): (value: {
            readonly type: "audio-delta";
            readonly chunk: Uint8Array<ArrayBufferLike>;
        } | {
            readonly type: "timestamps";
            readonly items: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
            }[];
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly audio: Media.Asset;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }) => import("effect/Unify").Unify<ReturnType<Handlers["audio-delta" | "finish" | "generation-progress" | "generation-queued" | "timestamps"]>>;
    };
    readonly matchOrElse: {
        <Handlers, OrElse>(value: {
            readonly type: "audio-delta";
            readonly chunk: Uint8Array<ArrayBufferLike>;
        } | {
            readonly type: "timestamps";
            readonly items: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
            }[];
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly audio: Media.Asset;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, cases: Handlers & {
            readonly "audio-delta"?: ((value: {
                readonly type: "audio-delta";
                readonly chunk: Uint8Array<ArrayBufferLike>;
            }) => any) | undefined;
            readonly finish?: ((value: {
                readonly type: "finish";
                readonly audio: Media.Asset;
                readonly usage?: {
                    readonly type: "seconds";
                    readonly seconds: number;
                } | {
                    readonly type: "characters";
                    readonly characters: number;
                } | {
                    readonly type: "credits";
                    readonly credits: number;
                } | {
                    readonly type: "compute";
                    readonly seconds: number;
                } | {
                    readonly type: "tokens";
                    readonly input?: number | undefined;
                    readonly output?: number | undefined;
                    readonly total?: number | undefined;
                    readonly details?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                } | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "generation-progress"?: ((value: {
                readonly type: "generation-progress";
                readonly id: string;
                readonly progress?: number | undefined;
            }) => any) | undefined;
            readonly "generation-queued"?: ((value: {
                readonly type: "generation-queued";
                readonly id: string;
                readonly position?: number | undefined;
            }) => any) | undefined;
            readonly timestamps?: ((value: {
                readonly type: "timestamps";
                readonly items: readonly {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                }[];
            }) => any) | undefined;
        } & (Exclude<keyof Handlers, "audio-delta" | "finish" | "generation-progress" | "generation-queued" | "timestamps"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
            readonly type: "audio-delta";
            readonly chunk: Uint8Array<ArrayBufferLike>;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "timestamps";
            readonly items: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
            }[];
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "finish";
            readonly audio: Media.Asset;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }>) => any)): import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
        <Handlers, OrElse>(cases: Handlers & {
            readonly "audio-delta"?: ((value: {
                readonly type: "audio-delta";
                readonly chunk: Uint8Array<ArrayBufferLike>;
            }) => any) | undefined;
            readonly finish?: ((value: {
                readonly type: "finish";
                readonly audio: Media.Asset;
                readonly usage?: {
                    readonly type: "seconds";
                    readonly seconds: number;
                } | {
                    readonly type: "characters";
                    readonly characters: number;
                } | {
                    readonly type: "credits";
                    readonly credits: number;
                } | {
                    readonly type: "compute";
                    readonly seconds: number;
                } | {
                    readonly type: "tokens";
                    readonly input?: number | undefined;
                    readonly output?: number | undefined;
                    readonly total?: number | undefined;
                    readonly details?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                } | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "generation-progress"?: ((value: {
                readonly type: "generation-progress";
                readonly id: string;
                readonly progress?: number | undefined;
            }) => any) | undefined;
            readonly "generation-queued"?: ((value: {
                readonly type: "generation-queued";
                readonly id: string;
                readonly position?: number | undefined;
            }) => any) | undefined;
            readonly timestamps?: ((value: {
                readonly type: "timestamps";
                readonly items: readonly {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                }[];
            }) => any) | undefined;
        } & (Exclude<keyof Handlers, "audio-delta" | "finish" | "generation-progress" | "generation-queued" | "timestamps"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
            readonly type: "audio-delta";
            readonly chunk: Uint8Array<ArrayBufferLike>;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "timestamps";
            readonly items: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
            }[];
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "finish";
            readonly audio: Media.Asset;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }>) => any)): (value: {
            readonly type: "audio-delta";
            readonly chunk: Uint8Array<ArrayBufferLike>;
        } | {
            readonly type: "timestamps";
            readonly items: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
            }[];
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly audio: Media.Asset;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }) => import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
    };
} & {
    is: {
        generationQueued: (u: unknown) => u is {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        };
        generationProgress: (u: unknown) => u is {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        };
        audioDelta: (u: unknown) => u is {
            readonly type: "audio-delta";
            readonly chunk: Uint8Array<ArrayBufferLike>;
        };
        timestamps: (u: unknown) => u is {
            readonly type: "timestamps";
            readonly items: readonly {
                readonly text: string;
                readonly startSeconds: number;
                readonly endSeconds: number;
            }[];
        };
        finish: (u: unknown) => u is {
            readonly type: "finish";
            readonly audio: Media.Asset;
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
    };
};
export type SpeechEvent = Schema.Schema.Type<typeof speechEventTagged>;
/** Normalize speech request input into a plain `SpeechRequest`. */
export declare const request: <const Model extends SpeechModel>(input: SpeechRequestInput<Model>) => SpeechRequest<Model>;
export declare function generate<const Model extends SpeechModel>(input: SpeechRequestInput<Model>): Effect.Effect<SpeechResponse, AIError, Service>;
export declare function stream<const Model extends SpeechModel>(input: SpeechRequestInput<Model>): Stream.Stream<SpeechEvent, AIError, Service>;
export declare const Speech: {
    readonly request: typeof request;
    readonly generate: typeof generate;
    readonly stream: typeof stream;
};
export {};
