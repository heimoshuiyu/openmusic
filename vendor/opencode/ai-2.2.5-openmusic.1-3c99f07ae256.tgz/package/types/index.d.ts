import { Effect, Layer, Schema } from "effect";
import { AIClient } from "./ai-client.js";
import { type DecisionModel, type DecisionQuestions, type DecisionRequestInput } from "./decision.js";
import type { AwaitOptions, Event, Snapshot } from "./generation.js";
import { type ImageModel, type ImageRequest, type ImageRequestInput } from "./image.js";
import { LLM } from "./llm.js";
import { Media } from "./media.js";
import { type CheckpointRequest, type CompactionRequest, type EndpointCompactOptions, type StreamOptions, type TriggerCompactOptions } from "./route/client.js";
import { RequestExecutor } from "./route/executor.js";
import { LanguageModel, type CompactionCheckpointResponse, type CompactionResponse, type LLMEvent, type LLMResponse } from "./schema/index.js";
import type { LoopObjectEvent, ObjectEvent, ObjectResponse, OutputSchema, OutputType, LLMLoopInput, LLMRequestInput } from "./llm.js";
import { type SpeechModel, type SpeechRequest, type SpeechRequestInput } from "./speech.js";
import { type TranscriptionModel, type TranscriptionRequest, type TranscriptionRequestInput } from "./transcription.js";
import type { NoExecute, ToolExecuteContext, ToolInput, ToolInputType, ToolOptions, ToolSchema } from "./tool.js";
import { type VideoModel, type VideoRequest, type VideoRequestInput } from "./video.js";
/**
 * Promise-first entrypoint for scripts and non-Effect callers. One `ManagedRuntime` hosts the LLM, image, video, speech,
 * transcription and decision clients over a request executor; every method runs the corresponding Effect API and rethrows
 * `AIError` unchanged. `file` and `write` load `node:fs/promises` on first use, so importing this module does not.
 */
export interface Options {
    /** Executor layer; defaults to `RequestExecutor.fetchLayer`. Inject a recorder or `RequestExecutor.middleware(fn)` here. */
    readonly layer?: Layer.Layer<RequestExecutor.Service>;
}
export interface RunOptions {
    readonly signal?: AbortSignal;
}
export type Services = AIClient.Services;
/**
 * Promise view of a `Generation`. Its fields are a snapshot taken when the handle was created; `refresh()` resolves to a
 * new handle rather than updating this one.
 */
export type GenerationHandle<Response> = Snapshot & {
    readonly snapshot: Snapshot;
    readonly terminal: boolean;
    /** Serializable JSON; pass it back to `resume` from another process. */
    readonly token: unknown;
    readonly await: (options?: AwaitOptions & RunOptions) => Promise<Response>;
    /** Status observations until the first terminal one, polling like `await`; abort throws `signal.reason`. */
    readonly events: (options?: AwaitOptions & RunOptions) => AsyncIterable<Event>;
    /** The result without polling; fails when the generation has not completed. */
    readonly result: (options?: RunOptions) => Promise<Response>;
    readonly refresh: (options?: RunOptions) => Promise<GenerationHandle<Response>>;
    readonly cancel: (options?: RunOptions) => Promise<void>;
};
export declare const make: (options?: Options) => {
    run: <A, E>(effect: Effect.Effect<A, E, Services>, options?: RunOptions) => Promise<A>;
    /** Decoded asset bytes, downloading `url` sources through the executor. */
    bytes: (asset: Media.Asset, options?: RunOptions) => Promise<Uint8Array<ArrayBufferLike>>;
    base64: (asset: Media.Asset, options?: RunOptions) => Promise<string>;
    /** Pull a `url` asset into owned bytes before the provider URL expires. */
    materialize: (asset: Media.Asset, options?: RunOptions) => Promise<Media.Asset>;
    /** Read a file into an asset like `Media.file`: sniffed media type, then the extension's. */
    file: (path: string, options?: Media.AssetOptions & RunOptions) => Promise<Media.Asset>;
    /** Write an asset's bytes like `Media.write`, downloading `url` sources through the executor. */
    write: (asset: Media.Asset, path: string, options?: RunOptions) => Promise<void>;
    request: typeof LLM.request;
    generate: {
        <const Model extends LanguageModel, S extends OutputSchema>(input: LLMRequestInput<Model> & {
            readonly schema: S;
        }, options?: StreamOptions & RunOptions): Promise<ObjectResponse<OutputType<S>>>;
        <const Model extends LanguageModel>(input: LLMRequestInput<Model>, options?: StreamOptions & RunOptions): Promise<LLMResponse>;
    };
    stream: {
        <const Model extends LanguageModel, S extends OutputSchema>(input: LLMRequestInput<Model> & {
            readonly schema: S;
        }, options?: StreamOptions & RunOptions): AsyncIterable<ObjectEvent<OutputType<S>>>;
        <const Model extends LanguageModel>(input: LLMRequestInput<Model>, options?: StreamOptions & RunOptions): AsyncIterable<LLMEvent>;
    };
    /** Stream model calls, running their tool calls, until the model stops calling tools or `until` is true. */
    loop: {
        <const Model extends LanguageModel, S extends OutputSchema>(input: LLMLoopInput<Model> & {
            readonly schema: S;
        }, options?: StreamOptions & RunOptions): AsyncIterable<LoopObjectEvent<OutputType<S>>>;
        <const Model extends LanguageModel>(input: LLMLoopInput<Model>, options?: StreamOptions & RunOptions): AsyncIterable<LLMEvent>;
    };
    collect: <Event extends LLMEvent>(events: AsyncIterable<Event>, options?: RunOptions) => Promise<LLM.CollectResult<Event>>;
    /** Compact a Responses request: a replacement window, or a checkpoint with `mechanism: "trigger"`. */
    compact: {
        (request: CheckpointRequest, options: TriggerCompactOptions & RunOptions): Promise<CompactionCheckpointResponse>;
        (request: CompactionRequest, options?: EndpointCompactOptions & RunOptions): Promise<CompactionResponse>;
    };
    canCompact: typeof LLM.canCompact;
    image: {
        request: typeof import("./image.js").request;
        generate: <const Model extends ImageModel>(input: ImageRequestInput<Model> | ImageRequest, options?: AwaitOptions & RunOptions) => Promise<import("./image.js").ImageResponse>;
        stream: <const Model extends ImageModel>(input: ImageRequestInput<Model> | ImageRequest, options?: AwaitOptions & RunOptions) => AsyncIterable<{
            readonly type: "image-partial";
            readonly index: number;
            readonly image: Media.Asset;
        } | {
            readonly type: "image";
            readonly index: number;
            readonly image: Media.Asset;
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }>;
        start: <const Model extends ImageModel>(input: ImageRequestInput<Model> | ImageRequest, options?: RunOptions) => Promise<GenerationHandle<import("./image.js").ImageResponse>>;
        resume: (model: ImageModel, token: unknown, options?: RunOptions) => Promise<GenerationHandle<import("./image.js").ImageResponse>>;
    };
    decision: {
        request: typeof import("./decision.js").request;
        generate: <const Model extends DecisionModel, const Questions extends DecisionQuestions>(input: DecisionRequestInput<Model, Questions>, options?: RunOptions) => Promise<import("./decision.js").DecisionResponseFor<Questions>>;
    };
    /** Experimental: may change without compatibility guarantees. */
    experimental: {
        speech: {
            request: typeof import("./speech.js").request;
            generate: <const Model extends SpeechModel>(input: SpeechRequestInput<Model> | SpeechRequest, options?: RunOptions) => Promise<import("./speech.js").SpeechResponse>;
            stream: <const Model extends SpeechModel>(input: SpeechRequestInput<Model> | SpeechRequest, options?: RunOptions) => AsyncIterable<{
                readonly type: "audio-delta";
                readonly chunk: Uint8Array<ArrayBufferLike>;
            } | {
                readonly type: "timestamps";
                readonly items: readonly {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                }[];
            } | {
                readonly type: "generation-queued";
                readonly id: string;
                readonly position?: number | undefined;
            } | {
                readonly type: "generation-progress";
                readonly id: string;
                readonly progress?: number | undefined;
            } | {
                readonly type: "finish";
                readonly audio: Media.Asset;
                readonly usage?: {
                    readonly type: "seconds";
                    readonly seconds: number;
                } | {
                    readonly type: "characters";
                    readonly characters: number;
                } | {
                    readonly type: "credits";
                    readonly credits: number;
                } | {
                    readonly type: "compute";
                    readonly seconds: number;
                } | {
                    readonly type: "tokens";
                    readonly input?: number | undefined;
                    readonly output?: number | undefined;
                    readonly total?: number | undefined;
                    readonly details?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                } | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }>;
        };
        transcription: {
            request: typeof import("./transcription.js").request;
            generate: <const Model extends TranscriptionModel>(input: TranscriptionRequestInput<Model> | TranscriptionRequest, options?: AwaitOptions & RunOptions) => Promise<import("./transcription.js").TranscriptionResponse>;
            stream: <const Model extends TranscriptionModel>(input: TranscriptionRequestInput<Model> | TranscriptionRequest, options?: AwaitOptions & RunOptions) => AsyncIterable<{
                readonly type: "text-delta";
                readonly delta: string;
            } | {
                readonly type: "segment";
                readonly segment: {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                    readonly speaker?: string | undefined;
                };
            } | {
                readonly type: "generation-queued";
                readonly id: string;
                readonly position?: number | undefined;
            } | {
                readonly type: "generation-progress";
                readonly id: string;
                readonly progress?: number | undefined;
            } | {
                readonly text: string;
                readonly segments?: readonly {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                    readonly speaker?: string | undefined;
                }[] | undefined;
                readonly words?: readonly {
                    readonly text: string;
                    readonly startSeconds: number;
                    readonly endSeconds: number;
                    readonly speaker?: string | undefined;
                    readonly confidence?: number | undefined;
                }[] | undefined;
                readonly language?: string | undefined;
                readonly durationSeconds?: number | undefined;
                readonly usage?: {
                    readonly type: "seconds";
                    readonly seconds: number;
                } | {
                    readonly type: "characters";
                    readonly characters: number;
                } | {
                    readonly type: "credits";
                    readonly credits: number;
                } | {
                    readonly type: "compute";
                    readonly seconds: number;
                } | {
                    readonly type: "tokens";
                    readonly input?: number | undefined;
                    readonly output?: number | undefined;
                    readonly total?: number | undefined;
                    readonly details?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                } | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
                readonly type: "finish";
            }>;
            start: <const Model extends TranscriptionModel>(input: TranscriptionRequestInput<Model> | TranscriptionRequest, options?: RunOptions) => Promise<GenerationHandle<import("./transcription.js").TranscriptionResponse>>;
            resume: (model: TranscriptionModel, token: unknown, options?: RunOptions) => Promise<GenerationHandle<import("./transcription.js").TranscriptionResponse>>;
        };
        video: {
            request: typeof import("./video.js").request;
            start: <const Model extends VideoModel>(input: VideoRequestInput<Model> | VideoRequest, options?: RunOptions) => Promise<GenerationHandle<import("./video.js").VideoResponse>>;
            generate: <const Model extends VideoModel>(input: VideoRequestInput<Model> | VideoRequest, options?: AwaitOptions & RunOptions) => Promise<import("./video.js").VideoResponse>;
            resume: (model: VideoModel, token: unknown, options?: RunOptions) => Promise<GenerationHandle<import("./video.js").VideoResponse>>;
            stream: <const Model extends VideoModel>(input: VideoRequestInput<Model> | VideoRequest, options?: AwaitOptions & RunOptions) => AsyncIterable<{
                readonly type: "video";
                readonly index: number;
                readonly video: Media.Asset;
            } | {
                readonly type: "generation-queued";
                readonly id: string;
                readonly position?: number | undefined;
            } | {
                readonly type: "generation-progress";
                readonly id: string;
                readonly progress?: number | undefined;
            } | {
                readonly type: "finish";
                readonly usage?: {
                    readonly type: "seconds";
                    readonly seconds: number;
                } | {
                    readonly type: "characters";
                    readonly characters: number;
                } | {
                    readonly type: "credits";
                    readonly credits: number;
                } | {
                    readonly type: "compute";
                    readonly seconds: number;
                } | {
                    readonly type: "tokens";
                    readonly input?: number | undefined;
                    readonly output?: number | undefined;
                    readonly total?: number | undefined;
                    readonly details?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                } | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }>;
        };
    };
    dispose: () => Promise<void>;
};
export type Client = ReturnType<typeof make>;
/** `tool` from `@opencode/ai/effect`, with an `execute` that returns a value or a Promise and throws to fail. */
export declare const tool: <Input extends ToolInput = typeof Schema.Unknown, Success extends ToolSchema<any> = typeof Schema.Unknown, Result extends Schema.Schema.Type<Success> | PromiseLike<Schema.Schema.Type<Success>> | NoExecute = NoExecute>(config: ToolOptions<Input, Success, (input: ToolInputType<Input>, context: Partial<ToolExecuteContext> & {
    signal: AbortSignal;
}) => Result>) => 0 extends 1 & Result ? import("./tool.js").ExecutableTool<Input, Success> : [Result, NoExecute] extends [NoExecute, Result] ? import("./tool.js").Tool<Input, Success> : import("./tool.js").ExecutableTool<Input, Success>;
/** Default client over `RequestExecutor.fetchLayer`; the runtime builds its layer on first use and holds nothing to dispose. */
export declare const ai: Omit<Client, "dispose">;
export * as AI from "./index.js";
export * from "./public.js";
