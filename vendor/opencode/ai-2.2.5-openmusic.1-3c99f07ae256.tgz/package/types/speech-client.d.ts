import { Context } from "effect";
import { MediaClient } from "./media-client.js";
import { type SpeechEvent, type SpeechRequest, type SpeechResponse } from "./speech.js";
export type Interface = MediaClient.Interface<SpeechRequest, SpeechEvent, SpeechResponse>;
declare const SpeechClientService_base: Context.ServiceClass<SpeechClientService, "@opencode/SpeechClient", Interface>;
export declare class SpeechClientService extends SpeechClientService_base {
}
export declare const Service: typeof SpeechClientService;
export type Service = SpeechClientService;
export declare const SpeechClient: {
    readonly responseEvents: (response: SpeechResponse) => readonly ({
        readonly type: "audio-delta";
        readonly chunk: Uint8Array<ArrayBufferLike>;
    } | {
        readonly type: "timestamps";
        readonly items: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
        }[];
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly type: "finish";
        readonly audio: import("./media.js").Asset;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    })[];
    readonly layer: import("effect/Layer").Layer<SpeechClientService, never, import("./route.js").RequestExecutorService>;
    readonly generate: (request: SpeechRequest, options?: import("./generation.js").AwaitOptions) => import("effect/Effect").Effect<SpeechResponse, import("./public.js").AIError, SpeechClientService>;
    readonly stream: (request: SpeechRequest, options?: import("./generation.js").AwaitOptions) => import("effect/Stream").Stream<{
        readonly type: "audio-delta";
        readonly chunk: Uint8Array<ArrayBufferLike>;
    } | {
        readonly type: "timestamps";
        readonly items: readonly {
            readonly text: string;
            readonly startSeconds: number;
            readonly endSeconds: number;
        }[];
    } | {
        readonly type: "finish";
        readonly audio: import("./media.js").Asset;
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    } | import("./generation.js").Observation, import("./public.js").AIError, SpeechClientService>;
    readonly start: (request: SpeechRequest) => import("effect/Effect").Effect<import("./generation.js").Generation<SpeechResponse>, import("./public.js").AIError, SpeechClientService>;
    readonly resume: (model: import("./speech.js").SpeechModel<{
        readonly [x: string]: unknown;
    }>, token: unknown) => import("effect/Effect").Effect<import("./generation.js").Generation<SpeechResponse>, import("./public.js").AIError, SpeechClientService>;
    readonly Service: typeof SpeechClientService;
};
export {};
