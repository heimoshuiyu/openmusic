import { Effect, Stream } from "effect";
import { AIError, LLMResponse, Message, Usage, LLMEvent, type FinishReasonDetails, type LLMRequest } from "./schema/index.js";
import type { DispatchResult, PendingCall } from "./tool-runtime.js";
/**
 * Client calls to answer before the next step. A call whose input was not valid JSON carries the error the model
 * gets back, so it can retry. A step is final when it calls `answerTool`, even alongside other tools, or when it hits
 * the output token limit, which may have cut its calls off.
 */
export declare const pendingCalls: (response: LLMResponse, answerTool?: string) => ReadonlyArray<PendingCall>;
/** The step's assistant message followed by one tool message per call, in call order. */
export declare const stepMessages: (response: LLMResponse, calls: ReadonlyArray<PendingCall>, results: ReadonlyArray<DispatchResult>) => ReadonlyArray<Message>;
/**
 * The request for the step after `response`, with its messages and tool results appended. A caller's forced
 * `toolChoice` applies to the first step only; with `keepForcedChoice` (the answer tool's) it stays.
 */
export declare const nextRequest: (request: LLMRequest, response: LLMResponse, calls: ReadonlyArray<PendingCall>, results: ReadonlyArray<DispatchResult>, keepForcedChoice: boolean) => LLMRequest;
/** Sum usage across steps. */
export declare const addUsage: (total: Usage | undefined, step: Usage | undefined) => Usage | undefined;
/** The result of `collect`: every step of a stream from `stream` or `loop`, folded into one value. */
export interface Collected {
    /** Text of the final step. */
    readonly text: string;
    /** One response per model call, in order. */
    readonly steps: ReadonlyArray<LLMResponse>;
    /** Each step's assistant message followed by its tool results, ready to append to the request's messages. */
    readonly messages: ReadonlyArray<Message>;
    /** Usage from the terminal `finish`, summed across steps for a loop. */
    readonly usage?: Usage;
    readonly finishReason: FinishReasonDetails;
}
type FinishOf<Event> = Extract<Event, {
    readonly type: "finish";
}>;
/** `Collected`, plus `object` when the stream was started with `schema`. */
export type CollectResult<Event> = "object" extends keyof FinishOf<Event> ? Collected & Pick<FinishOf<Event>, "object"> : Collected;
/** Run a stream from `stream` or `loop` to the end and fold its events into the final result. */
export declare function collect<Event extends LLMEvent, E, R>(events: Stream.Stream<Event, E, R>): Effect.Effect<CollectResult<Event>, E | AIError, R>;
export {};
