import { Effect, Schema, Stream } from "effect";
import { Generation, type AwaitOptions } from "./generation.js";
import { Media } from "./media.js";
import { MediaModel } from "./media-model.js";
import { MediaRoute } from "./route/media.js";
import { AIError, type OpenString, type BaseRequest } from "./schema/index.js";
import { Service } from "./image-client.js";
export type ImageOptions = MediaModel.Options;
export type ImageRoute = MediaRoute.AnyRoute<ImageRequest, ImageEvent, ImageResponse>;
export declare class ImageModel<Options extends ImageOptions = ImageOptions> extends MediaModel<ImageRoute, Options> {
    protected readonly _ImageModel: void;
    /** The number of type arguments selects the kind: `<Options>`, `<Options, Frame, State>`, or `<Options, Token>`. */
    static fromRoute<Options extends ImageOptions>(route: MediaModel.InlineRouteInput<ImageRequest<ImageModel<Options>>, ImageResponse>, input: MediaRoute.ModelInput): ImageModel<Options>;
    static fromRoute<Options extends ImageOptions, Frame, State>(route: MediaModel.StreamRouteInput<ImageRequest<ImageModel<Options>>, ImageEvent, Frame, State>, input: MediaRoute.ModelInput): ImageModel<Options>;
    static fromRoute<Options extends ImageOptions, Token>(route: MediaModel.QueuedRouteInput<ImageRequest<ImageModel<Options>>, ImageResponse, Token>, input: MediaRoute.ModelInput): ImageModel<Options>;
}
export declare const ImageModelSchema: Schema.declare<ImageModel<{
    readonly [x: string]: unknown;
}>, ImageModel<{
    readonly [x: string]: unknown;
}>>;
export type ImageAspectRatio = Media.AspectRatio;
export declare const ImageAspectRatio: Schema.declare<`${number}:${number}`, `${number}:${number}`>;
/** Size tier: `1K` is about as many pixels as 1024×1024 at the requested aspect, `2K` as 2048×2048. */
export type ImageResolution = OpenString<"1K" | "2K" | "4K">;
/** A normalized image request, the plain object `ai.image.request(...)` returns. */
export interface ImageRequest<Model extends ImageModel = ImageModel> extends BaseRequest<Model, ImageModelOptions<Model>> {
    readonly prompt: string;
    /** Edit sources or style/subject references, in order. */
    readonly images?: ReadonlyArray<Media.Asset>;
    readonly n?: number;
    readonly aspect?: ImageAspectRatio;
    readonly resolution?: ImageResolution;
}
export type ImageModelOptions<Model> = Model extends ImageModel<infer Options> ? Options : never;
/** Input accepted by `ai.image.request`, `generate`, `stream` and `start`. An `ImageRequest` is also a valid input. */
export type ImageRequestInput<Model extends ImageModel = ImageModel> = Omit<ImageRequest<Model>, "images" | "providerOptions"> & {
    /** Edit sources or style/subject references, in order: assets or plain data with a detectable type. */
    readonly images?: ReadonlyArray<Media.Input>;
    readonly providerOptions?: NoInfer<ImageModelOptions<Model>>;
};
declare const ImageResponse_base: Schema.Class<ImageResponse, Schema.Struct<{
    readonly images: Schema.$Array<Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>>;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, {}>;
export declare class ImageResponse extends ImageResponse_base {
    get image(): Media.Asset;
}
/** The `index`-th lower-fidelity preview of an image still generating; the `image` event supersedes it. */
export declare const ImagePartialEvent: Schema.Struct<{
    readonly type: Schema.tag<"image-partial">;
    readonly index: Schema.Number;
    readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
}>;
export declare const ImageOutputEvent: Schema.Struct<{
    readonly type: Schema.tag<"image">;
    readonly index: Schema.Number;
    readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
}>;
export declare const ImageFinishEvent: Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>;
declare const imageEventTagged: Schema.toTaggedUnion<"type", readonly [Schema.Struct<{
    readonly type: Schema.tag<"generation-queued">;
    readonly id: Schema.String;
    readonly position: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"generation-progress">;
    readonly id: Schema.String;
    readonly progress: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"image-partial">;
    readonly index: Schema.Number;
    readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"image">;
    readonly index: Schema.Number;
    readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>]>;
export declare const ImageEvent: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.tag<"generation-queued">;
    readonly id: Schema.String;
    readonly position: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"generation-progress">;
    readonly id: Schema.String;
    readonly progress: Schema.optional<Schema.Number>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"image-partial">;
    readonly index: Schema.Number;
    readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"image">;
    readonly index: Schema.Number;
    readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
        readonly source: Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"bytes">;
            readonly data: Schema.Uint8Array;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"base64">;
            readonly data: Schema.String;
            readonly mediaType: Schema.String;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"url">;
            readonly url: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
            readonly expiresAt: Schema.optional<Schema.Number>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"ref">;
            readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
            readonly id: Schema.String;
            readonly mediaType: Schema.optional<Schema.String>;
        }>]>;
        readonly info: Schema.optional<Schema.Struct<{
            readonly width: Schema.optional<Schema.Number>;
            readonly height: Schema.optional<Schema.Number>;
            readonly durationSeconds: Schema.optional<Schema.Number>;
            readonly sampleRate: Schema.optional<Schema.Number>;
            readonly channels: Schema.optional<Schema.Number>;
            readonly encoding: Schema.optional<Schema.String>;
            readonly format: Schema.optional<Schema.String>;
        }>>;
        readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
    }>, never, never>;
}>, Schema.Struct<{
    readonly type: Schema.tag<"finish">;
    readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.Literal<"tokens">;
        readonly input: Schema.optional<Schema.Number>;
        readonly output: Schema.optional<Schema.Number>;
        readonly total: Schema.optional<Schema.Number>;
        readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"seconds">;
        readonly seconds: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"characters">;
        readonly characters: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"credits">;
        readonly credits: Schema.Number;
    }>, Schema.Struct<{
        readonly type: Schema.Literal<"compute">;
        readonly seconds: Schema.Number;
    }>]>>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>]> & {
    readonly tag: "type";
    readonly discriminants: readonly ["generation-queued", "generation-progress", "image-partial", "image", "finish"];
    readonly cases: {
        finish: Schema.Struct<{
            readonly type: Schema.tag<"finish">;
            readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"tokens">;
                readonly input: Schema.optional<Schema.Number>;
                readonly output: Schema.optional<Schema.Number>;
                readonly total: Schema.optional<Schema.Number>;
                readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"seconds">;
                readonly seconds: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"characters">;
                readonly characters: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"credits">;
                readonly credits: Schema.Number;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"compute">;
                readonly seconds: Schema.Number;
            }>]>>;
            readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
        }>;
        "generation-progress": Schema.Struct<{
            readonly type: Schema.tag<"generation-progress">;
            readonly id: Schema.String;
            readonly progress: Schema.optional<Schema.Number>;
        }>;
        "generation-queued": Schema.Struct<{
            readonly type: Schema.tag<"generation-queued">;
            readonly id: Schema.String;
            readonly position: Schema.optional<Schema.Number>;
        }>;
        image: Schema.Struct<{
            readonly type: Schema.tag<"image">;
            readonly index: Schema.Number;
            readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"bytes">;
                    readonly data: Schema.Uint8Array;
                    readonly mediaType: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"base64">;
                    readonly data: Schema.String;
                    readonly mediaType: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"url">;
                    readonly url: Schema.String;
                    readonly mediaType: Schema.optional<Schema.String>;
                    readonly expiresAt: Schema.optional<Schema.Number>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"ref">;
                    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                    readonly id: Schema.String;
                    readonly mediaType: Schema.optional<Schema.String>;
                }>]>;
                readonly info: Schema.optional<Schema.Struct<{
                    readonly width: Schema.optional<Schema.Number>;
                    readonly height: Schema.optional<Schema.Number>;
                    readonly durationSeconds: Schema.optional<Schema.Number>;
                    readonly sampleRate: Schema.optional<Schema.Number>;
                    readonly channels: Schema.optional<Schema.Number>;
                    readonly encoding: Schema.optional<Schema.String>;
                    readonly format: Schema.optional<Schema.String>;
                }>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>, never, never>;
        }>;
        "image-partial": Schema.Struct<{
            readonly type: Schema.tag<"image-partial">;
            readonly index: Schema.Number;
            readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                readonly source: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"bytes">;
                    readonly data: Schema.Uint8Array;
                    readonly mediaType: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"base64">;
                    readonly data: Schema.String;
                    readonly mediaType: Schema.String;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"url">;
                    readonly url: Schema.String;
                    readonly mediaType: Schema.optional<Schema.String>;
                    readonly expiresAt: Schema.optional<Schema.Number>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"ref">;
                    readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                    readonly id: Schema.String;
                    readonly mediaType: Schema.optional<Schema.String>;
                }>]>;
                readonly info: Schema.optional<Schema.Struct<{
                    readonly width: Schema.optional<Schema.Number>;
                    readonly height: Schema.optional<Schema.Number>;
                    readonly durationSeconds: Schema.optional<Schema.Number>;
                    readonly sampleRate: Schema.optional<Schema.Number>;
                    readonly channels: Schema.optional<Schema.Number>;
                    readonly encoding: Schema.optional<Schema.String>;
                    readonly format: Schema.optional<Schema.String>;
                }>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>, never, never>;
        }>;
    };
    readonly isAnyOf: <const Keys>(keys: readonly Keys[]) => (value: {
        readonly type: "image-partial";
        readonly index: number;
        readonly image: Media.Asset;
    } | {
        readonly type: "image";
        readonly index: number;
        readonly image: Media.Asset;
    } | {
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    } | {
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    } | {
        readonly type: "finish";
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }) => value is Extract<{
        readonly type: "image-partial";
        readonly index: number;
        readonly image: Media.Asset;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "image";
        readonly index: number;
        readonly image: Media.Asset;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "generation-queued";
        readonly id: string;
        readonly position?: number | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "generation-progress";
        readonly id: string;
        readonly progress?: number | undefined;
    }, {
        readonly type: Keys;
    }> | Extract<{
        readonly type: "finish";
        readonly usage?: {
            readonly type: "seconds";
            readonly seconds: number;
        } | {
            readonly type: "characters";
            readonly characters: number;
        } | {
            readonly type: "credits";
            readonly credits: number;
        } | {
            readonly type: "compute";
            readonly seconds: number;
        } | {
            readonly type: "tokens";
            readonly input?: number | undefined;
            readonly output?: number | undefined;
            readonly total?: number | undefined;
            readonly details?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly providerMetadata?: {
            readonly [x: string]: {
                readonly [x: string]: unknown;
            };
        } | undefined;
    }, {
        readonly type: Keys;
    }>;
    readonly guards: {
        finish: (u: unknown) => u is {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
        "generation-progress": (u: unknown) => u is {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        };
        "generation-queued": (u: unknown) => u is {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        };
        image: (u: unknown) => u is {
            readonly type: "image";
            readonly index: number;
            readonly image: Media.Asset;
        };
        "image-partial": (u: unknown) => u is {
            readonly type: "image-partial";
            readonly index: number;
            readonly image: Media.Asset;
        };
    };
    readonly match: {
        <Handlers extends { [K in "finish" | "generation-progress" | "generation-queued" | "image" | "image-partial"]: (value: {
            readonly finish: Schema.Struct<{
                readonly type: Schema.tag<"finish">;
                readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"tokens">;
                    readonly input: Schema.optional<Schema.Number>;
                    readonly output: Schema.optional<Schema.Number>;
                    readonly total: Schema.optional<Schema.Number>;
                    readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"seconds">;
                    readonly seconds: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"characters">;
                    readonly characters: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"credits">;
                    readonly credits: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"compute">;
                    readonly seconds: Schema.Number;
                }>]>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "generation-progress": Schema.Struct<{
                readonly type: Schema.tag<"generation-progress">;
                readonly id: Schema.String;
                readonly progress: Schema.optional<Schema.Number>;
            }>;
            readonly "generation-queued": Schema.Struct<{
                readonly type: Schema.tag<"generation-queued">;
                readonly id: Schema.String;
                readonly position: Schema.optional<Schema.Number>;
            }>;
            readonly image: Schema.Struct<{
                readonly type: Schema.tag<"image">;
                readonly index: Schema.Number;
                readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"bytes">;
                        readonly data: Schema.Uint8Array;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"base64">;
                        readonly data: Schema.String;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"url">;
                        readonly url: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                        readonly expiresAt: Schema.optional<Schema.Number>;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"ref">;
                        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                        readonly id: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                    }>]>;
                    readonly info: Schema.optional<Schema.Struct<{
                        readonly width: Schema.optional<Schema.Number>;
                        readonly height: Schema.optional<Schema.Number>;
                        readonly durationSeconds: Schema.optional<Schema.Number>;
                        readonly sampleRate: Schema.optional<Schema.Number>;
                        readonly channels: Schema.optional<Schema.Number>;
                        readonly encoding: Schema.optional<Schema.String>;
                        readonly format: Schema.optional<Schema.String>;
                    }>>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>, never, never>;
            }>;
            readonly "image-partial": Schema.Struct<{
                readonly type: Schema.tag<"image-partial">;
                readonly index: Schema.Number;
                readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"bytes">;
                        readonly data: Schema.Uint8Array;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"base64">;
                        readonly data: Schema.String;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"url">;
                        readonly url: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                        readonly expiresAt: Schema.optional<Schema.Number>;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"ref">;
                        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                        readonly id: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                    }>]>;
                    readonly info: Schema.optional<Schema.Struct<{
                        readonly width: Schema.optional<Schema.Number>;
                        readonly height: Schema.optional<Schema.Number>;
                        readonly durationSeconds: Schema.optional<Schema.Number>;
                        readonly sampleRate: Schema.optional<Schema.Number>;
                        readonly channels: Schema.optional<Schema.Number>;
                        readonly encoding: Schema.optional<Schema.String>;
                        readonly format: Schema.optional<Schema.String>;
                    }>>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>, never, never>;
            }>;
        }[K]["Type"]) => any; }>(value: {
            readonly type: "image-partial";
            readonly index: number;
            readonly image: Media.Asset;
        } | {
            readonly type: "image";
            readonly index: number;
            readonly image: Media.Asset;
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, cases: Handlers): import("effect/Unify").Unify<ReturnType<Handlers["finish" | "generation-progress" | "generation-queued" | "image" | "image-partial"]>>;
        <Handlers extends { [K in "finish" | "generation-progress" | "generation-queued" | "image" | "image-partial"]: (value: {
            readonly finish: Schema.Struct<{
                readonly type: Schema.tag<"finish">;
                readonly usage: Schema.optional<Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"tokens">;
                    readonly input: Schema.optional<Schema.Number>;
                    readonly output: Schema.optional<Schema.Number>;
                    readonly total: Schema.optional<Schema.Number>;
                    readonly details: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"seconds">;
                    readonly seconds: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"characters">;
                    readonly characters: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"credits">;
                    readonly credits: Schema.Number;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"compute">;
                    readonly seconds: Schema.Number;
                }>]>>;
                readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
            }>;
            readonly "generation-progress": Schema.Struct<{
                readonly type: Schema.tag<"generation-progress">;
                readonly id: Schema.String;
                readonly progress: Schema.optional<Schema.Number>;
            }>;
            readonly "generation-queued": Schema.Struct<{
                readonly type: Schema.tag<"generation-queued">;
                readonly id: Schema.String;
                readonly position: Schema.optional<Schema.Number>;
            }>;
            readonly image: Schema.Struct<{
                readonly type: Schema.tag<"image">;
                readonly index: Schema.Number;
                readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"bytes">;
                        readonly data: Schema.Uint8Array;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"base64">;
                        readonly data: Schema.String;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"url">;
                        readonly url: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                        readonly expiresAt: Schema.optional<Schema.Number>;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"ref">;
                        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                        readonly id: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                    }>]>;
                    readonly info: Schema.optional<Schema.Struct<{
                        readonly width: Schema.optional<Schema.Number>;
                        readonly height: Schema.optional<Schema.Number>;
                        readonly durationSeconds: Schema.optional<Schema.Number>;
                        readonly sampleRate: Schema.optional<Schema.Number>;
                        readonly channels: Schema.optional<Schema.Number>;
                        readonly encoding: Schema.optional<Schema.String>;
                        readonly format: Schema.optional<Schema.String>;
                    }>>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>, never, never>;
            }>;
            readonly "image-partial": Schema.Struct<{
                readonly type: Schema.tag<"image-partial">;
                readonly index: Schema.Number;
                readonly image: Schema.decodeTo<Schema.declare<Media.Asset, Media.Asset>, Schema.Struct<{
                    readonly source: Schema.Union<readonly [Schema.Struct<{
                        readonly type: Schema.Literal<"bytes">;
                        readonly data: Schema.Uint8Array;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"base64">;
                        readonly data: Schema.String;
                        readonly mediaType: Schema.String;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"url">;
                        readonly url: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                        readonly expiresAt: Schema.optional<Schema.Number>;
                    }>, Schema.Struct<{
                        readonly type: Schema.Literal<"ref">;
                        readonly provider: Schema.brand<Schema.String, "AI.ProviderID">;
                        readonly id: Schema.String;
                        readonly mediaType: Schema.optional<Schema.String>;
                    }>]>;
                    readonly info: Schema.optional<Schema.Struct<{
                        readonly width: Schema.optional<Schema.Number>;
                        readonly height: Schema.optional<Schema.Number>;
                        readonly durationSeconds: Schema.optional<Schema.Number>;
                        readonly sampleRate: Schema.optional<Schema.Number>;
                        readonly channels: Schema.optional<Schema.Number>;
                        readonly encoding: Schema.optional<Schema.String>;
                        readonly format: Schema.optional<Schema.String>;
                    }>>;
                    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
                }>, never, never>;
            }>;
        }[K]["Type"]) => any; }>(cases: Handlers): (value: {
            readonly type: "image-partial";
            readonly index: number;
            readonly image: Media.Asset;
        } | {
            readonly type: "image";
            readonly index: number;
            readonly image: Media.Asset;
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }) => import("effect/Unify").Unify<ReturnType<Handlers["finish" | "generation-progress" | "generation-queued" | "image" | "image-partial"]>>;
    };
    readonly matchOrElse: {
        <Handlers, OrElse>(value: {
            readonly type: "image-partial";
            readonly index: number;
            readonly image: Media.Asset;
        } | {
            readonly type: "image";
            readonly index: number;
            readonly image: Media.Asset;
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, cases: Handlers & {
            readonly finish?: ((value: {
                readonly type: "finish";
                readonly usage?: {
                    readonly type: "seconds";
                    readonly seconds: number;
                } | {
                    readonly type: "characters";
                    readonly characters: number;
                } | {
                    readonly type: "credits";
                    readonly credits: number;
                } | {
                    readonly type: "compute";
                    readonly seconds: number;
                } | {
                    readonly type: "tokens";
                    readonly input?: number | undefined;
                    readonly output?: number | undefined;
                    readonly total?: number | undefined;
                    readonly details?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                } | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "generation-progress"?: ((value: {
                readonly type: "generation-progress";
                readonly id: string;
                readonly progress?: number | undefined;
            }) => any) | undefined;
            readonly "generation-queued"?: ((value: {
                readonly type: "generation-queued";
                readonly id: string;
                readonly position?: number | undefined;
            }) => any) | undefined;
            readonly image?: ((value: {
                readonly type: "image";
                readonly index: number;
                readonly image: Media.Asset;
            }) => any) | undefined;
            readonly "image-partial"?: ((value: {
                readonly type: "image-partial";
                readonly index: number;
                readonly image: Media.Asset;
            }) => any) | undefined;
        } & (Exclude<keyof Handlers, "finish" | "generation-progress" | "generation-queued" | "image" | "image-partial"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
            readonly type: "image-partial";
            readonly index: number;
            readonly image: Media.Asset;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "image";
            readonly index: number;
            readonly image: Media.Asset;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }>) => any)): import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
        <Handlers, OrElse>(cases: Handlers & {
            readonly finish?: ((value: {
                readonly type: "finish";
                readonly usage?: {
                    readonly type: "seconds";
                    readonly seconds: number;
                } | {
                    readonly type: "characters";
                    readonly characters: number;
                } | {
                    readonly type: "credits";
                    readonly credits: number;
                } | {
                    readonly type: "compute";
                    readonly seconds: number;
                } | {
                    readonly type: "tokens";
                    readonly input?: number | undefined;
                    readonly output?: number | undefined;
                    readonly total?: number | undefined;
                    readonly details?: {
                        readonly [x: string]: unknown;
                    } | undefined;
                } | undefined;
                readonly providerMetadata?: {
                    readonly [x: string]: {
                        readonly [x: string]: unknown;
                    };
                } | undefined;
            }) => any) | undefined;
            readonly "generation-progress"?: ((value: {
                readonly type: "generation-progress";
                readonly id: string;
                readonly progress?: number | undefined;
            }) => any) | undefined;
            readonly "generation-queued"?: ((value: {
                readonly type: "generation-queued";
                readonly id: string;
                readonly position?: number | undefined;
            }) => any) | undefined;
            readonly image?: ((value: {
                readonly type: "image";
                readonly index: number;
                readonly image: Media.Asset;
            }) => any) | undefined;
            readonly "image-partial"?: ((value: {
                readonly type: "image-partial";
                readonly index: number;
                readonly image: Media.Asset;
            }) => any) | undefined;
        } & (Exclude<keyof Handlers, "finish" | "generation-progress" | "generation-queued" | "image" | "image-partial"> extends never ? unknown : never), orElse: OrElse & ((value: Exclude<{
            readonly type: "image-partial";
            readonly index: number;
            readonly image: Media.Asset;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "image";
            readonly index: number;
            readonly image: Media.Asset;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        }, {
            readonly type: keyof Handlers;
        }> | Exclude<{
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }, {
            readonly type: keyof Handlers;
        }>) => any)): (value: {
            readonly type: "image-partial";
            readonly index: number;
            readonly image: Media.Asset;
        } | {
            readonly type: "image";
            readonly index: number;
            readonly image: Media.Asset;
        } | {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        } | {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        } | {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        }) => import("effect/Unify").Unify<{ [K in keyof Handlers]-?: NonNullable<Handlers[K]> extends (...args: Array<any>) => infer R ? R : never; }[keyof Handlers] | (OrElse extends (...args: Array<any>) => infer R ? R : never)>;
    };
} & {
    is: {
        generationQueued: (u: unknown) => u is {
            readonly type: "generation-queued";
            readonly id: string;
            readonly position?: number | undefined;
        };
        generationProgress: (u: unknown) => u is {
            readonly type: "generation-progress";
            readonly id: string;
            readonly progress?: number | undefined;
        };
        imagePartial: (u: unknown) => u is {
            readonly type: "image-partial";
            readonly index: number;
            readonly image: Media.Asset;
        };
        image: (u: unknown) => u is {
            readonly type: "image";
            readonly index: number;
            readonly image: Media.Asset;
        };
        finish: (u: unknown) => u is {
            readonly type: "finish";
            readonly usage?: {
                readonly type: "seconds";
                readonly seconds: number;
            } | {
                readonly type: "characters";
                readonly characters: number;
            } | {
                readonly type: "credits";
                readonly credits: number;
            } | {
                readonly type: "compute";
                readonly seconds: number;
            } | {
                readonly type: "tokens";
                readonly input?: number | undefined;
                readonly output?: number | undefined;
                readonly total?: number | undefined;
                readonly details?: {
                    readonly [x: string]: unknown;
                } | undefined;
            } | undefined;
            readonly providerMetadata?: {
                readonly [x: string]: {
                    readonly [x: string]: unknown;
                };
            } | undefined;
        };
    };
};
export type ImageEvent = Schema.Schema.Type<typeof imageEventTagged>;
/** Normalize image request input into a plain `ImageRequest`. */
export declare const request: <const Model extends ImageModel>(input: ImageRequestInput<Model>) => ImageRequest<Model>;
export declare function generate<const Model extends ImageModel>(input: ImageRequestInput<Model>, options?: AwaitOptions): Effect.Effect<ImageResponse, AIError, Service>;
export declare function stream<const Model extends ImageModel>(input: ImageRequestInput<Model>, options?: AwaitOptions): Stream.Stream<ImageEvent, AIError, Service>;
/** Inline and streaming routes fail with `UnsupportedOperation`. */
export declare function start<const Model extends ImageModel>(input: ImageRequestInput<Model>): Effect.Effect<Generation<ImageResponse>, AIError, Service>;
export declare const resume: (model: ImageModel, token: unknown) => Effect.Effect<Generation<ImageResponse>, AIError, Service>;
export declare const Image: {
    readonly request: typeof request;
    readonly generate: typeof generate;
    readonly stream: typeof stream;
    readonly start: typeof start;
    readonly resume: typeof resume;
};
export {};
