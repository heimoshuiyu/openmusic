import { ExtractionModel, ExtractionResponse, type ExtractionRequest } from "./extraction.js";
import { MediaProtocol } from "../route/media-protocol.js";
import { MediaRoute } from "../route/media.js";
/** Posts Clairic's `{ model, state, fields }` body to Cloudflare's `/ai/run/{model}`. */
export declare const protocol: MediaProtocol.Inline<ExtractionRequest<ExtractionModel<{
    readonly [x: string]: unknown;
}>, Readonly<Record<string, import("./extraction.js").ExtractionField>>>, ExtractionResponse>;
/** `baseURL` is the Run API base, `.../client/v4/accounts/{account}/ai/run`. */
export declare const model: (input: MediaRoute.ModelInput) => ExtractionModel<{
    readonly [x: string]: unknown;
}>;
export declare const CloudflareRunExtraction: {
    readonly protocol: MediaProtocol.Inline<ExtractionRequest<ExtractionModel<{
        readonly [x: string]: unknown;
    }>, Readonly<Record<string, import("./extraction.js").ExtractionField>>>, ExtractionResponse>;
    readonly model: typeof model;
};
