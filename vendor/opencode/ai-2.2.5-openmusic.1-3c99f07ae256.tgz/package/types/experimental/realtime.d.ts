import { Effect, Redacted } from "effect";
import { RequestExecutor } from "../route/executor.js";
import { AIError } from "../schema/index.js";
export type RealtimeTransportInput = {
    readonly type: "webrtc";
    readonly sdp: string;
    readonly dcid?: number;
} | {
    readonly type: "websocket";
};
export type RealtimeTransportType = RealtimeTransportInput["type"];
export type RealtimeTransport = {
    readonly type: "webrtc";
    readonly sdp: string;
} | {
    readonly type: "websocket";
    readonly url: string;
    readonly token: string;
    readonly expiresAt: number;
};
export type RealtimeSession = Readonly<Record<string, unknown>>;
export interface RealtimeConnectInput {
    readonly model: string;
    readonly apiKey: Redacted.Redacted;
    /** Where a GPT-Live session starts, OpenAI by default: another host of its API, such as OpenCode's. */
    readonly baseURL?: string;
    /** Headers that host needs besides the API key, such as OpenCode's workspace. */
    readonly headers?: Readonly<Record<string, string>>;
    readonly session?: RealtimeSession;
    readonly transport: RealtimeTransportInput;
}
export declare const engines: readonly [{
    readonly family: "gpt-live";
    readonly model: "gpt-live-1";
    readonly id: "openai-live";
    readonly provider: "openai";
    readonly transports: readonly ["webrtc"];
}, {
    readonly family: "gpt-realtime";
    readonly model: "gpt-realtime-2.1";
    readonly id: "openai-realtime";
    readonly provider: "openai";
    readonly transports: readonly ["webrtc", "websocket"];
}, {
    readonly family: "grok-voice";
    readonly model: "grok-voice-3.0";
    readonly id: "xai-realtime";
    readonly provider: "xai";
    readonly transports: readonly ["websocket"];
}, {
    readonly family: "gemini-3.8-live";
    readonly model: "gemini-3.8-live";
    readonly id: "gemini-live";
    readonly provider: "google";
    readonly transports: readonly ["websocket"];
}];
export declare const engine: (model: string) => {
    readonly family: "gpt-live";
    readonly model: "gpt-live-1";
    readonly id: "openai-live";
    readonly provider: "openai";
    readonly transports: readonly ["webrtc"];
} | {
    readonly family: "gpt-realtime";
    readonly model: "gpt-realtime-2.1";
    readonly id: "openai-realtime";
    readonly provider: "openai";
    readonly transports: readonly ["webrtc", "websocket"];
} | {
    readonly family: "grok-voice";
    readonly model: "grok-voice-3.0";
    readonly id: "xai-realtime";
    readonly provider: "xai";
    readonly transports: readonly ["websocket"];
} | {
    readonly family: "gemini-3.8-live";
    readonly model: "gemini-3.8-live";
    readonly id: "gemini-live";
    readonly provider: "google";
    readonly transports: readonly ["websocket"];
} | undefined;
export declare const connect: (input: RealtimeConnectInput) => Effect.Effect<RealtimeTransport, AIError, RequestExecutor.RequestExecutorService>;
export declare const Realtime: {
    readonly engines: readonly [{
        readonly family: "gpt-live";
        readonly model: "gpt-live-1";
        readonly id: "openai-live";
        readonly provider: "openai";
        readonly transports: readonly ["webrtc"];
    }, {
        readonly family: "gpt-realtime";
        readonly model: "gpt-realtime-2.1";
        readonly id: "openai-realtime";
        readonly provider: "openai";
        readonly transports: readonly ["webrtc", "websocket"];
    }, {
        readonly family: "grok-voice";
        readonly model: "grok-voice-3.0";
        readonly id: "xai-realtime";
        readonly provider: "xai";
        readonly transports: readonly ["websocket"];
    }, {
        readonly family: "gemini-3.8-live";
        readonly model: "gemini-3.8-live";
        readonly id: "gemini-live";
        readonly provider: "google";
        readonly transports: readonly ["websocket"];
    }];
    readonly engine: typeof engine;
    readonly connect: (input: RealtimeConnectInput) => Effect.Effect<RealtimeTransport, AIError, RequestExecutor.RequestExecutorService>;
};
