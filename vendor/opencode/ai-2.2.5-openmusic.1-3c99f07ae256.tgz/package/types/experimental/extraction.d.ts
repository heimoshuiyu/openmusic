import { Effect, Schema } from "effect";
import { MediaModel } from "../media-model.js";
import { RequestExecutor } from "../route/executor.js";
import type { MediaRoute } from "../route/media.js";
import { AIError, Usage, type BaseRequest, type OpenString } from "../schema/index.js";
/**
 * The answer schema for each field type Clairic documents, decoding its wire keys (`p_null` and friends). Answers to
 * other field types pass through as sent.
 */
export declare const ExtractionAnswers: {
    text: Schema.encodeKeys<Schema.Struct<{
        readonly value: Schema.NullOr<Schema.String>;
        readonly guess: Schema.optional<Schema.String>;
        readonly nullProbability: Schema.optional<Schema.Number>;
        readonly confidence: Schema.optional<Schema.Number>;
        readonly span: Schema.optional<Schema.Tuple<readonly [Schema.Int, Schema.Int]>>;
    }>, {
        readonly nullProbability: "p_null";
    }>;
    number: Schema.encodeKeys<Schema.Struct<{
        readonly value: Schema.NullOr<Schema.Number>;
        readonly guess: Schema.optional<Schema.Number>;
        readonly nullProbability: Schema.optional<Schema.Number>;
        readonly confidence: Schema.optional<Schema.Number>;
        readonly span: Schema.optional<Schema.Tuple<readonly [Schema.Int, Schema.Int]>>;
    }>, {
        readonly nullProbability: "p_null";
    }>;
    date: Schema.encodeKeys<Schema.Struct<{
        readonly value: Schema.NullOr<Schema.String>;
        readonly guess: Schema.optional<Schema.String>;
        readonly nullProbability: Schema.optional<Schema.Number>;
        readonly confidence: Schema.optional<Schema.Number>;
        readonly span: Schema.optional<Schema.Tuple<readonly [Schema.Int, Schema.Int]>>;
    }>, {
        readonly nullProbability: "p_null";
    }>;
    time: Schema.encodeKeys<Schema.Struct<{
        readonly value: Schema.NullOr<Schema.String>;
        readonly guess: Schema.optional<Schema.String>;
        readonly nullProbability: Schema.optional<Schema.Number>;
        readonly confidence: Schema.optional<Schema.Number>;
        readonly span: Schema.optional<Schema.Tuple<readonly [Schema.Int, Schema.Int]>>;
    }>, {
        readonly nullProbability: "p_null";
    }>;
    datetime: Schema.encodeKeys<Schema.Struct<{
        readonly value: Schema.NullOr<Schema.String>;
        readonly guess: Schema.optional<Schema.String>;
        readonly nullProbability: Schema.optional<Schema.Number>;
        readonly confidence: Schema.optional<Schema.Number>;
        readonly span: Schema.optional<Schema.Tuple<readonly [Schema.Int, Schema.Int]>>;
    }>, {
        readonly nullProbability: "p_null";
    }>;
    duration: Schema.encodeKeys<Schema.Struct<{
        readonly value: Schema.NullOr<Schema.Number>;
        readonly guess: Schema.optional<Schema.Number>;
        readonly nullProbability: Schema.optional<Schema.Number>;
        readonly confidence: Schema.optional<Schema.Number>;
        readonly span: Schema.optional<Schema.Tuple<readonly [Schema.Int, Schema.Int]>>;
    }>, {
        readonly nullProbability: "p_null";
    }>;
    list: Schema.Struct<{
        readonly value: Schema.NullOr<Schema.$Array<Schema.Union<readonly [Schema.String, Schema.Number]>>>;
        readonly spans: Schema.optional<Schema.$Array<Schema.Tuple<readonly [Schema.Int, Schema.Int]>>>;
        readonly confidence: Schema.optional<Schema.Number>;
    }>;
    estimate: Schema.encodeKeys<Schema.Struct<{
        readonly value: Schema.Union<readonly [Schema.Number, Schema.String]>;
        readonly mean: Schema.optional<Schema.Union<readonly [Schema.Number, Schema.String]>>;
        readonly median: Schema.Union<readonly [Schema.Number, Schema.String]>;
        readonly p10: Schema.Union<readonly [Schema.Number, Schema.String]>;
        readonly p90: Schema.Union<readonly [Schema.Number, Schema.String]>;
        readonly belowProbability: Schema.optional<Schema.Number>;
        readonly aboveProbability: Schema.optional<Schema.Number>;
        readonly quantiles: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Number, Schema.String]>>>;
    }>, {
        readonly belowProbability: "p_below";
        readonly aboveProbability: "p_above";
    }>;
    /** One estimate per step of the series. */
    forecast: Schema.Struct<{
        readonly value: Schema.$Array<Schema.Union<readonly [Schema.Number, Schema.String]>>;
        readonly steps: Schema.$Array<Schema.encodeKeys<Schema.Struct<{
            readonly value: Schema.Union<readonly [Schema.Number, Schema.String]>;
            readonly mean: Schema.optional<Schema.Union<readonly [Schema.Number, Schema.String]>>;
            readonly median: Schema.Union<readonly [Schema.Number, Schema.String]>;
            readonly p10: Schema.Union<readonly [Schema.Number, Schema.String]>;
            readonly p90: Schema.Union<readonly [Schema.Number, Schema.String]>;
            readonly belowProbability: Schema.optional<Schema.Number>;
            readonly aboveProbability: Schema.optional<Schema.Number>;
            readonly quantiles: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Number, Schema.String]>>>;
        }>, {
            readonly belowProbability: "p_below";
            readonly aboveProbability: "p_above";
        }>>;
    }>;
};
type Answers = typeof ExtractionAnswers;
export type ExtractionAnswerFor<Field extends ExtractionField> = Field["type"] extends keyof Answers ? Answers[Field["type"]]["Type"] : Readonly<Record<string, unknown>>;
/** One answer per field, keyed by field name. */
export type ExtractionAnswersFor<Fields extends ExtractionFields> = {
    readonly [Name in keyof Fields]: ExtractionAnswerFor<Fields[Name]>;
};
/** Options beyond these, such as `unit`, `decimals`, `items`, `min` or `max`, go to the host as written. */
declare const ExtractionFieldSchema: Schema.StructWithRest<Schema.Struct<{
    readonly type: Schema.String;
    readonly instructions: Schema.optional<Schema.String>;
    /** Probability of null above which the value is null; the host's default is 0.5. */
    readonly nullThreshold: Schema.optional<Schema.Number>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
export type ExtractionField = typeof ExtractionFieldSchema.Type & {
    readonly type: OpenString<keyof Answers>;
};
export type ExtractionFields = Readonly<Record<string, ExtractionField>>;
export type ExtractionOptions = MediaModel.Options;
export type ExtractionRoute = MediaRoute.InlineRoute<ExtractionRequest, ExtractionResponse>;
export declare class ExtractionModel<Options extends ExtractionOptions = ExtractionOptions> extends MediaModel<ExtractionRoute, Options> {
    protected readonly _ExtractionModel: void;
}
export type ExtractionModelOptions<Model> = Model extends ExtractionModel<infer Options> ? Options : never;
/** A normalized extraction request, the plain object `Extraction.request(...)` returns. */
export interface ExtractionRequest<Model extends ExtractionModel = ExtractionModel, Fields extends ExtractionFields = ExtractionFields> extends BaseRequest<Model, ExtractionModelOptions<Model>> {
    /** The text to read; text answers carry spans into it. */
    readonly input: string;
    readonly fields: Fields;
    /** ISO date that anchors dates written without a year. */
    readonly referenceDate?: string;
}
/** Input accepted by `Extraction.request` and `generate`; an `ExtractionRequest` is also a valid input. */
export type ExtractionRequestInput<Model extends ExtractionModel = ExtractionModel, Fields extends ExtractionFields = ExtractionFields> = Omit<ExtractionRequest<Model, Fields>, "providerOptions"> & {
    readonly providerOptions?: NoInfer<ExtractionModelOptions<Model>>;
};
declare const ExtractionResponse_base: Schema.Class<ExtractionResponse, Schema.Struct<{
    readonly answers: Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly usage: Schema.optional<typeof Usage>;
    readonly providerMetadata: Schema.optional<Schema.$Record<Schema.String, Schema.$Record<Schema.String, Schema.Unknown>>>;
}>, {}>;
export declare class ExtractionResponse extends ExtractionResponse_base {
}
export type ExtractionResponseFor<Fields extends ExtractionFields> = Omit<ExtractionResponse, "answers"> & {
    readonly answers: ExtractionAnswersFor<Fields>;
};
/** Normalize extraction request input into a plain `ExtractionRequest`. */
export declare const request: <const Model extends ExtractionModel, const Fields extends ExtractionFields>(input: ExtractionRequestInput<Model, Fields>) => ExtractionRequest<Model, Fields>;
export declare function generate<const Model extends ExtractionModel, const Fields extends ExtractionFields>(input: ExtractionRequestInput<Model, Fields>): Effect.Effect<ExtractionResponseFor<Fields>, AIError, RequestExecutor.Service>;
export declare const Extraction: {
    readonly request: typeof request;
    readonly generate: typeof generate;
};
export {};
