import { type ProviderAuthOption } from "../route/auth-options.js";
import type { Route, CompactionOperations } from "../route/client.js";
import type { ProviderPackage } from "../provider-package.js";
import { ToolDefinition, type ModelID, type OpenString, type ProviderOptions, type RequestOptions } from "../schema/index.js";
import * as OpenAIResponses from "../protocols/openai-responses.js";
import { type OpenAIProviderOptionsInput } from "./openai-options.js";
import { type OptionsInput as OpenAIDecisionOptionsInput } from "../protocols/openai-decisions.js";
export type { OpenAIOptionsInput, OpenAIResponseIncludable, OpenAIServiceTier } from "./openai-options.js";
export type { OpenAIImageOptions } from "../protocols/openai-images.js";
export type { OpenAISpeechOptions } from "../protocols/openai-speech.js";
export type { OpenAITranscriptionOptions } from "../protocols/openai-transcription.js";
export type { OptionsInput as OpenAIDecisionOptions } from "../protocols/openai-decisions.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export declare const routes: (Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly verbosity?: OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, CompactionOperations | undefined> | Route<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: import("../schema/options.js").ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly text?: {
        readonly verbosity?: OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "namespace";
        readonly name: string;
        readonly description: string;
        readonly tools: readonly {
            readonly type: "function";
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        }[];
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly type: "image_generation";
        readonly action?: "auto" | "edit" | "generate" | undefined;
        readonly background?: "auto" | "opaque" | "transparent" | undefined;
        readonly input_fidelity?: "high" | "low" | undefined;
        readonly output_compression?: number | undefined;
        readonly output_format?: "jpeg" | "png" | "webp" | undefined;
        readonly partial_images?: number | undefined;
        readonly quality?: "auto" | "high" | "low" | "medium" | undefined;
        readonly size?: string | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | {
        readonly type: "image_generation";
    } | undefined;
    readonly reasoning?: {
        readonly effort?: import("../schema/options.js").ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
        readonly mode?: OpenString<"pro" | "standard"> | undefined;
        readonly context?: OpenString<"all_turns" | "auto" | "current_turn"> | undefined;
    } | undefined;
    readonly context_management?: readonly {
        readonly type: "compaction";
        readonly compact_threshold?: number | undefined;
    }[] | undefined;
    readonly stream: true;
}, import("../protocols/open-responses-channel.js").Prepared, {
    endpoint: import("../route/client.js").CompactOperation;
    trigger: import("../route/client.js").TriggerCompactOperation;
}>)[];
export type Config = RequestOptions & ProviderAuthOption<"optional"> & {
    readonly baseURL?: string;
    readonly queryParams?: Record<string, string>;
    readonly providerOptions?: OpenAIProviderOptionsInput;
};
export interface ImageGenerationOptions {
    readonly action?: OpenString<"auto" | "generate" | "edit">;
    readonly background?: OpenString<"auto" | "opaque" | "transparent">;
    readonly inputFidelity?: OpenString<"low" | "high">;
    readonly outputCompression?: number;
    readonly outputFormat?: OpenString<"png" | "jpeg" | "webp">;
    readonly partialImages?: number;
    readonly quality?: OpenString<"auto" | "low" | "medium" | "high" | "standard" | "hd">;
    readonly size?: OpenString<"auto" | "256x256" | "512x512" | "1024x1024" | "1536x1024" | "1024x1536" | "1792x1024" | "1024x1792">;
}
export declare const imageGeneration: (options?: ImageGenerationOptions) => ToolDefinition;
export type Settings = ProviderPackage.Settings & OpenAIProviderOptionsInput & {
    readonly apiKey?: string | false;
    readonly baseURL?: string;
    readonly organization?: string;
    readonly project?: string;
    readonly queryParams?: Readonly<Record<string, string>>;
};
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (id: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, {
        endpoint: import("../route/client.js").CompactOperation;
        trigger: import("../route/client.js").TriggerCompactOperation;
    }>;
    responses: (id: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, {
        endpoint: import("../route/client.js").CompactOperation;
        trigger: import("../route/client.js").TriggerCompactOperation;
    }>;
    chat: (id: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, CompactionOperations | undefined>;
    image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
    speech: (modelID: string | ModelID) => import("../speech.js").SpeechModel<import("../protocols/openai-speech.js").OpenAISpeechOptions>;
    transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/openai-transcription.js").OpenAITranscriptionOptions>;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<OpenAIDecisionOptionsInput>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (id: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, {
        endpoint: import("../route/client.js").CompactOperation;
        trigger: import("../route/client.js").TriggerCompactOperation;
    }>;
    responses: (id: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, {
        endpoint: import("../route/client.js").CompactOperation;
        trigger: import("../route/client.js").TriggerCompactOperation;
    }>;
    chat: (id: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, CompactionOperations | undefined>;
    image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
    speech: (modelID: string | ModelID) => import("../speech.js").SpeechModel<import("../protocols/openai-speech.js").OpenAISpeechOptions>;
    transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/openai-transcription.js").OpenAITranscriptionOptions>;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<OpenAIDecisionOptionsInput>;
    configure: typeof configure;
};
export declare const model: ProviderPackage.Model<Settings, OpenAIProviderOptionsInput, typeof OpenAIResponses.route.compact>;
export declare const chatModel: ProviderPackage.Model<Settings, OpenAIProviderOptionsInput>;
export declare const imageModel: (modelID: string, settings?: Settings) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
export declare const decisionModel: (modelID: string, settings?: Settings) => import("../decision.js").DecisionModel<OpenAIDecisionOptionsInput>;
export declare const responses: (id: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, {
    endpoint: import("../route/client.js").CompactOperation;
    trigger: import("../route/client.js").TriggerCompactOperation;
}>;
export declare const chat: (id: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, CompactionOperations | undefined>;
export declare const image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
export declare const speech: (modelID: string | ModelID) => import("../speech.js").SpeechModel<import("../protocols/openai-speech.js").OpenAISpeechOptions>;
export declare const transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/openai-transcription.js").OpenAITranscriptionOptions>;
export declare const decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<OpenAIDecisionOptionsInput>;
