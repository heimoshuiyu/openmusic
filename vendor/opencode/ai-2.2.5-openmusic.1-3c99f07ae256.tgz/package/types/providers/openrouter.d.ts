import { Schema } from "effect";
import { Route } from "../route/client.js";
import { Protocol } from "../route/protocol.js";
import type { ProviderAuthOption } from "../route/auth-options.js";
import { type ModelID, type OpenString, type ProviderOptions, type RequestOptions } from "../schema/index.js";
import type { ProviderPackage } from "../provider-package.js";
import { HttpTransport } from "../route/transport/index.js";
import { OpenAIChat } from "../protocols/openai-chat.js";
import type { OpenResponsesProviderOptionsInput } from "./open-responses-options.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export interface OpenRouterProviderRouting {
    readonly [key: string]: unknown;
    readonly order?: ReadonlyArray<string>;
    readonly allow_fallbacks?: boolean;
    readonly require_parameters?: boolean;
    readonly data_collection?: OpenString<"allow" | "deny">;
    readonly only?: ReadonlyArray<string>;
    readonly ignore?: ReadonlyArray<string>;
    readonly quantizations?: ReadonlyArray<string>;
    readonly sort?: OpenString<"price" | "throughput" | "latency">;
    readonly max_price?: Readonly<{
        prompt?: number | string;
        completion?: number | string;
        image?: number | string;
        audio?: number | string;
        request?: number | string;
    }>;
    readonly zdr?: boolean;
}
export type OpenRouterPlugin = Readonly<{
    id: "web";
    max_results?: number;
    search_prompt?: string;
    engine?: OpenString<"native" | "exa">;
}> | Readonly<{
    id: "file-parser";
    max_files?: number;
    pdf?: {
        engine?: string;
    };
}> | Readonly<{
    id: "moderation";
}> | Readonly<{
    id: "response-healing";
}> | Readonly<{
    id: "auto-router";
    allowed_models?: ReadonlyArray<string>;
}> | Readonly<{
    id: string & {};
    [key: string]: unknown;
}>;
export interface OpenRouterOptions {
    readonly [key: string]: unknown;
    readonly debug?: Readonly<{
        echo_upstream_body?: boolean;
    }>;
    readonly models?: ReadonlyArray<string>;
    readonly plugins?: ReadonlyArray<OpenRouterPlugin>;
    readonly provider?: OpenRouterProviderRouting;
    readonly reasoning?: Readonly<{
        enabled?: boolean;
        exclude?: boolean;
        effort?: OpenString<"none" | "minimal" | "low" | "medium" | "high" | "xhigh" | "max">;
        max_tokens?: number;
    }>;
    readonly usage?: boolean | Readonly<{
        include: boolean;
    }>;
    readonly user?: string;
    readonly web_search_options?: Readonly<{
        max_results?: number;
        search_prompt?: string;
        engine?: OpenString<"native" | "exa">;
    }>;
}
export type OpenRouterProviderOptionsInput = OpenRouterOptions;
export type OpenRouterResponsesProviderOptionsInput = OpenResponsesProviderOptionsInput & Pick<OpenRouterOptions, "debug" | "models" | "plugins" | "provider" | "user">;
export interface OpenRouterDecisionOptions {
    readonly [key: string]: unknown;
    readonly provider?: OpenRouterProviderRouting;
    readonly session_id?: string;
    readonly trace?: Readonly<Record<string, unknown>>;
    readonly user?: string;
}
export type Config = Omit<RequestOptions, "providerOptions"> & ProviderAuthOption<"optional"> & {
    readonly baseURL?: string;
    readonly providerOptions?: OpenRouterProviderOptionsInput | OpenRouterResponsesProviderOptionsInput;
};
export type Settings<Options = OpenRouterProviderOptionsInput> = ProviderPackage.Settings & Options & {
    readonly apiKey?: string | false;
    readonly baseURL?: string;
};
declare const OpenRouterBody: Schema.StructWithRest<Schema.Struct<{
    readonly model: Schema.String;
    readonly messages: Schema.$Array<Schema.toTaggedUnion<"role", readonly [Schema.Struct<{
        readonly role: Schema.Literal<"system">;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"image_url">;
            readonly image_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"video_url">;
            readonly video_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly file: Schema.Struct<{
                readonly filename: Schema.String;
                readonly file_data: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"audio_url">;
            readonly audio_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>]>>]>;
    }>, Schema.Struct<{
        readonly role: Schema.Literal<"user">;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"image_url">;
            readonly image_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"video_url">;
            readonly video_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"file">;
            readonly file: Schema.Struct<{
                readonly filename: Schema.String;
                readonly file_data: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"input_audio">;
            readonly input_audio: Schema.Struct<{
                readonly data: Schema.String;
                readonly format: Schema.String;
            }>;
        }>, Schema.Struct<{
            readonly type: Schema.Literal<"audio_url">;
            readonly audio_url: Schema.Struct<{
                readonly url: Schema.String;
            }>;
        }>]>>]>;
    }>, Schema.StructWithRest<Schema.Struct<{
        readonly role: Schema.Literal<"assistant">;
        readonly content: Schema.NullOr<Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>>]>>;
        readonly tool_calls: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly id: Schema.String;
            readonly type: Schema.tag<"function">;
            readonly function: Schema.Struct<{
                readonly name: Schema.String;
                readonly arguments: Schema.String;
            }>;
            readonly extra_content: Schema.optional<Schema.Struct<{
                readonly google: Schema.Struct<{
                    readonly thought_signature: Schema.String;
                }>;
            }>>;
        }>, Schema.Struct<{
            readonly id: Schema.String;
            readonly type: Schema.tag<"custom">;
            readonly custom: Schema.Struct<{
                readonly name: Schema.String;
                readonly input: Schema.String;
            }>;
        }>]>>>;
        readonly reasoning_content: Schema.optional<Schema.String>;
        readonly reasoning: Schema.optional<Schema.String>;
        readonly reasoning_text: Schema.optional<Schema.String>;
        readonly reasoning_details: Schema.optional<Schema.Unknown>;
        readonly reasoning_opaque: Schema.optional<Schema.String>;
    }>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>, Schema.Struct<{
        readonly role: Schema.Literal<"tool">;
        readonly tool_call_id: Schema.String;
        readonly content: Schema.Union<readonly [Schema.String, Schema.$Array<Schema.Struct<{
            readonly type: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly cache_control: Schema.optional<Schema.Struct<{
                readonly type: Schema.Literal<"ephemeral">;
                readonly ttl: Schema.optional<Schema.String>;
            }>>;
        }>>]>;
    }>]>>;
    readonly tools: Schema.optional<Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly type: Schema.tag<"function">;
        readonly function: Schema.Struct<{
            readonly name: Schema.String;
            readonly description: Schema.String;
            readonly parameters: Schema.$Record<Schema.String, Schema.Unknown>;
            readonly strict: Schema.optional<Schema.Boolean>;
        }>;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.Literal<"ephemeral">;
            readonly ttl: Schema.optional<Schema.String>;
        }>>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom">;
        readonly custom: Schema.Struct<{
            readonly name: Schema.String;
            readonly description: Schema.String;
            readonly format: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.tag<"text">;
            }>, Schema.Struct<{
                readonly type: Schema.tag<"grammar">;
                readonly grammar: Schema.Struct<{
                    readonly syntax: Schema.Literals<readonly ["lark", "regex"]>;
                    readonly definition: Schema.String;
                }>;
            }>]>;
        }>;
        readonly cache_control: Schema.optional<Schema.Struct<{
            readonly type: Schema.Literal<"ephemeral">;
            readonly ttl: Schema.optional<Schema.String>;
        }>>;
    }>]>>>;
    readonly tool_choice: Schema.optional<Schema.Union<readonly [Schema.Literals<readonly ["auto", "none", "required"]>, Schema.Struct<{
        readonly type: Schema.tag<"function">;
        readonly function: Schema.Struct<{
            readonly name: Schema.String;
        }>;
    }>, Schema.Struct<{
        readonly type: Schema.tag<"custom">;
        readonly custom: Schema.Struct<{
            readonly name: Schema.String;
        }>;
    }>]>>;
    readonly stream: Schema.Literal<true>;
    readonly stream_options: Schema.optional<Schema.Struct<{
        readonly include_usage: Schema.Boolean;
    }>>;
    readonly store: Schema.optional<Schema.Boolean>;
    readonly prompt_cache_key: Schema.optional<Schema.String>;
    readonly prompt_cache_retention: Schema.optional<Schema.String>;
    readonly prompt_cache_options: Schema.optional<Schema.Struct<{
        readonly ttl: Schema.optional<Schema.String>;
    }>>;
    readonly reasoning_effort: Schema.optional<Schema.declare<import("../schema/options.js").ReasoningEffort, import("../schema/options.js").ReasoningEffort>>;
    readonly verbosity: Schema.optional<Schema.declare<OpenString<"high" | "low" | "medium">, OpenString<"high" | "low" | "medium">>>;
    readonly service_tier: Schema.optional<Schema.declare<OpenString<"auto" | "default" | "flex" | "priority">, OpenString<"auto" | "default" | "flex" | "priority">>>;
    readonly parallel_tool_calls: Schema.optional<Schema.Boolean>;
    readonly metadata: Schema.optional<Schema.$Record<Schema.String, Schema.String>>;
    readonly safety_identifier: Schema.optional<Schema.String>;
    readonly tool_stream: Schema.optional<Schema.Boolean>;
    readonly max_completion_tokens: Schema.optional<Schema.Number>;
    readonly max_tokens: Schema.optional<Schema.Number>;
    readonly temperature: Schema.optional<Schema.Number>;
    readonly top_p: Schema.optional<Schema.Number>;
    readonly frequency_penalty: Schema.optional<Schema.Number>;
    readonly presence_penalty: Schema.optional<Schema.Number>;
    readonly seed: Schema.optional<Schema.Number>;
    readonly stop: Schema.optional<Schema.$Array<Schema.String>>;
    readonly models: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.$Array<Schema.String>>, never>>;
    readonly provider: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.$Record<Schema.String, Schema.Unknown>>, never>>;
    readonly plugins: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.$Array<Schema.$Record<Schema.String, Schema.Unknown>>>, never>>;
    readonly debug: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.$Record<Schema.String, Schema.Unknown>>, never>>;
    readonly user: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.String>, never>>;
    readonly web_search_options: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.$Record<Schema.String, Schema.Unknown>>, never>>;
    readonly reasoning: Schema.optionalKey<Schema.middlewareDecoding<Schema.UndefinedOr<Schema.$Record<Schema.String, Schema.Unknown>>, never>>;
    readonly usage: Schema.optional<Schema.$Record<Schema.String, Schema.Unknown>>;
}>, readonly [Schema.$Record<Schema.String, Schema.Unknown>]>;
export type OpenRouterBody = Schema.Schema.Type<typeof OpenRouterBody>;
export declare const protocol: Protocol<{
    model: string;
    messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    stream: true;
    stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    store?: boolean | undefined;
    prompt_cache_key?: string | undefined;
    prompt_cache_retention?: string | undefined;
    prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    verbosity?: OpenString<"high" | "low" | "medium"> | undefined;
    service_tier?: OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    parallel_tool_calls?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    tool_stream?: boolean | undefined;
    max_completion_tokens?: number | undefined;
    max_tokens?: number | undefined;
    temperature?: number | undefined;
    top_p?: number | undefined;
    frequency_penalty?: number | undefined;
    presence_penalty?: number | undefined;
    seed?: number | undefined;
    stop?: readonly string[] | undefined;
    usage?: {
        readonly [x: string]: unknown;
    } | undefined;
    web_search_options?: {
        readonly [x: string]: unknown;
    } | undefined;
    reasoning?: Record<string, unknown> | undefined;
    models?: readonly string[] | undefined;
    provider?: {
        readonly [x: string]: unknown;
    } | undefined;
    plugins?: readonly {
        readonly [x: string]: unknown;
    }[] | undefined;
    debug?: {
        readonly [x: string]: unknown;
    } | undefined;
    user?: string | undefined;
}, string, "[DONE]" | {
    readonly [x: string]: unknown;
    readonly choices?: readonly {
        readonly [x: string]: unknown;
        readonly delta?: {
            readonly [x: string]: unknown;
            readonly content?: string | null | undefined;
            readonly refusal?: string | null | undefined;
            readonly reasoning_content?: string | null | undefined;
            readonly reasoning?: string | null | undefined;
            readonly reasoning_text?: string | null | undefined;
            readonly reasoning_details?: unknown;
            readonly reasoning_opaque?: string | null | undefined;
            readonly tool_calls?: readonly {
                readonly index?: number | null | undefined;
                readonly id?: string | null | undefined;
                readonly function?: {
                    readonly name?: string | null | undefined;
                    readonly arguments?: string | null | undefined;
                } | null | undefined;
                readonly custom?: {
                    readonly name?: string | null | undefined;
                    readonly input?: string | null | undefined;
                } | null | undefined;
                readonly extra_content?: unknown;
            }[] | null | undefined;
        } | null | undefined;
        readonly finish_reason?: string | null | undefined;
        readonly native_finish_reason?: string | null | undefined;
        readonly usage?: {
            readonly [x: string]: unknown;
            readonly prompt_tokens?: number | null | undefined;
            readonly completion_tokens?: number | null | undefined;
            readonly total_tokens?: number | null | undefined;
            readonly cached_tokens?: number | null | undefined;
            readonly prompt_cache_hit_tokens?: number | null | undefined;
            readonly cache_read_input_tokens?: number | null | undefined;
            readonly cache_created_input_tokens?: number | null | undefined;
            readonly reasoning_tokens?: number | null | undefined;
            readonly prompt_tokens_details?: {
                readonly [x: string]: unknown;
                readonly cached_tokens?: number | null | undefined;
                readonly cache_write_tokens?: number | null | undefined;
            } | null | undefined;
            readonly completion_tokens_details?: {
                readonly [x: string]: unknown;
                readonly reasoning_tokens?: number | null | undefined;
                readonly accepted_prediction_tokens?: number | null | undefined;
                readonly rejected_prediction_tokens?: number | null | undefined;
            } | null | undefined;
        } | null | undefined;
    }[] | null | undefined;
    readonly usage?: {
        readonly [x: string]: unknown;
        readonly prompt_tokens?: number | null | undefined;
        readonly completion_tokens?: number | null | undefined;
        readonly total_tokens?: number | null | undefined;
        readonly cached_tokens?: number | null | undefined;
        readonly prompt_cache_hit_tokens?: number | null | undefined;
        readonly cache_read_input_tokens?: number | null | undefined;
        readonly cache_created_input_tokens?: number | null | undefined;
        readonly reasoning_tokens?: number | null | undefined;
        readonly prompt_tokens_details?: {
            readonly [x: string]: unknown;
            readonly cached_tokens?: number | null | undefined;
            readonly cache_write_tokens?: number | null | undefined;
        } | null | undefined;
        readonly completion_tokens_details?: {
            readonly [x: string]: unknown;
            readonly reasoning_tokens?: number | null | undefined;
            readonly accepted_prediction_tokens?: number | null | undefined;
            readonly rejected_prediction_tokens?: number | null | undefined;
        } | null | undefined;
    } | null | undefined;
    readonly error?: {
        readonly [x: string]: unknown;
        readonly code?: string | number | null | undefined;
        readonly message: string;
    } | null | undefined;
}, OpenAIChat.ParserState>;
export declare const route: Route<{
    model: string;
    messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    stream: true;
    stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    store?: boolean | undefined;
    prompt_cache_key?: string | undefined;
    prompt_cache_retention?: string | undefined;
    prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    verbosity?: OpenString<"high" | "low" | "medium"> | undefined;
    service_tier?: OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    parallel_tool_calls?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    tool_stream?: boolean | undefined;
    max_completion_tokens?: number | undefined;
    max_tokens?: number | undefined;
    temperature?: number | undefined;
    top_p?: number | undefined;
    frequency_penalty?: number | undefined;
    presence_penalty?: number | undefined;
    seed?: number | undefined;
    stop?: readonly string[] | undefined;
    usage?: {
        readonly [x: string]: unknown;
    } | undefined;
    web_search_options?: {
        readonly [x: string]: unknown;
    } | undefined;
    reasoning?: Record<string, unknown> | undefined;
    models?: readonly string[] | undefined;
    provider?: {
        readonly [x: string]: unknown;
    } | undefined;
    plugins?: readonly {
        readonly [x: string]: unknown;
    }[] | undefined;
    debug?: {
        readonly [x: string]: unknown;
    } | undefined;
    user?: string | undefined;
}, HttpTransport.HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>;
export declare const routes: (Route<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: import("../schema/options.js").ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly reasoning?: {
        readonly effort?: import("../schema/options.js").ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
    } | undefined;
    readonly text?: {
        readonly verbosity?: OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly stream: true;
    readonly models?: readonly string[] | undefined;
    readonly provider?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly plugins?: readonly {
        readonly [x: string]: unknown;
    }[] | undefined;
    readonly debug?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly user?: string | undefined;
}, HttpTransport.HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined> | Route<{
    model: string;
    messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    stream: true;
    stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    store?: boolean | undefined;
    prompt_cache_key?: string | undefined;
    prompt_cache_retention?: string | undefined;
    prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    verbosity?: OpenString<"high" | "low" | "medium"> | undefined;
    service_tier?: OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    parallel_tool_calls?: boolean | undefined;
    metadata?: {
        readonly [x: string]: string;
    } | undefined;
    safety_identifier?: string | undefined;
    tool_stream?: boolean | undefined;
    max_completion_tokens?: number | undefined;
    max_tokens?: number | undefined;
    temperature?: number | undefined;
    top_p?: number | undefined;
    frequency_penalty?: number | undefined;
    presence_penalty?: number | undefined;
    seed?: number | undefined;
    stop?: readonly string[] | undefined;
    usage?: {
        readonly [x: string]: unknown;
    } | undefined;
    web_search_options?: {
        readonly [x: string]: unknown;
    } | undefined;
    reasoning?: Record<string, unknown> | undefined;
    models?: readonly string[] | undefined;
    provider?: {
        readonly [x: string]: unknown;
    } | undefined;
    plugins?: readonly {
        readonly [x: string]: unknown;
    }[] | undefined;
    debug?: {
        readonly [x: string]: unknown;
    } | undefined;
    user?: string | undefined;
}, HttpTransport.HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>)[];
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<OpenRouterOptions, import("../route/client.js").CompactionOperations | undefined>;
    chat: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<OpenRouterOptions, import("../route/client.js").CompactionOperations | undefined>;
    responses: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<OpenRouterResponsesProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<OpenRouterDecisionOptions>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<OpenRouterOptions, import("../route/client.js").CompactionOperations | undefined>;
    chat: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<OpenRouterOptions, import("../route/client.js").CompactionOperations | undefined>;
    responses: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<OpenRouterResponsesProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<OpenRouterDecisionOptions>;
    configure: typeof configure;
};
export declare const decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<OpenRouterDecisionOptions>;
export declare const image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
export declare const chat: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<OpenRouterOptions, import("../route/client.js").CompactionOperations | undefined>;
export declare const responses: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<OpenRouterResponsesProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
export declare const model: ProviderPackage.Model<Settings, OpenRouterProviderOptionsInput>;
export declare const responsesModel: ProviderPackage.Model<Settings<OpenRouterResponsesProviderOptionsInput>, OpenRouterResponsesProviderOptionsInput>;
export declare const imageModel: (modelID: string, settings?: Settings) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
export declare const decisionModel: (modelID: string, settings?: Settings) => import("../decision.js").DecisionModel<OpenRouterDecisionOptions>;
export * as OpenRouter from "./openrouter.js";
