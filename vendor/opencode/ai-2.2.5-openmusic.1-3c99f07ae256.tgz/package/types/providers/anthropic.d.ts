import { type ProviderAuthOption } from "../route/auth-options.js";
import type { ProviderPackage } from "../provider-package.js";
import { type ModelID, type RequestOptions } from "../schema/index.js";
import { AnthropicMessages } from "../protocols/anthropic-messages.js";
export type AnthropicOptionsInput = AnthropicMessages.OptionsInput;
export type AnthropicProviderOptionsInput = AnthropicMessages.ProviderOptionsInput;
export type AnthropicThinkingInput = AnthropicMessages.ThinkingInput;
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export declare const routes: import("../route.js").Route<{
    readonly context_management?: {
        readonly edits: readonly {
            readonly type: "compact_20260112";
            readonly trigger?: {
                readonly type: "input_tokens";
                readonly value: number;
            } | undefined;
            readonly pause_after_compaction?: boolean | undefined;
            readonly instructions?: string | undefined;
        }[];
    } | undefined;
    readonly model: string;
    readonly system?: readonly {
        readonly type: "text";
        readonly text: string;
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly messages: readonly ({
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "image";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly transformations?: {
                readonly oversized_image?: "downsize" | "error" | undefined;
            } | undefined;
        } | {
            readonly type: "video";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "document";
            readonly source: {
                readonly type: "base64";
                readonly media_type: "application/pdf";
                readonly data: string;
            } | {
                readonly type: "text";
                readonly media_type: "text/plain";
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly title?: string | undefined;
            readonly context?: string | undefined;
            readonly citations?: {
                readonly enabled: boolean;
            } | undefined;
        } | {
            readonly type: "tool_result";
            readonly tool_use_id: string;
            readonly content: string | readonly ({
                readonly type: "text";
                readonly text: string;
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "image";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly transformations?: {
                    readonly oversized_image?: "downsize" | "error" | undefined;
                } | undefined;
            } | {
                readonly type: "video";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "document";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: "application/pdf";
                    readonly data: string;
                } | {
                    readonly type: "text";
                    readonly media_type: "text/plain";
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly title?: string | undefined;
                readonly context?: string | undefined;
                readonly citations?: {
                    readonly enabled: boolean;
                } | undefined;
            })[];
            readonly is_error?: boolean | undefined;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: readonly ({
            readonly type: "compaction";
            readonly content: string | null;
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "thinking";
            readonly thinking: string;
            readonly signature: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "redacted_thinking";
            readonly data: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "server_tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "code_execution_tool_result" | "web_fetch_tool_result" | "web_search_tool_result";
            readonly tool_use_id: string;
            readonly content: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "system";
        readonly content: readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        }[];
        readonly output_config?: {
            readonly effort: string;
        } | undefined;
    })[];
    readonly tools?: readonly {
        readonly name: string;
        readonly description: string;
        readonly input_schema: {
            readonly [x: string]: unknown;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly tool_choice?: {
        readonly type: "any" | "auto" | "none";
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | {
        readonly type: "tool";
        readonly name: string;
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | undefined;
    readonly stream: true;
    readonly max_tokens: number;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly top_k?: number | undefined;
    readonly stop_sequences?: readonly string[] | undefined;
    readonly thinking?: {
        readonly type: "between_tools" | "disabled";
    } | {
        readonly display?: import("../schema/options.js").OpenString<"omitted" | "summarized"> | undefined;
        readonly block_binding?: {
            readonly prefix_mismatch_behavior?: import("../schema/options.js").OpenString<"drop_block" | "error"> | undefined;
        } | undefined;
        readonly type: "enabled";
        readonly budget_tokens: number;
    } | {
        readonly display?: import("../schema/options.js").OpenString<"omitted" | "summarized"> | undefined;
        readonly block_binding?: {
            readonly prefix_mismatch_behavior?: import("../schema/options.js").OpenString<"drop_block" | "error"> | undefined;
        } | undefined;
        readonly type: "adaptive";
    } | undefined;
    readonly output_config?: {
        readonly effort?: string | undefined;
        readonly format?: {
            readonly type: "json_schema";
            readonly schema: {
                readonly [x: string]: unknown;
            };
        } | null | undefined;
    } | undefined;
    readonly cache_control?: {
        readonly type: "ephemeral";
        readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
    } | undefined;
    readonly container?: string | {
        readonly id?: string | null | undefined;
        readonly skills?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | null | undefined;
    readonly inference_geo?: string | null | undefined;
    readonly metadata?: {
        readonly user_id?: string | null | undefined;
    } | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "standard_only"> | undefined;
    readonly speed?: import("../schema/options.js").OpenString<"fast" | "standard"> | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route.js").CompactionOperations | undefined>[];
export type Config = RequestOptions & ProviderAuthOption<"optional"> & {
    readonly baseURL?: string;
    readonly providerOptions?: AnthropicMessages.ProviderOptionsInput;
};
export type Settings = ProviderPackage.Settings & AnthropicMessages.ProviderOptionsInput & ({
    readonly apiKey?: string | false;
    readonly authToken?: never;
} | {
    readonly apiKey?: never;
    readonly authToken?: string;
}) & {
    readonly baseURL?: string;
};
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<AnthropicMessages.OptionsInput, import("../route.js").CompactionOperations | undefined>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<AnthropicMessages.OptionsInput, import("../route.js").CompactionOperations | undefined>;
    configure: typeof configure;
};
export declare const model: ProviderPackage.Model<Settings, AnthropicMessages.ProviderOptionsInput>;
