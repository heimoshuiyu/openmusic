import type { ProviderPackage } from "../provider-package.js";
import type { ProviderAuthOption } from "../route/auth-options.js";
import { Route } from "../route/client.js";
import { type ModelID, type ProviderOptions, type RequestOptions } from "../schema/index.js";
import type { OpenAIProviderOptionsInput } from "./openai-options.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type Config = Omit<RequestOptions, "providerOptions"> & ProviderAuthOption<"optional"> & {
    readonly baseURL?: string;
    readonly providerOptions?: OpenAIProviderOptionsInput;
};
export interface BasetenDecisionOptions {
    readonly [key: string]: unknown;
    readonly max_len?: number;
}
export type Settings = ProviderPackage.Settings & OpenAIProviderOptionsInput & {
    readonly apiKey?: string | false;
    readonly baseURL?: string;
};
export declare const route: Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>;
export declare const routes: Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>[];
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<BasetenDecisionOptions>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<BasetenDecisionOptions>;
    configure: typeof configure;
};
export declare const decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<BasetenDecisionOptions>;
export declare const model: ProviderPackage.Model<Settings, OpenAIProviderOptionsInput>;
export declare const decisionModel: (modelID: string, settings?: Settings) => import("../decision.js").DecisionModel<BasetenDecisionOptions>;
export * as Baseten from "./baseten.js";
