import { type ProviderAuthOption } from "../route/auth-options.js";
import type { ProviderPackage } from "../provider-package.js";
import { type ModelID, type ProviderOptions, type RequestOptions } from "../schema/index.js";
import { Gemini } from "../protocols/gemini.js";
import { GoogleInteractions } from "../protocols/google-interactions.js";
export type { GoogleImageOptions } from "../protocols/google-images.js";
export type { GoogleSpeechOptions } from "../protocols/google-speech.js";
export type { GoogleTranscriptionOptions } from "../protocols/google-transcription.js";
export type { GoogleVideoOptions } from "../protocols/google-video.js";
export type GeminiOptionsInput = Gemini.OptionsInput;
export type GeminiProviderOptionsInput = Gemini.ProviderOptionsInput;
export type GoogleInteractionsOptionsInput = GoogleInteractions.OptionsInput;
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export declare const routes: (import("../route.js").Route<{
    readonly cachedContent?: string | undefined;
    readonly contents: readonly {
        readonly role?: "model" | "user" | null | undefined;
        readonly parts?: readonly ({
            readonly fileData: {
                readonly mimeType: string;
                readonly fileUri: string;
            };
        } | {
            readonly functionResponse: {
                readonly id?: string | undefined;
                readonly name: string;
                readonly response: unknown;
                readonly parts?: readonly {
                    readonly inlineData: {
                        readonly mimeType: string;
                        readonly data: string;
                    };
                    readonly thoughtSignature?: string | null | undefined;
                }[] | undefined;
            };
        } | {
            readonly text: string;
            readonly thought?: boolean | null | undefined;
            readonly thoughtSignature?: string | null | undefined;
        } | {
            readonly inlineData: {
                readonly mimeType: string;
                readonly data: string;
            };
            readonly thoughtSignature?: string | null | undefined;
        } | {
            readonly functionCall: {
                readonly id?: string | null | undefined;
                readonly name: string;
                readonly args?: unknown;
            };
            readonly thoughtSignature?: string | null | undefined;
        })[] | null | undefined;
    }[];
    readonly labels?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safetySettings?: readonly {
        readonly category: import("../schema/options.js").OpenString<"HARM_CATEGORY_CIVIC_INTEGRITY" | "HARM_CATEGORY_DANGEROUS_CONTENT" | "HARM_CATEGORY_HARASSMENT" | "HARM_CATEGORY_HATE_SPEECH" | "HARM_CATEGORY_SEXUALLY_EXPLICIT" | "HARM_CATEGORY_UNSPECIFIED">;
        readonly threshold: import("../schema/options.js").OpenString<"BLOCK_LOW_AND_ABOVE" | "BLOCK_MEDIUM_AND_ABOVE" | "BLOCK_NONE" | "BLOCK_ONLY_HIGH" | "HARM_BLOCK_THRESHOLD_UNSPECIFIED" | "OFF">;
    }[] | undefined;
    readonly serviceTier?: string | undefined;
    readonly systemInstruction?: {
        readonly parts: readonly {
            readonly text: string;
        }[];
    } | undefined;
    readonly tools?: readonly {
        readonly functionDeclarations: readonly {
            readonly name: string;
            readonly description: string;
            readonly parametersJsonSchema: {
                readonly [x: string]: unknown;
            };
        }[];
    }[] | undefined;
    readonly toolConfig?: {
        readonly functionCallingConfig: {
            readonly mode: "ANY" | "AUTO" | "NONE";
            readonly allowedFunctionNames?: readonly string[] | undefined;
        };
    } | undefined;
    readonly generationConfig?: {
        readonly maxOutputTokens?: number | undefined;
        readonly temperature?: number | undefined;
        readonly topP?: number | undefined;
        readonly topK?: number | undefined;
        readonly frequencyPenalty?: number | undefined;
        readonly presencePenalty?: number | undefined;
        readonly seed?: number | undefined;
        readonly stopSequences?: readonly string[] | undefined;
        readonly thinkingConfig?: {
            readonly thinkingBudget?: number | undefined;
            readonly includeThoughts?: boolean | undefined;
            readonly thinkingLevel?: import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal"> | undefined;
        } | undefined;
    } | undefined;
    readonly continuationToken?: string | undefined;
}, Gemini.Prepared, import("../route.js").CompactionOperations | undefined> | import("../route.js").Route<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "model_output" | "user_input";
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "audio" | "document" | "image" | "video";
            readonly data?: string | undefined;
            readonly uri?: string | undefined;
            readonly mime_type: string;
        })[];
    } | {
        readonly type: "thought";
        readonly signature?: string | undefined;
        readonly summary?: readonly {
            readonly type: "text";
            readonly text: string;
        }[] | undefined;
    } | {
        readonly type: "function_call";
        readonly id: string;
        readonly name: string;
        readonly arguments: unknown;
        readonly signature?: string | undefined;
    } | {
        readonly type: "function_result";
        readonly call_id: string;
        readonly name: string;
        readonly result: unknown;
        readonly is_error?: boolean | undefined;
    })[];
    readonly stream: true;
    readonly store: boolean;
    readonly previous_interaction_id?: string | undefined;
    readonly system_instruction?: string | undefined;
    readonly service_tier?: string | undefined;
    readonly tools?: readonly {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
    }[] | undefined;
    readonly generation_config: {
        readonly max_output_tokens?: number | undefined;
        readonly temperature?: number | undefined;
        readonly top_p?: number | undefined;
        readonly seed?: number | undefined;
        readonly stop_sequences?: readonly string[] | undefined;
        readonly thinking_level?: import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal"> | undefined;
        readonly thinking_summaries?: string | undefined;
        readonly tool_choice?: "any" | "auto" | "none" | {
            readonly allowed_tools: {
                readonly mode: "any";
                readonly tools: readonly string[];
            };
        } | undefined;
    };
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route.js").CompactionOperations | undefined>)[];
export type Config = RequestOptions & ProviderAuthOption<"optional"> & {
    readonly baseURL?: string;
    readonly providerOptions?: Gemini.ProviderOptionsInput & GoogleInteractions.ProviderOptionsInput;
};
export type Settings = ProviderPackage.Settings & Gemini.ProviderOptionsInput & {
    readonly apiKey?: string | false;
    readonly baseURL?: string;
};
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<Gemini.OptionsInput, import("../route.js").CompactionOperations | undefined>;
    gemini: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<Gemini.OptionsInput, import("../route.js").CompactionOperations | undefined>;
    interactions: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<{
        readonly previousInteractionId?: string | undefined;
        readonly store?: boolean | undefined;
        readonly thinkingLevel?: import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal"> | undefined;
        readonly thinkingSummaries?: import("../schema/options.js").OpenString<"auto" | "none"> | undefined;
        readonly serviceTier?: import("../schema/options.js").OpenString<"deferred" | "flex" | "priority" | "standard"> | undefined;
    }, import("../route.js").CompactionOperations | undefined>;
    image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/google-images.js").GoogleImageOptions>;
    video: (modelID: string | ModelID) => import("../video.js").VideoModel<import("../protocols/google-video.js").GoogleVideoOptions>;
    speech: (modelID: string | ModelID) => import("../speech.js").SpeechModel<import("../protocols/google-speech.js").GoogleSpeechOptions>;
    transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/google-transcription.js").GoogleTranscriptionOptions>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<Gemini.OptionsInput, import("../route.js").CompactionOperations | undefined>;
    gemini: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<Gemini.OptionsInput, import("../route.js").CompactionOperations | undefined>;
    interactions: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<{
        readonly previousInteractionId?: string | undefined;
        readonly store?: boolean | undefined;
        readonly thinkingLevel?: import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal"> | undefined;
        readonly thinkingSummaries?: import("../schema/options.js").OpenString<"auto" | "none"> | undefined;
        readonly serviceTier?: import("../schema/options.js").OpenString<"deferred" | "flex" | "priority" | "standard"> | undefined;
    }, import("../route.js").CompactionOperations | undefined>;
    image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/google-images.js").GoogleImageOptions>;
    video: (modelID: string | ModelID) => import("../video.js").VideoModel<import("../protocols/google-video.js").GoogleVideoOptions>;
    speech: (modelID: string | ModelID) => import("../speech.js").SpeechModel<import("../protocols/google-speech.js").GoogleSpeechOptions>;
    transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/google-transcription.js").GoogleTranscriptionOptions>;
    configure: typeof configure;
};
export declare const model: ProviderPackage.Model<Settings, Gemini.ProviderOptionsInput>;
export declare const imageModel: (modelID: string, settings?: Settings) => import("../image.js").ImageModel<import("../protocols/google-images.js").GoogleImageOptions>;
export declare const image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/google-images.js").GoogleImageOptions>;
export declare const gemini: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<Gemini.OptionsInput, import("../route.js").CompactionOperations | undefined>;
export declare const interactions: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<{
    readonly previousInteractionId?: string | undefined;
    readonly store?: boolean | undefined;
    readonly thinkingLevel?: import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal"> | undefined;
    readonly thinkingSummaries?: import("../schema/options.js").OpenString<"auto" | "none"> | undefined;
    readonly serviceTier?: import("../schema/options.js").OpenString<"deferred" | "flex" | "priority" | "standard"> | undefined;
}, import("../route.js").CompactionOperations | undefined>;
export declare const video: (modelID: string | ModelID) => import("../video.js").VideoModel<import("../protocols/google-video.js").GoogleVideoOptions>;
export declare const speech: (modelID: string | ModelID) => import("../speech.js").SpeechModel<import("../protocols/google-speech.js").GoogleSpeechOptions>;
export declare const transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/google-transcription.js").GoogleTranscriptionOptions>;
