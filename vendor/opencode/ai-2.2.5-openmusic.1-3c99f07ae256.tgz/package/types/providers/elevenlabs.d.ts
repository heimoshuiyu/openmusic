import { type ProviderAuthOption } from "../route/auth-options.js";
import { type HttpOptions, type ModelID } from "../schema/index.js";
export type { ElevenLabsOutputFormat, ElevenLabsSpeechOptions } from "../protocols/elevenlabs-speech.js";
export type { ElevenLabsTranscriptionOptions } from "../protocols/elevenlabs-transcription.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type Config = ProviderAuthOption<"optional"> & {
    readonly baseURL?: string;
    readonly headers?: Record<string, string>;
    readonly http?: HttpOptions;
};
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    speech: (modelID: string | ModelID) => import("../speech.js").SpeechModel<import("../protocols/elevenlabs-speech.js").ElevenLabsSpeechOptions>;
    transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/elevenlabs-transcription.js").ElevenLabsTranscriptionOptions>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    speech: (modelID: string | ModelID) => import("../speech.js").SpeechModel<import("../protocols/elevenlabs-speech.js").ElevenLabsSpeechOptions>;
    transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/elevenlabs-transcription.js").ElevenLabsTranscriptionOptions>;
    configure: typeof configure;
};
export declare const speech: (modelID: string | ModelID) => import("../speech.js").SpeechModel<import("../protocols/elevenlabs-speech.js").ElevenLabsSpeechOptions>;
export declare const transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/elevenlabs-transcription.js").ElevenLabsTranscriptionOptions>;
