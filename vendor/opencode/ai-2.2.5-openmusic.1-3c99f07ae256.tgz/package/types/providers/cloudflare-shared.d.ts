import { type ProviderID } from "../schema/index.js";
type AccountURL = {
    readonly accountId?: string;
    readonly baseURL?: string;
};
export declare const requireAccountId: (input: AccountURL, provider: ProviderID, name: string) => string;
export declare const baseURL: (input: AccountURL, provider: ProviderID, name: string) => string;
export declare const runBaseURL: (input: AccountURL, provider: ProviderID, name: string) => string;
export * as CloudflareShared from "./cloudflare-shared.js";
