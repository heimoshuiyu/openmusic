import type { ProviderPackage } from "../provider-package.js";
import { AlibabaChat } from "../protocols/alibaba-chat.js";
import { AlibabaMessages } from "../protocols/alibaba-messages.js";
import { AlibabaResponses } from "../protocols/alibaba-responses.js";
import { type AtLeastOne, type ProviderAuthOption } from "../route/auth-options.js";
import { Route } from "../route/client.js";
import { ToolDefinition, type ModelID, type ProviderOptions, type RequestOptions } from "../schema/index.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type Region = "ap-southeast-1" | "cn-beijing" | "cn-hongkong" | "us-east-1" | "eu-central-1" | "ap-northeast-1" | (string & {});
export type ChatOptionsInput = AlibabaChat.OptionsInput;
export type MessagesOptionsInput = AlibabaMessages.OptionsInput;
export type ResponsesOptionsInput = AlibabaResponses.OptionsInput;
export type { AlibabaImageOptions } from "../protocols/alibaba-images.js";
type Location = AtLeastOne<{
    readonly region: Region;
    /** Overrides the selected API's complete base URL, including its version prefix. */
    readonly baseURL: string;
}> & {
    readonly workspaceID?: string;
};
export type Config = Location & Omit<RequestOptions, "providerOptions"> & ProviderAuthOption<"optional"> & {
    readonly providerOptions?: ChatOptionsInput | MessagesOptionsInput | ResponsesOptionsInput;
};
export type Settings<Options = ChatOptionsInput> = Location & ProviderPackage.Settings & Options & {
    readonly apiKey?: string | false;
};
export declare const routes: (Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
    readonly enable_thinking?: boolean | undefined;
    readonly thinking_budget?: number | undefined;
    readonly preserve_thinking?: boolean | undefined;
    readonly clear_thinking?: boolean | undefined;
    readonly thinking?: {
        readonly type: import("../schema/options.js").OpenString<"adaptive" | "disabled">;
    } | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly repetition_penalty?: number | undefined;
    readonly top_k?: number | undefined;
    readonly response_format?: {
        readonly type: import("../schema/options.js").OpenString<"json_object" | "json_schema" | "text">;
        readonly json_schema?: {
            readonly [x: string]: unknown;
        } | undefined;
    } | undefined;
    readonly enable_search?: boolean | undefined;
    readonly search_options?: {
        readonly forced_search?: boolean | undefined;
        readonly search_strategy?: import("../schema/options.js").OpenString<"agent" | "agent_max" | "max" | "turbo"> | undefined;
        readonly enable_search_extension?: boolean | undefined;
    } | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined> | Route<{
    readonly context_management?: {
        readonly edits: readonly {
            readonly type: "compact_20260112";
            readonly trigger?: {
                readonly type: "input_tokens";
                readonly value: number;
            } | undefined;
            readonly pause_after_compaction?: boolean | undefined;
            readonly instructions?: string | undefined;
        }[];
    } | undefined;
    readonly model: string;
    readonly system?: readonly {
        readonly type: "text";
        readonly text: string;
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly messages: readonly ({
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "image";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly transformations?: {
                readonly oversized_image?: "downsize" | "error" | undefined;
            } | undefined;
        } | {
            readonly type: "video";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "document";
            readonly source: {
                readonly type: "base64";
                readonly media_type: "application/pdf";
                readonly data: string;
            } | {
                readonly type: "text";
                readonly media_type: "text/plain";
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly title?: string | undefined;
            readonly context?: string | undefined;
            readonly citations?: {
                readonly enabled: boolean;
            } | undefined;
        } | {
            readonly type: "tool_result";
            readonly tool_use_id: string;
            readonly content: string | readonly ({
                readonly type: "text";
                readonly text: string;
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "image";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly transformations?: {
                    readonly oversized_image?: "downsize" | "error" | undefined;
                } | undefined;
            } | {
                readonly type: "video";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "document";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: "application/pdf";
                    readonly data: string;
                } | {
                    readonly type: "text";
                    readonly media_type: "text/plain";
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly title?: string | undefined;
                readonly context?: string | undefined;
                readonly citations?: {
                    readonly enabled: boolean;
                } | undefined;
            })[];
            readonly is_error?: boolean | undefined;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: readonly ({
            readonly type: "compaction";
            readonly content: string | null;
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "thinking";
            readonly thinking: string;
            readonly signature: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "redacted_thinking";
            readonly data: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "server_tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "code_execution_tool_result" | "web_fetch_tool_result" | "web_search_tool_result";
            readonly tool_use_id: string;
            readonly content: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "system";
        readonly content: readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        }[];
        readonly output_config?: {
            readonly effort: string;
        } | undefined;
    })[];
    readonly tools?: readonly {
        readonly name: string;
        readonly description: string;
        readonly input_schema: {
            readonly [x: string]: unknown;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly tool_choice?: {
        readonly type: "any" | "auto" | "none";
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | {
        readonly type: "tool";
        readonly name: string;
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | undefined;
    readonly stream: true;
    readonly max_tokens: number;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly top_k?: number | undefined;
    readonly stop_sequences?: readonly string[] | undefined;
    readonly output_config?: {
        readonly effort?: string | undefined;
        readonly format?: {
            readonly type: "json_schema";
            readonly schema: {
                readonly [x: string]: unknown;
            };
        } | null | undefined;
    } | undefined;
    readonly cache_control?: {
        readonly type: "ephemeral";
        readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
    } | undefined;
    readonly container?: string | {
        readonly id?: string | null | undefined;
        readonly skills?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | null | undefined;
    readonly inference_geo?: string | null | undefined;
    readonly metadata?: {
        readonly user_id?: string | null | undefined;
    } | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "standard_only"> | undefined;
    readonly speed?: import("../schema/options.js").OpenString<"fast" | "standard"> | undefined;
    readonly thinking?: {
        readonly type: string;
        readonly budget_tokens?: number | undefined;
    } | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined> | Route<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: import("../schema/options.js").ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly reasoning?: {
        readonly effort?: import("../schema/options.js").ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
    } | undefined;
    readonly text?: {
        readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly enable_thinking?: boolean | undefined;
    readonly previous_response_id?: string | undefined;
    readonly conversation?: string | undefined;
    readonly stream: true;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>)[];
export declare const configure: (input: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (id: string | ModelID) => import("../schema/options.js").LanguageModel<{
        readonly reasoningEffort?: import("../schema/options.js").ReasoningEffort | undefined;
        readonly enableThinking?: boolean | undefined;
        readonly thinkingBudget?: number | undefined;
        readonly preserveThinking?: boolean | undefined;
        readonly clearThinking?: boolean | undefined;
        readonly thinking?: {
            readonly type: import("../schema/options.js").OpenString<"adaptive" | "disabled">;
        } | undefined;
        readonly toolStream?: boolean | undefined;
        readonly parallelToolCalls?: boolean | undefined;
        readonly repetitionPenalty?: number | undefined;
        readonly responseFormat?: {
            readonly type: import("../schema/options.js").OpenString<"json_object" | "json_schema" | "text">;
            readonly json_schema?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly enableSearch?: boolean | undefined;
        readonly searchOptions?: {
            readonly forced_search?: boolean | undefined;
            readonly search_strategy?: import("../schema/options.js").OpenString<"agent" | "agent_max" | "max" | "turbo"> | undefined;
            readonly enable_search_extension?: boolean | undefined;
        } | undefined;
    }, import("../route/client.js").CompactionOperations | undefined>;
    chat: (id: string | ModelID) => import("../schema/options.js").LanguageModel<{
        readonly reasoningEffort?: import("../schema/options.js").ReasoningEffort | undefined;
        readonly enableThinking?: boolean | undefined;
        readonly thinkingBudget?: number | undefined;
        readonly preserveThinking?: boolean | undefined;
        readonly clearThinking?: boolean | undefined;
        readonly thinking?: {
            readonly type: import("../schema/options.js").OpenString<"adaptive" | "disabled">;
        } | undefined;
        readonly toolStream?: boolean | undefined;
        readonly parallelToolCalls?: boolean | undefined;
        readonly repetitionPenalty?: number | undefined;
        readonly responseFormat?: {
            readonly type: import("../schema/options.js").OpenString<"json_object" | "json_schema" | "text">;
            readonly json_schema?: {
                readonly [x: string]: unknown;
            } | undefined;
        } | undefined;
        readonly enableSearch?: boolean | undefined;
        readonly searchOptions?: {
            readonly forced_search?: boolean | undefined;
            readonly search_strategy?: import("../schema/options.js").OpenString<"agent" | "agent_max" | "max" | "turbo"> | undefined;
            readonly enable_search_extension?: boolean | undefined;
        } | undefined;
    }, import("../route/client.js").CompactionOperations | undefined>;
    messages: (id: string | ModelID) => import("../schema/options.js").LanguageModel<AlibabaMessages.OptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    responses: (id: string | ModelID) => import("../schema/options.js").LanguageModel<{
        readonly reasoningEffort?: import("../schema/options.js").ReasoningEffort | undefined;
        readonly enableThinking?: boolean | undefined;
        readonly store?: boolean | undefined;
        readonly previousResponseId?: string | undefined;
        readonly conversation?: string | undefined;
    }, import("../route/client.js").CompactionOperations | undefined>;
    image: (id: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("./alibaba.js").AlibabaImageOptions>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    configure: typeof configure;
};
export declare const model: ProviderPackage.Model<Settings, ChatOptionsInput>;
export declare const messagesModel: ProviderPackage.Model<Settings<MessagesOptionsInput>, MessagesOptionsInput>;
export declare const responsesModel: ProviderPackage.Model<Settings<ResponsesOptionsInput>, ResponsesOptionsInput>;
export declare const chat: ProviderPackage.Model<Settings<{
    readonly reasoningEffort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly enableThinking?: boolean | undefined;
    readonly thinkingBudget?: number | undefined;
    readonly preserveThinking?: boolean | undefined;
    readonly clearThinking?: boolean | undefined;
    readonly thinking?: {
        readonly type: import("../schema/options.js").OpenString<"adaptive" | "disabled">;
    } | undefined;
    readonly toolStream?: boolean | undefined;
    readonly parallelToolCalls?: boolean | undefined;
    readonly repetitionPenalty?: number | undefined;
    readonly responseFormat?: {
        readonly type: import("../schema/options.js").OpenString<"json_object" | "json_schema" | "text">;
        readonly json_schema?: {
            readonly [x: string]: unknown;
        } | undefined;
    } | undefined;
    readonly enableSearch?: boolean | undefined;
    readonly searchOptions?: {
        readonly forced_search?: boolean | undefined;
        readonly search_strategy?: import("../schema/options.js").OpenString<"agent" | "agent_max" | "max" | "turbo"> | undefined;
        readonly enable_search_extension?: boolean | undefined;
    } | undefined;
}>, {
    readonly reasoningEffort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly enableThinking?: boolean | undefined;
    readonly thinkingBudget?: number | undefined;
    readonly preserveThinking?: boolean | undefined;
    readonly clearThinking?: boolean | undefined;
    readonly thinking?: {
        readonly type: import("../schema/options.js").OpenString<"adaptive" | "disabled">;
    } | undefined;
    readonly toolStream?: boolean | undefined;
    readonly parallelToolCalls?: boolean | undefined;
    readonly repetitionPenalty?: number | undefined;
    readonly responseFormat?: {
        readonly type: import("../schema/options.js").OpenString<"json_object" | "json_schema" | "text">;
        readonly json_schema?: {
            readonly [x: string]: unknown;
        } | undefined;
    } | undefined;
    readonly enableSearch?: boolean | undefined;
    readonly searchOptions?: {
        readonly forced_search?: boolean | undefined;
        readonly search_strategy?: import("../schema/options.js").OpenString<"agent" | "agent_max" | "max" | "turbo"> | undefined;
        readonly enable_search_extension?: boolean | undefined;
    } | undefined;
}, import("../route/client.js").CompactionOperations | undefined>;
export declare const messages: ProviderPackage.Model<Settings<AlibabaMessages.OptionsInput>, AlibabaMessages.OptionsInput, import("../route/client.js").CompactionOperations | undefined>;
export declare const responses: ProviderPackage.Model<Settings<{
    readonly reasoningEffort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly enableThinking?: boolean | undefined;
    readonly store?: boolean | undefined;
    readonly previousResponseId?: string | undefined;
    readonly conversation?: string | undefined;
}>, {
    readonly reasoningEffort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly enableThinking?: boolean | undefined;
    readonly store?: boolean | undefined;
    readonly previousResponseId?: string | undefined;
    readonly conversation?: string | undefined;
}, import("../route/client.js").CompactionOperations | undefined>;
export declare const imageModel: (id: string, settings: Settings) => import("../image.js").ImageModel<import("./alibaba.js").AlibabaImageOptions>;
export declare const webSearch: () => ToolDefinition;
export declare const webExtractor: () => ToolDefinition;
export declare const codeInterpreter: () => ToolDefinition;
export * as Alibaba from "./alibaba.js";
