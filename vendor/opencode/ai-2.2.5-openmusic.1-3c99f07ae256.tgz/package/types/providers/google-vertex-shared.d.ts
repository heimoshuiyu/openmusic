import type { AnyAuthClient } from "google-auth-library";
import type { ProviderPackage } from "../provider-package.js";
import { Auth } from "../route/auth.js";
import type { CompactionOperations, Route } from "../route/client.js";
import { type RequestOptions } from "../schema/index.js";
export declare const loadADCClient: (project?: string) => Promise<AnyAuthClient>;
export type OAuthOptions = {
    readonly accessToken?: string;
    readonly auth?: never;
} | {
    readonly accessToken?: never;
    readonly auth?: Auth.Definition;
};
export type ApiKeyOptions = (OAuthOptions & {
    readonly apiKey?: never;
}) | {
    readonly accessToken?: never;
    readonly apiKey?: string;
    readonly auth?: never;
};
export declare const project: (value?: string) => string | undefined;
export declare const location: (value: string | undefined) => string;
export declare const host: (location: string) => string;
export declare const requireProject: (value: string | undefined) => string;
export declare const apiKey: (input: ApiKeyOptions & {
    readonly project?: string;
    readonly location?: string;
}) => string | undefined;
export declare const oauth: (input: OAuthOptions, project?: string) => Auth.Definition;
export declare const oauthRoute: <Body, Prepared, Compact extends CompactionOperations | undefined>(route: Route<Body, Prepared, Compact>, label: string, input: RequestOptions & OAuthOptions & {
    readonly baseURL?: string;
    readonly location?: string;
    readonly project?: string;
}, url: (project: string, location: string) => string) => Route<Body, Prepared, Compact>;
export declare const oauthSettings: <Options>(label: string, { accessToken, apiKey, baseURL, body, headers, location, project, ...providerOptions }: ProviderPackage.Settings & Options & {
    readonly accessToken?: string;
    readonly apiKey?: never;
    readonly baseURL?: string;
    readonly location?: string;
    readonly project?: string;
}) => {
    accessToken: string | undefined;
    baseURL: string | undefined;
    headers: Readonly<Record<string, string>> | undefined;
    http: {
        body: Readonly<Record<string, unknown>>;
    } | undefined;
    location: string | undefined;
    project: string | undefined;
    providerOptions: Omit<ProviderPackage.Settings & Options & {
        readonly accessToken?: string;
        readonly apiKey?: never;
        readonly baseURL?: string;
        readonly location?: string;
        readonly project?: string;
    }, "accessToken" | "apiKey" | "baseURL" | "body" | "headers" | "location" | "project">;
};
export * as GoogleVertexShared from "./google-vertex-shared.js";
