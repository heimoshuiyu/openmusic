import type { ProviderPackage } from "../provider-package.js";
import { type ModelID, type RequestOptions } from "../schema/index.js";
import * as BedrockConverse from "../protocols/bedrock-converse.js";
import type { BedrockCredentials } from "../protocols/bedrock-converse.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type Config = RequestOptions & {
    /** Bedrock API key. Falls back to `AWS_BEARER_TOKEN_BEDROCK`; bearer auth takes precedence over SigV4. */
    readonly apiKey?: string;
    /** `sigv4` ignores `apiKey` fallbacks from the environment; `bearer` requires a token. */
    readonly auth?: "bearer" | "sigv4";
    readonly headers?: Record<string, string>;
    /** Static SigV4 credentials. When omitted the AWS default credential chain resolves them per request. */
    readonly credentials?: BedrockCredentials;
    /** Shared config profile for the default credential chain. */
    readonly profile?: string;
    /** AWS region. Falls back to `credentials.region`, `AWS_REGION`, `AWS_DEFAULT_REGION`, then `us-east-1`. */
    readonly region?: string;
    /** Override the computed `https://bedrock-runtime.<region>.amazonaws.com` URL. */
    readonly baseURL?: string;
    readonly providerOptions?: BedrockConverse.OptionsInput;
};
export type Settings = ProviderPackage.Settings & BedrockConverse.OptionsInput & {
    readonly apiKey?: string;
    readonly auth?: "bearer" | "sigv4";
    readonly baseURL?: string;
    readonly credentials?: BedrockCredentials;
    readonly profile?: string;
    readonly region?: string;
    readonly topP?: number;
};
export declare const routes: import("../route.js").Route<{
    readonly modelId: string;
    readonly messages: readonly ({
        readonly role: "user";
        readonly content: readonly ({
            readonly cachePoint: {
                readonly type: "default";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            };
        } | {
            readonly image: {
                readonly format: "gif" | "jpeg" | "png" | "webp";
                readonly source: {
                    readonly bytes: string;
                };
            };
        } | {
            readonly document: {
                readonly format: "csv" | "doc" | "docx" | "html" | "md" | "pdf" | "txt" | "xls" | "xlsx";
                readonly name: string;
                readonly source: {
                    readonly bytes: string;
                };
            };
        } | {
            readonly text: string;
        } | {
            readonly toolResult: {
                readonly toolUseId: string;
                readonly content: readonly ({
                    readonly image: {
                        readonly format: "gif" | "jpeg" | "png" | "webp";
                        readonly source: {
                            readonly bytes: string;
                        };
                    };
                } | {
                    readonly document: {
                        readonly format: "csv" | "doc" | "docx" | "html" | "md" | "pdf" | "txt" | "xls" | "xlsx";
                        readonly name: string;
                        readonly source: {
                            readonly bytes: string;
                        };
                    };
                } | {
                    readonly text: string;
                } | {
                    readonly json: unknown;
                })[];
                readonly status?: "error" | "success" | undefined;
            };
        })[];
    } | {
        readonly role: "assistant";
        readonly content: readonly ({
            readonly cachePoint: {
                readonly type: "default";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            };
        } | {
            readonly text: string;
        } | {
            readonly toolUse: {
                readonly toolUseId: string;
                readonly name: string;
                readonly input: unknown;
            };
        } | {
            readonly reasoningContent: {
                readonly reasoningText: {
                    readonly text: string;
                    readonly signature?: string | undefined;
                };
            } | {
                readonly redactedContent: string;
            };
        })[];
    })[];
    readonly system?: readonly ({
        readonly cachePoint: {
            readonly type: "default";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        };
    } | {
        readonly text: string;
    })[] | undefined;
    readonly inferenceConfig?: {
        readonly maxTokens?: number | undefined;
        readonly temperature?: number | undefined;
        readonly topP?: number | undefined;
        readonly stopSequences?: readonly string[] | undefined;
    } | undefined;
    readonly toolConfig?: {
        readonly tools: readonly ({
            readonly cachePoint: {
                readonly type: "default";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            };
        } | {
            readonly toolSpec: {
                readonly name: string;
                readonly description?: string | undefined;
                readonly inputSchema: {
                    readonly json: {
                        readonly [x: string]: unknown;
                    };
                };
            };
        })[];
        readonly toolChoice?: {
            readonly auto: {};
        } | {
            readonly any: {};
        } | {
            readonly tool: {
                readonly name: string;
            };
        } | undefined;
    } | undefined;
    readonly additionalModelRequestFields?: {
        readonly [x: string]: unknown;
    } | undefined;
    readonly serviceTier?: {
        readonly type: import("../schema/options.js").OpenString<"default" | "flex" | "priority" | "reserved">;
    } | undefined;
    readonly guardrailConfig?: {
        readonly guardrailIdentifier: string;
        readonly guardrailVersion: string;
        readonly trace?: import("../schema/options.js").OpenString<"disabled" | "enabled" | "enabled_full"> | undefined;
        readonly streamProcessingMode?: import("../schema/options.js").OpenString<"async" | "sync"> | undefined;
    } | undefined;
    readonly outputConfig?: {
        readonly textFormat: {
            readonly type: import("../schema/options.js").OpenString<"json_schema">;
            readonly structure: {
                readonly jsonSchema: {
                    readonly schema: string;
                    readonly name?: string | undefined;
                    readonly description?: string | undefined;
                };
            };
        };
    } | undefined;
    readonly requestMetadata?: {
        readonly [x: string]: string;
    } | undefined;
}, import("../route/transport/http.js").HttpPrepared<{
    readonly [x: string]: unknown;
    readonly rawBody: string;
}>, import("../route.js").CompactionOperations | undefined>[];
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<BedrockConverse.OptionsInput, import("../route.js").CompactionOperations | undefined>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<BedrockConverse.OptionsInput, import("../route.js").CompactionOperations | undefined>;
    configure: typeof configure;
};
export declare const model: ProviderPackage.Model<Settings, BedrockConverse.OptionsInput>;
