import type { ProviderPackage } from "../provider-package.js";
import { MistralChat } from "../protocols/mistral-chat.js";
import { Route } from "../route/client.js";
import { HttpTransport } from "../route/transport/index.js";
import { type ModelID, type RequestOptions } from "../schema/index.js";
import { GoogleVertexShared } from "./google-vertex-shared.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type Config = RequestOptions & GoogleVertexShared.OAuthOptions & {
    readonly baseURL?: string;
    readonly location?: string;
    readonly project?: string;
    readonly providerOptions?: MistralChat.ProviderOptionsInput;
};
export type Settings = ProviderPackage.Settings & MistralChat.ProviderOptionsInput & {
    readonly accessToken?: string;
    readonly apiKey?: never;
    readonly baseURL?: string;
    readonly location?: string;
    readonly project?: string;
};
export declare const routes: Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
        }[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly name: string;
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly [x: string]: unknown;
            readonly type: "thinking";
            readonly thinking: readonly {
                readonly [x: string]: unknown;
                readonly type?: string | undefined;
                readonly text?: string | undefined;
            }[];
        })[];
        readonly tool_calls?: readonly {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
        }[] | undefined;
        readonly prefix?: true | undefined;
    })[];
    readonly tools?: readonly {
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict: false;
        };
    }[] | undefined;
    readonly tool_choice?: "any" | "auto" | "none" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly max_tokens?: number | undefined;
    readonly random_seed?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly stop?: readonly string[] | undefined;
    readonly safe_prompt?: boolean | undefined;
    readonly document_image_limit?: number | undefined;
    readonly document_page_limit?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly reasoning_effort?: string | undefined;
    readonly prompt_mode?: "reasoning" | undefined;
}, HttpTransport.HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>[];
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<MistralChat.ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    configure: typeof configure;
};
export declare const model: ProviderPackage.Model<Settings, MistralChat.ProviderOptionsInput>;
