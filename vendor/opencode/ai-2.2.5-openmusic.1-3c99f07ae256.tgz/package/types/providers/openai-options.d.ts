import { type ProviderOptions } from "../schema/index.js";
import type { Options, ResponseIncludable, ServiceTier } from "../protocols/utils/open-responses-options.js";
import type { ContextManagement, ReasoningContext, ReasoningMode } from "../protocols/openai-responses.js";
export type OpenAIResponseIncludable = ResponseIncludable;
export type OpenAIServiceTier = ServiceTier | "scale" | "fast" | "ultrafast";
export type OpenAIOptionsInput = Omit<Options, "serviceTier"> & {
    /** Advanced in-band compaction. The caller owns checkpoint persistence and recovery. */
    readonly contextManagement?: ContextManagement;
    readonly reasoningMode?: ReasoningMode;
    readonly reasoningContext?: ReasoningContext;
    readonly serviceTier?: OpenAIServiceTier;
    readonly [key: string]: unknown;
};
export type OpenAIProviderOptionsInput = OpenAIOptionsInput;
export declare const gpt5DefaultOptions: (modelID: string) => ProviderOptions | undefined;
export declare const openAIDefaultOptions: (modelID: string) => ProviderOptions | undefined;
export declare const withOpenAIOptions: <Options extends {
    readonly providerOptions?: ProviderOptions;
}>(modelID: string, options: Options) => Omit<Options, "providerOptions"> & {
    readonly providerOptions?: ProviderOptions;
};
