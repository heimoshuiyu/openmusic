import { type ProviderAuthOption } from "../route/auth-options.js";
import { type HttpOptions, type ModelID } from "../schema/index.js";
export type { AssemblyAITranscriptionOptions } from "../protocols/assemblyai-transcription.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type Config = ProviderAuthOption<"optional"> & {
    /** `https://api.eu.assemblyai.com` for the EU region. */
    readonly baseURL?: string;
    readonly headers?: Record<string, string>;
    readonly http?: HttpOptions;
};
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/assemblyai-transcription.js").AssemblyAITranscriptionOptions>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/assemblyai-transcription.js").AssemblyAITranscriptionOptions>;
    configure: typeof configure;
};
export declare const transcription: (modelID: string | ModelID) => import("../transcription.js").TranscriptionModel<import("../protocols/assemblyai-transcription.js").AssemblyAITranscriptionOptions>;
