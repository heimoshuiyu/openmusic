import { AnthropicMessages } from "../protocols/anthropic-messages.js";
import type { ProviderPackage } from "../provider-package.js";
import type { ProviderAuthOption } from "../route/auth-options.js";
import { Route } from "../route/client.js";
import { ModelID, type ProviderOptions, type RequestOptions } from "../schema/index.js";
import type { OpenResponsesProviderOptionsInput } from "./open-responses-options.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export interface GatewayOptions {
    /** Service-owned options added by the Gateway without requiring an SDK update. */
    readonly [key: string]: unknown;
    /** Enables Gateway automatic prompt-cache breakpoint injection (`"auto"`). */
    readonly caching?: "auto" | (string & {});
    /** Provider slugs that are the only ones allowed to serve the request (e.g. `["anthropic", "vertex"]`). */
    readonly only?: ReadonlyArray<string>;
    /** Provider slugs specifying the order in which providers are tried (e.g. `["bedrock", "anthropic"]`). */
    readonly order?: ReadonlyArray<string>;
    /** Sort candidate providers by cost (`"cost"`), throughput (`"tps"`), or time-to-first-token (`"ttft"`). */
    readonly sort?: "cost" | "tps" | "ttft" | (string & {});
    /** Fallback models to try in order. */
    readonly models?: ReadonlyArray<string | Readonly<Record<string, unknown>>>;
    /** Restrict routing to providers with zero data retention agreements. */
    readonly zeroDataRetention?: boolean;
    /** Restrict routing to providers that do not train on prompt data. */
    readonly disallowPromptTraining?: boolean;
    /**
     * Restrict routing to provider models that satisfy every entry: capability
     * tags (`"implicit-caching"`, `"reasoning"`, `"structured-output"`,
     * `"tool-use"`, `"vision"`) or weight-format filters (`"quantization:fp8"`,
     * `"!quantization:fp8"`).
     */
    readonly has?: ReadonlyArray<"implicit-caching" | "reasoning" | "structured-output" | "tool-use" | "vision" | `quantization:${string}` | `!quantization:${string}` | (string & {})>;
    /** Entity identifier against which Gateway quota is tracked. */
    readonly quotaEntityId?: string;
    /** Unified service tier intent (`"flex"` or `"priority"`). */
    readonly serviceTier?: "flex" | "priority" | (string & {});
    /** End-user identifier for spend tracking and attribution. */
    readonly user?: string;
    /** User-specified tags for reporting and filtering usage. */
    readonly tags?: ReadonlyArray<string>;
    /** Request-scoped BYOK credentials keyed by provider slug, used instead of cached workspace credentials. */
    readonly byok?: Readonly<Record<string, ReadonlyArray<Readonly<Record<string, unknown>>>>>;
    /** Preferred inference region for upstream provider routing. */
    readonly inferenceRegion?: string;
    /** Per-provider timeouts in milliseconds (e.g. `{ byok: { anthropic: 3000 } }`). */
    readonly providerTimeouts?: {
        readonly [key: string]: unknown;
        readonly byok?: Readonly<Record<string, number>>;
    };
}
export type ProviderOptionsInput = OpenResponsesProviderOptionsInput & Omit<AnthropicMessages.OptionsInput, "thinking"> & {
    /** Reasoning configuration for Messages (`thinking`) or Chat (`reasoning.enabled` + `reasoning.max_tokens`). */
    readonly thinking?: AnthropicMessages.OptionsInput["thinking"] | {
        readonly type: "enabled" | "adaptive" | "disabled" | (string & {});
        readonly budgetTokens?: number;
        readonly budget_tokens?: number;
    };
    /** Gateway routing, fallback, BYOK, compliance, and attribution options sent under `body.providerOptions.gateway`. */
    readonly gateway?: GatewayOptions;
    /** Provider-specific options forwarded under their upstream namespace in `body.providerOptions` (e.g. `{ anthropic: { ... } }`). */
    readonly upstream?: Readonly<Record<string, Readonly<Record<string, unknown>>>>;
    /** Responses API automatic-cache lifetime (`"5m"` or `"1h"`), sent as top-level `cache_ttl`. */
    readonly cacheTTL?: "5m" | "1h" | (string & {});
    /** Responses API count of stable input items to anchor for caching, sent as top-level `cache_anchor_items`. */
    readonly cacheAnchorItems?: number;
};
export type Config = Omit<RequestOptions, "providerOptions"> & ProviderAuthOption<"optional"> & {
    readonly baseURL?: string;
    readonly providerOptions?: ProviderOptionsInput;
};
export type Settings = ProviderPackage.Settings & ProviderOptionsInput & {
    readonly apiKey?: string | false;
};
export declare const routes: Route<{
    readonly [x: string]: unknown;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>[];
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    messages: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    responses: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    chat: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    messages: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    responses: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    chat: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
    configure: typeof configure;
};
export declare const decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
export declare const messages: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
export declare const responses: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
export declare const chat: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
export declare const image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
export declare const model: ProviderPackage.Model<Settings, ProviderOptionsInput>;
export declare const messagesModel: ProviderPackage.Model<Settings, ProviderOptionsInput>;
export declare const responsesModel: ProviderPackage.Model<Settings, ProviderOptionsInput>;
export declare const chatModel: ProviderPackage.Model<Settings, ProviderOptionsInput>;
export declare const imageModel: (modelID: string, settings?: Settings) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
export declare const decisionModel: (modelID: string, settings?: Settings) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
export * as VercelAIGateway from "./vercel-ai-gateway.js";
