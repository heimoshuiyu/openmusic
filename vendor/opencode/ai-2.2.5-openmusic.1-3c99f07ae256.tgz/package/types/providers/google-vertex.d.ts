import type { ProviderPackage } from "../provider-package.js";
import { Gemini } from "../protocols/gemini.js";
import { Route } from "../route/client.js";
import { type ModelID, type ProviderOptions, type RequestOptions } from "../schema/index.js";
import { GoogleVertexShared } from "./google-vertex-shared.js";
export interface GeminiOptionsInput extends Gemini.OptionsInput {
    readonly labels?: Readonly<Record<string, string>>;
}
export type GeminiProviderOptionsInput = GeminiOptionsInput;
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type Config = RequestOptions & GoogleVertexShared.ApiKeyOptions & {
    readonly baseURL?: string;
    readonly location?: string;
    readonly project?: string;
    readonly providerOptions?: GeminiProviderOptionsInput;
};
export type Settings = ProviderPackage.Settings & GeminiProviderOptionsInput & ({
    readonly accessToken?: string;
    readonly apiKey?: never;
} | {
    readonly accessToken?: never;
    readonly apiKey?: string;
}) & {
    readonly baseURL?: string;
    readonly location?: string;
    readonly project?: string;
};
export declare const routes: Route<{
    readonly cachedContent?: string | undefined;
    readonly contents: readonly {
        readonly role?: "model" | "user" | null | undefined;
        readonly parts?: readonly ({
            readonly fileData: {
                readonly mimeType: string;
                readonly fileUri: string;
            };
        } | {
            readonly functionResponse: {
                readonly id?: string | undefined;
                readonly name: string;
                readonly response: unknown;
                readonly parts?: readonly {
                    readonly inlineData: {
                        readonly mimeType: string;
                        readonly data: string;
                    };
                    readonly thoughtSignature?: string | null | undefined;
                }[] | undefined;
            };
        } | {
            readonly text: string;
            readonly thought?: boolean | null | undefined;
            readonly thoughtSignature?: string | null | undefined;
        } | {
            readonly inlineData: {
                readonly mimeType: string;
                readonly data: string;
            };
            readonly thoughtSignature?: string | null | undefined;
        } | {
            readonly functionCall: {
                readonly id?: string | null | undefined;
                readonly name: string;
                readonly args?: unknown;
            };
            readonly thoughtSignature?: string | null | undefined;
        })[] | null | undefined;
    }[];
    readonly labels?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safetySettings?: readonly {
        readonly category: import("../schema/options.js").OpenString<"HARM_CATEGORY_CIVIC_INTEGRITY" | "HARM_CATEGORY_DANGEROUS_CONTENT" | "HARM_CATEGORY_HARASSMENT" | "HARM_CATEGORY_HATE_SPEECH" | "HARM_CATEGORY_SEXUALLY_EXPLICIT" | "HARM_CATEGORY_UNSPECIFIED">;
        readonly threshold: import("../schema/options.js").OpenString<"BLOCK_LOW_AND_ABOVE" | "BLOCK_MEDIUM_AND_ABOVE" | "BLOCK_NONE" | "BLOCK_ONLY_HIGH" | "HARM_BLOCK_THRESHOLD_UNSPECIFIED" | "OFF">;
    }[] | undefined;
    readonly serviceTier?: string | undefined;
    readonly systemInstruction?: {
        readonly parts: readonly {
            readonly text: string;
        }[];
    } | undefined;
    readonly tools?: readonly {
        readonly functionDeclarations: readonly {
            readonly name: string;
            readonly description: string;
            readonly parametersJsonSchema: {
                readonly [x: string]: unknown;
            };
        }[];
    }[] | undefined;
    readonly toolConfig?: {
        readonly functionCallingConfig: {
            readonly mode: "ANY" | "AUTO" | "NONE";
            readonly allowedFunctionNames?: readonly string[] | undefined;
        };
    } | undefined;
    readonly generationConfig?: {
        readonly maxOutputTokens?: number | undefined;
        readonly temperature?: number | undefined;
        readonly topP?: number | undefined;
        readonly topK?: number | undefined;
        readonly frequencyPenalty?: number | undefined;
        readonly presencePenalty?: number | undefined;
        readonly seed?: number | undefined;
        readonly stopSequences?: readonly string[] | undefined;
        readonly thinkingConfig?: {
            readonly thinkingBudget?: number | undefined;
            readonly includeThoughts?: boolean | undefined;
            readonly thinkingLevel?: import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal"> | undefined;
        } | undefined;
    } | undefined;
    readonly continuationToken?: string | undefined;
}, Gemini.Prepared, import("../route/client.js").CompactionOperations | undefined>[];
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<GeminiOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/google-images.js").GoogleImageOptions>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    configure: typeof configure;
};
export declare const model: ProviderPackage.Model<Settings, GeminiProviderOptionsInput>;
export declare const imageModel: (modelID: string, settings?: Settings) => import("../image.js").ImageModel<import("../protocols/google-images.js").GoogleImageOptions>;
