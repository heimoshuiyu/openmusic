import type { ProviderPackage } from "../provider-package.js";
import { OpenAIChat } from "../protocols/openai-chat.js";
import type { ProviderAuthOption } from "../route/auth-options.js";
import { Route } from "../route/client.js";
import { Protocol } from "../route/protocol.js";
import { type ModelID, type RequestOptions } from "../schema/index.js";
import type { OpenAIProviderOptionsInput } from "./openai-options.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type ProviderOptions = Pick<OpenAIProviderOptionsInput, "reasoningEffort"> & {
    /** Controls visible reasoning on GPT-OSS; other models always use parsed reasoning. */
    readonly includeReasoning?: boolean;
    readonly parallelToolCalls?: boolean;
    readonly serviceTier?: "on_demand" | "flex" | "auto" | "performance" | (string & {});
    readonly user?: string;
};
export type Config = Omit<RequestOptions, "providerOptions"> & ProviderAuthOption<"optional"> & {
    readonly baseURL?: string;
    readonly providerOptions?: ProviderOptions;
};
export type Settings = ProviderPackage.Settings & ProviderOptions & {
    readonly apiKey?: string | false;
    readonly baseURL?: string;
};
export declare const protocol: Protocol<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
    readonly reasoning_format?: "parsed" | undefined;
    readonly include_reasoning?: boolean | undefined;
    readonly user?: string | undefined;
}, string, "[DONE]" | {
    readonly [x: string]: unknown;
    readonly choices?: readonly {
        readonly [x: string]: unknown;
        readonly delta?: {
            readonly [x: string]: unknown;
            readonly content?: string | null | undefined;
            readonly refusal?: string | null | undefined;
            readonly reasoning_content?: string | null | undefined;
            readonly reasoning?: string | null | undefined;
            readonly reasoning_text?: string | null | undefined;
            readonly reasoning_details?: unknown;
            readonly reasoning_opaque?: string | null | undefined;
            readonly tool_calls?: readonly {
                readonly index?: number | null | undefined;
                readonly id?: string | null | undefined;
                readonly function?: {
                    readonly name?: string | null | undefined;
                    readonly arguments?: string | null | undefined;
                } | null | undefined;
                readonly custom?: {
                    readonly name?: string | null | undefined;
                    readonly input?: string | null | undefined;
                } | null | undefined;
                readonly extra_content?: unknown;
            }[] | null | undefined;
        } | null | undefined;
        readonly finish_reason?: string | null | undefined;
        readonly native_finish_reason?: string | null | undefined;
        readonly usage?: {
            readonly [x: string]: unknown;
            readonly prompt_tokens?: number | null | undefined;
            readonly completion_tokens?: number | null | undefined;
            readonly total_tokens?: number | null | undefined;
            readonly cached_tokens?: number | null | undefined;
            readonly prompt_cache_hit_tokens?: number | null | undefined;
            readonly cache_read_input_tokens?: number | null | undefined;
            readonly cache_created_input_tokens?: number | null | undefined;
            readonly reasoning_tokens?: number | null | undefined;
            readonly prompt_tokens_details?: {
                readonly [x: string]: unknown;
                readonly cached_tokens?: number | null | undefined;
                readonly cache_write_tokens?: number | null | undefined;
            } | null | undefined;
            readonly completion_tokens_details?: {
                readonly [x: string]: unknown;
                readonly reasoning_tokens?: number | null | undefined;
                readonly accepted_prediction_tokens?: number | null | undefined;
                readonly rejected_prediction_tokens?: number | null | undefined;
            } | null | undefined;
        } | null | undefined;
    }[] | null | undefined;
    readonly usage?: {
        readonly [x: string]: unknown;
        readonly prompt_tokens?: number | null | undefined;
        readonly completion_tokens?: number | null | undefined;
        readonly total_tokens?: number | null | undefined;
        readonly cached_tokens?: number | null | undefined;
        readonly prompt_cache_hit_tokens?: number | null | undefined;
        readonly cache_read_input_tokens?: number | null | undefined;
        readonly cache_created_input_tokens?: number | null | undefined;
        readonly reasoning_tokens?: number | null | undefined;
        readonly prompt_tokens_details?: {
            readonly [x: string]: unknown;
            readonly cached_tokens?: number | null | undefined;
            readonly cache_write_tokens?: number | null | undefined;
        } | null | undefined;
        readonly completion_tokens_details?: {
            readonly [x: string]: unknown;
            readonly reasoning_tokens?: number | null | undefined;
            readonly accepted_prediction_tokens?: number | null | undefined;
            readonly rejected_prediction_tokens?: number | null | undefined;
        } | null | undefined;
    } | null | undefined;
    readonly error?: {
        readonly [x: string]: unknown;
        readonly code?: string | number | null | undefined;
        readonly message: string;
    } | null | undefined;
}, OpenAIChat.ParserState>;
export declare const route: Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
    readonly reasoning_format?: "parsed" | undefined;
    readonly include_reasoning?: boolean | undefined;
    readonly user?: string | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>;
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptions, import("../route/client.js").CompactionOperations | undefined>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<ProviderOptions, import("../route/client.js").CompactionOperations | undefined>;
    configure: typeof configure;
};
export declare const model: ProviderPackage.Model<Settings, ProviderOptions>;
export * as Groq from "./groq.js";
