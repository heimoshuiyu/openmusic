import type { Config, Redacted } from "effect";
import type { ProviderPackage } from "../provider-package.js";
import { type AtLeastOne, type ProviderAuthOption } from "../route/auth-options.js";
import { type ModelID, type ProviderOptions, type RequestOptions } from "../schema/index.js";
import type { OpenAIProviderOptionsInput } from "./openai-options.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export declare const authEnvVars: readonly ["CLOUDFLARE_API_TOKEN", "CF_AIG_TOKEN"];
type GatewayURL = AtLeastOne<{
    readonly accountId: string;
    readonly baseURL: string;
}>;
type GatewayOptions = {
    readonly gatewayId?: string;
    readonly metadata?: unknown;
    readonly cacheTtl?: number;
    readonly cacheKey?: string;
    readonly skipCache?: boolean;
    readonly collectLog?: boolean;
};
export type Config = GatewayURL & GatewayOptions & Omit<RequestOptions, "providerOptions"> & ProviderAuthOption<"optional"> & {
    readonly gatewayApiKey?: string | Redacted.Redacted | Config.Config<string | Redacted.Redacted>;
    readonly providerOptions?: OpenAIProviderOptionsInput;
};
export type Settings = ProviderPackage.Settings & OpenAIProviderOptionsInput & GatewayURL & GatewayOptions & {
    readonly apiKey?: string | false;
    readonly gatewayApiKey?: string;
};
export declare const baseURL: (input: GatewayURL) => string;
/** The Run API (`/ai/run`) next to the OpenAI-compatible `/ai/v1` base. */
export declare const runBaseURL: (input: GatewayURL) => string;
export declare const responsesRoute: import("../route.js").Route<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: import("../schema/options.js").ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly text?: {
        readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "namespace";
        readonly name: string;
        readonly description: string;
        readonly tools: readonly {
            readonly type: "function";
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        }[];
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly type: "image_generation";
        readonly action?: "auto" | "edit" | "generate" | undefined;
        readonly background?: "auto" | "opaque" | "transparent" | undefined;
        readonly input_fidelity?: "high" | "low" | undefined;
        readonly output_compression?: number | undefined;
        readonly output_format?: "jpeg" | "png" | "webp" | undefined;
        readonly partial_images?: number | undefined;
        readonly quality?: "auto" | "high" | "low" | "medium" | undefined;
        readonly size?: string | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | {
        readonly type: "image_generation";
    } | undefined;
    readonly reasoning?: {
        readonly effort?: import("../schema/options.js").ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
        readonly mode?: import("../schema/options.js").OpenString<"pro" | "standard"> | undefined;
        readonly context?: import("../schema/options.js").OpenString<"all_turns" | "auto" | "current_turn"> | undefined;
    } | undefined;
    readonly context_management?: readonly {
        readonly type: "compaction";
        readonly compact_threshold?: number | undefined;
    }[] | undefined;
    readonly stream: true;
}, import("../protocols/open-responses-channel.js").Prepared, {
    endpoint: import("../route/client.js").CompactOperation;
    trigger: import("../route/client.js").TriggerCompactOperation;
}>;
export declare const messagesRoute: import("../route.js").Route<{
    readonly context_management?: {
        readonly edits: readonly {
            readonly type: "compact_20260112";
            readonly trigger?: {
                readonly type: "input_tokens";
                readonly value: number;
            } | undefined;
            readonly pause_after_compaction?: boolean | undefined;
            readonly instructions?: string | undefined;
        }[];
    } | undefined;
    readonly model: string;
    readonly system?: readonly {
        readonly type: "text";
        readonly text: string;
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly messages: readonly ({
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "image";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly transformations?: {
                readonly oversized_image?: "downsize" | "error" | undefined;
            } | undefined;
        } | {
            readonly type: "video";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "document";
            readonly source: {
                readonly type: "base64";
                readonly media_type: "application/pdf";
                readonly data: string;
            } | {
                readonly type: "text";
                readonly media_type: "text/plain";
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly title?: string | undefined;
            readonly context?: string | undefined;
            readonly citations?: {
                readonly enabled: boolean;
            } | undefined;
        } | {
            readonly type: "tool_result";
            readonly tool_use_id: string;
            readonly content: string | readonly ({
                readonly type: "text";
                readonly text: string;
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "image";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly transformations?: {
                    readonly oversized_image?: "downsize" | "error" | undefined;
                } | undefined;
            } | {
                readonly type: "video";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "document";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: "application/pdf";
                    readonly data: string;
                } | {
                    readonly type: "text";
                    readonly media_type: "text/plain";
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly title?: string | undefined;
                readonly context?: string | undefined;
                readonly citations?: {
                    readonly enabled: boolean;
                } | undefined;
            })[];
            readonly is_error?: boolean | undefined;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: readonly ({
            readonly type: "compaction";
            readonly content: string | null;
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "thinking";
            readonly thinking: string;
            readonly signature: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "redacted_thinking";
            readonly data: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "server_tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "code_execution_tool_result" | "web_fetch_tool_result" | "web_search_tool_result";
            readonly tool_use_id: string;
            readonly content: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "system";
        readonly content: readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        }[];
        readonly output_config?: {
            readonly effort: string;
        } | undefined;
    })[];
    readonly tools?: readonly {
        readonly name: string;
        readonly description: string;
        readonly input_schema: {
            readonly [x: string]: unknown;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly tool_choice?: {
        readonly type: "any" | "auto" | "none";
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | {
        readonly type: "tool";
        readonly name: string;
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | undefined;
    readonly stream: true;
    readonly max_tokens: number;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly top_k?: number | undefined;
    readonly stop_sequences?: readonly string[] | undefined;
    readonly thinking?: {
        readonly type: "between_tools" | "disabled";
    } | {
        readonly display?: import("../schema/options.js").OpenString<"omitted" | "summarized"> | undefined;
        readonly block_binding?: {
            readonly prefix_mismatch_behavior?: import("../schema/options.js").OpenString<"drop_block" | "error"> | undefined;
        } | undefined;
        readonly type: "enabled";
        readonly budget_tokens: number;
    } | {
        readonly display?: import("../schema/options.js").OpenString<"omitted" | "summarized"> | undefined;
        readonly block_binding?: {
            readonly prefix_mismatch_behavior?: import("../schema/options.js").OpenString<"drop_block" | "error"> | undefined;
        } | undefined;
        readonly type: "adaptive";
    } | undefined;
    readonly output_config?: {
        readonly effort?: string | undefined;
        readonly format?: {
            readonly type: "json_schema";
            readonly schema: {
                readonly [x: string]: unknown;
            };
        } | null | undefined;
    } | undefined;
    readonly cache_control?: {
        readonly type: "ephemeral";
        readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
    } | undefined;
    readonly container?: string | {
        readonly id?: string | null | undefined;
        readonly skills?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | null | undefined;
    readonly inference_geo?: string | null | undefined;
    readonly metadata?: {
        readonly user_id?: string | null | undefined;
    } | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "standard_only"> | undefined;
    readonly speed?: import("../schema/options.js").OpenString<"fast" | "standard"> | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route.js").CompactionOperations | undefined>;
export declare const route: import("../route.js").Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route.js").CompactionOperations | undefined>;
export declare const routes: (import("../route.js").Route<{
    readonly context_management?: {
        readonly edits: readonly {
            readonly type: "compact_20260112";
            readonly trigger?: {
                readonly type: "input_tokens";
                readonly value: number;
            } | undefined;
            readonly pause_after_compaction?: boolean | undefined;
            readonly instructions?: string | undefined;
        }[];
    } | undefined;
    readonly model: string;
    readonly system?: readonly {
        readonly type: "text";
        readonly text: string;
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly messages: readonly ({
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "image";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly transformations?: {
                readonly oversized_image?: "downsize" | "error" | undefined;
            } | undefined;
        } | {
            readonly type: "video";
            readonly source: {
                readonly type: "base64";
                readonly media_type: string;
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "document";
            readonly source: {
                readonly type: "base64";
                readonly media_type: "application/pdf";
                readonly data: string;
            } | {
                readonly type: "text";
                readonly media_type: "text/plain";
                readonly data: string;
            } | {
                readonly type: "url";
                readonly url: string;
            } | {
                readonly type: "file";
                readonly file_id: string;
            };
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
            readonly title?: string | undefined;
            readonly context?: string | undefined;
            readonly citations?: {
                readonly enabled: boolean;
            } | undefined;
        } | {
            readonly type: "tool_result";
            readonly tool_use_id: string;
            readonly content: string | readonly ({
                readonly type: "text";
                readonly text: string;
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "image";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly transformations?: {
                    readonly oversized_image?: "downsize" | "error" | undefined;
                } | undefined;
            } | {
                readonly type: "video";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: string;
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
            } | {
                readonly type: "document";
                readonly source: {
                    readonly type: "base64";
                    readonly media_type: "application/pdf";
                    readonly data: string;
                } | {
                    readonly type: "text";
                    readonly media_type: "text/plain";
                    readonly data: string;
                } | {
                    readonly type: "url";
                    readonly url: string;
                } | {
                    readonly type: "file";
                    readonly file_id: string;
                };
                readonly cache_control?: {
                    readonly type: "ephemeral";
                    readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
                } | undefined;
                readonly title?: string | undefined;
                readonly context?: string | undefined;
                readonly citations?: {
                    readonly enabled: boolean;
                } | undefined;
            })[];
            readonly is_error?: boolean | undefined;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: readonly ({
            readonly type: "compaction";
            readonly content: string | null;
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "thinking";
            readonly thinking: string;
            readonly signature: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "redacted_thinking";
            readonly data: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "server_tool_use";
            readonly id: string;
            readonly name: string;
            readonly input: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        } | {
            readonly type: "code_execution_tool_result" | "web_fetch_tool_result" | "web_search_tool_result";
            readonly tool_use_id: string;
            readonly content: unknown;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "system";
        readonly content: readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
            } | undefined;
        }[];
        readonly output_config?: {
            readonly effort: string;
        } | undefined;
    })[];
    readonly tools?: readonly {
        readonly name: string;
        readonly description: string;
        readonly input_schema: {
            readonly [x: string]: unknown;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
        } | undefined;
    }[] | undefined;
    readonly tool_choice?: {
        readonly type: "any" | "auto" | "none";
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | {
        readonly type: "tool";
        readonly name: string;
        readonly disable_parallel_tool_use?: boolean | undefined;
    } | undefined;
    readonly stream: true;
    readonly max_tokens: number;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly top_k?: number | undefined;
    readonly stop_sequences?: readonly string[] | undefined;
    readonly thinking?: {
        readonly type: "between_tools" | "disabled";
    } | {
        readonly display?: import("../schema/options.js").OpenString<"omitted" | "summarized"> | undefined;
        readonly block_binding?: {
            readonly prefix_mismatch_behavior?: import("../schema/options.js").OpenString<"drop_block" | "error"> | undefined;
        } | undefined;
        readonly type: "enabled";
        readonly budget_tokens: number;
    } | {
        readonly display?: import("../schema/options.js").OpenString<"omitted" | "summarized"> | undefined;
        readonly block_binding?: {
            readonly prefix_mismatch_behavior?: import("../schema/options.js").OpenString<"drop_block" | "error"> | undefined;
        } | undefined;
        readonly type: "adaptive";
    } | undefined;
    readonly output_config?: {
        readonly effort?: string | undefined;
        readonly format?: {
            readonly type: "json_schema";
            readonly schema: {
                readonly [x: string]: unknown;
            };
        } | null | undefined;
    } | undefined;
    readonly cache_control?: {
        readonly type: "ephemeral";
        readonly ttl?: `${number}d` | `${number}h` | `${number}m` | `${number}ms` | `${number}s` | undefined;
    } | undefined;
    readonly container?: string | {
        readonly id?: string | null | undefined;
        readonly skills?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | null | undefined;
    readonly inference_geo?: string | null | undefined;
    readonly metadata?: {
        readonly user_id?: string | null | undefined;
    } | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "standard_only"> | undefined;
    readonly speed?: import("../schema/options.js").OpenString<"fast" | "standard"> | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route.js").CompactionOperations | undefined> | import("../route.js").Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route.js").CompactionOperations | undefined> | import("../route.js").Route<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: import("../schema/options.js").ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly text?: {
        readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "namespace";
        readonly name: string;
        readonly description: string;
        readonly tools: readonly {
            readonly type: "function";
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        }[];
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly type: "image_generation";
        readonly action?: "auto" | "edit" | "generate" | undefined;
        readonly background?: "auto" | "opaque" | "transparent" | undefined;
        readonly input_fidelity?: "high" | "low" | undefined;
        readonly output_compression?: number | undefined;
        readonly output_format?: "jpeg" | "png" | "webp" | undefined;
        readonly partial_images?: number | undefined;
        readonly quality?: "auto" | "high" | "low" | "medium" | undefined;
        readonly size?: string | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | {
        readonly type: "image_generation";
    } | undefined;
    readonly reasoning?: {
        readonly effort?: import("../schema/options.js").ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
        readonly mode?: import("../schema/options.js").OpenString<"pro" | "standard"> | undefined;
        readonly context?: import("../schema/options.js").OpenString<"all_turns" | "auto" | "current_turn"> | undefined;
    } | undefined;
    readonly context_management?: readonly {
        readonly type: "compaction";
        readonly compact_threshold?: number | undefined;
    }[] | undefined;
    readonly stream: true;
}, import("../protocols/open-responses-channel.js").Prepared, {
    endpoint: import("../route/client.js").CompactOperation;
    trigger: import("../route/client.js").TriggerCompactOperation;
}>)[];
export declare const configure: (input: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (value: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, {
        endpoint: import("../route/client.js").CompactOperation;
        trigger: import("../route/client.js").TriggerCompactOperation;
    }>;
    chat: (value: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, import("../route.js").CompactionOperations | undefined>;
    responses: (value: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, {
        endpoint: import("../route/client.js").CompactOperation;
        trigger: import("../route/client.js").TriggerCompactOperation;
    }>;
    messages: (value: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, import("../route.js").CompactionOperations | undefined>;
    decision: (value: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    configure: typeof configure;
};
export declare const model: ProviderPackage.Model<Settings, OpenAIProviderOptionsInput>;
export declare const chat: ProviderPackage.Model<Settings, OpenAIProviderOptionsInput>;
export declare const responses: ProviderPackage.Model<Settings, OpenAIProviderOptionsInput>;
export declare const messages: ProviderPackage.Model<Settings, OpenAIProviderOptionsInput>;
export declare const decisionModel: (modelID: string, settings: Settings) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
export * as CloudflareAIGateway from "./cloudflare-ai-gateway.js";
