import type { ProviderPackage } from "../../provider-package.js";
import { MiniMax } from "../minimax.js";
export type Settings = MiniMax.Settings<MiniMax.ResponsesOptionsInput>;
export declare const model: ProviderPackage.Model<Settings, MiniMax.ResponsesOptionsInput>;
