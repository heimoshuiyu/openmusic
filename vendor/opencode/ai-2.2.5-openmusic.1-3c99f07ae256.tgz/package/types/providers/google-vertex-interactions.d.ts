import type { ProviderPackage } from "../provider-package.js";
import { GoogleInteractions } from "../protocols/google-interactions.js";
import { Route } from "../route/client.js";
import { type ModelID, type RequestOptions } from "../schema/index.js";
import { GoogleVertexShared } from "./google-vertex-shared.js";
export type GoogleInteractionsOptionsInput = GoogleInteractions.OptionsInput;
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type Config = RequestOptions & GoogleVertexShared.ApiKeyOptions & {
    readonly baseURL?: string;
    readonly location?: string;
    readonly project?: string;
    readonly providerOptions?: GoogleInteractions.ProviderOptionsInput;
};
export type Settings = ProviderPackage.Settings & GoogleInteractions.ProviderOptionsInput & ({
    readonly accessToken?: string;
    readonly apiKey?: never;
} | {
    readonly accessToken?: never;
    readonly apiKey?: string;
}) & {
    readonly baseURL?: string;
    readonly location?: string;
    readonly project?: string;
};
export declare const routes: Route<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "model_output" | "user_input";
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "audio" | "document" | "image" | "video";
            readonly data?: string | undefined;
            readonly uri?: string | undefined;
            readonly mime_type: string;
        })[];
    } | {
        readonly type: "thought";
        readonly signature?: string | undefined;
        readonly summary?: readonly {
            readonly type: "text";
            readonly text: string;
        }[] | undefined;
    } | {
        readonly type: "function_call";
        readonly id: string;
        readonly name: string;
        readonly arguments: unknown;
        readonly signature?: string | undefined;
    } | {
        readonly type: "function_result";
        readonly call_id: string;
        readonly name: string;
        readonly result: unknown;
        readonly is_error?: boolean | undefined;
    })[];
    readonly stream: true;
    readonly store: boolean;
    readonly previous_interaction_id?: string | undefined;
    readonly system_instruction?: string | undefined;
    readonly service_tier?: string | undefined;
    readonly tools?: readonly {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
    }[] | undefined;
    readonly generation_config: {
        readonly max_output_tokens?: number | undefined;
        readonly temperature?: number | undefined;
        readonly top_p?: number | undefined;
        readonly seed?: number | undefined;
        readonly stop_sequences?: readonly string[] | undefined;
        readonly thinking_level?: import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal"> | undefined;
        readonly thinking_summaries?: string | undefined;
        readonly tool_choice?: "any" | "auto" | "none" | {
            readonly allowed_tools: {
                readonly mode: "any";
                readonly tools: readonly string[];
            };
        } | undefined;
    };
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>[];
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<{
        readonly previousInteractionId?: string | undefined;
        readonly store?: boolean | undefined;
        readonly thinkingLevel?: import("../schema/options.js").OpenString<"high" | "low" | "medium" | "minimal"> | undefined;
        readonly thinkingSummaries?: import("../schema/options.js").OpenString<"auto" | "none"> | undefined;
        readonly serviceTier?: import("../schema/options.js").OpenString<"deferred" | "flex" | "priority" | "standard"> | undefined;
    }, import("../route/client.js").CompactionOperations | undefined>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    configure: typeof configure;
};
export declare const model: ProviderPackage.Model<Settings, GoogleInteractions.ProviderOptionsInput>;
