import type { ProviderPackage } from "../provider-package.js";
import { OpenAIChat } from "../protocols/openai-chat.js";
import type { ProviderAuthOption } from "../route/auth-options.js";
import { Route } from "../route/client.js";
import { Protocol } from "../route/protocol.js";
import { type ModelID, type ProviderOptions, type RequestOptions } from "../schema/index.js";
import type { OpenAIProviderOptionsInput } from "./openai-options.js";
import type { OpenResponsesProviderOptionsInput } from "./open-responses-options.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type Config = Omit<RequestOptions, "providerOptions"> & ProviderAuthOption<"optional"> & {
    readonly baseURL?: string;
    readonly providerOptions?: OpenAIProviderOptionsInput | OpenResponsesProviderOptionsInput;
};
export type Settings<Options = OpenAIProviderOptionsInput> = ProviderPackage.Settings & Options & {
    readonly apiKey?: string | false;
};
export declare const protocol: Protocol<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
}, string, "[DONE]" | {
    readonly [x: string]: unknown;
    readonly choices?: readonly {
        readonly [x: string]: unknown;
        readonly delta?: {
            readonly [x: string]: unknown;
            readonly content?: string | null | undefined;
            readonly refusal?: string | null | undefined;
            readonly reasoning_content?: string | null | undefined;
            readonly reasoning?: string | null | undefined;
            readonly reasoning_text?: string | null | undefined;
            readonly reasoning_details?: unknown;
            readonly reasoning_opaque?: string | null | undefined;
            readonly tool_calls?: readonly {
                readonly index?: number | null | undefined;
                readonly id?: string | null | undefined;
                readonly function?: {
                    readonly name?: string | null | undefined;
                    readonly arguments?: string | null | undefined;
                } | null | undefined;
                readonly custom?: {
                    readonly name?: string | null | undefined;
                    readonly input?: string | null | undefined;
                } | null | undefined;
                readonly extra_content?: unknown;
            }[] | null | undefined;
        } | null | undefined;
        readonly finish_reason?: string | null | undefined;
        readonly native_finish_reason?: string | null | undefined;
        readonly usage?: {
            readonly [x: string]: unknown;
            readonly prompt_tokens?: number | null | undefined;
            readonly completion_tokens?: number | null | undefined;
            readonly total_tokens?: number | null | undefined;
            readonly cached_tokens?: number | null | undefined;
            readonly prompt_cache_hit_tokens?: number | null | undefined;
            readonly cache_read_input_tokens?: number | null | undefined;
            readonly cache_created_input_tokens?: number | null | undefined;
            readonly reasoning_tokens?: number | null | undefined;
            readonly prompt_tokens_details?: {
                readonly [x: string]: unknown;
                readonly cached_tokens?: number | null | undefined;
                readonly cache_write_tokens?: number | null | undefined;
            } | null | undefined;
            readonly completion_tokens_details?: {
                readonly [x: string]: unknown;
                readonly reasoning_tokens?: number | null | undefined;
                readonly accepted_prediction_tokens?: number | null | undefined;
                readonly rejected_prediction_tokens?: number | null | undefined;
            } | null | undefined;
        } | null | undefined;
    }[] | null | undefined;
    readonly usage?: {
        readonly [x: string]: unknown;
        readonly prompt_tokens?: number | null | undefined;
        readonly completion_tokens?: number | null | undefined;
        readonly total_tokens?: number | null | undefined;
        readonly cached_tokens?: number | null | undefined;
        readonly prompt_cache_hit_tokens?: number | null | undefined;
        readonly cache_read_input_tokens?: number | null | undefined;
        readonly cache_created_input_tokens?: number | null | undefined;
        readonly reasoning_tokens?: number | null | undefined;
        readonly prompt_tokens_details?: {
            readonly [x: string]: unknown;
            readonly cached_tokens?: number | null | undefined;
            readonly cache_write_tokens?: number | null | undefined;
        } | null | undefined;
        readonly completion_tokens_details?: {
            readonly [x: string]: unknown;
            readonly reasoning_tokens?: number | null | undefined;
            readonly accepted_prediction_tokens?: number | null | undefined;
            readonly rejected_prediction_tokens?: number | null | undefined;
        } | null | undefined;
    } | null | undefined;
    readonly error?: {
        readonly [x: string]: unknown;
        readonly code?: string | number | null | undefined;
        readonly message: string;
    } | null | undefined;
}, OpenAIChat.ParserState>;
export declare const route: Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>;
export declare const routes: (Route<{
    readonly model: string;
    readonly input: readonly ({
        readonly type: "configuration_update";
        readonly reasoning: {
            readonly effort: import("../schema/options.js").ReasoningEffort;
        };
    } | {
        readonly type: "message";
        readonly role: "system";
        readonly content: string;
    } | {
        readonly type: "message";
        readonly role: "developer";
        readonly content: string;
    } | {
        readonly type: "custom_tool_call_output" | "function_call_output";
        readonly call_id: string;
        readonly output: string | readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
    } | {
        readonly type: "reasoning";
        readonly id?: string | undefined;
        readonly summary: readonly {
            readonly type: "summary_text";
            readonly text: string;
        }[];
        readonly encrypted_content?: string | null | undefined;
    } | {
        readonly type: "compaction";
        readonly id?: string | null | undefined;
        readonly encrypted_content: string;
    } | {
        readonly type: "message";
        readonly role: "user";
        readonly content: readonly ({
            readonly type: "input_text";
            readonly text: string;
        } | {
            readonly type: "input_video";
            readonly video_url: string;
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "input_image";
            readonly image_url: string;
            readonly detail?: string | undefined;
        } | {
            readonly type: "input_file";
            readonly filename?: string | undefined;
            readonly detail?: string | undefined;
            readonly file_data?: string | undefined;
            readonly file_url?: string | undefined;
        })[];
        readonly id?: string | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "message";
        readonly id?: string | undefined;
        readonly role: "assistant";
        readonly content: readonly {
            readonly type: "output_text";
            readonly text: string;
        }[];
        readonly phase?: "commentary" | "final_answer" | null | undefined;
        readonly status?: string | undefined;
    } | {
        readonly type: "function_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly namespace?: string | undefined;
        readonly arguments: string;
    } | {
        readonly type: "custom_tool_call";
        readonly id?: string | undefined;
        readonly call_id: string;
        readonly name: string;
        readonly input: string;
    } | {
        readonly [x: string]: unknown;
        readonly type: "web_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly action?: {
            readonly [x: string]: unknown;
        } | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "file_search_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly queries?: readonly string[] | undefined;
        readonly results?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "code_interpreter_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly code?: string | null | undefined;
        readonly container_id?: string | null | undefined;
        readonly outputs?: readonly {
            readonly [x: string]: unknown;
        }[] | null | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: "mcp_call";
        readonly id: string;
        readonly status?: string | undefined;
        readonly server_label?: string | undefined;
        readonly name?: string | undefined;
        readonly arguments?: string | undefined;
        readonly output?: string | null | undefined;
        readonly error?: unknown;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
        readonly id: string;
    })[];
    readonly instructions?: string | undefined;
    readonly tools?: readonly ({
        readonly type: "custom";
        readonly name: string;
        readonly description: string;
        readonly format: {
            readonly type: "text";
        } | {
            readonly type: "grammar";
            readonly syntax: "lark" | "regex";
            readonly definition: string;
        };
    } | {
        readonly type: "function";
        readonly name: string;
        readonly description: string;
        readonly parameters: {
            readonly [x: string]: unknown;
        };
        readonly strict?: boolean | undefined;
    } | {
        readonly [x: string]: unknown;
        readonly type: string;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "custom" | "function";
        readonly name: string;
    } | {
        readonly type: "allowed_tools";
        readonly mode: "auto" | "none" | "required";
        readonly tools: readonly {
            readonly type: "custom" | "function";
            readonly name: string;
        }[];
    } | undefined;
    readonly store?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly stream_options?: {
        readonly include_obfuscation?: boolean | undefined;
    } | undefined;
    readonly top_logprobs?: number | undefined;
    readonly truncation?: "auto" | "disabled" | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly include?: readonly import("../schema/options.js").OpenString<"code_interpreter_call.outputs" | "computer_call_output.output.image_url" | "file_search_call.results" | "message.input_image.image_url" | "message.output_text.logprobs" | "reasoning.encrypted_content" | "web_search_call.action.sources" | "web_search_call.results">[] | undefined;
    readonly reasoning?: {
        readonly effort?: import("../schema/options.js").ReasoningEffort | undefined;
        readonly summary?: "auto" | "concise" | "detailed" | undefined;
    } | undefined;
    readonly text?: {
        readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    } | undefined;
    readonly max_output_tokens?: number | undefined;
    readonly max_tool_calls?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly stream: true;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined> | Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "image_url";
            readonly image_url: {
                readonly url: string;
            };
        } | {
            readonly type: "video_url";
            readonly video_url: {
                readonly url: string;
            };
        } | {
            readonly type: "file";
            readonly file: {
                readonly filename: string;
                readonly file_data: string;
            };
        } | {
            readonly type: "input_audio";
            readonly input_audio: {
                readonly data: string;
                readonly format: string;
            };
        } | {
            readonly type: "audio_url";
            readonly audio_url: {
                readonly url: string;
            };
        } | {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[];
    } | {
        readonly [x: string]: unknown;
        readonly role: "assistant";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
            readonly cache_control?: {
                readonly type: "ephemeral";
                readonly ttl?: string | undefined;
            } | undefined;
        }[] | null;
        readonly tool_calls?: readonly ({
            readonly id: string;
            readonly type: "custom";
            readonly custom: {
                readonly name: string;
                readonly input: string;
            };
        } | {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
            readonly extra_content?: {
                readonly google: {
                    readonly thought_signature: string;
                };
            } | undefined;
        })[] | undefined;
        readonly reasoning_content?: string | undefined;
        readonly reasoning?: string | undefined;
        readonly reasoning_text?: string | undefined;
        readonly reasoning_details?: unknown;
        readonly reasoning_opaque?: string | undefined;
    })[];
    readonly tools?: readonly ({
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict?: boolean | undefined;
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
            readonly description: string;
            readonly format: {
                readonly type: "text";
            } | {
                readonly type: "grammar";
                readonly grammar: {
                    readonly syntax: "lark" | "regex";
                    readonly definition: string;
                };
            };
        };
        readonly cache_control?: {
            readonly type: "ephemeral";
            readonly ttl?: string | undefined;
        } | undefined;
    })[] | undefined;
    readonly tool_choice?: "auto" | "none" | "required" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | {
        readonly type: "custom";
        readonly custom: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly stream_options?: {
        readonly include_usage: boolean;
    } | undefined;
    readonly store?: boolean | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly prompt_cache_retention?: string | undefined;
    readonly prompt_cache_options?: {
        readonly ttl?: string | undefined;
    } | undefined;
    readonly reasoning_effort?: import("../schema/options.js").ReasoningEffort | undefined;
    readonly verbosity?: import("../schema/options.js").OpenString<"high" | "low" | "medium"> | undefined;
    readonly service_tier?: import("../schema/options.js").OpenString<"auto" | "default" | "flex" | "priority"> | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly metadata?: {
        readonly [x: string]: string;
    } | undefined;
    readonly safety_identifier?: string | undefined;
    readonly tool_stream?: boolean | undefined;
    readonly max_completion_tokens?: number | undefined;
    readonly max_tokens?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly seed?: number | undefined;
    readonly stop?: readonly string[] | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route/client.js").CompactionOperations | undefined>)[];
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    chat: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    responses: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<import("./open-responses-options.js").OpenResponsesOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    chat: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    responses: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<import("./open-responses-options.js").OpenResponsesOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
    image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
    configure: typeof configure;
};
export declare const decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
export declare const image: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
export declare const chat: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<import("./openai-options.js").OpenAIOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
export declare const responses: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<import("./open-responses-options.js").OpenResponsesOptionsInput, import("../route/client.js").CompactionOperations | undefined>;
export declare const model: ProviderPackage.Model<Settings, OpenAIProviderOptionsInput>;
export declare const responsesModel: ProviderPackage.Model<Settings<OpenResponsesProviderOptionsInput>, OpenResponsesProviderOptionsInput>;
export declare const imageModel: (modelID: string, settings?: Settings) => import("../image.js").ImageModel<import("../protocols/openai-images.js").OpenAIImageOptions>;
export declare const decisionModel: (modelID: string, settings?: Settings) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
export * as DigitalOcean from "./digitalocean.js";
