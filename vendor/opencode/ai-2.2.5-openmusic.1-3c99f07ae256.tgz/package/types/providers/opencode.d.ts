import { type HttpOptions, type ModelID, type ProviderOptions } from "../schema/index.js";
import type { ProviderPackage } from "../provider-package.js";
import { type ProviderAuthOption } from "../route/auth-options.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type Config = ProviderAuthOption<"optional"> & {
    readonly baseURL?: string;
    readonly headers?: Record<string, string>;
    readonly http?: HttpOptions;
};
export type Settings = ProviderPackage.Settings & {
    readonly apiKey?: string | false;
};
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
    configure: typeof configure;
};
export declare const decision: (modelID: string | ModelID, providerOptions?: ProviderOptions) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
export declare const decisionModel: (modelID: string, settings?: Settings) => import("../decision.js").DecisionModel<import("../decision.js").DecisionOptions>;
export * as OpenCode from "./opencode.js";
