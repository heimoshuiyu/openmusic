import type { ProviderPackage } from "../provider-package.js";
import { MistralChat } from "../protocols/mistral-chat.js";
import type { ProviderAuthOption } from "../route/auth-options.js";
import { type ModelID, type RequestOptions } from "../schema/index.js";
export declare const id: string & import("effect/Brand").Brand<"AI.ProviderID">;
export type ProviderOptions = MistralChat.ProviderOptionsInput;
export type Config = Omit<RequestOptions, "providerOptions"> & ProviderAuthOption<"optional"> & {
    readonly baseURL?: string;
    readonly providerOptions?: ProviderOptions;
};
export type Settings = ProviderPackage.Settings & ProviderOptions & {
    readonly apiKey?: string | false;
    readonly baseURL?: string;
};
export declare const route: import("../route.js").Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
        }[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly name: string;
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly [x: string]: unknown;
            readonly type: "thinking";
            readonly thinking: readonly {
                readonly [x: string]: unknown;
                readonly type?: string | undefined;
                readonly text?: string | undefined;
            }[];
        })[];
        readonly tool_calls?: readonly {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
        }[] | undefined;
        readonly prefix?: true | undefined;
    })[];
    readonly tools?: readonly {
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict: false;
        };
    }[] | undefined;
    readonly tool_choice?: "any" | "auto" | "none" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly max_tokens?: number | undefined;
    readonly random_seed?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly stop?: readonly string[] | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly safe_prompt?: boolean | undefined;
    readonly document_image_limit?: number | undefined;
    readonly document_page_limit?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly reasoning_effort?: string | undefined;
    readonly prompt_mode?: "reasoning" | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route.js").CompactionOperations | undefined>;
export declare const routes: import("../route.js").Route<{
    readonly model: string;
    readonly messages: readonly ({
        readonly role: "system";
        readonly content: string | readonly {
            readonly type: "text";
            readonly text: string;
        }[];
    } | {
        readonly role: "user";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "tool";
        readonly tool_call_id: string;
        readonly name: string;
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "image_url";
            readonly image_url: string;
        } | {
            readonly type: "document_url";
            readonly document_url: string;
        })[];
    } | {
        readonly role: "assistant";
        readonly content: string | readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly [x: string]: unknown;
            readonly type: "thinking";
            readonly thinking: readonly {
                readonly [x: string]: unknown;
                readonly type?: string | undefined;
                readonly text?: string | undefined;
            }[];
        })[];
        readonly tool_calls?: readonly {
            readonly id: string;
            readonly type: "function";
            readonly function: {
                readonly name: string;
                readonly arguments: string;
            };
        }[] | undefined;
        readonly prefix?: true | undefined;
    })[];
    readonly tools?: readonly {
        readonly type: "function";
        readonly function: {
            readonly name: string;
            readonly description: string;
            readonly parameters: {
                readonly [x: string]: unknown;
            };
            readonly strict: false;
        };
    }[] | undefined;
    readonly tool_choice?: "any" | "auto" | "none" | {
        readonly type: "function";
        readonly function: {
            readonly name: string;
        };
    } | undefined;
    readonly stream: true;
    readonly max_tokens?: number | undefined;
    readonly random_seed?: number | undefined;
    readonly temperature?: number | undefined;
    readonly top_p?: number | undefined;
    readonly frequency_penalty?: number | undefined;
    readonly presence_penalty?: number | undefined;
    readonly stop?: readonly string[] | undefined;
    readonly prompt_cache_key?: string | undefined;
    readonly safe_prompt?: boolean | undefined;
    readonly document_image_limit?: number | undefined;
    readonly document_page_limit?: number | undefined;
    readonly parallel_tool_calls?: boolean | undefined;
    readonly reasoning_effort?: string | undefined;
    readonly prompt_mode?: "reasoning" | undefined;
}, import("../route/transport/http.js").HttpPrepared<string>, import("../route.js").CompactionOperations | undefined>[];
export declare const configure: (input?: Config) => {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<MistralChat.ProviderOptionsInput, import("../route.js").CompactionOperations | undefined>;
    configure: typeof configure;
};
export declare const provider: {
    id: string & import("effect/Brand").Brand<"AI.ProviderID">;
    model: (modelID: string | ModelID) => import("../schema/options.js").LanguageModel<MistralChat.ProviderOptionsInput, import("../route.js").CompactionOperations | undefined>;
    configure: typeof configure;
};
export declare const model: ProviderPackage.Model<Settings, ProviderOptions>;
export * as Mistral from "./mistral.js";
