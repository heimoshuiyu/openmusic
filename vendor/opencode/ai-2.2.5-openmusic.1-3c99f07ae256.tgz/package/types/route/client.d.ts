import { Context, Effect, Layer, Schema, Stream } from "effect";
import { Auth } from "./auth.js";
import { Endpoint, type EndpointPatch } from "./endpoint.js";
import { RequestExecutor } from "./executor.js";
import { Framing } from "./framing.js";
import { HttpTransport } from "./transport/index.js";
import type { HttpMiddleware, Transport, TransportRuntime, WebSocketChannelExecutor } from "./transport/index.js";
import type { Protocol } from "./protocol.js";
import type { LanguageModelSanitizerCompatibility, ProtocolID, ProviderOptions } from "../schema/index.js";
import type { LLMRequestInput } from "../llm.js";
import { AIError, CompactionResponse, CompactionCheckpointResponse, LLMResponse, LanguageModel, LLMEvent, ProviderID, type LLMRequest, type RequestOptions } from "../schema/index.js";
export interface RouteBody<Body> {
    /** Schema for the validated provider-native body sent as the JSON request. */
    readonly schema: Schema.Codec<Body, unknown>;
    /** Build the provider-native body from a common `LLMRequest`. */
    readonly from: (request: LLMRequest) => Effect.Effect<Body, AIError>;
}
export interface Route<Body, Prepared = unknown, Compact extends CompactionOperations | undefined = CompactionOperations | undefined> {
    readonly compact: Compact;
    readonly id: string;
    readonly provider?: ProviderID;
    /** ProviderMetadata namespace emitted and consumed by this route. */
    readonly providerMetadataKey?: string;
    readonly protocol: ProtocolID;
    readonly endpoint: Endpoint.Definition<Body>;
    readonly auth: Auth.Definition;
    /** Deployment headers resolved once for every operation, before transport authentication. */
    readonly headers?: (input: {
        readonly request: LLMRequest;
    }) => Record<string, string>;
    readonly transport: Transport<Body, Prepared, unknown>;
    /** Options every model built on this route starts from. */
    readonly options?: RequestOptions;
    readonly body: RouteBody<Body>;
    readonly supportsEffortUpdates?: (request: LLMRequest) => boolean;
    readonly sanitizer?: LanguageModelSanitizerCompatibility;
    readonly with: {
        <Next extends CompactionOperations | undefined>(patch: RoutePatch<Body, Prepared> & {
            readonly compact: Next;
        }): Route<Body, Prepared, Next>;
        (patch: Omit<RoutePatch<Body, Prepared>, "compact"> & {
            readonly compact?: undefined;
        }): Route<Body, Prepared, Compact>;
        (patch: RoutePatch<Body, Prepared>): Route<Body, Prepared>;
    };
    readonly model: <Options extends ProviderOptions = ProviderOptions>(input: RouteMappedLanguageModelInput) => LanguageModel<Options, Compact>;
    readonly prepareTransport: (body: Body, request: LLMRequest, options?: StreamOptions) => Effect.Effect<Prepared, AIError>;
    readonly streamPrepared: (prepared: Prepared, request: LLMRequest, runtime: TransportRuntime, options?: StreamOptions) => Stream.Stream<LLMEvent, AIError>;
}
export type AnyRoute<Compact extends CompactionOperations | undefined = CompactionOperations | undefined> = Route<any, any, Compact>;
export type RouteLanguageModelInput = Omit<LanguageModel.Input, "provider" | "route">;
export type RouteRoutedLanguageModelInput = Omit<LanguageModel.Input, "route">;
export interface RoutePatch<Body, Prepared> extends RequestOptions {
    readonly compact?: CompactionOperations;
    readonly id?: string;
    readonly provider?: string | ProviderID;
    readonly providerMetadataKey?: string;
    readonly auth?: Auth.Definition;
    readonly transport?: Transport<Body, Prepared, unknown>;
    readonly endpoint?: EndpointPatch<Body>;
}
type RouteMappedLanguageModelInput = RouteLanguageModelInput | RouteRoutedLanguageModelInput;
export interface Interface {
    readonly compact: CompactMethod;
    readonly stream: StreamMethod;
    readonly generate: GenerateMethod;
}
export interface StreamOptions {
    readonly http?: HttpMiddleware;
    readonly webSocket?: WebSocketChannelExecutor;
}
export interface StreamMethod {
    (request: LLMRequest, options?: StreamOptions): Stream.Stream<LLMEvent, AIError>;
}
export interface GenerateMethod {
    (request: LLMRequest, options?: StreamOptions): Effect.Effect<LLMResponse, AIError>;
}
export type CompactOperation = (request: LLMRequest, executor: RequestExecutor.Interface, options?: Pick<StreamOptions, "http">) => Effect.Effect<CompactionResponse, AIError>;
export type TriggerCompactOperation = (request: LLMRequest, executor: RequestExecutor.Interface, options: TriggerCompactOptions) => Effect.Effect<CompactionCheckpointResponse, AIError>;
/** Protocol capabilities, not deployment/model eligibility. */
export interface CompactionOperations {
    readonly endpoint?: CompactOperation;
    readonly trigger?: TriggerCompactOperation;
}
export interface EndpointCompactOptions extends Pick<StreamOptions, "http"> {
    readonly mechanism?: "endpoint";
    readonly webSocket?: never;
}
export interface TriggerCompactOptions extends StreamOptions {
    readonly mechanism: "trigger";
}
type EndpointModel = LanguageModel<ProviderOptions, {
    readonly endpoint: CompactOperation;
}>;
type TriggerModel = LanguageModel<ProviderOptions, {
    readonly trigger: TriggerCompactOperation;
}>;
/** A text request whose model supports explicit compaction. */
export type CompactionRequest = LLMRequestInput & {
    readonly model: EndpointModel;
};
/** A text request whose model supports trigger compaction checkpoints. */
export type CheckpointRequest = LLMRequestInput & {
    readonly model: TriggerModel;
};
export interface CompactMethod<R = never> {
    (request: LLMRequest & {
        readonly model: TriggerModel;
    }, options: TriggerCompactOptions): Effect.Effect<CompactionCheckpointResponse, AIError, R>;
    (request: LLMRequest & {
        readonly model: EndpointModel;
    }, options?: EndpointCompactOptions): Effect.Effect<CompactionResponse, AIError, R>;
}
/** Whether a model, or a text request's model, supports compaction through the given mechanism. */
export declare function canCompact<Model extends LanguageModel>(model: Model, options: {
    readonly mechanism: "trigger";
}): model is Model & TriggerModel;
export declare function canCompact<Request extends {
    readonly model: LanguageModel;
}>(request: Request, options: {
    readonly mechanism: "trigger";
}): request is Request & {
    readonly model: TriggerModel;
};
export declare function canCompact<Model extends LanguageModel>(model: Model, options?: {
    readonly mechanism?: "endpoint";
}): model is Model & EndpointModel;
export declare function canCompact<Request extends {
    readonly model: LanguageModel;
}>(request: Request, options?: {
    readonly mechanism?: "endpoint";
}): request is Request & {
    readonly model: EndpointModel;
};
declare const LLMClientService_base: Context.ServiceClass<LLMClientService, "@opencode/LLMClient", Interface>;
export declare class LLMClientService extends LLMClientService_base {
}
export declare const Service: typeof LLMClientService;
export type Service = LLMClientService;
export interface MakeInput<Body, Frame, Event, State> {
    readonly compact?: CompactionOperations;
    /** Route id used in diagnostics and prepared request metadata. */
    readonly id: string;
    /** Provider identity for route-owned model construction. */
    readonly provider?: string | ProviderID;
    /** ProviderMetadata namespace emitted and consumed by this route. */
    readonly providerMetadataKey?: string;
    /** Semantic API contract — owns body construction, body schema, and parsing. */
    readonly protocol: Protocol<Body, Frame, Event, State>;
    /** Where the request is sent. */
    readonly endpoint: Endpoint.Definition<Body>;
    /** Per-request transport auth. Provider facades override this via `route.with(...)`. */
    readonly auth?: Auth.Definition;
    /** Stream framing — bytes -> frames before `protocol.stream.event` decoding. */
    readonly framing: Framing.Definition<Frame>;
    /** Static / per-request headers added before `auth` runs. */
    readonly headers?: (input: {
        readonly request: LLMRequest;
    }) => Record<string, string>;
    /** Options every model built on this route starts from. */
    readonly options?: RequestOptions;
}
export interface MakeTransportInput<Body, Prepared, Frame, Event, State> {
    readonly compact?: CompactionOperations;
    /** Route id used in diagnostics and prepared request metadata. */
    readonly id: string;
    /** Provider identity for route-owned model construction. */
    readonly provider?: string | ProviderID;
    /** ProviderMetadata namespace emitted and consumed by this route. */
    readonly providerMetadataKey?: string;
    /** Semantic API contract — owns body construction, body schema, and parsing. */
    readonly protocol: Protocol<Body, Frame, Event, State>;
    /** Where the request is sent. */
    readonly endpoint: Endpoint.Definition<Body>;
    /** Per-request transport auth. Provider facades override this via `route.with(...)`. */
    readonly auth?: Auth.Definition;
    /** Static / per-request headers added before `auth` runs. */
    readonly headers?: (input: {
        readonly request: LLMRequest;
    }) => Record<string, string>;
    /** Runnable transport route. */
    readonly transport: Transport<Body, Prepared, Frame>;
    /** Options every model built on this route starts from. */
    readonly options?: RequestOptions;
}
export declare function make<Body, Prepared, Frame, Event, State, Compact extends CompactionOperations>(input: MakeTransportInput<Body, Prepared, Frame, Event, State> & {
    readonly compact: Compact;
}): Route<Body, Prepared, Compact>;
export declare function make<Body, Frame, Event, State, Compact extends CompactionOperations>(input: MakeInput<Body, Frame, Event, State> & {
    readonly compact: Compact;
}): Route<Body, HttpTransport.HttpPrepared<Frame>, Compact>;
export declare function make<Body, Prepared, Frame, Event, State>(input: MakeTransportInput<Body, Prepared, Frame, Event, State>): Route<Body, Prepared>;
/**
 * Build a `Route` by composing the four orthogonal pieces of a deployment:
 *
 * - `Protocol` — what is the API I'm speaking?
 * - `Endpoint` — where do I send the request?
 * - `Auth` — how do I authenticate it?
 * - `Framing` — how do I cut the response stream into protocol frames?
 *
 * Plus optional `headers` for cross-cutting deployment concerns (provider
 * version pins, per-deployment quirks).
 *
 * This is the canonical route constructor. If a new route does not fit
 * this four-axis model, add a purpose-built constructor rather than widening
 * the public surface preemptively.
 */
export declare function make<Body, Frame, Event, State>(input: MakeInput<Body, Frame, Event, State>): Route<Body, HttpTransport.HttpPrepared<Frame>>;
/** Test-only projection of the execution compiler; exported from `@opencode/ai/testing`. */
export declare const compileRequest: (request: LLMRequest<LanguageModel<{
    readonly [x: string]: unknown;
}, CompactionOperations | undefined>>) => Effect.Effect<{
    id: string;
    route: string;
    protocol: string;
    model: LanguageModel<{
        readonly [x: string]: unknown;
    }, CompactionOperations | undefined>;
    body: any;
    metadata: {
        transport: string;
    };
}, AIError, never>;
export declare const generateWith: (stream: Interface["stream"]) => (request: LLMRequest<LanguageModel<{
    readonly [x: string]: unknown;
}, CompactionOperations | undefined>>, options?: StreamOptions | undefined) => Effect.Effect<LLMResponse, AIError, never>;
export declare function stream(request: LLMRequest, options?: StreamOptions): Stream.Stream<LLMEvent, AIError, Service>;
export declare function generate(request: LLMRequest, options?: StreamOptions): Effect.Effect<LLMResponse, AIError, Service>;
/** Compact through the client for `options.mechanism`, failing typed when the request's route does not support it. */
export declare function compactRequest(request: LLMRequest, options?: EndpointCompactOptions | TriggerCompactOptions): Effect.Effect<CompactionResponse | CompactionCheckpointResponse, AIError, Service>;
export declare const layer: Layer.Layer<Service, never, RequestExecutor.Service>;
export declare const Route: {
    readonly make: typeof make;
};
export declare const LLMClient: {
    readonly Service: typeof LLMClientService;
    readonly layer: Layer.Layer<LLMClientService, never, RequestExecutor.RequestExecutorService>;
    readonly stream: typeof stream;
    readonly generate: typeof generate;
};
export {};
