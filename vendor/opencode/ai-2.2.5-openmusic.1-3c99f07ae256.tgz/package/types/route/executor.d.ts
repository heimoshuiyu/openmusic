import { Layer, Stream } from "effect";
import { HttpClient, HttpClientRequest, HttpClientResponse } from "effect/http";
import { AIError } from "../schema/index.js";
import { Service, type HttpMiddleware, type Interface } from "./executor-service.js";
export { responseHttp, Service } from "./executor-service.js";
export type { HttpHandler, HttpMiddleware, Interface, RequestExecutorService } from "./executor-service.js";
/** Preserve HTTP diagnostics for executor and externally captured failures alike. */
export declare const httpFailure: (input: {
    readonly message: string;
    readonly url?: string | undefined;
    readonly status?: number | undefined;
    readonly data?: unknown;
    readonly responseHeaders?: Record<string, string> | undefined;
    readonly responseBody?: string | undefined;
    readonly cause?: unknown;
}) => AIError;
export declare const responseStream: (response: HttpClientResponse.HttpClientResponse) => Stream.Stream<Uint8Array, AIError>;
export declare const stream: (executor: Interface, request: HttpClientRequest.HttpClientRequest, middleware?: HttpMiddleware) => Stream.Stream<Uint8Array, AIError>;
export declare const layer: Layer.Layer<Service, never, HttpClient.HttpClient>;
export declare const fetchLayer: Layer.Layer<import("./executor-service.js").RequestExecutorService, never, never>;
/**
 * Per-call middleware that sends through `fetch` instead of the executor's HTTP client. Executor middleware and
 * `middleware` still wrap the call, and status classification still applies.
 */
export declare const withFetch: (fetch: typeof globalThis.fetch | undefined, middleware?: HttpMiddleware) => HttpMiddleware | undefined;
/** Run `fn` on every request: it sees the raw response before status classification, inside middleware already on `executor`, and outside per-call middleware. */
export declare const middleware: (fn: HttpMiddleware, executor?: Layer.Layer<Service>) => Layer.Layer<Service>;
export * as RequestExecutor from "./executor.js";
