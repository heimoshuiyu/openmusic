import { Context, type Effect } from "effect";
import type { Headers, HttpClientRequest, HttpClientResponse } from "effect/http";
import { HttpContext, type AIError } from "../schema/errors.js";
export interface Interface {
    readonly execute: (request: HttpClientRequest.HttpClientRequest, middleware?: HttpMiddleware) => Effect.Effect<HttpClientResponse.HttpClientResponse, AIError>;
}
export type HttpHandler = (request: HttpClientRequest.HttpClientRequest) => Effect.Effect<HttpClientResponse.HttpClientResponse, Error>;
export type HttpMiddleware = (request: HttpClientRequest.HttpClientRequest, handler: HttpHandler) => Effect.Effect<HttpClientResponse.HttpClientResponse, Error>;
declare const RequestExecutorService_base: Context.ServiceClass<RequestExecutorService, "@opencode/AI/RequestExecutor", Interface>;
export declare class RequestExecutorService extends RequestExecutorService_base {
}
export declare const Service: typeof RequestExecutorService;
export type Service = RequestExecutorService;
export declare const headerDetails: (headers: Headers.Headers) => {
    [k: string]: string;
};
export declare const responseHttp: (response: HttpClientResponse.HttpClientResponse) => HttpContext;
export {};
