import { Effect, Stream } from "effect";
import { Headers } from "effect/http";
import { Socket } from "effect/socket";
import { AIError, type HttpContext } from "../../schema/index.js";
import type { WebSocketChannelExecutor } from "./websocket-channel.js";
export interface WebSocketRequest {
    readonly url: string;
    readonly headers: Headers.Headers;
}
export interface WebSocketConnection {
    readonly http?: HttpContext;
    readonly sendText: (message: string) => Effect.Effect<void, AIError>;
    readonly messages: Stream.Stream<string | Uint8Array, AIError>;
    readonly close: Effect.Effect<void, never>;
}
export interface WebSocketConnector {
    readonly open: (input: WebSocketRequest) => Effect.Effect<WebSocketConnection, AIError>;
}
export declare const toWebSocketUrl: (value: string) => Effect.Effect<string, AIError, never>;
export declare const open: (input: WebSocketRequest) => Effect.Effect<WebSocketConnection, AIError, Socket.WebSocketConstructor>;
export declare const fromWebSocket: (ws: Socket.WebSocketLike, input: WebSocketRequest) => Effect.Effect<WebSocketConnection, AIError>;
export declare const messageText: (message: string | Uint8Array, decoder: TextDecoder) => string;
export declare const makeDirect: (connector: WebSocketConnector) => WebSocketChannelExecutor;
export declare const direct: Effect.Effect<WebSocketChannelExecutor, never, Socket.WebSocketConstructor>;
export declare const WebSocketTransport: {
    readonly direct: Effect.Effect<WebSocketChannelExecutor, never, Socket.WebSocketConstructor>;
    readonly makeDirect: typeof makeDirect;
    readonly open: typeof open;
    readonly fromWebSocket: typeof fromWebSocket;
    readonly messageText: typeof messageText;
    readonly toWebSocketUrl: typeof toWebSocketUrl;
};
