import { Effect } from "effect";
import type { HttpClientResponse } from "effect/http";
import { DecisionModel, DecisionModelCompatibility, type DecisionOptions, type DecisionRequest, type DecisionResponse } from "../decision.js";
import { ProviderID, type HttpOptions, type AIError, type ProviderOptions } from "../schema/index.js";
import { Auth } from "./auth.js";
import { Endpoint } from "./endpoint.js";
import { MediaProtocol } from "./media-protocol.js";
/** One decision API: how a request becomes its JSON body and how its response becomes a `DecisionResponse`. */
export interface Protocol {
    readonly id: string;
    readonly name: string;
    /** The host only takes inline data, so URL media is downloaded before `body.from`. */
    readonly inlineMedia?: boolean;
    readonly body: {
        readonly from: (request: DecisionRequest) => Effect.Effect<Record<string, unknown>, AIError>;
    };
    readonly response: {
        readonly decode: (response: HttpClientResponse.HttpClientResponse, context: {
            readonly request: DecisionRequest;
            readonly providerMetadataKey: string;
        }) => Effect.Effect<DecisionResponse, AIError>;
    };
}
export declare const protocol: (input: Protocol) => Protocol;
export interface Patch {
    readonly id?: string;
    readonly provider?: string | ProviderID;
    /** ProviderMetadata namespace for responses; defaults to the provider. */
    readonly providerMetadataKey?: string;
    readonly endpoint?: Endpoint.EndpointPatch<MediaProtocol.Body, DecisionRequest>;
    readonly auth?: Auth.Definition;
    readonly headers?: Record<string, string>;
    readonly http?: HttpOptions;
}
export interface Route {
    readonly id: string;
    readonly provider: ProviderID;
    readonly providerMetadataKey: string;
    readonly protocol: Protocol;
    readonly endpoint: Endpoint.Definition<MediaProtocol.Body, DecisionRequest>;
    readonly auth: Auth.Definition;
    readonly headers?: Record<string, string>;
    readonly http?: HttpOptions;
    readonly with: (patch: Patch) => Route;
    readonly model: <Options extends DecisionOptions = DecisionOptions>(input: {
        readonly id: string;
        readonly compatibility?: DecisionModelCompatibility.Input;
        readonly providerOptions?: ProviderOptions;
    }) => DecisionModel<Options>;
}
export interface MakeInput extends Omit<Patch, "endpoint"> {
    readonly id: string;
    readonly provider: string | ProviderID;
    readonly protocol: Protocol;
    readonly endpoint: Endpoint.Definition<MediaProtocol.Body, DecisionRequest>;
}
export declare const make: (input: MakeInput) => Route;
export * as DecisionRoute from "./decision.js";
