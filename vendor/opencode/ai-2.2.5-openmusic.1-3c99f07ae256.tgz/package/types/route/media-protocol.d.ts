import { Duration, Effect, Schema, type Stream } from "effect";
import { HttpClientResponse } from "effect/http";
import type { Snapshot, Status } from "../generation.js";
import { Media } from "../media.js";
import type { AuthInput } from "./auth.js";
import { AIError, AuthenticationError, type HttpContext, InvalidRequestError, ProviderID, ProviderInternalError, RateLimitError } from "../schema/index.js";
/** Array values become repeated parameters (`keyterm=a&keyterm=b`). */
export type Query = Readonly<Record<string, string | ReadonlyArray<string>>>;
/** `query` is appended to the endpoint URL before the route and caller `http.query` overlays. */
export type Body = {
    readonly type: "json";
    readonly value: Record<string, unknown>;
    readonly query?: Query;
} | {
    readonly type: "multipart";
    readonly value: FormData;
} | {
    readonly type: "binary";
    readonly value: Uint8Array;
    readonly contentType: string;
    readonly query?: Query;
};
export declare const json: (value: Record<string, unknown>, query?: Query) => Body;
export declare const multipart: (value: FormData) => Body;
export declare const binary: (value: Uint8Array, contentType: string, query?: Query) => Body;
export type Send = (path: string, body: Body) => Effect.Effect<HttpClientResponse.HttpClientResponse, AIError>;
/** Runs after unsupported-field rejection and before `body.from`, for providers that need an upload first. */
export type Prepare<Request> = (request: Request, send: Send) => Effect.Effect<Request, AIError>;
export interface DecodeContext<Request> {
    readonly request: Request;
    readonly body: Body;
}
/** One request, one response. JSON or multipart in; JSON or raw bytes out. */
export interface Inline<Request, Response> {
    readonly kind: "inline";
    readonly id: string;
    readonly provider: ProviderID;
    /** Common request fields this protocol cannot lower; the route rejects them before `body.from` runs. */
    readonly unsupported?: ReadonlyArray<keyof Request & string>;
    readonly body: {
        readonly from: (request: Request) => Effect.Effect<Body, AIError>;
    };
    readonly response: {
        readonly decode: (response: HttpClientResponse.HttpClientResponse, context: DecodeContext<Request>) => Effect.Effect<Response, AIError>;
    };
}
export declare const inline: <Request, Response>(route: Identity, input: Omit<Inline<Request, Response>, "kind" | "id" | "provider">) => Inline<Request, Response>;
/** What `start` learned from the submission response: the route-owned handle plus the first observation. */
export interface Started<Token> {
    readonly token: Token;
    readonly snapshot: Snapshot;
}
/**
 * A follow-up call's inputs: the decoded token and the auth headers the route sent, so a protocol can attach them
 * to output URLs that require the same credentials to download (Veo).
 */
export interface PollContext<Token> {
    readonly token: Token;
    readonly auth: Record<string, string>;
}
/**
 * Submit, then poll. `start` posts the body to the route endpoint; `status`, `result`, and `cancel` are follow-up
 * calls addressed by the token. Paths are relative to the route base URL unless the provider hands back absolute
 * URLs, in which case they are used verbatim. `result` is always its own GET: providers that
 * return the output inside the status body (Veo, xAI, Runway) point `result.path` at the status path and decode the
 * same document, so `Generation.await` and `Video.resume(...).await()` behave identically everywhere.
 */
export interface Queued<Request, Response, Token> {
    readonly kind: "queued";
    readonly id: string;
    readonly provider: ProviderID;
    /** Common request fields this protocol cannot lower; the route rejects them before `start.body.from` runs. */
    readonly unsupported?: ReadonlyArray<keyof Request & string>;
    /** Serializable handle. `Generation.token` carries the encoded form so it can be persisted and resumed elsewhere. */
    readonly token: Schema.Codec<Token, unknown>;
    readonly start: {
        readonly prepare?: Prepare<Request>;
        readonly body: {
            readonly from: (request: Request) => Effect.Effect<Body, AIError>;
        };
        readonly decode: (response: HttpClientResponse.HttpClientResponse, context: DecodeContext<Request>) => Effect.Effect<Started<Token>, AIError>;
    };
    readonly status: {
        readonly path: (token: Token) => string;
        readonly decode: (response: HttpClientResponse.HttpClientResponse, context: PollContext<Token>) => Effect.Effect<Snapshot, AIError>;
    };
    readonly result: {
        readonly path: (token: Token) => string;
        readonly decode: (response: HttpClientResponse.HttpClientResponse, context: PollContext<Token>) => Effect.Effect<Response, AIError>;
    };
    readonly cancel?: {
        readonly method: AuthInput["method"];
        readonly path: (token: Token) => string;
        /**
         * Fetch a fresh status first and skip the call for terminal generations, for providers whose cancel endpoint
         * destroys finished work (Runway's `DELETE /v1/tasks/{id}` deletes completed tasks and their outputs).
         */
        readonly activeOnly?: boolean;
    };
}
export declare const queued: <Request, Response, Token>(route: Identity, input: Omit<Queued<Request, Response, Token>, "kind" | "id" | "provider">) => Queued<Request, Response, Token>;
export type Mode = "generate" | "stream";
export type Addressed<Request> = Request & {
    readonly mode: Mode;
};
export interface ResponseContext<Request> extends DecodeContext<Addressed<Request>> {
    readonly http: HttpContext;
}
/**
 * One request whose body is parsed incrementally, like LLM protocols: `frames` → `step`* → `finish`. `generate` and
 * `stream` share this state machine; `request.mode` lets a protocol pick a different body, path, or framing.
 */
export interface Streamed<Request, Event, Frame, State> {
    readonly kind: "stream";
    readonly id: string;
    readonly provider: ProviderID;
    /** Common request fields this protocol cannot lower; the route rejects them before `body.from` runs. */
    readonly unsupported?: ReadonlyArray<keyof Request & string>;
    readonly body: {
        readonly from: (request: Addressed<Request>) => Effect.Effect<Body, AIError>;
    };
    readonly frames: (bytes: Stream.Stream<Uint8Array, AIError>, context: DecodeContext<Addressed<Request>>) => Stream.Stream<Frame, AIError>;
    readonly initial: () => State;
    readonly step: (state: State, frame: Frame) => Effect.Effect<readonly [State, ReadonlyArray<Event>], AIError>;
    /** Emit exactly one terminal event, or fail when the provider stopped before completing. */
    readonly finish: (state: State, context: ResponseContext<Request>) => Effect.Effect<ReadonlyArray<Event>, AIError>;
}
export declare const stream: <Request, Event, Frame, State>(route: Identity, input: Omit<Streamed<Request, Event, Frame, State>, "kind" | "id" | "provider">) => Streamed<Request, Event, Frame, State>;
/** Reasons a provider can report for a `failed` generation; anything it does not classify is `ProviderInternal`. */
declare const FAILURES: {
    InvalidRequest: typeof InvalidRequestError;
    Authentication: typeof AuthenticationError;
    RateLimit: typeof RateLimitError;
    ProviderInternal: typeof ProviderInternalError;
};
export type Failure = keyof typeof FAILURES;
/** One protocol's route id, display name, and provider, with the decoders and errors that carry them. */
export declare const identity: (input: {
    readonly id: string;
    readonly name: string;
    readonly provider: string;
}) => {
    id: string;
    name: string;
    provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    text: (response: HttpClientResponse.HttpClientResponse) => Effect.Effect<{
        body: string;
        http: HttpContext;
        invalid: (message: string, cause?: unknown) => AIError;
        ended: (status: Exclude<Status, "queued" | "running" | "completed">, message: string, failure?: Failure) => AIError;
        pending: (id: string) => AIError;
        contentPolicy: (message: string) => AIError;
    }, AIError, never>;
    bytes: (response: HttpClientResponse.HttpClientResponse) => Effect.Effect<Uint8Array<ArrayBuffer>, AIError, never>;
    decodeJson: <A>(schema: Schema.Codec<A, unknown>) => (response: HttpClientResponse.HttpClientResponse) => Effect.Effect<{
        body: string;
        http: HttpContext;
        invalid: (message: string, cause?: unknown) => AIError;
        ended: (status: Exclude<Status, "queued" | "running" | "completed">, message: string, failure?: Failure) => AIError;
        pending: (id: string) => AIError;
        contentPolicy: (message: string) => AIError;
        value: A;
    }, AIError, never>;
    /** Decode a submission response into the token and first snapshot. */
    decodeStarted: <A, Token>(schema: Schema.Codec<A, unknown>, started: (value: A) => Started<Token>) => (response: HttpClientResponse.HttpClientResponse) => Effect.Effect<Started<Token>, AIError, never>;
    /** Schema-decode one JSON stream frame. Decode failures keep the frame as `reason.body`. */
    decodeFrame: <A>(schema: Schema.Codec<A, unknown>) => (frame: string) => Effect.Effect<A, AIError, never>;
    /** A stream-time failure; the frame stays on `reason.body`. */
    frameError: (message: string, body?: string, cause?: unknown) => AIError;
    incomplete: () => AIError;
    unsupported: (operation: string, message: string) => AIError;
};
export type Identity = ReturnType<typeof identity>;
/** Map a provider status string through the protocol's table; unknown values keep the generation running. */
export declare const status: (table: Readonly<Record<string, Status>>, raw: string) => Status;
/** Map a provider error code through the protocol's table; missing or unmapped codes are `ProviderInternal`. */
export declare const failure: (table: Readonly<Record<string, Failure>>, code: string | number | undefined) => Failure;
/** A `url` asset whose provider-declared retention window starts now. */
export declare const expiringUrl: (url: string, retention: Duration.Duration, options?: Parameters<typeof Media.url>[1]) => Effect.Effect<Media.Asset, never, never>;
export * as MediaProtocol from "./media-protocol.js";
