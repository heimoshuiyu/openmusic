export * as TestLLM from "./testing.js";
export { compileRequest } from "./route/client.js";
import { LLMClient } from "./route/client.js";
import { LLMEvent, CompactionResponse, CompactionCheckpointResponse, type FinishReasonDetails, type AIError, type LLMRequest, type ProviderMetadata, type UsageInput } from "./schema/index.js";
import { Context, Effect, Layer, Scope, Stream } from "effect";
export type Response = readonly LLMEvent[] | Stream.Stream<LLMEvent, AIError> | CompactionResponse | CompactionCheckpointResponse;
export type Gate = Readonly<{
    started: Effect.Effect<void>;
    release: Effect.Effect<void>;
}>;
type ClientInterface = Context.Service.Shape<typeof LLMClient.Service>;
export type Responder = (request: LLMRequest) => Response;
interface Controls {
    /** Returns a snapshot of requests observed at execution time. */
    readonly requests: () => Effect.Effect<readonly LLMRequest[]>;
    readonly push: (...responses: readonly Response[]) => Effect.Effect<void>;
    /** Replaces the fallback without changing queued responses. */
    readonly always: (response: Response) => Effect.Effect<void>;
    /** Answers requests after the one-shot queue is exhausted; receives the original request. */
    readonly serve: (responder: Responder) => Effect.Effect<void>;
    /** Waits for request arrivals, not output or completion. */
    readonly wait: (count: number) => Effect.Effect<void>;
    readonly gate: () => Effect.Effect<Gate, never, Scope.Scope>;
}
export interface TestInterface extends ClientInterface, Controls {
}
declare const Test_base: Context.ServiceClass<Test, "@opencode/ai/TestLLM/Test", TestInterface>;
export declare class Test extends Test_base {
}
export interface LayerOptions {
    readonly transformRequest?: (request: LLMRequest) => LLMRequest;
    /** Used after the one-shot response queue is exhausted. Omit to defect on unexpected requests. */
    readonly fallback?: Response;
}
export declare const complete: (options: {
    readonly reason: FinishReasonDetails;
    readonly usage?: UsageInput;
    readonly providerMetadata?: ProviderMetadata;
}, ...events: readonly LLMEvent[]) => ({
    readonly type: "step-start";
    readonly index: number;
} | {
    readonly type: "raw";
    readonly data: unknown;
} | {
    readonly type: "text-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-start";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-delta";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly text: string;
    readonly input?: unknown;
} | {
    readonly type: "tool-input-end";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-error";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly raw: string;
} | {
    readonly type: "tool-call";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly input: unknown;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-result";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly result: {
        readonly type: "json";
        readonly value: unknown;
    } | {
        readonly type: "text";
        readonly value: unknown;
    } | {
        readonly type: "error";
        readonly value: unknown;
    } | {
        readonly type: "content";
        readonly value: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    };
    readonly output?: {
        readonly structured: unknown;
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    } | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "step-finish";
    readonly index: number;
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "finish";
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly message?: import("./schema/messages.js").AssistantMessage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "media";
    readonly media: import("./media.js").Asset;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | ({
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
})))[];
export declare const stop: (...events: readonly LLMEvent[]) => ({
    readonly type: "step-start";
    readonly index: number;
} | {
    readonly type: "raw";
    readonly data: unknown;
} | {
    readonly type: "text-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-start";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-delta";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly text: string;
    readonly input?: unknown;
} | {
    readonly type: "tool-input-end";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-error";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly raw: string;
} | {
    readonly type: "tool-call";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly input: unknown;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-result";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly result: {
        readonly type: "json";
        readonly value: unknown;
    } | {
        readonly type: "text";
        readonly value: unknown;
    } | {
        readonly type: "error";
        readonly value: unknown;
    } | {
        readonly type: "content";
        readonly value: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    };
    readonly output?: {
        readonly structured: unknown;
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    } | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "step-finish";
    readonly index: number;
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "finish";
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly message?: import("./schema/messages.js").AssistantMessage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "media";
    readonly media: import("./media.js").Asset;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | ({
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
})))[];
export declare const toolCalls: (...events: readonly LLMEvent[]) => ({
    readonly type: "step-start";
    readonly index: number;
} | {
    readonly type: "raw";
    readonly data: unknown;
} | {
    readonly type: "text-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-start";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-delta";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly text: string;
    readonly input?: unknown;
} | {
    readonly type: "tool-input-end";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-error";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly raw: string;
} | {
    readonly type: "tool-call";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly input: unknown;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-result";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly result: {
        readonly type: "json";
        readonly value: unknown;
    } | {
        readonly type: "text";
        readonly value: unknown;
    } | {
        readonly type: "error";
        readonly value: unknown;
    } | {
        readonly type: "content";
        readonly value: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    };
    readonly output?: {
        readonly structured: unknown;
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    } | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "step-finish";
    readonly index: number;
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "finish";
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly message?: import("./schema/messages.js").AssistantMessage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "media";
    readonly media: import("./media.js").Asset;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | ({
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
})))[];
export declare const text: (value: string, id: string) => ({
    readonly type: "step-start";
    readonly index: number;
} | {
    readonly type: "raw";
    readonly data: unknown;
} | {
    readonly type: "text-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-start";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-delta";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly text: string;
    readonly input?: unknown;
} | {
    readonly type: "tool-input-end";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-error";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly raw: string;
} | {
    readonly type: "tool-call";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly input: unknown;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-result";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly result: {
        readonly type: "json";
        readonly value: unknown;
    } | {
        readonly type: "text";
        readonly value: unknown;
    } | {
        readonly type: "error";
        readonly value: unknown;
    } | {
        readonly type: "content";
        readonly value: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    };
    readonly output?: {
        readonly structured: unknown;
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    } | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "step-finish";
    readonly index: number;
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "finish";
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly message?: import("./schema/messages.js").AssistantMessage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "media";
    readonly media: import("./media.js").Asset;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | ({
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
})))[];
export declare const textWithUsage: (value: string, id: string, inputTokens: number) => ({
    readonly type: "step-start";
    readonly index: number;
} | {
    readonly type: "raw";
    readonly data: unknown;
} | {
    readonly type: "text-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-start";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-delta";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly text: string;
    readonly input?: unknown;
} | {
    readonly type: "tool-input-end";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-error";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly raw: string;
} | {
    readonly type: "tool-call";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly input: unknown;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-result";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly result: {
        readonly type: "json";
        readonly value: unknown;
    } | {
        readonly type: "text";
        readonly value: unknown;
    } | {
        readonly type: "error";
        readonly value: unknown;
    } | {
        readonly type: "content";
        readonly value: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    };
    readonly output?: {
        readonly structured: unknown;
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    } | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "step-finish";
    readonly index: number;
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "finish";
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly message?: import("./schema/messages.js").AssistantMessage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "media";
    readonly media: import("./media.js").Asset;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | ({
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
})))[];
export declare const toolCall: (id: string, name: string, input: unknown) => ({
    readonly type: "step-start";
    readonly index: number;
} | {
    readonly type: "raw";
    readonly data: unknown;
} | {
    readonly type: "text-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-start";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-delta";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly text: string;
    readonly input?: unknown;
} | {
    readonly type: "tool-input-end";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-error";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly raw: string;
} | {
    readonly type: "tool-call";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly input: unknown;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-result";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly result: {
        readonly type: "json";
        readonly value: unknown;
    } | {
        readonly type: "text";
        readonly value: unknown;
    } | {
        readonly type: "error";
        readonly value: unknown;
    } | {
        readonly type: "content";
        readonly value: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    };
    readonly output?: {
        readonly structured: unknown;
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    } | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "step-finish";
    readonly index: number;
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "finish";
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly message?: import("./schema/messages.js").AssistantMessage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "media";
    readonly media: import("./media.js").Asset;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | ({
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
})))[];
export declare const failAfter: (error: AIError, ...events: readonly LLMEvent[]) => Stream.Stream<{
    readonly type: "step-start";
    readonly index: number;
} | {
    readonly type: "raw";
    readonly data: unknown;
} | {
    readonly type: "text-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-start";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-delta";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly text: string;
    readonly input?: unknown;
} | {
    readonly type: "tool-input-end";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-error";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly raw: string;
} | {
    readonly type: "tool-call";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly input: unknown;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-result";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly result: {
        readonly type: "json";
        readonly value: unknown;
    } | {
        readonly type: "text";
        readonly value: unknown;
    } | {
        readonly type: "error";
        readonly value: unknown;
    } | {
        readonly type: "content";
        readonly value: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    };
    readonly output?: {
        readonly structured: unknown;
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    } | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "step-finish";
    readonly index: number;
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "finish";
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly message?: import("./schema/messages.js").AssistantMessage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "media";
    readonly media: import("./media.js").Asset;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | ({
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
})), AIError, never>;
export declare const hangAfter: (...events: readonly LLMEvent[]) => Stream.Stream<{
    readonly type: "step-start";
    readonly index: number;
} | {
    readonly type: "raw";
    readonly data: unknown;
} | {
    readonly type: "text-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "text-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-start";
    readonly id: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-delta";
    readonly id: string;
    readonly text: string;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "reasoning-end";
    readonly id: string;
    readonly text?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-start";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-delta";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly text: string;
    readonly input?: unknown;
} | {
    readonly type: "tool-input-end";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-input-error";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly raw: string;
} | {
    readonly type: "tool-call";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly input: unknown;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "tool-result";
    readonly id: string;
    readonly name: string;
    readonly namespace?: string | undefined;
    readonly result: {
        readonly type: "json";
        readonly value: unknown;
    } | {
        readonly type: "text";
        readonly value: unknown;
    } | {
        readonly type: "error";
        readonly value: unknown;
    } | {
        readonly type: "content";
        readonly value: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    };
    readonly output?: {
        readonly structured: unknown;
        readonly content: readonly ({
            readonly type: "text";
            readonly text: string;
        } | {
            readonly type: "file";
            readonly uri: string;
            readonly mime: string;
            readonly name?: string | undefined;
        })[];
    } | undefined;
    readonly providerExecuted?: boolean | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "step-finish";
    readonly index: number;
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "finish";
    readonly reason: {
        readonly normalized: "content-filter" | "error" | "length" | "stop" | "tool-calls" | "unknown";
        readonly raw?: string | undefined;
        readonly category?: string | undefined;
        readonly explanation?: string | undefined;
    };
    readonly usage?: import("./schema/events.js").Usage | undefined;
    readonly message?: import("./schema/messages.js").AssistantMessage | undefined;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | {
    readonly type: "media";
    readonly media: import("./media.js").Asset;
    readonly providerMetadata?: {
        readonly [x: string]: {
            readonly [x: string]: unknown;
        };
    } | undefined;
} | ({
    readonly type: "compaction";
    readonly provider: string & import("effect/Brand").Brand<"AI.ProviderID">;
    readonly id?: string | undefined;
    readonly encrypted?: string | undefined;
    readonly text?: string | null | undefined;
} & ({
    readonly encrypted: string;
    readonly text?: never;
} | {
    readonly text: string | null;
    readonly encrypted?: never;
})), never, never>;
/** Provides one shared implementation under the normal client and test-control tags. */
export declare const testLayer: (options?: LayerOptions) => Layer.Layer<import("./route/client.js").LLMClientService | Test, never, never>;
