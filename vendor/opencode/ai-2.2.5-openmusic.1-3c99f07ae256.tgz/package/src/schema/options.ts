import { Schema } from "effect"
import { ModelID, ProviderID } from "./ids.js"
import type { AnyRoute, CompactionOperations } from "../route/client.js"
import { isRecord } from "../utils/record.js"

export const JsonSchema = Schema.Record(Schema.String, Schema.Unknown)
export type JsonSchema = Schema.Schema.Type<typeof JsonSchema>

export const mergeJsonRecords = (
  ...items: ReadonlyArray<Record<string, unknown> | undefined>
): Record<string, unknown> | undefined => {
  const defined = items.filter((item): item is Record<string, unknown> => item !== undefined)
  if (defined.length === 0) return undefined
  if (defined.length === 1 && Object.values(defined[0]).every((value) => value !== undefined)) return defined[0]
  const result: Record<string, unknown> = {}
  for (const item of defined) {
    for (const [key, value] of Object.entries(item)) {
      if (value === undefined) continue
      result[key] = isRecord(result[key]) && isRecord(value) ? mergeJsonRecords(result[key], value) : value
    }
  }
  return Object.keys(result).length === 0 ? undefined : result
}

const mergeStringRecords = (
  ...items: ReadonlyArray<Record<string, string> | undefined>
): Record<string, string> | undefined => {
  const defined = items.filter((item): item is Record<string, string> => item !== undefined)
  if (defined.length === 0) return undefined
  if (defined.length === 1) return defined[0]
  const result = Object.fromEntries(
    defined.flatMap((item) =>
      Object.entries(item).filter((entry): entry is [string, string] => entry[1] !== undefined),
    ),
  )
  return Object.keys(result).length === 0 ? undefined : result
}

export const ProviderOptions = Schema.Record(Schema.String, Schema.Unknown)
export type ProviderOptions = Schema.Schema.Type<typeof ProviderOptions>

export const ProviderMetadata = Schema.Record(Schema.String, Schema.Record(Schema.String, Schema.Unknown)).annotate({
  identifier: "LLM.ProviderMetadata",
})
export type ProviderMetadata = Schema.Schema.Type<typeof ProviderMetadata>

export const mergeProviderOptions = (
  ...items: ReadonlyArray<ProviderOptions | undefined>
): ProviderOptions | undefined => mergeJsonRecords(...items)

/** Milliseconds for an HTTP timeout, or `false` to disable it. */
export const HttpTimeout = Schema.Union([Schema.Number.check(Schema.isGreaterThan(0)), Schema.Literal(false)])
export type HttpTimeout = Schema.Schema.Type<typeof HttpTimeout>

/** Applied to `timeout.headers` when a request leaves it unset. */
export const DEFAULT_HTTP_TIMEOUT_MS = 300_000

/**
 * Applied to `timeout.chunk` when a request leaves it unset. Some providers, such as DeepSeek, have specifically asked
 * clients to allow at least 15 minutes, because their models can stream nothing for minutes while they reason.
 */
export const DEFAULT_CHUNK_TIMEOUT_MS = 900_000

/** `Content-Encoding` for JSON request bodies; `none` sends plain JSON. */
export const RequestEncoding = Schema.Literals(["zstd", "gzip", "none"])
export type RequestEncoding = Schema.Schema.Type<typeof RequestEncoding>

/** Rare wire-level overrides. */
export interface HttpOptions {
  readonly query?: Record<string, string>
  /** Deep-merged over the provider-native JSON body. */
  readonly body?: Record<string, unknown>
  /** Compression for JSON request bodies. Only set it for endpoints known to decode it. */
  readonly encoding?: RequestEncoding
}

/** Per-phase time limits in milliseconds. */
export interface TimeoutConfig {
  /** The whole request, from send until the response completes. Unbounded when unset. */
  readonly total?: HttpTimeout
  /** Until response headers arrive. */
  readonly headers?: HttpTimeout
  /** Between streamed response chunks once headers have arrived. */
  readonly chunk?: HttpTimeout
}

/** Milliseconds for the whole request, `false` to disable it, or per-phase limits. */
export type RequestTimeout = HttpTimeout | TimeoutConfig

/** Transport settings shared by requests, models and routes. */
export interface TransportOptions {
  /** Merged over the provider's headers; these win. */
  readonly headers?: Record<string, string>
  /** Applied to text requests; media requests do not apply it yet. */
  readonly timeout?: RequestTimeout
  readonly http?: HttpOptions
}

/** The fields every request shares, whatever its modality. */
export interface BaseRequest<Model, Options = ProviderOptions> extends TransportOptions {
  readonly model: Model
  readonly providerOptions?: Options
  /** Sends this call through `fetch` instead of the client's HTTP executor. */
  readonly fetch?: typeof globalThis.fetch
}

export const timeoutConfig = (timeout: RequestTimeout | undefined): TimeoutConfig =>
  typeof timeout === "object" ? timeout : { total: timeout }

const last = <A>(values: ReadonlyArray<A | undefined>) => values.findLast((value) => value !== undefined)

const someDefined = <A extends object>(value: A) =>
  Object.values(value).some((item) => item !== undefined) ? value : undefined

/** Merge transport settings; later items win, headers, query and body merge by key. */
export const mergeTransport = (...items: ReadonlyArray<TransportOptions | undefined>): TransportOptions => {
  const timeouts = items.map((item) => timeoutConfig(item?.timeout))
  const http = items.map((item) => item?.http)
  return {
    headers: mergeStringRecords(...items.map((item) => item?.headers)),
    timeout: someDefined({
      total: last(timeouts.map((item) => item.total)),
      headers: last(timeouts.map((item) => item.headers)),
      chunk: last(timeouts.map((item) => item.chunk)),
    }),
    http: someDefined({
      query: mergeStringRecords(...http.map((item) => item?.query)),
      body: mergeJsonRecords(...http.map((item) => item?.body)),
      encoding: last(http.map((item) => item?.encoding)),
    }),
  }
}

/** Portable sampling knobs, set at the top level of text requests, model defaults and route defaults. */
export interface GenerationOptionsFields {
  readonly maxTokens?: number
  readonly temperature?: number
  readonly topP?: number
  readonly topK?: number
  readonly frequencyPenalty?: number
  readonly presencePenalty?: number
  readonly seed?: number
  readonly stop?: ReadonlyArray<string>
}

/** The keys of `GenerationOptionsFields`, for splitting a flat record into portable knobs and provider options. */
export const GENERATION_KEYS: ReadonlySet<string> = new Set([
  "maxTokens",
  "temperature",
  "topP",
  "topK",
  "frequencyPenalty",
  "presencePenalty",
  "seed",
  "stop",
] satisfies ReadonlyArray<keyof GenerationOptionsFields>)

/** Pick the generation knobs out of each item; later items win per knob. */
export const mergeGeneration = (...items: ReadonlyArray<GenerationOptionsFields | undefined>) =>
  Object.fromEntries(
    [...GENERATION_KEYS].map((key) => [key, last(items.map((item) => item?.[key as keyof GenerationOptionsFields]))]),
  ) as GenerationOptionsFields

/** Request options a model applies under each request: the same keys as a request, and the request wins. */
export interface RequestOptions extends TransportOptions, GenerationOptionsFields {
  readonly providerOptions?: ProviderOptions
}

/** Merge model options; later items win per key. Empty results are `undefined`. */
export const mergeRequestOptions = (
  ...items: ReadonlyArray<RequestOptions | undefined>
): RequestOptions | undefined => {
  const merged = Object.entries({
    ...mergeTransport(...items),
    ...mergeGeneration(...items),
    providerOptions: mergeProviderOptions(...items.map((item) => item?.providerOptions)),
  }).filter(([, value]) => value !== undefined)
  return merged.length === 0 ? undefined : (Object.fromEntries(merged) as RequestOptions)
}

/** Provider-defined string enum: known values for autocomplete, any string accepted. */
export type OpenString<Known extends string> = Known | (string & {})

export const ReasoningEfforts = ["none", "minimal", "low", "medium", "high", "xhigh", "max"] as const
export type ReasoningEffort = OpenString<(typeof ReasoningEfforts)[number]>
export const ReasoningEffort = Schema.declare<ReasoningEffort>(
  (value): value is ReasoningEffort => typeof value === "string",
  { title: "ReasoningEffort" },
)

/** Tool schema sanitizer for a model family. `none` opts out of the protocol and model-name defaults. */
export const LanguageModelSanitizerCompatibility = Schema.Literals(["gemini", "moonshot", "none"])
export type LanguageModelSanitizerCompatibility = Schema.Schema.Type<typeof LanguageModelSanitizerCompatibility>

export const LanguageModelMaxTokensFieldCompatibility = Schema.Literals(["max_completion_tokens", "max_tokens"])
export type LanguageModelMaxTokensFieldCompatibility = Schema.Schema.Type<
  typeof LanguageModelMaxTokensFieldCompatibility
>

export const LanguageModelCacheFormatCompatibility = Schema.Literals(["anthropic", "alibaba"])
export type LanguageModelCacheFormatCompatibility = Schema.Schema.Type<typeof LanguageModelCacheFormatCompatibility>

export class LanguageModelCompatibility extends Schema.Class<LanguageModelCompatibility>(
  "LLM.LanguageModelCompatibility",
)({
  sanitizer: Schema.optional(LanguageModelSanitizerCompatibility),
  reasoningField: Schema.optional(Schema.String),
  /** Require every assistant message to include its reasoning field, even when empty. */
  requireReasoning: Schema.optional(Schema.Boolean),
  maxTokensField: Schema.optional(LanguageModelMaxTokensFieldCompatibility),
  requireFinishReason: Schema.optional(Schema.Boolean),
  requireAssistantAfterTool: Schema.optional(Schema.Boolean),
  /** Prompt-cache marker syntax the endpoint accepts. Overrides the route default; both send `cache_control`, and `alibaba` skips tool definitions. */
  cacheFormat: Schema.optional(LanguageModelCacheFormatCompatibility),
  zaiToolStream: Schema.optional(Schema.Boolean),
  requireSignature: Schema.optional(Schema.Boolean),
  /** Supports Anthropic's thinking-prefix mismatch controls. Overrides model-ID detection. */
  supportsThinkingBlockBinding: Schema.optional(Schema.Boolean),
}) {}

export namespace LanguageModelCompatibility {
  export type Input = LanguageModelCompatibility | ConstructorParameters<typeof LanguageModelCompatibility>[0]

  /** Normalize model/upstream compatibility metadata without projecting requests. */
  export const make = (input: Input) =>
    input instanceof LanguageModelCompatibility ? input : new LanguageModelCompatibility(input)
}

/**
 * What the model accepts on its API: models.dev v2 `capabilities` in camelCase, with the API's own overrides merged in.
 * Unset fields keep the protocol default, which may still guess from the provider, base URL or model ID.
 */
export interface Capabilities {
  readonly tools?: {
    readonly supported?: boolean
    /** Accepts `strict` on function tools. OpenAI Chat detects it from the provider when unset. */
    readonly strict?: boolean
    readonly choice?: ReadonlyArray<"auto" | "none" | "required" | "tool">
    readonly search?: boolean
    /** Input formats accepted by custom (free-form) tools. */
    readonly freeform?: ReadonlyArray<"text" | "lark" | "regex">
    /** Accepts a changed tool list mid-conversation. */
    readonly updates?: boolean
  }
  readonly reasoning?: {
    readonly supported?: boolean
    readonly default?:
      | { readonly type: "toggle"; readonly value: boolean }
      | { readonly type: "effort"; readonly value: ReasoningEffort }
      | { readonly type: "budget"; readonly value: number }
    readonly toggle?: boolean
    readonly effort?: ReadonlyArray<ReasoningEffort>
    readonly budget?: { readonly min?: number; readonly max?: number }
    /** Accepts per-message effort updates. Detected from the model ID when unset. */
    readonly updates?: boolean
  }
  readonly cache?:
    | false
    | {
        readonly implicit?: true | { readonly ttl?: ReadonlyArray<CacheTTL>; readonly minTokens?: number }
        readonly explicit?:
          | true
          | {
              readonly ttl?: ReadonlyArray<CacheTTL>
              readonly maxBreakpoints?: number
              readonly targets?: ReadonlyArray<"tools" | "system" | "messages">
              readonly minTokens?: number
            }
      }
  readonly structuredOutput?: boolean
  readonly temperature?: boolean
  readonly topP?: boolean
  readonly topK?: boolean
  /** Accepts mid-conversation system messages. Anthropic Messages detects it from the model ID when unset. */
  readonly systemUpdates?: boolean
  /** Accepts `store`. OpenAI Chat detects it from the provider when unset. */
  readonly store?: boolean
  /** Accepts `stream_options.include_usage`. OpenAI Chat defaults to true. */
  readonly streamUsage?: boolean
  // Accepts `prompt_cache_key` in the request body. Chat omits the key unless
  // this is true; other protocols omit it only when this is false.
  // Session-affinity headers still flow regardless.
  readonly promptCacheKey?: boolean
  readonly serviceTier?: ReadonlyArray<OpenString<"flex" | "priority" | "fast" | "ultrafast" | "standby">>
}

export class LanguageModel<
  Options extends ProviderOptions = ProviderOptions,
  Compact extends CompactionOperations | undefined = CompactionOperations | undefined,
> {
  declare protected readonly _ProviderOptions: Options
  readonly id: ModelID
  readonly provider: ProviderID
  readonly route: AnyRoute<Compact>
  readonly options?: RequestOptions
  readonly capabilities?: Capabilities
  readonly compatibility?: LanguageModelCompatibility

  constructor(input: LanguageModel.ConstructorInput<Compact>) {
    this.id = input.id
    this.provider = input.provider
    this.route = input.route
    this.options = input.options
    this.capabilities = input.capabilities
    this.compatibility = input.compatibility
  }

  static make<
    Options extends ProviderOptions = ProviderOptions,
    Compact extends CompactionOperations | undefined = CompactionOperations | undefined,
  >(input: LanguageModel.Input<Compact>) {
    return new LanguageModel<Options, Compact>({
      id: ModelID.make(input.id),
      provider: ProviderID.make(input.provider),
      route: input.route,
      // The route's options are a preset under the model's own.
      options: mergeRequestOptions(input.route.options, input.options),
      capabilities: input.capabilities,
      compatibility:
        input.compatibility === undefined ? undefined : LanguageModelCompatibility.make(input.compatibility),
    })
  }

  static input<Options extends ProviderOptions, Compact extends CompactionOperations | undefined>(
    model: LanguageModel<Options, Compact>,
  ): LanguageModel.ConstructorInput<Compact> {
    return {
      id: model.id,
      provider: model.provider,
      route: model.route,
      options: model.options,
      capabilities: model.capabilities,
      compatibility: model.compatibility,
    }
  }

  static update<Options extends ProviderOptions, Compact extends CompactionOperations | undefined>(
    model: LanguageModel<Options>,
    patch: Partial<LanguageModel.Input<Compact>> & { readonly route: AnyRoute<Compact> },
  ): LanguageModel<Options, Compact>
  static update<Options extends ProviderOptions, Compact extends CompactionOperations | undefined>(
    model: LanguageModel<Options, Compact>,
    patch: Partial<Omit<LanguageModel.Input, "route">> & { readonly route?: undefined },
  ): LanguageModel<Options, Compact>
  static update<Options extends ProviderOptions>(
    model: LanguageModel<Options>,
    patch: Partial<LanguageModel.Input>,
  ): LanguageModel<Options>
  static update<Options extends ProviderOptions>(model: LanguageModel<Options>, patch: Partial<LanguageModel.Input>) {
    if (Object.keys(patch).length === 0) return model
    return LanguageModel.make<Options>({
      ...LanguageModel.input(model),
      ...patch,
      route: patch.route ?? model.route,
    })
  }
}

export namespace LanguageModel {
  export type ConstructorInput<Compact extends CompactionOperations | undefined = CompactionOperations | undefined> = {
    readonly id: ModelID
    readonly provider: ProviderID
    readonly route: AnyRoute<Compact>
    readonly options?: RequestOptions
    readonly capabilities?: Capabilities
    readonly compatibility?: LanguageModelCompatibility
  }

  export type Input<Compact extends CompactionOperations | undefined = CompactionOperations | undefined> = Omit<
    ConstructorInput<Compact>,
    "id" | "provider" | "compatibility"
  > & {
    readonly id: string | ModelID
    readonly provider: string | ProviderID
    readonly compatibility?: LanguageModelCompatibility.Input
  }
}

export type LanguageModelInput = LanguageModel.Input

export type LanguageModelProviderOptions<SelectedModel> =
  SelectedModel extends LanguageModel<infer Options> ? Options : never

export const LanguageModelSchema = Schema.declare((value): value is LanguageModel => value instanceof LanguageModel, {
  expected: "LLM.LanguageModel",
})

// Provider cache lifetime such as "5m", "30m", "1h" or "24h", in models.dev's duration format. It is sent as given;
// each provider accepts its own set, and omitting it keeps the provider default.
export const CacheTTL = Schema.TemplateLiteral([Schema.Number, Schema.Literals(["ms", "s", "m", "h", "d"])]).check(
  Schema.isPattern(/^\d+(ms|s|m|h|d)$/),
)
export type CacheTTL = typeof CacheTTL.Type

export class CacheHint extends Schema.Class<CacheHint>("LLM.CacheHint")({
  type: Schema.Literals(["ephemeral", "persistent"]),
  ttl: Schema.optional(CacheTTL),
}) {}

// Auto-placement policy for prompt caching. The protocol-neutral lowering step
// reads this and injects `CacheHint`s at the configured boundaries; the
// per-protocol body builders then translate those hints into wire markers as
// usual. `"auto"` is the default for agent loops — it places
// breakpoints at the last tool definition, the first and last distinct system
// parts, and the conversation tail so recent prefixes remain reusable during
// tool loops.
//
// Pass `"none"` to opt out entirely (the legacy behavior). Pass the granular
// object form to choose placements exactly; an object with only `ttl` keeps
// the automatic placements and sets their lifetime. Routes without inline
// markers send `ttl` as a request-level cache option where one exists.
export const CachePolicyObject = Schema.Struct({
  tools: Schema.optional(Schema.Boolean),
  system: Schema.optional(Schema.Boolean),
  messages: Schema.optional(
    Schema.Union([
      Schema.Literal("latest-user-message"),
      Schema.Literal("latest-assistant"),
      Schema.Struct({ tail: Schema.Natural }),
    ]),
  ),
  ttl: Schema.optional(CacheTTL),
})
export type CachePolicyObject = Schema.Schema.Type<typeof CachePolicyObject>

export const CachePolicy = Schema.Union([Schema.Literal("auto"), Schema.Literal("none"), CachePolicyObject])
export type CachePolicy = Schema.Schema.Type<typeof CachePolicy>
