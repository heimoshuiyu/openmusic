import { Schema } from "effect"
import { NonNegativeInt } from "@opencode/schema"
import { Tool } from "@opencode/schema/tool"
import { ProviderID, RouteID } from "./ids.js"
import type { LLMResponse } from "./events.js"
import { awsErrorType, providerCodes } from "../utils/provider-codes.js"

export const ProviderFailureClassification = Schema.Literals(["context-overflow", "payload-too-large"])
export type ProviderFailureClassification = typeof ProviderFailureClassification.Type

export class HttpContext extends Schema.Class<HttpContext>("AI.HttpContext")({
  url: Schema.String,
  status: Schema.Int.check(Schema.isBetween({ minimum: 100, maximum: 599 })),
  headers: Schema.Record(Schema.String, Schema.String),
}) {}

export class HttpRateLimitDetails extends Schema.Class<HttpRateLimitDetails>("AI.HttpRateLimitDetails")({
  retryAfterMs: Schema.optional(NonNegativeInt),
  limit: Schema.optional(Schema.Record(Schema.String, Schema.String)),
  remaining: Schema.optional(Schema.Record(Schema.String, Schema.String)),
  reset: Schema.optional(Schema.Record(Schema.String, Schema.String)),
}) {}

const ReasonFields = {
  message: Schema.String,
  // Preserve the complete original response or triggering event before decoding narrows it.
  body: Schema.optional(Schema.String),
  http: Schema.optional(HttpContext),
  cause: Schema.optional(Schema.Defect({ includeStack: true })),
}

export class InvalidRequestError extends Schema.TaggedError<InvalidRequestError>("AI.Error.InvalidRequest")(
  "InvalidRequest",
  {
    ...ReasonFields,
    parameter: Schema.optional(Schema.String),
    classification: Schema.optional(ProviderFailureClassification),
  },
) {}

/**
 * A caller-requested operation the selected route does not implement, such as
 * explicit compaction on a route without a compact endpoint. Detected locally
 * before any network I/O, so unlike transport or provider-output failures it
 * never carries HTTP context from a provider round-trip.
 */
export class UnsupportedOperationError extends Schema.TaggedError<UnsupportedOperationError>(
  "AI.Error.UnsupportedOperation",
)("UnsupportedOperation", {
  ...ReasonFields,
  operation: Schema.String,
  provider: Schema.optional(ProviderID),
  route: Schema.optional(RouteID),
}) {}

/**
 * Provider settings that are missing, conflicting, or unsupported, such as
 * Azure without `resourceName` or `baseURL`. Thrown synchronously while a
 * provider facade or package entrypoint configures a model, before any
 * request exists, so it is not an `AIError` reason.
 */
export class ProviderConfigurationError extends Schema.TaggedError<ProviderConfigurationError>(
  "AI.Error.ProviderConfiguration",
)("ProviderConfiguration", {
  provider: ProviderID,
  message: Schema.String,
}) {}

export class AuthenticationError extends Schema.TaggedError<AuthenticationError>("AI.Error.Authentication")(
  "Authentication",
  ReasonFields,
) {}

export class RateLimitError extends Schema.TaggedError<RateLimitError>("AI.Error.RateLimit")("RateLimit", {
  ...ReasonFields,
  retryAfterMs: Schema.optional(NonNegativeInt),
  rateLimit: Schema.optional(HttpRateLimitDetails),
}) {}

export class QuotaExceededError extends Schema.TaggedError<QuotaExceededError>("AI.Error.QuotaExceeded")(
  "QuotaExceeded",
  {
    ...ReasonFields,
    retryAfterMs: Schema.optional(NonNegativeInt),
  },
) {}

export class ContentPolicyError extends Schema.TaggedError<ContentPolicyError>("AI.Error.ContentPolicy")(
  "ContentPolicy",
  ReasonFields,
) {}

export class ProviderInternalError extends Schema.TaggedError<ProviderInternalError>("AI.Error.ProviderInternal")(
  "ProviderInternal",
  {
    ...ReasonFields,
    retryAfterMs: Schema.optional(NonNegativeInt),
  },
) {}

export const TransportType = Schema.Literals(["http", "websocket"])
export type TransportType = typeof TransportType.Type

export const TransportOperation = Schema.Literals(["request", "read", "write"])
export type TransportOperation = typeof TransportOperation.Type

export class TransportError extends Schema.TaggedError<TransportError>("AI.Error.Transport")("Transport", {
  ...ReasonFields,
  transport: TransportType,
  operation: TransportOperation,
  code: Schema.optional(Schema.String),
  url: Schema.optional(Schema.String),
  phase: Schema.optional(
    Schema.Literals(["prepare", "queue", "connect", "send", "receive", "decode", "complete", "fallback", "close"]),
  ),
  delivery: Schema.optional(Schema.Literals(["not-sent", "rejected", "ambiguous", "accepted"])),
  recovery: Schema.optional(
    Schema.Literals(["retry-connect", "retry-full", "rotate-and-retry-full", "fallback-http", "fail"]),
  ),
}) {}

export class InvalidProviderOutputError extends Schema.TaggedError<InvalidProviderOutputError>(
  "AI.Error.InvalidProviderOutput",
)("InvalidProviderOutput", {
  ...ReasonFields,
  classification: Schema.optional(Schema.Literals(["incomplete-stream"])),
  route: Schema.optional(Schema.String),
}) {}

export class UnknownProviderError extends Schema.TaggedError<UnknownProviderError>("AI.Error.UnknownProvider")(
  "UnknownProvider",
  ReasonFields,
) {}

/** A caller-supplied deadline elapsed, such as `Generation.await` polling past its `Poll.timeout`. */
export class TimeoutError extends Schema.TaggedError<TimeoutError>("AI.Error.Timeout")("Timeout", {
  ...ReasonFields,
  timeoutMs: Schema.optional(NonNegativeInt),
}) {}

export const AIErrorReason = Schema.Union([
  InvalidRequestError,
  UnsupportedOperationError,
  AuthenticationError,
  RateLimitError,
  QuotaExceededError,
  ContentPolicyError,
  ProviderInternalError,
  TransportError,
  InvalidProviderOutputError,
  UnknownProviderError,
  TimeoutError,
]).pipe(Schema.toTaggedUnion("_tag"))
export type AIErrorReason = Schema.Schema.Type<typeof AIErrorReason>

export class AIError extends Schema.TaggedError<AIError>()("AI.Error", {
  reason: AIErrorReason,
}) {
  override readonly cause = this.reason
  /** Output that arrived before `generate` (including its `schema` decode) or a `loop` step failed. Not in the schema, so encoding omits it. */
  readonly partial?: LLMResponse

  constructor(props: Pick<AIError, "reason" | "partial">) {
    super({ reason: props.reason })
    this.partial = props.partial
  }

  override get message(): string {
    return this.reason.message
  }

  /** HTTP status of the failed response, when the failure came from one. */
  get status(): number | undefined {
    return this.reason.http?.status
  }

  /** The provider's error code from the response body or `x-amzn-errortype`, or the transport's system error code. */
  get code(): string | undefined {
    if (this.reason._tag === "Transport" && this.reason.code !== undefined) return this.reason.code
    return [
      ...(this.reason.body === undefined ? [] : providerCodes(this.reason.body)),
      ...awsErrorType(this.reason.http?.headers["x-amzn-errortype"]),
    ][0]
  }

  /** Delay the provider asked for before retrying, from `retry-after` style headers. */
  get retryAfterMs(): number | undefined {
    if (this.reason._tag === "RateLimit") return this.reason.retryAfterMs ?? this.reason.rateLimit?.retryAfterMs
    if (this.reason._tag === "QuotaExceeded" || this.reason._tag === "ProviderInternal") return this.reason.retryAfterMs
    return undefined
  }

  /**
   * Whether a failed call may succeed when sent again: rate limits, provider-side failures, transport failures that did
   * not deliver an accepted write, and unrecognized failures. Callers decide which calls are safe to repeat.
   */
  get isRetryable(): boolean {
    const override = this.reason.http?.headers["x-should-retry"]
    if (override === "true") return true
    if (override === "false") return false
    switch (this.reason._tag) {
      case "RateLimit":
      case "ProviderInternal":
        return true
      // A WebSocket acknowledgment marks delivery accepted before model output may exist.
      // Read failures can still recover; the caller chooses retry versus continuation from durable output.
      case "Transport":
        return (
          this.reason.delivery !== "rejected" && (this.reason.delivery !== "accepted" || this.reason.operation === "read")
        )
      case "InvalidProviderOutput":
        return this.reason.classification === "incomplete-stream"
      // Unrecognized failures retry: classification records affirmative
      // deterministic evidence, and transient failures are exactly the ones
      // that arrive in shapes no classifier anticipates.
      case "UnknownProvider":
        return true
      case "Authentication":
      case "QuotaExceeded":
      case "ContentPolicy":
      case "InvalidRequest":
      case "UnsupportedOperation":
      case "Timeout":
        return false
      default: {
        const exhaustive: never = this.reason
        return exhaustive
      }
    }
  }
}

/** Return `error` with `partial` attached, or unchanged when there is no partial output. */
export const withPartial = (error: AIError, partial: LLMResponse | undefined) =>
  partial === undefined ? error : new AIError({ reason: error.reason, partial })

/**
 * Failure type for tool execute handlers. Handlers must map their internal
 * errors to this shape; the runtime catches `ToolFailure`s and surfaces them
 * as a `tool-result` of `type: "error"` so the model can self-correct.
 *
 * Anything thrown or yielded by a handler that is not a `ToolFailure` is
 * treated as a defect and fails the stream.
 */
export class ToolFailure extends Tool.Error {}
