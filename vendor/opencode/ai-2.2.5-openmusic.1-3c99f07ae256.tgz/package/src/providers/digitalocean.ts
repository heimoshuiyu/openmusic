import type { ProviderPackage } from "../provider-package.js"
import { OpenAIChat } from "../protocols/openai-chat.js"
import { OpenAIImages } from "../protocols/openai-images.js"
import { OpenResponses } from "../protocols/open-responses.js"
import { SystemOne } from "../protocols/system-one.js"
import { cacheControl } from "../protocols/utils/cache.js"
import type { ProviderAuthOption } from "../route/auth-options.js"
import { Route } from "../route/client.js"
import { Endpoint } from "../route/endpoint.js"
import { MediaRoute } from "../route/media.js"
import { Protocol } from "../route/protocol.js"
import { ProviderID, type ModelID, type ProviderOptions, type RequestOptions } from "../schema/index.js"
import type { OpenAIProviderOptionsInput } from "./openai-options.js"
import type { OpenResponsesProviderOptionsInput } from "./open-responses-options.js"
import { bearerRouteDefaults } from "./settings.js"

export const id = ProviderID.make("digitalocean")
const baseURL = "https://inference.do-ai.run/v1"

export type Config = Omit<RequestOptions, "providerOptions"> &
  ProviderAuthOption<"optional"> & {
    readonly baseURL?: string
    readonly providerOptions?: OpenAIProviderOptionsInput | OpenResponsesProviderOptionsInput
  }

export type Settings<Options = OpenAIProviderOptionsInput> = ProviderPackage.Settings &
  Options & { readonly apiKey?: string | false }

export const protocol = Protocol.make({
  id: "digitalocean-chat",
  body: {
    schema: OpenAIChat.protocol.body.schema,
    from: (request) => OpenAIChat.fromRequest(request, { cacheControl: cacheControl() }),
  },
  stream: OpenAIChat.protocol.stream,
})

export const route = Route.make({
  id: "digitalocean",
  provider: id,
  providerMetadataKey: "digitalocean",
  protocol,
  endpoint: Endpoint.path("/chat/completions", { baseURL }),
  framing: OpenAIChat.framing,
})

const responsesRoute = Route.make({
  id: "digitalocean-responses",
  provider: id,
  providerMetadataKey: "digitalocean",
  protocol: OpenResponses.protocol,
  endpoint: Endpoint.path("/responses", { baseURL }),
  transport: OpenResponses.httpTransport,
  options: { providerOptions: { store: false, include: ["reasoning.encrypted_content"] } },
})

export const routes = [route, responsesRoute]

export const configure = (input: Config = {}) => {
  const options = bearerRouteDefaults(
    input,
    ["DIGITALOCEAN_ACCESS_TOKEN", "DIGITALOCEAN_API_KEY", "DO_INFERENCE_API_KEY"],
    baseURL,
  )
  const configured = route.with(options)
  const configuredResponses = responsesRoute.with(options)
  const decisionRoute = SystemOne.route.with({
    provider: id,
    providerMetadataKey: "digitalocean",
    endpoint: options.endpoint,
    auth: options.auth,
    // DigitalOcean serves TypeSafe's Jev, which needs this header for images.
    headers: { "TypeSafe-Danger-Zone-Images": "true", ...input.headers },
    http: input.http,
  })
  const decision = (modelID: string | ModelID, providerOptions?: ProviderOptions) =>
    decisionRoute.model({ id: modelID, providerOptions })
  const media = MediaRoute.deployment({ ...input, baseURL: options.endpoint.baseURL }, options.auth)
  const image = (modelID: string | ModelID, providerOptions?: ProviderOptions) =>
    OpenAIImages.model({ ...media, id: modelID, provider: id, providerOptions })
  const chat = (modelID: string | ModelID) =>
    configured.model<OpenAIProviderOptionsInput>({
      id: modelID,
      capabilities: { promptCacheKey: true },
    })
  return {
    id,
    model: chat,
    chat,
    responses: (modelID: string | ModelID) =>
      configuredResponses.model<OpenResponsesProviderOptionsInput>({ id: modelID }),
    image,
    decision,
    configure,
  }
}

export const provider = configure()
export const decision = provider.decision
export const image = provider.image
export const chat = provider.chat
export const responses = provider.responses

export const model: ProviderPackage.Model<Settings, OpenAIProviderOptionsInput> = (modelID, settings) =>
  configure(config(settings)).model(modelID)
export const responsesModel: ProviderPackage.Model<
  Settings<OpenResponsesProviderOptionsInput>,
  OpenResponsesProviderOptionsInput
> = (modelID, settings) => configure(config(settings)).responses(modelID)
export const imageModel = (modelID: string, settings?: Settings) => {
  const input = config(settings)
  return configure(input).image(modelID, input.providerOptions)
}
export const decisionModel = (modelID: string, settings?: Settings) => {
  const input = config(settings)
  return configure(input).decision(modelID, input.providerOptions)
}

function config({ apiKey, baseURL, body, headers, ...providerOptions }: Settings<Config["providerOptions"]> = {}) {
  return {
    apiKey,
    baseURL,
    headers,
    http: { body },
    providerOptions,
  }
}

export * as DigitalOcean from "./digitalocean.js"
