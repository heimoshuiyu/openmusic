import { Effect, Schema, Struct } from "effect"
import type { ProviderPackage } from "../provider-package.js"
import { AnthropicMessages } from "../protocols/anthropic-messages.js"
import { Auth } from "../route/auth.js"
import { Route } from "../route/client.js"
import { Endpoint } from "../route/endpoint.js"
import { Protocol } from "../route/protocol.js"
import { ProviderID, type ModelID, type RequestOptions } from "../schema/index.js"
import { GoogleVertexShared } from "./google-vertex-shared.js"

export type AnthropicOptionsInput = AnthropicMessages.OptionsInput
export type AnthropicProviderOptionsInput = AnthropicMessages.ProviderOptionsInput
export type AnthropicThinkingInput = AnthropicMessages.ThinkingInput

const VERSION = "vertex-2023-10-16" as const
const HEADER_VERSION = "2023-06-01" as const

export const id = ProviderID.make("google-vertex")

export type Config = RequestOptions &
  GoogleVertexShared.OAuthOptions & {
    readonly baseURL?: string
    readonly location?: string
    readonly project?: string
    readonly providerOptions?: AnthropicMessages.ProviderOptionsInput
  }

export type Settings = ProviderPackage.Settings &
  AnthropicMessages.ProviderOptionsInput & {
    readonly accessToken?: string
    readonly apiKey?: never
    readonly baseURL?: string
    readonly location?: string
    readonly project?: string
  }

const route = Route.make({
  id: "google-vertex-messages",
  provider: id,
  providerMetadataKey: "vertex",
  protocol: Protocol.make({
    id: AnthropicMessages.protocol.id,
    body: {
      schema: Schema.Struct({
        ...Struct.omit(AnthropicMessages.AnthropicMessagesBody.fields, ["model"]),
        anthropic_version: Schema.Literal(VERSION),
      }),
      from: (request) =>
        AnthropicMessages.protocol.body.from(request).pipe(
          Effect.map((body) => ({
            ...Struct.omit(body, ["model"]),
            anthropic_version: VERSION,
          })),
        ),
    },
    stream: AnthropicMessages.protocol.stream,
    supportsEffortUpdates: AnthropicMessages.protocol.supportsEffortUpdates,
  }),
  endpoint: Endpoint.path(({ request }) => `/${request.model.id}:streamRawPredict`),
  auth: Auth.none,
  transport: AnthropicMessages.transport<
    Omit<AnthropicMessages.AnthropicMessagesBody, "model"> & { readonly anthropic_version: typeof VERSION }
  >(),
  headers: () => ({ "anthropic-version": HEADER_VERSION }),
})

export const routes = [route]

const configuredRoute = (input: Config) =>
  GoogleVertexShared.oauthRoute(
    route,
    "Messages",
    input,
    (project, location) =>
      `https://${GoogleVertexShared.host(location)}/v1/projects/${project}/locations/${location}/publishers/anthropic/models`,
  )

export const configure = (input: Config = {}) => {
  const route = configuredRoute(input)
  return {
    id,
    model: (modelID: string | ModelID) => route.model<AnthropicMessages.ProviderOptionsInput>({ id: modelID }),
    configure,
  }
}

export const provider = {
  id,
  configure,
}

export const model: ProviderPackage.Model<Settings, AnthropicMessages.ProviderOptionsInput> = (
  modelID,
  settings = {},
) =>
  configure(GoogleVertexShared.oauthSettings<AnthropicMessages.ProviderOptionsInput>("Messages", settings)).model(
    modelID,
  )
