import { Effect, Schema } from "effect"
import type { ProviderPackage } from "../provider-package.js"
import { OpenAIChat } from "../protocols/openai-chat.js"
import { ProviderShared } from "../protocols/shared.js"
import type { ProviderAuthOption } from "../route/auth-options.js"
import { Route } from "../route/client.js"
import { Endpoint } from "../route/endpoint.js"
import { Protocol } from "../route/protocol.js"
import { ProviderID, type ModelID, type LLMRequest, type RequestOptions } from "../schema/index.js"
import type { OpenAIProviderOptionsInput } from "./openai-options.js"
import { bearerRouteDefaults, toConfig } from "./settings.js"

export const id = ProviderID.make("groq")
const baseURL = "https://api.groq.com/openai/v1"

export type ProviderOptions = Pick<OpenAIProviderOptionsInput, "reasoningEffort"> & {
  /** Controls visible reasoning on GPT-OSS; other models always use parsed reasoning. */
  readonly includeReasoning?: boolean
  readonly parallelToolCalls?: boolean
  readonly serviceTier?: "on_demand" | "flex" | "auto" | "performance" | (string & {})
  readonly user?: string
}

export type Config = Omit<RequestOptions, "providerOptions"> &
  ProviderAuthOption<"optional"> & {
    readonly baseURL?: string
    readonly providerOptions?: ProviderOptions
  }

export type Settings = ProviderPackage.Settings &
  ProviderOptions & {
    readonly apiKey?: string | false
    readonly baseURL?: string
  }

const Options = Schema.Struct({
  includeReasoning: Schema.optional(Schema.Boolean),
  user: Schema.optional(Schema.String),
})

export const protocol = Protocol.make({
  id: "groq-chat",
  body: {
    schema: Schema.Struct({
      ...OpenAIChat.bodyFields,
      reasoning_format: Schema.optional(Schema.Literal("parsed")),
      include_reasoning: Schema.optional(Schema.Boolean),
      user: Schema.optional(Schema.String),
    }),
    from: Effect.fn("Groq.fromRequest")(function* (request: LLMRequest) {
      const options = yield* ProviderShared.validateWith(Schema.decodeUnknownEffect(Options))(
        request.providerOptions ?? {},
      )
      const gptOSS = request.model.id.startsWith("openai/gpt-oss-")
      return {
        ...(yield* OpenAIChat.fromRequest(request)),
        reasoning_format: gptOSS ? undefined : ("parsed" as const),
        include_reasoning: gptOSS ? options.includeReasoning : undefined,
        user: options.user,
      }
    }),
  },
  stream: OpenAIChat.protocol.stream,
})

export const route = Route.make({
  id: "groq-chat",
  provider: id,
  providerMetadataKey: "groq",
  protocol,
  endpoint: Endpoint.path("/chat/completions", { baseURL }),
  framing: OpenAIChat.framing,
})

export const configure = (input: Config = {}) => {
  const configured = route.with(bearerRouteDefaults(input, "GROQ_API_KEY", baseURL))
  return {
    id,
    model: (modelID: string | ModelID) =>
      configured.model<ProviderOptions>({
        id: modelID,
        compatibility: {
          maxTokensField: "max_completion_tokens",
          reasoningField: "reasoning",
          requireReasoning: false,
        },
        capabilities: { tools: { strict: false } },
      }),
    configure,
  }
}

export const provider = configure()

export const model: ProviderPackage.Model<Settings, ProviderOptions> = (modelID, settings) =>
  configure(toConfig(settings)).model(modelID)

export * as Groq from "./groq.js"
