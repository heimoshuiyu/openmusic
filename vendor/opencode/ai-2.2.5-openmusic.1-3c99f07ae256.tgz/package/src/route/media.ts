import { Duration, Effect, Schedule, Schema, Stream } from "effect"
import { Headers, HttpClientRequest, type HttpClientResponse } from "effect/http"
import { Auth, type AuthInput } from "./auth.js"
import { Endpoint } from "./endpoint.js"
import type { Interface } from "./executor-service.js"
import { RequestExecutor } from "./executor.js"
import { MediaProtocol } from "./media-protocol.js"
import { Generation, isTerminal } from "../generation.js"
import { isRetryable } from "../provider-error.js"
import {
  AIError,
  AIErrorReason,
  InvalidRequestError,
  ProviderID,
  UnsupportedOperationError,
  mergeProviderOptions,
  mergeTransport,
  type BaseRequest,
  type HttpOptions,
  type ProviderOptions,
} from "../schema/index.js"
import { encodeJson } from "../utils/json.js"
import { sanitizeSurrogates } from "../utils/sanitize.js"

export type Execute = Interface["execute"]

/** The minimum a media request must carry for the route to build a transport request. */
export type MediaRequest = BaseRequest<{
  readonly id: string
  readonly provider: ProviderID
  readonly http?: HttpOptions
  readonly providerOptions?: ProviderOptions
}>

/** What every HTTP exchange of one generation shares. */
type Exchange = Pick<MediaRequest, "headers" | "http" | "fetch">

/** Deployment inputs every media model factory accepts; provider facades fill these from `configure(...)`. */
export interface ModelInput {
  readonly id: string
  readonly auth: Auth.Definition
  readonly baseURL?: string
  readonly headers?: Record<string, string>
  readonly http?: HttpOptions
  /** Defaults under each request's `providerOptions`. */
  readonly providerOptions?: ProviderOptions
}

/** A provider facade's `configure(...)` input as the `ModelInput` every media selector shares, minus the model id. */
export const deployment = (
  input: { readonly baseURL?: string; readonly headers?: Record<string, string>; readonly http?: HttpOptions },
  auth: Auth.Definition,
): Omit<ModelInput, "id"> => ({ auth, baseURL: input.baseURL, headers: input.headers, http: input.http })

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

/** One request, one response. */
export interface InlineRoute<Request extends MediaRequest, Response> {
  readonly kind: "inline"
  readonly id: string
  readonly provider: ProviderID
  readonly protocol: string
  readonly generate: (request: Request, execute: Execute) => Effect.Effect<Response, AIError>
}

/** Submit, then poll through the returned `Generation`. */
export interface QueuedRoute<Request extends MediaRequest, Response> {
  readonly kind: "queued"
  readonly id: string
  readonly provider: ProviderID
  readonly protocol: string
  readonly start: (request: Request, execute: Execute) => Effect.Effect<Generation<Response>, AIError>
  /** Rebuild a handle from a persisted `Generation.token`; fails typed when the token is not this route's. */
  readonly resume: (
    model: MediaRequest["model"],
    token: unknown,
    execute: Execute,
  ) => Effect.Effect<Generation<Response>, AIError>
}

/** One request whose response parses into events; `generate` runs the same stream and collects it. */
export interface StreamRoute<Request extends MediaRequest, Event, Response> {
  readonly kind: "stream"
  readonly id: string
  readonly provider: ProviderID
  readonly protocol: string
  readonly stream: (request: Request, execute: Execute) => Stream.Stream<Event, AIError>
  readonly generate: (request: Request, execute: Execute) => Effect.Effect<Response, AIError>
}

export type AnyRoute<Request extends MediaRequest, Event, Response> =
  | InlineRoute<Request, Response>
  | StreamRoute<Request, Event, Response>
  | QueuedRoute<Request, Response>

export interface Composition<Request extends MediaRequest> {
  readonly endpoint: Endpoint.Definition<MediaProtocol.Body, Request>
  readonly auth: Auth.Definition
  /** Deployment headers applied before transport authentication. */
  readonly headers?: Record<string, string>
}

export interface InlineInput<Request extends MediaRequest, Response> extends Composition<Request> {
  readonly protocol: MediaProtocol.Inline<Request, Response>
}

export interface QueuedInput<Request extends MediaRequest, Response, Token> extends Composition<Request> {
  readonly protocol: MediaProtocol.Queued<Request, Response, Token>
}

export interface StreamInput<Request extends MediaRequest, Event, Response, Frame, State>
  extends Composition<MediaProtocol.Addressed<Request>> {
  readonly protocol: MediaProtocol.Streamed<Request, Event, Frame, State>
  readonly collect: (events: ReadonlyArray<Event>) => Effect.Effect<Response, AIError>
}

/**
 * Compose an inline media protocol with an endpoint and auth into a runnable route. The route owns the transport
 * plumbing every media protocol would otherwise duplicate: option merging, surrogate sanitizing, unsupported-field
 * rejection, URL and query rendering, auth headers, JSON, multipart, or binary encoding, and handing responses back
 * to the protocol.
 */
export const inline = <Request extends MediaRequest, Response>(
  input: InlineInput<Request, Response>,
): InlineRoute<Request, Response> => {
  const transport = makeTransport(input)
  return {
    kind: "inline",
    id: input.protocol.id,
    provider: input.protocol.provider,
    protocol: input.protocol.id,
    generate: Effect.fn(`MediaRoute.generate`)(function* (request: Request, execute: Execute) {
      const submitted = yield* transport.submit(
        request,
        { unsupported: input.protocol.unsupported, from: input.protocol.body.from },
        execute,
      )
      return yield* input.protocol.response.decode(submitted.response, submitted.context)
    }),
  }
}

const READ_RETRY_MAX_DELAY = Duration.seconds(30)

/**
 * Status and result reads retry transient failures; `start` and `cancel` never do. Gaps grow exponentially from 1s,
 * jittered, up to 30s each, for at most 8 retries (about two minutes when every attempt fails), so a direct
 * `Generation.result()` stays bounded; `await` and `events` also cut retries off at `poll.timeout`. A provider
 * `retryAfterMs` raises the gap, still capped at 30s.
 */
const READ_RETRY = Schedule.max([
  Schedule.min([Schedule.exponential("1 second"), Schedule.spaced(READ_RETRY_MAX_DELAY)]),
  Schedule.recurs(8),
]).pipe(
  Schedule.jittered,
  Schedule.setInputType<AIError>(),
  Schedule.modifyDelay(({ input, duration }) =>
    Effect.succeed(
      Duration.min(
        input.reason._tag === "RateLimit" || input.reason._tag === "ProviderInternal"
          ? Duration.max(duration, Duration.millis(input.reason.retryAfterMs ?? 0))
          : duration,
        READ_RETRY_MAX_DELAY,
      ),
    ),
  ),
)

/**
 * Compose a queued media protocol the same way, adding `start`/`resume` handles whose polls reuse the route's auth,
 * deployment headers, and (for `start`) the request's `http` overlay. The token is decoded once at the boundary and
 * closed over by the resulting `Generation.Route`.
 */
export const queued = <Request extends MediaRequest, Response, Token>(
  input: QueuedInput<Request, Response, Token>,
): QueuedRoute<Request, Response> => {
  const transport = makeTransport(input)
  const protocol = input.protocol
  const decodeToken = Schema.decodeUnknownEffect(protocol.token)
  // A protocol producing a token its own codec rejects is a programmer defect, not a provider error.
  const encodeToken = Schema.encodeSync(protocol.token)

  const generationRoute = (token: Token, exchange: Exchange, execute: Execute) => {
    // Only the GET exchange retries: a decoded terminal failure (`output.ended`) can be a `ProviderInternal` too, and
    // re-reading it would spin until the caller's deadline.
    const poll = <A>(operation: {
      readonly path: (token: Token) => string
      readonly decode: (
        response: HttpClientResponse.HttpClientResponse,
        context: MediaProtocol.PollContext<Token>,
      ) => Effect.Effect<A, AIError>
    }) =>
      transport.call("GET", operation.path(token), exchange, execute).pipe(
        Effect.retry({ schedule: READ_RETRY, while: isRetryable }),
        Effect.flatMap((sent) => operation.decode(sent.response, { token, auth: sent.auth })),
      )
    const status = poll(protocol.status)
    const cancel = protocol.cancel
    const send =
      cancel === undefined
        ? undefined
        : transport.call(cancel.method, cancel.path(token), exchange, execute).pipe(Effect.asVoid)
    return {
      status,
      result: poll(protocol.result),
      cancel:
        send !== undefined && cancel?.activeOnly
          ? status.pipe(Effect.flatMap((snapshot) => (isTerminal(snapshot.status) ? Effect.void : send)))
          : send,
    }
  }

  const start = Effect.fn("MediaRoute.start")(function* (request: Request, execute: Execute) {
    const submitted = yield* transport.submit(
      request,
      { unsupported: protocol.unsupported, prepare: protocol.start.prepare, from: protocol.start.body.from },
      execute,
    )
    const started = yield* protocol.start.decode(submitted.response, submitted.context)
    const route = generationRoute(started.token, submitted.exchange, execute)
    return new Generation(route, encodeToken(started.token), started.snapshot)
  })

  const resume = Effect.fn("MediaRoute.resume")(function* (
    model: MediaRequest["model"],
    raw: unknown,
    execute: Execute,
  ) {
    const token = yield* decodeToken(raw).pipe(
      Effect.mapError(
        (cause) =>
          new AIError({
            reason: new InvalidRequestError({
              message: `${protocol.id} cannot resume a generation from this token`,
              cause,
            }),
          }),
      ),
    )
    const route = generationRoute(token, transport.exchange(model), execute)
    return new Generation(route, encodeToken(token), yield* route.status)
  })

  return { kind: "queued", id: protocol.id, provider: protocol.provider, protocol: protocol.id, start, resume }
}

/** Compose a streaming media protocol; `generate` runs the same stream in `generate` mode and folds it with `collect`. */
export const stream = <Request extends MediaRequest, Event, Response, Frame, State>(
  input: StreamInput<Request, Event, Response, Frame, State>,
): StreamRoute<Request, Event, Response> => {
  const transport = makeTransport(input)
  const protocol = input.protocol
  const events = (request: Request, execute: Execute, mode: MediaProtocol.Mode) =>
    Stream.unwrap(
      Effect.gen(function* () {
        const submitted = yield* transport.submit(
          { ...request, mode },
          { unsupported: protocol.unsupported, from: protocol.body.from },
          execute,
        )
        const http = RequestExecutor.responseHttp(submitted.response)
        return Stream.suspend(() => {
          // Parser state is local to one response, exactly like `Route.make`'s LLM stream loop.
          let state = protocol.initial()
          return protocol.frames(RequestExecutor.responseStream(submitted.response), submitted.context).pipe(
            Stream.mapEffect((frame) =>
              protocol.step(state, frame).pipe(
                Effect.map(([next, output]) => {
                  state = next
                  return output
                }),
              ),
            ),
            Stream.flattenIterable,
            Stream.concat(
              Stream.suspend(() => Stream.fromIterableEffect(protocol.finish(state, { ...submitted.context, http }))),
            ),
            Stream.mapError((error) =>
              error.reason.http !== undefined
                ? error
                : new AIError({
                    reason: AIErrorReason.make({
                      ...error.reason,
                      message: error.reason.message,
                      cause: error.reason.cause,
                      http,
                    }),
                  }),
            ),
          )
        })
      }),
    )
  return {
    kind: "stream",
    id: protocol.id,
    provider: protocol.provider,
    protocol: protocol.id,
    stream: (request, execute) => events(request, execute, "stream"),
    generate: (request, execute) =>
      events(request, execute, "generate").pipe(Stream.runCollect, Effect.flatMap(input.collect)),
  }
}

// ---------------------------------------------------------------------------
// Transport plumbing shared by every kind
// ---------------------------------------------------------------------------

const makeTransport = <Request extends MediaRequest>(
  input: Composition<Request> & { readonly protocol: { readonly id: string; readonly provider: ProviderID } },
) => {
  const authorize = Auth.toEffect(input.auth)
  const baseURL = (path: string) => new URL(`${Endpoint.trimBaseUrl(input.endpoint.baseURL ?? "")}${path}`)
  /** `auth` is only what `Auth` added or changed, never untouched deployment headers. */
  const send = Effect.fn("MediaRoute.send")(function* (
    call: {
      readonly method: AuthInput["method"]
      readonly url: URL
      readonly headers: Headers.Headers
      readonly request: AuthInput["request"]
      readonly body?: MediaProtocol.Body
    },
    fetch: typeof globalThis.fetch | undefined,
    execute: Execute,
  ) {
    const encoded = encode(call.body, call.headers)
    const url = call.url.toString()
    const headers = yield* authorize({
      request: call.request,
      method: call.method,
      url,
      body: encoded.text,
      headers: encoded.headers,
    })
    const response = yield* execute(
      encoded.apply(HttpClientRequest.make(call.method)(url).pipe(HttpClientRequest.setHeaders(headers))),
      RequestExecutor.withFetch(fetch),
    )
    return {
      response,
      auth: Object.fromEntries(Object.entries(headers).filter(([key, value]) => encoded.headers[key] !== value)),
    }
  })
  return {
    /** Route and model overlays; `start` additionally merges the request's own. */
    exchange: (model: MediaRequest["model"]): Exchange => mergeTransport({ headers: input.headers, http: model.http }),
    /** POST the protocol body to the route endpoint. */
    submit: Effect.fn("MediaRoute.submit")(function* (
      request: Request,
      protocol: {
        readonly unsupported?: ReadonlyArray<keyof Request & string>
        readonly prepare?: MediaProtocol.Prepare<Request>
        readonly from: (request: Request) => Effect.Effect<MediaProtocol.Body, AIError>
      },
      execute: Execute,
    ) {
      yield* rejectUnsupported(input.protocol.id, input.protocol.provider, request, protocol.unsupported)
      const { headers: merged, http } = mergeTransport({ headers: input.headers, http: request.model.http }, request)
      const exchange = { headers: merged, http, fetch: request.fetch }
      const providerOptions = mergeProviderOptions(request.model.providerOptions, request.providerOptions)
      const headers = Headers.fromInput(merged)
      const prepared =
        protocol.prepare === undefined
          ? request
          : yield* protocol.prepare(request, (path, body) =>
              send({ method: "POST", url: baseURL(path), headers, request, body }, request.fetch, execute).pipe(
                Effect.map((sent) => sent.response),
              ),
            )
      // Sanitize after merging so model-level overlays are covered; the model value is restored, not sanitized.
      const resolved: Request = {
        ...sanitizeSurrogates({ ...prepared, headers: merged, http, providerOptions }),
        model: request.model,
      }
      const body = yield* protocol.from(resolved)
      const url = withQuery(
        withQuery(
          Endpoint.render(input.endpoint, { request: resolved, body }),
          body.type === "multipart" ? undefined : body.query,
        ),
        http?.query,
      )
      const sent = yield* send({ method: "POST", url, headers, request: resolved, body }, request.fetch, execute)
      return { response: sent.response, context: { request: resolved, body }, exchange }
    }),
    /** Bodiless follow-up call (status, result, cancel) with the same auth and headers as `submit`. */
    call: (method: AuthInput["method"], path: string, exchange: Exchange, execute: Execute) => {
      // Provider-issued absolute URLs are used as-is; everything else resolves against the base.
      const url = withQuery(/^https?:\/\//.test(path) ? new URL(path) : baseURL(path), exchange.http?.query)
      for (const [key, value] of Object.entries(input.endpoint.query ?? {})) url.searchParams.set(key, value)
      const headers = Headers.fromInput(exchange.headers)
      return send({ method, url, headers, request: { http: exchange.http } }, exchange.fetch, execute)
    },
  }
}

const withQuery = (url: URL, query: MediaProtocol.Query | undefined) => {
  for (const [key, value] of Object.entries(query ?? {})) {
    url.searchParams.delete(key)
    for (const item of typeof value === "string" ? [value] : value) url.searchParams.append(key, item)
  }
  return url
}

const encode = (body: MediaProtocol.Body | undefined, headers: Headers.Headers) => {
  if (body === undefined) return { text: "", headers, apply: (request: HttpClientRequest.HttpClientRequest) => request }
  if (body.type === "json") {
    const text = encodeJson(body.value)
    return { text, headers, apply: HttpClientRequest.bodyText(text, "application/json") }
  }
  if (body.type === "binary")
    return {
      text: `[${body.contentType}]`,
      headers,
      apply: HttpClientRequest.bodyUint8Array(body.value, body.contentType),
    }
  return {
    text: "[multipart/form-data]",
    // The HTTP client sets the multipart boundary; a caller-supplied content-type would corrupt it.
    headers: Headers.remove(headers, "content-type"),
    apply: HttpClientRequest.bodyFormData(body.value),
  }
}

/**
 * Common fields are never silently dropped: a present field the protocol declared unsupported fails typed. `false`
 * counts as present because some booleans mean something when false (video `audio`); protocols reject opt-in
 * booleans such as speech `timestamps` with `=== true` in `body.from` instead of listing them.
 */
const rejectUnsupported = <Request extends object>(
  route: string,
  provider: ProviderID,
  request: Request,
  unsupported: ReadonlyArray<keyof Request & string> | undefined,
): Effect.Effect<void, AIError> => {
  const present = (unsupported ?? []).filter((field) => {
    const value = request[field]
    return Array.isArray(value) ? value.length > 0 : value !== undefined
  })
  if (present.length === 0) return Effect.void
  return Effect.fail(
    new AIError({
      reason: new UnsupportedOperationError({
        operation: `media.${present[0]}`,
        provider,
        route,
        message: `${provider}/${route} does not support ${present.join(", ")}`,
      }),
    }),
  )
}

export * as MediaRoute from "./media.js"
