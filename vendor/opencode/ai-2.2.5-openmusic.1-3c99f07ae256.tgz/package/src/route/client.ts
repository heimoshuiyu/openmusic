import { Cause, Context, Effect, Layer, Option, Schema, Stream } from "effect"
import { Auth } from "./auth.js"
import { Endpoint, type EndpointPatch } from "./endpoint.js"
import { RequestExecutor } from "./executor.js"
import { Framing } from "./framing.js"
import { HttpTransport } from "./transport/index.js"
import type { HttpMiddleware, Transport, TransportRuntime, WebSocketChannelExecutor } from "./transport/index.js"
import type { Protocol } from "./protocol.js"
import { applyCachePolicy } from "../cache-policy.js"
import { applyEffortUpdates } from "../effort-updates.js"
import { normalizeToolHistory } from "../tool-history.js"
import { sanitizeSurrogates } from "../utils/sanitize.js"
import * as ProviderShared from "../protocols/shared.js"
import { ToolSchemaProjection } from "../protocols/utils/tool-schema.js"
import type { LanguageModelSanitizerCompatibility, ProtocolID, ProviderOptions } from "../schema/index.js"
import type { LLMRequestInput } from "../llm.js"
import {
  AIError,
  CompactionResponse,
  CompactionCheckpointResponse,
  AIErrorReason,
  LLMResponse,
  ResponseFold,
  LanguageModel,
  Message,
  LLMEvent,
  InvalidProviderOutputError,
  ProviderConfigurationError,
  ProviderID,
  ToolChoice,
  ToolEntry,
  type LLMRequest,
  mergeGeneration,
  mergeRequestOptions,
  mergeProviderOptions,
  mergeTransport,
  type RequestOptions,
  withPartial,
} from "../schema/index.js"

export interface RouteBody<Body> {
  /** Schema for the validated provider-native body sent as the JSON request. */
  readonly schema: Schema.Codec<Body, unknown>
  /** Build the provider-native body from a common `LLMRequest`. */
  readonly from: (request: LLMRequest) => Effect.Effect<Body, AIError>
}

export interface Route<
  Body,
  Prepared = unknown,
  Compact extends CompactionOperations | undefined = CompactionOperations | undefined,
> {
  readonly compact: Compact
  readonly id: string
  readonly provider?: ProviderID
  /** ProviderMetadata namespace emitted and consumed by this route. */
  readonly providerMetadataKey?: string
  readonly protocol: ProtocolID
  readonly endpoint: Endpoint.Definition<Body>
  readonly auth: Auth.Definition
  /** Deployment headers resolved once for every operation, before transport authentication. */
  readonly headers?: (input: { readonly request: LLMRequest }) => Record<string, string>
  readonly transport: Transport<Body, Prepared, unknown>
  /** Options every model built on this route starts from. */
  readonly options?: RequestOptions
  readonly body: RouteBody<Body>
  readonly supportsEffortUpdates?: (request: LLMRequest) => boolean
  readonly sanitizer?: LanguageModelSanitizerCompatibility
  readonly with: {
    <Next extends CompactionOperations | undefined>(
      patch: RoutePatch<Body, Prepared> & { readonly compact: Next },
    ): Route<Body, Prepared, Next>
    (
      patch: Omit<RoutePatch<Body, Prepared>, "compact"> & { readonly compact?: undefined },
    ): Route<Body, Prepared, Compact>
    (patch: RoutePatch<Body, Prepared>): Route<Body, Prepared>
  }
  readonly model: <Options extends ProviderOptions = ProviderOptions>(
    input: RouteMappedLanguageModelInput,
  ) => LanguageModel<Options, Compact>
  readonly prepareTransport: (
    body: Body,
    request: LLMRequest,
    options?: StreamOptions,
  ) => Effect.Effect<Prepared, AIError>
  readonly streamPrepared: (
    prepared: Prepared,
    request: LLMRequest,
    runtime: TransportRuntime,
    options?: StreamOptions,
  ) => Stream.Stream<LLMEvent, AIError>
}

// Route registries intentionally erase body generics after construction.
// Normal call sites use `OpenAIChat.route`; callers only need body types
// when preparing a request with a protocol-specific type assertion.
// oxlint-disable-next-line typescript-eslint/no-explicit-any
export type AnyRoute<Compact extends CompactionOperations | undefined = CompactionOperations | undefined> = Route<
  any,
  any,
  Compact
>

export type RouteLanguageModelInput = Omit<LanguageModel.Input, "provider" | "route">

export type RouteRoutedLanguageModelInput = Omit<LanguageModel.Input, "route">

export interface RoutePatch<Body, Prepared> extends RequestOptions {
  readonly compact?: CompactionOperations
  readonly id?: string
  readonly provider?: string | ProviderID
  readonly providerMetadataKey?: string
  readonly auth?: Auth.Definition
  readonly transport?: Transport<Body, Prepared, unknown>
  readonly endpoint?: EndpointPatch<Body>
}

type RouteMappedLanguageModelInput = RouteLanguageModelInput | RouteRoutedLanguageModelInput

const makeRouteLanguageModel = <Options extends ProviderOptions, Compact extends CompactionOperations | undefined>(
  route: AnyRoute<Compact>,
  mapped: RouteMappedLanguageModelInput,
) => {
  const provider = route.provider ?? ("provider" in mapped ? mapped.provider : undefined)
  if (!provider) throw new Error(`Route.model(${route.id}) requires a provider`)
  if (!route.endpoint.baseURL)
    throw new ProviderConfigurationError({
      provider: ProviderID.make(provider),
      message: `Route.model(${route.id}) requires an endpoint baseURL — configure it on the route first`,
    })
  return LanguageModel.make<Options, Compact>({
    ...mapped,
    provider,
    route,
  })
}

export interface Interface {
  readonly compact: CompactMethod
  readonly stream: StreamMethod
  readonly generate: GenerateMethod
}

export interface StreamOptions {
  readonly http?: HttpMiddleware
  readonly webSocket?: WebSocketChannelExecutor
}

export interface StreamMethod {
  (request: LLMRequest, options?: StreamOptions): Stream.Stream<LLMEvent, AIError>
}

export interface GenerateMethod {
  (request: LLMRequest, options?: StreamOptions): Effect.Effect<LLMResponse, AIError>
}

export type CompactOperation = (
  request: LLMRequest,
  executor: RequestExecutor.Interface,
  options?: Pick<StreamOptions, "http">,
) => Effect.Effect<CompactionResponse, AIError>

export type TriggerCompactOperation = (
  request: LLMRequest,
  executor: RequestExecutor.Interface,
  options: TriggerCompactOptions,
) => Effect.Effect<CompactionCheckpointResponse, AIError>

/** Protocol capabilities, not deployment/model eligibility. */
export interface CompactionOperations {
  readonly endpoint?: CompactOperation
  readonly trigger?: TriggerCompactOperation
}

export interface EndpointCompactOptions extends Pick<StreamOptions, "http"> {
  readonly mechanism?: "endpoint"
  readonly webSocket?: never
}

export interface TriggerCompactOptions extends StreamOptions {
  readonly mechanism: "trigger"
}

type EndpointModel = LanguageModel<ProviderOptions, { readonly endpoint: CompactOperation }>
type TriggerModel = LanguageModel<ProviderOptions, { readonly trigger: TriggerCompactOperation }>

/** A text request whose model supports explicit compaction. */
export type CompactionRequest = LLMRequestInput & { readonly model: EndpointModel }
/** A text request whose model supports trigger compaction checkpoints. */
export type CheckpointRequest = LLMRequestInput & { readonly model: TriggerModel }

export interface CompactMethod<R = never> {
  (
    request: LLMRequest & { readonly model: TriggerModel },
    options: TriggerCompactOptions,
  ): Effect.Effect<CompactionCheckpointResponse, AIError, R>
  (
    request: LLMRequest & { readonly model: EndpointModel },
    options?: EndpointCompactOptions,
  ): Effect.Effect<CompactionResponse, AIError, R>
}

/** Whether a model, or a text request's model, supports compaction through the given mechanism. */
export function canCompact<Model extends LanguageModel>(
  model: Model,
  options: { readonly mechanism: "trigger" },
): model is Model & TriggerModel
export function canCompact<Request extends { readonly model: LanguageModel }>(
  request: Request,
  options: { readonly mechanism: "trigger" },
): request is Request & { readonly model: TriggerModel }
export function canCompact<Model extends LanguageModel>(
  model: Model,
  options?: { readonly mechanism?: "endpoint" },
): model is Model & EndpointModel
export function canCompact<Request extends { readonly model: LanguageModel }>(
  request: Request,
  options?: { readonly mechanism?: "endpoint" },
): request is Request & { readonly model: EndpointModel }
export function canCompact(
  target: LanguageModel | { readonly model: LanguageModel },
  options?: { readonly mechanism?: string },
) {
  const model = target instanceof LanguageModel ? target : target.model
  if (options?.mechanism === "trigger") return model.route.compact?.trigger !== undefined
  if (options?.mechanism !== undefined && options.mechanism !== "endpoint") return false
  return model.route.compact?.endpoint !== undefined
}

const unsupportedCompaction = (model: LanguageModel, mechanism: string | undefined) => {
  if (mechanism !== undefined && mechanism !== "endpoint" && mechanism !== "trigger")
    return ProviderShared.invalidRequest(`Unknown compaction mechanism: ${mechanism}`)
  return ProviderShared.unsupportedOperation({
    operation: mechanism === "trigger" ? "compact.trigger" : "compact",
    provider: model.provider,
    route: model.route.id,
    message: `${model.provider}/${model.route.id} does not support ${mechanism === "trigger" ? "trigger" : "explicit"} compaction`,
  })
}

export class LLMClientService extends Context.Service<LLMClientService, Interface>()("@opencode/LLMClient") {}
export const Service = LLMClientService
export type Service = LLMClientService

const resolveRequestOptions = (request: LLMRequest): LLMRequest => {
  const messages = normalizeToolHistory(request.messages)
  const normalized = messages === request.messages ? request : { ...request, messages }
  const options = normalized.model.options
  return {
    ...normalized,
    ...mergeGeneration(options, normalized),
    providerOptions: mergeProviderOptions(options?.providerOptions, normalized.providerOptions),
    ...mergeTransport(options, normalized),
  }
}

export interface MakeInput<Body, Frame, Event, State> {
  readonly compact?: CompactionOperations
  /** Route id used in diagnostics and prepared request metadata. */
  readonly id: string
  /** Provider identity for route-owned model construction. */
  readonly provider?: string | ProviderID
  /** ProviderMetadata namespace emitted and consumed by this route. */
  readonly providerMetadataKey?: string
  /** Semantic API contract — owns body construction, body schema, and parsing. */
  readonly protocol: Protocol<Body, Frame, Event, State>
  /** Where the request is sent. */
  readonly endpoint: Endpoint.Definition<Body>
  /** Per-request transport auth. Provider facades override this via `route.with(...)`. */
  readonly auth?: Auth.Definition
  /** Stream framing — bytes -> frames before `protocol.stream.event` decoding. */
  readonly framing: Framing.Definition<Frame>
  /** Static / per-request headers added before `auth` runs. */
  readonly headers?: (input: { readonly request: LLMRequest }) => Record<string, string>
  /** Options every model built on this route starts from. */
  readonly options?: RequestOptions
}

export interface MakeTransportInput<Body, Prepared, Frame, Event, State> {
  readonly compact?: CompactionOperations
  /** Route id used in diagnostics and prepared request metadata. */
  readonly id: string
  /** Provider identity for route-owned model construction. */
  readonly provider?: string | ProviderID
  /** ProviderMetadata namespace emitted and consumed by this route. */
  readonly providerMetadataKey?: string
  /** Semantic API contract — owns body construction, body schema, and parsing. */
  readonly protocol: Protocol<Body, Frame, Event, State>
  /** Where the request is sent. */
  readonly endpoint: Endpoint.Definition<Body>
  /** Per-request transport auth. Provider facades override this via `route.with(...)`. */
  readonly auth?: Auth.Definition
  /** Static / per-request headers added before `auth` runs. */
  readonly headers?: (input: { readonly request: LLMRequest }) => Record<string, string>
  /** Runnable transport route. */
  readonly transport: Transport<Body, Prepared, Frame>
  /** Options every model built on this route starts from. */
  readonly options?: RequestOptions
}

const streamError = (route: string, message: string, cause: Cause.Cause<unknown>) => {
  const failed = cause.reasons.find(Cause.isFailReason)?.error
  if (failed instanceof AIError) return failed
  return ProviderShared.eventError(route, message, undefined, cause)
}

const incompleteStreamError = (route: string) =>
  new AIError({
    reason: new InvalidProviderOutputError({
      message: "The provider response ended unexpectedly.",
      classification: "incomplete-stream",
      route,
    }),
  })

const requireTerminalEvent = (route: string) => (events: Stream.Stream<LLMEvent, AIError>) =>
  Stream.suspend(() => {
    let terminal = false
    return events.pipe(
      Stream.mapEffect((event) => {
        // Raw events carry provider frames that may trail the terminal event.
        if (terminal && !LLMEvent.is.raw(event))
          return Effect.fail(
            ProviderShared.eventError(route, `Provider emitted ${event.type} after the terminal event`),
          )
        if (LLMEvent.is.finish(event)) terminal = true
        return Effect.succeed(event)
      }),
      Stream.onEnd(Effect.suspend(() => (terminal ? Effect.void : Effect.fail(incompleteStreamError(route))))),
    )
  })

const decodeJsonOption = Schema.decodeUnknownOption(ProviderShared.Json)

// JSON text frames are parsed; non-JSON sentinels such as `[DONE]` stay strings.
const rawFrame = (frame: unknown) =>
  typeof frame === "string" ? Option.getOrElse(decodeJsonOption(frame), () => frame) : frame

// Transports may interleave their own marker objects with provider frames, e.g. Gemini's continuation boundary.
const isProviderFrame = (frame: unknown) =>
  typeof frame !== "object" ||
  frame === null ||
  Array.isArray(frame) ||
  Object.getPrototypeOf(frame) === Object.prototype

function makeFromTransport<Body, Prepared, Frame, Event, State>(
  input: MakeTransportInput<Body, Prepared, Frame, Event, State>,
): Route<Body, Prepared> {
  const protocol = input.protocol
  const decodeEventEffect = Schema.decodeUnknownEffect(protocol.stream.event)
  const decodeEvent = (route: string) => (frame: Frame) =>
    decodeEventEffect(frame).pipe(
      Effect.mapError((cause) =>
        ProviderShared.eventError(
          input.id,
          `Invalid ${route} stream event`,
          typeof frame === "string" ? frame : ProviderShared.encodeJson(frame),
          cause,
        ),
      ),
    )

  type BuiltRouteInput = MakeTransportInput<Body, Prepared, Frame, Event, State>

  const build = (routeInput: BuiltRouteInput): Route<Body, Prepared> => {
    const route: Route<Body, Prepared> = {
      compact: routeInput.compact,
      id: routeInput.id,
      provider: routeInput.provider === undefined ? undefined : ProviderID.make(routeInput.provider),
      providerMetadataKey: routeInput.providerMetadataKey,
      protocol: protocol.id,
      endpoint: routeInput.endpoint,
      auth: routeInput.auth ?? Auth.none,
      headers: routeInput.headers,
      transport: routeInput.transport,
      options: routeInput.options,
      body: protocol.body,
      supportsEffortUpdates: protocol.supportsEffortUpdates,
      sanitizer: protocol.sanitizer,
      with: (patch: RoutePatch<Body, Prepared>) => {
        const { compact, id, provider, providerMetadataKey, auth, transport, endpoint, ...options } = patch
        return build({
          ...routeInput,
          compact: "compact" in patch ? compact : routeInput.compact,
          id: id ?? routeInput.id,
          provider: provider ?? routeInput.provider,
          providerMetadataKey:
            providerMetadataKey ??
            (provider !== undefined && provider !== routeInput.provider ? provider : routeInput.providerMetadataKey),
          auth: auth ?? routeInput.auth,
          endpoint: endpoint ? Endpoint.merge(routeInput.endpoint, endpoint) : routeInput.endpoint,
          transport: (transport as Transport<Body, Prepared, Frame> | undefined) ?? routeInput.transport,
          options: mergeRequestOptions(route.options, options),
        })
      },
      model: <Options extends ProviderOptions = ProviderOptions>(input: RouteMappedLanguageModelInput) =>
        makeRouteLanguageModel<Options, CompactionOperations | undefined>(route, input),
      prepareTransport: (body, request, options) =>
        routeInput.transport.prepare({
          body,
          request,
          endpoint: routeInput.endpoint,
          auth: routeInput.auth ?? Auth.none,
          encodeBody: ProviderShared.encodeJson,
          middleware: RequestExecutor.withFetch(request.fetch, options?.http),
          webSocket: options?.webSocket,
        }),
      streamPrepared: (prepared: Prepared, request: LLMRequest, runtime: TransportRuntime, options?: StreamOptions) => {
        const route = `${request.model.provider}/${request.model.route.id}`
        return Stream.unwrap(
          routeInput.transport.execute(prepared, request, runtime, options).pipe(
            Effect.map((execution) => {
              const terminal = protocol.stream.terminal
              // Preserve assembled inputs; replace only serialized event fallbacks with their original wire data.
              const frameError =
                (frame: Frame, event: Frame | Event = frame) =>
                (error: AIError) =>
                  new AIError({
                    reason: AIErrorReason.make({
                      ...error.reason,
                      message: error.reason.message,
                      cause: error.reason.cause,
                      body:
                        error.reason.body !== undefined && error.reason.body !== ProviderShared.encodeJson(event)
                          ? error.reason.body
                          : (execution.body?.(frame) ??
                            (typeof frame === "string" ? frame : ProviderShared.encodeJson(frame))),
                    }),
                  })
              const events = execution.frames.pipe(
                Stream.mapEffect((frame) =>
                  decodeEvent(route)(frame).pipe(
                    Effect.catchCause((cause) =>
                      Effect.fail(streamError(route, `Failed to decode ${route} event`, cause)),
                    ),
                    Effect.map((event) => ({ event, frame })),
                    Effect.mapError(frameError(frame)),
                  ),
                ),
                terminal ? Stream.takeUntil(({ event }) => terminal(event)) : (stream) => stream,
              )
              const stream = Stream.suspend(() => {
                let state = protocol.stream.initial(request)
                const parsed = events.pipe(
                  Stream.mapEffect(({ event, frame }) =>
                    protocol.stream.step(state, event).pipe(
                      Effect.catchCause((cause) =>
                        Effect.fail(streamError(route, `Failed to parse ${route} event`, cause)),
                      ),
                      Effect.map(([next, output]) => {
                        state = next
                        return request.includeRaw && isProviderFrame(frame)
                          ? [LLMEvent.raw({ data: execution.raw?.(frame) ?? rawFrame(frame) }), ...output]
                          : output
                      }),
                      Effect.mapError(frameError(frame, event)),
                    ),
                  ),
                  Stream.flatMap(Stream.fromIterable),
                )
                const onHalt = protocol.stream.onHalt
                return onHalt
                  ? parsed.pipe(
                      Stream.concat(
                        Stream.suspend(() => Stream.unwrap(onHalt(state).pipe(Effect.map(Stream.fromIterable)))),
                      ),
                    )
                  : parsed
              }).pipe(
                Stream.catchCause((cause) => Stream.fail(streamError(route, `Failed to read ${route} stream`, cause))),
                requireTerminalEvent(route),
                Stream.mapError(
                  (error) =>
                    new AIError({
                      reason: AIErrorReason.make({
                        ...error.reason,
                        message: error.reason.message,
                        cause: error.reason.cause,
                        http: error.reason.http ?? execution.http,
                      }),
                    }),
                ),
              )
              return execution.complete ? stream.pipe(Stream.onEnd(execution.complete)) : stream
            }),
          ),
        )
      },
    } satisfies Route<Body, Prepared>
    return route
  }

  return build({ ...input, options: mergeRequestOptions(input.options) })
}

export function make<Body, Prepared, Frame, Event, State, Compact extends CompactionOperations>(
  input: MakeTransportInput<Body, Prepared, Frame, Event, State> & { readonly compact: Compact },
): Route<Body, Prepared, Compact>
export function make<Body, Frame, Event, State, Compact extends CompactionOperations>(
  input: MakeInput<Body, Frame, Event, State> & { readonly compact: Compact },
): Route<Body, HttpTransport.HttpPrepared<Frame>, Compact>
export function make<Body, Prepared, Frame, Event, State>(
  input: MakeTransportInput<Body, Prepared, Frame, Event, State>,
): Route<Body, Prepared>
/**
 * Build a `Route` by composing the four orthogonal pieces of a deployment:
 *
 * - `Protocol` — what is the API I'm speaking?
 * - `Endpoint` — where do I send the request?
 * - `Auth` — how do I authenticate it?
 * - `Framing` — how do I cut the response stream into protocol frames?
 *
 * Plus optional `headers` for cross-cutting deployment concerns (provider
 * version pins, per-deployment quirks).
 *
 * This is the canonical route constructor. If a new route does not fit
 * this four-axis model, add a purpose-built constructor rather than widening
 * the public surface preemptively.
 */
export function make<Body, Frame, Event, State>(
  input: MakeInput<Body, Frame, Event, State>,
): Route<Body, HttpTransport.HttpPrepared<Frame>>
export function make<Body, Prepared, Frame, Event, State>(
  input: MakeInput<Body, Frame, Event, State> | MakeTransportInput<Body, Prepared, Frame, Event, State>,
): Route<Body, Prepared> | Route<Body, HttpTransport.HttpPrepared<Frame>> {
  if ("transport" in input) return makeFromTransport(input)
  const protocol = input.protocol
  return makeFromTransport({
    compact: input.compact,
    id: input.id,
    provider: input.provider,
    providerMetadataKey: input.providerMetadataKey,
    protocol,
    endpoint: input.endpoint,
    auth: input.auth,
    headers: input.headers,
    transport: HttpTransport.httpJson({ framing: input.framing }),
    options: input.options,
  })
}

const prepareRequest = (request: LLMRequest): LLMRequest => {
  const original = resolveRequestOptions(request)
  const sanitized = restoreClasses({ ...sanitizeSurrogates({ ...original, model: undefined }), model: original.model })
  // Deduplicate per sibling level; a tool and a namespace may share a name.
  const dedupe = (tools: LLMRequest["tools"]): LLMRequest["tools"] =>
    [...new Map(tools.map((tool) => [`${tool.type}:${tool.name}`, tool])).values()].map((tool) =>
      tool.type === "tool" ? tool : { ...tool, tools: dedupe(tool.tools) },
    )
  const resolved = applyCachePolicy(
    applyEffortUpdates({ ...sanitized, tools: ToolSchemaProjection.tools(dedupe(sanitized.tools), sanitized.model) }),
  )
  const headers = resolved.model.route.headers?.({ request: resolved })
  return headers === undefined ? resolved : { ...resolved, headers: { ...headers, ...resolved.headers } }
}

// Sanitizing copies changed class instances into plain records; rebuild them so protocols see the canonical classes.
const restoreClasses = (request: LLMRequest): LLMRequest => ({
  ...request,
  messages: request.messages.map(Message.make),
  tools: request.tools.map(ToolEntry.make),
  toolChoice: request.toolChoice === undefined ? undefined : ToolChoice.make(request.toolChoice),
})

const compile = Effect.fn("LLM.compile")(function* (request: LLMRequest, options?: StreamOptions) {
  const references = request.messages.flatMap((message) =>
    message.content.flatMap((part) => {
      if (part.type === "media") {
        const source = part.media.source
        return source.type === "url" ? [source.url] : source.type === "ref" ? [source.id] : []
      }
      if (part.type !== "tool-result" || part.result.type !== "content") return []
      return part.result.value.flatMap((item) => (item.type === "file" ? [item.uri] : []))
    }),
  )
  if (references.some((reference) => /^\s*file:/i.test(reference)))
    return yield* ProviderShared.invalidRequest(
      "Local file references must be read with Media.file(path) before sending",
    )
  const resolved = prepareRequest(request)
  const route = resolved.model.route

  const body = yield* route.body.from(resolved)
  const prepared = yield* route.prepareTransport(body, resolved, options)

  return {
    request: resolved,
    route,
    body,
    prepared,
  }
})

/** Test-only projection of the execution compiler; exported from `@opencode/ai/testing`. */
export const compileRequest = Effect.fn("LLM.compileRequest")(function* (request: LLMRequest) {
  const compiled = yield* compile(request)
  return {
    id: compiled.request.id ?? "request",
    route: compiled.route.id,
    protocol: compiled.route.protocol,
    model: compiled.request.model,
    body: compiled.body,
    metadata: { transport: compiled.route.transport.id },
  }
})

const streamRequestWith = (runtime: TransportRuntime) => (request: LLMRequest, options?: StreamOptions) =>
  Stream.unwrap(
    Effect.gen(function* () {
      const compiled = yield* compile(request, options)
      return compiled.route.streamPrepared(compiled.prepared, compiled.request, runtime, options)
    }),
  )

export const generateWith = (stream: Interface["stream"]) =>
  Effect.fn("LLM.generate")(function* (request: LLMRequest, options?: StreamOptions) {
    let state = ResponseFold.empty()
    yield* stream(request, options).pipe(
      Stream.runForEach((event) => Effect.sync(() => (state = ResponseFold.reduce(state, event)))),
      Effect.mapError((error) => withPartial(error, ResponseFold.partial(state))),
    )
    const response = ResponseFold.complete(state)
    if (response) return response
    return yield* withPartial(
      incompleteStreamError(`${request.model.provider}/${request.model.route.id}`),
      ResponseFold.partial(state),
    )
  })

export function stream(request: LLMRequest, options?: StreamOptions): Stream.Stream<LLMEvent, AIError, Service> {
  return Stream.unwrap(
    Effect.gen(function* () {
      return (yield* Service).stream(request, options)
    }),
  )
}

export function generate(request: LLMRequest, options?: StreamOptions): Effect.Effect<LLMResponse, AIError, Service> {
  return Effect.gen(function* () {
    return yield* (yield* Service).generate(request, options)
  })
}

/** Compact through the client for `options.mechanism`, failing typed when the request's route does not support it. */
export function compactRequest(
  request: LLMRequest,
  options?: EndpointCompactOptions | TriggerCompactOptions,
): Effect.Effect<CompactionResponse | CompactionCheckpointResponse, AIError, Service> {
  return Effect.gen(function* () {
    const client = yield* Service
    if (options?.mechanism === "trigger" && canCompact(request, options)) return yield* client.compact(request, options)
    if ((options?.mechanism === undefined || options.mechanism === "endpoint") && canCompact(request))
      return yield* client.compact(request, options)
    return yield* unsupportedCompaction(request.model, options?.mechanism)
  })
}

export const layer: Layer.Layer<Service, never, RequestExecutor.Service> = Layer.effect(
  Service,
  Effect.gen(function* () {
    const executor = yield* RequestExecutor.Service
    const stream = streamRequestWith({ http: executor })
    function compact(
      request: LLMRequest & { readonly model: TriggerModel },
      options: TriggerCompactOptions,
    ): Effect.Effect<CompactionCheckpointResponse, AIError>
    function compact(
      request: LLMRequest & { readonly model: EndpointModel },
      options?: EndpointCompactOptions,
    ): Effect.Effect<CompactionResponse, AIError>
    function compact(request: LLMRequest, options?: EndpointCompactOptions | TriggerCompactOptions) {
      return Effect.suspend((): Effect.Effect<CompactionResponse | CompactionCheckpointResponse, AIError> => {
        if (options?.mechanism === "trigger" && canCompact(request, options))
          return request.model.route.compact.trigger(prepareRequest(request), executor, options)
        if ((options?.mechanism === undefined || options.mechanism === "endpoint") && canCompact(request))
          return request.model.route.compact.endpoint(prepareRequest(request), executor, options)
        return unsupportedCompaction(request.model, options?.mechanism)
      })
    }
    return Service.of({
      stream,
      generate: generateWith(stream),
      compact,
    })
  }),
)

export const Route = { make } as const

export const LLMClient = {
  Service,
  layer,
  stream,
  generate,
} as const
