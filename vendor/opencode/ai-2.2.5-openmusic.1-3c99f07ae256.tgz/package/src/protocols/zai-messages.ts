import { Effect, Schema } from "effect"
import { Protocol } from "../route/protocol.js"
import type { LLMRequest } from "../schema/index.js"
import { AnthropicMessages } from "./anthropic-messages.js"
import { ProviderShared } from "./shared.js"
import { OpenResponsesOptions } from "./utils/open-responses-options.js"

const Options = Schema.Struct({
  effort: Schema.optional(OpenResponsesOptions.ReasoningEffort),
  thinking: Schema.optional(Schema.Struct({ type: ProviderShared.knownString<"enabled" | "adaptive" | "disabled">() })),
})
export type OptionsInput = typeof Options.Type
const Body = Schema.Struct({
  ...AnthropicMessages.AnthropicMessagesBody.fields,
  thinking: Options.fields.thinking,
})

const fromRequest = Effect.fn("ZAIMessages.fromRequest")(function* (request: LLMRequest) {
  const options = yield* ProviderShared.validateWith(Schema.decodeUnknownEffect(Options))(request.providerOptions ?? {})
  // Z.AI accepts enabled thinking without Anthropic's mandatory token budget.
  const body = yield* AnthropicMessages.protocol.body.from({
    ...request,
    providerOptions: { ...request.providerOptions, thinking: undefined },
  })
  return { ...body, thinking: options.thinking }
})

export const protocol = Protocol.make({
  id: "zai-messages",
  body: { schema: Body, from: fromRequest },
  stream: AnthropicMessages.protocol.stream,
})

export * as ZAIMessages from "./zai-messages.js"
