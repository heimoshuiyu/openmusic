import { Effect } from "effect";
import { HttpClient } from "effect/http";
import type { Plan } from "./types.js";
export declare const invoke: (plan: Plan, input: unknown) => Effect.Effect<unknown, unknown, HttpClient.HttpClient>;
