import type { Options, Result } from "./types.js";
export type { AuthResolver, Credential, Document, Operation, Options, Result, SecurityScheme, Skipped, Tools, } from "./types.js";
/**
 * Builds one CodeMode tool per representable OpenAPI 3.x operation. Auth remains host-side,
 * tools require `HttpClient.HttpClient`, and unrepresentable operations land in `skipped`.
 */
export declare const fromSpec: (options: Options) => Result;
