import type { Tools } from "./tools.js";
/** A tool namespace with optional model-visible metadata. */
export type Namespace<R = never> = {
    readonly _tag: "CodeModeNamespace";
    readonly description?: string;
    readonly tools: Tools<R>;
};
/** Options for declaring one CodeMode namespace. */
export type Options<R = never> = {
    readonly description?: string;
    readonly tools: Tools<R>;
};
export declare const isNamespace: <R = never>(value: Namespace<R> | Tools<R>) => value is Namespace<R>;
/** Declares a namespace when descriptions or other namespace metadata are needed. */
export declare const make: <R = never>(options: Options<R>) => Namespace<R>;
