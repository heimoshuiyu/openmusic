import { Effect } from "effect";
import type { Json } from "./data.js";
import type { DiagnosticKind } from "./codemode.js";
import { type Namespace } from "./namespace.js";
import { type Durable, type Idempotent, type Tool, type ToolContext } from "./tool.js";
import type { Tools } from "./tools.js";
export declare const compareText: (left: string, right: string) => -1 | 0 | 1;
export type Services<T> = ServicesOf<T, []>;
type ServicesOf<T, Depth extends ReadonlyArray<unknown>> = Depth["length"] extends 8 ? never : T extends {
    readonly _tag: "CodeModeTool";
    readonly execute: (input: unknown, context?: ToolContext) => Effect.Effect<unknown, unknown, infer R>;
} ? R : T extends object ? string extends keyof T ? ServicesOf<T[string], [...Depth, unknown]> : ServicesOf<T[keyof T], [...Depth, unknown]> : never;
export type ToolCall = {
    readonly name: string;
};
/** A tool call the program is making, with its decoded input. */
export type ToolInvocation = {
    readonly name: string;
    readonly input: unknown;
    /** The call's idempotency key, `<runId>:<callId>`: the same at every hook, and across a suspended run's resumes. */
    readonly key: string;
};
/**
 * A call the program is making to an extension global or module function, with its arguments. A module function is
 * named by its path from the module, such as `fs.readFile`.
 */
export type ExtensionInvocation = {
    readonly extension: string;
    readonly name: string;
    readonly args: ReadonlyArray<unknown>;
};
/** How a call ended; `after` hooks observe it and cannot change it. */
export type CallResult = {
    readonly status: "success";
    readonly value: unknown;
} | {
    readonly status: "failure";
    readonly error: unknown;
} | {
    readonly status: "interrupted";
};
/** Hooks around every call the program makes into the host. A failing `before` denies the call. */
export type Hooks<R = never> = {
    readonly "tool.before"?: ((call: ToolInvocation) => Effect.Effect<void, unknown, R>) | undefined;
    readonly "tool.after"?: ((call: ToolInvocation, result: CallResult) => Effect.Effect<void, never, R>) | undefined;
    readonly "extension.before"?: ((call: ExtensionInvocation) => Effect.Effect<void, unknown, R>) | undefined;
    readonly "extension.after"?: ((call: ExtensionInvocation, result: CallResult) => Effect.Effect<void, never, R>) | undefined;
};
/** Runs `before`, then `run`, then `after` with how it ended, including when interrupted (unless `detaching`). */
export declare const hooked: <Call, A, R>(call: Call, before: ((call: Call) => Effect.Effect<void, unknown, R>) | undefined, after: ((call: Call, result: CallResult) => Effect.Effect<void, never, R>) | undefined, run: Effect.Effect<A, unknown, R>, detaching?: () => boolean) => Effect.Effect<A, unknown, R>;
export type ToolDescription = {
    readonly path: string;
    readonly description: string;
    readonly signature: string;
};
export declare const toolExpression: (path: string) => string;
export declare class ToolReference {
    readonly path: ReadonlyArray<string>;
    constructor(path: ReadonlyArray<string>);
}
type ToolNode<R> = {
    tool?: Tool<R>;
    namespace?: Namespace<R>;
    readonly children: Map<string, ToolNode<R>>;
};
/** Tools indexed once per runtime, with discovery materialized on demand. */
export type Prepared<R = never> = {
    readonly root: ToolNode<R>;
    readonly catalog: ReadonlyArray<ToolDescription>;
    readonly searchIndex: ReadonlyArray<SearchEntry>;
};
export type SearchEntry = {
    readonly description: ToolDescription;
    /** The path split into words, so `zones` matches `get_zones` as a word rather than as a substring of `timezones`. */
    readonly pathWords: ReadonlyArray<string>;
    readonly searchText: string;
};
/** Exact callable signature of the built-in `search` function, for host-owned instructions. */
export declare const searchSignature: string;
export declare const prepare: <R>(tools: Tools<R>) => Prepared<R>;
export declare class ToolRuntimeError extends Error {
    readonly kind: Extract<DiagnosticKind, "UnknownTool" | "InvalidToolInput" | "InvalidToolOutput" | "ToolCallLimitExceeded">;
    readonly suggestions: ReadonlyArray<string>;
    constructor(kind: Extract<DiagnosticKind, "UnknownTool" | "InvalidToolInput" | "InvalidToolOutput" | "ToolCallLimitExceeded">, message: string, suggestions?: ReadonlyArray<string>);
}
export type ExecuteCallOptions = {
    readonly key?: string | undefined;
    readonly admit?: ((name: string) => void) | undefined;
    readonly detaching?: (() => boolean) | undefined;
};
/** The tool bridge of one execution. Arguments arrive and results leave as JSON; program values never enter. */
export type ToolRuntime<R = never> = {
    readonly calls: Array<ToolCall>;
    readonly hooks: Hooks<R>;
    readonly invocations: Map<string, ToolInvocation>;
    readonly record: (name: string) => void;
    readonly execute: (path: ReadonlyArray<string>, args: Array<Json | undefined>, options?: ExecuteCallOptions) => Effect.Effect<Json | undefined, unknown, R>;
    readonly search: (args: Array<Json | undefined>, options?: ExecuteCallOptions) => Effect.Effect<Json | undefined, unknown, R>;
    readonly keys: (path: ReadonlyArray<string>) => ReadonlyArray<string>;
    /** How the tool at `path` executes on suspend (`undefined` when unknown or plain). */
    readonly mode: (path: ReadonlyArray<string>) => Idempotent<unknown, unknown, R> | Durable<unknown, unknown, R> | undefined;
    /** Admits a call to a durable tool, runs `tool.before`, and starts its work under `key`: its JSON data. */
    readonly start: (path: ReadonlyArray<string>, args: Array<Json | undefined>, key: string, admit?: (name: string) => void) => Effect.Effect<Json, unknown, R>;
    /**
     * Waits for a durable tool's running work: its output, as `execute` gives it. `detaching` says whether an
     * interruption detaches to suspend the run, which `tool.after` doesn't see, or ends the call, which it sees as
     * interrupted.
     */
    readonly wait: (path: ReadonlyArray<string>, args: Array<Json | undefined>, key: string, data: Json, detaching: () => boolean) => Effect.Effect<Json | undefined, unknown, R>;
    /** Cancels a durable tool's started work when the run is interrupted or ends. */
    readonly cancel: (path: ReadonlyArray<string>, data: Json) => Effect.Effect<void, unknown, R>;
};
/** Per-execution call state over tools prepared once for the runtime. */
export declare const make: <R>(prepared: Prepared<R>, maxToolCalls: number | undefined, hooks?: Hooks<R>) => ToolRuntime<R>;
export * as ToolRuntime from "./tool-runtime.js";
