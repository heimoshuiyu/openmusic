import { Result } from "effect";
import type { Diagnostic } from "./codemode.js";
/**
 * Extracts every `tools.<path>` referenced by a Code Mode program, in first-seen order. Fails on syntax errors,
 * dynamic bracket access (`tools[name]`), or aliasing/passing `tools` rather than calling `tools.<path>(...)` directly.
 */
export declare function scanTools(code: string): Result.Result<ReadonlyArray<string>, Diagnostic>;
