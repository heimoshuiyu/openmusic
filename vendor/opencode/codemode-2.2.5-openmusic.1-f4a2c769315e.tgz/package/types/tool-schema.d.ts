import { Schema } from "effect";
import type { Tool, JsonSchema } from "./tool.js";
export declare const identifierSegment: RegExp;
export declare const toTypeScript: (schema: Schema.Top, decoded?: boolean, pretty?: boolean) => string;
export declare const jsonSchemaToTypeScript: (schema: JsonSchema, pretty?: boolean) => string;
export type InputProperty = {
    readonly name: string;
    readonly description: string | undefined;
    readonly required: boolean;
};
export declare const inputProperties: <R>(tool: Tool<R>) => Array<InputProperty>;
export declare const inputTypeScript: <R>(tool: Tool<R>, pretty?: boolean) => string;
export declare const isEmptyInput: <R>(tool: Tool<R>) => boolean;
export declare const outputTypeScript: <R>(tool: Tool<R>, pretty?: boolean) => string;
export declare const decodeInput: <R>(tool: Tool<R>, value: unknown) => unknown;
export declare const decodeOutput: <R>(tool: Tool<R>, value: unknown) => unknown;
