import type { Interpreter } from "../runtime/interpreter.js";
import { type Value } from "../runtime/objects.js";
declare global {
    interface Math {
        sumPrecise(values: Iterable<number>): number;
    }
}
export declare const helpers: (ctx: Interpreter<unknown>) => Array<readonly [string, Value]>;
