import type { Interpreter } from "../runtime/interpreter.js";
import { Fn, Obj, type Value } from "../runtime/objects.js";
/**
 * The prelude's bytecode, and its top-level functions' code by name. It is parsed without locations: a failure raised
 * inside it has none, so it is located at the program's call instead (see `locate`).
 */
export declare const compiledPrelude: () => {
    codes: readonly import("../code.js").Code[];
    byName: Map<string, import("../code.js").Code>;
};
/** One runtime's prelude: what its functions' free names see, and its functions and helpers, by name. */
export declare class Prelude {
    readonly scope: Map<string, Value>;
    /** Every prelude function (installed or internal), as an object the intrinsic names reach. */
    readonly functions: Obj;
    /** The `$` helpers, as an object the intrinsic names reach. */
    readonly helpers: Obj;
    constructor(ctx: Interpreter<unknown>, globals: ReadonlyArray<readonly [string, Value]>);
    /** A prelude function, for a native that hands its work on to it. */
    fn(name: string): Fn;
}
