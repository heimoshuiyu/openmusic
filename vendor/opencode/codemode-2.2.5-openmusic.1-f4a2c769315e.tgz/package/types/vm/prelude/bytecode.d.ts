import { type Code, type CodeJson } from "../code.js";
/** A built-in source's bytecode as `script/prelude.ts` saves it, with a hash of the text it was compiled from. */
export type SavedCodes = {
    readonly text: string;
    readonly codes: ReadonlyArray<CodeJson>;
};
/**
 * A built-in source's bytecode (the prelude's, the VM's internal helpers'), made once per process: from the bytecode
 * compiled ahead of time when it was compiled from this text, so the process neither parses nor compiles it until
 * something asks for its nodes (an error's site, a saved state's); compiled now otherwise. A test checks the saved
 * bytecode is what the compiler makes. Its top-level functions start at a line's start; they are found by name.
 */
export declare const builtinCodes: (id: string, text: string) => {
    codes: readonly Code[];
    byName: Map<string, Code>;
};
/** What `script/prelude.ts` saves for a built-in source. */
export declare const saveCodes: (text: string, codes: ReadonlyArray<Code>) => SavedCodes;
