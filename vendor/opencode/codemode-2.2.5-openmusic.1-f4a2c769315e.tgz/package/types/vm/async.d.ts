import type { Diagnostic } from "../codemode.js";
import { type AstNode } from "./runtime/model.js";
import { type Callable, PromiseObj, type Value } from "./runtime/objects.js";
import { type Completion } from "./runtime/signals.js";
import { type Job, type Reaction, Resolving } from "./scheduler.js";
import { type Frame, type FrameMode, type Vm } from "./vm.js";
export type SettlingTarget = {
    resolve(value: Value): void;
    reject(reason: unknown): void;
};
/**
 * Target for a `Promise.prototype.finally` cleanup frame running in `Mode.SETTLE`.
 * When the cleanup completes with `result`, chains `finallyCleaned` and `finallyOutcome` reactions.
 */
export declare class FinallyTarget implements SettlingTarget {
    readonly vm: Vm;
    readonly made: Resolving;
    readonly site: AstNode | undefined;
    readonly outcome: Completion;
    constructor(vm: Vm, made: Resolving, site: AstNode | undefined, outcome: Completion);
    resolve(result: Value): void;
    reject(reason: unknown): void;
}
/**
 * Target for `$vmAsyncFromSyncClose`: regardless of whether `iterator.return()` succeeds or throws,
 * the original rejection reason wins.
 */
export declare class AsyncFromSyncCloseTarget implements SettlingTarget {
    readonly made: Resolving;
    readonly reason: unknown;
    constructor(made: Resolving, reason: unknown);
    resolve(_value: Value): void;
    reject(_error: unknown): void;
}
type Parked = {
    readonly promise: PromiseObj;
    readonly node: AstNode | undefined;
    readonly result: Value;
};
export declare class VmScheduler {
    readonly vm: Vm;
    intrinsicThen: Callable | undefined;
    readonly parked: Map<Frame, Parked>;
    readonly queue: Array<Job>;
    head: number;
    pending: number;
    nextID: number;
    readonly unhandled: Map<PromiseObj, {
        readonly kind: "ExecutionFailure" | "InvalidDataValue" | "InvalidToolInput" | "InvalidToolOutput" | "ParseError" | "TimeoutExceeded" | "ToolCallLimitExceeded" | "ToolFailure" | "Truncated" | "UnknownTool" | "UnsupportedSyntax";
        readonly message: string;
        readonly location?: {
            readonly line: number;
            readonly column: number;
        } | undefined;
        readonly suggestions?: readonly string[] | undefined;
    }>;
    constructor(vm: Vm);
    get hasJobs(): boolean;
    newPromise(): PromiseObj;
    resolving(promise: PromiseObj, site?: AstNode): Resolving;
    then(promise: PromiseObj, reaction: Reaction): void;
    detach(promise: PromiseObj, reaction: Reaction): void;
    promiseResolve(value: Value): PromiseObj;
    reject(promise: PromiseObj, reason: unknown): void;
    resolveWith(promise: PromiseObj, resolution: Value, site?: AstNode): void;
    settle(promise: PromiseObj, completion: Completion): void;
    enqueue(job: Job): void;
    dequeue(): Job | undefined;
    compact(): void;
    park(frames: Array<Frame>, promise: PromiseObj, node: AstNode | undefined, result: Value): void;
    stuckAwait(): AstNode | undefined;
    diagnostics(): Array<Diagnostic>;
    beginJob(job: Job): void;
    enterSettlingCall(callerFrame: Frame | undefined, callable: Value, thisVal: Value, args: Array<Value>, mode: FrameMode, target: SettlingTarget, answer: Value, site: AstNode | undefined): number;
    handlePromisePush(callerFrame: Frame, kindName: string, slots: Array<unknown>, site: AstNode | undefined): number | undefined;
}
export declare const registerAsyncIntrinsics: (map: Map<string, unknown>, vm: Vm) => void;
export {};
