import { ToolReference } from "../../tool-runtime.js";
import type { Builtins } from "./intrinsics.js";
import { type AstNode, type PendingThrow } from "./model.js";
import { type Convert, type GeneratorRequest, Invoke, type Push, type Resume } from "./signals.js";
import type { Code } from "../code.js";
import { type Cell } from "../opcodes.js";
import type { Reaction, Resolving } from "../scheduler.js";
import type { Frame } from "../vm.js";
import { OrderedTable, type TableCursor } from "./table.js";
/** Property attributes, as in a JS property descriptor. */
export type Attributes = {
    readonly writable: boolean;
    readonly enumerable: boolean;
    readonly configurable: boolean;
};
export type Getter = (receiver: Value) => Value;
export type Setter = (receiver: Value, value: Value) => void;
/** One own property: a data slot or a native accessor pair. */
export type Slot = {
    value: Value;
    writable: boolean;
    enumerable: boolean;
    configurable: boolean;
} | {
    get: Getter | undefined;
    set: Setter | undefined;
    enumerable: boolean;
    configurable: boolean;
};
/**
 * Runs `make`, which makes a runtime's intrinsics, and returns every object made meanwhile, in creation order, after
 * `first` (the built-in prototypes, made before). An object's index in the list is its static intrinsic id.
 */
export declare const makingIntrinsics: <A>(first: ReadonlyArray<Obj>, make: () => A) => readonly [A, Array<Obj>];
/** Marks an intrinsic as changed by the program, so saving a run records it; any other object is left alone. */
export declare const changed: (target: Obj) => void;
/** Ordinary assignment: writable, enumerable, configurable. */
export declare const data: Attributes;
/** Built-in methods and `constructor`: writable and configurable but hidden from enumeration. */
export declare const hidden: Attributes;
/** Function `name` and `length`: read-only but deletable. */
export declare const readonly: Attributes;
/** Constants such as `Math.PI` and a constructor's `prototype`. */
export declare const frozen: Attributes;
/**
 * An object owned by the program: own properties plus a prototype link. Subclasses answer, in one place, how a
 * built-in kind of object prints, coerces, iterates, and crosses to the host.
 */
export declare class Obj {
    proto: Obj | null;
    readonly props: Map<string | symbol, Slot>;
    /** [[Extensible]]: cleared by `Object.preventExtensions`, `seal`, and `freeze`. */
    extensible: boolean;
    /**
     * 0 for an object the program made. For an intrinsic, its id plus one while it is as the runtime made it, negated
     * once it changes (see `changed` and `IntrinsicNames`).
     */
    intrinsic: number;
    constructor(proto: Obj | null);
    /** The class name `Object.prototype.toString` reports: `[object Map]`. */
    readonly tag: string;
    /** How diagnostics refer to a value of this kind. */
    get describe(): string;
    /** ToString without consulting program-defined methods. */
    toString(): string;
    /** ToPrimitive without consulting program-defined methods: only a Date answers a number hint differently. */
    toPrimitive(hint: "default" | "number" | "string"): string | number;
    /** ToNumber without consulting program-defined methods. */
    toNumber(): number;
    /** How `console.log` shows the value; `item` formats a child with cycle and depth tracking. */
    inspect(item: (value: Value) => string): string;
    /** A copy the host can hold; `item` converts a child. A `__proto__` key never reaches host code. */
    toHost(item: (value: Value) => unknown): unknown;
    /** The built-in iteration `for...of` and spread use, when this kind of object has one. */
    iterator(builtins: Builtins): Cursor | undefined;
}
export declare class Arr extends Obj {
    readonly items: Array<Value>;
    readonly tag = "Array";
    /** The attributes every live element shares; `seal` and `freeze` narrow them since elements have no slots. */
    elements: Attributes;
    constructor(proto: Obj, items?: Array<Value>);
    get describe(): string;
    toString(): string;
    inspect(item: (value: Value) => string): string;
    toHost(item: (value: Value) => unknown): unknown[];
    iterator(builtins: Builtins): Position;
}
/** An object with the [[ErrorData]] slot: what `Error.prototype.toString` and the host boundary recognize as an error. */
export declare class ErrorObj extends Obj {
    readonly tag = "Error";
    /**
     * The interpreter failure this error materialized from, so rethrowing it keeps the diagnostic kind and location. It
     * is plain data (type, message, kind, suggestions, and the node it is located at), shared with the failure so a
     * location attached later is seen here too.
     */
    failure?: PendingThrow;
    /** Error.prototype.toString: "name: message", or just one when the other is empty. */
    toString(): string;
    inspect(): string;
}
/** Interpreter machinery a program can hold but never inspect, serialize, or hand to the host. */
export declare abstract class Opaque extends Obj {
    inspect(): string;
}
export declare abstract class Callable extends Opaque {
    readonly length: number;
    readonly tag = "Function";
    constructor(proto: Obj, name: string, length: number);
    get describe(): string;
}
/** A program or prelude function: its bytecode, and the cells of the bindings it captured. */
export declare class Fn extends Callable {
    readonly code: Code;
    readonly cells: ReadonlyArray<Cell>;
    constructor(proto: Obj, code: Code, cells: ReadonlyArray<Cell>, name?: string);
    get generator(): boolean;
}
/** The strict `arguments` object: an ordinary object with indexed own properties and a hidden `length`. */
export declare class Arguments extends Obj {
    readonly tag = "Arguments";
    constructor(proto: Obj, args: Array<Value>);
    iterator(builtins: Builtins): Position;
}
/**
 * A native function body: a value, or what the VM carries out as the call: work it hands over by name (`Push`), a
 * suspended generator to continue (`Resume`), a call it hands on (`Invoke`), or conversions to run before it runs again
 * (`Convert`). A native never runs program code itself.
 */
export type NativeResult = Value | Push | Resume | Invoke | Convert;
/** `site` is the call running the built-in, where a failure it reports later (a rejection) is located. */
export type NativeCall = (thisValue: Value, args: Array<Value>, site: AstNode | undefined) => NativeResult;
export type NativeConstruct = (args: Array<Value>, newTarget: Callable, site: AstNode | undefined) => NativeResult;
export type NativeOptions = {
    /**
     * Why this native may be made while the program runs, for the few kinds that still capture state in a host closure.
     * Every other native is made with the intrinsics; see `nativeRule`.
     */
    readonly runtime?: RuntimeNative;
    readonly name: string;
    readonly length?: number;
    readonly call: NativeCall;
    /** `new name(...)`; without it the function is not a constructor. */
    readonly construct?: NativeConstruct;
    /** Whether callback sites (array methods, replacers, promise reactions) admit this function. Defaults to true. */
    readonly callback?: boolean;
};
/** The natives still made at run time, each holding state in a host closure that cannot be saved yet. */
export type RuntimeNative = "extension";
/**
 * Natives are made only with the intrinsics, so each one has an intrinsic name and run state never holds a host
 * closure. When `check` is on (tests turn it on), making a native for a runtime whose intrinsics are `sealed` (keyed by
 * its `Function.prototype`) throws, unless it declares one of the `RuntimeNative` exceptions.
 */
export declare const nativeRule: {
    check: boolean;
    sealed: WeakSet<Obj>;
    observe?: (native: Native) => void;
};
/**
 * A built-in function: a `Native` made with the intrinsics, or a data kind such as `BoundFn` or `Resolver` whose state
 * is plain fields and whose behaviour lives on its class.
 */
export declare abstract class Builtin extends Callable {
    /** `new name(...)`; without it the function is not a constructor. */
    abstract readonly construct: NativeConstruct | undefined;
    /** Whether callback sites (array methods, replacers, promise reactions) admit this function. */
    abstract readonly callback: boolean;
    abstract invoke(thisValue: Value, args: Array<Value>, site: AstNode | undefined): NativeResult;
}
export declare class Native extends Builtin {
    readonly call: NativeCall;
    readonly construct: NativeConstruct | undefined;
    readonly callback: boolean;
    constructor(proto: Obj, options: NativeOptions);
    invoke(thisValue: Value, args: Array<Value>, site: AstNode | undefined): NativeResult;
}
/** `Function.prototype.bind`'s result: calls `target` with the bound receiver and leading arguments. */
export declare class BoundFn extends Builtin {
    readonly target: Callable;
    readonly boundThis: Value;
    readonly boundArgs: ReadonlyArray<Value>;
    readonly construct: undefined;
    readonly callback = true;
    constructor(proto: Obj, target: Callable, boundThis: Value, boundArgs: ReadonlyArray<Value>);
    invoke(_: Value, args: Array<Value>, site: AstNode | undefined): NativeResult;
}
/** A `resolve` or `reject` function handed to an executor or thenable: settles its shared `Resolving` once. */
export declare class Resolver extends Builtin {
    readonly resolving: Resolving;
    readonly kind: "resolve" | "reject";
    readonly construct: undefined;
    readonly callback = true;
    constructor(proto: Obj, name: string, resolving: Resolving, kind: "resolve" | "reject");
    invoke(_: Value, args: Array<Value>): NativeResult;
}
export declare class PromiseObj extends Opaque {
    /** Creation order, for reporting unhandled rejections in the order their promises were made. */
    readonly id: number;
    readonly tag = "Promise";
    state: "pending" | "fulfilled" | "rejected";
    /** The value, or the failure as thrown; a handler receives it materialized. */
    result: unknown;
    reactions: Array<Reaction>;
    /** [[PromiseIsHandled]]: a reaction was attached, so a rejection is not reported as unhandled. */
    handled: boolean;
    constructor(proto: Obj, 
    /** Creation order, for reporting unhandled rejections in the order their promises were made. */
    id: number);
    get describe(): string;
    inspect(): string;
}
export type GeneratorState = "suspendedStart" | "suspendedYield" | "executing" | "awaiting-return" | "draining" | "completed";
export declare class GeneratorObj extends Opaque {
    readonly asynchronous: boolean;
    readonly tag = "Generator";
    state: GeneratorState;
    /** The suspended body's frame, kept while it waits for the next request, which puts it back on the job stack. */
    frame: Frame | undefined;
    /** An async generator's requests, oldest first, each with what settles its promise. */
    readonly queue: Array<{
        readonly request: GeneratorRequest;
        readonly resolving: Resolving;
    }>;
    constructor(proto: Obj, asynchronous: boolean);
    get describe(): string;
}
/** One pull from an iterator, as `for...of` sees it. */
export type Step = {
    readonly done: boolean;
    readonly value: Value;
};
/**
 * An iterator the interpreter drives, as data: a built-in cursor over a collection (`Position`), or a program
 * iterator driven by its own `next` method (`CustomIterator`).
 */
export type Cursor = Position | CustomIterator;
/** A program iterator record: the iterator, its `next` method, and whether its results are awaited. */
export type CustomIterator = {
    readonly iterator: Obj;
    readonly next: Value;
    readonly asynchronous: boolean;
};
/** What a built-in iterator yields for each entry: `keys()`, `values()`, or `entries()`. */
export type IterationKind = "keys" | "values" | "entries";
/** What a built-in iterator walks: a collection, a string, or a fixed list of values. */
export type PositionSource = Arr | Bytes | MapObj | SetObj | HeadersObj | URLSearchParamsObj | string | ReadonlyArray<Value>;
/**
 * A built-in iterator's place in its source, as data: what it walks, what it yields, and the next index. Iteration is
 * live, as in JS: an array iterator reads the length on every step, and a Map or Set iterator is kept in place by its
 * table. Once done it stays done. There is nothing to close.
 */
export declare class Position implements TableCursor {
    readonly source: PositionSource;
    readonly kind: IterationKind;
    /** The prototype of the `[key, value]` arrays `entries()` yields. */
    readonly arrays: Obj;
    index: number;
    done: boolean;
    constructor(source: PositionSource, kind: IterationKind, 
    /** The prototype of the `[key, value]` arrays `entries()` yields. */
    arrays: Obj);
    step(): Step;
    private yield;
    private finish;
}
/** A built-in iterator: a live cursor over a host collection or an iterator helper, yielding program values. */
export declare class IteratorObj extends Opaque {
    readonly cursor: Cursor;
    readonly tag = "Iterator";
    constructor(proto: Obj, cursor: Cursor);
    get describe(): string;
}
/** A built-in iterator over a collection, e.g. `array.values()`. */
export declare const positionIterator: (builtins: Builtins, source: PositionSource, kind: IterationKind) => IteratorObj;
/** A built-in object around a host value: data-like, so it prints as itself and crosses to extensions as a copy. */
export declare abstract class Wrapper extends Obj {
    inspect(item: (value: Value) => string): string;
}
export declare class DateObj extends Wrapper {
    time: number;
    readonly tag = "Date";
    constructor(proto: Obj, time: number);
    toString(): string;
    toPrimitive(hint: "default" | "number" | "string"): string | number;
    toHost(): Date;
}
/** A RegExp as data: its source, flags, and `lastIndex`; the host regex is only a compiled cache of the first two. */
export declare class RegExpObj extends Wrapper {
    readonly tag = "RegExp";
    readonly source: string;
    readonly flags: string;
    /** Shared by `exec`/`test` and the String methods, as the host regex's own `lastIndex` would be. */
    lastIndex: number;
    private compiled;
    constructor(proto: Obj, pattern: string, flags: string);
    /** The compiled regex, for reading what it is; anything that matches goes through `use`. */
    get regex(): RegExp;
    /** Runs host regex work starting from this object's `lastIndex`, and keeps the `lastIndex` the work leaves. */
    use<T>(work: (regex: RegExp) => T): T;
    toString(): string;
    toHost(): RegExp;
}
export declare class MapObj extends Wrapper {
    readonly tag = "Map";
    readonly map: OrderedTable;
    inspect(item: (value: Value) => string): string;
    toHost(item: (value: Value) => unknown): Map<unknown, unknown>;
    iterator(builtins: Builtins): Position;
}
export declare class SetObj extends Wrapper {
    readonly tag = "Set";
    readonly set: OrderedTable;
    inspect(item: (value: Value) => string): string;
    toHost(item: (value: Value) => unknown): Set<unknown>;
    iterator(builtins: Builtins): Position;
}
/**
 * Keys are held strongly for the run, which is short-lived; garbage collection is not observable in Code Mode, and a
 * plain table keeps the state as data.
 */
export declare class WeakMapObj extends Wrapper {
    readonly tag = "WeakMap";
    readonly map: Map<Obj, Value>;
    inspect(): string;
}
export declare class WeakSetObj extends Wrapper {
    readonly tag = "WeakSet";
    readonly set: Set<Obj>;
    inspect(): string;
}
export declare class URLSearchParamsObj extends Wrapper {
    readonly params: URLSearchParams;
    readonly tag = "URLSearchParams";
    constructor(proto: Obj, params: URLSearchParams);
    toString(): string;
    toHost(): URLSearchParams;
    iterator(builtins: Builtins): Position;
}
export declare class HeadersObj extends Wrapper {
    readonly headers: Headers;
    readonly tag = "Headers";
    constructor(proto: Obj, headers: Headers);
    inspect(): string;
    toHost(): Headers;
    iterator(builtins: Builtins): Position;
}
export declare class URLObj extends Wrapper {
    readonly url: URL;
    readonly tag = "URL";
    readonly searchParams: URLSearchParamsObj;
    constructor(proto: Obj, searchParamsProto: Obj, url: URL);
    toString(): string;
    toHost(): URL;
}
/** A `Uint8Array`: the host array does the byte clamping and ignores out-of-range writes, as JS does. */
export declare class Bytes extends Wrapper {
    readonly bytes: Uint8Array;
    readonly tag = "Uint8Array";
    constructor(proto: Obj, bytes: Uint8Array);
    toString(): string;
    inspect(): string;
    toHost(): Uint8Array<ArrayBuffer>;
    iterator(builtins: Builtins): Position;
}
/** Every value a program can hold. Host values never appear here; they are copied in at the boundaries. */
export type Value = string | number | boolean | null | undefined | symbol | Obj | ToolReference;
/** ToString without consulting program-defined methods. */
export declare const coerceToString: (value: Value) => string;
/** ToNumber without consulting program-defined methods; tool references are not numbers. */
export declare const coerceToNumber: (value: Value) => number;
/** ToIntegerOrInfinity: NaN is 0, fractions truncate. */
export declare const coerceToInteger: (value: Value) => number;
/** Values that cannot cross the data boundary: opaque machinery and host-backed wrappers. */
export declare const isRuntimeReference: (value: Value) => boolean;
export declare const parseArrayIndex: (key: string | number) => number | undefined;
/** The own property under `key`, including an array's live indexes and `length`. */
export declare const own: (target: Obj, key: PropertyKey) => Slot | undefined;
export declare const hasOwn: (target: Obj, key: PropertyKey) => boolean;
export declare const getOwn: (target: Obj, key: PropertyKey) => Value;
/** [[Get]]: walks the prototype chain; accessors see `receiver`, which is the primitive for wrapper prototypes. */
export declare const get: (target: Obj, key: PropertyKey, receiver?: Value) => Value;
export declare const has: (target: Obj, key: PropertyKey) => boolean;
export declare const hasPrototype: (value: Value, proto: Obj) => boolean;
/** [[Set]]: an inherited setter or read-only property decides before an own data property is created. */
export declare const set: (target: Obj, key: PropertyKey, value: Value) => boolean;
/** Creating a property on a non-extensible object is the one [[Set]] failure with its own message. */
export declare const rejectAddition: (target: Obj, key: string | symbol | number) => void;
/** [[DefineOwnProperty]] for a data property, ignoring the chain. */
export declare const define: (target: Obj, key: PropertyKey, value: Value, attrs?: Attributes) => void;
export declare const defineAccessor: (target: Obj, key: PropertyKey, get: Getter | undefined, set?: Setter) => void;
export declare const remove: (target: Obj, key: PropertyKey) => boolean;
export declare const ownKeys: (target: Obj) => Array<string | symbol>;
/** Own enumerable keys, including the iterator symbols; what spread and `Object.assign` copy. */
export declare const enumerableKeys: (target: Obj) => Array<string | symbol>;
/** Own enumerable string keys: `Object.keys`. */
export declare const keys: (target: Obj) => Array<string>;
/** Own enumerable string entries: `Object.entries` and serialization. */
export declare const entries: (target: Obj) => Array<[string, Value]>;
/** An iterator result `{ value, done }`, built directly since every iteration step makes one. */
export declare const iteratorResult: (proto: Obj, value: Value, done: boolean) => Obj;
export declare const record: (proto: Obj, fields: Record<string, Value>) => Obj;
export declare const assign: (target: Obj, source: Obj, skip?: ReadonlySet<PropertyKey>) => void;
