import type { Expression, MemberExpression, NewExpression, Super } from "acorn";
import { ToolReference } from "../../tool-runtime.js";
import { type AstNode } from "./model.js";
import { type Builtins } from "./intrinsics.js";
import { type Cursor, Obj, type Value } from "./objects.js";
import type { Interpreter } from "./interpreter.js";
/** ToPropertyKey on a primitive (or an opaque value, which keeps its built-in string form). */
export declare const propertyKey: (value: Value) => PropertyKey;
/** The TypeError for calling a value that is not a function. */
export declare const notAFunction: (callee: Expression | Super | undefined, node: AstNode | undefined) => import("./model.js").PendingThrow;
/** The TypeError for `new` on a callee that cannot be constructed. */
export declare const notConstructible: (callee: Value, node: NewExpression) => import("./model.js").PendingThrow;
export declare const instanceofValue: (lhs: Value, rhs: Value, node: AstNode) => boolean;
export declare const applyBinaryOperator: (operator: string, lhs: Value, rhs: Value, node: AstNode) => Value;
/**
 * How an operator with an object operand converts: `in` with a data object on the left asks ToPropertyKey of it,
 * a converting operator asks ToPrimitive of both operands with `hint`, and anything else needs no conversion.
 */
export declare const operatorConversion: (operator: string, lhs: Value, rhs: Value) => {
    readonly kind: "key";
} | {
    readonly kind: "primitive";
    readonly hint: "default" | "number";
} | undefined;
export type { CustomIterator } from "./objects.js";
/** A resolved member: the object to read through and the receiver that inherited accessors see. */
type MemberReference = {
    target: Obj;
    key: PropertyKey;
    receiver: Value;
};
export declare const isThenable: (value: Value) => boolean;
/** A built-in iterator over `value` that needs no program code to start: an iterator object, a string, a collection. */
export declare const builtinCursor: (builtins: Builtins, value: Value) => Cursor | undefined;
export declare const requireIteratorObject: (value: Value, context: string, node?: AstNode) => Obj;
export declare const requireIteratorMethod: (value: Value, context: string, node?: AstNode) => Value;
export declare const forInKeys: <R>(ctx: Interpreter<R>, value: Value, node: AstNode) => Array<string>;
export declare const requireMemberBase: (node: MemberExpression, objectValue: Value, keyValue: Value) => void;
export declare const resolveProperty: (builtins: Builtins, objectValue: Value, key: PropertyKey, objectNode: AstNode, propertyNode: AstNode) => MemberReference | ToolReference | {
    value: Value;
};
export declare const destructuredProperty: (builtins: Builtins, source: Value, key: PropertyKey, node: AstNode) => Value;
export declare const readReference: (reference: MemberReference, node: MemberExpression) => Value;
export declare const readProperty: (target: Obj, key: PropertyKey, node: AstNode | undefined, receiver?: Value) => Value;
/** The reference an assignment or update writes through: only a data field of an object. */
export declare const writableReference: (reference: MemberReference | ToolReference | {
    value: Value;
} | symbol, node: MemberExpression) => MemberReference;
export declare const assignToReference: (target: Obj, key: PropertyKey, next: Value, node: AstNode) => void;
