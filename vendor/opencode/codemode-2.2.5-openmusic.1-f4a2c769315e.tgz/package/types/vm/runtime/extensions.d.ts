import { type Extension } from "../../extension.js";
import type { Interpreter } from "./interpreter.js";
import { type AstNode } from "./model.js";
import { PromiseObj, type Value } from "./objects.js";
import type { ExtensionRequest } from "../scheduler.js";
/**
 * The global bindings of one run's extensions. Everything crossing the boundary is converted: plain data and built-in
 * wrappers are copied, a host function becomes a program function whose calls cross the same way, and a host Promise
 * or Effect becomes a program promise.
 */
export declare const extensionGlobals: <R>(ctx: Interpreter<R>, extensions: ReadonlyArray<Extension>) => ReadonlyArray<readonly [string, Value]>;
/**
 * Calls a synchronous extension function's host function, once its `extension.before` hook allowed it: a promise for
 * a result that settles later (an Effect or a Promise), or the request that settles what it returned or threw now.
 */
export declare const startExtensionCall: <R>(ctx: Interpreter<R>, host: Function, args: ReadonlyArray<unknown>, call: Pick<ExtensionRequest, "label" | "extension" | "invocation">, site: AstNode | undefined) => PromiseObj | ExtensionRequest;
