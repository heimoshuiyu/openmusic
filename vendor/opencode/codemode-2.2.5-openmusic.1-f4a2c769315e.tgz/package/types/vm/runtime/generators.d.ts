import type { Interpreter } from "./interpreter.js";
/**
 * `next`/`return`/`throw` on the generator prototypes (async generators answer with promises), on iterator helpers,
 * and on the async-from-sync iterator. A generator's suspended body runs on the caller's job stack.
 */
export declare const generatorGlobals: <R>(ctx: Interpreter<R>) => void;
