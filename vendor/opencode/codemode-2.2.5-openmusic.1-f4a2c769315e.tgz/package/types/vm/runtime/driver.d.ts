import { type Context, Effect } from "effect";
import type { HostCall } from "../scheduler.js";
import { type ToolRuntime } from "../../tool-runtime.js";
import type { Vm } from "../vm.js";
import { type Completion } from "./signals.js";
/** What `Driver.run` returns once the run was suspended: its state is saved, and the VM stopped. */
export declare const SUSPENDED: unique symbol;
/**
 * Runs the VM (see `Vm`) in Effect: the only place program execution meets the host. It calls `vm.run`
 * until the program ends, and does what each stop asks: yields to the Effect scheduler for a slice, and starts the host
 * calls the VM queued, as fibers with the caller's services, reporting each outcome back with `vm.complete`.
 * Fibers live only here, by host call id, and never become part of the VM's state.
 *
 * A durable tool's call runs as two fibers, `start` then `wait`, so suspending can detach the second and keep the JSON
 * data `start` gave. An idempotent tool's running fiber is detached and interrupted on suspend, and its call is saved
 * as queued to run again on resume. The VM and tool bridge can be swapped for restored ones between stops (the
 * round-trip test mode does); a fiber's outcome goes to whichever VM is current, by host call id.
 */
export declare class Driver<R> {
    vm: Vm;
    tools: ToolRuntime<R>;
    /** The services host work runs with: the caller's, so tools see its context, tracing, and clock. */
    private readonly services;
    private readonly fibers;
    private readonly detached;
    private wake;
    private stopping;
    private suspending;
    private interrupted;
    /** Called at every slice and host stop, before queued calls start: the round-trip test mode swaps the VM. */
    checkpoint: Effect.Effect<void, unknown, R> | undefined;
    constructor(vm: Vm, tools: ToolRuntime<R>, 
    /** The services host work runs with: the caller's, so tools see its context, tracing, and clock. */
    services: Context.Context<R>);
    /**
     * Runs the VM until the program's body completes, then returns how it ended, or `SUSPENDED` once the run was
     * suspended (see `detach`). Host work it started may still be running; `interrupt` stops it. Host work interrupted
     * on its own that reaches the program's body, or blocking host work that is interrupted, interrupts the execution.
     */
    run(): Effect.Effect<Completion | typeof SUSPENDED, unknown, R>;
    /**
     * The host calls that block a suspend now: every call in progress except an idempotent tool call or a durable tool
     * call in `started`, plus any queued or synchronous extension call the program is in the middle of, which holds live
     * host values. A tool call queued but not started starts on resume.
     */
    blocking(): Array<{
        readonly key: string;
        readonly path: string;
    }>;
    /** Whether the run holds live host values: an extension call in progress. */
    get holdsHostValues(): boolean;
    /**
     * Stops the run to suspend it, once its state is saved: `run` returns `SUSPENDED` at its next step, and running
     * idempotent or durable calls' fibers are detached, so ending them reports nothing.
     */
    detach(): void;
    /** Stops host work still running, waiting for its cleanup; a durable tool's work is cancelled unless detached. */
    interrupt(): Effect.Effect<void>;
    /** Starts tool calls that were queued (including idempotent calls) and waits on durable calls in `started`. */
    resume(): void;
    private admit;
    private launch;
    private wait;
    private fork;
    private get settled();
}
/** A host call as the program wrote it: `tools.x.y`, `search`, or an extension function's path. */
export declare const callPath: (call: HostCall) => string;
