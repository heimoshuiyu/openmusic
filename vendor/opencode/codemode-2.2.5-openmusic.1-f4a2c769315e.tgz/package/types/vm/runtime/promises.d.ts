import { type AstNode } from "./model.js";
import { Callable, Obj, PromiseObj, type Value } from "./objects.js";
import type { Interpreter } from "./interpreter.js";
import { type Completion } from "./signals.js";
import type { Combination, Reaction, Resolving } from "../scheduler.js";
/**
 * NewPromiseCapability(%Promise%): a pending promise with what settles it once. A built-in's own failure that rejects
 * it is located at `site`, the call that created it.
 */
export declare const capability: <R>(ctx: Interpreter<R>, site: AstNode | undefined) => Resolving;
/**
 * Runs a settled promise's reaction as a job: it finishes at once, or returns the call into program code the VM makes
 * for it.
 */
export declare const react: <R>(ctx: Interpreter<R>, reaction: Exclude<Reaction, {
    readonly kind: "await" | "asyncFromSync";
}>, settled: Completion) => JobCall | void;
/**
 * A job that calls program code once, which the VM runs (`VmScheduler.beginJob`), counted toward the depth limit:
 * - `thenable` (PromiseResolveThenableJob): calls the thenable's `then` with the resolving functions; a throw rejects
 *   `resolving`.
 * - `handler` (PromiseReactionJob): a `then`/`catch` handler; its result or failure settles `derived`.
 * - `finally` (PromiseFinallyJob): a `finally` cleanup; once its own result settles, the original outcome passes on to
 *   `made` (the spec chains `then(valueThunk)` onto the cleanup's promise: one more job), and a failing cleanup wins.
 */
export type JobCall = {
    readonly kind: "thenable";
    readonly resolving: Resolving;
    readonly then: Value;
    readonly thenable: Obj;
    readonly functions: Array<Value>;
} | {
    readonly kind: "handler";
    readonly derived: Resolving;
    readonly handler: Callable;
    readonly argument: Value;
} | {
    readonly kind: "finally";
    readonly made: Resolving;
    readonly cleanup: Callable;
    readonly site: AstNode | undefined;
    readonly outcome: Completion;
};
/**
 * NewPromiseResolveThenableJob: the work that calls the thenable's `then`. Adopting a native promise through the
 * intrinsic `then` takes the same jobs as calling it, and keeps the rejection as thrown so its diagnostic survives.
 */
export declare const adoptThenable: <R>(ctx: Interpreter<R>, promise: PromiseObj, thenable: Obj, then: Value) => JobCall | void;
export declare const finishCombination: <R>(ctx: Interpreter<R>, combination: Combination) => void;
/**
 * Lets a synchronous object result also be awaited or chained like a Promise. It inherits non-enumerable
 * then/catch/finally that settle with a plain copy, so data views never show them and awaiting does not recurse.
 */
export declare const promiseLike: <R>(ctx: Interpreter<R>, value: Value) => Value;
export declare const promiseGlobal: <R>(ctx: Interpreter<R>) => import("./objects.js").Native;
