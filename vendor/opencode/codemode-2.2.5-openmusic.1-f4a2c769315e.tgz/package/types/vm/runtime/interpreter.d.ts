import type { ToolRuntime } from "../../tool-runtime.js";
import type { ExtensionRequest } from "../scheduler.js";
import type { HostBridge } from "../snapshot/codec.js";
import { Vm } from "../vm.js";
import type { Builtins } from "./intrinsics.js";
import { IntrinsicNames } from "./intrinsic-names.js";
import { type AstNode, type Binding } from "./model.js";
import { Obj, type Value } from "./objects.js";
import { Prelude } from "../prelude/prelude.js";
import { Push } from "./signals.js";
import type { NodeId, Source } from "./source.js";
/** One program execution: the tool bridge, the VM that runs it, captured logs, and the global scope built once. */
export declare class Interpreter<R> {
    readonly tools: ToolRuntime<R>;
    readonly builtins: Builtins;
    readonly logs: Array<string>;
    /** Runs program code, and keeps the job queue, promises, and host calls the program waits on. */
    readonly vm: Vm;
    /** Names for this runtime's intrinsics, taken before any program code can change a built-in. */
    readonly intrinsics: IntrinsicNames;
    /** The built-ins written in Code Mode, and the scope they close over. */
    readonly prelude: Prelude;
    /** Makes the Effect an extension function's host work runs as; set by the extension bridge. */
    extensionWork: ((request: ExtensionRequest) => unknown) | undefined;
    /** Saves and restores values returned by extensions with `snapshot` hooks; set by the extension bridge. */
    hosts: HostBridge | undefined;
    /** The parsed sources this execution runs, by id, so a `NodeId` resolves to its node. */
    readonly sources: Map<string, Source>;
    /** The global bindings: the intrinsics, the host's globals, and the program's bindings. */
    readonly globalScope: Map<string, Binding>;
    private readonly modules;
    private readonly namespaces;
    constructor(options: {
        readonly tools: ToolRuntime<R>;
        readonly builtins: Builtins;
        readonly logs?: Array<string>;
        /** The host's globals (extensions, a test harness): made again, the same way, when a saved run is restored. */
        readonly globals?: (ctx: Interpreter<R>) => ReadonlyArray<readonly [string, Value]>;
        /** Data bound for this program, part of its saved state; host globals of the same name win. */
        readonly bindings?: (ctx: Interpreter<R>) => ReadonlyArray<readonly [string, Value]>;
    });
    /** A module, as `require` returns it and a default import binds it: a global, by its Node module name. */
    module(specifier: string, site?: AstNode): Value;
    /**
     * What `import * as` and `import()` see: the module's own properties, and the module itself as `default`, the way
     * Node presents a CommonJS module.
     */
    namespace(specifier: string, site?: AstNode): Obj;
    /** The node a `NodeId` names, in one of this execution's sources. */
    node(id: NodeId): AstNode | undefined;
    /** The built-in search: its result is usable directly, and can also be awaited or chained like a Promise. */
    search(args: Array<Value>): Push;
}
