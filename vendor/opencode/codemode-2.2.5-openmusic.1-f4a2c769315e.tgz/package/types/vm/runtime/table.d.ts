import type { Value } from "./objects.js";
/** The key of a deleted entry. */
export declare const deleted: unique symbol;
/** A position in a table's entries, kept by the table so compaction can move it. */
export type TableCursor = {
    index: number;
    done: boolean;
};
/**
 * The storage behind Map and Set: entries in insertion order with tombstones, as V8's OrderedHashTable. An entry keeps
 * its index until the table compacts, and the table moves every live cursor when it does, so an iterator's position is
 * a plain integer. Iteration is live: entries added before a cursor reaches the end are visited, deleted ones skipped,
 * and after `clear()` a cursor continues with whatever is added next. Keys compare by SameValueZero.
 */
export declare class OrderedTable {
    readonly keys: Array<Value | typeof deleted>;
    readonly values: Array<Value>;
    private readonly index;
    private cursors;
    private tombstones;
    private pruneAt;
    get size(): number;
    has(key: Value): boolean;
    get(key: Value): Value;
    set(key: Value, value: Value): void;
    add(key: Value): void;
    delete(key: Value): boolean;
    clear(): void;
    /** A cursor at the first entry, moved along by `advance`. */
    cursor(): TableCursor;
    /** Starts keeping `cursor` in place across compaction. */
    track<C extends TableCursor>(cursor: C): C;
    /** The index of the cursor's next live entry, moving past it; -1 once the cursor is done, which is for good. */
    advance(cursor: TableCursor): number;
    /**
     * Live entries in order, through a tracked cursor, so host code may change the table (or run program code that does)
     * between steps. Stopping early releases the cursor.
     */
    entries(): Generator<[Value, Value]>;
    [Symbol.iterator](): Generator<[Value, Value]>;
    liveKeys(): Generator<Value>;
    private compact;
}
