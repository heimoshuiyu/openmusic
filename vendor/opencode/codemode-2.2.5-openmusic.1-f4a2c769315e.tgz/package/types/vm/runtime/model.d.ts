import type { Node } from "acorn";
import type { ErrorType } from "./intrinsics.js";
import type { DiagnosticKind } from "../../codemode.js";
import type { ErrorObj, Value } from "./objects.js";
/** Any parsed node; the compiler narrows on `type`, and diagnostics read `loc`. */
export type AstNode = Node;
/** A global binding: globals are immutable per run, and top-level declarations are the program's own locals. */
export type Binding = {
    readonly value: Value;
};
export type GeneratorRequestKind = "next" | "return" | "throw";
export declare const AsyncIteratorSymbol: unique symbol;
export declare const IteratorSymbol: unique symbol;
export declare class Throw {
    readonly value: Value;
    constructor(value: Value);
}
/**
 * A failure raised by the interpreter or a built-in. It travels as a defect and becomes one program Error object
 * the first time a handler observes it, so every observer of the same failure sees the same value.
 */
export declare class PendingThrow {
    /** The JS error class a program sees when it catches this failure. */
    readonly type: ErrorType;
    readonly message: string;
    readonly kind: DiagnosticKind;
    readonly suggestions?: ReadonlyArray<string> | undefined;
    node?: AstNode;
    value?: ErrorObj;
    constructor(
    /** The JS error class a program sees when it catches this failure. */
    type: ErrorType, message: string, node?: AstNode, kind?: DiagnosticKind, suggestions?: ReadonlyArray<string> | undefined);
}
/**
 * A host value a restored run cannot have back: a function an extension returned, or what a host function returned,
 * which have no data form. Using it fails with `lostError`.
 */
export declare class Lost {
    readonly description: string;
    constructor(description: string);
}
/** What using a value lost to a suspend throws. */
export declare const lostError: (description: string, node?: AstNode) => PendingThrow;
export declare const typeError: (message: string, node?: AstNode) => PendingThrow;
export declare const invalidData: (message: string, node?: AstNode) => PendingThrow;
export declare const rangeError: (message: string, node?: AstNode) => PendingThrow;
export declare const referenceError: (message: string, node?: AstNode) => PendingThrow;
export declare const syntaxError: (message: string, node?: AstNode) => PendingThrow;
export declare const uriError: (message: string, node?: AstNode) => PendingThrow;
export declare const supportedSyntaxMessage = "This is a restricted JavaScript-like language. Supported: plain and async functions, data literals, destructuring, standard control flow, await and Promise, and built-ins such as Array, Object, Math, JSON, Date, RegExp, Map, Set, and URL. Unsupported: classes, getters/setters, BigInt, and custom Symbols. Use plain functions and data objects instead.";
export declare const sourceLocation: (node: AstNode) => {
    readonly line: number;
    readonly column: number;
};
export declare const formatLocation: (location?: {
    readonly line: number;
    readonly column: number;
}) => string;
