import { type Builtins } from "./intrinsics.js";
import { Callable, type NativeResult, type Value } from "./objects.js";
import { type Hints, Invoke } from "./signals.js";
/** Invoke(value, name), as the call to make: the method the value would find through its prototype. */
export declare const invokeMethod: (builtins: Builtins, value: Value, name: string, label: string) => Invoke;
/**
 * The conversions a built-in received, while it runs again after them: by ordinal, the order its `withPrimitives`
 * calls run in. The VM resets `count` before every built-in call.
 */
export declare const conversions: {
    count: number;
    replay: Array<Array<Value> | undefined> | undefined;
};
/**
 * Runs a native body on values after ToPrimitive, in order, with one hint for all positions or one per position.
 * Primitive values skip the conversion entirely. Otherwise the built-in asks the VM for the conversions (they
 * call program code, so they run as prelude code) and runs again from the start once they are done; this call then
 * receives them. So everything a built-in does before its last conversion must be repeatable: it reads, checks, and
 * throws, but changes nothing. State the body needs as it was before the conversions (a Date's time) goes in `values`.
 * With `coerce`, each value is also converted to a number or string (by its hint) before the next one is.
 */
export declare const withPrimitives: (hints: Hints, values: Array<Value>, body: (primitives: Array<Value>) => NativeResult, coerce?: boolean) => NativeResult;
/** Checks a callback argument: the callable it is, or the TypeError for one a callback site does not admit. */
export declare const requireCallback: (callback: Value, name: string) => Callable;
export declare const isSupportedCallback: (value: Value) => value is Callable;
