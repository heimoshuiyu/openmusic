import type { Builtins } from "./intrinsics.js";
import { Obj, type Value } from "./objects.js";
/**
 * Deterministic names for one runtime's intrinsic objects, so saved state can refer to a built-in by name instead of
 * copying it, and whether each one changed since the runtime was made.
 *
 * - **Static ids.** Every object made with the intrinsics (`createBuiltins`, the globals, the prelude) has an id: its
 *   creation index, which is the same in every runtime because making them is deterministic (see `makingIntrinsics`).
 *   The ids are named once per process, by a breadth-first walk of the first runtime made, before any program runs:
 *   from the global names (`Array.prototype.map`), then `%Name%` for built-in prototypes the walk cannot reach
 *   (`%Generator%`) and the prelude's internals, and what is reachable from them. The first path found names a value.
 *   No later runtime walks anything.
 * - **`@host` names.** The host's globals (extensions, a test harness) differ between runtimes, so each runtime names
 *   them itself, `@name`, by a walk over only the objects they reach that have no static id. Host lists are small.
 * - **Dirty bits.** `Obj.intrinsic` is the id plus one while the object is as made, negated once it changes. Every
 *   write to an object's properties, prototype, extensibility or elements marks it (`changed` in objects.ts), and so
 *   does restoring it from a saved record, so a run suspended twice keeps what changed before the first suspend.
 */
export declare class IntrinsicNames {
    /** The objects made with the intrinsics, by id. */
    private readonly made;
    private readonly hostValues;
    private readonly hostNames;
    private readonly hostIndex;
    private named;
    constructor(
    /** The objects made with the intrinsics, by id. */
    made: ReadonlyArray<Obj>, roots: Roots, hosts?: ReadonlyArray<readonly [string, Value]>);
    /** The named intrinsics, in name order (see `all`). */
    get values(): ReadonlyArray<Obj>;
    /** The name of an intrinsic, or undefined for any other object. */
    nameOf(value: Obj): string | undefined;
    /** The intrinsic a name refers to. */
    valueOf(name: string): Obj | undefined;
    /** Every name: the static ones in walk order, then the host globals'. */
    all(): ReadonlyArray<string>;
    /** The host globals' names, `@name`, in walk order. */
    hosts(): ReadonlyArray<string>;
    /**
     * The named intrinsics a saved state has to record: those changed since the runtime was made, and host values of
     * classes whose state is not their properties (an extension's Map), which count as changed.
     */
    changed(): Array<Obj>;
    private isStatic;
}
/** Whether a named object is still as the runtime made it, so its name alone restores it. */
export declare const unchanged: (value: Obj) => boolean;
/** The static names, in walk order, once a runtime has been made in this process. */
export declare const staticNames: () => ReadonlyArray<string>;
/** Where the walk that names the static intrinsics starts. */
export type Roots = {
    readonly globals: ReadonlyArray<readonly [string, Value]>;
    readonly builtins: Builtins;
    /** Internal objects no global reaches (the prelude's functions and helpers), named like the builtins. */
    readonly internals: ReadonlyArray<readonly [string, Obj]>;
};
