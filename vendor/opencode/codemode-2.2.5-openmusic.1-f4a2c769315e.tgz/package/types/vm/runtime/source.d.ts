import type { Program } from "acorn";
import type { AstNode } from "./model.js";
/** A stable reference to one AST node: its source and its index in a pre-order walk of that source's tree. */
export type NodeId = {
    readonly source: string;
    readonly index: number;
};
/**
 * One parsed program text with every node numbered in pre-order, so a node can be named and found again. A built-in
 * source whose bytecode was compiled ahead of time is parsed only once something asks for its nodes.
 */
export declare class Source {
    readonly id: string;
    readonly code: string;
    private tree;
    private numbered;
    constructor(id: string, code: string, program: Program | (() => Program));
    get program(): Program;
    /** Nodes by pre-order index. */
    get nodes(): ReadonlyArray<AstNode>;
    /** The node `id` names, when it belongs to this source. */
    node(id: NodeId): AstNode | undefined;
}
/** The id of a node from a numbered source; nodes built outside one (none today) have none. */
export declare const nodeId: (node: AstNode) => NodeId | undefined;
/** The source a numbered node belongs to. */
export declare const sourceOf: (node: AstNode) => Source | undefined;
/** Whether `node` is the prelude's: it is parsed without locations, so a failure there is located at the program's call. */
export declare const inPrelude: (node: AstNode) => boolean;
