import { type Program } from "acorn";
import { Effect } from "effect";
import type { DataValue, Diagnostic, Outcome, ResolvedExecutionLimits, Result } from "../../codemode.js";
import type { Extension } from "../../extension.js";
import { type Snapshot, SnapshotError } from "../snapshot/snapshot.js";
import { ToolRuntime } from "../../tool-runtime.js";
import { SuspendError } from "../../suspend-error.js";
import { Interpreter } from "./interpreter.js";
import type { Value } from "./objects.js";
import { Source } from "./source.js";
type Globals<R> = (ctx: Interpreter<R>) => ReadonlyArray<readonly [string, Value]>;
/** How a runtime runs programs: its tools, limits, hooks, and host globals, shared by every run it starts. */
export type Setup<R> = {
    readonly prepared: ToolRuntime.Prepared<R>;
    readonly limits: ResolvedExecutionLimits;
    readonly hooks: ToolRuntime.Hooks<R>;
    /** The host's globals, made again for a restored run; see `Interpreter`. */
    readonly globals?: Globals<R> | undefined;
    /** Whether the host globals can hand the program values with no data form (extensions can). */
    readonly lossy?: boolean;
};
/** Turns a suspended outcome into a failure, for callers that only run programs to their end. */
export declare const finishExecution: <E, R>(outcome: Effect.Effect<Outcome, E, R>) => Effect.Effect<Result, E, R>;
/** Runs a program on the VM with `CodeMode.make`'s extensions and JSON bindings. */
export declare const execute: <R>(code: string, prepared: ToolRuntime.Prepared<R>, limits: ResolvedExecutionLimits, hooks: ToolRuntime.Hooks<R>, extensions: ReadonlyArray<Extension>, bindings: Readonly<Record<string, DataValue>> | undefined) => Effect.Effect<Result, never, R>;
export declare const executeProgram: <R>(code: string, prepared: ToolRuntime.Prepared<R>, limits: ResolvedExecutionLimits, hooks: ToolRuntime.Hooks<R>, globals?: Globals<R>, bindings?: Globals<R>, lossy?: boolean) => Effect.Effect<Result, never, R>;
/** A program ready to run on the VM: nothing runs until `run`. */
export declare const startProgram: <R>(setup: Setup<R>, code: string, bindings?: Globals<R>, runId?: string) => Running<R>;
/**
 * Restores a saved run into this runtime, under the limits it was saved with, ready to run as `startProgram`'s.
 * Fails with a `SnapshotError` when the state can't be read or belongs to another build, other host globals, or other
 * sources.
 */
export declare const resumeProgram: <R>(setup: Setup<R>, saved: Snapshot | Uint8Array | unknown) => Effect.Effect<Running<R>, SnapshotError>;
export declare const setRoundTrip: (enabled: boolean) => void;
/** One run's state: the runtime it is in now (restoring swaps it), its driver, and how much active time it used. */
export declare class Running<R> {
    private readonly setup;
    /** Active milliseconds used before this run, by earlier ones of the same execution. */
    private readonly activeBefore;
    private readonly prepare;
    private readonly resuming;
    private ctx;
    private driver;
    private startedAt;
    private finished;
    private suspended;
    private trips;
    private skip;
    private readonly started;
    private readonly done;
    constructor(setup: Setup<R>, 
    /** Active milliseconds used before this run, by earlier ones of the same execution. */
    activeBefore: number, prepare: () => Interpreter<R> | Result, resuming?: boolean);
    /** Makes the run's runtime and driver, then runs the program in the current fiber until it ends or is suspended. */
    run(): Effect.Effect<Outcome, never, R>;
    /**
     * Saves the run's state and stops it, at once: `run` then returns the same `Suspended`. It fails with a
     * `SuspendError`, leaving the run running, while a host call is in progress. A run that already ended gives its result.
     * Before the run has started, it waits for it.
     */
    suspend(maxBytes: number | undefined): Effect.Effect<Outcome, SuspendError>;
    private execute;
    private stop;
    /**
     * Saves the run's state, with no effect on the run: the calls that block a suspend, or the state as it is now. The
     * program shares this thread with the caller, so it is at a step boundary.
     */
    private save;
    private trip;
}
export declare const parseProgram: (code: string) => {
    ok: true;
    program: Program;
    source: Source;
} | {
    ok: false;
    error: Diagnostic;
};
export {};
