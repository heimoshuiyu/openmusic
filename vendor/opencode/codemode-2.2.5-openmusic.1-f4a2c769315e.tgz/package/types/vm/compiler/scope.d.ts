import type { AnyNode, ArrowFunctionExpression, FunctionDeclaration, FunctionExpression, Identifier, Pattern, Program } from "acorn";
import type { Source } from "../runtime/source.js";
type FunctionNode = Program | FunctionDeclaration | FunctionExpression | ArrowFunctionExpression;
type DeclKind = "var" | "let" | "const" | "function" | "param" | "catch" | "import" | "self" | "this" | "arguments";
export type Decl = {
    readonly name: string;
    readonly kind: DeclKind;
    readonly fnIndex: number;
    mutable: boolean;
    captured: boolean;
    used: boolean;
    slot: number;
    /** When a body `var` shares a name with a parameter or `arguments` in a separate `paramScope`. */
    copyFromParam?: Decl | undefined;
};
export declare class Scope {
    readonly parent: Scope | undefined;
    readonly decls: Map<string, Decl>;
    readonly hoistedFunctions: Array<{
        readonly node: FunctionDeclaration;
        fnIndex: number;
        readonly decl: Decl;
    }>;
    constructor(parent: Scope | undefined);
}
type UpvalueInfo = {
    /** `0` = parent's local cell slot, `1` = parent's upvalue index. */
    readonly from: 0 | 1;
    index: number;
    readonly decl: Decl;
};
export type FunctionInfo = {
    readonly index: number;
    readonly node: FunctionNode;
    readonly parentIndex: number;
    readonly name: string;
    flags: number;
    readonly length: number;
    readonly params: ReadonlyArray<Pattern>;
    readonly selfScope: Scope | undefined;
    readonly paramScope: Scope;
    readonly bodyScope: Scope;
    readonly allDecls: Array<Decl>;
    readonly upvalues: Array<UpvalueInfo>;
    readonly upvalueMap: Map<Decl, number>;
    thisDecl: Decl | undefined;
    argumentsDecl: Decl | undefined;
    locals: number;
    readonly localNames: Array<string>;
};
export type ResolvedRef = {
    readonly kind: "local";
    readonly decl: Decl;
} | {
    readonly kind: "upval";
    readonly upvalIndex: number;
    readonly decl: Decl;
} | {
    readonly kind: "global";
    readonly name: string;
};
export type ScopeAnalysis = {
    readonly functions: ReadonlyArray<FunctionInfo>;
    readonly nodeToFunction: ReadonlyMap<FunctionNode, FunctionInfo>;
    readonly scopeOfNode: ReadonlyMap<AnyNode, Scope>;
    readonly refs: ReadonlyMap<Identifier, ResolvedRef>;
    readonly thisRefs: ReadonlyMap<AnyNode, ResolvedRef>;
};
/**
 * Pass 1: walks the AST to build lexical/var scopes, assign pre-order function indices,
 * resolve all identifier and `this` references, mark captured bindings, and assign local/upvalue slots.
 */
export declare const analyzeScopes: (source: Source, internal?: boolean) => ScopeAnalysis;
export {};
