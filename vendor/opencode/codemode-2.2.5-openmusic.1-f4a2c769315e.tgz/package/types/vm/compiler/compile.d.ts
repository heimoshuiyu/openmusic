import { type Source } from "../runtime/source.js";
import { Code } from "../code.js";
/** Bump when the compiler emits different bytecode for the same source; it is part of the snapshot build id. */
export declare const COMPILER_VERSION = 1;
export type CompileOptions = {
    readonly internal?: boolean;
    readonly forceExtra?: boolean;
    readonly noCache?: boolean;
};
/**
 * Compiles a `Source` into an immutable `Code[]` array indexed by pre-order function index (`0` = program).
 */
export declare const compileSource: (source: Source, options?: CompileOptions) => ReadonlyArray<Code>;
