import type { Interruption } from "./runtime/signals.js";
import { type Source } from "./runtime/source.js";
import { type Header, type Snapshot } from "./snapshot/snapshot.js";
import { Vm } from "./vm.js";
export type CaptureOptions = {
    readonly limits?: Header["limits"];
    /** Active milliseconds used so far, across every resume. */
    readonly activeMs?: number;
    /** Throw on the first value with no data form, instead of reporting it in `lost`. */
    readonly strict: boolean;
};
export type RestoreOptions = {
    /** Parses a saved program source (cached by text). */
    readonly parse: (code: string) => Source;
    readonly interruption: () => Interruption;
};
/**
 * The VM build a snapshot belongs to: the package version, and a hash of the format, the opcode table, the frame
 * modes, the compiler version, the prelude's and the internal helpers' bytecode, the static intrinsic names, and the
 * codec's shape. A runtime must have been made first (the intrinsic names come from it).
 */
export declare const buildId: () => string;
/** Saves a VM's state as it is now, with every built-in or host global the run changed. Changes nothing. */
export declare const captureVm: (vm: Vm, options: CaptureOptions) => {
    readonly snapshot: Snapshot;
    readonly lost: ReadonlyArray<string>;
};
/**
 * Restores a saved state into `vm`, a fresh one made for a new runtime with the same host globals and no bindings,
 * after checking the snapshot belongs to this build, these host globals, its own sources and their bytecode.
 */
export declare const restoreVm: (vm: Vm, saved: unknown, options: RestoreOptions) => Snapshot;
