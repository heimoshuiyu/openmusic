export * as Data from "./data.js";
import type { Json } from "../data.js";
import type { Interpreter } from "./runtime/interpreter.js";
import { type Value } from "./runtime/objects.js";
export type { Json };
/** Host JSON as program values: objects and arrays are copied, primitives pass through. */
export declare const fromJson: <R>(ctx: Interpreter<R>, value: Json | undefined) => Value;
