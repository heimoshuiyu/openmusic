import type { DiagnosticKind } from "../codemode.js";
import type { ErrorType } from "./runtime/intrinsics.js";
/** Uninitialized lexical binding sentinel (temporal dead zone). */
export declare const HOLE: unique symbol;
/** Mutable box for a binding captured by a closure. */
export declare class Cell {
    v: unknown;
    constructor(v: unknown);
}
export declare const EMPTY_CELLS: ReadonlyArray<Cell>;
/** Raised when the VM compiler or runtime encounters a feature scheduled for a later phase. */
export declare class NotYetImplemented extends Error {
    readonly feature: string;
    constructor(feature: string);
}
/**
 * Bytecode opcodes (1 word per instruction: `op:8 | a:8 | bx:16`, widened by `EXTRA` prefixes for `a > 0xff` or `bx > 0xffff`).
 */
export declare const Op: {
    readonly PUSH_UNDEF: 0;
    readonly PUSH_NULL: 1;
    readonly PUSH_BOOL: 2;
    readonly PUSH_INT: 3;
    readonly PUSH_CONST: 4;
    readonly POP: 5;
    readonly POPN: 6;
    readonly DUP: 7;
    readonly PICK: 8;
    readonly ROT: 9;
    readonly GET_LOCAL: 10;
    readonly PUT_LOCAL: 11;
    readonly HOLE_LOCAL: 12;
    readonly NEW_CELL: 13;
    readonly COPY_CELL: 14;
    readonly GET_CELL: 15;
    readonly PUT_CELL: 16;
    readonly GET_UPVAL: 17;
    readonly PUT_UPVAL: 18;
    readonly GET_GLOBAL: 19;
    readonly GET_INTRINSIC: 20;
    readonly ARGS: 21;
    readonly CLOSURE: 22;
    readonly SET_NAME: 23;
    readonly IMPORT: 24;
    readonly GET_PROP: 25;
    readonly GET_ELEM: 26;
    readonly PUT_PROP: 27;
    readonly PUT_ELEM: 28;
    readonly DELETE_PROP: 29;
    readonly DELETE_ELEM: 30;
    readonly CHECK_BASE: 31;
    readonly TO_KEY: 32;
    readonly IN: 33;
    readonly INSTANCEOF: 34;
    readonly NEW_OBJECT: 35;
    readonly NEW_ARRAY: 36;
    readonly ARRAY_APPEND: 37;
    readonly DEFINE_FIELD: 38;
    readonly COPY_DATA_PROPS: 39;
    readonly COPY_REST: 40;
    readonly TEMPLATE: 41;
    readonly REGEXP: 42;
    readonly ADD: 43;
    readonly SUB: 44;
    readonly MUL: 45;
    readonly LT: 46;
    readonly LE: 47;
    readonly GT: 48;
    readonly GE: 49;
    readonly SEQ: 50;
    readonly SNE: 51;
    readonly BINOP: 52;
    readonly UNARY: 53;
    readonly NOT: 54;
    readonly TO_NUMERIC: 55;
    readonly INC: 56;
    readonly TO_STRING: 57;
    readonly CONCAT: 58;
    readonly JUMP: 59;
    readonly LOOP: 60;
    readonly JUMP_IF_FALSE: 61;
    readonly JUMP_IF_TRUE: 62;
    readonly JUMP_COND: 63;
    readonly THROW: 64;
    readonly THROW_ERROR: 65;
    readonly END_FINALLY: 66;
    readonly RETURN: 67;
    readonly NOP: 68;
    readonly EXTRA: 69;
    readonly CALL: 70;
    readonly CALL_SPREAD: 71;
    readonly NEW: 72;
    readonly NEW_SPREAD: 73;
    readonly ITER_OPEN: 74;
    readonly ITER_INIT: 75;
    readonly ITER_STEP: 76;
    readonly ITER_RESULT: 77;
    readonly ITER_CLOSE: 78;
    readonly ITER_APPEND_ALL: 79;
    readonly FOR_IN: 80;
    readonly GENERATOR_START: 81;
    readonly YIELD: 82;
    readonly RESUME: 83;
    readonly AWAIT: 84;
    readonly YSTAR: 85;
    readonly YSTAR_RESULT: 86;
    readonly END_PROGRAM: 87;
};
export type OpCode = (typeof Op)[keyof typeof Op];
export declare const OpNames: ReadonlyArray<string>;
/** Sub-ops for `Op.BINOP` (`a` operand). */
export declare const BinOp: {
    readonly DIV: 0;
    readonly MOD: 1;
    readonly EXP: 2;
    readonly BAND: 3;
    readonly BOR: 4;
    readonly BXOR: 5;
    readonly SHL: 6;
    readonly SAR: 7;
    readonly SHR: 8;
    readonly EQ: 9;
    readonly NE: 10;
};
export declare const BinOpSymbols: ReadonlyArray<string>;
/** Sub-ops for `Op.UNARY` (`a` operand). */
export declare const UnaryOp: {
    readonly NEG: 0;
    readonly PLUS: 1;
    readonly BNOT: 2;
    readonly TYPEOF: 3;
    readonly VOID: 4;
};
export declare const UnaryOpSymbols: ReadonlyArray<string>;
/** Sub-ops for `Op.JUMP_COND` (`a` operand). */
export declare const CondKind: {
    /** If top is truthy, keep it and jump; else pop and fall through (`||`, `||=`). */
    readonly TRUTHY_KEEP: 0;
    /** If top is falsy, keep it and jump; else pop and fall through (`&&`, `&&=`). */
    readonly FALSY_KEEP: 1;
    /** If top is not null/undefined, keep it and jump; else pop and fall through (`??`, `??=`). */
    readonly NOT_NULLISH_KEEP: 2;
    /** If top !== undefined, keep it and jump; else pop and fall through (defaults). */
    readonly DEFINED: 3;
    /** If top == null, replace top with undefined and jump; else keep top and fall through (`?.`). */
    readonly NULLISH: 4;
    /** For `[thisValue, callable]`: if callable == null, pop callable, set top to undefined, and jump (`o.m?.()`). */
    readonly NULLISH_METHOD: 5;
};
/** Sub-ops for `Op.PUT_LOCAL`, `Op.PUT_CELL`, `Op.PUT_UPVAL` (`a` operand). */
export declare const PutKind: {
    /** Normal assignment: checks TDZ (`HOLE`). */
    readonly ASSIGN: 0;
    /** Declaration initialization or internal slot write: skips TDZ check. */
    readonly INIT: 1;
    /** Assignment to a `const` or read-only binding: checks TDZ first, then throws `TypeError`. */
    readonly CONST: 2;
};
/** Sub-ops for `Op.CHECK_BASE` (`a` operand). */
export declare const CheckBaseKind: {
    /** `o[k]`: checks `o` is not null/undefined before converting `k` (`[o, k] -> [o, k]`). */
    readonly READ: 0;
    /** `o.x = ...`: checks `o.x` is a writable reference (`[o] -> [o]`, `bx = k`). */
    readonly WRITE_PROP: 1;
    /** `o[k] = ...`: checks `o[k]` is a writable reference after `TO_KEY` (`[o, key] -> [o, key]`). */
    readonly WRITE_ELEM: 2;
    /** Destructuring target check: throws if top is null or undefined (`[v] -> [v]`). */
    readonly DESTRUCTURE: 3;
};
/** Sub-ops for `Op.ITER_OPEN` and `Op.ITER_INIT` (`a` operand). */
export declare const IterContext: {
    readonly FOR_OF: 0;
    readonly DESTRUCTURE: 1;
    readonly SPREAD: 2;
    readonly DELEGATE: 3;
    readonly FOR_AWAIT: 4;
    readonly ASYNC_DELEGATE: 5;
    readonly CHECK_OBJECT: 6;
};
/** Sub-ops for `Op.IMPORT` (`a` operand). */
export declare const ImportKind: {
    readonly DEFAULT: 0;
    readonly NAMESPACE: 1;
    readonly NAMED: 2;
    readonly SIDE_EFFECT: 3;
    readonly DYNAMIC: 4;
};
/** Bit flags on `Code.flags`. */
export declare const CodeFlags: {
    readonly ARROW: number;
    readonly ASYNC: number;
    readonly GENERATOR: number;
    readonly SIMPLE_PARAMS: number;
    readonly USES_THIS: number;
    readonly USES_ARGUMENTS: number;
    readonly INTERNAL: number;
    readonly PROGRAM: number;
    readonly NEEDS_ARGS: number;
};
/** Constant pool descriptors. */
export type TemplateSite = {
    readonly cooked: ReadonlyArray<string | undefined>;
    readonly raw: ReadonlyArray<string>;
    readonly nodeIndex: number;
};
export type RegExpSite = {
    readonly pattern: string;
    readonly flags: string;
};
export type ErrorSite = {
    readonly type: ErrorType;
    readonly message: string;
    readonly kind?: DiagnosticKind;
    readonly suggestions?: ReadonlyArray<string>;
};
export type ImportSite = {
    readonly specifier: string;
    readonly imported?: string;
};
export type ConstValue = string | number | TemplateSite | RegExpSite | ErrorSite | ImportSite;
/** Packs one instruction word: `op:8 | a:8 | bx:16`. Throws if any field does not fit its width. */
export declare const packWord: (op: OpCode, a?: number, bx?: number) => number;
