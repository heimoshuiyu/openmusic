import { type Json } from "./data.js";
import type { Builtins } from "./runtime/intrinsics.js";
import { type NativeResult, type Value } from "./runtime/objects.js";
import type { Code } from "./code.js";
import { type Vm } from "./vm.js";
/**
 * Lightweight internal callable for VM-only `$` intrinsics. Does not extend `Obj` or `Native`,
 * so it never touches `builtins.Function`, `nativeRule.sealed`, or static intrinsic numbering.
 */
export declare class VmIntrinsic {
    readonly name: string;
    readonly call: (args: Array<Value>) => NativeResult;
    constructor(name: string, call: (args: Array<Value>) => NativeResult);
}
export declare const INTERNAL_SOURCE: string;
/** The VM's internal helpers' bytecode, and their functions' code by name. */
export declare const getInternalPrelude: () => {
    codes: readonly Code[];
    byName: Map<string, Code>;
};
/** The code of the internal helper `name`. */
export declare const internalCode: (name: string) => Code;
/**
 * Adds the intrinsics available to `CodeFlags.INTERNAL` functions (both `@prelude` and `@vm-internal`) to `map`: the
 * internal helpers, and the `$` natives. Uses `VmIntrinsic` rather than `Native` so it never touches
 * `builtins.Function` or `nativeRule.sealed`.
 */
export declare const registerVmIntrinsics: (map: Map<string, unknown>, vm: Vm) => void;
/**
 * Budgeted native fast path for copying plain data at the host boundary (`boundary`) or for `JSON.stringify`. Returns
 * `{ ok: true, json }` if the tree has no custom `toJSON`, promises, or shared references revisited more than `budget`
 * times; otherwise the prelude walk (`$vmJsonWalk`) does the work, ticking fuel.
 *
 * Both give the text `JSON.stringify` would: `toJSON` is honored, functions and `undefined` vanish, non-finite numbers
 * become null, and everything else is copied. Two departures from JS so a mistake is not a silent `{}`: an Error
 * serializes as `{ name, message, ...own }`, and a promise throws. At the host boundary a promise is awaited, a Set
 * crosses as an array, a URLSearchParams as its query string, a Uint8Array asks to be encoded as text first, and a
 * `__proto__` key is dropped so host code can never receive one.
 */
export declare const tryFastBoundaryOrJson: (builtins: Builtins, value: Value, boundary: boolean, revisitBudget?: number) => {
    readonly ok: true;
    readonly json: Json | undefined;
} | {
    readonly ok: false;
};
