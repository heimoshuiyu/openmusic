import { Obj, type Value } from "../runtime/objects.js";
import type { Interpreter } from "../runtime/interpreter.js";
/** Captured console: every method appends one formatted line to `logs`. */
export declare const consoleGlobal: <R>(ctx: Interpreter<R>) => Obj;
/** One value as `console.log` shows it. */
export declare const formatValue: (value: Value) => string;
