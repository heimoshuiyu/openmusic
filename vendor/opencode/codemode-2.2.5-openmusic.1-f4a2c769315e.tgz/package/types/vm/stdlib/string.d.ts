import type { Interpreter } from "../runtime/interpreter.js";
export declare const stringGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
