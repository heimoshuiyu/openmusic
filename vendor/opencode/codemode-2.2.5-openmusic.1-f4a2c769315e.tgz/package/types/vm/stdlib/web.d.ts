import { Obj } from "../runtime/objects.js";
import type { Interpreter } from "../runtime/interpreter.js";
export declare const base64Global: <R>(ctx: Interpreter<R>, name: "atob" | "btoa") => import("../runtime/objects.js").Native;
export declare const structuredCloneGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
export declare const cryptoGlobal: <R>(ctx: Interpreter<R>) => Obj;
