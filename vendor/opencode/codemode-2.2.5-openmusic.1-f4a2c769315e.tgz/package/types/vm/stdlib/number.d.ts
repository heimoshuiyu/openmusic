import type { Interpreter } from "../runtime/interpreter.js";
export declare const numberGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
export declare const booleanGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
