import type { Interpreter } from "../runtime/interpreter.js";
import { Obj } from "../runtime/objects.js";
export declare const jsonGlobal: <R>(ctx: Interpreter<R>) => Obj;
