import type { Interpreter } from "../runtime/interpreter.js";
export declare const iteratorGlobals: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
