import type { Interpreter } from "../runtime/interpreter.js";
export declare const dateGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
