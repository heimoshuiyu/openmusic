import { Obj, type Value } from "../runtime/objects.js";
import type { Interpreter } from "../runtime/interpreter.js";
export declare const finishBytes: (bytes: Uint8Array, into: Obj, offset: number) => Value;
export declare const uint8ArrayGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
export declare const textEncoderGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
/** A `TextDecoder` holding the host decoder its label and options configured. */
export declare class TextDecoderObj extends Obj {
    readonly decoder: TextDecoder;
    constructor(proto: Obj, decoder: TextDecoder);
}
export declare const textDecoderGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
