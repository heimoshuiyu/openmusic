import { Invoke } from "../runtime/signals.js";
import type { Builtins } from "../runtime/intrinsics.js";
import { Arr, Bytes, type Value } from "../runtime/objects.js";
import type { Interpreter } from "../runtime/interpreter.js";
/** Where a sort puts its result: back into an array or bytes, or into a new array. */
export type SortInto = "Array.sort" | "Array.toSorted" | "Uint8Array.sort";
/** The most values the default sort sorts in one native call; more sort in bounded steps (see `sortDefault`). */
export declare const SORT_RUN = 4096;
/**
 * Sorts `target`'s values: at once without a comparator, unless there are many, otherwise in the prelude
 * (`sortWith`), which calls it. The merges of a top-down merge sort are planned here, in post-order, so the prelude
 * compares in the same order as the recursive sort. Holes and undefined values sort last without being compared.
 */
export declare const sortArray: <R>(ctx: Interpreter<R>, target: Arr | Bytes, comparator: Value, into: SortInto) => Value | Invoke;
export declare const sorted: (builtins: Builtins, target: Arr | Bytes, into: SortInto, holes: number, result: Array<Value>) => Arr | Bytes;
export declare const arrayGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
