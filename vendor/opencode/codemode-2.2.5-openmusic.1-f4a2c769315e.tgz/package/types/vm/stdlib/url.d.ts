import { Invoke } from "../runtime/signals.js";
import { Obj, type Callable, type Value } from "../runtime/objects.js";
import type { Interpreter } from "../runtime/interpreter.js";
type UriFunction = "encodeURI" | "encodeURIComponent" | "decodeURI" | "decodeURIComponent";
export declare const uriGlobal: <R>(ctx: Interpreter<R>, name: UriFunction) => import("../runtime/objects.js").Native;
export declare const urlGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
/** What `readPairs` builds from `[name, value]` pairs, or from a record of names to values when `init` is no iterable. */
export type PairsInto = {
    readonly kind: "Headers" | "URLSearchParams";
    readonly proto: Obj;
};
/**
 * Reads a synchronous iterable of `[name, value]` pairs as strings (in the prelude), then builds `into` from them; a
 * record of names to values when `init` is not iterable. As in WebIDL, the whole sequence is converted before any
 * pair's length is checked.
 */
export declare const readPairs: <R>(ctx: Interpreter<R>, init: Value, label: string, into: PairsInto) => Invoke;
/** What `readPairs` makes of the pairs it read (an array of arrays of strings), or of a record. */
export declare const buildPairs: (into: PairsInto, value: Value, label: string) => Value;
/** The host validates header names and values and throws its own TypeError; the program gets one of its own. */
export declare const attempt: <T>(run: () => T) => T;
/** Headers and URLSearchParams `forEach`: the callback sees each `[name, value]` pair as listed when it started. */
export declare const pairsForEach: <R>(ctx: Interpreter<R>, target: Value, pairs: Array<[string, string]>, callback: Callable, thisArg: Value) => Invoke;
export declare const urlSearchParamsGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
export {};
