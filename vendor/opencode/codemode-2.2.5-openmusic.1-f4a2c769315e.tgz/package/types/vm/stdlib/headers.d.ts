import type { Interpreter } from "../runtime/interpreter.js";
export declare const headersGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
