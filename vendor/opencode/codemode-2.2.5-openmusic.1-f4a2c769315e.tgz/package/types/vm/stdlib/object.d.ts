import { type AstNode } from "../runtime/model.js";
import { Obj, type Value } from "../runtime/objects.js";
import type { Interpreter } from "../runtime/interpreter.js";
export declare const enumerableSource: <R>(ctx: Interpreter<R>, label: string, value: Value, node?: AstNode) => Obj;
export declare const objectAssign: <R>(ctx: Interpreter<R>, args: Array<Value>) => Value;
export declare const objectGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
