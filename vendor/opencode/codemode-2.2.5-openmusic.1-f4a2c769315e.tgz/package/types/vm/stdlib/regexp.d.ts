import type { Builtins } from "../runtime/intrinsics.js";
import { Arr, Obj, RegExpObj, type Value } from "../runtime/objects.js";
import type { Interpreter } from "../runtime/interpreter.js";
/** Runs host regex work on a RegExp argument, sharing its `lastIndex`, or on a pattern string compiled for the call. */
export declare const withHostRegex: <T>(arg: Value, method: string, extraFlags: string, work: (regex: RegExp) => T) => T;
export declare const matchToValue: (builtins: Builtins, match: RegExpMatchArray) => Arr;
export declare const constructRegExp: (builtins: Builtins, args: Array<Value>, proto?: Obj) => RegExpObj;
export declare const regexpGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
