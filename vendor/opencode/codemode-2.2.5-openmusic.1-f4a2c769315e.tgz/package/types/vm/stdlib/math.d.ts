import { Obj } from "../runtime/objects.js";
import type { Interpreter } from "../runtime/interpreter.js";
export declare const mathGlobal: <R>(ctx: Interpreter<R>) => Obj;
