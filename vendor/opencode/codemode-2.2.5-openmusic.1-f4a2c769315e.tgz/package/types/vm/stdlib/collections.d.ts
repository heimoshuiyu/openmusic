import { Obj, type Value } from "../runtime/objects.js";
import type { Interpreter } from "../runtime/interpreter.js";
export declare const mapGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
export declare const setGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
export declare const weakKey: (value: Value, label: string) => Obj;
export declare const weakMapGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
export declare const weakSetGlobal: <R>(ctx: Interpreter<R>) => import("../runtime/objects.js").Native;
