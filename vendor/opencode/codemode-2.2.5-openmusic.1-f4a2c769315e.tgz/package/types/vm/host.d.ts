import type { Diagnostic } from "../codemode.js";
import { type Json } from "./data.js";
import type { Interpreter } from "./runtime/interpreter.js";
import { type AstNode } from "./runtime/model.js";
import { PromiseObj, type Value } from "./runtime/objects.js";
import type { Completion } from "./runtime/signals.js";
import { type ExtensionRequest, HostCall, type HostRequest, Resolving } from "./scheduler.js";
import type { Code } from "./code.js";
import { type FrameMode, type Vm } from "./vm.js";
/** What host calls need from the promise scheduler. */
export type Promises = {
    newPromise(): PromiseObj;
    resolving(promise: PromiseObj, site?: AstNode): Resolving;
    /** Unhandled rejections, in promise creation order. */
    diagnostics(): Array<Diagnostic>;
};
/** A native's answer asking the VM to stop the job until the blocking host call it queued completes. */
export declare const BLOCK: unique symbol;
/** A host operation pushed an internal frame that produces its result. */
export declare const ENTERED: unique symbol;
export type HostResult = Value | typeof BLOCK | typeof ENTERED;
/** What the VM gives host operations: its runtime, and a way to run an internal prelude function at the call. */
export type HostVm = {
    readonly ctx: Interpreter<unknown>;
    /**
     * Runs an internal prelude function at the call `origin`; its result is the call's. In another `mode` than `CALLER`,
     * it settles `target`, and the call's result is `answer`: in `REJECT_ONLY` mode, a failure in it rejects `target`.
     */
    pushInternal(code: Code, args: ReadonlyArray<unknown>, origin: AstNode | undefined, mode?: FrameMode, target?: unknown, answer?: Value): unknown;
};
type Delivery = {
    readonly call: HostCall;
    readonly completion: Completion;
};
/** Visited nodes a native fast path may spend before it hands the work to the prelude walk, which slices. */
export declare const VISIT_BUDGET = 2048;
/**
 * The host calls of one run: queued (written ahead, for the driver to start at the next stop), running, completed and
 * waiting in the inbox, and the blocking call the current job waits on. Ids count up in program order.
 */
export declare class HostCalls {
    private readonly ctx;
    readonly promises: Promises;
    /** Names this run's host calls (`<runId>:<callId>`). */
    runId: string;
    queued: Array<HostCall>;
    readonly running: Map<number, HostCall>;
    readonly inbox: Array<Delivery>;
    nextID: number;
    /** The blocking call the job on the stack waits on. */
    blocked: HostCall | undefined;
    /** A completed blocking call's outcome, which continues the job on the stack before anything else runs. */
    input: {
        readonly call: HostCall;
        readonly completion: Completion;
    } | undefined;
    /** The synchronous extension call the program is in the middle of: see `Vm.activeExtension`. */
    extension: {
        readonly key: string;
        readonly path: string;
    } | undefined;
    extensionResume: ((completion: Completion) => HostResult) | undefined;
    constructor(ctx: Interpreter<unknown>, promises: Promises);
    /** Queues concurrent host work; `resolving` settles its promise in a later job, in completion order. */
    host(request: HostRequest, call: {
        readonly label: string;
        readonly result: "json" | "value";
        readonly resolving: Resolving;
        readonly site: AstNode | undefined;
    }): HostCall;
    /** Queues blocking `search` work: the job stops until it completes, then continues with its result. */
    blockSearch(args: Array<Json | undefined>): typeof BLOCK;
    /** Queues blocking extension work: the job stops until it completes, then continues with `resume`. */
    blockExtension(call: ExtensionRequest, resume: (completion: Completion) => HostResult): typeof BLOCK;
    private block;
    private queue;
    /** Continues the job stopped at a blocking call with its outcome. */
    resume(input: {
        readonly call: HostCall;
        readonly completion: Completion;
    }): HostResult;
    /** Hands the queued calls to the driver: they are running from now on. */
    handOver(): Array<HostCall>;
    complete(id: number, completion: Completion): void;
    /** Settles the oldest completed concurrent call's promise; false when the inbox is empty. */
    deliver(): boolean;
}
/**
 * A tool call returns its promise at once. Plain-data arguments cross on the native fast path; anything else
 * (`toJSON`, a promise, a deep or shared value) crosses through `$vmCross` at the call, which queues the call with the
 * same `Resolving` or rejects it. Either way the call is queued once its arguments have crossed, and the driver starts
 * it before any other job runs.
 */
export declare const callTool: (vm: HostVm, hosts: HostCalls, path: ReadonlyArray<string>, args: Array<Value>, site: AstNode | undefined) => HostResult;
/** `search(...)`: blocking; its result can be used directly, or awaited and chained like a Promise. */
export declare const callSearch: (vm: HostVm, hosts: HostCalls, args: Array<Value>, site: AstNode | undefined) => HostResult;
/**
 * A synchronous extension function's call, staged here so its host values never enter a frame: the `extension.before`
 * hook (blocking), then the host function; what it returns settles now (blocking) unless it is an Effect or a Promise,
 * which the program holds a promise for. The call is active, holding live host values, until its result is a program
 * value or its concurrent call is queued.
 */
export declare const callExtension: (ctx: Interpreter<unknown>, hosts: HostCalls, slots: ReadonlyArray<unknown>, site: AstNode | undefined) => HostResult;
/** The intrinsics the boundary walk calls to queue a tool or search host call. */
export declare const registerHostIntrinsics: (map: Map<string, unknown>, vm: Vm) => void;
export {};
