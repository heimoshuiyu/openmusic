import type { Diagnostic } from "../codemode.js";
import type { Interpreter } from "./runtime/interpreter.js";
import { type AstNode } from "./runtime/model.js";
import { Arr, Fn, Obj, type Value } from "./runtime/objects.js";
import { type Completion } from "./runtime/signals.js";
import { Source } from "./runtime/source.js";
import type { HostCall, Stop } from "./scheduler.js";
import { VmScheduler } from "./async.js";
import type { Code } from "./code.js";
import { type CaptureOptions, type RestoreOptions } from "./snapshot.js";
import { HostCalls } from "./host.js";
import { Cell } from "./opcodes.js";
export declare const Mode: {
    readonly CALLER: 0;
    readonly ASYNC: 1;
    readonly GENERATOR: 2;
    readonly SETTLE: 3;
    readonly REJECT_ONLY: 4;
    readonly PROGRAM: 5;
    readonly BOUNDARY_OUT: 6;
};
export type FrameMode = (typeof Mode)[keyof typeof Mode];
/** Custom synchronous/async iterator state stored in a frame's hidden `%it` slot. */
export declare class CustomIter {
    readonly iterator: Obj;
    readonly next: Value;
    done: boolean;
    rawGen: boolean;
    constructor(iterator: Obj, next: Value);
}
/** Single uniform activation record for the bytecode VM. */
export declare class Frame {
    fn: Fn | null;
    cells: ReadonlyArray<Cell>;
    code: Code;
    pc: number;
    sp: number;
    regs: Array<unknown>;
    thisValue: Value;
    args: Array<Value> | undefined;
    mode: FrameMode;
    target: unknown;
    answer: unknown;
    origin: AstNode | undefined;
    counted: boolean;
    constructor(code: Code, regs: Array<unknown>);
}
/** Internal closure wrapper that does not touch `builtins.Function` or `nativeRule.sealed`. */
export declare class VmInternalFn {
    readonly code: Code;
    readonly boundArgs?: ReadonlyArray<Value> | undefined;
    constructor(code: Code, boundArgs?: ReadonlyArray<Value> | undefined);
}
/**
 * Runs a runtime's program code: the job stack, the job queue, promises, and host calls. `execute.ts` and the driver
 * use only its host surface:
 *
 * - **Starting.** Exactly one of `start(source)` (a new run) or `restore(saved, …)` (a saved one), once. Host call
 *   ids count up in program order.
 * - **Running.** `run()` is synchronous, runs no host work, and returns a `Stop`:
 *   - `host(calls)`: start these queued calls now (they are `queued`; the driver marks them `running`),
 *     then call `run()` again; `host([])` means wait until `ready` (a blocking call or the inbox has input) and call
 *     `run()` again;
 *   - `slice`: the time slice is over; yield to the host scheduler and call `run()` again;
 *   - `done(completion)`: the program's body ended; host calls may still be running (`diagnostics()` reports
 *     unhandled rejections);
 *   - `stuck(node)`: nothing is queued or running, and the body awaits something that can never settle.
 * - **Host calls.** `complete(id, completion)` reports how a handed-over call ended, at any time between `run()`s: a
 *   blocking call's outcome continues the job that made it; a concurrent call's waits in the inbox and settles its
 *   promise in a later job, in completion order. Unknown or completed ids are ignored. `call(id)`/`calls()` list the
 *   calls handed over and not completed, in the order they were made.
 * - **Snapshots.** `capture` and `restore` run only between `run()`s, synchronously. A capture changes nothing a
 *   later `run()` sees; it fails (throws) only on a codec gap. A state holding live host values (`calls()` with an
 *   extension call, or `activeExtension`) can't be restored faithfully.
 */
export declare class Vm {
    readonly ctx: Interpreter<unknown>;
    readonly frames: Array<Frame>;
    private readonly pool;
    readonly sourceCodes: Map<string, readonly Code[]>;
    readonly templates: Map<string, Arr>;
    readonly intrinsics: Map<string, unknown>;
    readonly scheduler: VmScheduler;
    /** Host calls: queued, running, completed, and the blocking one the job on the stack waits on. */
    readonly hosts: HostCalls;
    depth: number;
    fuel: number;
    /** When the current slice began; -1 until the next `run` starts one. Host stops don't end a slice, only a yield does. */
    sliceStart: number;
    sliced: boolean;
    outcome: Completion | undefined;
    /** Round-trip test mode (task C): slice after this many fuel ticks, so the run is saved and restored all through. */
    tripEvery: number;
    constructor(ctx: Interpreter<unknown>);
    private initIntrinsics;
    private getIntrinsic;
    /** Queues the program's body as the root frame. */
    start(source: Source): void;
    /**
     * Runs until it has to stop (`Stop`), in this order: hand over queued host calls; a due slice; continue the job a
     * completed blocking call waits on; wait while the job on the stack is blocked; continue a sliced job before any
     * other; the outcome; the next job; one inbox completion; wait for running calls; stuck.
     */
    run(): Stop;
    private resumeBlocked;
    /** Reports how host work handed over by a `host` stop ended. */
    complete(id: number, completion: Completion): void;
    /** Whether `run` has something to do: a blocking call's outcome, or one in the inbox while no job runs. */
    get ready(): boolean;
    /** A host call handed over and not yet completed, by id. */
    call(id: number): HostCall | undefined;
    /** The host calls handed over and not yet completed, in the order they were made. */
    calls(): Array<HostCall>;
    compact(): void;
    /** Unhandled rejections, in promise creation order, once inbox completions are delivered. */
    diagnostics(): Array<Diagnostic>;
    /**
     * A synchronous extension call the program is in the middle of, from its `before` hook until its result is a
     * program value or its concurrent call is running: it holds live host values.
     */
    get activeExtension(): {
        readonly key: string;
        readonly path: string;
    } | undefined;
    /** Saves the run's state as it is now. */
    capture(options: CaptureOptions): {
        readonly snapshot: import("./index.js").Snapshot;
        readonly lost: ReadonlyArray<string>;
    };
    /** Restores a saved state into this fresh VM, after checking it belongs to this build and runtime. */
    restore(saved: unknown, options: RestoreOptions): import("./index.js").Snapshot;
    deliverAnswer(frame: Frame): void;
    acquire(code: Code): Frame;
    release(frame: Frame): void;
    private codesOf;
    /**
     * Nearest non-internal frame's AST site, or the bottom internal frame's `origin` (§3.6). A failure the host
     * boundary's own walk raises (copying out the result, or a tool call's arguments) has no location: the call that
     * crosses reports it.
     */
    currentSite(): AstNode | undefined;
    private exec;
    private copyParams;
    private failCallDepth;
    private failStringLength;
    private execInstanceof;
    private execBinopSlow;
    private execThrow;
    private execForIn;
    private onGeneratorStart;
    private onYield;
    private onResume;
    private onAwait;
    private onYstar;
    private onYstarResult;
    private failOpcode;
    private execRot;
    private failTdz;
    private failPut;
    private execGetGlobal;
    private execArgs;
    private execSetName;
    private execToKey;
    private execIn;
    private execNewArray;
    private execArrayAppend;
    private execDefineField;
    private execCopyDataProps;
    private execCopyRest;
    private execRegExp;
    private execBinopNum;
    private execToNumericSlow;
    private execIncSlow;
    private execToStringSlow;
    private execConcat;
    private execThrowError;
    private execEndFinally;
    private execReturnSlow;
    private execCallSpread;
    private execNew;
    private execNewSpread;
    private execIterStepSlow;
    private execIterResult;
    private execIterClose;
    private execIterAppendAll;
    private readObjProp;
    unwind(rawError: unknown): boolean;
    private finishProgram;
    private makeClosure;
    private getTemplateObject;
    private execImport;
    private execGetProp;
    private execGetElem;
    private readMember;
    private resolveMember;
    private execPutProp;
    private execPutElem;
    private execDeleteProp;
    private execDeleteElem;
    private execCheckBase;
    private execBinarySlow;
    private execUnarySlow;
    private execCallSlow;
    /**
     * Dispatches a call to `callee`. Returns `0` if synchronous value pushed, `1` if a frame was entered, `2` if the job
     * blocks on a host call.
     */
    private invokeCallable;
    private execConstruct;
    private settleNativeResult;
    private hostResult;
    /**
     * Enters the program function `fn`, from the call at `origin`. A frame in another `mode` than `CALLER` settles
     * `target`, and hands the caller `answer` when it ends.
     */
    pushFn(fn: Fn, thisValue: Value, args: Array<Value>, origin: AstNode | undefined, mode: FrameMode, target?: unknown, answer?: Value): void;
    private pushInternalCall;
    /** Runs an internal prelude function at the call `origin`; see `HostVm.pushInternal`. */
    pushInternal(code: Code, args: ReadonlyArray<unknown>, origin: AstNode | undefined, mode?: FrameMode, target?: unknown, answer?: Value): Frame;
    private execIterOpen;
    private execIterInit;
    private openWithMethod;
    private customIter;
    private execExtra;
    private execWide;
}
