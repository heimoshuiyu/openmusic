import { type AstNode } from "../runtime/model.js";
import { Native, Obj } from "../runtime/objects.js";
import { Interruption } from "../runtime/signals.js";
/** A plain JSON value, as a snapshot holds it. */
export type Json = null | boolean | number | string | ReadonlyArray<Json> | {
    readonly [key: string]: Json;
};
/**
 * A value inside a record: a JSON primitive, or a tag (an array whose first item says what it is):
 * - `["u"]` undefined, `["n", "NaN" | "Infinity" | "-Infinity" | "-0"]` a number JSON cannot spell, `["-"]` an absent
 *   field, `["h"]` an array hole;
 * - `["s", name]` an interpreter symbol;
 * - `["i", name]` a built-in or host global, unchanged since the runtime was made;
 * - `["a", source, index]` an AST node (a call site, an error's location);
 * - `["x", data]` something the engine names itself (the VM's compiled code, by source and function index);
 * - `["r", id]` another record.
 */
export type Encoded = string | number | boolean | null | ReadonlyArray<Json>;
/** One object of the graph. `t` says how to read the rest. */
export type Record = {
    readonly t: string;
    readonly [field: string]: Json;
};
/** A saved state can't be read, or doesn't fit this runtime. */
import { SnapshotError } from "../../suspend-error.js";
export { SnapshotError };
/**
 * Where a function inside a value an extension returned came from, so a saved state can name it instead of losing it:
 * the extension, the value its function returned (`root`), which the extension's `snapshot` hooks save, and the path
 * from there to the function.
 */
export type HostOrigin = {
    readonly extension: string;
    readonly root: object;
    readonly path: ReadonlyArray<string | number>;
    /** What the program calls it, for its errors (`fetch.text`). */
    readonly label: string;
};
/** The extension bridge's side of saving and restoring those functions; see `extensionGlobals`. */
export type HostBridge = {
    /** Each extension's name, and whether it has `snapshot` hooks: a state resumes only where both match. */
    readonly extensions: ReadonlyArray<{
        readonly name: string;
        readonly hooked: boolean;
    }>;
    /** Where a program function wrapping a host function came from, when its extension can save it. */
    readonly origin: (value: object) => HostOrigin | undefined;
    /** A returned value as its extension saves it. */
    readonly encode: (extension: string, root: object) => unknown;
    /** A returned value back from what `encode` gave. */
    readonly decode: (extension: string, data: unknown) => object;
    /** Makes `target`, a restored program function, call the host function `origin` leads to. */
    readonly rewrap: (target: Native, origin: HostOrigin) => void;
};
/** What the encoder asks of the runtime whose state it saves. */
export type EncodeEnv = {
    /** The name of a built-in or host global object. */
    readonly nameOf: (value: Obj) => string | undefined;
    /** Whether a named object is still as the runtime made it, so its name alone restores it. */
    readonly unchanged: (value: Obj) => boolean;
    /** The anchors: objects the restored runtime already has, filled in place (the VM, its scheduler, ...). */
    readonly anchorOf: (value: object) => string | undefined;
    readonly nodeId: (node: AstNode) => readonly [source: string, index: number] | undefined;
    /** Values with no data form are reported here; strict encoding throws on the first instead. */
    readonly lost: Array<string>;
    readonly strict: boolean;
    readonly hosts?: HostBridge | undefined;
    /** More classes to save, an engine's own (the VM's frames and closures), after the built-in ones. */
    readonly specs?: ReadonlyArray<ClassSpec> | undefined;
    /** The data an engine names an object or symbol by, saved as `["x", data]`, instead of copying it. */
    readonly external?: ((value: object | symbol) => Json | undefined) | undefined;
};
/** What the decoder asks of the fresh runtime it restores into. */
export type DecodeEnv = {
    readonly named: (name: string) => Obj | undefined;
    readonly anchor: (name: string) => object | undefined;
    readonly node: (source: string, index: number) => AstNode | undefined;
    /** An `Interruption` (it holds an Effect cause, which this module does not make). */
    readonly interruption: () => Interruption;
    readonly hosts?: HostBridge | undefined;
    readonly specs?: ReadonlyArray<ClassSpec> | undefined;
    /** What `EncodeEnv.external` named. */
    readonly external?: ((data: Json) => unknown) | undefined;
};
/** How one class saves: its own fields in order, and how a restored instance is made whole. */
export type ClassSpec = {
    readonly name: string;
    readonly ctor: Function;
    /** Saved fields, in the order a constructor makes them. */
    readonly fields: ReadonlyArray<string>;
    /** Own fields that are not saved: caches and runtime configuration, set to `reset`'s values. */
    readonly skip?: ReadonlyArray<string>;
    /** Own fields with the same value on every instance. */
    readonly constants?: Readonly<{
        [field: string]: unknown;
    }>;
    /** An `Obj`: its prototype, extensibility, and properties are saved too. */
    readonly obj?: boolean;
    /** The restored runtime already has this object; it is filled in place. */
    readonly anchor?: string;
    /** Sets fields that are not saved, once the saved ones are in. */
    readonly reset?: (value: never) => void;
    /** The saved fields' values, when they are not the own fields as they are (a frame saves its live registers only). */
    readonly view?: (value: never) => ReadonlyArray<unknown>;
};
/** The names of every class with a codec: a build that saves a different set cannot read this one's snapshots. */
export declare const codecShape: (extra?: ReadonlyArray<ClassSpec>) => string;
/** Encodes everything reachable from `roots`: the roots' values and the records they refer to. */
export declare const encode: (roots: ReadonlyArray<unknown>, env: EncodeEnv) => {
    readonly roots: Array<Encoded>;
    readonly records: Array<Record>;
};
/** Rebuilds the graph `encode` saved, filling anchors in place: the decoded roots. */
export declare const decode: (saved: {
    readonly roots: ReadonlyArray<unknown>;
    readonly records: ReadonlyArray<unknown>;
}, env: DecodeEnv) => Array<unknown>;
