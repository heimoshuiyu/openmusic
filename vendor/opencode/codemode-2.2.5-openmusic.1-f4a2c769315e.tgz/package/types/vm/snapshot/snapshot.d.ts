import type { Interpreter } from "../runtime/interpreter.js";
import type { ToolCall } from "../../tool-runtime.js";
import { fromBytes, SnapshotError, toBytes } from "../../suspend-error.js";
import type { Encoded, Record } from "./codec.js";
export { fromBytes, SnapshotError, toBytes };
/** The snapshot format this build writes and reads: the bytecode VM's (see `src/vm/snapshot.ts`). */
export declare const FORMAT = 2;
/**
 * A suspended run's whole state as JSON: a header that says which build and sources it belongs to and what budget it
 * has used, and the graph of records (see codec.ts) rooted at the VM, the interpreter, and the global scope, then
 * every built-in or host global the run changed.
 */
export type Snapshot = {
    readonly format: typeof FORMAT;
    readonly header: Header;
    readonly roots: ReadonlyArray<Encoded>;
    readonly records: ReadonlyArray<Record>;
};
export type Header = {
    /** The build that wrote it: the package version, and a hash of the opcodes, the prelude's bytecode, codecs, and built-ins. */
    readonly build: string;
    /**
     * A hash of the host's globals (extensions, a test harness), and of each extension's name and whether it has
     * `snapshot` hooks, which the restoring runtime must have too.
     */
    readonly hosts: string;
    readonly runId: string;
    /** The program texts, re-parsed and recompiled on restore, and checked against their hashes and bytecode hashes. */
    readonly sources: ReadonlyArray<{
        readonly id: string;
        readonly code: string;
        readonly hash: string;
        readonly bytecode: string;
    }>;
    readonly limits: {
        readonly timeoutMs: number | null;
        readonly maxToolCalls: number | null;
        readonly maxOutputBytes: number | null;
    };
    /** What the run has used so far, across every resume: active milliseconds, and tool calls admitted. */
    readonly budget: {
        readonly activeMs: number;
        readonly toolCalls: number;
    };
    /** The tool calls admitted so far. */
    readonly toolCalls: ReadonlyArray<ToolCall>;
};
export type SnapshotHeader = Header;
export declare const hostsId: (ctx: Interpreter<unknown>) => string;
/** A saved state's header, checked in full, before anything is restored. */
export declare const header: (saved: unknown) => Header;
export declare const validate: (saved: unknown) => Snapshot;
export declare const hash: (text: string) => string;
