import type { AstNode } from "./runtime/model.js";
import type { Source } from "./runtime/source.js";
import { type ConstValue, type OpCode } from "./opcodes.js";
type SourceRef = {
    readonly id: string;
    readonly hash: string;
};
export type Label = {
    pc: number;
    readonly patches: Array<number>;
    depth: number | undefined;
};
/**
 * Immutable compiled function or program body. Holds no per-run mutable state.
 */
export declare class Code {
    readonly source: SourceRef;
    readonly index: number;
    readonly name: string;
    readonly flags: number;
    readonly length: number;
    readonly params: number;
    readonly locals: number;
    readonly maxStack: number;
    readonly code: Int32Array;
    readonly consts: ReadonlyArray<ConstValue>;
    /** Per upvalue: `[from (0 = parent cell slot, 1 = parent upvalue), index]`. */
    readonly captures: Int32Array;
    /** Exception handlers `[start, end, target, depth]*`, innermost first (`end` exclusive). */
    readonly handlers: Int32Array;
    /** Per finally level: `[tagSlot, valSlot, entryDepth, n, target_0 … target_{n-1}]`. */
    readonly finallies: Int32Array;
    /** Offsets into `finallies` indexed by finally level. */
    readonly finallyOffsets: Int32Array;
    /** Run-length encoded `[pc, nodeIndex]*` sorted by `pc`. */
    readonly sites: Int32Array;
    readonly localNames: ReadonlyArray<string>;
    readonly upvalNames: ReadonlyArray<string>;
    readonly sourceObj: Source | undefined;
    constructor(init: {
        readonly source: SourceRef;
        readonly index: number;
        readonly name: string;
        readonly flags: number;
        readonly length: number;
        readonly params: number;
        readonly locals: number;
        readonly maxStack: number;
        readonly code: Int32Array;
        readonly consts: ReadonlyArray<ConstValue>;
        readonly captures: Int32Array;
        readonly handlers: Int32Array;
        readonly finallies: Int32Array;
        readonly finallyOffsets: Int32Array;
        readonly sites: Int32Array;
        readonly localNames: ReadonlyArray<string>;
        readonly upvalNames?: ReadonlyArray<string> | undefined;
        readonly sourceObj?: Source | undefined;
    });
    /** Resolves the AST node index recorded for `pc`, or `-1` when none was recorded. */
    nodeIndexAt(pc: number): number;
    /** Resolves the AST node recorded for `pc`. */
    siteAt(pc: number): AstNode | undefined;
    /** The same code over another parse of its source, so its sites resolve to that tree's nodes. */
    withSource(sourceObj: Source): Code;
}
export type CodeJson = {
    readonly [field: string]: unknown;
};
/** Code as JSON, for bytecode compiled ahead of time: every field but the source tree, which `codeFromJson` is given. */
export declare const codeToJson: (code: Code) => CodeJson;
export declare const codeFromJson: (data: CodeJson, sourceObj: Source) => Code;
/** Raised when a narrow-jump function exceeds 16-bit jump range (`65,535` words) and must recompile in wide mode. */
export declare class CodeSizeOverflow extends RangeError {
    constructor(message?: string);
}
export declare class CodeBuilder {
    readonly source: SourceRef;
    readonly sourceObj: Source | undefined;
    readonly index: number;
    readonly name: string;
    flags: number;
    readonly length: number;
    readonly params: number;
    locals: number;
    readonly localNames: Array<string>;
    readonly captures: Int32Array;
    readonly upvalNames: ReadonlyArray<string>;
    private readonly words;
    private readonly sitePairs;
    private lastNodeIndex;
    private readonly constList;
    private readonly pooled;
    private readonly handlerWords;
    private readonly finallyWords;
    private readonly finallyLevelOffsets;
    depth: number;
    maxStack: number;
    wideJumps: boolean;
    forceExtra: boolean;
    constructor(source: SourceRef, sourceObj: Source | undefined, index: number, name: string, flags: number, length: number, params: number, locals: number, localNames: Array<string>, captures: Int32Array, upvalNames?: ReadonlyArray<string>);
    get pc(): number;
    adjustDepth(delta: number): void;
    setDepth(depth: number): void;
    unreachable(): void;
    constant(value: ConstValue): number;
    private recordSite;
    private pushOp;
    emit(op: OpCode, a?: number, bx?: number, nodeIndex?: number, stackDelta?: number): number;
    emitNumber(value: number, nodeIndex?: number): void;
    emitString(value: string, nodeIndex?: number): void;
    newLabel(depth?: number): Label;
    mark(label: Label): void;
    emitJump(op: OpCode, a: number, label: Label, nodeIndex?: number, jumpDelta?: number, fallDelta?: number | null): void;
    addHandler(start: number, end: number, target: number, depth: number): void;
    reserveFinally(): number;
    setFinally(level: number, tagSlot: number, valSlot: number, entryDepth: number, targets: ReadonlyArray<number>): void;
    finish(): Code;
}
/** Deterministic FNV-1a 64-bit hash over a compiled `Code[]` array. */
export declare const hashOf: (codes: ReadonlyArray<Code>) => string;
export {};
