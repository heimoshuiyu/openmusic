import { type AstNode, type GeneratorRequestKind } from "./runtime/model.js";
import { type Cursor, GeneratorObj, Obj, Opaque, type Value } from "./runtime/objects.js";
import { type Completion, type GeneratorRequest, Resume } from "./runtime/signals.js";
import { type Frame, type Vm } from "./vm.js";
/**
 * CreateAsyncFromSyncIterator's object: an async iterator over a synchronous one, for `for await` and an async
 * generator's `yield*`. Its methods are the `%AsyncFromSyncIterator%` intrinsics, so it is plain data.
 */
export declare class AsyncFromSyncIterator extends Opaque {
    /** The synchronous iterator it drives. */
    readonly sync: Cursor;
    /** Where it was made, so a failure that rejects one of its promises is located there. */
    readonly site: AstNode;
    readonly tag = "AsyncFromSyncIterator";
    constructor(proto: Obj, 
    /** The synchronous iterator it drives. */
    sync: Cursor, 
    /** Where it was made, so a failure that rejects one of its promises is located there. */
    site: AstNode);
    get describe(): string;
}
/** Generator.prototype.next/return/throw: the body runs on the caller's job stack until it yields, returns, or throws. */
export declare const generatorStep: (vm: Vm, generator: GeneratorObj, kind: GeneratorRequestKind, value: Value) => Value | Resume;
/**
 * AsyncGenerator.prototype.next/return/throw: queue the request with its promise, and run the body now if it is
 * waiting for one. A request that arrives while the body runs is answered when the body reaches it.
 */
export declare const generatorRequest: (vm: Vm, thisValue: Value, kind: GeneratorRequestKind, value: Value) => Value | Resume;
/** The `awaitReturn` reaction: answers the `return` request with how its value settled, then drains the queue. */
export declare const finishAwaitReturn: (vm: Vm, generator: GeneratorObj, completion: Completion) => void;
export declare const execGeneratorStart: (vm: Vm, frame: Frame, pc: number, sp: number) => void;
export declare const execYield: (vm: Vm, frame: Frame, pc: number, sp: number) => boolean;
export declare const execResume: (frame: Frame, bx: number, pc: number, sp: number) => number;
export declare const execAwait: (vm: Vm, frame: Frame, a: number, pc: number, sp: number) => void;
export declare const execYstar: (frame: Frame, itSlot: number, bx: number, pc: number, sp: number) => number;
export declare const execYstarResult: (frame: Frame, kindSlot: number, bx: number, pc: number, sp: number) => number;
/** Puts a suspended generator's body back on the job stack, handing it `request` unless it has not started yet. */
export declare const resumeVmGenerator: (vm: Vm, gen: GeneratorObj, request: GeneratorRequest) => void;
export declare const completeGeneratorReturn: (vm: Vm, frame: Frame, v: Value) => void;
export declare const unwindGenerator: (vm: Vm, frame: Frame, error: unknown) => boolean;
export declare const handleAdapterPush: (vm: Vm, callerFrame: Frame, slots: Array<unknown>) => number;
export declare const registerGeneratorIntrinsics: (map: Map<string, unknown>, vm: Vm) => void;
