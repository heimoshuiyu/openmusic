import { Schema } from "effect";
import type { Snapshot } from "./vm/snapshot/snapshot.js";
declare const SuspendError_base: Schema.Class<SuspendError, Schema.TaggedStruct<"SuspendError", {
    readonly message: Schema.String;
    readonly running: Schema.$Array<Schema.Struct<{
        readonly key: Schema.String;
        readonly path: Schema.String;
    }>>;
}>, import("effect/Cause").YieldableError>;
/**
 * A suspend that failed, leaving the run running: `running` names each host call that blocked it by its key and its
 * path (`tools.x.y`, `search`, or an extension function's path such as `fetch`). Empty when the state couldn't be
 * saved or was too large.
 */
export declare class SuspendError extends SuspendError_base {
}
export declare class SnapshotError extends Error {
    readonly name = "SnapshotError";
}
/** A snapshot as bytes: UTF-8 JSON. */
export declare const toBytes: (snapshot: Snapshot) => Uint8Array;
/** Reads bytes `toBytes` wrote; `restore` checks what they hold. */
export declare const fromBytes: (bytes: Uint8Array) => unknown;
export {};
