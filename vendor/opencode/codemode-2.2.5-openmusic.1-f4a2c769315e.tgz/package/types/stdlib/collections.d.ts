import type { Interpreter } from "../interpreter/interpreter.js";
/** `Map.groupBy` and `Object.groupBy`: the same iteration, keyed into a Map or a data object. */
export declare const groupBy: <R>(ctx: Interpreter<R>, namespace: "Map" | "Object") => import("../interpreter/objects.js").Native;
export declare const mapGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
export declare const setGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
export declare const weakMapGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
export declare const weakSetGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
