import type { Interpreter } from "../interpreter/interpreter.js";
export declare const stringGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
