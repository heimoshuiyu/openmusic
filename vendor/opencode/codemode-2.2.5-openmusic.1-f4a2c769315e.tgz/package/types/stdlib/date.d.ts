import type { Interpreter } from "../interpreter/interpreter.js";
export declare const dateGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
