import type { Interpreter } from "../interpreter/interpreter.js";
export declare const iteratorGlobals: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
