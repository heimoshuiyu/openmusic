import { type AstNode } from "../interpreter/model.js";
import { Obj, type Value } from "../interpreter/objects.js";
import type { Interpreter } from "../interpreter/interpreter.js";
export declare const enumerableSource: <R>(ctx: Interpreter<R>, label: string, value: Value, node?: AstNode) => Obj;
export declare const objectAssign: <R>(ctx: Interpreter<R>, args: Array<Value>) => Value;
export declare const objectGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
