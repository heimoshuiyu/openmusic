import type { Interpreter } from "../interpreter/interpreter.js";
export declare const numberGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
export declare const booleanGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
