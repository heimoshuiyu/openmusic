import type { Builtins } from "../interpreter/intrinsics.js";
import { Arr, Obj, RegExpObj, type Value } from "../interpreter/objects.js";
import type { Interpreter } from "../interpreter/interpreter.js";
export declare const toHostRegex: (arg: Value, method: string, extraFlags?: string) => RegExp;
export declare const matchToValue: (builtins: Builtins, match: RegExpMatchArray) => Arr;
export declare const constructRegExp: (builtins: Builtins, args: Array<Value>, proto?: Obj) => RegExpObj;
export declare const regexpGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
