import { type Native, type Value } from "../interpreter/objects.js";
import type { Interpreter } from "../interpreter/interpreter.js";
export declare const compoundOperators: Set<string>;
export type Coercion = "Number" | "String" | "Boolean" | "parseInt" | "parseFloat" | "isFinite" | "isNaN";
export declare const coerce: <R>(ctx: Interpreter<R>, name: Coercion, args: Array<Value>) => import("../interpreter/objects.js").NativeResult;
/** A global coercion function such as `Number` or `parseInt`. */
export declare const coercion: <R>(ctx: Interpreter<R>, name: Coercion, length?: number) => Native;
