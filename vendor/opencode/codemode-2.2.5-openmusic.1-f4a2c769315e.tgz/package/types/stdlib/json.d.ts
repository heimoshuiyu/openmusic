import type { Interpreter } from "../interpreter/interpreter.js";
import { Obj } from "../interpreter/objects.js";
export declare const jsonGlobal: <R>(ctx: Interpreter<R>) => Obj;
