import { Obj } from "../interpreter/objects.js";
import type { Interpreter } from "../interpreter/interpreter.js";
export declare const base64Global: <R>(ctx: Interpreter<R>, name: "atob" | "btoa") => import("../interpreter/objects.js").Native;
export declare const structuredCloneGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
export declare const cryptoGlobal: <R>(ctx: Interpreter<R>) => Obj;
