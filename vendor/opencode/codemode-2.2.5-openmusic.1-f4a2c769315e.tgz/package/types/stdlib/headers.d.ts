import type { Interpreter } from "../interpreter/interpreter.js";
export declare const headersGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
