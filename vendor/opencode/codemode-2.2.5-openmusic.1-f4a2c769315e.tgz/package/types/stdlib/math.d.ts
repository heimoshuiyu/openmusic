import { Obj } from "../interpreter/objects.js";
import type { Interpreter } from "../interpreter/interpreter.js";
declare global {
    interface Math {
        sumPrecise(values: Iterable<number>): number;
    }
}
export declare const mathGlobal: <R>(ctx: Interpreter<R>) => Obj;
