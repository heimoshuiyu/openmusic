import type { Eval } from "../interpreter/runner.js";
import { type Method } from "../interpreter/native.js";
import { Obj, type Value } from "../interpreter/objects.js";
import type { Interpreter } from "../interpreter/interpreter.js";
export declare function sortArray<R>(ctx: Interpreter<R>, target: Array<Value>, comparator: Value, name: string): Eval<Array<Value>>;
export declare const arrayGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
/**
 * The callback methods Array and Uint8Array share. They fix the iteration length while reading existing elements
 * live; `wrap` builds the collection `map` and `filter` return.
 */
export declare const callbackMethods: <R, T extends Obj>(ctx: Interpreter<R>, label: string, self: (thisValue: Value, name: string) => T, elements: (target: T) => ArrayLike<Value>, wrap: (values: Array<Value>) => Value) => Array<Method>;
