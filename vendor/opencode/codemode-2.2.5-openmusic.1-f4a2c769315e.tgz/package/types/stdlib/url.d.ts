import type { Eval } from "../interpreter/runner.js";
import { type Value } from "../interpreter/objects.js";
import type { Interpreter } from "../interpreter/interpreter.js";
type UriFunction = "encodeURI" | "encodeURIComponent" | "decodeURI" | "decodeURIComponent";
export declare const uriGlobal: <R>(ctx: Interpreter<R>, name: UriFunction) => import("../interpreter/objects.js").Native;
export declare const urlGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
/**
 * Reads a synchronous iterable of `[name, value]` pairs as strings; `undefined` when `init` is not iterable. As in
 * WebIDL, the whole sequence is converted before any pair's length is checked.
 */
export declare function readPairs<R>(ctx: Interpreter<R>, init: Value, label: string): Eval<Array<[string, string]> | undefined>;
export declare const urlSearchParamsGlobal: <R>(ctx: Interpreter<R>) => import("../interpreter/objects.js").Native;
export {};
