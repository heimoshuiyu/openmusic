export * as Data from "./data.js";
import type { Schema } from "effect";
import type { Interpreter } from "./interpreter/interpreter.js";
import { Obj, type Value } from "./interpreter/objects.js";
import { type Eval } from "./interpreter/runner.js";
export type Json = Schema.Json;
type Replacer = (args: Array<Value>, holder: Obj) => Eval<Value>;
/**
 * What `JSON.stringify` would serialize for a program value, as host JSON: `toJSON` is honored, functions and
 * `undefined` vanish, non-finite numbers become null, and everything else is copied. Two departures from JS
 * so a mistake is not a silent `{}`: an Error serializes as `{ name, message, ...own }`, and a promise throws.
 */
export declare const toJson: <R>(ctx: Interpreter<R>, value: Value, replacer?: Replacer) => Eval<Schema.Json | undefined>;
/**
 * The host boundary: `toJson`, plus what a program most likely meant when a value cannot be JSON. A promise is
 * awaited, a Set crosses as an array, a URLSearchParams as its query string, a Uint8Array asks to be encoded as
 * text first, and a `__proto__` key is dropped so host code can never receive one.
 */
export declare const toBoundary: <R>(ctx: Interpreter<R>, value: Value) => Eval<Schema.Json | undefined>;
/** Host JSON as program values: objects and arrays are copied, primitives pass through. */
export declare const fromJson: <R>(ctx: Interpreter<R>, value: Json | undefined) => Value;
