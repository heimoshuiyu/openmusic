import type { Interpreter } from "./interpreter.js";
import { Callable, type Cursor, type NativeResult, type Value } from "./objects.js";
import { type Eval } from "./runner.js";
/** IteratorClose: a consumer failure closes the iterator and wins over any close failure, except that a generator's
 * return() is a return completion, so a failing close wins over it, as after `break`. */
export declare function preserveConsumerError<A>(close: Cursor["close"], body: Eval<A>): Eval<A>;
export type Hint = "number" | "string" | "default";
/**
 * ToPrimitive: calls `valueOf`/`toString` in hint order and returns the first primitive result. Dates treat the
 * default hint as "string", like their `Symbol.toPrimitive`. Opaque values (functions, promises, generators, tool
 * references) pass through unchanged so callers reject or describe them in their built-in form.
 */
export declare function toPrimitive<R>(ctx: Interpreter<R>, value: Value, hint: Hint): Eval<Value>;
/** Invoke(value, name): calls the method the value would find through its prototype. */
export declare const invoke: <R>(ctx: Interpreter<R>, value: Value, name: string, label: string) => Eval<Value>;
export declare function toPrimitiveString<R>(ctx: Interpreter<R>, value: Value): Eval<string>;
export declare function toPrimitiveNumber<R>(ctx: Interpreter<R>, value: Value): Eval<number>;
/**
 * Runs a native body on its arguments after ToPrimitive, in order, with one hint for all positions or one per
 * position. Primitive arguments skip the conversion entirely.
 */
export declare const withPrimitives: <R>(ctx: Interpreter<R>, hints: Hint | ReadonlyArray<Hint>, values: Array<Value>, body: (primitives: Array<Value>) => NativeResult) => NativeResult;
export declare const isSupportedCallback: (value: Value) => value is Callable;
export declare const applyCollectionCallback: <R>(ctx: Interpreter<R>, callback: Value, name: string) => ((args: Array<Value>, thisValue?: Value) => Eval<Value>);
