/** Longest string a built-in or operator may produce. */
export declare const MAX_STRING_LENGTH: number;
/** Longest array a built-in may create or grow to. */
export declare const MAX_ARRAY_LENGTH = 10000000;
/** Most promises that may be pending at once. */
export declare const MAX_PENDING_PROMISES = 10000;
/** Deepest nesting a value may have when it crosses to or from the host. */
export declare const MAX_VALUE_DEPTH = 32;
export declare const checkStringLength: (length: number) => void;
export declare const checkArrayLength: (length: number) => void;
