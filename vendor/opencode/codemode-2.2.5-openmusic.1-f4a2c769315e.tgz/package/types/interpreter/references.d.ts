import { Obj, type Value } from "./objects.js";
/** Interpreter machinery that is never data, unlike a Date or Map, which cross some boundaries as copies. */
export declare const isOpaque: (value: Value) => boolean;
export declare const containsRuntimeReference: (value: Value) => boolean;
export declare const containsOpaqueReference: (value: Value) => boolean;
export declare const rejectCircularInsertion: (container: Obj, value: Value, label: string, seen?: Set<object>) => void;
export declare const describeValue: (value: Value) => string;
export declare const typeofValue: (value: Value) => string;
