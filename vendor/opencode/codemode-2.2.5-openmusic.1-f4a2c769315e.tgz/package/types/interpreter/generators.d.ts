import type { Interpreter } from "./interpreter.js";
/** `next`/`return`/`throw` on the generator prototypes; async generators answer with promises. */
export declare const generatorGlobals: <R>(ctx: Interpreter<R>) => void;
