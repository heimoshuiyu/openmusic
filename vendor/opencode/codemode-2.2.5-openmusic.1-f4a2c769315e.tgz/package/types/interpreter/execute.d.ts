import { type Program } from "acorn";
import { Effect } from "effect";
import type { Diagnostic, ResolvedExecutionLimits, Result } from "../codemode.js";
import { ToolRuntime } from "../tool-runtime.js";
import { Interpreter } from "./interpreter.js";
import type { Value } from "./objects.js";
export declare const executeProgram: <R>(code: string, prepared: ToolRuntime.Prepared<R>, limits: ResolvedExecutionLimits, hooks: ToolRuntime.Hooks<R>, globals?: (ctx: Interpreter<R>) => ReadonlyArray<readonly [string, Value]>) => Effect.Effect<Result, never, R>;
export declare const parseProgram: (code: string) => {
    ok: true;
    program: Program;
} | {
    ok: false;
    error: Diagnostic;
};
