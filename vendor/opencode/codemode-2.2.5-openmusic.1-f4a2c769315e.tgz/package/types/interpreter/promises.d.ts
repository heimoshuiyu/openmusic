import { type AstNode } from "./model.js";
import { PromiseObj, type Value } from "./objects.js";
import type { Interpreter } from "./interpreter.js";
/**
 * NewPromiseCapability(%Promise%): a pending promise with the host functions that settle it once. A built-in's own
 * failure that rejects it is located at `site`, the call that created it.
 */
export declare const capability: <R>(ctx: Interpreter<R>, site: AstNode | undefined) => {
    resolve: (resolution: Value) => void;
    reject: (reason: unknown) => void;
    promise: PromiseObj;
};
/**
 * Lets a synchronous object result also be awaited or chained like a Promise. It inherits non-enumerable
 * then/catch/finally that settle with a plain copy, so data views never show them and awaiting does not recurse.
 */
export declare const promiseLike: <R>(ctx: Interpreter<R>, value: Value) => Value;
export declare const promiseGlobal: <R>(ctx: Interpreter<R>) => import("./objects.js").Native;
