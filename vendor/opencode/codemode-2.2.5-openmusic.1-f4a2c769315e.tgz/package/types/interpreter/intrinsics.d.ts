import { ErrorObj, Obj, type Value } from "./objects.js";
export declare const errorTypes: readonly ["Error", "TypeError", "RangeError", "SyntaxError", "ReferenceError", "EvalError", "URIError", "AggregateError"];
export type ErrorType = (typeof errorTypes)[number];
export declare const isErrorType: (name: string) => name is ErrorType;
declare const builtins: readonly ["Object", "Function", "Array", "String", "Number", "Boolean", "Date", "RegExp", "Map", "Set", "WeakMap", "WeakSet", "URL", "URLSearchParams", "Headers", "Uint8Array", "TextEncoder", "TextDecoder", "Promise", "Iterator", "IteratorHelper", "AsyncIterator", "Generator", "AsyncGenerator"];
/**
 * The built-in prototype objects of one runtime, allocated empty in dependency order. The globals populate them
 * and attach their constructors when the runtime is built.
 */
export type Builtins = Readonly<Record<(typeof builtins)[number] | ErrorType, Obj>>;
export declare const createErrorValue: (prototype: Obj, message: string | undefined) => ErrorObj;
/** The prototype a primitive reads its methods from without being boxed; none for null, undefined, and symbols. */
export declare const primitivePrototype: (builtins: Builtins, value: Value) => Obj | undefined;
export declare const createBuiltins: () => Builtins;
export {};
