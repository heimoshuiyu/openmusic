import { Cause, type Context, Effect } from "effect";
import type { Diagnostic } from "../codemode.js";
import type { Interpreter } from "./interpreter.js";
import { type AstNode, type GeneratorRequestKind } from "./model.js";
import { type Callable, PromiseObj, type Value } from "./objects.js";
/**
 * Interpreter work: a generator that yields signals to the driver and returns its result. Work inside one activation
 * composes with `yield*`; a program call is a `Call`, so program recursion lives on the explicit stack below and never
 * grows the host stack.
 */
export type Eval<A> = Generator<Signal, A, unknown>;
export type Completion = {
    readonly ok: true;
    readonly value: unknown;
} | {
    readonly ok: false;
    readonly error: unknown;
};
export declare const normal: (value: unknown) => Completion;
export declare const abrupt: (error: unknown) => Completion;
/** Run `body` as a new activation; a boundary marks where a suspended body splits off the stack. */
export declare class Call {
    readonly body: Eval<unknown>;
    readonly boundary?: Boundary | undefined;
    constructor(body: Eval<unknown>, boundary?: Boundary | undefined);
}
/** Push saved activations back on the stack and continue the top one with `input`. */
export declare class Enter {
    readonly entries: Array<Entry>;
    readonly input: Completion;
    constructor(entries: Array<Entry>, input: Completion);
}
/** Suspend the innermost async body until `value` settles; a stall while it waits is reported at `node`. */
export declare class Await {
    readonly value: Value;
    readonly node?: AstNode | undefined;
    constructor(value: Value, node?: AstNode | undefined);
}
/** Suspend the innermost generator body, producing `value`; it continues with the next request. */
export declare class Yield {
    readonly value: Value;
    constructor(value: Value);
}
/** Block the current job on host work: no other job runs until it ends, as with a synchronous host call. */
export declare class Host {
    readonly effect: Effect.Effect<unknown, unknown>;
    constructor(effect: Effect.Effect<unknown, unknown>);
}
/**
 * Host work that was interrupted on its own. It settles its promise like a rejection, but program code cannot catch
 * it: handlers, `catch`, and `finally` are skipped, an unobserved one is not reported, and one that reaches the
 * program's body interrupts the execution.
 */
export declare class Interruption {
    readonly cause: Cause.Cause<unknown>;
    constructor(cause: Cause.Cause<unknown>);
}
/** Let the host run; the current job continues before any other job. */
export declare const Slice: unique symbol;
export type Signal = Call | Enter | Await | Yield | Host | typeof Slice;
/** What a generator body continues with: the `next`, `return`, or `throw` call that resumed it. */
export type GeneratorRequest = {
    readonly kind: GeneratorRequestKind;
    readonly value: Value;
};
/** Where the stack splits when the body above suspends, and what the activation below receives. */
export interface Boundary {
    /** An `await` above suspends here: an async function, an async generator, or the program. */
    readonly async: boolean;
    /** A `yield` above suspends here. */
    readonly generator: boolean;
    /** The body above returned or threw. */
    finish(completion: Completion): Completion;
    /** The body above suspended at an `await`; its activations are saved in the continuation. */
    suspended(): Completion;
    /** The body above yielded; `split` takes its activations off the stack when it suspends. */
    yielded(value: Value, split: () => Array<Entry>): Completion;
}
/** The boundary of an async body: the body's completion settles it, and the caller receives `result` at once. */
export declare class AsyncBoundary implements Boundary {
    private readonly settle;
    readonly result: Value;
    readonly async = true;
    readonly generator = false;
    constructor(settle: (completion: Completion) => void, result: Value);
    finish(completion: Completion): Completion;
    suspended(): Completion;
    yielded(): Completion;
}
export type Entry = {
    readonly body: Eval<unknown>;
    readonly boundary: Boundary | undefined;
};
/** Paused or running program code: activations on an explicit stack, innermost last. */
export declare class Task {
    readonly stack: Array<Entry>;
    constructor(stack: Array<Entry>);
}
/** A settled promise's reaction, run as a job: it either finishes at once or starts a task. */
export type Reaction = (settled: Completion) => Start | void;
export type Start = {
    readonly task: Task;
    readonly input: Completion;
};
/** The functions that settle one promise, at most once between them. */
export type Resolving = {
    readonly resolve: (resolution: Value) => void;
    readonly reject: (reason: unknown) => void;
};
type Job = () => Start | void;
/** Most activations one task may hold, as the call-stack limit. */
export declare const MAX_CALL_DEPTH = 10000;
export declare const isEval: <A>(value: A | Eval<A>) => value is Eval<A>;
/**
 * One execution's job queue. Program code runs only inside a job, one job at a time and each to completion, as in a
 * JavaScript engine: promise reactions and resumed awaits queue in order, host work runs concurrently and settles its
 * promise as a later job, and the program is stuck exactly when no job is queued and no host work is running.
 */
export declare class Runner<R> {
    private readonly ctx;
    /** The services host work runs with: the caller's, so tools see its context, tracing, and clock. */
    private readonly services;
    /** The intrinsic `Promise.prototype.then`, so adopting a native promise skips exposing its rejection first. */
    intrinsicThen: Callable | undefined;
    private readonly queue;
    private head;
    private current;
    private fuel;
    private sliceStart;
    private pending;
    private nextID;
    /** Rejections nothing handled yet, described when they happened so reporting them at the end is cheap. */
    private readonly unhandled;
    /** Bodies suspended at an `await` and the promise each waits on, so a stall can point at the one that is stuck. */
    private readonly parked;
    private readonly fibers;
    private readonly inbox;
    private wake;
    private stopping;
    constructor(ctx: Interpreter<R>, 
    /** The services host work runs with: the caller's, so tools see its context, tracing, and clock. */
    services: Context.Context<R>);
    /** Activations on the running task's stack. */
    get depth(): number;
    /**
     * Runs the program as the first job until its body completes, then returns how it ended. Host work it started may
     * still be running; `interrupt` stops it.
     */
    run(main: Eval<unknown>): Effect.Effect<Completion, unknown, R>;
    /** Stops host work still running, waiting for its cleanup. */
    interrupt(): Effect.Effect<void>;
    /**
     * Rejections no handler observed, in the order their promises were created. Host work that finished before the
     * program did settles first, so its failures count even though no later job ran.
     */
    diagnostics(): Array<Diagnostic>;
    /** Counts one interpreter step; true when the slice is over and the caller should yield `Slice`. */
    tick(): boolean;
    /** A blocking host call, with the caller's services provided so the runner can run it as is. */
    blocking<A, E>(effect: Effect.Effect<A, E, R>): Host;
    enqueue(job: Job): void;
    /**
     * Starts host work now; its completion settles through `settle` in a later job, in completion order. A defect is
     * located at `site`, the call that started the work.
     */
    host(effect: Effect.Effect<unknown, unknown, R>, settle: (completion: Completion) => void, site?: AstNode): void;
    newPromise(): PromiseObj;
    /**
     * CreateResolvingFunctions, for host callers; `reject` takes the failure as thrown. A failure without a location is
     * located at `site`, the call that created the promise.
     */
    resolving(promise: PromiseObj, site?: AstNode): Resolving;
    /** PerformPromiseThen with one reaction for either outcome; marks the promise handled. */
    then(promise: PromiseObj, reaction: Reaction): void;
    /** Removes a reaction an internal consumer no longer needs, so a long-pending promise does not keep it. */
    detach(promise: PromiseObj, reaction: Reaction): void;
    /** PromiseResolve(%Promise%, value). */
    promiseResolve(value: Value): PromiseObj;
    private settle;
    private resolveWith;
    private thenableJob;
    private drive;
    private stuckAwait;
    private dequeue;
    private get yieldToHost();
    private get hostSettled();
}
export {};
