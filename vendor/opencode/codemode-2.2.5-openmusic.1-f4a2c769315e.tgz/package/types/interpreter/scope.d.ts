import { type AstNode, type Binding } from "./model.js";
import type { Value } from "./objects.js";
export declare class ScopeStack {
    private readonly scopes;
    constructor(scopes: Array<Map<string, Binding>>);
    reserve(name: string, mutable: boolean, node: AstNode): void;
    initialize(name: string, value: Value, node: AstNode): void;
    declare(name: string, value: Value, mutable: boolean, node: AstNode): void;
    get(name: string, node: AstNode): Value;
    set(name: string, value: Value, node: AstNode): Value;
    resolve(name: string): Binding | undefined;
    current(): Map<string, Binding>;
    push(scope?: Map<string, Binding>): void;
    pop(): void;
    capture(): Array<Map<string, Binding>>;
}
