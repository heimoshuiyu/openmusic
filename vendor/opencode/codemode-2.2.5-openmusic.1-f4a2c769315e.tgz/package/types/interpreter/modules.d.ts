import { type Value } from "./objects.js";
/** `node:fs` names the same module as `fs`. */
export declare const moduleName: (specifier: string) => string;
export declare const resolveModule: (specifier: string, global: (name: string) => Value) => Value;
