import { type Value } from "./objects.js";
import type { Interpreter } from "./interpreter.js";
/** Names bound in every program before extensions apply. */
export declare const globalNames: ReadonlySet<string>;
/** The immutable global bindings of every program, in declaration order. */
export declare const globals: <R>(ctx: Interpreter<R>) => ReadonlyArray<readonly [string, Value]>;
