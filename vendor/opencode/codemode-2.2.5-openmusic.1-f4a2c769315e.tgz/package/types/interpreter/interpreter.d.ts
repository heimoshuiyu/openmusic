import type { Program, TaggedTemplateExpression } from "acorn";
import type { Context } from "effect";
import { type Json } from "../data.js";
import { type ToolRuntime } from "../tool-runtime.js";
import { type AstNode } from "./model.js";
import { type Builtins } from "./intrinsics.js";
import { type Cursor, Arr, Obj, type Value } from "./objects.js";
import { type Eval, Runner } from "./runner.js";
/** One program execution: the tool bridge, job queue, captured logs, and the global scope built once. */
export declare class Interpreter<R> {
    readonly tools: ToolRuntime<R>;
    readonly runner: Runner<R>;
    readonly builtins: Builtins;
    readonly logs: Array<string>;
    /** Template objects by site: a tag sees the same `strings` array every time its literal is evaluated, as in JS. */
    readonly templates: WeakMap<TaggedTemplateExpression, Arr>;
    private readonly root;
    private readonly globalScope;
    private readonly modules;
    private readonly namespaces;
    constructor(options: {
        readonly tools: ToolRuntime<R>;
        /** The caller's services, which host work runs with. */
        readonly services: Context.Context<R>;
        readonly builtins: Builtins;
        readonly logs?: Array<string>;
        readonly globals?: (ctx: Interpreter<R>) => ReadonlyArray<readonly [string, Value]>;
    });
    /** A module, as `require` returns it and a default import binds it: a global, by its Node module name. */
    module(specifier: string, site?: AstNode): Value;
    /**
     * What `import * as` and `import()` see: the module's own properties, and the module itself as `default`, the way
     * Node presents a CommonJS module.
     */
    namespace(specifier: string, site?: AstNode): Obj;
    /** The program's body, as the first job: its completion value, copied out for the host. */
    main(program: Program): Eval<Json | undefined>;
    /** Calls into the program; a built-in passes its own call site so failures inside are located there. */
    call(callable: Value, thisValue: Value, args: Array<Value>, site?: AstNode): Eval<Value>;
    /** Await: suspends the innermost async body until `value` settles. */
    awaitValue(value: Value, node?: AstNode): Eval<Value>;
    iterate(value: Value): Eval<Cursor | undefined>;
    iterateDirect(value: Value): Cursor;
    /** Runs one host call to completion before any other job: arguments cross as JSON, the result comes back as values. */
    tool(run: ToolRuntime<R>["search"], args: Array<Value>): Generator<import("./runner.js").Signal, Value, import("effect/Schema").Json | undefined>;
    /** The built-in search: its result is usable directly, and can also be awaited or chained like a Promise. */
    search(args: Array<Value>): Generator<import("./runner.js").Signal, Value, import("effect/Schema").Json | undefined>;
}
