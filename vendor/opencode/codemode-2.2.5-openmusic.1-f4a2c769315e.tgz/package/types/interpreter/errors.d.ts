import type { Diagnostic } from "../codemode.js";
import { type AstNode } from "./model.js";
import { type ErrorType } from "./intrinsics.js";
import { type Native, ErrorObj, Obj, type Value } from "./objects.js";
import type { Interpreter } from "./interpreter.js";
/**
 * A host error's message as text. A host can store anything there; an object must not cross as itself, and turning it
 * into text would run its own methods.
 */
export declare const errorMessage: (error: Error) => string;
/** A host error's name as a program error type, read once so a getter cannot pass the check and then change. */
export declare const errorType: (error: Error) => ErrorType;
export declare const normalizeError: (error: unknown) => Diagnostic;
/**
 * Gives a failure the source location of the expression that raised it, keeping the first one attached. Host errors
 * that escape a built-in become the equivalent program error here.
 */
export declare const locate: (error: unknown, node?: AstNode) => unknown;
/** The program value a handler receives for a failure; one failure always yields the same value. */
export declare const materialize: <R>(ctx: Interpreter<R>, thrown: unknown) => Value;
export declare const createAggregateErrorValue: <R>(ctx: Interpreter<R>, errors: Array<Value>, message: string, proto?: Obj) => ErrorObj;
/** An error constructor such as `Error` or `TypeError`; callable with or without `new`, like JS. */
export declare const errorGlobal: <R>(type: ErrorType, ctx: Interpreter<R>) => Native;
