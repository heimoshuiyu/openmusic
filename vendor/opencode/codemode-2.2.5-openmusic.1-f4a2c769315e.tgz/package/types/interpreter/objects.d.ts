import type { BlockStatement, Expression, Pattern } from "acorn";
import { ToolReference } from "../tool-runtime.js";
import type { Builtins } from "./intrinsics.js";
import { type AstNode, type Binding } from "./model.js";
import type { Entry, Eval, GeneratorRequest, Reaction, Resolving } from "./runner.js";
/** Property attributes, as in a JS property descriptor. */
export type Attributes = {
    readonly writable: boolean;
    readonly enumerable: boolean;
    readonly configurable: boolean;
};
export type Getter = (receiver: Value) => Value;
export type Setter = (receiver: Value, value: Value) => void;
/** One own property: a data slot or a native accessor pair. */
export type Slot = {
    value: Value;
    writable: boolean;
    enumerable: boolean;
    configurable: boolean;
} | {
    get: Getter | undefined;
    set: Setter | undefined;
    enumerable: boolean;
    configurable: boolean;
};
/** Ordinary assignment: writable, enumerable, configurable. */
export declare const data: Attributes;
/** Built-in methods and `constructor`: writable and configurable but hidden from enumeration. */
export declare const hidden: Attributes;
/** Function `name` and `length`: read-only but deletable. */
export declare const readonly: Attributes;
/** Constants such as `Math.PI` and a constructor's `prototype`. */
export declare const frozen: Attributes;
/**
 * An object owned by the program: own properties plus a prototype link. Subclasses answer, in one place, how a
 * built-in kind of object prints, coerces, iterates, and crosses to the host.
 */
export declare class Obj {
    proto: Obj | null;
    readonly props: Map<string | symbol, Slot>;
    /** [[Extensible]]: cleared by `Object.preventExtensions`, `seal`, and `freeze`. */
    extensible: boolean;
    constructor(proto: Obj | null);
    /** The class name `Object.prototype.toString` reports: `[object Map]`. */
    readonly tag: string;
    /** How diagnostics refer to a value of this kind. */
    get describe(): string;
    /** ToString without consulting program-defined methods. */
    toString(): string;
    /** ToPrimitive without consulting program-defined methods: only a Date answers a number hint differently. */
    toPrimitive(hint: "default" | "number" | "string"): string | number;
    /** ToNumber without consulting program-defined methods. */
    toNumber(): number;
    /** How `console.log` shows the value; `item` formats a child with cycle and depth tracking. */
    inspect(item: (value: Value) => string): string;
    /** A copy the host can hold; `item` converts a child. A `__proto__` key never reaches host code. */
    toHost(item: (value: Value) => unknown): unknown;
    /** The built-in iteration `for...of` and spread use, when this kind of object has one. */
    iterator(builtins: Builtins): Iterator<Value, undefined> | undefined;
}
export declare class Arr extends Obj {
    readonly items: Array<Value>;
    readonly tag = "Array";
    /** The attributes every live element shares; `seal` and `freeze` narrow them since elements have no slots. */
    elements: Attributes;
    constructor(proto: Obj, items?: Array<Value>);
    get describe(): string;
    toString(): string;
    inspect(item: (value: Value) => string): string;
    toHost(item: (value: Value) => unknown): unknown[];
    iterator(): ArrayIterator<Value>;
}
/** An object with the [[ErrorData]] slot: what `Error.prototype.toString` and the host boundary recognize as an error. */
export declare class ErrorObj extends Obj {
    readonly tag = "Error";
    /** The failure this error materialized from, so rethrowing it keeps the diagnostic kind and location. */
    host?: unknown;
    /** Error.prototype.toString: "name: message", or just one when the other is empty. */
    toString(): string;
    inspect(): string;
}
/** Interpreter machinery a program can hold but never inspect, serialize, or hand to the host. */
export declare abstract class Opaque extends Obj {
    inspect(): string;
}
export declare abstract class Callable extends Opaque {
    readonly length: number;
    readonly tag = "Function";
    constructor(proto: Obj, name: string, length: number);
    get describe(): string;
}
export declare class Fn extends Callable {
    readonly parameters: ReadonlyArray<Pattern>;
    readonly body: BlockStatement | Expression;
    readonly capturedScopes: Array<Map<string, Binding>>;
    readonly async: boolean;
    readonly generator: boolean;
    /** Arrows have no `this` or `arguments` of their own; they read the enclosing function's. */
    readonly arrow: boolean;
    constructor(proto: Obj, name: string, parameters: ReadonlyArray<Pattern>, body: BlockStatement | Expression, capturedScopes: Array<Map<string, Binding>>, async: boolean, generator: boolean, 
    /** Arrows have no `this` or `arguments` of their own; they read the enclosing function's. */
    arrow: boolean);
}
/** The strict `arguments` object: an ordinary object with indexed own properties and a hidden `length`. */
export declare class Arguments extends Obj {
    readonly tag = "Arguments";
    constructor(proto: Obj, args: Array<Value>);
    iterator(): ArrayIterator<Value>;
}
/** A native function body: a value, or interpreter work for bodies that call program code or the host. */
export type NativeResult = Value | Eval<Value>;
/** `site` is the call running the built-in, where a failure it reports later (a rejection) is located. */
export type NativeCall = (thisValue: Value, args: Array<Value>, site: AstNode | undefined) => NativeResult;
export type NativeConstruct = (args: Array<Value>, newTarget: Callable, site: AstNode | undefined) => NativeResult;
export type NativeOptions = {
    readonly name: string;
    readonly length?: number;
    readonly call: NativeCall;
    /** `new name(...)`; without it the function is not a constructor. */
    readonly construct?: NativeConstruct;
    /** Whether callback sites (array methods, replacers, promise reactions) admit this function. Defaults to true. */
    readonly callback?: boolean;
};
export declare class Native extends Callable {
    readonly call: NativeCall;
    readonly construct: NativeConstruct | undefined;
    readonly callback: boolean;
    constructor(proto: Obj, options: NativeOptions);
}
export declare class PromiseObj extends Opaque {
    /** Creation order, for reporting unhandled rejections in the order their promises were made. */
    readonly id: number;
    readonly tag = "Promise";
    state: "pending" | "fulfilled" | "rejected";
    /** The value, or the failure as thrown; a handler receives it materialized. */
    result: unknown;
    reactions: Array<Reaction>;
    /** [[PromiseIsHandled]]: a reaction was attached, so a rejection is not reported as unhandled. */
    handled: boolean;
    constructor(proto: Obj, 
    /** Creation order, for reporting unhandled rejections in the order their promises were made. */
    id: number);
    get describe(): string;
    inspect(): string;
}
export type GeneratorState = "suspendedStart" | "suspendedYield" | "executing" | "awaiting-return" | "draining" | "completed";
export declare class GeneratorObj extends Opaque {
    readonly asynchronous: boolean;
    /** The body, started by the first `next()`. */
    readonly body: Eval<Value>;
    readonly tag = "Generator";
    state: GeneratorState;
    /** The suspended body's activations, kept while it waits for the next request. */
    entries: Array<Entry> | undefined;
    /** An async generator's requests, oldest first, each with the functions that settle its promise. */
    readonly queue: Array<{
        readonly request: GeneratorRequest;
        readonly resolving: Resolving;
    }>;
    constructor(proto: Obj, asynchronous: boolean, 
    /** The body, started by the first `next()`. */
    body: Eval<Value>);
    get describe(): string;
}
/** One pull from an iterator, as `for...of` sees it. */
export type Step = {
    readonly done: boolean;
    readonly value: Value;
};
/** How the interpreter drives any iterator: pull the next step, or close it early. */
export type Cursor = {
    readonly next: () => Eval<Step>;
    readonly close: () => Eval<void>;
};
/** A cursor over a host iterator; there is nothing to close. */
export declare const hostCursor: (iterator: Iterator<Value, undefined>) => Cursor;
/** A built-in iterator: a live cursor over a host collection or an iterator helper, yielding program values. */
export declare class IteratorObj extends Opaque {
    readonly cursor: Cursor;
    readonly tag = "Iterator";
    constructor(proto: Obj, cursor: Cursor);
    get describe(): string;
}
/** A built-in iterator over a host iterator, e.g. `array.values()`. */
export declare const hostIterator: (builtins: Builtins, iterator: Iterator<Value, undefined>) => IteratorObj;
/** A built-in object around a host value: data-like, so it prints as itself and crosses to extensions as a copy. */
export declare abstract class Wrapper extends Obj {
    inspect(item: (value: Value) => string): string;
}
export declare class DateObj extends Wrapper {
    time: number;
    readonly tag = "Date";
    constructor(proto: Obj, time: number);
    toString(): string;
    toPrimitive(hint: "default" | "number" | "string"): string | number;
    toHost(): Date;
}
export declare class RegExpObj extends Wrapper {
    readonly tag = "RegExp";
    readonly regex: RegExp;
    constructor(proto: Obj, pattern: string, flags: string);
    toString(): string;
    toHost(): RegExp;
}
export declare class MapObj extends Wrapper {
    readonly tag = "Map";
    readonly map: Map<Value, Value>;
    inspect(item: (value: Value) => string): string;
    toHost(item: (value: Value) => unknown): Map<unknown, unknown>;
    iterator(builtins: Builtins): IteratorObject<Arr, undefined, unknown>;
}
export declare class SetObj extends Wrapper {
    readonly tag = "Set";
    readonly set: Set<Value>;
    inspect(item: (value: Value) => string): string;
    toHost(item: (value: Value) => unknown): Set<unknown>;
    iterator(): SetIterator<Value>;
}
/** Keys are program objects, so a host WeakMap gives the same lifetime rule as JavaScript without any bookkeeping. */
export declare class WeakMapObj extends Wrapper {
    readonly tag = "WeakMap";
    readonly map: WeakMap<Obj, Value>;
    inspect(): string;
}
export declare class WeakSetObj extends Wrapper {
    readonly tag = "WeakSet";
    readonly set: WeakSet<Obj>;
    inspect(): string;
}
export declare class URLSearchParamsObj extends Wrapper {
    readonly params: URLSearchParams;
    readonly tag = "URLSearchParams";
    constructor(proto: Obj, params: URLSearchParams);
    toString(): string;
    toHost(): URLSearchParams;
    iterator(builtins: Builtins): IteratorObject<Arr, undefined, unknown>;
}
export declare class HeadersObj extends Wrapper {
    readonly headers: Headers;
    readonly tag = "Headers";
    constructor(proto: Obj, headers: Headers);
    inspect(): string;
    toHost(): Headers;
    iterator(builtins: Builtins): IteratorObject<Arr, undefined, unknown>;
}
export declare class URLObj extends Wrapper {
    readonly url: URL;
    readonly tag = "URL";
    readonly searchParams: URLSearchParamsObj;
    constructor(proto: Obj, searchParamsProto: Obj, url: URL);
    toString(): string;
    toHost(): URL;
}
/** A `Uint8Array`: the host array does the byte clamping and ignores out-of-range writes, as JS does. */
export declare class Bytes extends Wrapper {
    readonly bytes: Uint8Array;
    readonly tag = "Uint8Array";
    constructor(proto: Obj, bytes: Uint8Array);
    toString(): string;
    inspect(): string;
    toHost(): Uint8Array<ArrayBuffer>;
    iterator(): ArrayIterator<number>;
}
/** Every value a program can hold. Host values never appear here; they are copied in at the boundaries. */
export type Value = string | number | boolean | null | undefined | symbol | Obj | ToolReference;
/** ToString without consulting program-defined methods. */
export declare const coerceToString: (value: Value) => string;
/** ToNumber without consulting program-defined methods; tool references are not numbers. */
export declare const coerceToNumber: (value: Value) => number;
/** ToIntegerOrInfinity: NaN is 0, fractions truncate. */
export declare const coerceToInteger: (value: Value) => number;
/** Values that cannot cross the data boundary: opaque machinery and host-backed wrappers. */
export declare const isRuntimeReference: (value: Value) => boolean;
export declare const parseArrayIndex: (key: string | number) => number | undefined;
/** The own property under `key`, including an array's live indexes and `length`. */
export declare const own: (target: Obj, key: PropertyKey) => Slot | undefined;
export declare const hasOwn: (target: Obj, key: PropertyKey) => boolean;
export declare const getOwn: (target: Obj, key: PropertyKey) => Value;
/** [[Get]]: walks the prototype chain; accessors see `receiver`, which is the primitive for wrapper prototypes. */
export declare const get: (target: Obj, key: PropertyKey, receiver?: Value) => Value;
export declare const has: (target: Obj, key: PropertyKey) => boolean;
export declare const hasPrototype: (value: Value, proto: Obj) => boolean;
/** [[Set]]: an inherited setter or read-only property decides before an own data property is created. */
export declare const set: (target: Obj, key: PropertyKey, value: Value) => boolean;
/** Creating a property on a non-extensible object is the one [[Set]] failure with its own message. */
export declare const rejectAddition: (target: Obj, key: string | symbol | number) => void;
/** [[DefineOwnProperty]] for a data property, ignoring the chain. */
export declare const define: (target: Obj, key: PropertyKey, value: Value, attrs?: Attributes) => void;
export declare const defineAccessor: (target: Obj, key: PropertyKey, get: Getter | undefined, set?: Setter) => void;
export declare const remove: (target: Obj, key: PropertyKey) => boolean;
export declare const ownKeys: (target: Obj) => Array<string | symbol>;
/** Own enumerable keys, including the iterator symbols; what spread and `Object.assign` copy. */
export declare const enumerableKeys: (target: Obj) => Array<string | symbol>;
/** Own enumerable string keys: `Object.keys`. */
export declare const keys: (target: Obj) => Array<string>;
/** Own enumerable string entries: `Object.entries` and serialization. */
export declare const entries: (target: Obj) => Array<[string, Value]>;
/** An iterator result `{ value, done }`, built directly since every iteration step makes one. */
export declare const iteratorResult: (proto: Obj, value: Value, done: boolean) => Obj;
export declare const record: (proto: Obj, fields: Record<string, Value>) => Obj;
export declare const assign: (target: Obj, source: Obj, skip?: ReadonlySet<PropertyKey>) => void;
