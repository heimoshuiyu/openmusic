import type { Builtins } from "./intrinsics.js";
import { type Callable, Native, type NativeCall, type NativeOptions, Obj, type Value } from "./objects.js";
/** A native function body: a value, a thrown `PendingThrow`, or interpreter work producing a value. */
export type Impl = NativeCall;
export declare const native: (builtins: Builtins, options: NativeOptions) => Native;
export declare const fn: (builtins: Builtins, name: string, length: number, impl: Impl) => Native;
export type Method = readonly [name: string, length: number, impl: Impl];
export declare const methods: (builtins: Builtins, target: Obj, table: ReadonlyArray<Method>) => void;
export declare const constants: (target: Obj, table: Record<string, Value>) => void;
/** A constructor wired to its prototype: `C.prototype === proto` and `proto.constructor === C`. */
export declare const constructor: (builtins: Builtins, proto: Obj, options: NativeOptions) => Native;
/** The `call` of a constructor that JS requires to be invoked with `new`. */
export declare const requiresNew: (name: string) => () => never;
/** The instance prototype for `new` via `newTarget.prototype`, falling back to the built-in's own. */
export declare const prototypeFrom: (newTarget: Callable, fallback: Obj) => Obj;
/** Narrows a method receiver to the built-in it belongs to, or throws the TypeError JS would. */
export declare const receiver: <T extends Obj>(cls: abstract new (...args: never) => T, thisValue: Value, method: string) => T;
