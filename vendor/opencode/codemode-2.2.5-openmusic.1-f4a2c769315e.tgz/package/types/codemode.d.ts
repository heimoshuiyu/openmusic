import { Effect, Schema } from "effect";
import type { Extension } from "./extension.js";
import { scanTools } from "./scan.js";
import { fromBytes, SnapshotError, SuspendError, toBytes } from "./suspend-error.js";
import { type Services, type ToolDescription, ToolRuntime } from "./tool-runtime.js";
import type { Tools } from "./tools.js";
import type { VmEngine } from "./vm/index.js";
export { fromBytes, scanTools, SnapshotError, SuspendError, toBytes };
export type SnapshotHeader = VmEngine.SnapshotHeader;
export type Snapshot = VmEngine.Snapshot;
/** A tool call admitted during an execution. */
export type { CallResult, ExtensionInvocation, Hooks, ToolCall, ToolDescription, ToolInvocation, } from "./tool-runtime.js";
/** Signature-construction helpers for host-owned catalog instructions. */
export { searchSignature, toolExpression } from "./tool-runtime.js";
/** Resource budgets enforced independently during each CodeMode program execution. */
export type ExecutionLimits = {
    /**
     * Wall-clock milliseconds before interruption. Result delivery waits for tool cleanup.
     * No default: absent means no timeout.
     */
    readonly timeoutMs?: number;
    /** Maximum number of tool calls admitted by the runtime. No default: absent means unlimited. */
    readonly maxToolCalls?: number;
    /**
     * Maximum UTF-8 bytes retained from the result and logs. Warnings have a separate equal budget;
     * truncation notices and host formatting are additional.
     */
    readonly maxOutputBytes?: number;
};
export type ResolvedExecutionLimits = {
    readonly timeoutMs: number | undefined;
    readonly maxToolCalls: number | undefined;
    readonly maxOutputBytes: number | undefined;
};
/** Execution engine: the default AST generator interpreter (`"legacy"`) or the experimental bytecode VM (`"vm"`). */
export type Engine = "legacy" | "vm";
/** Options for `VmRuntime.program`. */
export type ProgramOptions = {
    /** Names this run's host calls (`<runId>:<callId>`); a random UUID by default. */
    readonly runId?: string;
};
/** How `program.suspend` saves a run's state (`engine: "vm"` only). */
export type SuspendOptions = {
    /** The most bytes a saved state may take; a larger one fails the suspend, and the run goes on. */
    readonly maxBytes?: number;
};
/** Configuration shared by `CodeMode.make` and `CodeMode.execute`. */
export type Options<Provided extends Record<string, unknown> = {}, Extensions extends ReadonlyArray<Extension> = []> = {
    /** Explicit tools exposed to the program as `tools`. */
    tools?: Provided & Tools<Services<Provided>>;
    /** Hooks around every tool and extension call the program makes; see `Hooks`. */
    hooks?: ToolRuntime.Hooks<Environment<Provided, Extensions>>;
    /** Host functions and objects exposed as globals, also importable by Node module name; see `Extension.make`. */
    extensions?: Extensions;
    /** Resource limits enforced on each execution. Time counts active time only, across every resume of a run. */
    limits?: ExecutionLimits;
    /**
     * Interpreter that runs programs. `"vm"` is the experimental bytecode VM, whose runtime (`VmRuntime`) can also
     * suspend and resume runs; the default is `"legacy"`.
     */
    engine?: Engine;
};
/** The Effect environment an execution needs: what the tools and the extensions' Effect globals require. */
export type Environment<Provided extends Record<string, unknown>, Extensions extends ReadonlyArray<Extension>> = Services<Provided> | Extension.Services<Extensions[number]>;
/** Options for one CodeMode execution. */
export type ExecuteOptions<Provided extends Record<string, unknown> = {}, Extensions extends ReadonlyArray<Extension> = []> = Options<Provided, Extensions> & {
    /** Source for one program in the supported JavaScript subset. */
    code: string;
    /** Read-only JSON values bound in the program's outer global scope (shadowable by top-level declarations). */
    bindings?: Readonly<Record<string, DataValue>>;
};
/** A JSON value that can cross the confined interpreter boundary. */
export type DataValue = Schema.Json;
/** Schema for a host tool input containing CodeMode source. */
export declare const Input: Schema.Struct<{
    readonly code: Schema.String;
}>;
export type Input = typeof Input.Type;
export declare const DiagnosticKind: Schema.Literals<readonly ["ParseError", "UnsupportedSyntax", "UnknownTool", "InvalidToolInput", "InvalidToolOutput", "InvalidDataValue", "ToolCallLimitExceeded", "TimeoutExceeded", "ToolFailure", "ExecutionFailure", "Truncated"]>;
/** Stable categories produced by program, schema, tool, limit, and truncation diagnostics. */
export type DiagnosticKind = typeof DiagnosticKind.Type;
export declare const Diagnostic: Schema.Struct<{
    readonly kind: Schema.Literals<readonly ["ParseError", "UnsupportedSyntax", "UnknownTool", "InvalidToolInput", "InvalidToolOutput", "InvalidDataValue", "ToolCallLimitExceeded", "TimeoutExceeded", "ToolFailure", "ExecutionFailure", "Truncated"]>;
    readonly message: Schema.String;
    readonly location: Schema.optionalKey<Schema.Struct<{
        readonly line: Schema.Number;
        readonly column: Schema.Number;
    }>>;
    readonly suggestions: Schema.optionalKey<Schema.$Array<Schema.String>>;
}>;
/** A normalized program diagnostic safe to return across an agent tool boundary. */
export type Diagnostic = typeof Diagnostic.Type;
export declare const Success: Schema.Struct<{
    readonly ok: Schema.Literal<true>;
    readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    readonly warnings: Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly kind: Schema.Literals<readonly ["ParseError", "UnsupportedSyntax", "UnknownTool", "InvalidToolInput", "InvalidToolOutput", "InvalidDataValue", "ToolCallLimitExceeded", "TimeoutExceeded", "ToolFailure", "ExecutionFailure", "Truncated"]>;
        readonly message: Schema.String;
        readonly location: Schema.optionalKey<Schema.Struct<{
            readonly line: Schema.Number;
            readonly column: Schema.Number;
        }>>;
        readonly suggestions: Schema.optionalKey<Schema.$Array<Schema.String>>;
    }>>>;
    readonly logs: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly truncated: Schema.optionalKey<Schema.Boolean>;
    readonly toolCalls: Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
    }>>;
}>;
/** Successful execution after the result has crossed the plain-data boundary. */
export type Success = typeof Success.Type;
export declare const Failure: Schema.Struct<{
    readonly ok: Schema.Literal<false>;
    readonly error: Schema.Struct<{
        readonly kind: Schema.Literals<readonly ["ParseError", "UnsupportedSyntax", "UnknownTool", "InvalidToolInput", "InvalidToolOutput", "InvalidDataValue", "ToolCallLimitExceeded", "TimeoutExceeded", "ToolFailure", "ExecutionFailure", "Truncated"]>;
        readonly message: Schema.String;
        readonly location: Schema.optionalKey<Schema.Struct<{
            readonly line: Schema.Number;
            readonly column: Schema.Number;
        }>>;
        readonly suggestions: Schema.optionalKey<Schema.$Array<Schema.String>>;
    }>;
    readonly logs: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly truncated: Schema.optionalKey<Schema.Boolean>;
    readonly toolCalls: Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
    }>>;
}>;
/** Failed execution with calls admitted before the diagnostic was produced. */
export type Failure = typeof Failure.Type;
/** Schema for the structured success or diagnostic returned by CodeMode execution. */
export declare const Result: Schema.Union<readonly [Schema.Struct<{
    readonly ok: Schema.Literal<true>;
    readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    readonly warnings: Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly kind: Schema.Literals<readonly ["ParseError", "UnsupportedSyntax", "UnknownTool", "InvalidToolInput", "InvalidToolOutput", "InvalidDataValue", "ToolCallLimitExceeded", "TimeoutExceeded", "ToolFailure", "ExecutionFailure", "Truncated"]>;
        readonly message: Schema.String;
        readonly location: Schema.optionalKey<Schema.Struct<{
            readonly line: Schema.Number;
            readonly column: Schema.Number;
        }>>;
        readonly suggestions: Schema.optionalKey<Schema.$Array<Schema.String>>;
    }>>>;
    readonly logs: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly truncated: Schema.optionalKey<Schema.Boolean>;
    readonly toolCalls: Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
    }>>;
}>, Schema.Struct<{
    readonly ok: Schema.Literal<false>;
    readonly error: Schema.Struct<{
        readonly kind: Schema.Literals<readonly ["ParseError", "UnsupportedSyntax", "UnknownTool", "InvalidToolInput", "InvalidToolOutput", "InvalidDataValue", "ToolCallLimitExceeded", "TimeoutExceeded", "ToolFailure", "ExecutionFailure", "Truncated"]>;
        readonly message: Schema.String;
        readonly location: Schema.optionalKey<Schema.Struct<{
            readonly line: Schema.Number;
            readonly column: Schema.Number;
        }>>;
        readonly suggestions: Schema.optionalKey<Schema.$Array<Schema.String>>;
    }>;
    readonly logs: Schema.optionalKey<Schema.$Array<Schema.String>>;
    readonly truncated: Schema.optionalKey<Schema.Boolean>;
    readonly toolCalls: Schema.$Array<Schema.Struct<{
        readonly name: Schema.String;
    }>>;
}>]>;
/** Result of executing a CodeMode program. Program failures are data, not Effect failures. */
export type Result = typeof Result.Type;
/** A run stopped by `program.suspend`: its whole state, to resume with `VmRuntime.resume`. */
export type Suspended = {
    readonly ok: "suspended";
    readonly state: Snapshot;
};
/** How a run of a program ended: its result, or its saved state once suspended. */
export type Outcome = Result | Suspended;
/** Reusable confined runtime over explicit tools. */
export type Runtime<R = never> = {
    readonly catalog: ReadonlyArray<ToolDescription>;
    readonly execute: (code: string, bindings?: Readonly<Record<string, DataValue>>) => Effect.Effect<Result, never, R>;
};
/** A runtime on the bytecode VM (`engine: "vm"`, experimental): it can also suspend runs and resume them. */
export type VmRuntime<R = never> = Runtime<R> & {
    /** A program ready to run once; nothing runs until `program.run()`. */
    readonly program: (code: string, bindings?: Readonly<Record<string, DataValue>>, options?: ProgramOptions) => Program<R>;
    /**
     * A suspended run (its `state`, or that state as bytes) as a program to continue in this runtime, which must be the
     * same build with the same extensions. The state is checked when it runs: `run()` fails with a `SnapshotError` when
     * it can't be resumed here.
     */
    readonly resume: (state: Snapshot | Uint8Array) => Program<R, SnapshotError>;
};
/**
 * One run of a program on the VM. `run()` runs it in the current fiber until it ends or is suspended, and owns its host
 * calls: interrupting `run()` interrupts them. A program runs once: running it again is a defect.
 */
export type Program<R = never, E = never> = {
    readonly run: () => Effect.Effect<Outcome, E, R>;
    /**
     * Saves the run's state and stops it, at once, from another fiber: `run()` then returns the same `Suspended`, and so
     * does this. It fails with a `SuspendError`, leaving the run running, while a host call (tool, `search`, `fetch`, or
     * extension call) is in progress, or when the state can't be saved or is over `options.maxBytes`. A run that already
     * ended gives its result. Before `run()` starts, this waits for it to start.
     */
    readonly suspend: (options?: SuspendOptions) => Effect.Effect<Outcome, SuspendError>;
};
/** Executes one Effect-native CodeMode program without constructing a reusable runtime. */
export declare const execute: <const Provided extends Record<string, unknown>, const Extensions extends ReadonlyArray<Extension> = []>(options: ExecuteOptions<Provided, Extensions>) => Effect.Effect<Result, never, Environment<Provided, Extensions>>;
/** Creates an Effect-native runtime over explicit, schema-described tools and extensions. */
export declare function make<const Provided extends Record<string, unknown> = {}, const Extensions extends ReadonlyArray<Extension> = []>(options: Options<Provided, Extensions> & {
    engine: "vm";
}): VmRuntime<Environment<Provided, Extensions>>;
export declare function make<const Provided extends Record<string, unknown> = {}, const Extensions extends ReadonlyArray<Extension> = []>(options?: Options<Provided, Extensions>): Runtime<Environment<Provided, Extensions>>;
