export * as BrowserMachine from "./machine.js";
import type { Permission } from "@opencode/schema/permission";
import type { Session } from "@opencode/schema/session";
import { Tool } from "@opencode/schema/tool";
import type { Browser } from "./rpc.js";
/** How long one permission sync (`session.get` and, when needed, `session.update`) may take. The desktop waits 15 s. */
export declare const PERMISSION_SYNC_TIMEOUT_MS = 10000;
/** How long a dispatched browser command may run before it times out and is cancelled on the desktop. */
export declare const REQUEST_TIMEOUT_MS = 60000;
/** The browser tools and their skill, which an attachment allows together. */
export declare const ACCESS: readonly [{
    readonly action: "browser";
    readonly resource: "*";
}, {
    readonly action: "skill";
    readonly resource: string & import("effect/Brand").Brand<"Skill.ID">;
}];
/** The one `session.permissions` sync in flight for a session: grant (`allow`) or revoke the browser rules. */
export type PermissionSync = {
    readonly attempt: number;
    readonly allow: boolean;
};
/**
 * One session's attachment. A session absent from `sessions` has no attachment and no sync in flight.
 *
 * - `attaching`: the desktop called `attach` as `attempt`. Its grant runs after any revoke in flight (`sync`); until it
 *   succeeds, no `attached` handshake is sent and no command is dispatched.
 * - `attached`: the session allows the browser and the desktop received `attached`; commands run.
 * - `revoking`: no attachment; `sync` settles, then a revoke follows unless the session was `deleted`.
 */
export type SessionState = {
    readonly status: "attaching";
    readonly attempt: number;
    readonly connectionID: string;
    readonly sync: PermissionSync;
} | {
    readonly status: "attached";
    readonly attempt: number;
    readonly connectionID: string;
    readonly browserState: Browser.State;
    readonly pending: ReadonlyMap<string, Browser.Command>;
} | {
    readonly status: "revoking";
    readonly sync: PermissionSync;
    readonly deleted: boolean;
};
export type RevokingSession = Extract<SessionState, {
    readonly status: "revoking";
}>;
/** Every attachment of the plugin. Once `disposed`, only revokes still draining remain. */
export type ConnectionState = {
    readonly status: "active";
    readonly nextAttempt: number;
    readonly sessions: ReadonlyMap<Session.ID, SessionState>;
} | {
    readonly status: "disposed";
    readonly nextAttempt: number;
    readonly sessions: ReadonlyMap<Session.ID, RevokingSession>;
};
/** How an `attach` call ends: its result, or `unavailable` when the grant failed. */
export type AttachmentOutcome = "closed" | "replaced" | "unavailable";
export type RequestSettlement = {
    readonly ok: true;
    readonly result: Browser.Result;
} | {
    readonly ok: false;
    readonly error: Tool.Error;
};
export type ConnectionEvent = 
/** `attempt` is the state's `nextAttempt`, read when the driver registered the attachment's handle. */
{
    readonly type: "attach.started";
    readonly sessionID: Session.ID;
    readonly attempt: number;
    readonly connectionID: string;
}
/** The `attach` call ended on the desktop's side (disconnect or interrupt). */
 | {
    readonly type: "attach.closed";
    readonly sessionID: Session.ID;
    readonly attempt: number;
} | {
    readonly type: "permissions.synced";
    readonly sessionID: Session.ID;
    readonly attempt: number;
} | {
    readonly type: "permissions.failed";
    readonly sessionID: Session.ID;
    readonly attempt: number;
    readonly error: unknown;
} | {
    readonly type: "permissions.timed-out";
    readonly sessionID: Session.ID;
    readonly attempt: number;
} | {
    readonly type: "state.updated";
    readonly sessionID: Session.ID;
    readonly connectionID: string;
    readonly browserState: Browser.State;
} | {
    readonly type: "request.started";
    readonly sessionID: Session.ID;
    readonly connectionID: string;
    readonly requestID: string;
    readonly command: Browser.Command;
} | {
    readonly type: "request.dispatch-failed";
    readonly sessionID: Session.ID;
    readonly connectionID: string;
    readonly requestID: string;
    readonly error: unknown;
} | {
    readonly type: "request.settled";
    readonly sessionID: Session.ID;
    readonly connectionID: string;
    readonly requestID: string;
    readonly outcome: Browser.Outcome;
} | {
    readonly type: "request.timed-out";
    readonly sessionID: Session.ID;
    readonly connectionID: string;
    readonly requestID: string;
}
/** The tool call that started the request was interrupted. */
 | {
    readonly type: "request.cancelled";
    readonly sessionID: Session.ID;
    readonly connectionID: string;
    readonly requestID: string;
} | {
    readonly type: "session.moved";
    readonly sessionID: Session.ID;
} | {
    readonly type: "session.deleted";
    readonly sessionID: Session.ID;
} | {
    readonly type: "disposed";
};
export type ConnectionEffect = {
    readonly type: "sync-permissions";
    readonly sessionID: Session.ID;
    readonly attempt: number;
    readonly allow: boolean;
}
/** Disposes the attachment's tunnels and ends its `attach` call with `outcome`. */
 | {
    readonly type: "close-attachment";
    readonly attempt: number;
    readonly outcome: AttachmentOutcome;
} | {
    readonly type: "emit-control";
    readonly control: Browser.Control;
}
/** Emits the `command` control; a failure comes back as `request.dispatch-failed`. */
 | {
    readonly type: "dispatch-command";
    readonly sessionID: Session.ID;
    readonly connectionID: string;
    readonly requestID: string;
} | {
    readonly type: "settle-request";
    readonly requestID: string;
    readonly settlement: RequestSettlement;
} | {
    readonly type: "warn";
    readonly message: string;
    readonly error: unknown;
}
/** The disposed plugin has no revoke left in flight. */
 | {
    readonly type: "notify-drained";
};
export type ConnectionTransition = {
    readonly state: ConnectionState;
    readonly effects: readonly ConnectionEffect[];
};
export declare function createConnectionState(): ConnectionState;
export declare function transitionConnection(state: ConnectionState, event: ConnectionEvent): ConnectionTransition;
/**
 * The session's permissions with exactly one set of browser allows (`allow`) or none, every other rule kept in order.
 * Undefined when they already are, so a replace writes nothing.
 */
export declare function reconcileBrowserPermissions(current: readonly Permission.Rule[] | undefined, allow: boolean): Permission.Rule[] | undefined;
export declare function isConnectionDisposed(state: ConnectionState): state is {
    readonly status: "disposed";
    readonly nextAttempt: number;
    readonly sessions: ReadonlyMap<Session.ID, RevokingSession>;
};
/** The attempt the next `attach` gets; the driver keys its handle by it before dispatching `attach.started`. */
export declare function selectNextAttempt(state: ConnectionState): number;
/** The attempt of the session's attachment with `connectionID`, attaching or attached. */
export declare function selectAttachment(state: ConnectionState, sessionID: Session.ID, connectionID: string): number | undefined;
export declare function isAttachedConnection(state: ConnectionState, sessionID: Session.ID, connectionID: string): boolean;
export declare function selectPendingCommand(state: ConnectionState, sessionID: Session.ID, connectionID: string, requestID: string): Browser.Command | undefined;
/** The attachment and tab a browser tool call targets, or the error the tool returns. */
export declare function selectTarget(state: ConnectionState, sessionID: Session.ID, action: Browser.Action): {
    readonly ok: true;
    readonly connectionID: string;
    readonly tab: Browser.Tab | undefined;
} | {
    readonly ok: false;
    readonly error: Tool.Error;
};
