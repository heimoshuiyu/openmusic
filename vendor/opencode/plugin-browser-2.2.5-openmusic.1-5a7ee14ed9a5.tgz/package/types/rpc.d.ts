export * as Browser from "./rpc.js";
import { Schema } from "effect";
export declare const MAX_FILE_BYTES: number;
export declare const TUNNEL_CHUNK_BYTES: number;
export declare const MAX_TEXT = 100000;
export declare const TabID: Schema.brand<Schema.String, "Browser.TabID">;
export type TabID = typeof TabID.Type;
export declare const Ref: Schema.brand<Schema.String, "Browser.Ref">;
export type Ref = typeof Ref.Type;
export declare const FileID: Schema.brand<Schema.String, "Browser.FileID">;
export type FileID = typeof FileID.Type;
export interface Tab extends Schema.Schema.Type<typeof Tab> {
}
export declare const Tab: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Browser.TabID">;
    readonly url: Schema.String;
    readonly title: Schema.String;
    readonly loading: Schema.Boolean;
    readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly canGoBack: Schema.Boolean;
    readonly canGoForward: Schema.Boolean;
    readonly generation: Schema.Int;
}>;
export interface State extends Schema.Schema.Type<typeof State> {
}
export declare const State: Schema.Struct<{
    readonly tabs: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>>;
    readonly focusedTabID: Schema.NullOr<Schema.brand<Schema.String, "Browser.TabID">>;
}>;
export interface FileInfo extends Schema.Schema.Type<typeof FileInfo> {
}
export declare const FileInfo: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Browser.FileID">;
    readonly name: Schema.String;
    readonly mime: Schema.String;
    readonly bytes: Schema.Int;
    readonly path: Schema.String;
}>;
export interface File extends Schema.Schema.Type<typeof File> {
}
export declare const File: Schema.Struct<{
    readonly id: Schema.brand<Schema.String, "Browser.FileID">;
    readonly name: Schema.String;
    readonly mime: Schema.String;
    readonly data: Schema.Uint8ArrayFromBase64;
}>;
export declare const ResourceType: Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>;
export type ResourceType = typeof ResourceType.Type;
export declare const Body: Schema.Union<readonly [Schema.Struct<{
    readonly state: Schema.Literals<readonly ["notRequested", "pending", "empty"]>;
}>, Schema.Struct<{
    readonly state: Schema.Literal<"text">;
    readonly text: Schema.String;
    readonly truncated: Schema.Boolean;
}>, Schema.Struct<{
    readonly state: Schema.Literal<"unavailable">;
    readonly reason: Schema.Literals<readonly ["binary", "notCaptured", "backendUnavailable"]>;
}>]>;
export type Body = typeof Body.Type;
export declare const NetworkRequest: Schema.Union<readonly [Schema.Struct<{
    readonly id: Schema.String;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>;
    readonly timestampMs: Schema.Finite;
    readonly statusCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly state: Schema.Literal<"pending">;
}>, Schema.Struct<{
    readonly id: Schema.String;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>;
    readonly timestampMs: Schema.Finite;
    readonly statusCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly state: Schema.Literal<"completed">;
    readonly durationMs: Schema.Finite;
}>, Schema.Struct<{
    readonly id: Schema.String;
    readonly url: Schema.String;
    readonly method: Schema.String;
    readonly resourceType: Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>;
    readonly timestampMs: Schema.Finite;
    readonly statusCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly state: Schema.Literal<"failed">;
    readonly durationMs: Schema.Finite;
    readonly failure: Schema.String;
}>]>;
export type NetworkRequest = typeof NetworkRequest.Type;
export declare const ConsoleEntry: Schema.Struct<{
    readonly id: Schema.String;
    readonly timestampMs: Schema.Finite;
    readonly level: Schema.Literals<readonly ["debug", "info", "warning", "error"]>;
    readonly text: Schema.String;
    readonly textTruncated: Schema.Boolean;
    readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly url: Schema.String;
        readonly line: Schema.Int;
        readonly column: Schema.Int;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly url: Schema.String;
        readonly line: Schema.Int;
        readonly column: Schema.Int;
    }>>, never, never>;
}>;
export interface ConsoleEntry extends Schema.Schema.Type<typeof ConsoleEntry> {
}
export declare const Operations: readonly [{
    name: "tabs.list";
    description: string;
    input: Schema.Struct<{}>;
    output: Schema.Struct<{
        readonly tabs: Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>>;
        readonly focusedTabID: Schema.NullOr<Schema.brand<Schema.String, "Browser.TabID">>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"tabs.list">;
    }>;
}, {
    name: "tabs.open";
    description: string;
    input: Schema.Struct<{
        readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly focus: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"tabs.open">;
    } & {
        readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly focus: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>;
}, {
    name: "tabs.focus";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"tabs.focus">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "tabs.close";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly tabs: Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>>;
        readonly focusedTabID: Schema.NullOr<Schema.brand<Schema.String, "Browser.TabID">>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"tabs.close">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "preview";
    description: string;
    input: Schema.Struct<{
        readonly path: Schema.String;
    }>;
    output: Schema.Struct<{
        readonly path: Schema.String;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"preview">;
    } & {
        readonly path: Schema.String;
    }>;
}, {
    name: "navigate";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"navigate">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
    }>;
}, {
    name: "back";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"back">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "forward";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"forward">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "reload";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"reload">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "stop";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"stop">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "frames";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly frames: Schema.$Array<Schema.Struct<{
            readonly id: Schema.String;
            readonly parentID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly url: Schema.String;
            readonly name: Schema.String;
        }>>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"frames">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "snapshot";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
        readonly depth: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly boxes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly content: Schema.String;
        readonly truncated: Schema.Boolean;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"snapshot">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
        readonly depth: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly boxes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }>;
}, {
    name: "find";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly text: Schema.String;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly content: Schema.String;
        readonly truncated: Schema.Boolean;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"find">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly text: Schema.String;
    }>;
}, {
    name: "evaluate";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
        readonly script: Schema.String;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"evaluate">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
        readonly script: Schema.String;
    }>;
}, {
    name: "click";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly button: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["left", "right", "middle"]>>>, Schema.optionalKey<Schema.Literals<readonly ["left", "right", "middle"]>>, never, never>;
        readonly count: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly [1, 2]>>>, Schema.optionalKey<Schema.Literals<readonly [1, 2]>>, never, never>;
        readonly modifiers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Literals<readonly ["Alt", "Control", "Meta", "Shift"]>>>>, Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["Alt", "Control", "Meta", "Shift"]>>>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"click">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly button: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["left", "right", "middle"]>>>, Schema.optionalKey<Schema.Literals<readonly ["left", "right", "middle"]>>, never, never>;
        readonly count: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly [1, 2]>>>, Schema.optionalKey<Schema.Literals<readonly [1, 2]>>, never, never>;
        readonly modifiers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Literals<readonly ["Alt", "Control", "Meta", "Shift"]>>>>, Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["Alt", "Control", "Meta", "Shift"]>>>, never, never>;
    }>;
}, {
    name: "hover";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
        ref: Schema.brand<Schema.String, "Browser.Ref">;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"hover">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
        ref: Schema.brand<Schema.String, "Browser.Ref">;
    }>;
}, {
    name: "drag";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly from: Schema.brand<Schema.String, "Browser.Ref">;
        readonly to: Schema.brand<Schema.String, "Browser.Ref">;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"drag">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly from: Schema.brand<Schema.String, "Browser.Ref">;
        readonly to: Schema.brand<Schema.String, "Browser.Ref">;
    }>;
}, {
    name: "fill";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly text: Schema.String;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"fill">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly text: Schema.String;
    }>;
}, {
    name: "fill_form";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fields: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
            readonly type: Schema.Literal<"text">;
            readonly value: Schema.String;
        }>, Schema.Struct<{
            readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
            readonly type: Schema.Literal<"select">;
            readonly values: Schema.$Array<Schema.String>;
        }>, Schema.Struct<{
            readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
            readonly type: Schema.Literal<"check">;
            readonly checked: Schema.Boolean;
        }>]>>;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"fill_form">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fields: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
            readonly type: Schema.Literal<"text">;
            readonly value: Schema.String;
        }>, Schema.Struct<{
            readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
            readonly type: Schema.Literal<"select">;
            readonly values: Schema.$Array<Schema.String>;
        }>, Schema.Struct<{
            readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
            readonly type: Schema.Literal<"check">;
            readonly checked: Schema.Boolean;
        }>]>>;
    }>;
}, {
    name: "select";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly values: Schema.$Array<Schema.String>;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"select">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly values: Schema.$Array<Schema.String>;
    }>;
}, {
    name: "check";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly checked: Schema.Boolean;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"check">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly checked: Schema.Boolean;
    }>;
}, {
    name: "press";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly key: Schema.String;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"press">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly key: Schema.String;
    }>;
}, {
    name: "scroll";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly deltaX: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly deltaY: Schema.Int;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"scroll">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly deltaX: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly deltaY: Schema.Int;
    }>;
}, {
    name: "wait";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly condition: Schema.Literals<readonly ["load", "text", "textGone"]>;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly timeoutMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"wait">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly condition: Schema.Literals<readonly ["load", "text", "textGone"]>;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly timeoutMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "screenshot";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
        readonly fullPage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["png", "jpeg", "webp"]>>>, Schema.optionalKey<Schema.Literals<readonly ["png", "jpeg", "webp"]>>, never, never>;
        readonly quality: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxWidth: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly files: Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.FileID">;
            readonly name: Schema.String;
            readonly mime: Schema.String;
            readonly bytes: Schema.Int;
            readonly path: Schema.String;
        }>>;
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"screenshot">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
        readonly fullPage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["png", "jpeg", "webp"]>>>, Schema.optionalKey<Schema.Literals<readonly ["png", "jpeg", "webp"]>>, never, never>;
        readonly quality: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxWidth: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "dialog";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly action: Schema.Literals<readonly ["get", "accept", "dismiss"]>;
        readonly promptText: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly dialog: Schema.NullOr<Schema.Struct<{
            readonly type: Schema.String;
            readonly message: Schema.String;
            readonly defaultValue: Schema.String;
        }>>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"dialog">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly action: Schema.Literals<readonly ["get", "accept", "dismiss"]>;
        readonly promptText: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }>;
}, {
    name: "files.upload";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly paths: Schema.$Array<Schema.String>;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"files.upload">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly paths: Schema.$Array<Schema.String>;
    }>;
}, {
    name: "files.drop";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly paths: Schema.$Array<Schema.String>;
    }>;
    output: Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
        readonly title: Schema.String;
        readonly loading: Schema.Boolean;
        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly canGoBack: Schema.Boolean;
        readonly canGoForward: Schema.Boolean;
        readonly generation: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"files.drop">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly paths: Schema.$Array<Schema.String>;
    }>;
}, {
    name: "files.list";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly files: Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.FileID">;
            readonly name: Schema.String;
            readonly mime: Schema.String;
            readonly bytes: Schema.Int;
            readonly state: Schema.Literals<readonly ["pending", "completed", "failed"]>;
        }>>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"files.list">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "files.get";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
        fileID: Schema.brand<Schema.String, "Browser.FileID">;
    }>;
    output: Schema.Struct<{
        readonly files: Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.FileID">;
            readonly name: Schema.String;
            readonly mime: Schema.String;
            readonly bytes: Schema.Int;
            readonly path: Schema.String;
        }>>;
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"files.get">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
        fileID: Schema.brand<Schema.String, "Browser.FileID">;
    }>;
}, {
    name: "console";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly level: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["debug", "info", "warning", "error"]>>>, Schema.optionalKey<Schema.Literals<readonly ["debug", "info", "warning", "error"]>>, never, never>;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly messages: Schema.$Array<Schema.Struct<{
            readonly id: Schema.String;
            readonly timestampMs: Schema.Finite;
            readonly level: Schema.Literals<readonly ["debug", "info", "warning", "error"]>;
            readonly text: Schema.String;
            readonly textTruncated: Schema.Boolean;
            readonly source: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                readonly url: Schema.String;
                readonly line: Schema.Int;
                readonly column: Schema.Int;
            }>>>, Schema.optionalKey<Schema.Struct<{
                readonly url: Schema.String;
                readonly line: Schema.Int;
                readonly column: Schema.Int;
            }>>, never, never>;
        }>>;
        readonly truncated: Schema.Boolean;
        readonly dropped: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"console">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly level: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["debug", "info", "warning", "error"]>>>, Schema.optionalKey<Schema.Literals<readonly ["debug", "info", "warning", "error"]>>, never, never>;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "network.list";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly urlContains: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly resourceType: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>>>, Schema.optionalKey<Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>>, never, never>;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly requests: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly id: Schema.String;
            readonly url: Schema.String;
            readonly method: Schema.String;
            readonly resourceType: Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>;
            readonly timestampMs: Schema.Finite;
            readonly statusCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly state: Schema.Literal<"pending">;
        }>, Schema.Struct<{
            readonly id: Schema.String;
            readonly url: Schema.String;
            readonly method: Schema.String;
            readonly resourceType: Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>;
            readonly timestampMs: Schema.Finite;
            readonly statusCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly state: Schema.Literal<"completed">;
            readonly durationMs: Schema.Finite;
        }>, Schema.Struct<{
            readonly id: Schema.String;
            readonly url: Schema.String;
            readonly method: Schema.String;
            readonly resourceType: Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>;
            readonly timestampMs: Schema.Finite;
            readonly statusCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly state: Schema.Literal<"failed">;
            readonly durationMs: Schema.Finite;
            readonly failure: Schema.String;
        }>]>>;
        readonly truncated: Schema.Boolean;
        readonly dropped: Schema.Int;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"network.list">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly urlContains: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly resourceType: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>>>, Schema.optionalKey<Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>>, never, never>;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "network.get";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly id: Schema.String;
        readonly includeBody: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly maxBodyChars: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly request: Schema.Union<readonly [Schema.Struct<{
            readonly id: Schema.String;
            readonly url: Schema.String;
            readonly method: Schema.String;
            readonly resourceType: Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>;
            readonly timestampMs: Schema.Finite;
            readonly statusCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly state: Schema.Literal<"pending">;
        }>, Schema.Struct<{
            readonly id: Schema.String;
            readonly url: Schema.String;
            readonly method: Schema.String;
            readonly resourceType: Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>;
            readonly timestampMs: Schema.Finite;
            readonly statusCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly state: Schema.Literal<"completed">;
            readonly durationMs: Schema.Finite;
        }>, Schema.Struct<{
            readonly id: Schema.String;
            readonly url: Schema.String;
            readonly method: Schema.String;
            readonly resourceType: Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>;
            readonly timestampMs: Schema.Finite;
            readonly statusCode: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
            readonly state: Schema.Literal<"failed">;
            readonly durationMs: Schema.Finite;
            readonly failure: Schema.String;
        }>]>;
        readonly requestHeaders: Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly value: Schema.String;
        }>>;
        readonly responseHeaders: Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly value: Schema.String;
        }>>;
        readonly headersTruncated: Schema.Boolean;
        readonly requestBody: Schema.Union<readonly [Schema.Struct<{
            readonly state: Schema.Literals<readonly ["notRequested", "pending", "empty"]>;
        }>, Schema.Struct<{
            readonly state: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly truncated: Schema.Boolean;
        }>, Schema.Struct<{
            readonly state: Schema.Literal<"unavailable">;
            readonly reason: Schema.Literals<readonly ["binary", "notCaptured", "backendUnavailable"]>;
        }>]>;
        readonly responseBody: Schema.Union<readonly [Schema.Struct<{
            readonly state: Schema.Literals<readonly ["notRequested", "pending", "empty"]>;
        }>, Schema.Struct<{
            readonly state: Schema.Literal<"text">;
            readonly text: Schema.String;
            readonly truncated: Schema.Boolean;
        }>, Schema.Struct<{
            readonly state: Schema.Literal<"unavailable">;
            readonly reason: Schema.Literals<readonly ["binary", "notCaptured", "backendUnavailable"]>;
        }>]>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"network.get">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly id: Schema.String;
        readonly includeBody: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly maxBodyChars: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "trace.start";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly durationMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly recording: Schema.Boolean;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"trace.start">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly durationMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "trace.stop";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly files: Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.FileID">;
            readonly name: Schema.String;
            readonly mime: Schema.String;
            readonly bytes: Schema.Int;
            readonly path: Schema.String;
        }>>;
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly durationMs: Schema.Finite;
        readonly incomplete: Schema.Boolean;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"trace.stop">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "trace.analyze";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly metrics: Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly value: Schema.Finite;
            readonly unit: Schema.String;
        }>>;
        readonly events: Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly count: Schema.Int;
            readonly totalMs: Schema.Finite;
            readonly maxMs: Schema.Finite;
        }>>;
        readonly insights: Schema.$Array<Schema.String>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"trace.analyze">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "cpu.start";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly recording: Schema.Boolean;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"cpu.start">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "cpu.stop";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly files: Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.FileID">;
            readonly name: Schema.String;
            readonly mime: Schema.String;
            readonly bytes: Schema.Int;
            readonly path: Schema.String;
        }>>;
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly durationMs: Schema.Finite;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"cpu.stop">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "cpu.analyze";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly durationMs: Schema.Finite;
        readonly functions: Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly url: Schema.String;
            readonly line: Schema.Int;
            readonly selfMs: Schema.Finite;
        }>>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"cpu.analyze">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "heap.snapshot";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly files: Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.FileID">;
            readonly name: Schema.String;
            readonly mime: Schema.String;
            readonly bytes: Schema.Int;
            readonly path: Schema.String;
        }>>;
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"heap.snapshot">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}, {
    name: "heap.summary";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly nodes: Schema.Int;
        readonly edges: Schema.Int;
        readonly selfBytes: Schema.Finite;
        readonly classes: Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly count: Schema.Int;
            readonly bytes: Schema.Finite;
        }>>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"heap.summary">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "heap.query";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly nodes: Schema.$Array<Schema.Struct<{
            readonly id: Schema.Finite;
            readonly name: Schema.String;
            readonly type: Schema.String;
            readonly selfBytes: Schema.Int;
            readonly edgeCount: Schema.Int;
        }>>;
        readonly truncated: Schema.Boolean;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"heap.query">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "heap.object";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly id: Schema.Finite;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly node: Schema.Struct<{
            readonly id: Schema.Finite;
            readonly name: Schema.String;
            readonly type: Schema.String;
            readonly selfBytes: Schema.Int;
            readonly edgeCount: Schema.Int;
        }>;
        readonly references: Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly node: Schema.Struct<{
                readonly id: Schema.Finite;
                readonly name: Schema.String;
                readonly type: Schema.String;
                readonly selfBytes: Schema.Int;
                readonly edgeCount: Schema.Int;
            }>;
        }>>;
        readonly retainers: Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly node: Schema.Struct<{
                readonly id: Schema.Finite;
                readonly name: Schema.String;
                readonly type: Schema.String;
                readonly selfBytes: Schema.Int;
                readonly edgeCount: Schema.Int;
            }>;
        }>>;
        readonly truncated: Schema.Boolean;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"heap.object">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly id: Schema.Finite;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "heap.compare";
    description: string;
    input: Schema.Struct<{
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly before: Schema.brand<Schema.String, "Browser.FileID">;
        readonly after: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
    output: Schema.Struct<{
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly classes: Schema.$Array<Schema.Struct<{
            readonly name: Schema.String;
            readonly countDelta: Schema.Int;
            readonly bytesDelta: Schema.Finite;
        }>>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"heap.compare">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly before: Schema.brand<Schema.String, "Browser.FileID">;
        readonly after: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>;
}, {
    name: "lighthouse";
    description: string;
    input: Schema.Struct<{
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
    output: Schema.Struct<{
        readonly files: Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.FileID">;
            readonly name: Schema.String;
            readonly mime: Schema.String;
            readonly bytes: Schema.Int;
            readonly path: Schema.String;
        }>>;
        readonly tab: Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.TabID">;
            readonly url: Schema.String;
            readonly title: Schema.String;
            readonly loading: Schema.Boolean;
            readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
            readonly canGoBack: Schema.Boolean;
            readonly canGoForward: Schema.Boolean;
            readonly generation: Schema.Int;
        }>;
        readonly scores: Schema.$Array<Schema.Struct<{
            readonly id: Schema.String;
            readonly title: Schema.String;
            readonly score: Schema.NullOr<Schema.Finite>;
        }>>;
        readonly failures: Schema.$Array<Schema.Struct<{
            readonly id: Schema.String;
            readonly title: Schema.String;
            readonly description: Schema.String;
        }>>;
    }>;
    action: Schema.Struct<{
        readonly type: Schema.Literal<"lighthouse">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }>;
}];
export type Operation = (typeof Operations)[number];
export type Method = Operation["name"];
export declare const Action: Schema.Union<(Schema.Struct<{
    readonly type: Schema.Literal<"tabs.list">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"back">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"check">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
    readonly checked: Schema.Boolean;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"click">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
    readonly button: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["left", "right", "middle"]>>>, Schema.optionalKey<Schema.Literals<readonly ["left", "right", "middle"]>>, never, never>;
    readonly count: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly [1, 2]>>>, Schema.optionalKey<Schema.Literals<readonly [1, 2]>>, never, never>;
    readonly modifiers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Literals<readonly ["Alt", "Control", "Meta", "Shift"]>>>>, Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["Alt", "Control", "Meta", "Shift"]>>>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"console">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly level: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["debug", "info", "warning", "error"]>>>, Schema.optionalKey<Schema.Literals<readonly ["debug", "info", "warning", "error"]>>, never, never>;
    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"cpu.analyze">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"cpu.start">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"cpu.stop">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"dialog">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly action: Schema.Literals<readonly ["get", "accept", "dismiss"]>;
    readonly promptText: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"drag">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly from: Schema.brand<Schema.String, "Browser.Ref">;
    readonly to: Schema.brand<Schema.String, "Browser.Ref">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"evaluate">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
    readonly script: Schema.String;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"files.drop">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
    readonly paths: Schema.$Array<Schema.String>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"files.get">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
    fileID: Schema.brand<Schema.String, "Browser.FileID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"files.list">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"files.upload">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
    readonly paths: Schema.$Array<Schema.String>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"fill">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
    readonly text: Schema.String;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"fill_form">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly fields: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly type: Schema.Literal<"text">;
        readonly value: Schema.String;
    }>, Schema.Struct<{
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly type: Schema.Literal<"select">;
        readonly values: Schema.$Array<Schema.String>;
    }>, Schema.Struct<{
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly type: Schema.Literal<"check">;
        readonly checked: Schema.Boolean;
    }>]>>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"find">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly text: Schema.String;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"forward">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"frames">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"heap.compare">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly before: Schema.brand<Schema.String, "Browser.FileID">;
    readonly after: Schema.brand<Schema.String, "Browser.FileID">;
    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"heap.object">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
    readonly id: Schema.Finite;
    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"heap.query">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"heap.snapshot">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"heap.summary">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"hover">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
    ref: Schema.brand<Schema.String, "Browser.Ref">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"lighthouse">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"navigate">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly url: Schema.String;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"network.get">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly id: Schema.String;
    readonly includeBody: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly maxBodyChars: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"network.list">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly urlContains: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly resourceType: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>>>, Schema.optionalKey<Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>>, never, never>;
    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"press">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly key: Schema.String;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"preview">;
} & {
    readonly path: Schema.String;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"reload">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"screenshot">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
    readonly fullPage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["png", "jpeg", "webp"]>>>, Schema.optionalKey<Schema.Literals<readonly ["png", "jpeg", "webp"]>>, never, never>;
    readonly quality: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly maxWidth: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"scroll">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly deltaX: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly deltaY: Schema.Int;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"select">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
    readonly values: Schema.$Array<Schema.String>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"snapshot">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
    readonly depth: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly boxes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"stop">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"tabs.close">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"tabs.focus">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"tabs.open">;
} & {
    readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly focus: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"trace.analyze">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"trace.start">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly durationMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"trace.stop">;
} & {
    tabID: Schema.brand<Schema.String, "Browser.TabID">;
}> | Schema.Struct<{
    readonly type: Schema.Literal<"wait">;
} & {
    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
    readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly condition: Schema.Literals<readonly ["load", "text", "textGone"]>;
    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    readonly timeoutMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
}>)[]>;
export type Action = typeof Action.Type;
export declare const Target: Schema.Struct<{
    readonly resources: Schema.$Array<Schema.String>;
    readonly key: Schema.String;
}>;
export type Target = typeof Target.Type;
export declare const Command: Schema.Struct<{
    readonly action: Schema.Union<(Schema.Struct<{
        readonly type: Schema.Literal<"tabs.list">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"back">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"check">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly checked: Schema.Boolean;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"click">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly button: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["left", "right", "middle"]>>>, Schema.optionalKey<Schema.Literals<readonly ["left", "right", "middle"]>>, never, never>;
        readonly count: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly [1, 2]>>>, Schema.optionalKey<Schema.Literals<readonly [1, 2]>>, never, never>;
        readonly modifiers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Literals<readonly ["Alt", "Control", "Meta", "Shift"]>>>>, Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["Alt", "Control", "Meta", "Shift"]>>>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"console">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly level: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["debug", "info", "warning", "error"]>>>, Schema.optionalKey<Schema.Literals<readonly ["debug", "info", "warning", "error"]>>, never, never>;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"cpu.analyze">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"cpu.start">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"cpu.stop">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"dialog">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly action: Schema.Literals<readonly ["get", "accept", "dismiss"]>;
        readonly promptText: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"drag">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly from: Schema.brand<Schema.String, "Browser.Ref">;
        readonly to: Schema.brand<Schema.String, "Browser.Ref">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"evaluate">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
        readonly script: Schema.String;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"files.drop">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly paths: Schema.$Array<Schema.String>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"files.get">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
        fileID: Schema.brand<Schema.String, "Browser.FileID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"files.list">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"files.upload">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly paths: Schema.$Array<Schema.String>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"fill">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly text: Schema.String;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"fill_form">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fields: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
            readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
            readonly type: Schema.Literal<"text">;
            readonly value: Schema.String;
        }>, Schema.Struct<{
            readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
            readonly type: Schema.Literal<"select">;
            readonly values: Schema.$Array<Schema.String>;
        }>, Schema.Struct<{
            readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
            readonly type: Schema.Literal<"check">;
            readonly checked: Schema.Boolean;
        }>]>>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"find">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly text: Schema.String;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"forward">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"frames">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"heap.compare">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly before: Schema.brand<Schema.String, "Browser.FileID">;
        readonly after: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"heap.object">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly id: Schema.Finite;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"heap.query">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"heap.snapshot">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"heap.summary">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"hover">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
        ref: Schema.brand<Schema.String, "Browser.Ref">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"lighthouse">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"navigate">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly url: Schema.String;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"network.get">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly id: Schema.String;
        readonly includeBody: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly maxBodyChars: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"network.list">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly urlContains: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly resourceType: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>>>, Schema.optionalKey<Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>>, never, never>;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"press">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly key: Schema.String;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"preview">;
    } & {
        readonly path: Schema.String;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"reload">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"screenshot">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
        readonly fullPage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
        readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["png", "jpeg", "webp"]>>>, Schema.optionalKey<Schema.Literals<readonly ["png", "jpeg", "webp"]>>, never, never>;
        readonly quality: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly maxWidth: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"scroll">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly deltaX: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly deltaY: Schema.Int;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"select">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
        readonly values: Schema.$Array<Schema.String>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"snapshot">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
        readonly depth: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
        readonly boxes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"stop">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"tabs.close">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"tabs.focus">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"tabs.open">;
    } & {
        readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly focus: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"trace.analyze">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
        readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"trace.start">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly durationMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"trace.stop">;
    } & {
        tabID: Schema.brand<Schema.String, "Browser.TabID">;
    }> | Schema.Struct<{
        readonly type: Schema.Literal<"wait">;
    } & {
        readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
        readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly condition: Schema.Literals<readonly ["load", "text", "textGone"]>;
        readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
        readonly timeoutMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    }>)[]>;
    readonly generation: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
    readonly files: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.FileID">;
        readonly name: Schema.String;
        readonly mime: Schema.String;
        readonly data: Schema.Uint8ArrayFromBase64;
    }>>;
    readonly inspect: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
    readonly target: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
        readonly resources: Schema.$Array<Schema.String>;
        readonly key: Schema.String;
    }>>>, Schema.optionalKey<Schema.Struct<{
        readonly resources: Schema.$Array<Schema.String>;
        readonly key: Schema.String;
    }>>, never, never>;
}>;
export interface Command extends Schema.Schema.Type<typeof Command> {
}
export declare const Result: Schema.Struct<{
    readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
    readonly files: Schema.$Array<Schema.Struct<{
        readonly id: Schema.brand<Schema.String, "Browser.FileID">;
        readonly name: Schema.String;
        readonly mime: Schema.String;
        readonly data: Schema.Uint8ArrayFromBase64;
    }>>;
}>;
export interface Result extends Schema.Schema.Type<typeof Result> {
}
export declare const Outcome: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"success">;
    readonly result: Schema.Struct<{
        readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
        readonly files: Schema.$Array<Schema.Struct<{
            readonly id: Schema.brand<Schema.String, "Browser.FileID">;
            readonly name: Schema.String;
            readonly mime: Schema.String;
            readonly data: Schema.Uint8ArrayFromBase64;
        }>>;
    }>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"failure">;
    readonly code: Schema.String;
    readonly message: Schema.String;
}>]>;
export type Outcome = typeof Outcome.Type;
export declare const TunnelTarget: Schema.Struct<{
    readonly host: Schema.String;
    readonly port: Schema.Int;
}>;
export type TunnelTarget = typeof TunnelTarget.Type;
export declare const TunnelRead: Schema.Struct<{
    readonly data: Schema.Uint8ArrayFromBase64;
    readonly eof: Schema.Boolean;
}>;
export type TunnelRead = typeof TunnelRead.Type;
export declare const Control: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"attached">;
    readonly connectionID: Schema.String;
    readonly version: Schema.Literal<4>;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"command">;
    readonly connectionID: Schema.String;
    readonly requestID: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"cancel">;
    readonly connectionID: Schema.String;
    readonly requestID: Schema.String;
}>]>;
export type Control = typeof Control.Type;
export declare const Definition: {
    readonly id: "experimental.browser";
    readonly methods: {
        readonly attach: {
            readonly input: Schema.Struct<{
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly connectionID: Schema.String;
                readonly version: Schema.Literal<4>;
            }>;
            readonly output: Schema.Literals<readonly ["closed", "replaced"]>;
            readonly errors: {
                unavailable: Schema.Struct<{}>;
            };
        };
        readonly state: {
            readonly input: Schema.Struct<{
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly connectionID: Schema.String;
                readonly state: Schema.Struct<{
                    readonly tabs: Schema.$Array<Schema.Struct<{
                        readonly id: Schema.brand<Schema.String, "Browser.TabID">;
                        readonly url: Schema.String;
                        readonly title: Schema.String;
                        readonly loading: Schema.Boolean;
                        readonly loadError: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                        readonly canGoBack: Schema.Boolean;
                        readonly canGoForward: Schema.Boolean;
                        readonly generation: Schema.Int;
                    }>>;
                    readonly focusedTabID: Schema.NullOr<Schema.brand<Schema.String, "Browser.TabID">>;
                }>;
            }>;
            readonly output: Schema.Void;
            readonly errors: {
                unavailable: Schema.Struct<{}>;
            };
        };
        readonly command: {
            readonly input: Schema.Struct<{
                sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                connectionID: Schema.String;
                requestID: Schema.String;
            }>;
            readonly output: Schema.Struct<{
                readonly action: Schema.Union<(Schema.Struct<{
                    readonly type: Schema.Literal<"tabs.list">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"back">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"check">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
                    readonly checked: Schema.Boolean;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"click">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
                    readonly button: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["left", "right", "middle"]>>>, Schema.optionalKey<Schema.Literals<readonly ["left", "right", "middle"]>>, never, never>;
                    readonly count: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly [1, 2]>>>, Schema.optionalKey<Schema.Literals<readonly [1, 2]>>, never, never>;
                    readonly modifiers: Schema.decodeTo<Schema.optional<Schema.toType<Schema.$Array<Schema.Literals<readonly ["Alt", "Control", "Meta", "Shift"]>>>>, Schema.optionalKey<Schema.$Array<Schema.Literals<readonly ["Alt", "Control", "Meta", "Shift"]>>>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"console">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly level: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["debug", "info", "warning", "error"]>>>, Schema.optionalKey<Schema.Literals<readonly ["debug", "info", "warning", "error"]>>, never, never>;
                    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"cpu.analyze">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
                    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"cpu.start">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"cpu.stop">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"dialog">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly action: Schema.Literals<readonly ["get", "accept", "dismiss"]>;
                    readonly promptText: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"drag">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly from: Schema.brand<Schema.String, "Browser.Ref">;
                    readonly to: Schema.brand<Schema.String, "Browser.Ref">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"evaluate">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
                    readonly script: Schema.String;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"files.drop">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
                    readonly paths: Schema.$Array<Schema.String>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"files.get">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    fileID: Schema.brand<Schema.String, "Browser.FileID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"files.list">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"files.upload">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
                    readonly paths: Schema.$Array<Schema.String>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"fill">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
                    readonly text: Schema.String;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"fill_form">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly fields: Schema.$Array<Schema.Union<readonly [Schema.Struct<{
                        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
                        readonly type: Schema.Literal<"text">;
                        readonly value: Schema.String;
                    }>, Schema.Struct<{
                        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
                        readonly type: Schema.Literal<"select">;
                        readonly values: Schema.$Array<Schema.String>;
                    }>, Schema.Struct<{
                        readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
                        readonly type: Schema.Literal<"check">;
                        readonly checked: Schema.Boolean;
                    }>]>>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"find">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly text: Schema.String;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"forward">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"frames">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"heap.compare">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly before: Schema.brand<Schema.String, "Browser.FileID">;
                    readonly after: Schema.brand<Schema.String, "Browser.FileID">;
                    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"heap.object">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
                    readonly id: Schema.Finite;
                    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"heap.query">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
                    readonly name: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"heap.snapshot">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"heap.summary">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
                    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"hover">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    ref: Schema.brand<Schema.String, "Browser.Ref">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"lighthouse">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"navigate">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly url: Schema.String;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"network.get">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly id: Schema.String;
                    readonly includeBody: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly maxBodyChars: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"network.list">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly urlContains: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly resourceType: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>>>, Schema.optionalKey<Schema.Literals<readonly ["document", "stylesheet", "image", "media", "font", "script", "xhr", "fetch", "eventsource", "websocket", "manifest", "other"]>>, never, never>;
                    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"press">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly key: Schema.String;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"preview">;
                } & {
                    readonly path: Schema.String;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"reload">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"screenshot">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
                    readonly fullPage: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                    readonly format: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Literals<readonly ["png", "jpeg", "webp"]>>>, Schema.optionalKey<Schema.Literals<readonly ["png", "jpeg", "webp"]>>, never, never>;
                    readonly quality: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly maxWidth: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"scroll">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly deltaX: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly deltaY: Schema.Int;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"select">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly ref: Schema.brand<Schema.String, "Browser.Ref">;
                    readonly values: Schema.$Array<Schema.String>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"snapshot">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly ref: Schema.decodeTo<Schema.optional<Schema.toType<Schema.brand<Schema.String, "Browser.Ref">>>, Schema.optionalKey<Schema.brand<Schema.String, "Browser.Ref">>, never, never>;
                    readonly depth: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                    readonly boxes: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"stop">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"tabs.close">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"tabs.focus">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"tabs.open">;
                } & {
                    readonly url: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly focus: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"trace.analyze">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly fileID: Schema.brand<Schema.String, "Browser.FileID">;
                    readonly limit: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"trace.start">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly durationMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"trace.stop">;
                } & {
                    tabID: Schema.brand<Schema.String, "Browser.TabID">;
                }> | Schema.Struct<{
                    readonly type: Schema.Literal<"wait">;
                } & {
                    readonly tabID: Schema.brand<Schema.String, "Browser.TabID">;
                    readonly frameID: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly condition: Schema.Literals<readonly ["load", "text", "textGone"]>;
                    readonly text: Schema.decodeTo<Schema.optional<Schema.toType<Schema.String>>, Schema.optionalKey<Schema.String>, never, never>;
                    readonly timeoutMs: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                }>)[]>;
                readonly generation: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Int>>, Schema.optionalKey<Schema.Int>, never, never>;
                readonly files: Schema.$Array<Schema.Struct<{
                    readonly id: Schema.brand<Schema.String, "Browser.FileID">;
                    readonly name: Schema.String;
                    readonly mime: Schema.String;
                    readonly data: Schema.Uint8ArrayFromBase64;
                }>>;
                readonly inspect: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
                readonly target: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Struct<{
                    readonly resources: Schema.$Array<Schema.String>;
                    readonly key: Schema.String;
                }>>>, Schema.optionalKey<Schema.Struct<{
                    readonly resources: Schema.$Array<Schema.String>;
                    readonly key: Schema.String;
                }>>, never, never>;
            }>;
            readonly errors: {
                unavailable: Schema.Struct<{}>;
            };
        };
        readonly result: {
            readonly input: Schema.Struct<{
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly connectionID: Schema.String;
                readonly requestID: Schema.String;
                readonly outcome: Schema.Union<readonly [Schema.Struct<{
                    readonly type: Schema.Literal<"success">;
                    readonly result: Schema.Struct<{
                        readonly value: Schema.Codec<Schema.Json, Schema.Json, never, never>;
                        readonly files: Schema.$Array<Schema.Struct<{
                            readonly id: Schema.brand<Schema.String, "Browser.FileID">;
                            readonly name: Schema.String;
                            readonly mime: Schema.String;
                            readonly data: Schema.Uint8ArrayFromBase64;
                        }>>;
                    }>;
                }>, Schema.Struct<{
                    readonly type: Schema.Literal<"failure">;
                    readonly code: Schema.String;
                    readonly message: Schema.String;
                }>]>;
            }>;
            readonly output: Schema.Void;
            readonly errors: {
                unavailable: Schema.Struct<{}>;
            };
        };
        readonly "tunnel.open": {
            readonly input: Schema.Struct<{
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly connectionID: Schema.String;
                readonly target: Schema.Struct<{
                    readonly host: Schema.String;
                    readonly port: Schema.Int;
                }>;
            }>;
            readonly output: Schema.String;
            readonly errors: {
                unavailable: Schema.Struct<{}>;
            };
        };
        readonly "tunnel.read": {
            readonly input: Schema.Struct<{
                sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                connectionID: Schema.String;
                tunnelID: Schema.String;
            }>;
            readonly output: Schema.Struct<{
                readonly data: Schema.Uint8ArrayFromBase64;
                readonly eof: Schema.Boolean;
            }>;
            readonly errors: {
                unavailable: Schema.Struct<{}>;
            };
        };
        readonly "tunnel.write": {
            readonly input: Schema.Struct<{
                readonly sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                readonly connectionID: Schema.String;
                readonly tunnelID: Schema.String;
                readonly data: Schema.Uint8ArrayFromBase64;
                readonly end: Schema.decodeTo<Schema.optional<Schema.toType<Schema.Boolean>>, Schema.optionalKey<Schema.Boolean>, never, never>;
            }>;
            readonly output: Schema.Void;
            readonly errors: {
                unavailable: Schema.Struct<{}>;
            };
        };
        readonly "tunnel.close": {
            readonly input: Schema.Struct<{
                sessionID: Schema.brand<Schema.String, "SessionID"> & {
                    create: () => string & import("effect/Brand").Brand<"SessionID">;
                };
                connectionID: Schema.String;
                tunnelID: Schema.String;
            }>;
            readonly output: Schema.Void;
            readonly errors: {
                unavailable: Schema.Struct<{}>;
            };
        };
    };
    readonly events: {
        control: {
            schema: Schema.Union<readonly [Schema.Struct<{
                readonly type: Schema.Literal<"attached">;
                readonly connectionID: Schema.String;
                readonly version: Schema.Literal<4>;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"command">;
                readonly connectionID: Schema.String;
                readonly requestID: Schema.String;
            }>, Schema.Struct<{
                readonly type: Schema.Literal<"cancel">;
                readonly connectionID: Schema.String;
                readonly requestID: Schema.String;
            }>]>;
        };
    };
};
