export * as BrowserProxy from "./proxy.js";
import { Browser } from "./rpc.js";
export type Transport = {
    open(target: Browser.TunnelTarget, signal: AbortSignal): Promise<string>;
    read(id: string, signal: AbortSignal): Promise<Browser.TunnelRead>;
    write(id: string, data: Uint8Array, end: boolean, signal: AbortSignal): Promise<void>;
    close(id: string): Promise<void>;
};
export type Proxy = Awaited<ReturnType<typeof make>>;
export declare function make(transport: Transport): Promise<{
    url: string;
    host: string;
    port: number;
    credentials: {
        username: string;
        password: string;
    };
    close(): Promise<void>;
}>;
