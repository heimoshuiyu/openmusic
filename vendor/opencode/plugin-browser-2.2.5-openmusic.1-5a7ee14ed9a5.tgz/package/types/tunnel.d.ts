export * as BrowserTunnel from "./tunnel.js";
import { Effect } from "effect";
export type Tunnels = ReturnType<typeof make>;
export declare function make(): {
    open: (target: {
        readonly host: string;
        readonly port: number;
    }) => Effect.Effect<`${string}-${string}-${string}-${string}-${string}`, Error, never>;
    read: (id: string) => Effect.Effect<{
        readonly data: Uint8Array<ArrayBufferLike>;
        readonly eof: boolean;
    }, Error, never>;
    write: (id: string, data: Uint8Array<ArrayBufferLike>, end?: boolean | undefined) => Effect.Effect<undefined, Error, never>;
    close: (id: string) => Effect.Effect<void, never, never>;
    dispose(): void;
};
