export * as BrowserTools from "./tools.js";
import type { Context } from "@opencode/plugin/effect/plugin";
import { Tool } from "@opencode/schema/tool";
import { Effect } from "effect";
import { Browser } from "./rpc.js";
export declare const register: (ctx: Pick<Context, "location" | "skill" | "tool">, connection: {
    target: (sessionID: string & import("effect/Brand").Brand<"SessionID">, action: {
        readonly type: "tabs.list";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "back";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly ref: string & import("effect/Brand").Brand<"Browser.Ref">;
        readonly type: "check";
        readonly checked: boolean;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "cpu.start";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "cpu.stop";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "drag";
        readonly from: string & import("effect/Brand").Brand<"Browser.Ref">;
        readonly to: string & import("effect/Brand").Brand<"Browser.Ref">;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly ref: string & import("effect/Brand").Brand<"Browser.Ref">;
        readonly type: "files.drop";
        readonly paths: readonly string[];
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly fileID: string & import("effect/Brand").Brand<"Browser.FileID">;
        readonly type: "files.get";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "files.list";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly ref: string & import("effect/Brand").Brand<"Browser.Ref">;
        readonly type: "files.upload";
        readonly paths: readonly string[];
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly ref: string & import("effect/Brand").Brand<"Browser.Ref">;
        readonly type: "fill";
        readonly text: string;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "fill_form";
        readonly fields: readonly ({
            readonly ref: string & import("effect/Brand").Brand<"Browser.Ref">;
            readonly type: "text";
            readonly value: string;
        } | {
            readonly ref: string & import("effect/Brand").Brand<"Browser.Ref">;
            readonly type: "select";
            readonly values: readonly string[];
        } | {
            readonly ref: string & import("effect/Brand").Brand<"Browser.Ref">;
            readonly type: "check";
            readonly checked: boolean;
        })[];
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "forward";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "frames";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "heap.snapshot";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly ref: string & import("effect/Brand").Brand<"Browser.Ref">;
        readonly type: "hover";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "lighthouse";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "navigate";
        readonly url: string;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "press";
        readonly key: string;
    } | {
        readonly type: "preview";
        readonly path: string;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "reload";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly ref: string & import("effect/Brand").Brand<"Browser.Ref">;
        readonly type: "select";
        readonly values: readonly string[];
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "stop";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "tabs.close";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "tabs.focus";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "trace.stop";
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly ref: string & import("effect/Brand").Brand<"Browser.Ref">;
        readonly type: "click";
        readonly button?: "left" | "middle" | "right" | undefined;
        readonly count?: 1 | 2 | undefined;
        readonly modifiers?: readonly ("Alt" | "Control" | "Meta" | "Shift")[] | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "console";
        readonly level?: "debug" | "error" | "info" | "warning" | undefined;
        readonly limit?: number | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly fileID: string & import("effect/Brand").Brand<"Browser.FileID">;
        readonly type: "cpu.analyze";
        readonly limit?: number | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "dialog";
        readonly action: "accept" | "dismiss" | "get";
        readonly promptText?: string | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly frameID?: string | undefined;
        readonly type: "evaluate";
        readonly ref?: (string & import("effect/Brand").Brand<"Browser.Ref">) | undefined;
        readonly script: string;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly frameID?: string | undefined;
        readonly type: "find";
        readonly text: string;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "heap.compare";
        readonly before: string & import("effect/Brand").Brand<"Browser.FileID">;
        readonly after: string & import("effect/Brand").Brand<"Browser.FileID">;
        readonly limit?: number | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly fileID: string & import("effect/Brand").Brand<"Browser.FileID">;
        readonly type: "heap.object";
        readonly id: number;
        readonly limit?: number | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly fileID: string & import("effect/Brand").Brand<"Browser.FileID">;
        readonly type: "heap.query";
        readonly name?: string | undefined;
        readonly limit?: number | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly fileID: string & import("effect/Brand").Brand<"Browser.FileID">;
        readonly type: "heap.summary";
        readonly limit?: number | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "network.get";
        readonly id: string;
        readonly includeBody?: boolean | undefined;
        readonly maxBodyChars?: number | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "network.list";
        readonly urlContains?: string | undefined;
        readonly resourceType?: "document" | "eventsource" | "fetch" | "font" | "image" | "manifest" | "media" | "other" | "script" | "stylesheet" | "websocket" | "xhr" | undefined;
        readonly limit?: number | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "screenshot";
        readonly ref?: (string & import("effect/Brand").Brand<"Browser.Ref">) | undefined;
        readonly fullPage?: boolean | undefined;
        readonly format?: "jpeg" | "png" | "webp" | undefined;
        readonly quality?: number | undefined;
        readonly maxWidth?: number | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "scroll";
        readonly deltaX?: number | undefined;
        readonly deltaY: number;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly frameID?: string | undefined;
        readonly type: "snapshot";
        readonly ref?: (string & import("effect/Brand").Brand<"Browser.Ref">) | undefined;
        readonly depth?: number | undefined;
        readonly boxes?: boolean | undefined;
    } | {
        readonly type: "tabs.open";
        readonly url?: string | undefined;
        readonly focus?: boolean | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly fileID: string & import("effect/Brand").Brand<"Browser.FileID">;
        readonly type: "trace.analyze";
        readonly limit?: number | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly type: "trace.start";
        readonly durationMs?: number | undefined;
    } | {
        readonly tabID: string & import("effect/Brand").Brand<"Browser.TabID">;
        readonly frameID?: string | undefined;
        readonly type: "wait";
        readonly condition: "load" | "text" | "textGone";
        readonly text?: string | undefined;
        readonly timeoutMs?: number | undefined;
    }) => Effect.Effect<{
        tab: Browser.Tab | undefined;
        inspect: () => Effect.Effect<{
            readonly resources: readonly string[];
            readonly key: string;
        }, Tool.Error, never>;
        request: (files: readonly Browser.File[], target?: Browser.Target) => Effect.Effect<Browser.Result, Tool.Error, never>;
    }, Tool.Error, never>;
}) => Effect.Effect<void, never, import("effect/Scope").Scope>;
export declare function normalizeAction(action: Browser.Action): Browser.Action;
