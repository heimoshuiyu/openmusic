export * as BrowserTunnelMachine from "./tunnel-machine.js";
export declare const MAX_TUNNELS = 64;
export type Entry = 
/** The slot is claimed before the first `await`, so concurrent opens cannot pass the cap. */
{
    readonly status: "connecting";
} | {
    readonly status: "open";
    readonly reading: boolean;
    readonly writing: boolean;
    /** The desktop has read EOF. */
    readonly readEnded: boolean;
    /** The desktop's final write flushed. */
    readonly writeEnded: boolean;
    /** The socket's first error; the next read reports it. */
    readonly error: Error | undefined;
};
export type State = {
    readonly status: "active";
    readonly entries: ReadonlyMap<string, Entry>;
} | {
    readonly status: "disposed";
};
export type ReadOutcome = "chunk" | "eof" | "error" | "interrupted";
export type WriteOutcome = "ok" | "error" | "interrupted";
export type Event = {
    readonly type: "open.started";
    readonly id: string;
} | {
    readonly type: "open.connected";
    readonly id: string;
} | {
    readonly type: "open.failed";
    readonly id: string;
} | {
    readonly type: "socket.errored";
    readonly id: string;
    readonly error: Error;
} | {
    readonly type: "socket.closed";
    readonly id: string;
} | {
    readonly type: "read.started";
    readonly id: string;
} | {
    readonly type: "read.settled";
    readonly id: string;
    readonly outcome: ReadOutcome;
    readonly socketClosed: boolean;
} | {
    readonly type: "write.started";
    readonly id: string;
} | {
    readonly type: "write.settled";
    readonly id: string;
    readonly end: boolean;
    readonly outcome: WriteOutcome;
    readonly socketClosed: boolean;
} | {
    readonly type: "tunnel.closed";
    readonly id: string;
} | {
    readonly type: "disposed";
};
export type SocketEffect = {
    readonly type: "destroy-socket";
    readonly id: string;
};
export type Transition = {
    readonly state: State;
    readonly effects: readonly SocketEffect[];
};
export declare const initial: () => State;
export declare function transition(state: State, event: Event): Transition;
/** Why `open` cannot claim a slot, if it cannot. */
export declare function openError(state: State): Error | undefined;
/** Whether `id` is connected and still in the pool. */
export declare function isOpen(state: State, id: string): boolean;
/** Why `read` cannot start on `id`, if it cannot. */
export declare function readError(state: State, id: string): Error | undefined;
/** Why `write` cannot start on `id`, if it cannot. */
export declare function writeError(state: State, id: string): Error | undefined;
/** The socket error recorded for `id`. */
export declare function socketError(state: State, id: string): Error | undefined;
