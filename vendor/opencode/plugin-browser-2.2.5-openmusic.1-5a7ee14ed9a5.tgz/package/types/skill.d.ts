export * as BrowserSkill from "./skill.js";
export declare const id: string & import("effect/Brand").Brand<"Skill.ID">;
/** How to use the browser tools well. Listed only while a desktop browser is attached, like the tools themselves. */
export declare const info: {
    readonly id: string & import("effect/Brand").Brand<"Skill.ID">;
    readonly name: string & import("effect/Brand").Brand<"Skill.Name">;
    readonly description?: string | undefined;
    readonly autoinvoke?: boolean | undefined;
    readonly path: string & import("effect/Brand").Brand<"AbsolutePath">;
    readonly content: string;
};
