export * as BrowserProxyMachine from "./proxy-machine.js";
export type State = {
    readonly status: "open";
} | {
    readonly status: "closed";
};
export type Event = {
    readonly type: "close";
};
/** `shutdown` aborts pending connects and destroys every tunnel and client socket, once. */
export type ProxyEffect = "shutdown";
export type Transition = {
    readonly state: State;
    readonly effects: readonly ProxyEffect[];
};
export declare const initial: State;
export declare function transition(state: State, event: Event): Transition;
/**
 * Whether a client connection or a tunnel that just opened may join the proxy. One that arrives
 * after `close` is destroyed instead, since shutdown already ran.
 */
export declare function admits(state: State): state is {
    readonly status: "open";
};
/**
 * One tunnel socket's read side: at most one transport read in flight, and no reads after EOF or
 * destruction.
 */
export type ReadState = "idle" | "reading" | "ended" | "destroyed";
/** Chromium pulled, a transport read answered with data or EOF, or the socket was destroyed. */
export type ReadEvent = "pull" | "chunk" | "eof" | "destroyed";
/** Returns `state` itself when the event does not apply, so callers compare to see whether to act. */
export declare function transitionRead(state: ReadState, event: ReadEvent): ReadState;
