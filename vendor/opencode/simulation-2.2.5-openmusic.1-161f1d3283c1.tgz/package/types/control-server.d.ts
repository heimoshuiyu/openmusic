import { Effect, Fiber } from "effect";
export interface Server {
    readonly url: string;
}
interface Request {
    readonly id?: string | number | null;
}
export interface SocketData {
    readonly drive?: true;
    attachment?: Fiber.Fiber<void>;
    closed?: true;
}
export interface Socket {
    readonly data: SocketData;
    readonly send: (message: string) => Effect.Effect<void>;
}
export declare function start<RequestType extends Request, Error, Services>(options: {
    readonly endpoint: string;
    readonly label: string;
    readonly data: () => SocketData;
    readonly decode: (input: string) => Effect.Effect<RequestType, Error>;
    readonly handle: (socket: Socket, request: RequestType) => Effect.Effect<unknown, unknown, Services>;
    readonly close?: (socket: Socket) => Effect.Effect<void, never, Services>;
}): Effect.Effect<{
    url: string;
}, unknown, Services | import("effect/Scope").Scope>;
export * as SimulationControlServer from "./control-server";
