import { Effect, FileSystem, Schema } from "effect";
export declare const Manifest: Schema.Struct<{
    readonly endpoints: Schema.Struct<{
        readonly ui: Schema.String;
        readonly backend: Schema.String;
    }>;
    readonly viewport: Schema.optionalKey<Schema.Struct<{
        readonly cols: Schema.Int;
        readonly rows: Schema.Int;
    }>>;
    readonly recording: Schema.optionalKey<Schema.Struct<{
        readonly timeline: Schema.String;
    }>>;
}>;
export interface Manifest extends Schema.Schema.Type<typeof Manifest> {
}
declare const ResolveError_base: Schema.Class<ResolveError, Schema.TaggedStruct<"DriveManifest.ResolveError", {
    readonly reason: Schema.Literals<readonly ["config", "not-found", "read", "decode"]>;
    readonly path: Schema.optionalKey<Schema.String>;
    readonly message: Schema.String;
    readonly cause: Schema.Defect;
}>, import("effect/Cause").YieldableError>;
export declare class ResolveError extends ResolveError_base {
}
export declare const defaults: Manifest;
export declare const resolve: () => Effect.Effect<Manifest, ResolveError, FileSystem.FileSystem>;
export * as DriveManifest from "./manifest";
