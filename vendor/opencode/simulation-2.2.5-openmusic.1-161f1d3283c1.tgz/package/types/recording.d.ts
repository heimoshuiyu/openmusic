import { Writable } from "node:stream";
import { Schema } from "effect";
export declare const Header: Schema.Struct<{
    readonly type: Schema.Literal<"header">;
    readonly version: Schema.Literal<1>;
    readonly cols: Schema.Number;
    readonly rows: Schema.Number;
    readonly encoding: Schema.Literal<"base64">;
}>;
export interface Header extends Schema.Schema.Type<typeof Header> {
}
export declare const Output: Schema.Struct<{
    readonly type: Schema.Literal<"output">;
    readonly at_ms: Schema.Number;
    readonly data: Schema.String;
}>;
export interface Output extends Schema.Schema.Type<typeof Output> {
}
export declare const Resize: Schema.Struct<{
    readonly type: Schema.Literal<"resize">;
    readonly at_ms: Schema.Number;
    readonly cols: Schema.Number;
    readonly rows: Schema.Number;
}>;
export interface Resize extends Schema.Schema.Type<typeof Resize> {
}
export declare const Event: Schema.Union<readonly [Schema.Struct<{
    readonly type: Schema.Literal<"header">;
    readonly version: Schema.Literal<1>;
    readonly cols: Schema.Number;
    readonly rows: Schema.Number;
    readonly encoding: Schema.Literal<"base64">;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"output">;
    readonly at_ms: Schema.Number;
    readonly data: Schema.String;
}>, Schema.Struct<{
    readonly type: Schema.Literal<"resize">;
    readonly at_ms: Schema.Number;
    readonly cols: Schema.Number;
    readonly rows: Schema.Number;
}>]>;
export type Event = Schema.Schema.Type<typeof Event>;
export declare const Pointer: Schema.Struct<{
    readonly atMs: Schema.Number;
    readonly action: Schema.Literals<readonly ["move", "down", "up", "click", "scroll"]>;
    readonly x: Schema.Number;
    readonly y: Schema.Number;
}>;
export interface Pointer extends Schema.Schema.Type<typeof Pointer> {
}
export declare class Timeline extends Writable {
    readonly isTTY = true;
    readonly path: string;
    readonly columns: number;
    readonly rows: number;
    private readonly output;
    private readonly started;
    private readonly timestamps;
    private done?;
    private pointers?;
    private constructor();
    static create(path: string, cols: number, rows: number): Promise<Timeline>;
    getColorDepth(): number;
    write(chunk: unknown, callback?: (error?: Error | null) => void): boolean;
    write(chunk: unknown, encoding: BufferEncoding, callback?: (error?: Error | null) => void): boolean;
    _write(chunk: Buffer, _encoding: BufferEncoding, callback: (error?: Error | null) => void): void;
    _final(callback: (error?: Error | null) => void): void;
    _destroy(error: Error | null, callback: (error: Error | null) => void): void;
    finish(): Promise<string>;
    resize(cols: number, rows: number): void;
    pointer(action: Pointer["action"], x: number, y: number): void;
    private streams;
    private elapsed;
    private writeOutput;
}
export * as SimulationRecording from "./recording";
