import { SimulationNetwork } from "./network";
import { SimulatedProvider } from "./simulated-provider";
export declare const route: (provider: SimulatedProvider.Interface) => SimulationNetwork.Route;
export * as SimulationOpenAI from "./openai";
