import { LayerNode } from "@opencode/util/effect/layer-node";
import { Effect, FileSystem } from "effect";
/**
 * Layer replacements applied when the server is built in simulation mode.
 *
 * The server merges these into the app node build when simulation is enabled
 * is enabled, via a dynamic import so this module is never loaded eagerly.
 *
 * - Network: all outbound HTTP resolves against the simulated route table;
 *   unknown destinations are denied. The driver-answered OpenAI endpoint is
 *   registered here as the first route.
 *
 */
export declare const simulationReplacements: (app: {
    readonly version: string;
}) => Effect.Effect<LayerNode.Replacements, Error, FileSystem.FileSystem>;
export * as Simulation from "./index";
