import { SdkPlugins } from "@opencode/core/plugin/sdk";
import { Cause, Context, Layer, Schema, Stream } from "effect";
import { SimulationProtocol } from "../protocol";
export interface ProviderRequest {
    readonly url: string;
    readonly body: unknown;
}
export type ProviderResponseEvent = SimulationProtocol.Backend.Item | {
    readonly type: "finish";
    readonly reason: SimulationProtocol.Backend.FinishReason;
};
declare const ProviderDisconnectedError_base: Schema.Class<ProviderDisconnectedError, Schema.TaggedStruct<"SimulatedProvider.ProviderDisconnectedError", {
    readonly message: Schema.String;
}>, Cause.YieldableError>;
export declare class ProviderDisconnectedError extends ProviderDisconnectedError_base {
}
export interface Interface {
    readonly stream: (request: ProviderRequest) => Stream.Stream<ProviderResponseEvent, ProviderDisconnectedError>;
}
declare const Service_base: Context.ServiceClass<Service, "@opencode/simulation/SimulatedProvider", Interface>;
export declare class Service extends Service_base {
}
export declare const layerDrive: (options: {
    readonly endpoint: string;
    readonly version: string;
}) => Layer.Layer<Service, unknown, SdkPlugins.Service>;
export * as SimulatedProvider from "./simulated-provider";
