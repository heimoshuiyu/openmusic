import { type CliRendererConfig } from "@opentui/core";
import { Effect } from "effect";
/** Drive-mode renderer and control-server acquisition. */
export declare const create: (options: CliRendererConfig, version: string) => Effect.Effect<import("@opentui/core").CliRenderer, unknown, import("effect/FileSystem").FileSystem | import("effect/Scope").Scope>;
export * as Drive from "./simulation";
