import type { Renderable } from "@opentui/core";
import type { SimulationProtocol } from "../protocol";
export type Definition = Omit<SimulationProtocol.Frontend.SemanticNode, "id" | "element" | "parent">;
declare const bind: (definition: () => Definition) => (renderable: Renderable) => void;
export declare const read: (renderable: Renderable) => (() => Definition) | undefined;
export declare const SimulationSemantics: {
    bind: typeof bind;
    read: typeof read;
};
export {};
