import type { CliRenderer, CliRendererConfig } from "@opentui/core";
import { type TestRendererSetup } from "@opentui/core/testing";
import { Effect } from "effect";
import { type Pointer } from "../recording";
/**
 * Creates a headless renderer with optional recording: a real CliRenderer
 * backed by an in-memory screen buffer. The TestRendererSetup is kept
 * module-side so the harness can use supported testing APIs without app
 * code carrying it around.
 */
export interface Viewport {
    readonly cols: number;
    readonly rows: number;
}
export declare const create: (options: CliRendererConfig, path?: string | undefined, viewport?: Viewport | undefined) => Effect.Effect<CliRenderer, import("effect/Cause").UnknownError, import("effect/Scope").Scope>;
export declare function recordResize(renderer: CliRenderer, cols: number, rows: number): void;
export declare function recordPointer(renderer: CliRenderer, action: Pointer["action"], x: number, y: number): void;
export declare function setupFor(renderer: CliRenderer): TestRendererSetup | undefined;
export declare function finish(renderer: CliRenderer): Effect.Effect<string, import("effect/Cause").UnknownError, never> | Effect.Effect<never, Error, never>;
export * as SimulationRenderer from "./renderer";
