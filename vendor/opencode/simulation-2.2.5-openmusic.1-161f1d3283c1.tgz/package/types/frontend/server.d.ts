import { Effect } from "effect";
import { type Harness } from "./actions";
export declare const start: (harness: Harness, endpoint: string, version?: any) => Effect.Effect<{
    url: string;
}, unknown, import("effect/Scope").Scope>;
export * as SimulationServer from "./server";
