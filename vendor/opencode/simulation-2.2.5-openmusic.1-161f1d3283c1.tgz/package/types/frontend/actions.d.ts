import { type CliRenderer } from "@opentui/core";
import { type MockInput, type MockMouse } from "@opentui/core/testing";
import { Effect } from "effect";
import { SimulationProtocol } from "../protocol";
export type Action = SimulationProtocol.Frontend.Action;
export type Element = SimulationProtocol.Frontend.Element;
export interface Harness {
    readonly renderer: CliRenderer;
    readonly mockInput: MockInput;
    readonly mockMouse: MockMouse;
    readonly resize: (cols: number, rows: number) => void;
    readonly renderOnce: () => Promise<void>;
    readonly screen: () => string;
}
/**
 * Builds the harness the simulation server drives.
 *
 * When the renderer is the headless simulation renderer, its TestRendererSetup
 * provides the supported testing APIs. For the visible terminal renderer the
 * harness falls back to `requestRender` + `idle` and reading the private
 * `currentRenderBuffer`.
 */
export declare function createHarness(renderer: CliRenderer): Harness;
export declare function elements(renderer: CliRenderer): Element[];
export declare function state(harness: Harness): {
    focused: {
        renderable?: number | undefined;
        editor: boolean;
    };
    elements: SimulationProtocol.Frontend.Element[];
};
export declare function snapshot(harness: Harness): SimulationProtocol.Frontend.SemanticSnapshot;
export declare function matches(harness: Pick<Harness, "screen">, text: string): boolean;
export declare const capture: (harness: Harness) => Effect.Effect<{
    cols: number;
    rows: number;
    cursor: readonly [0, 0];
    lines: {
        spans: {
            text: string;
            fg: [number, number, number, number];
            bg: [number, number, number, number];
            attributes: number;
            width: number;
        }[];
    }[];
    images: SimulationProtocol.Frontend.CapturedImage[];
}, import("effect/Cause").UnknownError, never>;
export declare const execute: (harness: Harness, action: {
    readonly type: "ui.type";
    readonly text: string;
} | {
    readonly type: "ui.enter";
} | {
    readonly type: "ui.arrow";
    readonly direction: "down" | "left" | "right" | "up";
} | {
    readonly type: "ui.focus";
    readonly target: number;
} | {
    readonly type: "ui.mouse";
    readonly params: {
        readonly x: number;
        readonly y: number;
        readonly modifiers?: {
            readonly shift?: boolean | undefined;
            readonly alt?: boolean | undefined;
            readonly ctrl?: boolean | undefined;
        } | undefined;
        readonly action: "move";
    } | {
        readonly x: number;
        readonly y: number;
        readonly modifiers?: {
            readonly shift?: boolean | undefined;
            readonly alt?: boolean | undefined;
            readonly ctrl?: boolean | undefined;
        } | undefined;
        readonly action: "down" | "up";
        readonly button?: "left" | "middle" | "right" | undefined;
    } | {
        readonly x: number;
        readonly y: number;
        readonly modifiers?: {
            readonly shift?: boolean | undefined;
            readonly alt?: boolean | undefined;
            readonly ctrl?: boolean | undefined;
        } | undefined;
        readonly action: "scroll";
        readonly direction: "down" | "left" | "right" | "up";
    };
} | {
    readonly type: "ui.resize";
    readonly cols: number;
    readonly rows: number;
} | {
    readonly type: "ui.press";
    readonly key: string;
    readonly modifiers?: {
        readonly ctrl?: boolean | undefined;
        readonly shift?: boolean | undefined;
        readonly meta?: boolean | undefined;
        readonly super?: boolean | undefined;
        readonly hyper?: boolean | undefined;
    } | undefined;
} | {
    readonly type: "ui.click";
    readonly target: number;
    readonly x: number;
    readonly y: number;
    readonly semantic?: {
        readonly id: string;
        readonly instance?: string | undefined;
        readonly element: number;
    } | undefined;
}) => Effect.Effect<{
    focused: {
        renderable?: number | undefined;
        editor: boolean;
    };
    elements: SimulationProtocol.Frontend.Element[];
}, Error, never>;
export * as SimulationActions from "./actions";
