export * as VcsGitPlugin from "./git.js"

import { randomUUID } from "crypto"
import fs from "fs/promises"
import os from "os"
import path from "path"
import { define } from "@opencode/plugin/effect/plugin"
import { Effect } from "effect"
import { ChildProcess } from "effect/process"
import { FileDiff } from "@opencode/schema/file-diff"
import { Base, BranchList, FileStatus, Info, Mode } from "@opencode/schema/vcs"
import { AppProcess } from "@opencode/util/process"
import { Location } from "../../location.js"
import type { Adapter, BranchOptions, DiffOptions, Untracked } from "../../vcs.js"
import { DiffError } from "../../vcs.js"
import { gitExecutable } from "../../util/git-executable.js"
import {
  chunksByFile,
  emptyPatch,
  MAX_PATCH_BYTES,
  MAX_TOTAL_PATCH_BYTES,
  PATCH_CONTEXT_LINES,
  splitGitPatch,
} from "../../vcs/patch.js"
import type { Patch } from "../../vcs/patch.js"

export const Plugin = define({
  id: "opencode.vcs.git",
  effect: Effect.fn("VcsGitPlugin")(function* (ctx) {
    const location = yield* Location.Service
    // Markerless locations need this definition to initialize their first repository.
    if (location.vcs && location.vcs.type !== "git") return

    const processes = yield* AppProcess.Service
    const adapter = make(processes, {
      directory: location.directory,
      worktree: location.project.directory,
    })

    yield* ctx.vcs.transform((editor) => {
      editor.add({
        id: "git",
        name: "Git",
        init: (input) =>
          Effect.gen(function* () {
            const result = yield* processes.run(
              ChildProcess.make(gitExecutable(), ["init"], { cwd: input.worktree, stdin: "ignore" }),
            )
            if (result.exitCode !== 0) return yield* Effect.fail(new Error("Git initialization failed"))
          }),
        info: () => adapter.info(),
        base: () => adapter.base(),
        branches: (input) => adapter.branches({ search: input.search, limit: input.limit }),
        status: () => adapter.status(),
        diff: (input) =>
          adapter.diff(input.mode, { context: input.context, base: input.base, untracked: input.untracked }),
      })
    })
  }),
})

/**
 * Git adapter for the Vcs service. Ported from the V1 pipeline: patches are
 * batched through one `git diff` invocation where possible and capped by
 * per-file and total byte budgets, falling back to empty patches when capped.
 */
function make(proc: AppProcess.Interface, input: { directory: string; worktree: string }) {
  // Listing commands scope pathspecs to the requested directory; per-file
  // commands run from the worktree root because git lists root-relative paths.
  const ctx: Ctx = { proc, git: makeGit(proc), directory: input.directory, worktree: input.worktree }

  return {
    info: Effect.fn("VcsGit.info")(function* () {
      const [current, root] = yield* Effect.all([ctx.git.branch(ctx.directory), ctx.git.defaultBranch(ctx.directory)], {
        concurrency: 2,
      })
      return { branch: { current, default: root?.name } } satisfies Info
    }),
    base: () => ctx.git.base(ctx.directory),
    branches: Effect.fn("VcsGit.branches")(function* (options?: BranchOptions) {
      return yield* ctx.git.branches(ctx.directory, options)
    }),
    status: Effect.fn("VcsGit.status")(function* () {
      const git = ctx.git
      const ref = (yield* git.hasHead(ctx.directory)) ? "HEAD" : undefined
      const [list, stats] = yield* Effect.all(
        [
          statusItems(ctx).pipe(Effect.map((result) => result.list)),
          ref ? git.stats(ctx.directory, ref) : Effect.succeed([] as Stat[]),
        ],
        { concurrency: 2 },
      )
      const map = nums(stats)
      const untracked = yield* untrackedBatch(
        ctx,
        list.filter((item) => item.status === "added" && !map.has(item.file)).map((item) => item.file),
      )
      return yield* Effect.forEach(
        list.toSorted((a, b) => a.file.localeCompare(b.file)),
        (item) =>
          Effect.gen(function* () {
            const stat =
              map.get(item.file) ??
              (item.status === "added"
                ? (untracked.stats.get(item.file) ?? (yield* git.statUntracked(ctx.worktree, item.file)))
                : undefined)
            return {
              file: item.file,
              additions: stat?.additions ?? 0,
              deletions: stat?.deletions ?? 0,
              status: item.status,
            } satisfies FileStatus
          }),
      )
    }),
    diff: Effect.fn("VcsGit.diff")(function* (mode: Mode, options?: DiffOptions) {
      const git = ctx.git
      if (mode === "working") {
        return yield* track(ctx, (yield* git.hasHead(ctx.directory)) ? "HEAD" : undefined, options)
      }

      if (!(yield* git.hasHead(ctx.directory))) {
        return mode === "committed" ? [] : yield* track(ctx, undefined, options)
      }
      const base = options?.base ?? (yield* git.defaultBranch(ctx.directory))?.ref
      const ref = base ? yield* git.mergeBase(ctx.directory, base) : undefined
      if (!ref) {
        return yield* new DiffError({
          message: base ? `No merge base available for ${base}` : "No review base available",
        })
      }
      return yield* diffAgainstRef(ctx, ref, { ...options, target: mode === "committed" ? "HEAD" : undefined })
    }),
  } satisfies Adapter
}

type Kind = FileStatus["status"]

interface Item {
  readonly file: string
  readonly code: string
  readonly status: Kind
}

interface Stat {
  readonly file: string
  readonly additions: number
  readonly deletions: number
}

interface GitDiffOptions extends DiffOptions {
  readonly target?: "HEAD"
}

interface PatchOptions extends GitDiffOptions {
  readonly maxOutputBytes?: number
}

interface Ctx {
  readonly proc: AppProcess.Interface
  readonly git: GitOps
  readonly directory: string
  readonly worktree: string
}

type GitOps = ReturnType<typeof makeGit>

const cfg = [
  "--no-optional-locks",
  "-c",
  "core.autocrlf=false",
  "-c",
  "core.fsmonitor=false",
  "-c",
  "core.longpaths=true",
  "-c",
  "core.symlinks=true",
  "-c",
  "core.quotepath=false",
] as const

const kind = (code: string): Kind => {
  if (code === "??") return "added"
  if (code.includes("U")) return "modified"
  if (code.includes("A") && !code.includes("D")) return "added"
  if (code.includes("D") && !code.includes("A")) return "deleted"
  return "modified"
}

const nuls = (text: string) => text.split("\0").filter(Boolean)

const numstat = (text: string) =>
  nuls(text).flatMap((item) => {
    const a = item.indexOf("\t")
    const b = item.indexOf("\t", a + 1)
    if (a === -1 || b === -1) return []
    const file = item.slice(b + 1)
    if (!file) return []
    return [{ file, additions: count(item.slice(0, a)), deletions: count(item.slice(a + 1, b)) } satisfies Stat]
  })

const count = (value: string) => {
  const parsed = value === "-" ? 0 : Number.parseInt(value || "0", 10)
  return Number.isFinite(parsed) ? parsed : 0
}

function makeGit(proc: AppProcess.Interface, env?: Record<string, string>) {
  const run = Effect.fnUntraced(
    function* (args: string[], opts: { cwd: string; maxOutputBytes?: number }) {
      const result = yield* proc.run(
        ChildProcess.make(gitExecutable(), [...cfg, ...args], {
          cwd: opts.cwd,
          env,
          extendEnv: true,
          stdin: "ignore",
        }),
        { maxOutputBytes: opts.maxOutputBytes },
      )
      return {
        exitCode: result.exitCode,
        text: () => result.stdout.toString("utf8"),
        truncated: result.stdoutTruncated || result.stderrTruncated,
      }
    },
    Effect.orElseSucceed(() => ({ exitCode: 1, text: () => "", truncated: false })),
  )

  const text = Effect.fnUntraced(function* (args: string[], opts: { cwd: string }) {
    return (yield* run(args, opts)).text()
  })

  const lines = Effect.fnUntraced(function* (args: string[], opts: { cwd: string }) {
    return (yield* text(args, opts))
      .split(/\r?\n/)
      .map((item) => item.trim())
      .filter(Boolean)
  })

  const configured = Effect.fnUntraced(function* (cwd: string, list: string[]) {
    const result = yield* run(["config", "init.defaultBranch"], { cwd })
    const name = result.text().trim()
    if (!name || !list.includes(name)) return
    return { name, ref: name }
  })

  const primary = Effect.fnUntraced(function* (cwd: string) {
    const list = yield* lines(["remote"], { cwd })
    if (list.includes("origin")) return "origin"
    if (list.length === 1) return list[0]
    if (list.includes("upstream")) return "upstream"
    return list[0]
  })

  const branch = Effect.fn("VcsGit.branch")(function* (cwd: string) {
    const result = yield* run(["symbolic-ref", "--quiet", "--short", "HEAD"], { cwd })
    if (result.exitCode !== 0) return
    return result.text().trim() || undefined
  })

  const branches = Effect.fn("VcsGit.branches")(function* (cwd: string, options?: BranchOptions) {
    const search = options?.search?.trim().toLowerCase()
    // `refname:short` collapses `refs/remotes/<remote>/HEAD` to the bare remote name, so strip the namespace
    // instead. Search and limit apply here because ref globs cannot cross `/` and `--count` precedes the filter.
    return (yield* lines(
      [
        "for-each-ref",
        "--sort=refname",
        "--sort=-committerdate",
        "--format=%(refname:lstrip=2)",
        "refs/heads",
        "refs/remotes",
      ],
      { cwd },
    ))
      .filter((item) => !item.endsWith("/HEAD") && (!search || item.toLowerCase().includes(search)))
      .slice(0, options?.limit) satisfies BranchList
  })

  const defaultBranch = Effect.fn("VcsGit.defaultBranch")(function* (cwd: string) {
    const remote = yield* primary(cwd)
    if (remote) {
      const head = yield* run(["symbolic-ref", `refs/remotes/${remote}/HEAD`], { cwd })
      if (head.exitCode === 0) {
        const ref = head
          .text()
          .trim()
          .replace(/^refs\/remotes\//, "")
        const name = ref.startsWith(`${remote}/`) ? ref.slice(`${remote}/`.length) : ""
        if (name) return { name, ref }
      }
    }

    const list = yield* lines(["for-each-ref", "--format=%(refname:lstrip=2)", "refs/heads"], { cwd })
    const next = yield* configured(cwd, list)
    if (next) return next
    if (list.includes("main")) return { name: "main", ref: "main" }
    if (list.includes("master")) return { name: "master", ref: "master" }
  })

  const resolve = Effect.fnUntraced(function* (cwd: string, ref: string) {
    const result = yield* run(["rev-parse", "--verify", "--end-of-options", `${ref}^{commit}`], { cwd })
    if (result.exitCode !== 0) return
    return result.text().trim() || undefined
  })

  const ancestor = Effect.fnUntraced(function* (cwd: string, commit: string, ref: string) {
    if (!/^[a-f0-9]{40,64}$/.test(commit)) return false
    return (yield* run(["merge-base", "--is-ancestor", commit, ref], { cwd })).exitCode === 0
  })

  const namedRef = Effect.fnUntraced(function* (cwd: string, input: string) {
    // Creation hints must identify a branch, not HEAD, an object ID, or a revision expression.
    if (input === "HEAD" || input.endsWith("/HEAD") || /[~^:@{}\s]/.test(input)) return
    const ref = (yield* text(["rev-parse", "--symbolic-full-name", "--verify", "--end-of-options", input], {
      cwd,
    })).trim()
    if (!/^refs\/(heads|remotes)\/.+/.test(ref) || ref.endsWith("/HEAD") || !(yield* resolve(cwd, ref))) return
    return { name: ref.replace(/^refs\/heads\//, "").replace(/^refs\/remotes\/[^/]+\//, ""), ref }
  })

  const base = Effect.fn("VcsGit.base")(function* (cwd: string) {
    if (!(yield* hasHead(cwd))) return null
    const current = yield* branch(cwd)
    if (!current) return yield* new DiffError({ message: "Choose a review base" })
    const history = (yield* lines(
      ["reflog", "show", "--max-count=256", "--format=%H%x00%gs", `refs/heads/${current}`],
      {
        cwd,
      },
    )).flatMap((line) => {
      const match = /^([a-f0-9]+)\0(.+)$/.exec(line)
      return match ? [{ commit: match[1], message: match[2] }] : []
    })
    const renamed = history.some((entry) => entry.message.startsWith("Branch: renamed "))
    const creation = renamed ? undefined : history.find((entry) => entry.message.startsWith("branch: Created from "))
    const origin = creation?.message.slice("branch: Created from ".length)
    if (creation && origin) {
      const candidate = yield* namedRef(cwd, origin)
      if (
        candidate &&
        candidate.name !== current &&
        (yield* ancestor(cwd, creation.commit, "HEAD")) &&
        (yield* ancestor(cwd, creation.commit, candidate.ref))
      ) {
        return { ...candidate, source: "reflog" } satisfies Base
      }
    }
    const root = yield* defaultBranch(cwd)
    if (!root || current !== root.name) return yield* new DiffError({ message: "Choose a review base" })
    const candidate = yield* namedRef(cwd, root.ref)
    if (!candidate) return yield* new DiffError({ message: "The default review base is unavailable" })
    return { name: root.name, ref: candidate.ref, source: "default" } satisfies Base
  })

  const hasHead = Effect.fn("VcsGit.hasHead")(function* (cwd: string) {
    const result = yield* run(["rev-parse", "--verify", "HEAD"], { cwd })
    return result.exitCode === 0
  })

  const mergeBase = Effect.fn("VcsGit.mergeBase")(function* (cwd: string, base: string) {
    const ref = yield* resolve(cwd, base)
    if (!ref) return
    const result = yield* run(["merge-base", ref, "HEAD"], { cwd })
    if (result.exitCode !== 0) return
    return result.text().trim() || undefined
  })

  const status = Effect.fn("VcsGit.statusNames")(function* (
    cwd: string,
    untracked: "normal" | "all" = "normal",
    names?: readonly string[],
  ) {
    const pathspecs = names ? names.map((name) => `:(literal)${name}`) : ["."]
    return nuls(
      yield* text(
        ["status", "--porcelain=v1", `--untracked-files=${untracked}`, "--no-renames", "-z", "--", ...pathspecs],
        { cwd },
      ),
    ).flatMap((item) => {
      const file = item.slice(3)
      if (!file) return []
      const code = item.slice(0, 2)
      return [{ file, code, status: kind(code) } satisfies Item]
    })
  })

  const diff = Effect.fn("VcsGit.diffNames")(function* (cwd: string, ref: string, target?: string) {
    const result = yield* run(
      ["diff", "--no-ext-diff", "--no-renames", "--name-status", "-z", ref, ...(target ? [target] : []), "--", "."],
      { cwd },
    )
    if (result.exitCode !== 0) return yield* new DiffError({ message: "Unable to list Git changes" })
    const list = nuls(result.text())
    return list.flatMap((code, idx) => {
      if (idx % 2 !== 0) return []
      const file = list[idx + 1]
      if (!code || !file) return []
      return [{ file, code, status: kind(code) } satisfies Item]
    })
  })

  const stats = Effect.fn("VcsGit.stats")(function* (cwd: string, ref: string, target?: string) {
    return numstat(
      yield* text(
        ["diff", "--no-ext-diff", "--no-renames", "--numstat", "-z", ref, ...(target ? [target] : []), "--", "."],
        { cwd },
      ),
    )
  })

  const diffPatch = Effect.fnUntraced(function* (
    cwd: string,
    args: string[],
    options: PatchOptions | undefined,
    mode: { dropTruncated: boolean; noIndex?: boolean },
  ) {
    const result = yield* run(
      [
        "diff",
        ...(mode.noIndex ? ["--no-index"] : []),
        "--patch",
        "--no-ext-diff",
        "--no-renames",
        `--unified=${options?.context ?? 3}`,
        ...args,
      ],
      { cwd, maxOutputBytes: options?.maxOutputBytes },
    )
    return {
      text: mode.dropTruncated && result.truncated ? "" : result.text(),
      truncated: result.truncated,
    } satisfies Patch
  })

  const patch = Effect.fn("VcsGit.patch")(function* (cwd: string, ref: string, file: string, options?: PatchOptions) {
    return yield* diffPatch(cwd, [ref, ...(options?.target ? [options.target] : []), "--", file], options, {
      dropTruncated: true,
    })
  })

  const patchAll = Effect.fn("VcsGit.patchAll")(function* (cwd: string, ref: string, options?: PatchOptions) {
    return yield* diffPatch(cwd, [ref, ...(options?.target ? [options.target] : []), "--", "."], options, {
      dropTruncated: false,
    })
  })

  const patchUntracked = Effect.fn("VcsGit.patchUntracked")(function* (
    cwd: string,
    file: string,
    options?: PatchOptions,
  ) {
    // A folder entry has no patch of its own.
    if (file.endsWith("/")) return { text: "", truncated: false } satisfies Patch
    return yield* diffPatch(cwd, ["--", "/dev/null", file], options, { dropTruncated: true, noIndex: true })
  })

  const statUntracked = Effect.fn("VcsGit.statUntracked")(function* (cwd: string, file: string) {
    if (file.endsWith("/")) return
    const result = yield* run(["diff", "--no-index", "--numstat", "--", "/dev/null", file], {
      cwd,
      maxOutputBytes: 4096,
    })
    if (result.truncated) return

    const parts = result.text().split("\t")
    if (parts.length < 2) return

    return { file, additions: count(parts[0]), deletions: count(parts[1]) } satisfies Stat
  })

  // Paths are literal so names containing pathspec magic such as `*` or `[` match only themselves.
  const intentToAdd = Effect.fn("VcsGit.intentToAdd")(function* (cwd: string, list: string) {
    yield* run(
      [
        "--literal-pathspecs",
        "-c",
        "core.splitIndex=false",
        "add",
        "--intent-to-add",
        "--force",
        "--sparse",
        "--ignore-errors",
        `--pathspec-from-file=${list}`,
        "--pathspec-file-nul",
      ],
      { cwd },
    )
  })

  const worktreeStats = Effect.fn("VcsGit.worktreeStats")(function* (cwd: string) {
    return numstat(yield* text(["diff", "--no-ext-diff", "--no-renames", "--numstat", "-z"], { cwd }))
  })

  const worktreePatch = Effect.fn("VcsGit.worktreePatch")(function* (cwd: string, options?: PatchOptions) {
    return yield* diffPatch(cwd, [], options, { dropTruncated: false })
  })

  return {
    branch,
    branches,
    base,
    defaultBranch,
    hasHead,
    mergeBase,
    status,
    diff,
    stats,
    patch,
    patchAll,
    patchUntracked,
    statUntracked,
    intentToAdd,
    worktreeStats,
    worktreePatch,
  }
}

const emptyUntracked = () => ({ stats: new Map<string, Stat>(), patches: new Map<string, string>() })

/**
 * Prefetches what `statUntracked` and `patchUntracked` report, in three Git processes instead of two
 * per file. The files are recorded intent-to-add in an otherwise empty throwaway index, so a plain
 * `git diff` against it shows exactly those files as new, with the same attribute handling and patch
 * text as `git diff --no-index /dev/null <file>`. Files the batch cannot reproduce byte for byte are
 * left out, and callers fall back to the per-file commands.
 */
const untrackedBatch = Effect.fnUntraced(function* (
  ctx: Ctx,
  files: readonly string[],
  // Patches are only built when requested; status needs line counts alone.
  patches?: DiffOptions,
) {
  const eligible = yield* Effect.promise(() =>
    Promise.all(
      files.map(async (file) => {
        // Directories (nested repositories) and symlinks diff differently through an index.
        if (file.endsWith("/")) return
        const stat = await fs.lstat(path.join(ctx.worktree, file)).catch(() => undefined)
        if (!stat?.isFile()) return
        // A file this large could crowd every other file out of the batch's output budget.
        if (stat.size > MAX_TOTAL_PATCH_BYTES / 2) return
        return file
      }),
    ).then((list) => list.filter((file) => file !== undefined)),
  )
  // The batch costs up to three processes; for a single file the per-file commands are cheaper.
  if (eligible.length < 2) return emptyUntracked()

  return yield* Effect.acquireUseRelease(
    Effect.promise(async () => {
      const base = path.join(os.tmpdir(), `opencode-untracked-${randomUUID()}`)
      await fs.writeFile(`${base}.list`, eligible.map((file) => `${file}\0`).join(""))
      return base
    }),
    (base) =>
      Effect.gen(function* () {
        const git = makeGit(ctx.proc, { GIT_INDEX_FILE: `${base}.index` })
        yield* git.intentToAdd(ctx.worktree, `${base}.list`)
        const [stats, patch] = yield* Effect.all(
          [
            git.worktreeStats(ctx.worktree),
            patches
              ? git.worktreePatch(ctx.worktree, {
                  context: patches.context ?? PATCH_CONTEXT_LINES,
                  maxOutputBytes: MAX_TOTAL_PATCH_BYTES,
                })
              : Effect.succeed({ text: "", truncated: false } satisfies Patch),
          ],
          { concurrency: 2 },
        )
        const wanted = new Set(eligible)
        const headers = new Map<string, string>(eligible.map((file) => [`diff --git a/${file} b/${file}`, file]))
        return {
          stats: new Map(stats.filter((item) => wanted.has(item.file)).map((item) => [item.file, item] as const)),
          // Only chunks with the default `a/` and `b/` prefixes match the per-file output; configured
          // prefixes and quoted paths fall back to it.
          patches: new Map(
            splitGitPatch(patch).flatMap((chunk) => {
              const file = headers.get(chunk.slice(0, chunk.indexOf("\n")))
              return file === undefined ? [] : [[file, chunk] as const]
            }),
          ),
        }
      }),
    (base) =>
      Effect.promise(() =>
        Promise.all(
          [`${base}.list`, `${base}.index`, `${base}.index.lock`].map((file) => fs.rm(file, { force: true })),
        ),
      ),
  )
})

/** Entries a folder listing shows, and checks per Git call. */
const MAX_FOLDER_ENTRIES = 500

/** Entries, and time, a folder listing spends checking before it stops and reports that more were not checked. */
const MAX_FOLDER_SCAN = 5_000
const MAX_FOLDER_SCAN_MS = 1_000

/**
 * Untracked files, one by one unless the caller asks for folders. With folders, Git lists an untracked folder as one
 * `dir/` entry, as `git status` shows it, and a directory inside such a folder lists only its immediate entries, with
 * its subfolders again as one entry each.
 */
const statusItems = Effect.fnUntraced(function* (ctx: Ctx, untracked: Untracked = "files") {
  if (untracked === "files") return { list: yield* ctx.git.status(ctx.directory, "all"), more: undefined }

  const list = yield* ctx.git.status(ctx.directory)
  const prefix = path.relative(ctx.worktree, ctx.directory).split(path.sep).join("/")
  if (
    !prefix ||
    !list.some((item) => item.code === "??" && item.file.endsWith("/") && `${prefix}/`.startsWith(item.file))
  )
    return { list, more: undefined }

  const names = yield* Effect.promise(() => fs.readdir(ctx.directory).then((items) => items.toSorted()))
  // Ignored entries do not list, so check entries a batch at a time until the listing fills, the folder runs out, or
  // the scan budget does.
  const entries: Item[] = []
  const started = Date.now()
  let checked = 0
  while (
    checked < names.length &&
    entries.length < MAX_FOLDER_ENTRIES &&
    checked < MAX_FOLDER_SCAN &&
    Date.now() - started < MAX_FOLDER_SCAN_MS
  ) {
    const batch = names.slice(checked, checked + MAX_FOLDER_ENTRIES)
    checked += batch.length
    entries.push(...(yield* ctx.git.status(ctx.directory, "normal", batch)))
  }
  return {
    list: entries.slice(0, MAX_FOLDER_ENTRIES),
    more: entries.length > MAX_FOLDER_ENTRIES || checked < names.length ? `${prefix}/` : undefined,
  }
})

/** A folder listing that stopped early ends with an entry for the folder itself, marked `more`. */
const withMore = (rows: FileDiff.Info[], folder: string | undefined) =>
  folder === undefined
    ? rows
    : [...rows, { file: folder, patch: "", additions: 0, deletions: 0, status: "added" as const, more: true as const }]

const nums = (list: Stat[]) =>
  new Map(list.map((item) => [item.file, { additions: item.additions, deletions: item.deletions }] as const))

const merge = (...lists: Item[][]) => {
  const out = new Map<string, Item>()
  lists.flat().forEach((item) => {
    if (!out.has(item.file)) out.set(item.file, item)
  })
  return [...out.values()]
}

const emptyBatch = () => ({ patches: new Map<string, string>(), capped: false })

const batchPatches = Effect.fnUntraced(function* (ctx: Ctx, ref: string, list: Item[], options?: GitDiffOptions) {
  if (list.length === 0) return emptyBatch()

  const result = yield* ctx.git.patchAll(ctx.directory, ref, {
    target: options?.target,
    context: options?.context ?? PATCH_CONTEXT_LINES,
    maxOutputBytes: MAX_TOTAL_PATCH_BYTES,
  })

  return {
    patches: chunksByFile(result, (index) => list[index]?.file),
    capped: result.truncated,
  }
})

const nativePatch = Effect.fnUntraced(function* (
  ctx: Ctx,
  ref: string | undefined,
  item: Item,
  options?: GitDiffOptions,
) {
  const result =
    item.code === "??" || !ref
      ? yield* ctx.git.patchUntracked(ctx.worktree, item.file, {
          context: options?.context ?? PATCH_CONTEXT_LINES,
          maxOutputBytes: MAX_PATCH_BYTES,
        })
      : yield* ctx.git.patch(ctx.worktree, ref, item.file, {
          target: options?.target,
          context: options?.context ?? PATCH_CONTEXT_LINES,
          maxOutputBytes: MAX_PATCH_BYTES,
        })
  if (!result.truncated && result.text) return result.text

  return emptyPatch(item.file)
})

const totalPatch = (file: string, patch: string, total: number) => {
  if (total + Buffer.byteLength(patch) <= MAX_TOTAL_PATCH_BYTES) return { patch, capped: false }
  return { patch: emptyPatch(file), capped: true }
}

const patchForItem = Effect.fnUntraced(function* (
  ctx: Ctx,
  ref: string | undefined,
  item: Item,
  batch: { patches: Map<string, string>; capped: boolean },
  untracked: Map<string, string>,
  capped: boolean,
  options?: GitDiffOptions,
) {
  if (capped) return emptyPatch(item.file)

  const batched = batch.patches.get(item.file)
  if (batched !== undefined) return batched
  if (item.code !== "??" && batch.capped) return emptyPatch(item.file)
  const prefetched = item.code === "??" || !ref ? untracked.get(item.file) : undefined
  if (prefetched !== undefined) return prefetched
  return yield* nativePatch(ctx, ref, item, options)
})

const files = Effect.fnUntraced(function* (
  ctx: Ctx,
  ref: string | undefined,
  list: Item[],
  map: Map<string, { additions: number; deletions: number }>,
  batch: { patches: Map<string, string>; capped: boolean },
  options?: GitDiffOptions,
) {
  const untracked = yield* untrackedBatch(
    ctx,
    list
      .filter(
        (item) => item.code === "??" || !ref || (!options?.target && item.status === "added" && !map.has(item.file)),
      )
      .map((item) => item.file),
    options ?? {},
  )
  const next: FileDiff.Info[] = []
  let total = 0
  let capped = false

  for (const item of list.toSorted((a, b) => a.file.localeCompare(b.file))) {
    const stat =
      map.get(item.file) ??
      (!options?.target && item.status === "added"
        ? (untracked.stats.get(item.file) ?? (yield* ctx.git.statUntracked(ctx.worktree, item.file)))
        : undefined)
    const patch = yield* patchForItem(ctx, ref, item, batch, untracked.patches, capped, options)
    const result: { patch: string; capped: boolean } = capped
      ? { patch, capped: true }
      : totalPatch(item.file, patch, total)
    capped = capped || result.capped
    if (!capped) {
      total += Buffer.byteLength(result.patch)
      capped = total >= MAX_TOTAL_PATCH_BYTES
    }
    next.push({
      file: item.file,
      patch: result.patch,
      additions: stat?.additions ?? 0,
      deletions: stat?.deletions ?? 0,
      status: item.status,
    })
  }

  return next
})

const diffAgainstRef = Effect.fnUntraced(function* (ctx: Ctx, ref: string, options?: GitDiffOptions) {
  const [list, stats, extra] = yield* Effect.all(
    [
      ctx.git.diff(ctx.directory, ref, options?.target),
      ctx.git.stats(ctx.directory, ref, options?.target),
      options?.target ? Effect.succeed({ list: [], more: undefined }) : statusItems(ctx, options?.untracked),
    ],
    { concurrency: 3 },
  )
  const rows = yield* files(
    ctx,
    ref,
    merge(
      list,
      extra.list.filter((item) => item.code === "??"),
    ),
    nums(stats),
    yield* batchPatches(ctx, ref, list, options),
    options,
  )
  return withMore(rows, extra.more)
})

const track = Effect.fnUntraced(function* (ctx: Ctx, ref: string | undefined, options?: DiffOptions) {
  if (!ref) {
    const status = yield* statusItems(ctx, options?.untracked)
    return withMore(yield* files(ctx, ref, status.list, new Map(), emptyBatch(), options), status.more)
  }
  return yield* diffAgainstRef(ctx, ref, options)
})
