import { Effect } from "effect"
import { define } from "@opencode/plugin/effect/plugin"
import { Form } from "@opencode/schema/form"
import { Provider } from "../../provider.js"
import { configuredSettings } from "./configured.js"
import { credentialSettings, metadataSettings } from "./credential-settings.js"

const providerID = Provider.ID.make("cloudflare-workers-ai")

export const CloudflareWorkersAIPlugin = define({
  id: "opencode.provider.cloudflare.workers.ai",
  effect: Effect.fn(function* (ctx) {
    const configured = yield* configuredSettings(providerID)
    const form =
      typeof configured?.baseURL === "string" || resolveAccountId(configured ?? {})
        ? undefined
        : Form.Fields.make([
            {
              type: "string",
              key: "accountId",
              title: "Enter your Cloudflare Account ID",
              placeholder: "e.g. 1234567890abcdef1234567890abcdef",
              required: true,
            },
          ])
    yield* ctx.integration.transform((editor) => {
      editor.method.update({
        integrationID: providerID,
        method: { type: "env", names: ["CLOUDFLARE_API_KEY", "CLOUDFLARE_WORKERS_AI_TOKEN", "CLOUDFLARE_API_TOKEN"] },
      })
      editor.method.update({
        integrationID: providerID,
        method: {
          type: "key",
          label: "API key",
          form,
        },
      })
    })
    // The key method's form answer is stored as credential metadata.
    const login = yield* credentialSettings(ctx, providerID, (value) =>
      value.type === "key" ? metadataSettings(value.metadata, ["accountId"]) : {},
    )
    yield* ctx.provider.transform((evt) => {
      const item = evt.get(providerID)
      if (!item) return
      evt.update(item.provider.id, (provider) => {
        if (typeof provider.settings?.baseURL === "string") return
        const accountId = resolveAccountId({ ...provider.settings, ...login.settings })
        if (!accountId) return
        provider.settings =
          provider.package === "@opencode/ai/providers/cloudflare-workers-ai"
            ? { ...provider.settings, accountId }
            : { ...provider.settings, baseURL: workersEndpoint(accountId) }
      })
    })
  }),
})

function resolveAccountId(options: Record<string, unknown>) {
  return stringOption(options, "accountId") ?? process.env.CLOUDFLARE_ACCOUNT_ID
}

function workersEndpoint(accountId: string) {
  return `https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/v1`
}

function stringOption(options: Record<string, unknown>, key: string) {
  return typeof options[key] === "string" ? options[key] : undefined
}
