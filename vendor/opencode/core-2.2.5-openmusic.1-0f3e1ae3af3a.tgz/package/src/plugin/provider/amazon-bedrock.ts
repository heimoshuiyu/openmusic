import { Effect } from "effect"
import path from "node:path"
import { define } from "@opencode/plugin/effect/plugin"
import { FSUtil } from "@opencode/util/fs-util"
import { Global } from "@opencode/util/global"
import { Provider } from "../../provider.js"
import { credentialSettings, metadataSettings } from "./credential-settings.js"

// Ambient inputs the AWS default credential chain can turn into credentials
// without any key stored in opencode. Mirrors the presence checks the AWS CLI
// and SDK use before consulting shared config.
const CHAIN_ENV = [
  "AWS_PROFILE",
  "AWS_ACCESS_KEY_ID",
  "AWS_WEB_IDENTITY_TOKEN_FILE",
  "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI",
  "AWS_CONTAINER_CREDENTIALS_FULL_URI",
]

const isBedrock = (item: { readonly package: string }) =>
  item.package.startsWith("@opencode/ai/providers/amazon-bedrock")

export const AmazonBedrockPlugin = define({
  id: "opencode.provider.amazon.bedrock",
  effect: Effect.fn(function* (ctx) {
    const fs = yield* FSUtil.Service
    const paths = [
      process.env.AWS_CONFIG_FILE ?? path.join(Global.Path.home, ".aws", "config"),
      process.env.AWS_SHARED_CREDENTIALS_FILE ?? path.join(Global.Path.home, ".aws", "credentials"),
    ]
    const files = yield* Effect.all(
      paths.map((file) => fs.readFileStringSafe(file).pipe(Effect.orElseSucceed(() => undefined))),
    )
    // Discover names only. Resolving every profile here could run credential helpers or contact AWS.
    const profiles = Array.from(
      new Set(
        files.flatMap((content, index) =>
          Array.from((content ?? "").matchAll(/^\s*\[([^\]\r\n]+)\]/gm)).flatMap((match) => {
            const section = match[1].trim()
            // The credentials file uses bare names; the config file prefixes all but "default" with "profile ".
            if (index === 1 || section === "default") return [section]
            return section.startsWith("profile ") ? [section.slice(8).trim()] : []
          }),
        ),
      ),
    )
      .filter(Boolean)
      .toSorted()
    yield* ctx.integration.transform((editor) => {
      // models.dev advertises AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, and
      // AWS_REGION alongside the bearer token. Only the bearer token is a key;
      // the rest feed the SigV4 credential chain and must not become one.
      editor.method.update({
        integrationID: Provider.ID.amazonBedrock,
        method: { type: "env", names: ["AWS_BEARER_TOKEN_BEDROCK"] },
      })
      editor.method.update({
        integrationID: Provider.ID.amazonBedrock,
        method: { type: "key", label: "Bedrock API key" },
      })
      editor.method.update({
        integrationID: Provider.ID.amazonBedrock,
        method: {
          id: "aws-profile",
          type: "external",
          label: "AWS profile (SSO or named profile)",
          form: [
            {
              key: "profile",
              type: "string",
              title: "AWS profile",
              description: profiles.length
                ? `Found ${profiles.length} profile${profiles.length === 1 ? "" : "s"} in your AWS configuration.`
                : "No profiles found in your AWS configuration.",
              required: true,
              minLength: 1,
              pattern: "\\S",
              placeholder: "Profile name",
              custom: true,
              options: profiles.map((profile) => ({ value: profile, label: profile })),
            },
          ],
        },
      })
    })
    // The AWS profile method stores its form answer as credential metadata.
    const login = yield* credentialSettings(ctx, Provider.ID.amazonBedrock, (value) =>
      value.type === "external" && value.methodID === "aws-profile"
        ? metadataSettings(value.metadata, ["profile"])
        : {},
    )
    yield* ctx.provider.transform((evt) => {
      for (const item of evt.list()) {
        if (!isBedrock(item.provider)) continue
        evt.update(item.provider.id, (provider) => {
          const settings = {
            ...provider.settings,
            ...((provider.integrationID ?? provider.id) === Provider.ID.amazonBedrock ? login.settings : {}),
          }
          const chain = typeof settings.profile === "string" || CHAIN_ENV.some((name) => process.env[name])
          // SigV4 authenticates through the AWS default chain rather than a key
          // credential, so ambient AWS configuration is what makes Bedrock usable.
          if (chain && provider.activation === "auto") provider.activation = "enabled"
          // Same default the native package uses, made explicit here so catalog
          // `${AWS_REGION}` URLs resolve without any region configured.
          const region = process.env.AWS_REGION ?? process.env.AWS_DEFAULT_REGION ?? "us-east-1"
          provider.settings = {
            ...settings,
            ...(typeof settings.region !== "string" ? { region } : {}),
            // Users configure Bedrock private/VPC endpoints as `endpoint`; move it
            // into the catalog base URL once.
            ...(typeof settings.baseURL !== "string" && typeof settings.endpoint === "string"
              ? { baseURL: settings.endpoint }
              : {}),
          }
          delete provider.settings.endpoint
        })
      }
    })
  }),
})
