export * as LocationLifecycle from "./location-lifecycle.js"

import { Context, Deferred, Effect, Layer, Schema, Scope } from "effect"
import { makeLocationNode } from "@opencode/util/effect/app-node"
import { LocationEvent } from "@opencode/schema/location-event"
import { Bus } from "./bus.js"
import { Form } from "./form.js"
import { Location } from "./location.js"
import { LocationServiceMap } from "./location-service-map.js"
import { Permission } from "./permission.js"
import { Project } from "./project.js"
import { Rpc } from "./rpc.js"
import { SessionEvent } from "./session/event.js"

const isSessionEvent = Schema.is(SessionEvent.Durable)
const durableSessionEventTypes: ReadonlySet<string> = new Set(
  SessionEvent.DurableDefinitions.map((definition) => definition.type),
)

export class Service extends Context.Service<
  Service,
  {
    readonly isClosed: () => boolean
    readonly shutdown: Effect.Effect<void>
    /** Completes once shutdown has run. Long-lived holders release the Location on it so its scope can close. */
    readonly awaitShutdown: Effect.Effect<void>
    /** Keeps the idle sweep from evicting the Location for the calling scope, for open client connections. */
    readonly retain: Effect.Effect<void, never, Scope.Scope>
    readonly isRetained: () => boolean
  }
>()("@opencode/LocationLifecycle") {}

const layer = Layer.effect(
  Service,
  Effect.gen(function* () {
    const bus = yield* Bus.Service
    const location = yield* Location.Service
    const permission = yield* Permission.Service
    const forms = yield* Form.Service
    const rpc = yield* Rpc.Service
    const project = yield* Project.Service
    const scope = yield* Effect.scope
    const self = LocationServiceMap.canonical(
      Location.Ref.make({ directory: location.directory, workspaceID: location.workspaceID }),
    )
    yield* project.activate(location.project.id)
    const unsubscribe = yield* bus.listen((event) => {
      if (!event.location || !durableSessionEventTypes.has(event.type)) return Effect.void
      const ref = LocationServiceMap.canonical(event.location)
      if (ref.directory !== self.directory || ref.workspaceID !== self.workspaceID) return Effect.void
      if (!isSessionEvent(event)) return Effect.void
      // Listeners run inside publish; keep the write and its Project event off that path.
      return project.activate(location.project.id, { forkIn: scope })
    })
    yield* Effect.addFinalizer(() => unsubscribe)
    let closed = false
    let retained = 0
    const done = yield* Deferred.make<void>()
    const shutdown = Effect.suspend(() => {
      if (closed) return Deferred.await(done)
      closed = true
      return Effect.gen(function* () {
        yield* permission.close
        yield* forms.close
        yield* rpc.close
        yield* bus.publish(
          LocationEvent.Shutdown,
          {},
          {
            location: Location.Ref.make({ directory: location.directory, workspaceID: location.workspaceID }),
          },
        )
      }).pipe(Effect.ensuring(Deferred.succeed(done, undefined)))
    }).pipe(Effect.uninterruptible)
    return Service.of({
      isClosed: () => closed,
      shutdown,
      awaitShutdown: Deferred.await(done),
      retain: Effect.acquireRelease(
        Effect.sync(() => {
          retained++
        }),
        () =>
          Effect.sync(() => {
            retained--
          }),
      ),
      isRetained: () => retained > 0,
    })
  }),
)

export const node = makeLocationNode({
  service: Service,
  layer,
  deps: [Bus.node, Location.node, Permission.node, Project.node, Form.node, Rpc.node],
})
