import type { ChildProcessSpawner } from "effect/process/ChildProcessSpawner"
import type { FilesImpl } from "./files.js"

export interface Driver {
  readonly spawner: ChildProcessSpawner["Service"]
  readonly overrides?: Partial<FilesImpl>
}

export * as EnvironmentDriver from "./driver.js"
