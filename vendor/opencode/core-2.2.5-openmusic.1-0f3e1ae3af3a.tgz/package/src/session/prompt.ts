export * as SessionPrompt from "./prompt.js"

import { Base64, FileAttachment } from "@opencode/schema/prompt"
import { PromptInput } from "@opencode/schema/prompt-input"
import { SessionInbox } from "@opencode/schema/session-inbox"
import type { Session } from "@opencode/schema/session"
import type { SessionMessage } from "@opencode/schema/session-message"
import { FSUtil } from "@opencode/util/fs-util"
import { Effect, Option, Schema } from "effect"
import path from "path"
import { fileURLToPath } from "url"
import { Database } from "../database/database.js"
import { Image } from "../image.js"
import { Mime } from "../mime.js"
import { Plugin } from "../plugin/service.js"
import { PluginHooks } from "../plugin/hooks.js"
import { Skill } from "../skill.js"
import { SessionBlob } from "./blob.js"
import { Transcription } from "../transcription/transcribe.js"
import { AttachmentError, SkillNotFoundError } from "./error.js"
import { SessionStored } from "./stored.js"

// Image types the resizer can decode; others such as HEIC and AVIF go to the provider unchanged.
const RESIZABLE_IMAGE_MIMES = new Set(["image/png", "image/jpeg", "image/gif", "image/webp", "image/bmp"])

export type Input = {
  text: string
  files?: PromptInput.Prompt["files"]
  agents?: PromptInput.Prompt["agents"]
  skills?: PromptInput.Prompt["skills"]
  metadata?: Record<string, unknown>
  delivery?: SessionInbox.Delivery
}

export const prepare = Effect.fn("SessionPrompt.prepare")(function* (request: {
  session: Session.Info
  messageID: SessionMessage.ID
  input: Input
}) {
  const fs = yield* FSUtil.Service
  yield* Plugin.awaitActivation
  const hooks = yield* PluginHooks.Service
  const event = yield* hooks.trigger("session", "prompt", {
    sessionID: request.session.id,
    messageID: request.messageID,
    prompt: structuredClone({
      text: request.input.text,
      files: request.input.files?.slice(),
      agents: request.input.agents?.slice(),
      skills: request.input.skills?.slice(),
    }),
    metadata: structuredClone(request.input.metadata),
    delivery: request.input.delivery ?? "steer",
  })
  const input = event.prompt
  const files = input.files
    ? yield* Effect.forEach(input.files, materializeAttachment, { concurrency: 8 })
    : undefined
  const requested = input.skills
  const selected = yield* Effect.gen(function* () {
    if (!requested?.length) return undefined
    const skillService = yield* Skill.Service
    const prepared = new Map<Skill.ID, Skill.Name>()
    return yield* Effect.forEach(requested, (attachment) =>
      Effect.gen(function* () {
        const name = prepared.get(attachment.id)
        if (name !== undefined) return { id: attachment.id, name, mention: attachment.mention }
        const skill = yield* skillService.get(attachment.id)
        if (!skill) return yield* new SkillNotFoundError({ skill: attachment.id })
        prepared.set(skill.id, skill.name)
        const files = yield* skillService.files(skill.id)
        return {
          id: skill.id,
          name: skill.name,
          text: (yield* Skill.prepare(fs, skill, files).pipe(Effect.orDie)).output,
          mention: attachment.mention,
        }
      }),
    )
  })
  return {
    type: "user",
    payload: SessionInbox.UserPayload.make({
      text: input.text,
      agents: input.agents,
      files,
      skills: selected?.length ? selected : undefined,
      metadata: event.metadata,
    }),
    delivery: event.delivery,
  } satisfies SessionInbox.Item
})

const materializeAttachment = Effect.fn("SessionPrompt.materializeAttachment")(function* (
  input: PromptInput.FileAttachment,
) {
  // Stored blob bytes were normalized when first admitted, so a `media:` ref re-admits them unchanged.
  const ref = Schema.decodeUnknownOption(SessionStored.Ref)(input.uri)
  if (Option.isSome(ref)) {
    const blob = yield* readBlobAttachment(ref.value)
    return FileAttachment.create({
      data: Base64.make(Buffer.from(blob.data).toString("base64")),
      mime: blob.mime,
      source: input.source ?? { type: "inline" },
      name: input.name,
      description: input.description,
      mention: input.mention,
    })
  }
  const label = attachmentLabel(input)
  const resolved = input.uri.startsWith("data:")
    ? yield* decodeDataURL(input.uri, label).pipe(
        Effect.map((decoded) => ({
          ...decoded,
          source: input.source ?? { type: "inline" as const },
          start: undefined,
          end: undefined,
          name: undefined,
        })),
      )
    : yield* readFileAttachment(input.uri)
  if (resolved.bytes.byteLength > MAX_ATTACHMENT_BYTES)
    return yield* new AttachmentError({
      uri: label,
      message: `Attachment exceeds the ${MAX_ATTACHMENT_BYTES} byte limit: ${label}`,
    })

  const mime =
    resolved.source.type === "uri" && resolved.mime === "application/x-directory"
      ? resolved.mime
      : detectAttachmentMime(resolved.bytes, resolved.mime)
  const content =
    mime === "text/plain" && resolved.start !== undefined
      ? Buffer.from(
          Buffer.from(resolved.bytes)
            .toString("utf8")
            .split("\n")
            .slice(resolved.start - 1, resolved.end)
            .join("\n"),
        )
      : resolved.bytes
  const image = yield* normalizeImageAttachment(input, Buffer.from(content).toString("base64"), mime)
  const normalized = yield* normalizeAudioAttachment(input, image.data, image.mime)
  const name = input.name ?? resolved.name
  return FileAttachment.create({
    data: normalized.data,
    mime: normalized.mime,
    source: resolved.source,
    name:
      normalized.mime === "audio/mpeg" && mime !== "audio/mpeg" && name ? `${name.replace(/\.[^.]+$/, "")}.mp3` : name,
    description: input.description,
    mention: input.mention,
  })
})

const normalizeAudioAttachment = Effect.fn("SessionPrompt.normalizeAudioAttachment")(function* (
  input: PromptInput.FileAttachment,
  data: Base64,
  mime: string,
) {
  if (!mime.startsWith("audio/") || mime === "audio/mpeg" || mime === "audio/wav") return { data, mime }
  const label = attachmentLabel(input)
  const transcription = yield* Transcription.Service
  const normalized = yield* transcription
    .normalize({ bytes: Buffer.from(data, "base64"), mime })
    .pipe(
      Effect.mapError(
        (error) =>
          new AttachmentError({ uri: label, message: `Audio conversion failed for ${label}: ${error.message}` }),
      ),
    )
  return { data: Base64.make(Buffer.from(normalized.bytes).toString("base64")), mime: normalized.mime }
})

const normalizeImageAttachment = Effect.fn("SessionPrompt.normalizeImageAttachment")(function* (
  input: PromptInput.FileAttachment,
  data: string,
  mime: string,
) {
  if (!RESIZABLE_IMAGE_MIMES.has(mime)) return { data: Base64.make(data), mime }
  const image = yield* Image.Service
  const label = attachmentLabel(input)
  const content = { uri: label, content: data, encoding: "base64" as const, mime }
  const normalized = yield* image.normalize(label, content).pipe(
    Effect.catchTag("Image.ResizerUnavailableError", () => Effect.succeed(content)),
    Effect.mapError((error) => new AttachmentError({ uri: label, message: error.message })),
  )
  return { data: Base64.make(normalized.content), mime: normalized.mime }
})

/** A `media:` ref a client received from an experimental `experimental-media-uri` read, sent back as an attachment. */
const readBlobAttachment = Effect.fn("SessionPrompt.readBlobAttachment")(function* (uri: SessionStored.Ref) {
  const { db } = yield* Database.Service
  const blob = yield* SessionBlob.read(db, SessionStored.refHash(uri))
  if (!blob) return yield* new AttachmentError({ uri, message: `Attachment is no longer stored: ${uri}` })
  return blob
})

const readFileAttachment = Effect.fn("SessionPrompt.readFileAttachment")(function* (uri: string) {
  const fs = yield* FSUtil.Service
  const url = yield* Effect.try({
    try: () => new URL(uri),
    catch: () => new AttachmentError({ uri, message: `Invalid attachment URI: ${uri}` }),
  })
  if (url.protocol !== "file:")
    return yield* new AttachmentError({ uri, message: `Unsupported attachment URI: ${uri}` })
  const start = positiveInt(url.searchParams.get("start"))
  const end = positiveInt(url.searchParams.get("end"))
  const target = yield* Effect.try({
    try: () => {
      url.search = ""
      url.hash = ""
      return fileURLToPath(url)
    },
    catch: () => new AttachmentError({ uri, message: `Invalid file URI: ${uri}` }),
  })
  const info = yield* fs
    .stat(target)
    .pipe(Effect.mapError(() => new AttachmentError({ uri, message: `Unable to read attachment: ${uri}` })))
  if (info.type === "Directory") {
    const entries = yield* fs
      .readDirectoryEntries(target)
      .pipe(Effect.mapError(() => new AttachmentError({ uri, message: `Unable to read attachment: ${uri}` })))
    return {
      bytes: Buffer.from(
        entries
          .filter((entry) => entry.type === "File" || entry.type === "Directory")
          .sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name) : a.type === "Directory" ? -1 : 1))
          .map((entry) => entry.name + (entry.type === "Directory" ? path.sep : ""))
          .join("\n"),
      ),
      source: { type: "uri" as const, uri },
      start: undefined,
      end: undefined,
      name: path.basename(target),
      mime: "application/x-directory",
    }
  }
  if (info.type !== "File") return yield* new AttachmentError({ uri, message: `Attachment is not a file: ${uri}` })
  if (Number(info.size) > MAX_ATTACHMENT_BYTES)
    return yield* new AttachmentError({
      uri,
      message: `Attachment exceeds the ${MAX_ATTACHMENT_BYTES} byte limit: ${uri}`,
    })
  const bytes = yield* fs
    .readFile(target)
    .pipe(Effect.mapError(() => new AttachmentError({ uri, message: `Unable to read attachment: ${uri}` })))
  return {
    bytes,
    source: { type: "uri" as const, uri },
    start,
    end,
    name: path.basename(target),
    mime: FSUtil.mimeType(target),
  }
})

const MAX_ATTACHMENT_BYTES = 20 * 1024 * 1024

function detectAttachmentMime(bytes: Uint8Array, declared: string | undefined) {
  const mime = declared?.split(";", 1)[0]?.trim().toLowerCase()
  if (mime?.startsWith("audio/")) return mime
  return Mime.detect(bytes)
}

// A data URL is the whole file; errors and logs must name the attachment, not echo its bytes.
function attachmentLabel(input: PromptInput.FileAttachment) {
  return input.name ?? (input.uri.startsWith("data:") ? "inline attachment" : input.uri)
}

function decodeDataURL(uri: string, label: string) {
  return Effect.try({
    try: () => {
      const comma = uri.indexOf(",")
      if (comma === -1) throw new Error("Invalid data URL")
      const metadata = uri.slice(5, comma)
      const payload = uri.slice(comma + 1)
      const mime = metadata.split(";", 1)[0]?.trim().toLowerCase() || undefined
      if (!metadata.split(";").some((part) => part.toLowerCase() === "base64"))
        return { bytes: Buffer.from(decodeURIComponent(payload)), mime }
      const bytes = Buffer.from(payload, "base64")
      if (bytes.toString("base64") !== payload) throw new Error("Non-canonical base64")
      return { bytes, mime }
    },
    catch: () => new AttachmentError({ uri: label, message: `Invalid attachment data URL: ${label}` }),
  })
}

function positiveInt(value: string | null) {
  if (value === null) return
  const parsed = Number(value)
  return Number.isInteger(parsed) && parsed > 0 ? parsed : undefined
}
