import { type LLMEvent, type ProviderMetadata, type ToolResultValue } from "@opencode/ai/effect"
import { isRecord } from "@opencode/util/record"
import type { Agent } from "@opencode/schema/agent"
import type { Model } from "@opencode/schema/model"
import type { RelativePath } from "@opencode/schema/schema"
import type { Snapshot } from "@opencode/schema/snapshot"
import type { TokenUsage } from "@opencode/schema/token-usage"
import { Effect, Fiber, Iterable } from "effect"
import { isReadonlyArrayNonEmpty } from "effect/Array"
import { Bus } from "../../bus.js"
import { SessionEvent } from "../event.js"
import { SessionMessage } from "../message.js"
import { SessionSchema } from "../schema.js"
import { SessionError } from "@opencode/schema/session-error"
import { Money } from "@opencode/schema/money"
import { contentFilterError } from "../to-session-error.js"
import type { Tool } from "../../tool.js"
import { stringify } from "../../tool/runtime.js"

type Input = {
  readonly sessionID: SessionSchema.ID
  readonly agent: Agent.ID
  readonly model: Model.Ref
  readonly providerMetadataKey: string
  /** The start snapshot, awaited before `Step.Started` so its capture can overlap the provider request. */
  readonly pendingSnapshot?: Effect.Effect<Snapshot.ID | undefined>
  readonly started: number
  readonly assistantMessageID: SessionMessage.ID
}

const asRecord = (value: unknown): Record<string, unknown> => (isRecord(value) ? value : { value })

const INPUT_EXCERPT_LIMIT = 2048

type InputExcerpt = {
  readonly text: string
  readonly length: number
}

type InputFailureReason = "malformed" | "length" | "incomplete"

const INPUT_FAILURES = {
  malformed: {
    type: "tool.input-json",
    message:
      "The tool input could not be parsed as JSON, so the call was not executed. Reissue the call with valid JSON arguments.",
  },
  length: {
    type: "tool.input-incomplete",
    message:
      "The tool call was not executed because the output token limit (stop reason: length) was reached before you could complete the arguments. Break large payloads into smaller tool calls and reissue the call with complete arguments.",
  },
  incomplete: {
    type: "tool.input-incomplete",
    message: "Tool call arguments were not completed and were not executed. Reissue the call with complete arguments.",
  },
} satisfies Record<InputFailureReason, SessionError.Error>

/** Immutable fold of the durable facts a step's writer has recorded so far. */
export interface StepRecord {
  /** The model produced visible output this attempt, which bars transparent retries and overflow recovery. */
  readonly outputStarted: boolean
  readonly providerFailed: boolean
  /** The step's recorded assistant failure, if any. */
  readonly failure?: SessionError.Error
  /** Present once the provider finished the step normally. */
  readonly finish?: {
    readonly finish: Extract<LLMEvent, { type: "step-finish" }>["reason"]["normalized"]
    readonly rawFinish?: string
    readonly native?: SessionMessage.Native
    readonly usage: Extract<LLMEvent, { type: "step-finish" }>["usage"]
  }
  readonly needsContinuation: boolean
}

/** Derives canonical model content from a provider-hosted tool result. */
type NonEmptyContent = readonly [Tool.Content, ...Tool.Content[]]

const hostedContent = (result: ToolResultValue): NonEmptyContent => {
  if (result.type === "content" && isReadonlyArrayNonEmpty(result.value)) return result.value
  return [{ type: "text", text: stringify(result.value) }]
}

/**
 * Persist one step without executing tools or starting a continuation step.
 *
 * Concurrency invariant: the provider loop and each owned tool fiber call these methods
 * concurrently without a lock. Two rules keep that safe, and every method must preserve
 * them. (1) Commit state marks synchronously before the first await: never a yield
 * between a check (`tool.settled`, `stepStarted`, ...) and its mark, so check-and-mark
 * stays atomic under cooperative scheduling. Provider-event publication remains
 * uninterruptible through its writes so cancellation cannot strand a mark without
 * its durable event. (2) Never require a cross-source event
 * order: each publishing fiber is sequential, so per-source order holds by construction,
 * and consumers fold by id/ordinal rather than global position.
 */
export const createLLMEventPublisher = (bus: Pick<Bus.Interface, "publish">, input: Input) => {
  const deltaBatchInterval = 100
  type ToolState = {
    readonly name: string
    called: boolean
    settled: boolean
    providerExecuted: boolean
    progress?: Tool.Metadata
    input?: InputExcerpt
    malformed?: boolean
  }
  const tools = new Map<string, ToolState>()
  const failureSnapshot = (tool: { readonly progress?: Tool.Metadata }, metadata?: Tool.Metadata) => {
    if (tool.progress === undefined) return metadata === undefined ? {} : { metadata }
    if (metadata === undefined) return { metadata: tool.progress }
    return { metadata: { ...tool.progress, ...metadata } }
  }
  const assistantMessageID = input.assistantMessageID
  let stepStarted = false
  let providerFailed = false
  let outputStarted = false
  let stepFailure: SessionError.Error | undefined
  let stepSettlement: StepRecord["finish"]

  const startAssistant = Effect.fnUntraced(function* () {
    if (stepStarted) return assistantMessageID
    const snapshot = input.pendingSnapshot ? yield* input.pendingSnapshot : undefined
    // Check again after the await, so the check and the mark below never straddle a yield.
    if (stepStarted) return assistantMessageID
    stepStarted = true
    yield* bus.publish(SessionEvent.Step.Started, {
      sessionID: input.sessionID,
      agent: input.agent,
      model: input.model,
      assistantMessageID,
      snapshot,
      started: input.started,
    })
    return assistantMessageID
  })
  const currentAssistantMessageID = () =>
    stepStarted ? Effect.succeed(assistantMessageID) : Effect.die(new Error("Tool event before assistant step start"))
  const streamed = Effect.fnUntraced(function* () {
    yield* bus.publish(SessionEvent.Step.Streamed, {
      sessionID: input.sessionID,
      assistantMessageID: yield* startAssistant(),
    })
  })
  const native = (metadata: ProviderMetadata | undefined) => metadata?.[input.providerMetadataKey]
  const fragments = (
    name: string,
    ended: (id: string, value: string, ordinal: number, native?: SessionMessage.Native) => Effect.Effect<void>,
    delta?: (id: string, value: string, ordinal: number) => Effect.Effect<void>,
    single = false,
  ) => {
    type Fragment = {
      readonly ordinal: number
      readonly values: string[]
      pending: string
      timer?: Fiber.Fiber<void>
      native?: SessionMessage.Native
    }
    const chunks = new Map<string, Fragment>()
    let nextOrdinal = 0
    const start = (id: string, native?: SessionMessage.Native) =>
      Effect.suspend(() => {
        if (chunks.has(id)) return Effect.die(new Error(`Duplicate ${name} start: ${id}`))
        if (single && chunks.size > 0) return Effect.die(new Error(`${name} start before end: ${id}`))
        const ordinal = nextOrdinal++
        chunks.set(id, { ordinal, values: [], pending: "", native })
        return Effect.succeed(ordinal)
      })
    const publishDelta = Effect.fnUntraced(function* (id: string) {
      if (!delta) return undefined
      const current = chunks.get(id)
      if (!current) return yield* Effect.die(new Error(`${name} delta before start: ${id}`))
      if (!current.pending) return undefined
      const value = current.pending
      // New chunks can arrive while the timer is publishing this batch.
      current.pending = ""
      yield* delta(id, value, current.ordinal)
      return undefined
    }, Effect.uninterruptible)
    const append = Effect.fnUntraced(function* (id: string, value: string, native?: SessionMessage.Native) {
      const current = chunks.get(id)
      if (!current) return yield* Effect.die(new Error(`${name} delta before start: ${id}`))
      current.values.push(value)
      if (delta) current.pending += value
      if (native !== undefined) current.native = { ...current.native, ...native }
      if (current.pending && !current.timer) {
        // Own the trailing flush in the provider fiber, even if no more chunks arrive.
        current.timer = yield* Effect.gen(function* () {
          while (current.pending) {
            yield* Effect.sleep(deltaBatchInterval)
            yield* publishDelta(id)
          }
        }).pipe(
          Effect.ensuring(
            Effect.sync(() => {
              current.timer = undefined
            }),
          ),
          Effect.forkChild({ startImmediately: true }),
        )
      }
      return current.ordinal
    })
    const end = Effect.fnUntraced(function* (id: string, native?: SessionMessage.Native, value?: string) {
      const current = chunks.get(id)
      if (!current) return yield* Effect.die(new Error(`${name} end before start: ${id}`))
      if (current.timer) yield* Fiber.interrupt(current.timer)
      yield* publishDelta(id)
      yield* ended(
        id,
        value ?? current.values.join(""),
        current.ordinal,
        native === undefined ? current.native : { ...current.native, ...native },
      )
      chunks.delete(id)
      return undefined
    })
    const flush = Effect.fnUntraced(function* () {
      for (const id of Array.from(chunks.keys())) yield* end(id)
    })
    /** Publish batched deltas now, keeping every fragment open. */
    const publishPending = Effect.fnUntraced(function* () {
      for (const [id, current] of Array.from(chunks)) {
        if (current.timer) yield* Fiber.interrupt(current.timer)
        yield* publishDelta(id)
      }
    })
    return { start, append, end, flush, publishPending, has: (id: string) => chunks.has(id) }
  }

  const contentFragments = (name: string, events: typeof SessionEvent.Text | typeof SessionEvent.Reasoning) =>
    fragments(
      name,
      (_id, value, ordinal, native) =>
        Effect.gen(function* () {
          yield* bus.publish(events.Ended, {
            sessionID: input.sessionID,
            assistantMessageID: yield* currentAssistantMessageID(),
            ordinal,
            text: value,
            native,
          })
        }),
      (_id, value, ordinal) =>
        Effect.gen(function* () {
          yield* bus.publish(events.Delta, {
            sessionID: input.sessionID,
            assistantMessageID: yield* currentAssistantMessageID(),
            ordinal,
            delta: value,
          })
        }),
      true,
    )
  const text = contentFragments("text", SessionEvent.Text)
  const reasoning = contentFragments("reasoning", SessionEvent.Reasoning)
  const toolInput = fragments("tool input", (id, value) =>
    Effect.gen(function* () {
      const tool = tools.get(id)
      if (!tool) return yield* Effect.die(new Error(`Tool input end before start: ${id}`))
      // Keep a bounded excerpt for recovery errors; the full argument text is persisted below.
      tool.input = inputExcerpt(value)
      yield* bus.publish(SessionEvent.Tool.Input.Ended, {
        sessionID: input.sessionID,
        assistantMessageID,
        id,
        text: value,
      })
    }),
  )

  // Deltas are batched, but block starts are not. Publishing held deltas first keeps each
  // block's content ahead of the next block, so the published order matches the model's.
  const publishPendingDeltas = Effect.fnUntraced(function* () {
    yield* text.publishPending()
    yield* reasoning.publishPending()
  })

  const flushFragments = Effect.fnUntraced(function* () {
    yield* text.flush()
    yield* reasoning.flush()
    yield* toolInput.flush()
  })

  const startToolInput = Effect.fnUntraced(function* (event: {
    readonly id: string
    readonly name: string
    readonly providerExecuted?: boolean
  }) {
    if (tools.has(event.id)) return yield* Effect.die(new Error(`Duplicate tool input start: ${event.id}`))
    yield* startAssistant()
    const tool: ToolState = {
      name: event.name,
      called: false,
      settled: false,
      providerExecuted: event.providerExecuted === true,
    }
    tools.set(event.id, tool)
    yield* toolInput.start(event.id)
    yield* publishPendingDeltas()
    yield* bus.publish(SessionEvent.Tool.Input.Started, {
      sessionID: input.sessionID,
      assistantMessageID,
      id: event.id,
      name: event.name,
    })
    return tool
  })

  const endToolInput = Effect.fnUntraced(function* (
    event: { readonly id: string; readonly name: string },
    value?: string,
  ) {
    const tool = tools.get(event.id)
    if (!tool) return yield* Effect.die(new Error(`Tool input end before start: ${event.id}`))
    if (tool.name !== event.name)
      return yield* Effect.die(new Error(`Tool input name changed for ${event.id}: ${tool.name} -> ${event.name}`))
    if (!toolInput.has(event.id)) return yield* Effect.die(new Error(`Duplicate tool input end: ${event.id}`))
    yield* toolInput.end(event.id, undefined, value)
  })

  const failMalformedToolInput = Effect.fnUntraced(function* (event: {
    readonly id: string
    readonly name: string
    readonly raw: string
  }) {
    const tool = tools.get(event.id) ?? (yield* startToolInput(event))
    if (tool.called || tool.settled)
      return yield* Effect.die(new Error(`Malformed tool input after call settlement: ${event.id}`))
    if (tool.name !== event.name)
      return yield* Effect.die(new Error(`Tool input name changed for ${event.id}: ${tool.name} -> ${event.name}`))
    if (toolInput.has(event.id)) yield* endToolInput(event, event.raw)
    // The parser's final raw input may differ from streamed deltas; use it for the recovery excerpt.
    tool.input = inputExcerpt(event.raw)
    tool.malformed = true
  })

  const failToolInput = (id: string, tool: ToolState, reason: Exclude<InputFailureReason, "length">) =>
    failTool(id, inputFailure(tool.input, stepSettlement?.finish === "length" ? "length" : reason))

  const flush = Effect.fn("SessionRunner.flush")(function* () {
    yield* flushFragments()
    // The finish reason distinguishes invalid JSON from arguments cut off by the output limit.
    for (const [id, tool] of tools) {
      if (!tool.malformed || tool.settled) continue
      yield* failToolInput(id, tool, "malformed")
    }
  })

  const failTool = Effect.fnUntraced(function* (id: string, error: SessionError.Error, metadata?: Tool.Metadata) {
    const tool = tools.get(id)
    if (!tool || tool.settled) return false
    tool.settled = true
    yield* bus.publish(SessionEvent.Tool.Failed, {
      sessionID: input.sessionID,
      assistantMessageID,
      id,
      error:
        tool.name === "subagent" && error.type === "aborted" && typeof tool.progress?.sessionID === "string"
          ? { ...error, message: `${error.message} (sessionID: ${tool.progress.sessionID})` }
          : error,
      ...failureSnapshot(tool, metadata),
      executed: tool.providerExecuted,
    })
    return true
  })

  const failTools = Effect.fnUntraced(function* (error: SessionError.Error, mode: "all" | "hosted" | "uncalled") {
    let failed = false
    for (const [id, tool] of tools) {
      if (tool.settled || (mode === "hosted" && !tool.providerExecuted) || (mode === "uncalled" && tool.called))
        continue
      if (yield* failTool(id, error)) failed = true
    }
    return failed
  })

  const failIncompleteTools = Effect.fn("SessionRunner.failIncompleteTools")(function* () {
    for (const [id, tool] of tools) {
      if (tool.called || tool.settled) continue
      yield* failToolInput(id, tool, "incomplete")
    }
  })

  const failAssistant = Effect.fnUntraced(function* (error: SessionError.Error) {
    yield* flush()
    yield* failTools(error, "uncalled")
    yield* startAssistant()
    if (stepFailure === undefined) stepFailure = error
  })

  const publishStepFailure = Effect.fnUntraced(function* (details?: {
    readonly cost?: Money.USD
    readonly tokens?: TokenUsage.Info
    readonly snapshot?: Snapshot.ID
    readonly files?: readonly RelativePath[]
  }) {
    if (stepFailure === undefined) return
    const assistantMessageID = yield* startAssistant()
    yield* bus.publish(SessionEvent.Step.Failed, {
      sessionID: input.sessionID,
      assistantMessageID,
      error: stepFailure,
      finish: stepSettlement?.finish === "content-filter" ? stepSettlement.finish : undefined,
      rawFinish: stepSettlement?.rawFinish,
      native: stepSettlement?.native,
      ...details,
    })
  })

  const failUnsettledTools = Effect.fn("SessionRunner.failUnsettledTools")(
    (error: SessionError.Error, scope: "hosted" | "all" | "uncalled" = "all") => failTools(error, scope),
  )

  const publish = Effect.fnUntraced(function* (event: LLMEvent) {
    switch (event.type) {
      case "step-start":
        yield* startAssistant()
        return
      case "text-start":
        outputStarted = true
        const startedTextOrdinal = yield* text.start(event.id, native(event.providerMetadata))
        yield* publishPendingDeltas()
        yield* bus.publish(SessionEvent.Text.Started, {
          sessionID: input.sessionID,
          assistantMessageID: yield* startAssistant(),
          ordinal: startedTextOrdinal,
        })
        return
      case "text-delta":
        yield* text.append(event.id, event.text, native(event.providerMetadata))
        return
      case "text-end":
        yield* text.end(event.id, native(event.providerMetadata), event.text)
        return
      case "reasoning-start":
        outputStarted = true
        const startedReasoningOrdinal = yield* reasoning.start(event.id, native(event.providerMetadata))
        yield* publishPendingDeltas()
        yield* bus.publish(SessionEvent.Reasoning.Started, {
          sessionID: input.sessionID,
          assistantMessageID: yield* startAssistant(),
          ordinal: startedReasoningOrdinal,
          native: native(event.providerMetadata),
        })
        return
      case "reasoning-delta":
        yield* reasoning.append(event.id, event.text, native(event.providerMetadata))
        return
      case "reasoning-end":
        yield* reasoning.end(event.id, native(event.providerMetadata), event.text)
        return
      case "tool-input-start":
        outputStarted = true
        yield* startToolInput(event)
        return
      case "tool-input-delta": {
        const tool = tools.get(event.id)
        if (!tool) return yield* Effect.die(new Error(`Tool input delta before start: ${event.id}`))
        if (tool.name !== event.name)
          return yield* Effect.die(new Error(`Tool input name changed for ${event.id}: ${tool.name} -> ${event.name}`))
        if (!toolInput.has(event.id)) return yield* Effect.die(new Error(`Tool input delta after end: ${event.id}`))
        yield* toolInput.append(event.id, event.text)
        return
      }
      case "tool-input-end":
        yield* endToolInput(event)
        return
      case "tool-input-error":
        outputStarted = true
        yield* failMalformedToolInput(event)
        return
      case "tool-call": {
        outputStarted = true
        const tool = tools.get(event.id) ?? (yield* startToolInput(event))
        if (toolInput.has(event.id)) yield* endToolInput(event)
        if (tool.name !== event.name)
          return yield* Effect.die(new Error(`Tool call name changed for ${event.id}: ${tool.name} -> ${event.name}`))
        if (tool.called) return yield* Effect.die(new Error(`Duplicate tool call: ${event.id}`))
        tool.called = true
        tool.providerExecuted = event.providerExecuted === true
        yield* bus.publish(SessionEvent.Tool.Called, {
          sessionID: input.sessionID,
          assistantMessageID,
          id: event.id,
          input: asRecord(event.input),
          executed: tool.providerExecuted,
          native: native(event.providerMetadata),
        })
        return
      }
      case "tool-result": {
        // Provider-hosted results only; local executions publish through `toolExecution`.
        const tool = tools.get(event.id)
        if (!tool?.called) return yield* Effect.die(new Error(`Tool result before call: ${event.id}`))
        if (tool.name !== event.name)
          return yield* Effect.die(new Error(`Tool result name changed for ${event.id}: ${tool.name} -> ${event.name}`))
        if (tool.settled) {
          // A late error result is a benign straggler (e.g. after an abort
          // sweep); a late success would mean double execution, so it dies.
          if (event.result.type === "error") return
          return yield* Effect.die(new Error(`Duplicate tool result: ${event.id}`))
        }
        tool.settled = true
        const executed = event.providerExecuted === true || tool.providerExecuted
        if (event.result.type === "error") {
          yield* bus.publish(SessionEvent.Tool.Failed, {
            sessionID: input.sessionID,
            assistantMessageID,
            id: event.id,
            error: { type: "tool.execution", message: stringify(event.result.value) },
            ...failureSnapshot(tool),
            executed,
            native: native(event.providerMetadata),
          })
          return
        }
        yield* bus.publish(SessionEvent.Tool.Success, {
          sessionID: input.sessionID,
          assistantMessageID,
          id: event.id,
          content: hostedContent(event.result),
          executed,
          native: native(event.providerMetadata),
        })
        return
      }
      case "step-finish":
        yield* flushFragments()
        if (stepSettlement) return yield* Effect.die(new Error("Duplicate step finish"))
        stepSettlement = {
          finish: event.reason.normalized,
          rawFinish: event.reason.raw,
          native: native(event.providerMetadata),
          usage: event.usage,
        }
        if (event.reason.normalized === "content-filter") {
          providerFailed = true
          yield* failAssistant(contentFilterError("Provider blocked the response", event.reason))
          return
        }
        return
      case "finish":
        return
    }
  }, Effect.uninterruptible)

  const progress = Effect.fnUntraced(function* (id: string, update: Tool.Metadata) {
    const tool = tools.get(id)
    if (!tool?.called || tool.settled) return yield* Effect.die(new Error(`Tool progress outside running call: ${id}`))
    tool.progress = update
    yield* bus.publish(SessionEvent.Tool.Progress, {
      sessionID: input.sessionID,
      assistantMessageID,
      id,
      metadata: update,
    })
  })

  /** Publishes one canonical terminal event for a locally executed tool call. */
  const toolExecution = Effect.fnUntraced(function* (id: string, name: string, result: Tool.NormalizedResult) {
    const tool = tools.get(id)
    if (!tool?.called) return yield* Effect.die(new Error(`Tool execution before call: ${id}`))
    if (tool.name !== name)
      return yield* Effect.die(new Error(`Tool execution name changed for ${id}: ${tool.name} -> ${name}`))
    if (tool.settled) return yield* Effect.die(new Error(`Duplicate tool execution: ${id}`))
    tool.settled = true
    const content = result.content
    if (!isReadonlyArrayNonEmpty(content)) return yield* Effect.die(new Error(`Tool execution has no content: ${id}`))
    yield* bus.publish(SessionEvent.Tool.Success, {
      sessionID: input.sessionID,
      assistantMessageID,
      id,
      content,
      ...(result.metadata === undefined ? {} : { metadata: result.metadata }),
      executed: tool.providerExecuted,
    })
  })

  return {
    publish: (event: LLMEvent): Effect.Effect<void> => publish(event),
    progress,
    toolExecution,
    flush,
    failAssistant,
    failTool,
    publishStepFailure,
    failUnsettledTools,
    failIncompleteTools,
    hasStarted: () => stepStarted,
    /** Immutable snapshot of everything recorded for this step so far. */
    record: (): StepRecord => ({
      outputStarted,
      providerFailed,
      failure: stepFailure,
      finish: stepSettlement,
      needsContinuation: Iterable.some(
        tools.values(),
        (tool) => !tool.providerExecuted && (tool.called || tool.settled),
      ),
    }),
    startAssistant,
    streamed,
  }
}

function inputExcerpt(value: string): InputExcerpt {
  return { text: value.slice(0, INPUT_EXCERPT_LIMIT), length: value.length }
}

function inputFailure(input: InputExcerpt | undefined, reason: InputFailureReason) {
  const failure = INPUT_FAILURES[reason]
  if (!input?.length) return failure
  const truncated = input.length > input.text.length ? "\n[truncated]" : ""
  return {
    ...failure,
    message: `${failure.message}\n\nInput excerpt (first ${input.text.length} of ${input.length} characters):\n${input.text}${truncated}`,
  }
}
