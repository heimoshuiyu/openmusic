export * as SessionProjector from "./projector.js"

import { castDraft, produce, type WritableDraft } from "immer"
import { and, asc, desc, eq, gt, gte, inArray, isNull, lt, lte, or, sql } from "drizzle-orm"
import { DateTime, Effect, Layer, Option, Schema, Stream } from "effect"
import path from "path"
import { Config } from "../config.js"
import { Database } from "../database/database.js"
import { DatabaseBatch } from "../database/batch.js"
import { Bus } from "../bus.js"
import { makeGlobalNode } from "@opencode/util/effect/app-node"
import { Model } from "@opencode/schema/model"
import { SessionEvent } from "./event.js"
import { SessionMessage } from "./message.js"
import { SessionMessageUpdater } from "./message-updater.js"
import { SessionInbox } from "./inbox.js"
import { InstructionState } from "./instruction-state.js"
import { SessionBlob } from "./blob.js"
import { SessionInboxTable, SessionMessageTable, SessionPartTable, SessionTable, type SessionPartData } from "./sql.js"
import { SessionStored } from "./stored.js"
import { InstructionEntry } from "./instruction-entry.js"
import type { SQLiteUpdateSetSource } from "drizzle-orm/sqlite-core/query-builders/update"
import { Slug } from "../util/slug.js"
import { FSUtil } from "@opencode/util/fs-util"
import { Money } from "@opencode/schema/money"
import type { TokenUsage } from "@opencode/schema/token-usage"
import { Worktree } from "@opencode/schema/worktree"
import { Project } from "@opencode/schema/project"
import { AbsolutePath, RelativePath } from "../schema.js"
import type { SessionSchema } from "./schema.js"
import { SessionHistory } from "./history.js"
import { ProjectTable } from "../project/sql.js"

type DatabaseService = Database.Interface["db"]
type MessageEvent = Exclude<
  SessionEvent.DurableEvent,
  typeof SessionEvent.Forked.Type | typeof SessionEvent.Deleted.Type
>

const encodeMessage = Schema.encodeSync(SessionMessage.Info)
const encodeStoredUser = Schema.encodeSync(SessionStored.User)

export class SessionAlreadyProjected extends Error {}

type Usage = {
  cost: number
  tokens: TokenUsage.Info
}

const ForkBatchSize = 500

const insertParts = (db: DatabaseService, rows: ReadonlyArray<typeof SessionPartTable.$inferInsert>) =>
  Effect.forEach(
    DatabaseBatch.insertBatches(SessionPartTable, rows),
    (batch) => db.insert(SessionPartTable).values(batch).run().pipe(Effect.orDie),
    { discard: true },
  )

const forkTitle = (value?: string) => {
  if (value === undefined) return
  const match = value.match(/^(.+) \(fork #(\d+)\)$/)
  if (match) return `${match[1]} (fork #${Number.parseInt(match[2], 10) + 1})`
  return `${value} (fork #1)`
}

function setSession(
  db: DatabaseService,
  sessionID: SessionSchema.ID,
  values: SQLiteUpdateSetSource<typeof SessionTable>,
) {
  return db.update(SessionTable).set(values).where(eq(SessionTable.id, sessionID)).run().pipe(Effect.orDie)
}

function applyUsage(db: DatabaseService, sessionID: SessionSchema.ID, value: Usage, timeUpdated?: number) {
  return setSession(db, sessionID, {
    cost: sql`${SessionTable.cost} + ${value.cost}`,
    tokens_input: sql`${SessionTable.tokens_input} + ${value.tokens.input}`,
    tokens_output: sql`${SessionTable.tokens_output} + ${value.tokens.output}`,
    tokens_reasoning: sql`${SessionTable.tokens_reasoning} + ${value.tokens.reasoning}`,
    tokens_cache_read: sql`${SessionTable.tokens_cache_read} + ${value.tokens.cache.read}`,
    tokens_cache_write: sql`${SessionTable.tokens_cache_write} + ${value.tokens.cache.write}`,
    time_updated: timeUpdated ?? sql`${SessionTable.time_updated}`,
  })
}

function touch(db: DatabaseService, event: MessageEvent) {
  return setSession(db, event.data.sessionID, { time_updated: event.created })
}

const publishSessionUsage = Effect.fn("SessionProjector.publishUsage")(function* (
  db: DatabaseService,
  bus: Bus.Interface,
  sessionID: SessionSchema.ID,
) {
  const row = yield* db
    .select({
      cost: SessionTable.cost,
      input: SessionTable.tokens_input,
      output: SessionTable.tokens_output,
      reasoning: SessionTable.tokens_reasoning,
      cacheRead: SessionTable.tokens_cache_read,
      cacheWrite: SessionTable.tokens_cache_write,
    })
    .from(SessionTable)
    .where(eq(SessionTable.id, sessionID))
    .get()
    .pipe(Effect.orDie)
  if (!row) return
  yield* bus.publish(SessionEvent.UsageUpdated, {
    sessionID,
    cost: Money.USD.make(row.cost),
    tokens: {
      input: row.input,
      output: row.output,
      reasoning: row.reasoning,
      cache: { read: row.cacheRead, write: row.cacheWrite },
    },
  })
})

const projectFork = Effect.fn("SessionProjector.projectFork")(function* (
  db: DatabaseService,
  event: typeof SessionEvent.Forked.Type,
) {
  const parent = yield* db
    .select()
    .from(SessionTable)
    .where(eq(SessionTable.id, event.data.parentID))
    .get()
    .pipe(Effect.orDie)
  if (!parent) return yield* Effect.die(new Error(`Fork parent session not found: ${event.data.parentID}`))
  const boundary = yield* db
    .select({ seq: SessionMessageTable.seq })
    .from(SessionMessageTable)
    .where(
      and(
        eq(SessionMessageTable.session_id, event.data.parentID),
        eq(SessionMessageTable.id, event.data.boundary.messageID),
      ),
    )
    .get()
    .pipe(Effect.orDie)
  if (!boundary)
    return yield* Effect.die(new Error(`Fork boundary message not found: ${event.data.boundary.messageID}`))
  const copied = yield* db
    .select({ seq: SessionMessageTable.seq })
    .from(SessionMessageTable)
    .where(
      and(
        eq(SessionMessageTable.session_id, event.data.parentID),
        event.data.boundary.type === "before"
          ? lt(SessionMessageTable.seq, boundary.seq)
          : lte(SessionMessageTable.seq, boundary.seq),
      ),
    )
    .orderBy(desc(SessionMessageTable.seq))
    .limit(1)
    .get()
    .pipe(Effect.orDie)
  const copiedSeq = copied?.seq

  const stored = yield* db
    .insert(SessionTable)
    .values({
      id: event.data.sessionID,
      parent_id: null,
      fork_session_id: event.data.parentID,
      fork_boundary: event.data.boundary,
      project_id: parent.project_id,
      workspace_id: parent.workspace_id,
      slug: Slug.create(),
      directory: parent.directory,
      path: parent.path,
      title: forkTitle(parent.title ?? undefined),
      agent: parent.agent,
      model: parent.model,
      metadata: parent.metadata,
      permission: parent.permission,
      version: parent.version,
      cost: 0,
      tokens_input: 0,
      tokens_output: 0,
      tokens_reasoning: 0,
      tokens_cache_read: 0,
      tokens_cache_write: 0,
      time_created: event.created,
      time_updated: event.created,
    })
    .onConflictDoNothing()
    .returning({ sessionID: SessionTable.id })
    .get()
    .pipe(Effect.orDie)
  if (!stored) return yield* Effect.die(new SessionAlreadyProjected())

  if (event.data.instructionEntries)
    yield* InstructionEntry.initialize(db, event.data.sessionID, event.data.instructionEntries, event.created)

  const forkedID = (seq: number) => SessionMessage.ID.make(`${SessionMessage.ID.fromEvent(event.id)}_${seq}`)
  // The child stores the parent's inline media as blobs; the parent's rows are never rewritten.
  const media = yield* SessionBlob.ForkMedia
  let cursor = -1
  while (copiedSeq !== undefined) {
    const rows = yield* db
      .select()
      .from(SessionMessageTable)
      .where(
        and(
          eq(SessionMessageTable.session_id, event.data.parentID),
          gt(SessionMessageTable.seq, cursor),
          lt(SessionMessageTable.seq, copiedSeq + 1),
          // Terminal events for active projections stay on the parent, so forks copy only settled history.
          sql`${SessionMessageTable.type} != 'assistant' or json_extract(${SessionMessageTable.data}, '$.time.completed') is not null`,
          sql`${SessionMessageTable.type} != 'shell' or json_extract(${SessionMessageTable.data}, '$.status') != 'running'`,
          sql`${SessionMessageTable.type} != 'compaction' or json_extract(${SessionMessageTable.data}, '$.status') != 'running'`,
        ),
      )
      .orderBy(asc(SessionMessageTable.seq))
      .limit(ForkBatchSize)
      .all()
      .pipe(Effect.orDie)
    if (rows.length === 0) break

    const values = yield* Effect.forEach(rows, (row) =>
      Effect.gen(function* () {
        const copy = {
          id: forkedID(row.seq),
          session_id: event.data.sessionID,
          type: row.type,
          seq: row.seq,
          time_created: row.time_created,
          time_updated: row.time_updated,
          // Split parents' envelopes carry no content, so only unsplit parents' inline media moves here.
          data: media ? yield* SessionBlob.externalizeRow(db, row.data) : row.data,
        }
        // A summary references the first message it kept, which the fork copied under a new ID.
        const keepID = row.type === "compaction" ? row.data.metadata?.keepID : undefined
        if (!Schema.is(SessionMessage.ID)(keepID)) return copy
        const kept = yield* db
          .select({ seq: SessionMessageTable.seq })
          .from(SessionMessageTable)
          .where(and(eq(SessionMessageTable.session_id, event.data.parentID), eq(SessionMessageTable.id, keepID)))
          .get()
          .pipe(Effect.orDie)
        if (!kept) return copy
        return {
          ...copy,
          data: { ...row.data, metadata: { ...row.data.metadata, keepID: forkedID(kept.seq) } },
        }
      }),
    )
    yield* Effect.forEach(
      DatabaseBatch.insertBatches(SessionMessageTable, values),
      (batch) => db.insert(SessionMessageTable).values(batch).run().pipe(Effect.orDie),
      { discard: true },
    )
    yield* Effect.forEach(
      values,
      (value) =>
        SessionBlob.recordRefs(
          db,
          { sessionID: event.data.sessionID, messageID: value.id, seq: value.seq },
          value.data,
        ),
      { discard: true },
    )

    const assistantRows = rows.filter((row) => row.type === "assistant")
    if (assistantRows.length > 0) {
      const idMap = new Map(assistantRows.map((row) => [row.id, forkedID(row.seq)]))
      const storedParts = yield* Effect.forEach(DatabaseBatch.batches([...idMap.keys()], 1, 1), (ids) =>
        db
          .select()
          .from(SessionPartTable)
          .where(and(eq(SessionPartTable.session_id, event.data.parentID), inArray(SessionPartTable.message_id, ids)))
          .orderBy(asc(SessionPartTable.message_id), asc(SessionPartTable.ordinal))
          .all()
          .pipe(Effect.orDie),
      ).pipe(Effect.map((batches) => batches.flat()))
      const partValues: Array<typeof SessionPartTable.$inferInsert> = yield* Effect.forEach(storedParts, (part) =>
        Effect.gen(function* () {
          const data = media ? SessionBlob.split(part.data) : undefined
          if (data?.moved) yield* SessionBlob.save(db, data.blobs)
          return {
            message_id: idMap.get(part.message_id)!,
            session_id: event.data.sessionID,
            ordinal: part.ordinal,
            type: part.type,
            call_id: part.call_id,
            time_created: part.time_created,
            time_updated: part.time_updated,
            data: data?.data ?? part.data,
          }
        }),
      )
      yield* insertParts(db, partValues)
      // Split parents' envelopes carry no content, so the parts' refs are recorded for each forked message here.
      const partsByMessage = Map.groupBy(partValues, (part) => part.message_id)
      yield* Effect.forEach(
        assistantRows,
        (row) => {
          const messageID = idMap.get(row.id)!
          const content = (partsByMessage.get(messageID) ?? []).map((part) => part.data)
          return SessionBlob.recordRefs(db, { sessionID: event.data.sessionID, messageID, seq: row.seq }, { content })
        },
        { discard: true },
      )
    }

    cursor = rows.at(-1)!.seq
  }
  if (copiedSeq !== undefined) yield* Bus.reserveSequence(db, event.data.sessionID, copiedSeq)
  if (event.data.instructions)
    yield* InstructionState.initialize(db, event.data.sessionID, event.durable.seq, event.data.instructions)
})

/** Reads `experimental.part_rows` from the Config in scope on every call; without one, it is off. */
const partRowsEnabled = Effect.gen(function* () {
  const config = yield* Effect.serviceOption(Config.Service)
  if (Option.isNone(config)) return false
  return Config.latest(yield* config.value.entries(), "experimental")?.part_rows === true
})

type MessageRow = typeof SessionMessageTable.$inferSelect
type PartRow = typeof SessionPartTable.$inferSelect
type Writes = Pick<
  SessionMessageUpdater.Adapter,
  | "getCurrentAssistant"
  | "getAssistant"
  | "updateAssistant"
  | "appendAssistantPart"
  | "updateAssistantPart"
  | "replaceAssistantParts"
  | "updateShell"
  | "updateCompaction"
>

function run(db: DatabaseService, event: MessageEvent) {
  return Effect.gen(function* () {
    const writes = (yield* partRowsEnabled) ? partRowWrites(db, event) : messageWrites(db, event)
    const adapter: SessionMessageUpdater.Adapter = {
      ...writes,
      getAgent() {
        return db
          .select({ agent: SessionTable.agent })
          .from(SessionTable)
          .where(eq(SessionTable.id, event.data.sessionID))
          .get()
          .pipe(
            Effect.orDie,
            Effect.map((row) => row?.agent ?? undefined),
          )
      },
      getModel() {
        return db
          .select({ model: SessionTable.model })
          .from(SessionTable)
          .where(eq(SessionTable.id, event.data.sessionID))
          .get()
          .pipe(
            Effect.orDie,
            Effect.map((row) => (row?.model ? Schema.decodeUnknownSync(Model.Ref)(row.model) : undefined)),
          )
      },
      getLocation() {
        return db
          .select({
            directory: SessionTable.directory,
            workspaceID: SessionTable.workspace_id,
            projectID: SessionTable.project_id,
            subpath: SessionTable.path,
          })
          .from(SessionTable)
          .where(eq(SessionTable.id, event.data.sessionID))
          .get()
          .pipe(
            Effect.orDie,
            Effect.map((row) =>
              row
                ? {
                    location: {
                      directory: AbsolutePath.make(row.directory),
                      workspaceID: row.workspaceID ?? undefined,
                    },
                    projectID: row.projectID,
                    subpath: row.subpath === null ? undefined : RelativePath.make(row.subpath),
                  }
                : undefined,
            ),
          )
      },
      getShell(shellID) {
        return Effect.gen(function* () {
          const row = yield* db
            .select()
            .from(SessionMessageTable)
            .where(
              and(
                eq(SessionMessageTable.session_id, event.data.sessionID),
                eq(SessionMessageTable.type, "shell"),
                sql`json_extract(${SessionMessageTable.data}, '$.shellID') = ${shellID}`,
              ),
            )
            .orderBy(desc(SessionMessageTable.seq))
            .limit(1)
            .get()
            .pipe(Effect.orDie)
          if (!row) return
          const message = SessionHistory.decodeMessageRowSync(row)
          return message.type === "shell" ? message : undefined
        })
      },
      getCompaction() {
        return Effect.gen(function* () {
          const row = yield* db
            .select()
            .from(SessionMessageTable)
            .where(
              and(
                eq(SessionMessageTable.session_id, event.data.sessionID),
                eq(SessionMessageTable.type, "compaction"),
                sql`json_extract(${SessionMessageTable.data}, '$.status') = 'running'`,
              ),
            )
            .orderBy(desc(SessionMessageTable.seq))
            .limit(1)
            .get()
            .pipe(Effect.orDie)
          if (!row) return
          const message = SessionHistory.decodeMessageRowSync(row)
          return message.type === "compaction" ? message : undefined
        })
      },
      appendMessage: (message) => insertMessage(db, event, message),
    }
    yield* SessionMessageUpdater.update(adapter, event)
  })
}

/** Assistant reads shared by both write paths; `decode` decides whether part rows are folded into `content`. */
function assistantReads(
  db: DatabaseService,
  event: MessageEvent,
  decode: (row: MessageRow) => Effect.Effect<SessionMessage.Info>,
): Pick<Writes, "getCurrentAssistant" | "getAssistant"> {
  return {
    getCurrentAssistant() {
      return Effect.gen(function* () {
        // A newer step supersedes stale incomplete rows; never resume an older assistant projection.
        const row = yield* db
          .select()
          .from(SessionMessageTable)
          .where(
            and(eq(SessionMessageTable.session_id, event.data.sessionID), eq(SessionMessageTable.type, "assistant")),
          )
          .orderBy(desc(SessionMessageTable.seq))
          .limit(1)
          .get()
          .pipe(Effect.orDie)
        if (!row || ("completed" in row.data.time && row.data.time.completed)) return
        const message = yield* decode(row)
        return message.type === "assistant" && !message.time.completed ? message : undefined
      })
    },
    getAssistant(messageID) {
      return Effect.gen(function* () {
        const row = yield* db
          .select()
          .from(SessionMessageTable)
          .where(
            and(
              eq(SessionMessageTable.id, messageID),
              eq(SessionMessageTable.session_id, event.data.sessionID),
              eq(SessionMessageTable.type, "assistant"),
            ),
          )
          .get()
          .pipe(Effect.orDie)
        if (!row) return
        const message = yield* decode(row)
        return message.type === "assistant" ? message : undefined
      })
    },
  }
}

/**
 * The write path with `experimental.part_rows` off, unchanged from before part rows were written: every assistant
 * event rewrites the whole message. A message whose parts already live in session_part (written with the flag on,
 * or by a newer release) is written into those rows, and its row keeps an empty envelope.
 */
function messageWrites(db: DatabaseService, event: MessageEvent): Writes {
  const partRows = (messageID: SessionMessage.ID) =>
    db
      .select()
      .from(SessionPartTable)
      .where(eq(SessionPartTable.message_id, messageID))
      .orderBy(asc(SessionPartTable.ordinal))
      .all()
      .pipe(Effect.orDie)
  // Writes `content` over a message's existing part rows, touching only the rows that changed.
  const writeParts = Effect.fnUntraced(function* (
    messageID: SessionMessage.ID,
    existing: ReadonlyArray<PartRow>,
    content: ReadonlyArray<SessionPartData>,
  ) {
    let next = (existing.at(-1)?.ordinal ?? -1) + 1
    for (const [index, part] of content.entries()) {
      const current = existing[index]
      const columns = { type: part.type, call_id: part.type === "tool" ? part.id : null, data: part }
      if (current === undefined)
        yield* db
          .insert(SessionPartTable)
          .values({
            ...columns,
            message_id: messageID,
            session_id: event.data.sessionID,
            ordinal: next++,
            time_created: event.created,
            time_updated: event.created,
          })
          .run()
          .pipe(Effect.orDie)
      else if (JSON.stringify(current.data) !== JSON.stringify(part))
        yield* db
          .update(SessionPartTable)
          .set({ ...columns, time_updated: event.created })
          .where(and(eq(SessionPartTable.message_id, messageID), eq(SessionPartTable.ordinal, current.ordinal)))
          .run()
          .pipe(Effect.orDie)
    }
    const stale = existing.slice(content.length).map((part) => part.ordinal)
    if (stale.length > 0)
      yield* db
        .delete(SessionPartTable)
        .where(and(eq(SessionPartTable.message_id, messageID), inArray(SessionPartTable.ordinal, stale)))
        .run()
        .pipe(Effect.orDie)
  })
  const updateMessage = Effect.fnUntraced(function* (message: SessionMessage.Info) {
    const stored = yield* SessionBlob.externalize(db, message)
    const { id: _, type, ...data } = encodeStored(stored)
    const parts = message.type === "assistant" && "content" in data ? yield* partRows(message.id) : []
    const updated = yield* db
      .update(SessionMessageTable)
      .set({
        type,
        time_created: DateTime.toEpochMillis(message.time.created),
        data: parts.length > 0 && "content" in data ? { ...data, content: [] } : data,
      })
      .where(and(eq(SessionMessageTable.id, message.id), eq(SessionMessageTable.session_id, event.data.sessionID)))
      .returning({ seq: SessionMessageTable.seq })
      .get()
      .pipe(Effect.orDie)
    if (!updated) return
    if (parts.length > 0 && "content" in data) yield* writeParts(message.id, parts, data.content)
    const owner = { sessionID: event.data.sessionID, messageID: message.id, seq: updated.seq }
    // Most updates only carry existing refs forward; a content rewrite may also drop some. `externalize` returns
    // the same message when it extracted nothing, so streaming updates skip the ref tables entirely.
    if (event.type === SessionEvent.MessageContentUpdated.type) yield* SessionBlob.syncRefs(db, owner, data)
    else if (stored !== message) yield* SessionBlob.recordRefs(db, owner, data)
  })
  const reads = assistantReads(db, event, (row) =>
    SessionHistory.withParts(db, [row]).pipe(
      Effect.map(([withParts = row]) => SessionHistory.decodeMessageRowSync(withParts)),
    ),
  )
  const editAssistant = (
    messageID: SessionMessage.ID,
    recipe: (draft: WritableDraft<SessionMessage.Assistant>) => void,
  ) =>
    Effect.gen(function* () {
      const assistant = yield* reads.getAssistant(messageID)
      if (!assistant) return
      yield* updateMessage(produce(assistant, recipe))
    })
  return {
    ...reads,
    updateAssistant: updateMessage,
    updateShell: updateMessage,
    updateCompaction: updateMessage,
    appendAssistantPart: (messageID, part) =>
      editAssistant(messageID, (draft) => {
        draft.content.push(castDraft(part))
      }),
    updateAssistantPart: (messageID, match, recipe) =>
      editAssistant(messageID, (draft) => {
        const found = draft.content.findLast(
          (
            item,
          ): item is WritableDraft<Extract<SessionMessage.AssistantContent, { readonly type: typeof match.type }>> =>
            item.type === match.type &&
            (match.callID === undefined || (item.type === "tool" && item.id === match.callID)) &&
            (!match.incompleteReasoning || (item.type === "reasoning" && !item.time?.completed)),
        )
        if (found) recipe(found)
      }),
    replaceAssistantParts: (messageID, parts) =>
      editAssistant(messageID, (draft) => {
        draft.content = castDraft([...parts])
      }),
  }
}

/** The write path with `experimental.part_rows` on: each assistant part is its own session_part row. */
function partRowWrites(db: DatabaseService, event: MessageEvent): Writes {
  /**
   * The only place a legacy inline assistant row moves to session_part, called right before its parts are written.
   * `carry: false` drops the inline parts instead of copying them, for a write that replaces them all. Returns the
   * owner the message's part refs belong to.
   */
  const prepareAssistantParts = Effect.fnUntraced(function* (messageID: SessionMessage.ID, carry: boolean) {
    const row = yield* db
      .select({
        id: SessionMessageTable.id,
        seq: SessionMessageTable.seq,
        inlineCount: sql<number>`json_array_length(${SessionMessageTable.data}, '$.content')`,
      })
      .from(SessionMessageTable)
      .where(
        and(
          eq(SessionMessageTable.id, messageID),
          eq(SessionMessageTable.session_id, event.data.sessionID),
          eq(SessionMessageTable.type, "assistant"),
        ),
      )
      .get()
      .pipe(Effect.orDie)
    if (!row) return
    const full =
      row.inlineCount > 0
        ? yield* db
            .select()
            .from(SessionMessageTable)
            .where(eq(SessionMessageTable.id, messageID))
            .get()
            .pipe(Effect.orDie)
        : undefined
    const message = full ? SessionHistory.decodeMessageRowSync(full) : undefined
    if (full && message?.type === "assistant") {
      if (carry) {
        // An older build that wrote inline content while part rows existed leaves both shapes on one message.
        // Keep the rows and append the inline parts after them, so a downgrade and re-upgrade loses nothing.
        const last = yield* db
          .select({ ordinal: sql<number | null>`max(${SessionPartTable.ordinal})` })
          .from(SessionPartTable)
          .where(eq(SessionPartTable.message_id, messageID))
          .get()
          .pipe(Effect.orDie)
        const first = (last?.ordinal ?? -1) + 1
        const partRows = message.content.map((part, index) => ({
          message_id: messageID,
          session_id: event.data.sessionID,
          ordinal: first + index,
          type: part.type,
          call_id: part.type === "tool" ? part.id : null,
          time_created: full.time_created,
          time_updated: event.created,
          data: SessionHistory.encodePart(part),
        }))
        yield* insertParts(db, partRows)
      }
      const { id: _, type: __, ...data } = encodeMessage({ ...message, content: [] })
      yield* db
        .update(SessionMessageTable)
        .set({ data })
        .where(and(eq(SessionMessageTable.id, messageID), eq(SessionMessageTable.session_id, event.data.sessionID)))
        .run()
        .pipe(Effect.orDie)
    }
    return { sessionID: event.data.sessionID, messageID, seq: row.seq } satisfies SessionBlob.Owner
  })
  // Assistant content is written only by the part methods below, which also record its blob refs. Envelope updates
  // keep whatever content the row already holds: inline for a legacy row that was never split, [] once it was.
  const updateMessage = (message: SessionMessage.Info) => {
    const {
      id: _,
      type: __,
      ...data
    } = encodeMessage(message.type === "assistant" ? { ...message, content: [] } : message)
    return db
      .update(SessionMessageTable)
      .set({
        ...(event.type === SessionEvent.Step.Started.type
          ? { time_created: DateTime.toEpochMillis(message.time.created) }
          : {}),
        data:
          message.type === "assistant"
            ? sql`json_set(${JSON.stringify(data)}, '$.content', json(coalesce(${SessionMessageTable.data} -> '$.content', '[]')))`
            : data,
      })
      .where(and(eq(SessionMessageTable.id, message.id), eq(SessionMessageTable.session_id, event.data.sessionID)))
      .run()
      .pipe(Effect.orDie)
  }
  const reads = assistantReads(db, event, (row) => Effect.sync(() => SessionHistory.decodeMessageRowSync(row)))
  return {
    ...reads,
    appendAssistantPart(messageID, part) {
      return Effect.gen(function* () {
        const owner = yield* prepareAssistantParts(messageID, true)
        if (!owner) return
        const data = SessionHistory.encodePart(yield* SessionBlob.externalizePart(db, part))
        const next = yield* db
          .select({ ordinal: sql<number>`coalesce(max(${SessionPartTable.ordinal}) + 1, 0)` })
          .from(SessionPartTable)
          .where(eq(SessionPartTable.message_id, messageID))
          .get()
          .pipe(Effect.orDie)
        yield* db
          .insert(SessionPartTable)
          .values({
            message_id: messageID,
            session_id: event.data.sessionID,
            ordinal: next?.ordinal ?? 0,
            type: part.type,
            call_id: part.type === "tool" ? part.id : null,
            time_created: event.created,
            time_updated: event.created,
            data,
          })
          .run()
          .pipe(Effect.orDie)
        yield* SessionBlob.recordRefs(db, owner, { content: [data] })
      })
    },
    updateAssistantPart(messageID, match, recipe) {
      return Effect.gen(function* () {
        const owner = yield* prepareAssistantParts(messageID, true)
        if (!owner) return
        const row = yield* db
          .select()
          .from(SessionPartTable)
          .where(
            and(
              eq(SessionPartTable.message_id, messageID),
              eq(SessionPartTable.session_id, event.data.sessionID),
              eq(SessionPartTable.type, match.type),
              match.callID !== undefined ? eq(SessionPartTable.call_id, match.callID) : undefined,
              match.incompleteReasoning
                ? sql`json_extract(${SessionPartTable.data}, '$.time.completed') is null`
                : undefined,
            ),
          )
          .orderBy(desc(SessionPartTable.ordinal))
          .limit(1)
          .get()
          .pipe(Effect.orDie)
        if (!row) return

        const current = SessionHistory.decodePartRowSync(row) as Extract<
          SessionMessage.AssistantContent,
          { readonly type: typeof match.type }
        >
        const updated = produce(current, recipe)
        if (updated === current) return
        // `externalizePart` returns the same part when it moved nothing, so streaming updates skip the ref tables.
        const stored = yield* SessionBlob.externalizePart(db, updated)
        const data = SessionHistory.encodePart(stored)
        yield* db
          .update(SessionPartTable)
          .set({ data, time_updated: event.created })
          .where(and(eq(SessionPartTable.message_id, messageID), eq(SessionPartTable.ordinal, row.ordinal)))
          .run()
          .pipe(Effect.orDie)
        if (stored !== updated) yield* SessionBlob.recordRefs(db, owner, { content: [data] })
      })
    },
    replaceAssistantParts(messageID, parts) {
      return Effect.gen(function* () {
        const owner = yield* prepareAssistantParts(messageID, false)
        if (!owner) return
        yield* db.delete(SessionPartTable).where(eq(SessionPartTable.message_id, messageID)).run().pipe(Effect.orDie)
        const stored = yield* Effect.forEach(parts, (part) => SessionBlob.externalizePart(db, part))
        const partRows = stored.map((part, ordinal) => ({
          message_id: messageID,
          session_id: event.data.sessionID,
          ordinal,
          type: part.type,
          call_id: part.type === "tool" ? part.id : null,
          time_created: event.created,
          time_updated: event.created,
          data: SessionHistory.encodePart(part),
        }))
        yield* insertParts(db, partRows)
        // A content rewrite may drop media, so refs the new parts no longer name are released.
        yield* SessionBlob.syncRefs(db, owner, { content: partRows.map((part) => part.data) })
      })
    },
    updateAssistant: updateMessage,
    updateShell: updateMessage,
    updateCompaction: updateMessage,
  }
}

const encodeStored = (message: SessionMessage.Info | SessionStored.User) =>
  message.type === "user" ? encodeStoredUser(message) : encodeMessage(message)

const insertMessage = Effect.fnUntraced(function* (
  db: DatabaseService,
  event: SessionEvent.DurableEvent,
  message: SessionMessage.Info | SessionStored.User,
) {
  const stored = yield* SessionBlob.externalize(db, message)
  const { id: _, type, ...data } = encodeStored(stored)
  const timeCreated = DateTime.toEpochMillis(message.time.created)
  // Assistant content goes to session_part rows; the message row keeps an empty envelope.
  const parts = stored.type === "assistant" ? stored.content : []
  yield* db
    .insert(SessionMessageTable)
    .values({
      id: message.id,
      session_id: event.data.sessionID,
      type,
      seq: event.durable.seq,
      time_created: timeCreated,
      data: "content" in data && parts.length > 0 ? { ...data, content: [] } : data,
    })
    .run()
    .pipe(Effect.orDie)
  const partRows = parts.map((part, ordinal) => ({
    message_id: message.id,
    session_id: event.data.sessionID,
    ordinal,
    type: part.type,
    call_id: part.type === "tool" ? part.id : null,
    time_created: timeCreated,
    time_updated: event.created,
    data: SessionHistory.encodePart(part),
  }))
  yield* insertParts(db, partRows)
  yield* SessionBlob.recordRefs(
    db,
    { sessionID: event.data.sessionID, messageID: message.id, seq: event.durable.seq },
    data,
  )
})

function projectIdle(
  db: DatabaseService,
  event:
    | typeof SessionEvent.Execution.Succeeded.Type
    | typeof SessionEvent.Execution.Failed.Type
    | typeof SessionEvent.Execution.Interrupted.Type,
) {
  return Effect.gen(function* () {
    yield* run(db, event)
    if (event.type === SessionEvent.Execution.Interrupted.type && event.data.reason === "shutdown") return
    const time = event.created
    const outcome =
      event.type === SessionEvent.Execution.Succeeded.type
        ? "succeeded"
        : event.type === SessionEvent.Execution.Failed.type
          ? "failed"
          : "interrupted"
    yield* setSession(db, event.data.sessionID, {
      // Unread uses a strict timestamp comparison, so every terminal must advance even within one millisecond.
      time_idle: sql`max(${time}, coalesce(${SessionTable.time_idle} + 1, ${time}))`,
      idle_outcome: outcome,
      time_updated: sql`${SessionTable.time_updated}`,
    })
  })
}

const layer = Layer.effectDiscard(
  Effect.gen(function* () {
    const bus = yield* Bus.Service
    const db = (yield* Database.Service).db
    yield* bus.project(SessionEvent.Created, (event) =>
      Effect.gen(function* () {
        const stored = yield* db
          .insert(SessionTable)
          .values({
            id: event.data.sessionID,
            project_id: event.data.projectID,
            workspace_id: event.data.location.workspaceID ?? null,
            parent_id: event.data.parentID,
            slug: event.data.slug,
            directory: event.data.location.directory,
            path: event.data.subpath,
            title: event.data.title,
            agent: event.data.agent,
            model: event.data.model,
            metadata: event.data.metadata,
            permission: event.data.permissions,
            version: event.data.version,
            time_created: event.created,
            time_updated: event.created,
          })
          .onConflictDoNothing()
          .returning({ sessionID: SessionTable.id })
          .get()
          .pipe(Effect.orDie)
        if (!stored) return yield* Effect.die(new SessionAlreadyProjected())
      }),
    )
    yield* bus.project(SessionEvent.Moved, (event) =>
      Effect.gen(function* () {
        yield* run(db, event)
        yield* setSession(db, event.data.sessionID, {
          directory: event.data.location.directory,
          path: event.data.subpath,
          ...(event.data.projectID ? { project_id: event.data.projectID } : {}),
          workspace_id: event.data.location.workspaceID ?? null,
          time_updated: event.created,
        })
      }),
    )
    // Sessions whose ownership came from the directory's previous resolution
    // follow its new identity. Location, transcript, instructions, and recency
    // are untouched: the session did not move, its directory got identified.
    yield* bus.project(Worktree.Event.Resolved, (event) =>
      Effect.gen(function* () {
        const candidates = [
          ...new Set(
            [event.data.previous, Project.ID.global, ...(event.data.adopted ?? [])].filter(
              (id) => id !== event.data.projectID,
            ),
          ),
        ]
        if (candidates.length === 0) return
        const rows = yield* db
          .select({
            id: SessionTable.id,
            directory: SessionTable.directory,
            projectID: SessionTable.project_id,
            canonical: ProjectTable.worktree,
          })
          .from(SessionTable)
          .innerJoin(ProjectTable, eq(SessionTable.project_id, ProjectTable.id))
          .where(
            and(
              inArray(SessionTable.project_id, candidates),
              isNull(SessionTable.workspace_id),
              or(
                event.data.adopted?.length ? inArray(SessionTable.project_id, event.data.adopted) : undefined,
                and(
                  gte(SessionTable.directory, event.data.directory),
                  lte(SessionTable.directory, AbsolutePath.make(event.data.directory + "\uffff")),
                ),
              ),
            ),
          )
          .all()
          .pipe(Effect.orDie)
        yield* Effect.forEach(
          rows,
          (row) => {
            const directory = event.data.adopted?.includes(row.projectID)
              ? row.canonical
              : AbsolutePath.make(path.resolve(row.directory))
            if (!FSUtil.contains(event.data.directory, directory)) return Effect.void
            return setSession(db, row.id, {
              project_id: event.data.projectID,
              path: RelativePath.make(path.relative(event.data.directory, directory).replaceAll("\\", "/")),
              // Self-assignment suppresses the column's $onUpdate: adoption is not activity.
              time_updated: sql`${SessionTable.time_updated}`,
            })
          },
          { discard: true },
        )
      }),
    )
    yield* bus.project(SessionEvent.Deleted, (event) =>
      Effect.gen(function* () {
        yield* SessionBlob.releaseSession(db, event.data.sessionID)
        yield* db.delete(SessionTable).where(eq(SessionTable.id, event.data.sessionID)).run().pipe(Effect.orDie)
      }),
    )
    yield* bus.project(SessionEvent.AgentSelected, (event) =>
      Effect.gen(function* () {
        yield* run(db, event)
        yield* setSession(db, event.data.sessionID, { agent: event.data.agent, time_updated: event.created })
      }),
    )
    yield* bus.project(SessionEvent.ModelSelected, (event) =>
      Effect.gen(function* () {
        yield* run(db, event)
        yield* setSession(db, event.data.sessionID, { model: event.data.model, time_updated: event.created })
      }),
    )
    yield* bus.project(SessionEvent.Renamed, (event) =>
      setSession(db, event.data.sessionID, { title: event.data.title, time_updated: event.created }),
    )
    yield* bus.project(SessionEvent.MetadataUpdated, (event) =>
      setSession(db, event.data.sessionID, { metadata: event.data.metadata, time_updated: event.created }),
    )
    yield* bus.project(SessionEvent.Permissions, (event) =>
      setSession(db, event.data.sessionID, { permission: event.data.permissions, time_updated: event.created }),
    )
    yield* bus.project(SessionEvent.Viewed, (event) => {
      const idle = event.data.idle
      return setSession(db, event.data.sessionID, {
        // Monotone watermark: a duplicate or stale view never regresses, and a terminal event
        // committing after the viewer's observation keeps the newer idle transition unread.
        time_viewed: sql`max(${idle}, coalesce(${SessionTable.time_viewed}, ${idle}))`,
        time_updated: sql`${SessionTable.time_updated}`,
      })
    })
    yield* bus.project(SessionEvent.Archived, (event) =>
      setSession(db, event.data.sessionID, { time_archived: event.created, time_updated: event.created }),
    )
    yield* bus.project(SessionEvent.Unarchived, (event) =>
      setSession(db, event.data.sessionID, { time_archived: null, time_updated: event.created }),
    )
    yield* bus.project(SessionEvent.MessageContentUpdated, (event) => run(db, event))
    yield* bus.project(SessionEvent.UsageRecorded, (event) => applyUsage(db, event.data.sessionID, event.data))
    yield* bus.project(SessionEvent.Forked, (event) => projectFork(db, event))
    yield* bus.project(SessionEvent.InboxDelivered, (event) =>
      Effect.gen(function* () {
        const input = yield* SessionInbox.projectDelivered(db, {
          id: event.data.inboxID,
          sessionID: event.data.sessionID,
        })
        const time = { created: DateTime.makeUnsafe(event.created) }
        if (input.type === "user")
          yield* insertMessage(db, event, {
            id: input.id,
            type: "user",
            metadata: input.payload.metadata,
            text: input.payload.text,
            files: input.payload.files,
            agents: input.payload.agents,
            skills: input.payload.skills,
            time,
          })
        if (input.type === "synthetic")
          yield* insertMessage(db, event, {
            id: input.id,
            type: "synthetic",
            text: input.payload.text,
            description: input.payload.description,
            metadata: input.payload.metadata,
            time,
          })
      }),
    )
    yield* bus.project(SessionEvent.InboxEnqueued, (event) =>
      Effect.gen(function* () {
        yield* SessionInbox.projectAdmitted(db, {
          enqueuedSeq: event.durable.seq,
          id: event.data.inboxID,
          sessionID: event.data.sessionID,
          item: event.data.item,
          timeCreated: event.created,
        })
        yield* touch(db, event)
      }),
    )
    yield* bus.project(SessionEvent.InboxCancelled, (event) =>
      SessionInbox.projectCancelled(db, {
        id: event.data.inboxID,
        sessionID: event.data.sessionID,
      }),
    )
    yield* bus.project(SessionEvent.InboxDeliveryChanged, (event) =>
      SessionInbox.projectDeliveryChanged(db, {
        id: event.data.inboxID,
        sessionID: event.data.sessionID,
        delivery: event.data.delivery,
      }),
    )
    yield* bus.project(SessionEvent.Execution.Started, (event) =>
      setSession(db, event.data.sessionID, {
        time_busy: event.created,
        time_updated: sql`${SessionTable.time_updated}`,
      }),
    )
    yield* bus.project(SessionEvent.Execution.Succeeded, (event) => projectIdle(db, event))
    yield* bus.project(SessionEvent.Execution.Failed, (event) => projectIdle(db, event))
    yield* bus.project(SessionEvent.Execution.Interrupted, (event) => projectIdle(db, event))
    yield* bus.project(SessionEvent.InstructionsUpdated, (event) =>
      Effect.gen(function* () {
        yield* run(db, event)
        yield* InstructionState.apply(db, event.data.sessionID, event.durable.seq, event.data.delta)
      }),
    )
    yield* bus.project(SessionEvent.Synthetic, (event) => run(db, event))
    yield* bus.project(SessionEvent.Skill.Activated, (event) => run(db, event))
    yield* bus.project(SessionEvent.Shell.Started, (event) => run(db, event))
    yield* bus.project(SessionEvent.Shell.Ended, (event) => run(db, event))
    yield* bus.project(SessionEvent.Step.Started, (event) =>
      Effect.gen(function* () {
        yield* run(db, event)
        yield* touch(db, event)
      }),
    )
    yield* bus.project(SessionEvent.Step.Streamed, (event) => run(db, event))
    yield* bus.project(SessionEvent.Step.Ended, (event) =>
      Effect.gen(function* () {
        yield* run(db, event)
        yield* applyUsage(db, event.data.sessionID, event.data, event.created)
      }),
    )
    yield* bus.project(SessionEvent.Step.Failed, (event) =>
      Effect.gen(function* () {
        yield* run(db, event)
        if (event.data.cost !== undefined && event.data.tokens !== undefined)
          yield* applyUsage(
            db,
            event.data.sessionID,
            { cost: event.data.cost, tokens: event.data.tokens },
            event.created,
          )
        else yield* touch(db, event)
      }),
    )
    yield* bus.project(SessionEvent.Text.Started, (event) => run(db, event))
    yield* bus.project(SessionEvent.Text.Ended, (event) => run(db, event))
    yield* bus.project(SessionEvent.Tool.Input.Started, (event) => run(db, event))
    yield* bus.project(SessionEvent.Tool.Input.Ended, (event) => run(db, event))
    yield* bus.project(SessionEvent.Tool.Called, (event) => run(db, event))
    yield* bus.project(SessionEvent.Tool.Success, (event) => run(db, event))
    yield* bus.project(SessionEvent.Tool.Failed, (event) => run(db, event))
    yield* bus.project(SessionEvent.Reasoning.Started, (event) => run(db, event))
    yield* bus.project(SessionEvent.Reasoning.Ended, (event) => run(db, event))
    yield* bus.project(SessionEvent.RetryScheduled, (event) => run(db, event))
    yield* bus.project(SessionEvent.Compaction.Started, (event) => run(db, event))
    yield* bus.project(SessionEvent.Compaction.Ended, (event) =>
      Effect.gen(function* () {
        yield* run(db, event)
        yield* InstructionState.advanceEpoch(db, event.data.sessionID, event.durable.seq)
      }),
    )
    yield* bus.project(SessionEvent.Compaction.Failed, (event) => run(db, event))
    yield* bus.project(SessionEvent.RevertEvent.Staged, (event) =>
      setSession(db, event.data.sessionID, { revert: event.data.revert, time_updated: event.created }),
    )
    yield* bus.project(SessionEvent.RevertEvent.Cleared, (event) =>
      setSession(db, event.data.sessionID, { revert: null, time_updated: event.created }),
    )
    yield* bus.project(SessionEvent.RevertEvent.Committed, (event) =>
      Effect.gen(function* () {
        const boundary = yield* db
          .select({ seq: SessionMessageTable.seq })
          .from(SessionMessageTable)
          .where(
            and(eq(SessionMessageTable.session_id, event.data.sessionID), eq(SessionMessageTable.id, event.data.to)),
          )
          .get()
          .pipe(Effect.orDie)
        if (!boundary) return yield* Effect.die(new Error(`Revert boundary message not found: ${event.data.to}`))
        yield* db
          .delete(SessionMessageTable)
          .where(
            and(eq(SessionMessageTable.session_id, event.data.sessionID), gte(SessionMessageTable.seq, boundary.seq)),
          )
          .run()
          .pipe(Effect.orDie)
        yield* db
          .delete(SessionInboxTable)
          .where(
            and(
              eq(SessionInboxTable.session_id, event.data.sessionID),
              gte(SessionInboxTable.enqueued_seq, boundary.seq),
            ),
          )
          .run()
          .pipe(Effect.orDie)
        yield* setSession(db, event.data.sessionID, { revert: null, time_updated: event.created })
        yield* InstructionState.rewind(db, event.data.sessionID, boundary.seq)
        yield* SessionBlob.releaseFrom(db, event.data.sessionID, boundary.seq)
      }),
    )
    yield* bus.subscribe([SessionEvent.Step.Ended, SessionEvent.Step.Failed, SessionEvent.UsageRecorded]).pipe(
      Stream.runForEach((event) => {
        if (
          event.type === SessionEvent.Step.Failed.type &&
          (event.data.cost === undefined || event.data.tokens === undefined)
        )
          return Effect.void
        return publishSessionUsage(db, bus, event.data.sessionID)
      }),
      Effect.forkScoped({ startImmediately: true }),
    )
  }),
)

export const node = makeGlobalNode({ name: "session-projector", layer, deps: [Bus.node, Database.node] })
