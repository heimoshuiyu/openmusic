export declare function importModule(_specifier: string): Promise<unknown>;
export declare function resolveModule(_specifier: string, _directory: string): string;
