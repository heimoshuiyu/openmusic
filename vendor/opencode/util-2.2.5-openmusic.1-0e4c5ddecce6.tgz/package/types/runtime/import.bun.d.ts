export declare function importModule(specifier: string): Promise<unknown>;
export declare function resolveModule(specifier: string, directory: string): string;
