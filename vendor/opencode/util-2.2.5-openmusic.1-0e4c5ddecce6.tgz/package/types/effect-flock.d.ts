import { Context, Effect, Schema } from "effect";
import type { Scope } from "effect";
export declare namespace EffectFlock {
    const LockTimeoutError_base: Schema.Class<LockTimeoutError, Schema.TaggedStruct<"LockTimeoutError", {
        readonly key: Schema.String;
    }>, import("effect/Cause").YieldableError>;
    export class LockTimeoutError extends LockTimeoutError_base {
    }
    const LockCompromisedError_base: Schema.Class<LockCompromisedError, Schema.TaggedStruct<"LockCompromisedError", {
        readonly detail: Schema.String;
    }>, import("effect/Cause").YieldableError>;
    export class LockCompromisedError extends LockCompromisedError_base {
    }
    export type LockError = LockTimeoutError | LockCompromisedError;
    export interface Options {
        readonly staleMs?: number;
        readonly timeoutMs?: number;
    }
    export interface Interface {
        readonly acquire: (key: string, dir?: string, options?: Options) => Effect.Effect<void, LockError, Scope.Scope>;
        readonly withLock: {
            (key: string, dir?: string): <A, E, R>(body: Effect.Effect<A, E, R>) => Effect.Effect<A, E | LockError, R>;
            <A, E, R>(body: Effect.Effect<A, E, R>, key: string, dir?: string): Effect.Effect<A, E | LockError, R>;
        };
    }
    const Service_base: Context.ServiceClass<Service, "EffectFlock", Interface>;
    export class Service extends Service_base {
    }
    export const node: import("./effect/layer-node.js").Provider<Service, never, import("./effect/layer-node.js").Tag<"global">>;
    export {};
}
