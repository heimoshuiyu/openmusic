export * as Observability from "./observability.js";
import { LayerNode } from "./effect/layer-node.js";
import { Layer, Schema } from "effect";
export declare const Options: Schema.Struct<{
    readonly endpoint: Schema.optional<Schema.String>;
    readonly headers: Schema.optional<Schema.String>;
    readonly client: Schema.optional<Schema.String>;
    readonly version: Schema.optional<Schema.String>;
    readonly channel: Schema.optional<Schema.String>;
}>;
export type Options = typeof Options.Type;
export declare function layer(options?: Options): Layer.Layer<never, never, never>;
export declare const node: LayerNode.Provider<never, never, undefined>;
