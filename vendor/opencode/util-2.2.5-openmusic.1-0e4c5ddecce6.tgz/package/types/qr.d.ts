/** Encodes text as UTF-8 into the smallest QR Code that fits. Rows of modules without a quiet zone; true is dark. */
export declare function encode(text: string): boolean[][];
/** Renders text as an SVG QR Code with 10-unit modules and a quiet zone of `border` modules. */
export declare function renderSVG(text: string, options?: {
    border?: number;
    blackColor?: string;
    whiteColor?: string;
}): string;
/**
 * Renders text as a QR Code for a terminal, two modules per character with half blocks. Light modules draw as blocks
 * and dark modules as the terminal background, rows are joined with "\n", and the quiet zone is `border` modules.
 */
export declare function renderUnicodeCompact(text: string, options?: {
    border?: number;
}): string;
