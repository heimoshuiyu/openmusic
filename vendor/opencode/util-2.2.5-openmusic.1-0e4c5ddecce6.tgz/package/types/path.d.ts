export declare function getFilename(path: string | undefined): string;
export declare function getDirectory(path: string | undefined): string;
export declare function getFilenameTruncated(path: string | undefined, maxLength?: number): string;
export declare function truncateMiddle(text: string, maxLength?: number): string;
/** A comparable form of a directory path: forward slashes for Windows paths, no trailing slash except on roots. */
export declare function comparablePath(path: string): string;
/** `child` is `parent` or inside it. Windows drive and UNC paths compare case-insensitively. */
export declare function containsDirectory(parent: string, child: string): boolean;
export declare function sameDirectory(a: string, b: string): boolean;
export declare function encodeFilePath(filepath: string): string;
export declare function isLineRangeHash(hash: string): boolean;
export declare function parsePathLineSuffix(input: string): {
    path: string;
    selection: {
        start: number;
        end: number;
    } | undefined;
};
