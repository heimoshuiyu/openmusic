export * as Teardown from "./teardown.js";
/** Record pending work; call the returned function once it settles. */
export declare function track(label: string): () => void;
/** Pending work, oldest first, with how long each has been pending. */
export declare function pending(now?: number): {
    label: string;
    ms: number;
}[];
