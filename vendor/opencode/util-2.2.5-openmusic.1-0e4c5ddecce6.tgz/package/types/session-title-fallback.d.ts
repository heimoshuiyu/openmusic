export * as SessionTitleFallback from "./session-title-fallback.js";
interface Info {
    readonly title?: string;
    readonly parentID?: string;
    readonly time: {
        readonly created: number;
    };
}
/** Supplies the timestamped title required by compatibility surfaces. */
export declare function withTimestampedFallback(info: Info): string;
/** Supplies a compact human label and collapses historical timestamped fallbacks. */
export declare function displayLabel(info: Pick<Info, "title" | "parentID">): string;
/** Recognizes missing and historical root or child fallback titles. */
export declare function isFallbackTitle(title?: string): boolean;
/** Recognizes a missing title or the exact root fallback for this session. */
export declare function isExactRootFallback(info: Pick<Info, "title" | "time">): boolean;
