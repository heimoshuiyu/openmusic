export * as NpmConfig from "./npm-config.js";
import { Effect } from "effect";
export declare const load: (dir: string) => Effect.Effect<Record<string, unknown>, never, never>;
export declare const registry: (dir: string) => Effect.Effect<string, never, never>;
