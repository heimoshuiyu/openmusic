import { Effect } from "effect";
/**
 * Writes a V8 heap snapshot of this process into `directory` and returns once the file is complete, with the
 * process's memory just before the snapshot: the snapshot holds only the garbage-collected heap, and writing it
 * raises the process's memory. Blocks the event loop while the heap serializes. The file can contain secrets, so it
 * is created owner-only before the runtime writes into it.
 */
export declare const write: (directory: string) => Effect.Effect<{
    path: string;
    pid: number;
    memory: {
        rss: number;
        heapTotal: number;
        heapUsed: number;
        external: number;
        arrayBuffers: number;
    };
}, import("effect/Cause").UnknownError, never>;
export * as HeapSnapshot from "./heap-snapshot.js";
