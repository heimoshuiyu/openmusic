/** How the app shows a file, from its extension. */
export type ArtifactKind = "image" | "svg" | "audio" | "video" | "pdf" | "html" | "markdown" | "mermaid" | "table" | "font" | "document" | "spreadsheet" | "presentation" | "text";
export declare function artifactMime(path: string): string | undefined;
export declare function artifactKind(path: string): ArtifactKind;
