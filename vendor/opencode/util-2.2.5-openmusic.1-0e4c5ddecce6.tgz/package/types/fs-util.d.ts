import { Context, Effect, FileSystem, Layer, Schema } from "effect";
import type { PlatformError } from "effect/PlatformError";
import { Glob } from "./glob.js";
export declare namespace FSUtil {
    const FileSystemError_base: Schema.Class<FileSystemError, Schema.TaggedStruct<"FileSystemError", {
        readonly method: Schema.String;
        readonly cause: Schema.optional<Schema.Defect>;
    }>, import("effect/Cause").YieldableError>;
    export class FileSystemError extends FileSystemError_base {
        get message(): string;
    }
    export type Error = PlatformError | FileSystemError;
    export interface UpOptions {
        readonly targets: string[];
        readonly start: string;
        readonly stop?: string;
        readonly mode?: "all" | "first";
        /** Only match regular files or directories (following symlinks). By default any existing path matches. */
        readonly type?: "file" | "directory";
    }
    export interface Interface extends FileSystem.FileSystem {
        readonly isDir: (path: string) => Effect.Effect<boolean>;
        readonly isFile: (path: string) => Effect.Effect<boolean>;
        readonly existsSafe: (path: string) => Effect.Effect<boolean>;
        readonly readFileStringSafe: (path: string) => Effect.Effect<string | undefined, Error>;
        readonly readJson: (path: string) => Effect.Effect<unknown, Error>;
        readonly writeJson: (path: string, data: unknown, mode?: number) => Effect.Effect<void, Error>;
        readonly ensureDir: (path: string) => Effect.Effect<void, Error>;
        readonly writeWithDirs: (path: string, content: string | Uint8Array, mode?: number) => Effect.Effect<void, Error>;
        readonly resolve: (path: string) => Effect.Effect<string>;
        readonly findUp: (target: string, start: string, stop?: string) => Effect.Effect<string[], Error>;
        readonly up: (options: UpOptions) => Effect.Effect<string[], Error>;
        readonly globUp: (pattern: string, start: string, stop?: string) => Effect.Effect<string[], Error>;
        readonly scan: (pattern: string, options?: Glob.Options) => Effect.Effect<string[], Error>;
        readonly globMatch: (pattern: string, filepath: string) => boolean;
    }
    const Service_base: Context.ServiceClass<Service, "@opencode/FSUtil", Interface>;
    export class Service extends Service_base {
    }
    export const layer: Layer.Layer<Service, never, FileSystem.FileSystem>;
    export const node: import("./effect/layer-node.js").Provider<Service, never, import("./effect/layer-node.js").Tag<"global">>;
    /** Permission denial, including macOS sandbox and privacy denials that surface as Unknown with an EPERM cause. */
    export function isAccessDenied(error: PlatformError): boolean;
    export function mimeType(p: string): string;
    export function normalizePath(p: string): string;
    export function resolve(p: string): string;
    export function windowsPath(p: string): string;
    export const ignoredDirectories: string[];
    export const ignoreGlobs: string[];
    export function overlaps(a: string, b: string): boolean;
    export function contains(parent: string, child: string): boolean;
    export {};
}
