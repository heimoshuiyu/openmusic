import { Brand, Context, Layer } from "effect";
export * as LayerNode from "./layer-node.js";
declare const GraphTypeId: unique symbol;
declare const VarianceTypeId: unique symbol;
declare const NodeTypeId: unique symbol;
declare const ReplacementTypeId: unique symbol;
export type Tag<Name extends string = string> = Name & Brand.Brand<"LayerNode.Tag">;
export type Graph<A, E = never, T extends Tag | undefined = Tag | undefined> = GraphValue<A, E, T>;
export type Node<A, E = never, T extends Tag | undefined = undefined> = NodeValue<A, E, T>;
export type Provider<A, E = never, T extends Tag | undefined = undefined> = ProviderNode<A, E, T>;
export type Replacement = ReplacementValue;
export type Replacements = readonly Replacement[];
type AnyGraph = Graph<never, unknown>;
type AnyNode = AnyGraph & {
    readonly [NodeTypeId]: unknown;
    readonly tag: Tag | undefined;
};
type RuntimeLayer = Layer.Layer<never, unknown, unknown>;
type GraphList = readonly [] | readonly [AnyGraph, ...AnyGraph[]];
export type Output<Item> = CommonOutput<Item, Item extends Graph<infer A, unknown> ? A : never>;
export type Error<Item> = Item extends Graph<never, infer E> ? E : never;
type GraphTag<Item> = [Item] extends [never] ? undefined : Item extends Graph<never, unknown, infer T> ? T : never;
type CommonOutput<Item, A> = A extends unknown ? ([Item] extends [Graph<A, unknown>] ? A : never) : never;
type LayerOutput<Item extends Layer.Any, A = Layer.Success<Item>> = A extends unknown ? [Item] extends [Layer.Layer<A, unknown, unknown>] ? A : never : never;
type ListOutput<Items extends readonly AnyGraph[], A = never> = [Items] extends [
    readonly [infer Head extends AnyGraph, ...infer Tail extends readonly AnyGraph[]]
] ? ListOutput<Tail, A | Output<Head>> : A;
type Definition = {
    readonly kind: "group";
    readonly name: string;
    readonly dependencies: readonly AnyGraph[];
} | {
    readonly kind: "unbound";
    readonly name: string;
} | {
    readonly kind: "layer";
    readonly name: string;
    readonly implementation: RuntimeLayer;
    readonly dependencies: readonly AnyGraph[];
};
declare class GraphValue<in A, out E, out T extends Tag | undefined> {
    private readonly graph;
    readonly [VarianceTypeId]: {
        readonly output: (_: A) => void;
        readonly error: () => E;
        readonly tags: () => T;
    };
    readonly [GraphTypeId]: Definition;
    constructor(definition: Definition);
    get name(): string;
}
declare class NodeValue<in out A, in out E, in out T extends Tag | undefined> extends GraphValue<A, E, T> {
    readonly tag: T;
    readonly [NodeTypeId]: (_: [A, E, T]) => [A, E, T];
    constructor(definition: Exclude<Definition, {
        kind: "group";
    }>, tag: T);
    /** Replace this declaration, including every dependency on it, without acquiring its old wiring. */
    replace<const Target extends AnyNode | Layer.Any>(this: Node<A, E, T>, replacement: Target & CheckReplacement<A, E, T, Target>): Replacement;
}
declare class ProviderNode<in out A, in out E, in out T extends Tag | undefined> extends NodeValue<A, E, T> {
    /** Decorate the implementation while preserving its dependency wiring and service contract. */
    mapLayer(this: Provider<A, E, T>, f: <R>(layer: Layer.Layer<A, E, R>) => Layer.Layer<A, E, R>): Provider<A, E, T>;
}
declare class ReplacementValue {
    private readonly checked;
    readonly [ReplacementTypeId]: {
        readonly source: AnyNode;
        readonly target: AnyNode;
    };
    constructor(source: AnyNode, target: AnyNode);
}
type CheckErrors<Expected, Actual> = [Exclude<Actual, Expected>] extends [never] ? never : {
    readonly "New replacement errors": Exclude<Actual, Expected>;
};
type CheckReplacement<A, E, T, Target> = [ReplacementErrors<A, E, T, Target>] extends [never] ? unknown : ReplacementErrors<A, E, T, Target>;
type ReplacementErrors<A, E, T, Target> = Target extends AnyNode ? [Exclude<A, Output<Target>>] extends [never] ? [GraphTag<Target>] extends [T] ? CheckErrors<E, Error<Target>> : {
    readonly "Invalid replacement tag": GraphTag<Target>;
} : {
    readonly "Missing replacement outputs": Exclude<A, Output<Target>>;
} : Target extends Layer.Layer<A, infer E2, never> ? CheckErrors<E, E2> : {
    readonly "Replacement must be a closed layer": Target;
};
type CheckDependencies<Implementation extends Layer.Any, Items extends GraphList> = [
    Exclude<Layer.Services<Implementation>, ListOutput<Items>>
] extends [never] ? unknown : {
    readonly "Missing dependencies": Exclude<Layer.Services<Implementation>, ListOutput<Items>>;
};
type Identity = {
    readonly service: Context.Service.Any;
    readonly name?: never;
} | {
    readonly name: string;
    readonly service?: never;
};
type CheckLayer<Implementation> = [Implementation] extends [RuntimeLayer] ? unknown : {
    readonly "Layer contract must be preserved": Implementation;
};
type TagInput<T> = {
    readonly tag: T;
} | ([T] extends [undefined] ? {
    readonly tag?: undefined;
} : never);
type MakeInput<Implementation extends Layer.Any, Items extends GraphList, T extends Tag | undefined> = Identity & TagInput<T> & {
    readonly layer: Implementation & CheckLayer<NoInfer<Implementation>>;
    readonly deps: Items & CheckDependencies<Implementation, NoInfer<Items>>;
};
type DistributiveOmit<A, K extends PropertyKey> = A extends unknown ? Omit<A, K> : never;
export type TagConfig = Readonly<Record<string, readonly string[]>>;
type TagNames<Config extends TagConfig> = keyof Config & string;
type CheckTags<Items extends GraphList, Names extends string> = [
    Exclude<GraphTag<Items[number]>, Tag<Names> | undefined>
] extends [never] ? unknown : {
    readonly "Invalid tag dependencies": Exclude<GraphTag<Items[number]>, Tag<Names> | undefined>;
};
export interface Tags<Config extends TagConfig> {
    readonly values: {
        readonly [Name in TagNames<Config>]: Tag<Name>;
    };
    readonly make: <Name extends TagNames<Config>>(name: Name) => TagMaker<Config, Name>;
}
export type TagMaker<Config extends TagConfig, Name extends TagNames<Config>> = <const Implementation extends Layer.Any, const Items extends GraphList>(input: DistributiveOmit<MakeInput<Implementation, Items, Tag<Name>>, "tag"> & CheckTags<Items, Name | Extract<Config[Name][number], string>>) => Provider<LayerOutput<Implementation>, Layer.Error<Implementation> | Error<Items[number]>, Tag<Name>>;
export declare function tags<const Config extends {
    readonly [Name in keyof Config]: readonly (keyof Config & string)[];
}>(config: Config): Tags<Config>;
export declare function make<const Implementation extends Layer.Any, const Items extends GraphList, const T extends Tag | undefined = undefined>(input: MakeInput<Implementation, Items, T>): Provider<LayerOutput<Implementation>, Layer.Error<Implementation> | Error<Items[number]>, T>;
export declare function unbound<R, Shape, const T extends Tag>(service: Context.Key<R, Shape>, tag: T): Node<R, never, T>;
/** Ordered, associative composition. Only these roots' outputs are exposed; their dependencies remain private. */
export declare function group<const Items extends readonly AnyGraph[]>(dependencies: Items): Graph<ListOutput<Items>, Error<Items[number]>, GraphTag<Items[number]>>;
export interface CompileOptions {
    readonly replacements?: Replacements;
    /** Share subgraphs rooted at this tag; give the remaining wiring a fresh map for each build. */
    readonly shared?: Tag;
}
/** Resolve the final overrides before validating or acquiring anything. Effect owns acquisition and finalization. */
export declare function compile<A, E>(root: Graph<A, E>, options?: CompileOptions): Layer.Layer<A, E>;
