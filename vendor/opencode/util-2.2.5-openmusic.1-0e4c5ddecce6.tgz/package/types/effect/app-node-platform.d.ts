import { FileSystem, Layer, Path } from "effect";
import { HttpClient } from "effect/http";
export declare const filesystem: import("./layer-node.js").Provider<FileSystem.FileSystem, never, import("./layer-node.js").Tag<"global">>;
export declare const path: import("./layer-node.js").Provider<Path.Path, never, import("./layer-node.js").Tag<"global">>;
export type Fetch = (input: Request | string | URL, init?: RequestInit) => Promise<Response>;
/**
 * The fetch behind `httpClient`, AI SDK providers and remote MCP servers: `fetch` when given, so an embedder can route requests through
 * e.g. a Service Binding, otherwise the `FetchHttpClient.Fetch` in scope when the graph is built.
 */
export declare const fetchLayer: (fetch?: Fetch) => Layer.Layer<never, never, never>;
export declare const httpFetch: import("./layer-node.js").Provider<never, never, import("./layer-node.js").Tag<"global">>;
export declare const httpClient: import("./layer-node.js").Provider<HttpClient.HttpClient, never, import("./layer-node.js").Tag<"global">>;
export * as LayerNodePlatform from "./app-node-platform.js";
