import { LayerNode } from "./layer-node.js";
export declare const tags: LayerNode.Tags<{
    readonly location: readonly ["global"];
    readonly global: readonly [];
}>;
export type GlobalGraph<A, E = never> = LayerNode.Graph<A, E, (typeof tags.values)["global"]>;
export type LocationGraph<A, E = never> = LayerNode.Graph<A, E, (typeof tags.values)["location" | "global"]>;
export declare const makeGlobalNode: LayerNode.TagMaker<{
    readonly location: readonly ["global"];
    readonly global: readonly [];
}, "global">;
export declare const makeLocationNode: LayerNode.TagMaker<{
    readonly location: readonly ["global"];
    readonly global: readonly [];
}, "location">;
export * as Node from "./app-node.js";
