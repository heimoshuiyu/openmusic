export type FlockGlobal = {
    state: string;
};
export declare namespace Flock {
    function setGlobal(g: FlockGlobal): void;
    interface WaitEvent {
        key: string;
        attempt: number;
        delay: number;
        waited: number;
    }
    type Wait = (input: WaitEvent) => void | Promise<void>;
    interface Options {
        dir?: string;
        signal?: AbortSignal;
        staleMs?: number;
        timeoutMs?: number;
        baseDelayMs?: number;
        maxDelayMs?: number;
        onWait?: Wait;
    }
    interface Lease {
        release: () => Promise<void>;
        [Symbol.asyncDispose]: () => Promise<void>;
    }
    function acquire(key: string, input?: Options): Promise<Lease>;
    function withLock<T>(key: string, fn: () => Promise<T>, input?: Options): Promise<T>;
}
