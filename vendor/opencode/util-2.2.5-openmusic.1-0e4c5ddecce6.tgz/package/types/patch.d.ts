export * as Patch from "./patch.js";
import { Result, Schema } from "effect";
declare const BoundaryError_base: Schema.Class<BoundaryError, Schema.TaggedStruct<"Patch.BoundaryError", {
    readonly boundary: Schema.Literals<readonly ["first", "last"]>;
}>, import("effect/Cause").YieldableError>;
export declare class BoundaryError extends BoundaryError_base {
    get message(): string;
}
declare const InvalidHunkError_base: Schema.Class<InvalidHunkError, Schema.TaggedStruct<"Patch.InvalidHunkError", {
    readonly line: Schema.String;
    readonly lineNumber: Schema.Number;
    readonly reason: Schema.optional<Schema.String>;
}>, import("effect/Cause").YieldableError>;
export declare class InvalidHunkError extends InvalidHunkError_base {
    get message(): string;
}
export type ParseError = BoundaryError | InvalidHunkError;
export type Hunk = {
    readonly type: "add";
    readonly path: string;
    readonly contents: string;
} | {
    readonly type: "delete";
    readonly path: string;
} | {
    readonly type: "update";
    readonly path: string;
    readonly movePath?: string;
    readonly chunks: ReadonlyArray<UpdateFileChunk>;
};
export interface UpdateFileChunk {
    readonly oldLines: ReadonlyArray<string>;
    readonly newLines: ReadonlyArray<string>;
    readonly changeContext?: string;
    readonly endOfFile?: boolean;
}
export interface FileUpdate {
    readonly content: string;
    readonly bom: boolean;
}
export declare function parse(patchText: string): Result.Result<ReadonlyArray<Hunk>, ParseError>;
export declare function derive(path: string, chunks: ReadonlyArray<UpdateFileChunk>, original: string): FileUpdate;
export declare function joinBom(text: string, bom: boolean): string;
