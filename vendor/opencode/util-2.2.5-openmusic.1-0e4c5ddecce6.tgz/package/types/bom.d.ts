export * as Bom from "./bom.js";
import { Effect } from "effect";
import type { FSUtil } from "./fs-util.js";
export declare function split(text: string): {
    bom: boolean;
    text: string;
};
export declare function join(text: string, bom: boolean): string;
export declare function has(content: Uint8Array): boolean;
export declare function decodeBytes(content: Uint8Array): {
    bom: boolean;
    text: string;
};
export declare function syncBytes(content: Uint8Array, bom: boolean): {
    text: string;
    bytes: Uint8Array<ArrayBuffer> | undefined;
};
export declare const readFile: (fs: FSUtil.Interface, filepath: string) => Effect.Effect<{
    bom: boolean;
    text: string;
}, import("effect/PlatformError").PlatformError, never>;
export declare const syncFile: (fs: FSUtil.Interface, filepath: string, bom: boolean) => Effect.Effect<string, FSUtil.Error, never>;
