import { ChildProcessSpawner } from "effect/process/ChildProcessSpawner";
/** Closing a child's scope escalates to SIGKILL after this, unless the command sets its own `forceKillAfter`. */
export declare const RELEASE_FORCE_KILL_AFTER = "3 seconds";
export declare class KilledBySignal extends Error {
    readonly signal: NodeJS.Signals;
    constructor(signal: NodeJS.Signals);
}
export declare const node: import("./effect/layer-node.js").Provider<ChildProcessSpawner, never, import("./effect/layer-node.js").Tag<"global">>;
export * as CrossSpawnSpawner from "./cross-spawn-spawner.js";
