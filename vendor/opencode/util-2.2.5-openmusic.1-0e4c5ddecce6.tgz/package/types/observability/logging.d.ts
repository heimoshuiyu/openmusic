import { Effect, FileSystem, Logger } from "effect";
export declare const LOG_MAX_BYTES: number;
export declare const LOG_KEEP_BYTES: number;
export declare const LOG_TRIM_INTERVAL = "1 hour";
export declare const LOG_TRIM_LOCK_STALE_MS: number;
export declare function file(local?: boolean, channel?: string): string;
export declare function fileLogger(target?: string, id?: string): Effect.Effect<Logger.Logger<unknown, void>, import("effect/PlatformError").PlatformError, FileSystem.FileSystem | import("effect/Scope").Scope>;
export declare const trim: (target: string, options?: {
    max?: number;
    keep?: number;
} | undefined) => Effect.Effect<void, import("effect/PlatformError").PlatformError, FileSystem.FileSystem>;
export declare function minimumLogLevel(): "Debug" | "Error" | "Info" | "Warn";
export declare function loggers(local?: boolean, channel?: string): (Effect.Effect<Logger.Logger<unknown, void>, import("effect/PlatformError").PlatformError, FileSystem.FileSystem | import("effect/Scope").Scope> | Logger.Logger<unknown, void>)[];
export * as Logging from "./logging.js";
