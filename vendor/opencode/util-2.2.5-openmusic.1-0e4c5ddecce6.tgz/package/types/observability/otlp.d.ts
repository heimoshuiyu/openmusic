import { Effect, Layer, Scope } from "effect";
export interface Options {
    readonly endpoint?: string;
    readonly headers?: string;
}
export interface App {
    readonly client: string;
    readonly version: string;
    readonly channel: string;
}
export declare function resource(app?: App): {
    serviceName: string;
    serviceVersion: string;
    attributes: Record<string, string>;
};
export declare function loggers(options: Options | undefined, app: App): Effect.Effect<import("effect/Logger").Logger<unknown, void>, never, import("effect/observability/OtlpExporter").Flusher | import("effect/http/HttpClient").HttpClient | import("effect/observability/OtlpSerialization").OtlpSerialization | Scope.Scope>[];
export declare const tracingLayer: (options: Options | undefined, app: App) => Effect.Effect<Layer.Layer<never, never, never>, never, never>;
export * as Otlp from "./otlp.js";
