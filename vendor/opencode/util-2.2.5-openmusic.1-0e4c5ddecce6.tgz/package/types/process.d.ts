import { Context, Duration, Effect, Schema, Stream } from "effect";
import type { PlatformError } from "effect/PlatformError";
import { ChildProcess } from "effect/process";
import { ChildProcessSpawner } from "effect/process/ChildProcessSpawner";
declare const AppProcessError_base: Schema.Class<AppProcessError, Schema.TaggedStruct<"AppProcessError", {
    readonly command: Schema.String;
    readonly exitCode: Schema.optional<Schema.Number>;
    readonly stderr: Schema.optional<Schema.String>;
    readonly cause: Schema.optional<Schema.Defect>;
}>, import("effect/Cause").YieldableError>;
export declare class AppProcessError extends AppProcessError_base {
    get message(): string;
}
export interface RunOptions {
    readonly combineOutput?: boolean;
    readonly maxOutputBytes?: number;
    readonly maxErrorBytes?: number;
    readonly signal?: AbortSignal;
    readonly timeout?: Duration.Input;
    readonly stdin?: string | Uint8Array | Stream.Stream<Uint8Array, PlatformError>;
}
export interface RunStreamOptions {
    readonly signal?: AbortSignal;
    readonly includeStderr?: boolean;
    readonly okExitCodes?: ReadonlyArray<number>;
    readonly maxErrorBytes?: number;
}
export interface RunResult {
    readonly command: string;
    readonly exitCode: number;
    readonly output?: Buffer;
    readonly stdout: Buffer;
    readonly stderr: Buffer;
    readonly outputTruncated?: boolean;
    readonly stdoutTruncated: boolean;
    readonly stderrTruncated: boolean;
}
export type Interface = ChildProcessSpawner["Service"] & {
    readonly run: (command: ChildProcess.Command, options?: RunOptions) => Effect.Effect<RunResult, AppProcessError>;
    readonly runStream: (command: ChildProcess.Command, options?: RunStreamOptions) => Stream.Stream<string, AppProcessError>;
};
declare const Service_base: Context.ServiceClass<Service, "@opencode/AppProcess", Interface>;
export declare class Service extends Service_base {
}
export declare const requireSuccess: (result: RunResult) => Effect.Effect<RunResult, AppProcessError>;
export declare const requireExitIn: (codes: ReadonlyArray<number>) => (result: RunResult) => Effect.Effect<RunResult, AppProcessError>;
export declare const abortError: (signal: AbortSignal) => Error;
export declare const waitForAbort: (signal: AbortSignal) => Effect.Effect<never, Error, never>;
export declare const collectStream: (stream: Stream.Stream<Uint8Array, PlatformError>, maxOutputBytes: number | undefined) => Effect.Effect<{
    buffer: Buffer<ArrayBuffer>;
    truncated: boolean;
}, PlatformError, never>;
export declare const node: import("./effect/layer-node.js").Provider<Service, never, import("./effect/layer-node.js").Tag<"global">>;
export * as AppProcess from "./process.js";
