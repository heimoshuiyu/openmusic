export declare const noTimeoutFetch: typeof fetch;
