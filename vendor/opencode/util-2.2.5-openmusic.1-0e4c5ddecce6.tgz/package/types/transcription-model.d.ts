/** The catalog picker and the service must accept the same audio protocols, including legacy package names. */
export declare function transcriptionModelIssue(model: {
    package?: string;
    capabilities: {
        input: readonly string[];
    };
}): "audio" | "package" | undefined;
