export declare function activityCalendar(input: {
    activity: readonly {
        date: string;
        steps: number;
    }[];
    from: number;
    to: number;
    maxWeeks: number;
}): {
    weeks: {
        date: string;
        steps: number;
        level: number;
    }[][];
    months: {
        week: number;
        label: string;
        span: number;
    }[];
    clipped: boolean;
};
