/** The XDG base directories that root opencode's global paths. */
export declare function roots(app: string): {
    data: string;
    cache: string;
    config: string;
    state: string;
    tmp: string;
};
