import { Context, Layer } from "effect";
export declare const Path: {
    readonly home: string;
    data: string;
    bin: string;
    log: string;
    repos: string;
    cache: string;
    config: string;
    state: string;
    tmp: string;
};
declare const Service_base: Context.ServiceClass<Service, "@opencode/Global", Interface>;
export declare class Service extends Service_base {
}
export interface Interface {
    readonly home: string;
    readonly data: string;
    readonly cache: string;
    readonly config: string;
    readonly state: string;
    readonly tmp: string;
    readonly bin: string;
    readonly log: string;
    readonly repos: string;
}
export declare function make(input?: Partial<Interface>): Interface;
export declare const node: import("./effect/layer-node.js").Provider<Service, never, import("./effect/layer-node.js").Tag<"global">>;
export declare const layerWith: (input: Partial<Interface>) => Layer.Layer<Service, never, never>;
export * as Global from "./global.js";
