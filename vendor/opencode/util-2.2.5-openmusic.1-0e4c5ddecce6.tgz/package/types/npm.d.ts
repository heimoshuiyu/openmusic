export * as Npm from "./npm.js";
import { Effect, Schema, Context } from "effect";
import { EffectFlock } from "./effect-flock.js";
declare const InstallFailedError_base: Schema.Class<InstallFailedError, Schema.TaggedStruct<"NpmInstallFailedError", {
    readonly add: Schema.optional<Schema.$Array<Schema.String>>;
    readonly dir: Schema.String;
    readonly cause: Schema.optional<Schema.Defect>;
}>, import("effect/Cause").YieldableError>;
export declare class InstallFailedError extends InstallFailedError_base {
    get message(): string;
}
export interface Package {
    readonly directory: string;
    readonly name: string;
    readonly version?: string;
    readonly revision?: string;
}
export interface Interface {
    readonly add: (pkg: string) => Effect.Effect<Package, InstallFailedError | EffectFlock.LockError>;
    readonly resolve: (pkg: string) => Effect.Effect<Package>;
    readonly check: (pkg: string) => Effect.Effect<boolean, InstallFailedError>;
    readonly update: (pkg: string) => Effect.Effect<Package, InstallFailedError | EffectFlock.LockError>;
    readonly which: (pkg: string, bin?: string) => Effect.Effect<string | undefined>;
}
declare const Service_base: Context.ServiceClass<Service, "@opencode/Npm", Interface>;
export declare class Service extends Service_base {
}
export declare function sanitize(pkg: string): string;
export declare function isRegistryPackage(pkg: string): Promise<boolean>;
export declare function isInstallablePackage(pkg: string): Promise<boolean>;
export declare function cacheKey(pkg: string): Promise<string>;
export declare const node: import("./effect/layer-node.js").Provider<Service, never, import("./effect/layer-node.js").Tag<"global">>;
