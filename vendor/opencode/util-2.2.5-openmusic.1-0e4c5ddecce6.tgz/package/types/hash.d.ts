export declare namespace Hash {
    function fast(input: string | Buffer): string;
    function sha256(input: string | Buffer): string;
}
