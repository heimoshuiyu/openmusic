/** Encodes bytes as standard base64. */
export declare function bytesToBase64(bytes: Uint8Array): string;
/** Decodes standard base64 into bytes. */
export declare function base64ToBytes(value: string): Uint8Array<ArrayBuffer>;
