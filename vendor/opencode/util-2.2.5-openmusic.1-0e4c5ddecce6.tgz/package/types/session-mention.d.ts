export type SessionMention = {
    id: `ses_${string}`;
};
export declare function sessionMentions(text: string): {
    id: SessionMention["id"];
    text: string;
    start: number;
    end: number;
}[];
export declare function parseSessionMention(text: string): SessionMention | undefined;
export declare function serializeSessionMention(mention: SessionMention): string;
