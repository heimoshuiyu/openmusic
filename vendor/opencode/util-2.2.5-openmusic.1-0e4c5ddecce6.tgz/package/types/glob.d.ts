export declare namespace Glob {
    interface Options {
        cwd?: string;
        absolute?: boolean;
        include?: "file" | "all";
        dot?: boolean;
        symlink?: boolean;
        ignore?: string[];
    }
    function scan(pattern: string, options?: Options): Promise<string[]>;
    function match(pattern: string, filepath: string): boolean;
}
