export * as ProcessSignal from "./process-signal.js";
/** Install once at process startup. Removing subscribers never restores the signal's default action. */
export declare function install(signal: NodeJS.Signals, unavailable: () => void): void;
/** Subscribe only to an installed signal. The returned cleanup removes this subscriber, not the process handler. */
export declare function subscribe(signal: NodeJS.Signals, listener: () => void): () => void;
