export declare function openUrl(input: string): Promise<import("child_process").ChildProcess>;
export declare function openPath(path: string): Promise<import("child_process").ChildProcess>;
