export * as SessionTurn from "./session-turn.js";
/** The fields of a session message that turn measurements read. Client session messages satisfy it as they are. */
export interface Message {
    readonly id: string;
    readonly type: string;
    readonly time: {
        readonly created: number;
        readonly streamed?: number;
        readonly completed?: number;
    };
    readonly tokens?: {
        readonly output: number;
        readonly reasoning: number;
    };
}
export interface Options {
    /** The position of `message` in `messages`. Reactive callers should pass it so the lookup does not read every message. */
    readonly index?: number;
    /**
     * Whether the session has no idle markers, so a turn ends at the next prompt. Reactive callers should pass it from a
     * shared memo: the default scans every message, which subscribes the caller to the whole history.
     */
    readonly legacy?: boolean;
}
/** Milliseconds from the prompt that started the turn until `message` completed, or 0 while it runs. */
export declare function duration(messages: readonly Message[], message: Message, options?: Options): number;
/** Output and reasoning tokens per second across the turn's steps up to `message`, or undefined until every step has streamed. */
export declare function tokensPerSecond(messages: readonly Message[], message: Message, options?: Options): number | undefined;
export declare function legacy(messages: readonly Message[]): boolean;
