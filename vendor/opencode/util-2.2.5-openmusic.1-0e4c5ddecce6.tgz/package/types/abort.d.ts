export declare function abort(controller: AbortController | undefined): void;
